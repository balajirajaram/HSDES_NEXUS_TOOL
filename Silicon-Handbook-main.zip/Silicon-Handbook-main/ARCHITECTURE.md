# Silicon Handbook — Knowledge Assistant Overview

## What It Is

Silicon Handbook is a **domain-specific knowledge agent** for VS Code Copilot. It acts as a chip engineering expert that can:

1. **Answer instantly** from curated reference files (acronyms, milestones, steppings)
2. **Search intelligently** across Intel data sources using structured query strategies
3. **Explain consistently** using standardized answer templates

## How It Works — Block Diagram

```mermaid
flowchart TD
    User["👤 Engineer asks a question"]
    Agent["🤖 Chip Engineer Agent"]
    Classify{"Classify Query"}
    
    S1["intel-tech-lookup skill"]
    S2["silicon-process skill"]
    
    R1["📄 common-acronyms.md"]
    R2["📄 search-strategy.md"]
    R3["📄 milestones.md"]
    R4["📄 stepping-conventions.md"]
    
    Found{"Answer in\nreferences?"}
    
    Confluence["🔍 Confluence Wiki"]
    SharePoint["🔍 SharePoint Docs"]
    Atlas["🔍 Atlas Dashboard"]
    TechLib["🔍 Intel Tech Library"]
    
    Format["📋 Structured Answer\n• Full form\n• Definition\n• Technical details\n• Related terms"]
    
    User --> Agent
    Agent --> Classify
    
    Classify -->|"Acronyms, SDM,\ncodenames, architecture"| S1
    Classify -->|"Milestones, steppings,\nECO, samples"| S2
    Classify -->|"Ambiguous"| S1 & S2
    
    S1 --> R1 & R2
    S2 --> R3 & R4
    
    R1 & R2 & R3 & R4 --> Found
    
    Found -->|"Yes"| Format
    Found -->|"No — search external"| Confluence & SharePoint & Atlas & TechLib
    
    Confluence & SharePoint & Atlas & TechLib --> Format
    Format --> User
```

## Query Flow Summary

| Step | Action | Latency |
|------|--------|---------|
| 1. **Receive** | User asks question via `@chip-engineer` | — |
| 2. **Classify** | Agent determines domain: tech-lookup vs silicon-process | Instant |
| 3. **Check references** | Search built-in markdown files for instant answer | Instant |
| 4. **Search external** | If not found → query Confluence, SharePoint, Atlas, Tech Library | 2-5 sec |
| 5. **Format** | Apply structured answer template | Instant |
| 6. **Respond** | Return formatted answer to user | — |

## Comparison: Knowledge Assistant vs Live Tool vs Agent

| Dimension | Silicon Handbook (Knowledge Assistant) | Codesign MCP (Live Tool) | Full Agent (Geni) |
|-----------|---------------------------------------|--------------------------|-------------------|
| **Data source** | Curated reference files + search playbooks | Real-time API calls to backends | Both + reasoning + multi-step workflows |
| **Offline capable** | Yes (built-in references) | No (needs service access) | Partial |
| **Query type** | "What is X?" / "How does Y work?" | "Show me HSD #123" / "Search specs" | Complex multi-step tasks |
| **Auth required** | None for references; SSO for search | SSO + service tokens | SSO + service tokens |
| **Customizable** | Edit markdown files to add knowledge | Requires backend changes | Requires agent platform changes |
| **Best for** | Onboarding, quick reference, concept explanation | Data retrieval, ticket management | Orchestrated workflows, debugging |

## Key Design Decisions

1. **References-first** — check local files before hitting external APIs (faster, works offline)
2. **Query expansion** — search acronym + expanded form + contextual terms simultaneously
3. **Skill separation** — `intel-tech-lookup` handles "what is it" questions, `silicon-process` handles "how does it work" lifecycle questions
4. **Structured output** — every answer follows the same template so engineers get consistent, scannable responses
