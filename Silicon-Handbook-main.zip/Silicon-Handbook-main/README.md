# Silicon Handbook

**Author:** Gayatri Mayukha Behara — Security Researcher, PSE DaS Security Effectiveness Team

A VS Code Copilot plugin that gives AI agents domain expertise in Intel chip engineering — acronyms, architecture concepts, silicon lifecycle, SDM references, and product knowledge.

## What It Does

Silicon Handbook is a **curated knowledge base** packaged as a Copilot plugin. It provides:

- **Instant acronym expansion** — 100+ Intel acronyms across processor, memory, PCIe, platform, and business domains
- **SDM reference guidance** — volume navigation, MSR lookup patterns, CPUID leaf references
- **Silicon lifecycle expertise** — milestones (PO → PRQ → HVM → EOL), stepping conventions (A0/B0/C0), ECO processes
- **Search playbooks** — structured strategies for finding information across Confluence, SharePoint, Atlas, and the Intel Developer Technical Library
- **Structured answer formats** — consistent output templates for technical explanations

## Skills

| Skill | Purpose |
|-------|---------|
| **intel-tech-lookup** | Look up Intel acronyms, SDM registers, architecture concepts, product codenames, and security advisories. Includes search strategies for Confluence, SharePoint, Atlas, and the Intel Technical Library. |
| **silicon-process** | Explain silicon milestones, stepping conventions, ECO/errata processes, and engineering sample stages. Covers the full journey from tape-out to end-of-life. |

## Agents

### Silicon Handbook Agent

The Silicon Handbook agent is the primary interface for engineers to interact with the plugin. It acts as an intelligent router and knowledge synthesizer that:

- **Classifies incoming queries** — determines whether a question is about acronyms/architecture (→ `intel-tech-lookup`), silicon lifecycle (→ `silicon-process`), or needs a full report (→ `report-generator`)
- **Checks built-in references first** — provides instant answers from curated markdown files without requiring network access or authentication
- **Searches external sources when needed** — queries Confluence wikis, SharePoint document libraries, Atlas product dashboards, and the Intel Developer Technical Library for deeper context
- **Applies query expansion** — searches for acronym + expanded form + contextual terms simultaneously to maximize result relevance
- **Generates structured responses** — every answer follows a consistent template (full form → definition → technical details → related terms) for quick scanning
- **Produces HTML reports** — on request, gathers information from all available sources and generates a self-contained HTML file with Mermaid block diagrams, source attribution tables, glossaries, and print-friendly styling

#### Supported Domains

| Domain | Examples | Data Sources |
|--------|----------|-------------|
| Acronyms & terminology | TLP, MCHECK, BKC, RAS | Built-in glossary, Confluence |
| SDM & registers | MSR 0x1A0, CPUID leaves, CR4 bits | SDM volumes, Intel Tech Library |
| Architecture concepts | VT-x, TDX, CXL, SGX, TME | Tech Library, Confluence, SharePoint |
| Product codenames | GNR, SRF, CWF, DMR | Atlas, Confluence |
| Silicon milestones | PO, PRQ, HVM, EOL gate criteria | Built-in milestones ref, Atlas |
| Stepping conventions | A0/B0/C0 naming, metal fixes, ECO | Built-in stepping ref |
| Validation phases | SV, EV, PV, CV, BKC composition | Confluence, SharePoint |
| Report generation | Any topic → HTML with block diagram | All sources combined |

## Project Structure

```
silicon-handbook/
├── manifest.yaml                         # Plugin package definition
├── README.md                             # This file
├── ARCHITECTURE.md                       # Design decisions and data flow
├── agents/
│   └── SiliconHandbook.agent.md             # Silicon Handbook agent definition
└── skills/
    ├── intel-tech-lookup/
    │   ├── SKILL.md                      # Skill instructions and search procedures
    │   └── references/
    │       ├── common-acronyms.md        # 100+ Intel acronym definitions
    │       └── search-strategy.md        # Query expansion and source-specific tips
    └── silicon-process/
        ├── SKILL.md                      # Skill instructions for lifecycle topics
        └── references/
            ├── milestones.md             # PO, PRQ, HVM, EOL definitions and gate criteria
            └── stepping-conventions.md   # A0/B0/C0 naming rules and fix types
```

## Usage

### In VS Code Chat

Invoke the Silicon Handbook agent directly:

```
@silicon-handbook What does TDX stand for?
@silicon-handbook What happens at PRQ?
@silicon-handbook Explain the difference between A0 and B0 stepping
@silicon-handbook What MSR controls hardware prefetching?
```

### Report Generation

Ask the agent to generate an HTML report on any topic:

```
@silicon-handbook Generate a report on the PRQ process
@silicon-handbook Summarize CXL architecture as HTML
@silicon-handbook Create a report on stepping conventions
```

Reports are saved to `reports/<topic>-report.html` — a self-contained HTML file with a Mermaid block diagram, multi-source summary, glossary, and structured explanation. Open in any browser. See [`reports/README.md`](reports/README.md) for an example report breakdown.

### Skill Triggers

The skills activate automatically when Copilot detects relevant queries:

| Skill | Trigger Examples |
|-------|-----------------|
| **intel-tech-lookup** | "What is TLP?", "MSR 0x1A0 fields", "Granite Rapids codename" |
| **silicon-process** | "What happens at PRQ?", "A0 vs B0 stepping", "ECO process" |
| **report-generator** | "Generate a report on...", "Summarize ... as HTML", "Create a doc on..." |

### Example Workflows

**Quick lookup:**
```
User: What does MCHECK stand for?
Agent: Checks common-acronyms.md → returns instant definition
```

**Deep dive:**
```
User: Explain CXL Type 3 memory pooling
Agent: Checks references → searches Confluence + Tech Library → returns structured answer
```

**Report output:**
```
User: Generate a report on the silicon validation lifecycle
Agent: Gathers from milestones.md + stepping-conventions.md + Confluence
     → produces reports/silicon-validation-lifecycle-report.html
     → includes block diagram, source table, glossary
```

### Adding Custom Knowledge

Extend the plugin by editing reference files:

| To Add | Edit |
|--------|------|
| New acronyms | `skills/intel-tech-lookup/references/common-acronyms.md` |
| New search sources | `skills/intel-tech-lookup/references/search-strategy.md` |
| Milestone updates | `skills/silicon-process/references/milestones.md` |
| Stepping details | `skills/silicon-process/references/stepping-conventions.md` |
| Report template styling | `skills/report-generator/templates/report-template.html` |

## How It Differs from Codesign MCP Tools

| | Silicon Handbook | Codesign MCP Tools |
|---|---|---|
| **Type** | Curated knowledge base | Live data connectors |
| **Data** | Baked-in reference material | Real-time API queries |
| **Requires** | No authentication | Intel SSO / service tokens |
| **Best for** | "What is X?" / "How does Y work?" | "Show me HSD ticket #123" / "Search specs for CXL" |

They are **complementary** — this plugin gives the agent domain expertise to understand results returned by Codesign tools.

## Requirements

- VS Code with GitHub Copilot extension
- For live data searches: access to Intel Confluence, SharePoint, and Atlas (via MCP tools)

## Version

1.0.0
