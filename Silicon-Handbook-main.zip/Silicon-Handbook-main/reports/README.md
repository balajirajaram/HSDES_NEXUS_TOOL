# Reports

Generated HTML reports from the Silicon Handbook agent. Each report is a self-contained HTML file with Mermaid block diagrams, structured explanations, source tables, and glossaries.

## Example Report: TDX 2.5 Architecture

**File:** [tdx-2.5-architecture-report.html](tdx-2.5-architecture-report.html)

**Prompt:**
```
@silicon-handbook Generate a report on TDX 2.5 architecture
```

### What the Agent Produced

| Section | Content |
|---------|---------|
| **Block Diagram** | Mermaid flowchart showing Host/VMM → TDX Module (SEAM) → Trust Domains → Hardware Root of Trust |
| **Overview** | What TDX is, how 2.5 extends 1.0/1.5, and why it matters for confidential computing |
| **How It Works** | 6 subsections — SEAM mode, memory encryption, TD Partitioning, live migration, attestation, interrupt handling |
| **Key Details** | 12-row parameter table (CPU mode, encryption, page tracking, interfaces, attestation, version history) |
| **Version Comparison** | Feature matrix across TDX 1.0 → 1.5 → 2.5 |
| **Sources** | 5 sources consulted with type badges |
| **Related Topics** | 12 linked concepts (SGX, MK-TME, VMX, EPT, CoCo, etc.) |
| **Glossary** | 18 terms defined (TDX, SEAM, PAMT, MigTD, RTMR, etc.) |

### Sources Consulted

| Source | Type | What Was Found |
|--------|------|---------------|
| `common-acronyms.md` | Built-in Reference | TDX definition — Trust Domain Extensions, hardware-based VM isolation |
| Intel TDX Module Architecture Specification | Intel Tech Library | SEAM mode, SEAMCALL/TDCALL ABI, PAMT structure, memory encryption model |
| Intel TDX Module Partitioning Specification | Intel Tech Library | TD Partitioning design, sub-TD isolation boundaries, per-partition attestation |
| Intel TDX Migration Architecture Specification | Intel Tech Library | MigTD design, migration key negotiation, cross-host TD transfer flow |
| Intel SDM Volume 3 (Ch. 28+) | Intel Tech Library | VMX/TDX chapters, ISA extensions, TDX ABI specs |

### Report Sections Breakdown

1. **Header** — Title, 2-sentence summary, generation date, source count
2. **Block Diagram** — Mermaid flowchart rendered via CDN, showing architecture layers and data flow
3. **Overview** — What the technology is and why it matters
4. **How It Works** — Multi-section deep dive into the architecture:
   - SEAM Mode & TDX Module
   - Memory Isolation & Encryption (MK-TME, PAMT)
   - TD Partitioning (new in 2.5)
   - Live Migration via MigTD (new in 2.5)
   - Attestation (TD Reports → SGX QE → TD Quotes)
   - Interrupt & Exception Handling
5. **Key Details** — Parameter table with technical specs and SDM references
6. **Version Comparison** — Feature matrix across TDX 1.0 / 1.5 / 2.5
7. **Sources** — Where each piece of information came from, with type badges (Reference / Wiki / Doc / Dashboard)
8. **Related Topics** — Clickable tags for related concepts
9. **Glossary** — All acronyms and terms used in the report

## Naming Convention

Reports follow the pattern: `<topic-slug>-report.html`
- Lowercase, hyphens, no spaces
- Examples: `tdx-2.5-architecture-report.html`, `prq-process-report.html`, `cxl-type-3-report.html`
