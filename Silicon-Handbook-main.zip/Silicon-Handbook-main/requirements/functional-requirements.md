# Functional Requirements — Silicon Handbook Plugin

## FR-1: Acronym Lookup

| Field | Value |
|-------|-------|
| **Priority** | P0 — Must Have |
| **Description** | The plugin shall expand and explain Intel acronyms when a user asks "What does [X] stand for?" or "What is [X]?" |
| **Acceptance Criteria** | 1. Returns full form and 1-3 sentence explanation within 2 seconds for acronyms in the built-in reference. 2. Falls back to Confluence/SharePoint search for unknown acronyms. 3. Handles ambiguous acronyms by presenting all known definitions grouped by domain. |

## FR-2: SDM Reference Lookup

| Field | Value |
|-------|-------|
| **Priority** | P0 — Must Have |
| **Description** | The plugin shall explain registers, MSRs, CPUID leaves, instructions, and CPU features from the Intel SDM. |
| **Acceptance Criteria** | 1. Identifies the correct SDM volume for a given query. 2. Returns MSR address, bit fields, and functional description. 3. Links to the Intel Developer Technical Library for full documentation. |

## FR-3: Silicon Milestone Explanation

| Field | Value |
|-------|-------|
| **Priority** | P0 — Must Have |
| **Description** | The plugin shall explain silicon lifecycle milestones (PO, PRQ, HVM, EOL) including gate criteria and timeline context. |
| **Acceptance Criteria** | 1. Returns milestone definition, gate criteria, and what comes before/after. 2. Provides typical duration estimates between milestones. 3. References Atlas for product-specific dates when applicable. |

## FR-4: Stepping Convention Explanation

| Field | Value |
|-------|-------|
| **Priority** | P0 — Must Have |
| **Description** | The plugin shall explain stepping naming conventions (A0/B0/C0), what triggers letter vs number increments, and fix types. |
| **Acceptance Criteria** | 1. Explains the letter/number naming scheme. 2. Differentiates full respin, metal-only fix, and fuse/config fix. 3. Maps typical stepping usage (A0 = first silicon, C0 = PRQ candidate). |

## FR-5: Product Codename Mapping

| Field | Value |
|-------|-------|
| **Priority** | P1 — Should Have |
| **Description** | The plugin shall map Intel product codenames to product families, marketing names, and socket types. |
| **Acceptance Criteria** | 1. Maps codename → marketing name → family (e.g., GNR → Granite Rapids → Xeon 6 P-core). 2. Searches Confluence and Atlas for codenames not in the built-in reference. |

## FR-6: Architecture Concept Explanation

| Field | Value |
|-------|-------|
| **Priority** | P1 — Should Have |
| **Description** | The plugin shall explain Intel architecture technologies (VT-x, VT-d, TDX, SGX, CXL, TME, etc.). |
| **Acceptance Criteria** | 1. Provides a concise definition and technical context. 2. References the relevant SDM volume or specification. 3. Lists related terms. |

## FR-7: Multi-Source Search

| Field | Value |
|-------|-------|
| **Priority** | P1 — Should Have |
| **Description** | The plugin shall search across Confluence, SharePoint, Atlas, and the Intel Developer Technical Library when built-in references are insufficient. |
| **Acceptance Criteria** | 1. Uses query expansion (acronym + expanded form + contextual query). 2. Searches sources in priority order based on query classification. 3. Retrieves full page content from Confluence when search snippets are insufficient. |

## FR-8: Structured Answer Format

| Field | Value |
|-------|-------|
| **Priority** | P1 — Should Have |
| **Description** | All responses shall follow a consistent template: term, full form, definition, technical details, and related terms. |
| **Acceptance Criteria** | 1. Every answer includes at minimum: definition and 1+ related terms. 2. SDM queries include volume/section references. 3. Milestone queries include gate criteria and timeline context. |

## FR-9: Skill Routing

| Field | Value |
|-------|-------|
| **Priority** | P0 — Must Have |
| **Description** | The Chip Engineer agent shall route queries to the correct skill based on domain classification. |
| **Acceptance Criteria** | 1. Acronyms, SDM, codenames, architecture → `intel-tech-lookup`. 2. Milestones, steppings, ECO → `silicon-process`. 3. Ambiguous queries use both skills. |
