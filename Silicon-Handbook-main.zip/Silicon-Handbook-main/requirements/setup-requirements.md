# Setup & Dependency Requirements — Silicon Handbook Plugin

## Environment

| Requirement | Minimum | Recommended |
|-------------|---------|-------------|
| **VS Code** | 1.95+ | Latest stable |
| **GitHub Copilot Extension** | 1.200+ | Latest stable |
| **Copilot Chat** | Enabled | Enabled |
| **OS** | Windows 10/11, macOS 13+, Linux (Ubuntu 22.04+) | Any supported VS Code platform |

## Authentication & Access

| Service | Required For | Auth Method |
|---------|-------------|-------------|
| **GitHub Copilot** | Agent and skill execution | GitHub account with Copilot license |
| **Intel Confluence** | Wiki search (optional) | Intel SSO / Kerberos |
| **Intel SharePoint** | Document search (optional) | Intel SSO / M365 Graph |
| **Atlas Product Dashboard** | Milestone dates (optional) | Intel SSO / Kerberos |
| **Intel Developer Technical Library** | SDM docs (optional) | None (public) |

> **Note:** The plugin works offline using built-in reference files. External searches require the corresponding MCP servers and authentication.

## MCP Server Dependencies (Optional)

These MCP servers enable live data searches. The plugin functions without them using built-in references only.

| MCP Server | Tools Used | Purpose |
|------------|-----------|---------|
| **atlassian-mcp** | `confluence_search`, `confluence_get_page` | Search and retrieve Confluence wiki pages |
| **m365-graph-mc** | `sharepoint_search`, `sharepoint_list_sites` | Search SharePoint document libraries |

## Plugin Installation

1. Clone or copy the `silicon-handbook` folder into your VS Code workspace
2. The `manifest.yaml` is auto-detected by the Copilot extension
3. Skills and agents become available in Copilot Chat

### Verify Installation

- Open Copilot Chat and type `@chip-engineer` — the agent should appear in autocomplete
- Ask a test question: `@chip-engineer What is PRQ?`

## File Dependencies

The plugin requires this minimum file structure to function:

```
silicon-handbook/
├── manifest.yaml                              # Required — plugin entry point
├── agents/
│   └── ChipEngineer.agent.md                  # Required — agent definition
└── skills/
    ├── intel-tech-lookup/
    │   ├── SKILL.md                           # Required — skill instructions
    │   └── references/
    │       ├── common-acronyms.md             # Required — acronym database
    │       └── search-strategy.md             # Optional — enhances search quality
    └── silicon-process/
        ├── SKILL.md                           # Required — skill instructions
        └── references/
            ├── milestones.md                  # Required — milestone definitions
            └── stepping-conventions.md        # Required — stepping rules
```
