---
name: intel-tech-lookup
description: "Look up Intel technical references — acronyms, SDM registers, architecture concepts, product codenames, security advisories, and internal documentation across Confluence, SharePoint, Atlas, and the Intel Developer Technical Library. Use when: user asks about an Intel acronym, SDM reference, architecture concept, product codename, milestone date, security advisory, register definition, instruction set, or any Intel-specific technical question."
argument-hint: "acronym, topic, or question (e.g., 'PCIe TLP', 'what is MCHECK', 'CXL protocol')"
---

# Intel Technical Reference Lookup

Search and explain Intel acronyms, architecture concepts, product milestones, timelines, internal processes, and technical topics by querying SharePoint, Confluence, Atlas, Power BI, and the Intel Developer Technical Library.

## When to Use

- User asks **"What does [ACRONYM] stand for?"** or **"What is [TERM]?"**
- User needs context on an Intel architecture concept (e.g., PCIe, CXL, DDR, MSR)
- User asks about Intel product codenames, steppings, or SKUs
- User wants SDM (Software Developer Manual) references for registers, instructions, or CPU features
- User needs information from Intel internal wikis, SharePoint, or documentation
- User asks about Intel security advisories (SA) or CVEs
- User wants to understand Intel internal processes, tools, or workflows
- User asks about **product milestones, timelines, PRQ dates, or steppings**
- User asks about **product overviews** or needs Intel Developer Technical Library documents
- User needs **Power BI dashboards or reports** for product/program data

## Data Sources

| Source | Tool | Best For |
|--------|------|----------|
| **SharePoint** | `mcp_m365-graph-mc_sharepoint_search` / `sharepoint_list_sites` | Internal team documents, design specs, presentations, process docs |
| **Confluence Wiki** | `mcp_atlassian_mcp_confluence_search` / `confluence_get_page` | Internal wiki pages, team knowledge bases, runbooks, how-to guides |
| **Atlas Product Dashboard** | Browser / `https://atlas.intel.com/ProductDashboard/<id>` | Product milestones, timelines, steppings, PRQ dates, program status |
| **Power BI Reports** | Browser / `https://app.powerbi.com/groups/<id>/reports/<id>` | Program metrics, dashboards, tracking reports |
| **Intel Developer Technical Library** | Web / `https://www.intel.com/content/www/us/en/developer/technical-library/overview.html` | SDM volumes, ISA extensions, TDX specs, architecture docs, white papers |

## Procedure

### Step 1: Classify the Query

Determine the query type to optimize the search strategy:

| Query Type | Example | Primary Source | Secondary Sources |
|------------|---------|----------------|-------------------|
| **Acronym lookup** | "What is TLP?" | Common acronyms reference | Confluence, SharePoint |
| **SDM / Architecture** | "MSR 0x1A0 fields" | Common acronyms reference | Technical Library, Confluence |
| **Security / CVE** | "SA-00950 details" | Confluence | SharePoint |
| **Internal process** | "How does silicon validation work?" | Confluence | SharePoint |
| **Product / codename** | "What is Granite Rapids?" | Atlas Dashboard | Confluence, SharePoint |
| **Product milestone** | "GNR PRQ date" | Atlas Dashboard | Power BI, Confluence |
| **Product overview** | "Xeon 6 features" | Technical Library | Atlas, Confluence |
| **General Intel topic** | "CXL Type 3 device" | Confluence | Technical Library, SharePoint |

### Step 2: Check Common Acronyms First

Before querying external sources, check the [common acronyms reference](./references/common-acronyms.md) for an instant answer. If found, provide the definition and then optionally query Confluence or SharePoint for deeper context.

### Step 3: Query Sources (Parallel When Possible)

Based on the classification, query the appropriate sources.

#### 3a. Confluence Wiki Search

Use `mcp_atlassian_mcp_confluence_search` for internal knowledge base content:

```
Tool: mcp_atlassian_mcp_confluence_search
Parameters:
  query: "<search terms>"
  limit: 10
```

For CQL-based targeted search:
- By title: `title~"<term>"`
- By label: `label=<tag>`
- In specific space: `type=page AND space=<SPACEKEY> AND text~"<term>"`

If a promising page is found, retrieve the full content with `mcp_atlassian_mcp_confluence_get_page`.

#### 3b. Atlas Product Dashboard

For product milestone, timeline, stepping, and PRQ queries, direct the user to the Atlas Product Dashboard:

- **Base URL**: `https://atlas.intel.com/ProductDashboard/<product_id>`
- Atlas requires Intel SSO authentication (Kerberos)
- Atlas contains official milestone dates (PO, A0, PRQ), stepping info, and program status
- If you know the product ID, construct the direct URL; otherwise search Atlas by product name

**Key data available in Atlas:**
- Product milestones and dates (PO, A-stepping, B-stepping, PRQ, HVM)
- Program status and health
- Stepping history and revisions
- SKU definitions and configurations

#### 3c. Intel Developer Technical Library

For SDM, ISA extensions, architecture specs, and official Intel documentation:

- **URL**: `https://www.intel.com/content/www/us/en/developer/technical-library/overview.html`
- Contains 3800+ documents including:
  - **SDM Volumes 1-4** — Intel 64 and IA-32 Architectures Software Developer's Manual
  - **ISA Extensions** — Instruction Set Extensions Programming Reference
  - **TDX Specs** — Trust Domain Extensions architecture and ABI specifications
  - **VT-d Specs** — Virtualization Technology for Directed I/O
  - **Architecture specs** — Memory encryption, confidential computing, etc.
  - **White papers, user guides, release notes, code samples**
- Search or filter by content type, date, or keyword
- All documents are publicly available (no SSO required)

**Key SDM volumes:**
| Volume | Content |
|--------|---------|
| Vol 1 | Basic Architecture |
| Vol 2A-2D | Instruction Set Reference (A-Z) |
| Vol 3A-3D | System Programming Guide |
| Vol 4 | Model-Specific Registers |

#### 3d. Power BI Reports

For program metrics and tracking dashboards:

- Power BI reports require Intel SSO and appropriate group access
- Provide the user with the direct report URL when known
- Common report types: program health, milestone tracking, resource utilization

#### 3e. SharePoint Search

First discover relevant SharePoint sites:

```
Tool: mcp_m365-graph-mc_sharepoint_list_sites
Parameters:
  query: "<team or topic name>"
```

Then search within a specific document library:

```
Tool: mcp_m365-graph-mc_sharepoint_search
Parameters:
  driveId: "<from site listing>"
  query: "<search terms>"
```

### Step 4: Synthesize and Present

Combine results from all sources into a structured educational response:

1. **Definition / Summary** — Clear, concise answer to the query
2. **Full Form** — If an acronym, provide the expanded form
3. **Context** — Where this term/concept is used within Intel
4. **Technical Details** — Relevant architecture or specification details from SDM
5. **Related Terms** — Cross-references to related acronyms or concepts
6. **Sources** — Cite which source(s) provided the information

#### Response Template

```
## [TERM/ACRONYM]

**Full form:** [expanded acronym if applicable]

**Definition:** [1-3 sentence clear explanation]

### Technical Details
[Deeper explanation from SDM, wiki, or SharePoint sources]

### Context & Usage
[Where/how this is used within Intel — products, teams, processes]

### Related Terms
- [RELATED1] — [brief definition]
- [RELATED2] — [brief definition]

### Sources
- Wiki: [page title]
- SharePoint: [document name]
- Atlas: [product dashboard link]
- Technical Library: [document title + URL]
- Power BI: [report name]
```

### Step 5: Offer Follow-Up

After presenting the answer, suggest related topics the user might want to explore:
- Related acronyms or specifications
- Related internal wiki or SharePoint pages
- Atlas product dashboard links for milestone/timeline queries
- Intel Developer Technical Library documents (SDM, specs, white papers)

## Advanced Search Strategies

See [search strategy reference](./references/search-strategy.md) for advanced query techniques and source-specific tips.

## Silicon Lifecycle Reference

### Milestone Definitions

The Intel silicon lifecycle follows a defined sequence of milestones from initial design through high-volume manufacturing. Each milestone is a formal gate with entry/exit criteria.

```
Tape-Out → A0 (PO) → A1 → B0 → B1 → C0 → PRQ → HVM → EOL
         ↑          ↑              ↑           ↑         ↑
       First      Bug-fix       Major        Product   High-volume
       silicon    stepping      re-spin      release   production
                                             qualified
```

| Milestone | Full Name | Description |
|-----------|-----------|-------------|
| **Tape-Out (TO)** | Tape-Out | RTL design is frozen and sent to fabrication. No further design changes possible for this stepping. |
| **PO / A0** | Power On | First silicon returns from fab and boots for the first time. Critical milestone — confirms basic functionality. |
| **A1** | A-stepping revision 1 | First metal-layer fix (bug fix stepping). Addresses critical bugs found in A0. |
| **B0** | B-stepping | Major re-spin, may include base-layer changes. Typically the stepping targeted for product qualification. |
| **B1** | B-stepping revision 1 | Metal-layer fix on B0. Further bug fixes. |
| **C0** | C-stepping | Additional re-spin if B-stepping quality is insufficient. Not always needed. |
| **PRQ** | Production Release Qualification | Product is qualified for customer shipment. All quality, reliability, and functional criteria met. |
| **HVM** | High Volume Manufacturing | Fab ramp to full production volume. |
| **EOL** | End of Life | Product discontinuation announced. Last order/ship dates published. |

### Pre-Silicon Milestones

| Milestone | Description |
|-----------|-------------|
| **Concept/Architecture** | Architecture definition, feature set, target performance/power |
| **RTL Freeze** | Register Transfer Level design is complete and frozen for synthesis |
| **FV Complete** | Formal Verification passes — mathematical proof of logic correctness |
| **Emulation** | Design running on FPGA/emulation platforms for pre-silicon validation |
| **Tape-Out (TO)** | Final design sent to fab |

### Stepping Naming Conventions

Steppings follow a letter + number scheme:

| Convention | Meaning | Example |
|------------|---------|---------|
| **Letter** (A, B, C...) | Base layer revision — higher letter = more significant change | A → B is a major re-spin |
| **Number** (0, 1, 2...) | Metal layer revision — incremental bug fixes | A0 → A1 is a metal fix |
| **QS** | Qualification Sample | Pre-PRQ samples sent to key customers for early validation |
| **ES** | Engineering Sample | Early silicon for internal debug only, not for customer use |
| **PRQ stepping** | The stepping that passed PRQ | The version shipped to customers |

### BKC — Best Known Configuration

The **BKC** is the validated software/firmware stack for a given stepping. It specifies exact versions of:

| Component | Example |
|-----------|---------|
| **BIOS/UEFI** | EGSDCRB.86B.0076.R01.2305 |
| **BMC Firmware** | 2.92 |
| **OS / Kernel** | RHEL 9.2, kernel 5.14.0-284 |
| **Drivers** | QAT 4.22, NIC i40e 2.23.17 |
| **Microcode** | 0x0b000491 |
| **FSP** | 3823.D00 |
| **ME/SPS Firmware** | SPS 6.0.3.156 |

> **Important:** Running outside the BKC may trigger known bugs or produce non-representative results. Always check the BKC before filing sightings.

### Validation Phases

| Phase | Acronym | Scope | When |
|-------|---------|-------|------|
| **Pre-Silicon Validation** | Pre-Si | RTL simulation, emulation, formal verification | Before tape-out |
| **Silicon Validation** | SV | Post-silicon functional testing on the actual chip | After PO (A0+) |
| **Electrical Validation** | EV | Signal integrity, power delivery, thermal, analog characterization | After PO |
| **Platform Validation** | PV | Full system-level testing (board + CPU + memory + OS) | B-stepping+ |
| **Customer Validation** | CV | OEM/customer-driven testing with their workloads | QS/PRQ stepping |

### Sighting (Bug) Lifecycle

```
New → Triaged → Assigned → Root-Caused → Fixed → Verified → Closed
                    ↓
                Duplicate / Won't Fix / By Design / Deferred
```

| Field | Description |
|-------|-------------|
| **Severity** | Sev1 (system crash/hang) → Sev2 (major feature broken) → Sev3 (minor) → Sev4 (cosmetic) |
| **Exposure** | Who is affected — Internal Only, Different Customers, All Customers |
| **Domain** | Hardware component area — Core, Uncore, Memory, IO, Power, Security |
| **Component** | Specific IP block — IMC, UPI, PCIe, CHA, PMU, etc. |
| **Target Stepping** | Which stepping the fix is planned for |
| **Workaround** | Temporary mitigation (BIOS, microcode, OS, or none) |

### Key Terms in Silicon Lifecycle

| Term | Definition |
|------|------------|
| **ECO** | Engineering Change Order — formal request to modify the silicon design |
| **Metal Fix** | Bug fix applied only to metal layers (fast, cheap, same letter stepping) |
| **Base Layer Fix** | Fix requiring changes to transistor/diffusion layers (new letter stepping, expensive) |
| **Different Customers** | Exposure: known to impact certain OEM configurations but not all |
| **POR** | Plan of Record — the official planned feature/configuration set for a stepping |
| **Non-POR** | Configuration outside the official plan — may work but not validated |
| **FUB** | Functional Unit Block — discrete functional unit within the chip |
| **IP Block** | Intellectual Property block — a reusable design component (e.g., PCIe controller, DDR PHY) |
| **SKU** | Stock Keeping Unit — a specific product variant (core count, frequency, features) |
| **Fuse** | One-time programmable configuration — used to create SKUs from the same die |

## Limitations

- SharePoint search requires knowing or discovering the relevant site/drive
- Confluence results depend on the spaces accessible to the user
- Atlas requires Intel SSO and the product ID — search by product name if ID is unknown
- Power BI reports require group membership — the user may need access grants
- Intel Developer Technical Library is publicly accessible but has 3800+ docs — use specific search terms
- Some acronyms are overloaded (same acronym, different meanings in different contexts) — always provide context
