# Common Intel Acronyms Quick Reference

A seed knowledge base for instant lookups. Organized by domain. When an acronym is found here, provide the definition immediately and optionally query Confluence or SharePoint for deeper technical context.

> **Note:** This list is not exhaustive. Always query Confluence and SharePoint for acronyms not found here or for deeper context on any term.

---

## Processor Architecture

| Acronym | Full Form | Brief Description |
|---------|-----------|-------------------|
| ALU | Arithmetic Logic Unit | Core computation unit in the processor |
| AVX | Advanced Vector Extensions | SIMD instruction set extensions for x86 |
| AVX-512 | Advanced Vector Extensions 512-bit | 512-bit SIMD instruction set |
| BPU | Branch Prediction Unit | Predicts branch outcomes to reduce pipeline stalls |
| BSP | Bootstrap Processor | First processor to execute code during boot |
| BTB | Branch Target Buffer | Cache for branch target addresses |
| CR | Control Register | Processor control registers (CR0-CR4) |
| DR | Debug Register | Hardware debug registers (DR0-DR7) |
| EFLAGS | Extended Flags Register | Status and control flags register |
| FPU | Floating Point Unit | Hardware for floating-point arithmetic |
| GPR | General Purpose Register | RAX, RBX, RCX, etc. |
| IDT | Interrupt Descriptor Table | Table mapping interrupts to handler addresses |
| ISA | Instruction Set Architecture | The set of instructions a processor supports |
| LAM | Linear Address Masking | Feature allowing software to use upper address bits for metadata |
| LBR | Last Branch Record | MSR-based recording of recent branch history |
| MCHECK | Machine Check | Machine check exception/error handling |
| MCE | Machine Check Exception | Hardware error reporting mechanism |
| MSR | Model Specific Register | Processor-specific configuration/status registers |
| NMI | Non-Maskable Interrupt | High-priority interrupt that cannot be disabled |
| PAE | Physical Address Extension | Extends physical address space beyond 4GB |
| PCID | Process Context Identifier | TLB tagging to avoid flushes on context switch |
| PMC | Performance Monitoring Counter | Hardware counters for performance analysis |
| PMU | Performance Monitoring Unit | Hardware unit managing performance counters |
| PT | Processor Trace | Intel hardware instruction tracing |
| RAT | Register Alias Table | Maps architectural to physical registers |
| RDT | Resource Director Technology | Cache and memory bandwidth allocation |
| ROB | Reorder Buffer | Tracks out-of-order instruction execution |
| RSB | Return Stack Buffer | Predicts return addresses |
| SGX | Software Guard Extensions | Hardware-based memory encryption for enclaves |
| SMM | System Management Mode | Special processor operating mode |
| SMI | System Management Interrupt | Interrupt entering SMM |
| SSE | Streaming SIMD Extensions | 128-bit SIMD instruction set |
| TDX | Trust Domain Extensions | Hardware-based VM isolation/confidential computing |
| TLB | Translation Lookaside Buffer | Cache for virtual-to-physical address translations |
| TME | Total Memory Encryption | Platform-wide memory encryption |
| TSC | Time Stamp Counter | High-resolution processor timestamp |
| TSX | Transactional Synchronization Extensions | Hardware transactional memory |
| UMIP | User-Mode Instruction Prevention | Prevents certain instructions in user mode |
| VMX | Virtual Machine Extensions | Intel hardware virtualization technology |
| VT-x | Virtualization Technology for x86 | CPU virtualization support |
| VT-d | Virtualization Technology for Directed I/O | IOMMU / DMA remapping |
| XD | Execute Disable | No-execute bit for memory pages |

## Memory & Cache

| Acronym | Full Form | Brief Description |
|---------|-----------|-------------------|
| CAT | Cache Allocation Technology | Partition LLC among workloads (part of RDT) |
| CHA | Caching and Home Agent | Manages LLC slices and coherency (replaces Cbo) |
| CXL | Compute Express Link | Cache-coherent interconnect for accelerators and memory |
| DDR | Double Data Rate | DRAM interface standard |
| DDR5 | Double Data Rate 5 | Latest generation DDR memory |
| DIMM | Dual In-line Memory Module | Physical memory module form factor |
| DMA | Direct Memory Access | Hardware mechanism for memory access without CPU |
| EPT | Extended Page Tables | Hardware support for VM memory virtualization |
| HBM | High Bandwidth Memory | Stacked DRAM with high bandwidth |
| IMC | Integrated Memory Controller | On-die memory controller |
| LLC | Last Level Cache | The outermost cache level (typically L3) |
| MBA | Memory Bandwidth Allocation | Controls memory bandwidth per workload (part of RDT) |
| MKTME | Multi-Key Total Memory Encryption | Per-VM/per-tenant memory encryption keys |
| MMIO | Memory-Mapped I/O | I/O devices mapped into memory address space |
| MTRR | Memory Type Range Register | Define caching policy for memory regions |
| NUMA | Non-Uniform Memory Access | Memory architecture with varying access latencies |
| PAT | Page Attribute Table | Fine-grained memory type control per page |
| PMem | Persistent Memory | Intel Optane persistent memory |
| SNC | Sub-NUMA Clustering | Divides socket into multiple NUMA domains |
| UPI | Ultra Path Interconnect | Inter-socket coherent link |

## PCIe & I/O

| Acronym | Full Form | Brief Description |
|---------|-----------|-------------------|
| ACS | Access Control Services | PCIe feature controlling peer-to-peer transactions |
| AER | Advanced Error Reporting | PCIe error reporting capability |
| ARI | Alternative Routing-ID Interpretation | Extends PCIe function numbering beyond 8 |
| BAR | Base Address Register | PCIe config register mapping device memory |
| BDF | Bus:Device.Function | PCIe device addressing format |
| CFG | Configuration Space | PCIe device configuration registers |
| CTO | Completion Timeout | PCIe timeout for outstanding requests |
| DLLP | Data Link Layer Packet | PCIe data link layer packet |
| ECAM | Enhanced Configuration Access Mechanism | Memory-mapped PCIe config space |
| IOMMU | I/O Memory Management Unit | DMA address translation and isolation |
| MPS | Max Payload Size | PCIe maximum TLP payload |
| MRR | Max Read Request | PCIe maximum read request size |
| MSIX | MSI-X (Message Signaled Interrupts Extended) | PCI interrupt mechanism using memory writes |
| NTB | Non-Transparent Bridge | PCIe bridge for multi-host systems |
| PCIE / PCIe | Peripheral Component Interconnect Express | High-speed serial interconnect |
| PME | Power Management Event | PCIe power management signaling |
| RCiEP | Root Complex Integrated Endpoint | Endpoint integrated into the root complex |
| SRIOV / SR-IOV | Single Root I/O Virtualization | PCIe device virtualization |
| TLP | Transaction Layer Packet | PCIe transaction layer data unit |

## Platform & Firmware

| Acronym | Full Form | Brief Description |
|---------|-----------|-------------------|
| ABL | Authenticated Boot Loader | Boot firmware component |
| ACM | Authenticated Code Module | Signed code module for platform security |
| ACPI | Advanced Configuration and Power Interface | OS-firmware power management interface |
| BIOS | Basic Input/Output System | Legacy firmware interface |
| BMC | Baseboard Management Controller | Out-of-band server management controller |
| CSME | Converged Security and Management Engine | Intel integrated security engine |
| EFI | Extensible Firmware Interface | Modern firmware interface (see UEFI) |
| FSP | Firmware Support Package | Intel binary for silicon initialization |
| IFD | Intel Flash Descriptor | Flash layout descriptor region |
| IFWI | Integrated Firmware Image | Complete firmware image for a platform |
| ME | Management Engine | Intel embedded security/management processor |
| MRC | Memory Reference Code | Memory training/initialization firmware |
| PCIE | PCI Express | see PCIe above |
| PMC | Power Management Controller | Platform power management IC |
| SPS | Server Platform Services | Server variant of Intel ME firmware |
| UEFI | Unified Extensible Firmware Interface | Modern firmware specification |

## Silicon & Validation

| Acronym | Full Form | Brief Description |
|---------|-----------|-------------------|
| ATE | Automated Test Equipment | Production silicon testing machines |
| DFx | Design for Test/Debug | Design features enabling testing and debug |
| DUT | Device Under Test | The silicon being tested |
| ECO | Engineering Change Order | Change request to silicon design |
| EV | Electrical Validation | Post-silicon electrical testing |
| FIB | Focused Ion Beam | Debug technique for silicon modification |
| FV | Formal Verification | Mathematical proof of design correctness |
| JTAG | Joint Test Action Group | Debug/test interface standard |
| PO | Power On | First silicon power-on milestone |
| PRQ | Production Release Qualification | Product release milestone |
| PV | Platform Validation | System-level validation |
| RTL | Register Transfer Level | Hardware description abstraction level |
| SV | Silicon Validation | Post-silicon functional validation |
| TAP | Test Access Port | JTAG physical interface |
| VPD | Vital Product Data | Manufacturing information stored on device |

## Intel Products & Platforms (Codenames)

| Codename | Product Family | Description |
|----------|---------------|-------------|
| ADL | Alder Lake | 12th Gen Core (hybrid architecture) |
| EMR | Emerald Rapids | 5th Gen Xeon Scalable |
| GNR | Granite Rapids | 6th Gen Xeon (Xeon 6 P-core) |
| ICX | Ice Lake Server | 3rd Gen Xeon Scalable |
| MTL | Meteor Lake | Core Ultra (first generation) |
| RPL | Raptor Lake | 13th Gen Core |
| SRF | Sierra Forest | Xeon 6 E-core (efficiency) |
| SPR | Sapphire Rapids | 4th Gen Xeon Scalable |

## Security

| Acronym | Full Form | Brief Description |
|---------|-----------|-------------------|
| ASLR | Address Space Layout Randomization | Memory layout randomization for security |
| CVE | Common Vulnerabilities and Exposures | Vulnerability identification system |
| IPAS | Intel Product Assurance and Security | Intel's security response team |
| SA | Security Advisory | Intel Security Advisory |
| SIPP | Stable Image Platform Program | Ensures driver/software stability guarantees |
| TEE | Trusted Execution Environment | Isolated secure processing environment |

## Common Internal Terms

| Term | Full Form | Description |
|------|-----------|-------------|
| 1S / 2S / 4S / 8S | 1-Socket / 2-Socket / etc. | Server socket configuration |
| BKC | Best Known Configuration | Validated software/firmware stack |
| BKM | Best Known Method | Recommended practice or procedure |
| CDSG | Client and Data Center Solutions Group | Intel business unit |
| DCAI | Data Center and AI | Intel business unit |
| EWS | Engineering Work Station | Development workstation |
| HSD / HSDES | High Speed Defect / HSD Enterprise System | Intel bug tracking system |
| ITP | Intel Trace Platform | Debug tool for silicon |
| NEX | Network and Edge | Intel business unit |
| NDA | Non-Disclosure Agreement | Confidentiality agreement |
| OOB | Out of Band | Management access outside the data path |
| POR | Plan of Record | Official planned configuration/feature set |
| PROM | Programmable Read-Only Memory / Promotion | Context-dependent |
| RDC | Regional Design Center | Intel design center |
| SoC | System on Chip | Integrated processor with subsystems |
| WW | Work Week | Intel calendar week numbering (WW01-WW52) |

---

## Intel Products & Platforms (Extended)

| Codename | Product Family | Description |
|----------|---------------|-------------|
| ARL | Arrow Lake | Core Ultra 200 (2nd gen, desktop) |
| BWF | Birch Forest | Future Xeon E-core (efficiency) |
| CWF | Clearwater Forest | Next-gen Xeon E-core |
| DMR | Diamond Rapids | Next-gen Xeon P-core |
| LNL | Lunar Lake | Core Ultra 200V (mobile, Foveros) |
| PTL | Panther Lake | Future Core Ultra |

---

> **This list is a starting point.** Use Confluence and SharePoint search tools to find definitions for acronyms not listed here, and to get deeper technical context for any term.
