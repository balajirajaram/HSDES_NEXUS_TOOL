# Advanced Search Strategy Reference

## Query Expansion Techniques

### Acronym Searches

When searching for an acronym, always expand into multiple query variants:

1. **Exact acronym**: `"TLP"` — matches direct mentions
2. **Expanded form**: `"Transaction Layer Packet"` — matches documents using the full term
3. **Contextual query**: `"TLP PCIe transaction layer"` — adds domain context for better retrieval
4. **Combined**: Search all three variants simultaneously across Confluence and SharePoint

### SDM Register Lookups

For CPU register queries, include multiple identifiers:
- MSR address (hex): `"MSR 0x1A0"`
- MSR symbolic name: `"IA32_MISC_ENABLE"`
- Functional description: `"miscellaneous processor feature enable disable"`
- Register field names: `"FAST_STRING_ENABLE bit 0"`

### Product / Platform Queries

Intel products have multiple names — search for all variants:
- Codename: `"Granite Rapids"`
- Marketing name: `"Xeon 6"`
- Platform code: `"GNR"`
- Socket/family: `"LGA 4677 server processor"`

## Source-Specific Tips

### Confluence Wiki

**Search patterns:**
- Simple text search: `"silicon validation methodology"`
- CQL title search: `title~"acronym glossary"`
- CQL label search: `label=architecture AND text~"memory controller"`
- Space-scoped: `type=page AND space=ARCHTEAM AND text~"cache coherency"`
- Recent content: `text~"CXL" AND lastModified > startOfMonth("-3M")`

**Page retrieval:** When Confluence search returns a promising result, always fetch the full page with `mcp_atlassian_mcp_confluence_get_page` to get complete context. The search snippet may truncate critical information.

**Finding the right space:** If you don't know which Confluence space to search, start with an unscoped text search, then note which spaces contain the most relevant results for future queries.

### SharePoint

**Discovery workflow:**
1. Find relevant sites: `mcp_m365-graph-mc_sharepoint_list_sites` with a keyword
2. List drives in the site to find document libraries
3. Search within the drive: `mcp_m365-graph-mc_sharepoint_search`
4. List folder contents if needed: `mcp_m365-graph-mc_sharepoint_list_items`

**Common Intel SharePoint sites to search for:**
- Team-specific portals (search by team name or organization)
- Architecture documentation libraries
- Design specification repositories
- Training and onboarding materials

## Cross-Source Correlation

When a topic spans multiple sources, follow this priority order:

1. **Official specs / SDM** → Intel Developer Technical Library (for architecture/ISA/register specs)
2. **Product milestones** → Atlas Product Dashboard (for timelines, PRQ, steppings)
3. **Program metrics** → Power BI Reports (for dashboards, tracking data)
4. **Internal context** → Confluence (for how Intel uses/implements it)
5. **Working documents** → SharePoint (for current designs, presentations, specs)

### Atlas Product Dashboard

- URL pattern: `https://atlas.intel.com/ProductDashboard/<product_id>`
- Requires Intel SSO (Kerberos)
- Best for: milestone dates, stepping info, program status, SKU definitions
- If the product ID is unknown, suggest the user search Atlas by product name

### Intel Developer Technical Library

- URL: `https://www.intel.com/content/www/us/en/developer/technical-library/overview.html`
- Publicly accessible — no SSO needed
- 3800+ documents: SDM, ISA extensions, TDX, VT-d, architecture specs, white papers
- Filter by content type: Technical Specifications, User Guides, Reference Guides, White Papers, Release Notes
- Key documents updated frequently:
  - Intel 64 and IA-32 SDM (all volumes) — latest March 2026
  - ISA Extensions Programming Reference — latest March 2026
  - TDX Module specs (base, partitioning, migration, ABI) — latest June 2026
  - VT-d Architecture Specification — latest May 2026
  - Memory Encryption Technologies Specification — latest June 2026

### Power BI Reports

- Requires Intel SSO + group membership
- Provide direct URLs when known
- Best for: program health tracking, milestone dashboards, resource reports

### Disambiguation

Many Intel acronyms are overloaded. When multiple meanings exist:

1. Present ALL known definitions
2. Group by domain (silicon, software, process, business)
3. Ask the user which context they're working in
4. Then deep-dive into the relevant definition

### Building Context Chains

For complex topics, build understanding progressively:

1. Start with the core term definition
2. Identify prerequisite concepts mentioned in the results
3. Search for those prerequisites
4. Build a concept map linking related terms
5. Present the full picture with cross-references

## Caching and Memory

After researching a topic, consider saving key findings to session memory (`/memories/session/`) for quick reference during the conversation:

```
/memories/session/intel-acronyms-researched.md
```

This avoids redundant queries if the user asks follow-up questions about related topics.
