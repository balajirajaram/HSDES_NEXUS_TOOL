---
name: report-generator
description: >
  Generate a summarized HTML report on any Intel chip engineering topic. Gathers information
  from built-in references, Confluence, SharePoint, and the Intel Developer Technical Library,
  then produces a self-contained HTML file with a block diagram, source summary, and structured
  explanation. Use when: user asks to "generate a report", "create a summary", "explain topic
  as a report", or wants an HTML output on any silicon/architecture topic.
argument-hint: "topic to report on (e.g., 'PRQ process', 'CXL architecture', 'stepping conventions')"
---

# Report Generator Skill

Generate a self-contained HTML report that summarizes a chip engineering topic from multiple sources, includes a Mermaid block diagram, and provides a structured explanation.

## When to Use

- User asks to **generate a report** on a topic
- User wants an **HTML output** or **downloadable summary**
- User says "summarize", "explain as a report", "create a doc on [topic]"
- User wants a **block diagram** with explanation

## Procedure

### Step 1: Gather Information

Collect topic information from all available sources in this order:

1. **Built-in references** — check `intel-tech-lookup` and `silicon-process` reference files
2. **Confluence** — search for internal wiki pages on the topic
3. **SharePoint** — search for design docs and presentations
4. **Intel Developer Technical Library** — search for official specs and white papers

For each source, capture:
- **Source name** (e.g., "Confluence — SV Team Wiki")
- **Key facts** found
- **URL** (if available)

### Step 2: Build the Report Structure

Organize gathered information into these sections:

| Section | Content |
|---------|---------|
| **Title & Summary** | Topic name, 2-3 sentence overview |
| **Block Diagram** | Mermaid flowchart showing the concept/process flow |
| **Detailed Explanation** | Multi-paragraph breakdown with subsections |
| **Source Summary Table** | Where each piece of information came from |
| **Related Topics** | Links to related concepts for further reading |
| **Glossary** | Key acronyms and terms used in the report |

### Step 3: Generate HTML File

Use the HTML template from [report-template.html](./templates/report-template.html) to produce a self-contained HTML file. The template includes:
- Mermaid.js CDN for rendering block diagrams
- Responsive CSS styling
- Print-friendly layout
- Source attribution table

### Step 4: Save the Report

Save the generated HTML file to the workspace:
- **File path:** `reports/<topic-slug>-report.html`
- **Naming convention:** lowercase, hyphens, no spaces (e.g., `prq-process-report.html`)

## Output Format

The final HTML report must include:

```html
<!-- Title Section -->
<h1>[Topic Name]</h1>
<p class="summary">[2-3 sentence overview]</p>
<p class="metadata">Generated: [date] | Sources: [count] sources consulted</p>

<!-- Block Diagram -->
<div class="mermaid">[Mermaid flowchart code]</div>

<!-- Detailed Explanation -->
<h2>Overview</h2>
<p>[What it is, why it matters]</p>

<h2>How It Works</h2>
<p>[Process/architecture details with subsections]</p>

<h2>Key Details</h2>
<table>[Structured data — criteria, specs, parameters]</table>

<!-- Source Summary -->
<h2>Sources</h2>
<table>
  <tr><th>Source</th><th>Type</th><th>Key Information</th></tr>
  <tr><td>[source]</td><td>[reference/wiki/doc]</td><td>[what was found]</td></tr>
</table>

<!-- Related Topics & Glossary -->
<h2>Related Topics</h2>
<h2>Glossary</h2>
```

## Example Prompt → Output

**User:** "Generate a report on the PRQ process"

**Agent produces:** `reports/prq-process-report.html` containing:
- Summary of what PRQ is and why it matters
- Block diagram: `Validation → Gate Review → Sighting Closure → Errata Doc → PRQ Approval → HVM`
- Detailed explanation of gate criteria, sighting thresholds, and stakeholder sign-offs
- Source table listing milestones.md, Confluence pages, and Atlas data
- Glossary of PRQ, HVM, BKC, ECO, and related terms
