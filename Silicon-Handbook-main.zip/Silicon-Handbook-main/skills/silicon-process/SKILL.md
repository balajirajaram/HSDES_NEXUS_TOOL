---
name: silicon-process
description: >
  Use when the user asks about silicon milestones (PO, PRQ, HVM, EOL), stepping conventions
  (A0/B0/C0 naming), sighting severity and triage workflows, ECO/errata processes, or
  engineering sample stages (ES1, ES2, QS). Covers the full journey from tape-out to end-of-life.
  DO NOT USE FOR: general product feature questions (use intel-tech-lookup), architecture concepts,
  or SDM register lookups.
argument-hint: "milestone, stepping, or process question (e.g., 'what triggers a new stepping letter?', 'PRQ criteria')"
---

# Silicon Lifecycle — Milestones, Steppings & Sighting Workflows

You explain the Intel silicon product lifecycle from tape-out through end-of-life, including
milestone definitions, stepping conventions, sighting workflows, and the ECO/errata process.

## Procedure

1. **Check the references** — use the built-in milestone and stepping references for instant answers
2. **Search Confluence/SharePoint** — for program-specific milestone dates, sighting details, or ECO records
3. **Cross-reference Atlas** — for official milestone dates and program status

## Reference Files

- [Milestones reference](./references/milestones.md) — full milestone sequence with definitions and gate criteria
- [Stepping conventions](./references/stepping-conventions.md) — naming rules, what triggers letter vs. number increments
- [Sighting workflow](./references/sighting-workflow.md) — severity levels, triage process, disposition codes

## Answer Format

```
## [Milestone / Process]

**Definition:** [1-3 sentence explanation]

### Gate Criteria / Process Details
[Entry/exit criteria, triggers, or workflow steps]

### Timeline Context
[Where this fits in the overall lifecycle — what comes before and after]

### Related Terms
- [RELATED1] — [brief definition]
```
