# Silicon Milestone Definitions

The Intel silicon lifecycle follows a defined sequence of milestones from initial design through high-volume manufacturing. Each milestone is a formal gate with entry/exit criteria.

## Milestone Sequence

```
Tape-Out → PO (A0) → ES1 → ES2 → QS → PRQ → HVM → EOL
```

## Pre-Silicon Milestones

| Milestone | Full Name | Description |
|-----------|-----------|-------------|
| RTL Freeze | Register Transfer Level Freeze | Design description locked — no functional changes allowed |
| Tape-Out | Tape-Out | Final design sent to foundry for mask creation |
| Mask Set | Mask Set | Physical masks created for lithography |

## Post-Silicon Milestones

| Milestone | Full Name | Description |
|-----------|-----------|-------------|
| PO | Power On | First silicon powers on and executes basic instructions. Major milestone — proves the design is functional at the transistor level. Typically the A0 stepping. |
| A0 | A-zero stepping | First silicon revision. Expected to have significant bugs. Used for initial silicon validation (SV) bring-up. |
| ES1 | Engineering Sample 1 | First samples distributed to validation teams. Not for customer use. May be A0 or A1 stepping. |
| ES2 | Engineering Sample 2 | Improved samples after initial bug fixes. Broader validation. Typically B0 stepping. |
| QS | Qualification Sample | Near-final silicon sent to OEM/ODM partners for platform qualification. Must meet most PRQ criteria. Typically C0 or later stepping. |
| PRQ | Production Release Qualification | Product declared ready for volume manufacturing and customer shipment. All critical bugs resolved or documented as errata. Formal quality gate. |
| HVM | High Volume Manufacturing | Factory producing silicon at scale for commercial orders. |
| EOL | End of Life | Product discontinued — last orders accepted, then production ceases. |

## Gate Criteria Summary

### PO (Power On) Gate
- Silicon boots to a known-good state
- Basic instruction execution verified
- Clock and power delivery functional
- JTAG/DCI debug access working

### PRQ Gate
- All S1 (different systems impacted) sightings resolved
- All S2 sightings resolved or formally waived
- BKC (Best Known Configuration) validated and documented
- Errata document published for remaining known issues
- OEM/ODM qualification complete
- Manufacturing test coverage meets targets
- Power and thermal within spec
- All product SKUs validated

### HVM Gate
- Yield targets met
- Manufacturing test programs qualified
- Supply chain and packaging validated
- All PRQ criteria sustained at volume

## Typical Timeline

The time between milestones varies by product complexity:

| Phase | Typical Duration |
|-------|-----------------|
| Tape-Out → PO | 3-4 months (foundry fabrication) |
| PO → PRQ | 6-18 months (validation and bug fixing) |
| PRQ → HVM | 1-3 months (manufacturing ramp) |
| HVM → EOL | 3-7 years (product lifetime) |

> **Note:** These are approximate. Actual timelines depend on process node maturity, product complexity, and market requirements. Check Atlas Product Dashboard for official dates.
