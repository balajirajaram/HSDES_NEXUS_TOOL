# Stepping Conventions

## Naming Format

Intel silicon steppings follow the pattern: **[Letter][Number]** (e.g., A0, B1, C0).

### Letter Increment (Major Revision)
A new **letter** indicates a metal layer or significant mask change:
- Requires new masks (expensive — typically $1M+ per mask set at advanced nodes)
- Addresses multiple bugs simultaneously
- Changes physical layout or routing
- Usually triggers a new round of full validation

### Number Increment (Minor Revision)
A new **number** indicates a minor change within the same mask set:
- Typically a single-layer metal fix (e.g., fuse blow, register default change)
- Addresses a small number of critical bugs
- Faster turnaround than a full respin
- May not require full re-validation

## Typical Stepping Progression

```
A0 → A1 → B0 → B1 → C0 (PRQ)
│         │         │
│         │         └── Production stepping (PRQ candidate)
│         └── Second major revision (most critical bugs fixed)
└── First silicon (expected to have significant issues)
```

### Common Patterns

| Stepping | Typical Use | Notes |
|----------|------------|-------|
| A0 | Initial power-on, SV bring-up | First silicon — many bugs expected |
| A1 | Continued SV, early EV | Minor fixes to A0, same metal layers |
| B0 | Broader validation (SV + EV + PV) | Major bug fixes, new masks |
| B1 | Extended validation, OEM samples | Minor fixes to B0 |
| C0 | PRQ candidate, production | Final stepping for HVM |

### Exceptions
- Not all products go through every stepping (may skip A1 or go directly to PRQ on B0)
- Some products have D0 or later steppings if significant issues are found late
- Server products tend to have more steppings than client due to higher quality requirements

## Stepping vs. Errata

- **Stepping change**: Physical silicon modification to fix a bug
- **Errata**: Documented workaround for a bug that is NOT fixed in silicon
- At PRQ, remaining known bugs are documented as errata rather than requiring another stepping
- Errata may have BIOS, firmware, or software workarounds

## Metal Layer Fixes

Modern processors have 10+ metal layers. Fixes that only change upper metal layers are cheaper and faster:

| Fix Type | Layers Changed | Turnaround | Cost |
|----------|---------------|------------|------|
| Full respin (new letter) | All layers | 3-4 months | High |
| Metal-only fix (new number) | Upper metal only | 4-8 weeks | Medium |
| Fuse/config fix | None (programming change) | Days | Low |
