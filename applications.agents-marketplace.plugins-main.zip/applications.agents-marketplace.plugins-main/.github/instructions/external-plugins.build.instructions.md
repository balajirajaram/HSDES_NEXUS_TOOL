---
name: external-plugin-registry
description: 'Reusable rules for building an external plugin registry with validated submissions, reject-over-sanitize approach, and deterministic marketplace generation by merging local and external plugins.'
---

## Role

You are building an external plugin registry system. External plugins are hosted in third-party repositories and tracked in a local registry file. They are validated, approved, merged with local plugins, and output into a single combined marketplace manifest.

## Registry File Schema

Each `external-plugins.json` file is a JSON object with a top-level `owners` metadata section and a `plugins` array:

```json
{
  "owners": ["owner1@intel.com", "owner2@intel.com"],
  "plugins": [
    {
      "name": "string",
      "description": "string",
      "version": "string",
      "owners": ["user@intel.com", "user2@intel.com"],
      "repository": "string (optional)",
      "homepage": "string (optional)",
      "license": "string (optional)",
      "keywords": ["string (optional)"],
      "tags": ["string (optional)"],
      "source": {
        "source": "string",
        "repo": "string",
        "path": "string (optional)",
        "ref": "string (optional)",
        "sha": "string (optional)"
      }
    }
  ]
}
```

### File-Level Owners

The top-level `owners` field declares who owns the registry file itself (not individual plugins). Rules:

- Required, array of valid Intel email addresses (`*@intel.com`), minimum 2 entries
- These owners are responsible for reviewing and approving changes to this file
- During build, the CODEOWNERS file is automatically updated with a line mapping the path to this `external-plugins.json` to its declared owners

Example CODEOWNERS entry generated:
```
plugins/suborg-a/external-plugins.json  @owner1 @owner2
```

The email-to-GitHub-handle mapping should be resolved during the sync (e.g., strip `@intel.com` and use the prefix, or look up from a mapping table).

## Validation Rules

### File-Level Validation

| Field | Required | Constraints |
|-------|----------|-------------|
| `owners` (top-level) | Yes | Array of valid Intel email addresses (`*@intel.com`), minimum 2 entries |
| `plugins` | Yes | Array of plugin objects |

### Plugin Entry Constraints

| Field | Required | Constraints |
|-------|----------|-------------|
| `name` | Yes | Non-empty, ≤50 chars, `/^[a-z0-9-]+$/` only |
| `description` | Yes | Non-empty, ≤1024 chars |
| `version` | Yes | Non-empty, ≤100 chars |
| `owners` | Yes | Array of valid Intel email addresses (`*@intel.com`), minimum 2 entries |
| `repository` | No | If present, valid HTTPS URL pointing to a public source host |
| `homepage` | No | If present, valid HTTPS URL |
| `license` | No | If present, non-empty string (e.g., SPDX identifier) |
| `keywords` | No | If present, array ≤10 items, each ≤30 chars, `/^[a-z0-9-]+$/` |
| `tags` | No | If present, array of non-empty strings |
| `source.source` | Yes | Must be an allowed source type (e.g., `"github"`) |
| `source.repo` | Yes | Format: `owner/repo`, regex `/^[A-Za-z0-9_.-]+\/[A-Za-z0-9_.-]+$/` |
| `source.path` | No | Safe relative path: no `..`, no backslashes, no trailing manifest filename; use `/` for repo root |
| `source.ref` | No | If present, non-empty string (tag, branch, or commit ref) |
| `source.sha` | No | If present, full 40-character lowercase hex SHA |

### Owners Validation

- Must be an array with at least 2 entries
- Each entry must be a valid email address matching `*@intel.com`
- Reject entries with empty strings or non-Intel email domains

### Duplicate Detection

- No two entries in the external registry may share the same name (case-insensitive comparison)
- No external entry name may collide with a local plugin name
- Duplicates are hard errors that fail the build

### Path Safety

`source.path` is validated against traversal attacks:
- No `..` segments
- No backslashes (must use forward slashes)
- Must not point directly to a manifest file (e.g., `plugin.json`) — must be the parent directory
- Bare `.` is rejected; use `/` for repo root

## Sanitization Approach

**Reject, never sanitize.** Invalid data causes a hard failure — no field-level escaping, trimming, coercion, or silent correction.

- URLs must parse as valid HTTPS — no protocol guessing
- Paths are validated against traversal — no normalization applied
- Names and keywords must match strict regex — no automatic lowercasing or character stripping
- If input doesn't pass validation, the submitter must fix it

This ensures the registry never contains ambiguous or partially-valid entries.

## Merge Logic (Build-Time)

Each DCG sub-org maintains its own `external-plugins.json` file. The directory structure looks like:

```
plugins/
  <suborg-a>/
    external-plugins.json
  <suborg-b>/
    external-plugins.json
  <suborg-c>/
    external-plugins.json
```

When generating the combined marketplace output:

1. **Read local plugins** — iterate plugin directories, extract `{ name, description, version, source, installScript, checkCommand, owners, keywords, tags }` from each manifest file
2. **Discover external registries** — find all `external-plugins.json` files under sub-org directories (e.g., `plugins/<suborg>/external-plugins.json`)
3. **Read and validate each external registry** — for each sub-org's `external-plugins.json`, load and validate all entries. Pass accumulated plugin names (local + previously processed sub-orgs) for collision detection. **Fail the build** if any validation error in any file
4. **Merge** — push all external entries from all sub-orgs into the same array as local entries, preserving all external fields verbatim (owners, repository, license, keywords, tags, source object, etc.)
5. **Sort** — alphabetically by name, case-insensitive
6. **Write** — output a single combined manifest file
7. **Sync CODEOWNERS** — for each discovered `external-plugins.json`, write a CODEOWNERS entry mapping the file path to the top-level `owners` from that file

### Multi-Registry Rules

- Each sub-org owns and manages its own `external-plugins.json` independently
- Plugin names must be globally unique across ALL sub-org registries and local plugins — a name collision between two sub-orgs is a build error
- Validation errors in one sub-org's file fail the entire build (no partial merges)
- The build discovers registries by scanning for `external-plugins.json` files — new sub-orgs are picked up automatically without config changes

### Merge Rules

- External entries appear alongside local entries with no structural distinction except richer metadata
- Local entries have a `source` string (directory name); external entries have a `source` object (with repo coordinates)
- The combined output is deterministic — same inputs always produce the same sorted output
- The build never modifies the external registry file — it only reads it
- **Deletes propagate automatically** — if an entry is removed from the external registry, it will no longer appear in the generated marketplace output on the next build. The marketplace is always regenerated from scratch; it is not patched incrementally.

## Submission Lifecycle

Three-phase intake for new external plugins:

### Phase 1 — Metadata Validation
- Parse the structured submission into a plugin JSON object
- Validate all required fields and format constraints

### Phase 3 — Approval & Merge
- A maintainer reviews and approves
- The entry is upserted into the external registry (insert new or update existing by name match)
- The full registry is re-validated and re-sorted after upsert
- Changes are submitted via PR targeting the main branch

## Design Principles

1. **Single validator** — one shared validation module used by build, intake, approval, and PR checks
2. **Reject over sanitize** — invalid input is never silently fixed
3. **Deterministic output** — sorted, reproducible marketplace file on every build
4. **No direct edits** — the registry file is modified only through automated tooling after validation passes
5. **Collision prevention** — namespace is shared between local and external plugins; duplicates are build errors
6. **Staleness management** — time-based re-review ensures abandoned plugins don't persist indefinitely
