#!/usr/bin/env bash
#
# Build .github/plugin/marketplace.json from plugin.json files,
# external-plugins.json registries, and CODEOWNERS.
#
# Requirements: bash 4+, jq
# Usage:        bash scripts/build-marketplace.sh
#
set -euo pipefail

REPO_ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
cd "$REPO_ROOT"

MARKETPLACE=".github/plugin/marketplace.json"
CODEOWNERS=".github/CODEOWNERS"
BUILD_DIR=".build-tmp"
META_VERSION="1.0.0"
VALIDATE_EXTERNAL=".github/scripts/validate-external-plugins.sh"

if ! command -v jq >/dev/null 2>&1 && ! command -v jq.exe >/dev/null 2>&1; then
  echo "Error: jq is required but not installed." >&2
  exit 1
fi

# Wrapper: strip \r from jq output (Windows jq.exe emits CRLF via WSL interop)
_jq_bin=$(command -v jq 2>/dev/null || command -v jq.exe 2>/dev/null)
jq() { "$_jq_bin" "$@" | tr -d '\r'; }

if [ ! -f "$CODEOWNERS" ]; then
  echo "Error: $CODEOWNERS not found." >&2
  exit 1
fi

mkdir -p "$BUILD_DIR"
trap 'rm -rf "$BUILD_DIR"' EXIT

# ---------------------------------------------------------------------------
# 1. Parse CODEOWNERS into a JSON lookup: path -> [emails]
# ---------------------------------------------------------------------------
owners_map=$(awk '
  /^[[:space:]]*#/ { next }
  /^[[:space:]]*$/ { next }
  $1 ~ /^\/plugins\// {
    path = $1
    printf "%s", path
    for (i = 2; i <= NF; i++) printf "\t%s", $i
    printf "\n"
  }
' "$CODEOWNERS" | jq -Rn '
  [inputs | split("\t") | {key: .[0], value: .[1:]}] |
  from_entries
')

# ---------------------------------------------------------------------------
# 2. Walk every plugin.json and emit one JSON entry per line.
# ---------------------------------------------------------------------------
# Discover plugin directories: collect every dir that has a plugin.json
# (either at the root or inside .claude-plugin/), deduplicate by plugin dir.
find plugins -not -path '*/.*' -type f -name plugin.json -printf '%h\n' > "$BUILD_DIR/plugin_dirs.txt"
find plugins -path '*/.claude-plugin/plugin.json' \
  | sed 's|/\.claude-plugin/plugin\.json$||' >> "$BUILD_DIR/plugin_dirs.txt"
sort -u -o "$BUILD_DIR/plugin_dirs.txt" "$BUILD_DIR/plugin_dirs.txt"

: > "$BUILD_DIR/entries.jsonl"

while IFS= read -r dir <&3 || [ -n "${dir:-}" ]; do
  if [ -f "$dir/.claude-plugin/plugin.json" ]; then
    pjson="$dir/.claude-plugin/plugin.json"
  elif [ -f "$dir/plugin.json" ]; then
    pjson="$dir/plugin.json"
  else
    continue
  fi

  if ! jq empty "$pjson" >/dev/null 2>&1; then
    echo "Error: invalid JSON in plugin manifest: $pjson" >&2
    jq empty "$pjson" >/dev/null
  fi
  source_path="./$dir"
  co_key="/$dir/"

  entry=$(jq -cn \
    --slurpfile p "$pjson" \
    --arg source "$source_path" \
    --arg co_key "$co_key" \
    --argjson owners_map "$owners_map" \
    '
    ($p[0]) as $plugin |
    ($owners_map[$co_key] // []) as $owners |
    {
      name:        ($plugin.name | gsub(" "; "-")),
      description: (
        ($plugin.description + "\n" + (($plugin.keywords // []) | join(", "))) as $full |
        if ($full | length) > 1024 then $full[:1024] else $full end
      ),
      version:     ($plugin.version | gsub("\\r";"") ),
      source:      (if $plugin.source then $plugin.source else $source end)
    }
    + (($plugin.installScript // $plugin.installer.windows.script // null) as $is |
       if $is then {installScript: $is} else {} end)
    + (($plugin.checkCommand // null) as $cc |
       if $cc then {checkCommand: $cc} else {} end)
    + {
      owners:       $owners,
      keywords:     ($plugin.keywords // []),
      tags:         ($plugin.tags // [])
    }
    ' < /dev/null)

  printf '%s\n' "$entry" >> "$BUILD_DIR/entries.jsonl"
done 3< "$BUILD_DIR/plugin_dirs.txt"

# ---------------------------------------------------------------------------
# 3. Discover and validate external-plugins.json registries.
# ---------------------------------------------------------------------------
mapfile -t external_files < <(find plugins -name 'external-plugins.json' -type f 2>/dev/null | sort)

if [ ${#external_files[@]} -gt 0 ]; then
  echo "Found ${#external_files[@]} external-plugins.json file(s):"
  printf '  %s\n' "${external_files[@]}"

  # Validate all external registries (shared validator — reject, never sanitize)
  if ! bash "$VALIDATE_EXTERNAL" "${external_files[@]}"; then
    echo "Error: external-plugins.json validation failed." >&2
    exit 1
  fi

  # Merge external entries into the entries file
  for ext_file in "${external_files[@]}"; do
    ext_count=$(jq '.plugins | length' "$ext_file")
    for ((i = 0; i < ext_count; i++)); do
      entry=$(jq -cn \
        --slurpfile f "$ext_file" \
        --argjson i "$i" \
        '
        ($f[0].plugins[$i]) as $p |
        {
          name:        $p.name,
          description: $p.description,
          version:     $p.version,
          source:      $p.source,
          owners:      $p.owners
        }
        + (if $p.repository then {repository: $p.repository} else {} end)
        + (if $p.homepage   then {homepage:   $p.homepage}   else {} end)
        + (if $p.license    then {license:    $p.license}    else {} end)
        + {
          keywords:    ($p.keywords // []),
          tags:        ($p.tags // [])
        }
        ')
      printf '%s\n' "$entry" >> "$BUILD_DIR/entries.jsonl"
    done
  done
fi

# ---------------------------------------------------------------------------
# 4. Sync CODEOWNERS with external-plugins.json owner entries.
# ---------------------------------------------------------------------------
if [ ${#external_files[@]} -gt 0 ]; then
  CODEOWNERS_MARKER_START="# >>> external-plugins.json owners (auto-generated — do not edit)"
  CODEOWNERS_MARKER_END="# <<< external-plugins.json owners (auto-generated)"

  # Remove any existing auto-generated block AND stray blank lines it left behind
  if grep -qF "$CODEOWNERS_MARKER_START" "$CODEOWNERS"; then
    sed -i "/$CODEOWNERS_MARKER_START/,/$CODEOWNERS_MARKER_END/d" "$CODEOWNERS"
  fi
  # Strip trailing blank lines so the next append is idempotent
  # (without this, each run accumulates an extra blank line → spurious PRs)
  sed -i -e :a -e '/^[[:space:]]*$/{$d;N;ba' -e '}' "$CODEOWNERS"

  # Build new block
  codeowners_block="$CODEOWNERS_MARKER_START"
  for ext_file in "${external_files[@]}"; do
    # Keep full email addresses to match the existing CODEOWNERS format
    emails=$(jq -r '.owners[]' "$ext_file" | tr '\n' ' ')
    codeowners_block+=$'\n'"/$ext_file  $emails"
  done
  codeowners_block+=$'\n'"$CODEOWNERS_MARKER_END"

  # Append block to CODEOWNERS
  printf '\n%s\n' "$codeowners_block" >> "$CODEOWNERS"
  echo "Updated CODEOWNERS with external-plugins.json owner entries."
fi

# ---------------------------------------------------------------------------
# 5. Assemble the final file (plugins sorted by name for determinism).
# ---------------------------------------------------------------------------
jq -s 'sort_by(.name)' "$BUILD_DIR/entries.jsonl" > "$BUILD_DIR/plugins_sorted.json"
count=$(jq 'length' "$BUILD_DIR/plugins_sorted.json" | tr -cd '0-9')

if [ "$count" -eq 0 ]; then
  echo "Error: no plugins found under plugins/." >&2
  exit 1
fi

jq -n \
  --arg meta_version "$META_VERSION" \
  --slurpfile plugins "$BUILD_DIR/plugins_sorted.json" \
  '{
    name: "plugins-marketplace",
    owner: { name: "dcg" },
    metadata: {
      description: "A general marketplace of plugins, agents, and MCP servers organized by organization and team.",
      version: $meta_version
    },
    plugins: $plugins[0]
  }' > "$MARKETPLACE"

echo "Built $MARKETPLACE with $count plugin(s) (metadata version $META_VERSION)"
