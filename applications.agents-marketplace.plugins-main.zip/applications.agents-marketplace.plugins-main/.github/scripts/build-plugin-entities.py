#!/usr/bin/env python3
import argparse
import json
import pathlib
from typing import Dict, List


def rel(path: pathlib.Path, root: pathlib.Path) -> str:
    return path.relative_to(root).as_posix()


def unique_by_path(items: List[Dict[str, str]]) -> List[Dict[str, str]]:
    seen = set()
    out = []
    for item in items:
        key = item.get("path", "") or item.get("name", "")
        if key in seen:
            continue
        seen.add(key)
        out.append(item)
    return out


def shorten(text: str, limit: int = 220) -> str:
    text = " ".join(text.strip().split())
    if len(text) <= limit:
        return text
    return text[: limit - 1].rstrip() + "..."


def extract_description_from_markdown(path: pathlib.Path) -> str:
    try:
        text = path.read_text(encoding="utf-8")
    except Exception:
        return ""

    lines = text.splitlines()

    # YAML frontmatter description is the best source when present.
    if lines and lines[0].strip() == "---":
        i = 1
        while i < len(lines):
            raw_line = lines[i]
            line = raw_line.strip()
            if line == "---":
                break

            if line.lower().startswith("description:"):
                desc_value = raw_line.split(":", 1)[1].strip().strip('"').strip("'")

                # Support YAML block scalars for multiline descriptions.
                if desc_value in {"|", ">", "|-", ">-", "|+", ">+"}:
                    block_lines = []
                    i += 1
                    while i < len(lines):
                        block_raw = lines[i]
                        block_strip = block_raw.strip()
                        if block_strip == "---":
                            break
                        if not block_raw.startswith(" ") and block_strip:
                            break
                        cleaned = block_raw.strip()
                        if cleaned:
                            block_lines.append(cleaned)
                        i += 1

                    if block_lines:
                        return shorten(" ".join(block_lines))
                elif desc_value:
                    return shorten(desc_value)

            i += 1

    # Fallback: first meaningful non-empty line.
    in_code = False
    for raw in lines:
        line = raw.strip()
        if not line:
            continue
        if line.startswith("```"):
            in_code = not in_code
            continue
        if in_code:
            continue
        if line in {"---", "***"}:
            continue
        if line.startswith("[") and "](" in line:
            continue
        if line.startswith("|"):
            continue

        clean = line.lstrip("#").strip()
        clean = clean.lstrip("- ").strip()
        if clean:
            return shorten(clean)

    return ""


def extract_description_from_json(path: pathlib.Path) -> str:
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return ""

    if isinstance(data, dict):
        if isinstance(data.get("description"), str) and data.get("description").strip():
            return shorten(data["description"])
        if isinstance(data.get("name"), str) and data.get("name").strip():
            return shorten(f"Config for {data['name']}")

    return ""


def extract_description(path: pathlib.Path) -> str:
    low = path.name.lower()
    if low.endswith(".json"):
        desc = extract_description_from_json(path)
        if desc:
            return desc
    if low.endswith(".md") or low.endswith(".txt"):
        desc = extract_description_from_markdown(path)
        if desc:
            return desc
    return ""


def collect_plugin_entities(repo_root: pathlib.Path, source_value):
    empty = {"mcp": [], "skills": [], "agents": [], "prompts": []}

    if not isinstance(source_value, str):
        return empty

    plugin_dir = repo_root / source_value.lstrip("./")
    if not plugin_dir.exists() or not plugin_dir.is_dir():
        return empty

    skills = []
    agents = []
    prompts = []
    mcp = []

    # Skills are explicit skill definitions.
    for p in plugin_dir.rglob("*"):
        if not p.is_file():
            continue
        low_name = p.name.lower()
        low_path = p.as_posix().lower()

        if low_name == "skill.md":
            skills.append({
                "name": p.parent.name,
                "path": rel(p, repo_root),
                "description": extract_description(p),
            })

        # Agents can be dedicated files or agent-styled prompt markdown.
        if low_name == "agent.md" or low_name.endswith(".agent.md"):
            agents.append({
                "name": p.stem.replace(".agent", ""),
                "path": rel(p, repo_root),
                "description": extract_description(p),
            })

        # Prompts include prompt markdown/text files and prompt directories.
        is_prompt_dir = "/prompts/" in low_path or "/prompt/" in low_path
        is_prompt_file = ".prompt." in low_name
        if is_prompt_dir or is_prompt_file:
            prompts.append({
                "name": p.name,
                "path": rel(p, repo_root),
                "description": extract_description(p),
            })

    for p in plugin_dir.rglob("*.mcp.json"):
        try:
            data = json.loads(p.read_text(encoding="utf-8"))
        except Exception:
            mcp.append({"name": p.name, "path": rel(p, repo_root), "description": "MCP config file"})
            continue

        servers = data.get("mcpServers") if isinstance(data, dict) else None
        if isinstance(servers, dict) and servers:
            for key in sorted(servers.keys()):
                server = servers.get(key)
                desc = ""
                if isinstance(server, dict):
                    if isinstance(server.get("description"), str):
                        desc = server.get("description", "").strip()
                    if not desc and isinstance(server.get("type"), str):
                        desc = f"{server.get('type', '').upper()} MCP server"
                    if not desc and isinstance(server.get("url"), str):
                        desc = f"Endpoint: {server.get('url', '').strip()}"
                mcp.append({"name": key, "path": rel(p, repo_root), "description": shorten(desc) if desc else "MCP server"})
        else:
            mcp.append({"name": p.name, "path": rel(p, repo_root), "description": "MCP config file"})

    dot_mcp = plugin_dir / ".mcp.json"
    if dot_mcp.exists() and dot_mcp.is_file():
        try:
            data = json.loads(dot_mcp.read_text(encoding="utf-8"))
            servers = data.get("mcpServers") if isinstance(data, dict) else None
            if isinstance(servers, dict) and servers:
                for key in sorted(servers.keys()):
                    server = servers.get(key)
                    desc = ""
                    if isinstance(server, dict):
                        if isinstance(server.get("description"), str):
                            desc = server.get("description", "").strip()
                        if not desc and isinstance(server.get("type"), str):
                            desc = f"{server.get('type', '').upper()} MCP server"
                        if not desc and isinstance(server.get("url"), str):
                            desc = f"Endpoint: {server.get('url', '').strip()}"
                    mcp.append({"name": key, "path": rel(dot_mcp, repo_root), "description": shorten(desc) if desc else "MCP server"})
            else:
                mcp.append({"name": dot_mcp.name, "path": rel(dot_mcp, repo_root), "description": "MCP config file"})
        except Exception:
            mcp.append({"name": dot_mcp.name, "path": rel(dot_mcp, repo_root), "description": "MCP config file"})

    return {
        "mcp": unique_by_path(mcp),
        "skills": unique_by_path(skills),
        "agents": unique_by_path(agents),
        "prompts": unique_by_path(prompts),
    }


def main():
    parser = argparse.ArgumentParser(description="Build plugin entity inventory JSON")
    parser.add_argument(
        "--out",
        dest="out",
        default=None,
        help="Optional output file path. Defaults to .github/plugin/plugin-entities.json",
    )
    args = parser.parse_args()

    repo_root = pathlib.Path(__file__).resolve().parents[2]
    marketplace_path = repo_root / ".github" / "plugin" / "marketplace.json"
    out_path = pathlib.Path(args.out) if args.out else (repo_root / ".github" / "plugin" / "plugin-entities.json")

    if not out_path.is_absolute():
        out_path = repo_root / out_path
    out_path.parent.mkdir(parents=True, exist_ok=True)

    marketplace = json.loads(marketplace_path.read_text(encoding="utf-8"))
    plugins = marketplace.get("plugins") if isinstance(marketplace, dict) else []

    by_plugin = {}
    for plugin in plugins or []:
        name = plugin.get("name")
        if not name:
            continue
        by_plugin[name] = collect_plugin_entities(repo_root, plugin.get("source"))

    out_doc = {
        "version": "1.0.0",
        "plugins": by_plugin,
    }
    out_path.write_text(json.dumps(out_doc, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
