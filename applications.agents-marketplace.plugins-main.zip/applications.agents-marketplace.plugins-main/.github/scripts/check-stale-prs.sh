#!/usr/bin/env bash
# check-stale-prs.sh
#
# Daily stale-PR lifecycle:
#   Day 0           — last human activity (commit or non-bot comment)
#   Day STALE_DAYS  — add "stale" label + post initial warning
#   Days +1 … +N    — post daily countdown comment (N days left)
#   Day STALE_DAYS + CLOSE_DAYS — close the PR
#
# If a human acts after the stale label is applied the label is removed
# and the clock resets.
#
# Environment variables (all optional, defaults shown):
#   STALE_DAYS  — days of inactivity before warning  (default: 14)
#   CLOSE_DAYS  — grace period in days after warning (default: 7)
#   STALE_LABEL — label name to apply                (default: stale)
#   EXEMPT_LABELS — space-separated list of labels that protect a PR
#                   (default: "do-not-close pinned security")

set -euo pipefail

REPO="$GITHUB_REPOSITORY"
STALE_DAYS="${STALE_DAYS:-14}"
CLOSE_DAYS="${CLOSE_DAYS:-7}"
STALE_LABEL="${STALE_LABEL:-stale}"
EXEMPT_LABELS="${EXEMPT_LABELS:-do-not-close pinned security}"

# ── Helpers ──────────────────────────────────────────────────────────────────

# ISO-8601 string → unix timestamp (GNU date, available on Linux runners)
to_ts() { date -u -d "$1" +%s; }

# Days elapsed since a unix timestamp
days_since() { echo $(( ( $(date -u +%s) - $1 ) / 86400 )); }

# ── Ensure the stale label exists in the repo ─────────────────────────────────
ensure_label() {
  gh label create "$STALE_LABEL" \
    --repo "$REPO" \
    --color "e4e669" \
    --description "No recent activity" 2>/dev/null || true
}

# ── Main ─────────────────────────────────────────────────────────────────────

echo "=== Stale PR check: $(date -u) ==="
echo "    repo=$REPO  stale_after=${STALE_DAYS}d  close_after=${CLOSE_DAYS}d"

prs=$(gh pr list \
  --repo "$REPO" \
  --state open \
  --json number,title,author,labels,createdAt,headRefOid \
  --limit 200)

pr_count=$(echo "$prs" | jq 'length')
echo "Found $pr_count open PR(s)"

echo "$prs" | jq -c '.[]' | while IFS= read -r pr; do
  number=$(echo "$pr" | jq -r '.number')
  title=$(echo "$pr"  | jq -r '.title')
  author=$(echo "$pr" | jq -r '.author.login')
  label_list=$(echo "$pr" | jq -r '[.labels[].name] | join(" ")')

  echo ""
  echo "─── PR #$number: $title (@$author) ───"

  # Skip PRs that carry an exempt label
  skip=false
  for exempt in $EXEMPT_LABELS; do
    if echo " $label_list " | grep -q " $exempt "; then
      echo "  Skipping: has exempt label '$exempt'"
      skip=true
      break
    fi
  done
  $skip && continue

  now_ts=$(date -u +%s)

  # ── Determine last HUMAN activity ────────────────────────────────────────
  # 1. Date of the most recent commit on the PR branch
  head_sha=$(echo "$pr" | jq -r '.headRefOid')
  last_commit=$(gh api "repos/$REPO/commits/$head_sha" \
    --jq '.commit.committer.date' 2>/dev/null || true)

  # 2. Date of the most recent non-bot comment
  last_comment=$(gh api "repos/$REPO/issues/$number/comments" \
    --paginate \
    --jq '.[] | select(.user.type != "Bot") | .created_at' \
    2>/dev/null | sort -r | head -1 || true)

  # 3. Fall back to PR creation date
  created_at=$(echo "$pr" | jq -r '.createdAt')

  # Most recent of the three (ignoring blanks)
  last_activity=$(printf '%s\n' "$last_commit" "$last_comment" "$created_at" \
    | grep -v '^$' | sort -r | head -1)

  activity_ts=$(to_ts "$last_activity")
  inactive_days=$(days_since "$activity_ts")
  echo "  Last human activity : $last_activity ($inactive_days day(s) ago)"

  # ── Branch on whether the stale label is already present ─────────────────
  if echo " $label_list " | grep -q " $STALE_LABEL "; then

    echo "  Status: already stale"

    # When was the stale label most recently applied?
    stale_since=$(gh api "repos/$REPO/issues/$number/events" \
      --paginate \
      --jq '.[] | select(.event == "labeled" and .label.name == "stale") | .created_at' \
      | sort -r | head -1 || true)

    if [ -z "$stale_since" ]; then
      echo "  Warning: stale label present but no label event found — skipping"
      continue
    fi

    stale_ts=$(to_ts "$stale_since")

    # Human acted AFTER we marked it stale → remove label and reset
    if [ "$activity_ts" -gt "$stale_ts" ]; then
      echo "  Human activity detected after stale label → removing label"
      gh pr edit "$number" --repo "$REPO" --remove-label "$STALE_LABEL"
      continue
    fi

    stale_days=$(days_since "$stale_ts")
    days_left=$(( CLOSE_DAYS - stale_days ))
    total_inactive=$(( STALE_DAYS + stale_days ))
    echo "  Stale since : $stale_since ($stale_days day(s) into grace period)"
    echo "  Days left   : $days_left"

    if [ "$days_left" -le 0 ]; then
      echo "  Action: CLOSING PR"
      gh pr close "$number" --repo "$REPO" --comment "$(printf '%s' \
"🔒 This pull request has been automatically **closed** after **${total_inactive} days** of inactivity.

Feel free to **reopen** it whenever you are ready to continue.")"

    else
      echo "  Action: posting countdown"
      gh pr comment "$number" --repo "$REPO" --body "$(printf '%s' \
"⏳ **Stale PR reminder** — **${days_left} day(s) left** before automatic closure.

@${author} this PR has had no human activity for **${total_inactive} day(s)**.  To keep it open:
- Push a new commit
- Leave a comment
- Remove the \`${STALE_LABEL}\` label")"
    fi

  elif [ "$inactive_days" -ge "$STALE_DAYS" ]; then

    echo "  Action: marking as stale (inactive for $inactive_days day(s))"
    ensure_label
    gh pr edit "$number" --repo "$REPO" --add-label "$STALE_LABEL"
    gh pr comment "$number" --repo "$REPO" --body "$(printf '%s' \
"👋 Hi @${author},

This pull request has had no activity for **${inactive_days} day(s)** and has been marked **stale**.

It will be automatically closed in **${CLOSE_DAYS} day(s)** unless you:
- Push a new commit
- Leave a comment
- Remove the \`${STALE_LABEL}\` label

*(Daily reminders with a countdown will be posted until then.)*")"

  else
    echo "  Status: active ($inactive_days / $STALE_DAYS day(s) inactive)"
  fi

done

echo ""
echo "=== Done ==="
