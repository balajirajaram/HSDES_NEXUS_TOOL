#!/usr/bin/env bash
#
# Request an AGS entitlement/role for CODEOWNERS users that lack repository
# write access.
#
# The EC AGS CLI (https://github.com/intel-innersource/applications.productivity.ags-cli.cli)
# must be installed and accessible via PATH (or AGS_BIN env var).
#
# Requirements: bash 4+, jq
#
# Authentication — the AGS CLI supports two modes:
#
#   1. Kerberos (default, for local/EC-Linux use):
#        Run "kinit" before executing this script. No extra env vars needed.
#
#   2. SIMPLE_AUTH (for CI runners or laptops without a Kerberos ticket):
#        Pass --ags-user and --ags-password on the command line, or set the
#        equivalent environment variables.  The script will prompt for the
#        password interactively if --ags-user is given but --ags-password is not.
#
# Usage:
#   # Kerberos (after kinit):
#   bash .github/scripts/request-ags-role.sh \
#       -j "Plugin owner onboarding" user@intel.com
#
#   # SIMPLE_AUTH from your laptop (password prompted):
#   bash .github/scripts/request-ags-role.sh \
#       --ags-user myidsid \
#       -j "Plugin owner onboarding" --from-errors errors.json
#
#   # SIMPLE_AUTH non-interactive (e.g. CI):
#   bash .github/scripts/request-ags-role.sh \
#       --ags-user myidsid --ags-password "s3cr3t" \
#       -j "Plugin owner onboarding" --from-errors errors.json
#
#   # Dry-run (no AGS calls, no auth needed):
#   bash .github/scripts/request-ags-role.sh \
#       --dry-run --from-errors errors.json
#
# Options:
#   -n, --name <name>         AGS object name
#                             (default: agents-marketplace-plugins-owners)
#   -t, --type <type>         AGS object type: entitlement | role
#                             (default: entitlement)
#   -j, --justification <t>   Justification text (required unless --dry-run)
#       --from-errors <file>  Read users from a GitHub CODEOWNERS errors JSON
#                             file (as returned by GET /repos/.../codeowners/errors)
#       --ags-user <idsid>    Use SIMPLE_AUTH with this Intel IDSID
#       --ags-password <pwd>  Password for --ags-user (prompted if omitted)
#       --ags-bin <path>      Path to the ags binary (default: ags or AGS_BIN env var)
#       --dry-run             Print ags commands without executing them
#   -h, --help                Show this help
#
# Environment (all overridable by the flags above):
#   AGS_BIN       Path to the ags binary (default: ags)
#   SIMPLE_AUTH   Set to "true" to activate username/password auth
#   AGS_USER      Intel IDSID  (used when SIMPLE_AUTH=true)
#   AGS_PASSWORD  Password     (used when SIMPLE_AUTH=true; prompted if unset)
#
set -euo pipefail

# ---------- Defaults ---------------------------------------------------------
AGS_NAME="agents-marketplace-plugins-owners"
AGS_TYPE="entitlement"
JUSTIFICATION=""
DRY_RUN=false
ERRORS_FILE=""
declare -a EMAILS=()

# ---------- Helpers ----------------------------------------------------------
usage() {
  grep '^#' "$0" | sed 's/^# \{0,1\}//'
  exit 0
}

info()  { echo "INFO:  $*"; }
warn()  { echo "WARN:  $*" >&2; }
error() { echo "ERROR: $*" >&2; }

# ---------- Parse arguments --------------------------------------------------
while [[ $# -gt 0 ]]; do
  case "$1" in
    -n|--name)           AGS_NAME="$2";          shift 2 ;;
    -t|--type)           AGS_TYPE="$2";           shift 2 ;;
    -j|--justification)  JUSTIFICATION="$2";      shift 2 ;;
    --from-errors)       ERRORS_FILE="$2";        shift 2 ;;
    --ags-user)          AGS_USER="$2";  SIMPLE_AUTH=true; shift 2 ;;
    --ags-password)      AGS_PASSWORD="$2";       shift 2 ;;
    --ags-bin)           AGS_BIN="$2";            shift 2 ;;
    --dry-run)           DRY_RUN=true;            shift   ;;
    -h|--help)           usage                            ;;
    --*)                 error "Unknown option: $1"; exit 1 ;;
    *)                   EMAILS+=("$1");          shift   ;;
  esac
done

# Validate --type value
if [[ "$AGS_TYPE" != "entitlement" && "$AGS_TYPE" != "role" ]]; then
  error "--type must be 'entitlement' or 'role', got: $AGS_TYPE"
  exit 1
fi

# ---------- Collect emails from CODEOWNERS errors JSON -----------------------
if [[ -n "$ERRORS_FILE" ]]; then
  if [[ ! -f "$ERRORS_FILE" ]]; then
    error "File not found: $ERRORS_FILE"
    exit 1
  fi

  info "Parsing unresolvable owners from: $ERRORS_FILE"

  # GitHub's .message field includes the CODEOWNERS source line as context, which
  # lists every owner on the line — not just the one who lacks access.  Anchoring
  # to the "email address X exists" phrase in the prose portion of the message
  # extracts only the specific failing owner.
  mapfile -t extra_emails < <(
    jq -r '.errors[].message // ""' "$ERRORS_FILE" \
      | grep -oE 'email address [a-zA-Z0-9._%+-]+@intel\.com' \
      | grep -oE '[a-zA-Z0-9._%+-]+@intel\.com' \
      | sort -u \
      || true
  )

  if [[ ${#extra_emails[@]} -gt 0 ]]; then
    EMAILS+=("${extra_emails[@]}")
  else
    info "No @intel.com addresses found in CODEOWNERS error sources."
  fi
fi

if [[ ${#EMAILS[@]} -eq 0 ]]; then
  info "No users to process. Provide email addresses or use --from-errors <file>."
  exit 0
fi

# Remove duplicates while preserving order
declare -a unique_emails=()
declare -A seen=()
for e in "${EMAILS[@]}"; do
  lc="${e,,}"
  if [[ -z "${seen[$lc]+x}" ]]; then
    seen[$lc]=1
    unique_emails+=("$lc")
  fi
done
EMAILS=("${unique_emails[@]}")

# ---------- Validate preconditions -------------------------------------------
if [[ "$DRY_RUN" == false && -z "$JUSTIFICATION" ]]; then
  error "--justification / -j is required (or use --dry-run to skip AGS calls)."
  exit 1
fi

# Support multi-word commands like "python /c/Temp/ags-cli/ags.py"
read -ra _AGS_CMD <<< "${AGS_BIN:-ags}"

# Derive the AGS CLI source directory from _AGS_CMD so the IDSID resolver
# can import its Python modules.  Works for both:
#   --ags-bin ags                              → AGS_CLI_DIR=""  (from PATH)
#   --ags-bin "python /path/to/ags-cli/ags.py" → AGS_CLI_DIR=/path/to/ags-cli
_AGS_CLI_DIR=""
for _tok in "${_AGS_CMD[@]}"; do
  if [[ "$_tok" == *.py ]]; then
    _AGS_CLI_DIR="$(dirname "$_tok")"
    break
  fi
done

# ---------- SIMPLE_AUTH wiring -----------------------------------------------
# If the caller supplied AGS_USER / AGS_PASSWORD (e.g. from GitHub secrets),
# forward them to the env var names the AGS CLI expects (SIMPLE_AUTH, USER,
# PASSWORD).  We avoid overwriting the OS USER variable at the shell level by
# exporting only into the subprocess environment via the env(1) prefix in
# has_pending_request() and the main request loop.
_AGS_ENV=()
if [[ "${SIMPLE_AUTH:-}" == "true" ]]; then
  if [[ -z "${AGS_USER:-}" ]]; then
    error "--ags-user (or AGS_USER) is required when using SIMPLE_AUTH."
    exit 1
  fi
  if [[ -z "${AGS_PASSWORD:-}" ]]; then
    # Prompt interactively — useful when running from a laptop
    read -r -s -p "AGS password for ${AGS_USER}: " AGS_PASSWORD
    echo
    if [[ -z "$AGS_PASSWORD" ]]; then
      error "No password entered."
      exit 1
    fi
  fi
  _AGS_ENV=(env SIMPLE_AUTH=true USER="${AGS_USER}" PASSWORD="${AGS_PASSWORD}")
  info "Using SIMPLE_AUTH (user: ${AGS_USER})"
fi

if ! command -v "${_AGS_CMD[0]}" >/dev/null 2>&1; then
  error "'${_AGS_CMD[0]}' not found in PATH."
  error "  Pass --ags-bin /path/to/ags.py  or  --ags-bin \"python /c/Temp/ags-cli/ags.py\""
  error "  Install: https://github.com/intel-innersource/applications.productivity.ags-cli.cli"
  error "  Kerberos: run 'kinit' before executing this script."
  error "  CI/no-Kerberos: set SIMPLE_AUTH=true, AGS_USER, AGS_PASSWORD."
  exit 1
fi

# ---------- Resolve Intel emails → IDSIDs via the LDAP API -------------------
# The CODEOWNERS email (e.g. mihir1.mehta@intel.com) is not always the same as
# the Intel IDSID (e.g. mpmehta).  We call the AGS CLI's LDAP endpoint in
# batch to get authoritative IDSIDs.
declare -A _IDSID_MAP=()
_RESOLVER="$(dirname "${BASH_SOURCE[0]}")/resolve-idsid.py"
# Build _AGS_PYTHON: all tokens in _AGS_CMD *before* the .py script file.
# E.g. ("/c/Windows/py.exe" "-3.12" "/c/Temp/ags-cli/ags.py") → ("/c/Windows/py.exe" "-3.12")
_AGS_PYTHON=()
for _tok in "${_AGS_CMD[@]}"; do
  [[ "$_tok" == *.py ]] && break
  _AGS_PYTHON+=("$_tok")
done
# Fall back to python3 when _AGS_CMD is just "ags" (no explicit interpreter).
[[ ${#_AGS_PYTHON[@]} -eq 0 ]] && _AGS_PYTHON=(python3)

if [[ -f "$_RESOLVER" && -n "$_AGS_CLI_DIR" ]]; then
  info "Resolving IDSIDs from Intel email addresses..."
  _resolver_out=$(
    "${_AGS_ENV[@]}" "${_AGS_PYTHON[@]}" "$_RESOLVER" "$_AGS_CLI_DIR" "${EMAILS[@]}" 2>&1
  ) && _resolver_rc=0 || _resolver_rc=$?

  if [[ $_resolver_rc -eq 0 ]]; then
    # Strip Windows CR characters before parsing (Python on Windows emits \r\n)
    _resolver_clean=$(printf '%s' "$_resolver_out" | tr -d '\r')
    while IFS=$'\t' read -r _email _idsid; do
      [[ -n "$_email" && -n "$_idsid" ]] && _IDSID_MAP["${_email,,}"]="$_idsid"
    done <<< "$_resolver_clean"
    info "Resolved ${#_IDSID_MAP[@]} of ${#EMAILS[@]} emails to IDSIDs."
  else
    warn "IDSID resolver failed (exit $_resolver_rc) — falling back to email local-part."
    warn "$_resolver_out"
  fi
else
  [[ -z "$_AGS_CLI_DIR" ]] && \
    warn "AGS CLI directory unknown — cannot resolve IDSIDs. Pass --ags-bin with full path to ags.py."
fi

# ---------- Request AGS access for each user ---------------------------------
declare -a succeeded=()
declare -a failed=()
declare -a skipped=()
declare -a already_granted=()
declare -a already_pending=()
declare -a timed_out=()

echo ""
echo "AGS $AGS_TYPE : $AGS_NAME"
echo "Dry-run       : $DRY_RUN"
echo "Users         : ${#EMAILS[@]}"
echo ""

# Run an ags command, capturing stdout; returns the ags exit code.
# Usage: _ags_run <out_var> <cmd args...>
# Applies AGS_TIMEOUT (default: 300s) to prevent indefinite hangs.
AGS_TIMEOUT="${AGS_TIMEOUT:-300}"
_ags_run() {
  local _outvar="$1"; shift
  local _outfile _errfile _rc
  _outfile=$(mktemp)
  _errfile=$(mktemp)
  timeout "${AGS_TIMEOUT}" "${_AGS_ENV[@]}" "${_AGS_CMD[@]}" "$@" >"$_outfile" 2>"$_errfile" && _rc=0 || _rc=$?
  if [[ $_rc -eq 124 ]]; then
    warn "AGS CLI timed out after ${AGS_TIMEOUT}s: ${_AGS_CMD[*]} $*"
    rm -f "$_outfile" "$_errfile"
    printf -v "$_outvar" ''
    return $_rc
  fi
  if [[ $_rc -ne 0 ]]; then
    rm -f "$_outfile" "$_errfile"
    printf -v "$_outvar" ''
    return $_rc
  fi
  local _out
  _out=$(cat "$_outfile")
  rm -f "$_outfile" "$_errfile"
  printf -v "$_outvar" '%s' "$_out"
  return 0
}

# Run an ags command, capturing combined stdout+stderr in all cases.
# Usage: _ags_run_all <out_var> <cmd args...>
# Returns the exit code of the ags command.
_ags_run_all() {
  local _outvar="$1"; shift
  local _out _rc
  _out=$(timeout "${AGS_TIMEOUT}" "${_AGS_ENV[@]}" "${_AGS_CMD[@]}" "$@" 2>&1) && _rc=0 || _rc=$?
  if [[ $_rc -eq 124 ]]; then
    warn "AGS CLI timed out after ${AGS_TIMEOUT}s: ${_AGS_CMD[*]} $*"
  fi
  printf -v "$_outvar" '%s' "$_out"
  return $_rc
}

# Fetch current members of the entitlement/role once (newline-separated IDSIDs).
# Exit 4 = ObjectNotFoundException = entitlement has no members yet.
_MEMBERS_LIST=""
_MEMBERS_AVAILABLE=false
_members_out=""
_ags_run _members_out members --name "$AGS_NAME" -t "$AGS_TYPE" && _members_rc=0 || _members_rc=$?
if [[ $_members_rc -eq 0 ]]; then
  _MEMBERS_LIST=$(printf '%s' "$_members_out" | tr -d '\r')
  _MEMBERS_AVAILABLE=true
  _members_count=$(printf '%s\n' "$_MEMBERS_LIST" | grep -c .)
  info "Fetched ${AGS_TYPE} members list ($_members_count entries)."
elif [[ $_members_rc -eq 4 ]]; then
  _MEMBERS_AVAILABLE=true
  info "Entitlement '$AGS_NAME' has no current members."
else
  warn "Could not fetch members list for '$AGS_NAME' (exit $_members_rc) — pre-check disabled."
fi

# Returns 0 if <idsid> is in the pre-fetched members list.
has_entitlement() {
  local idsid="$1"
  [[ "$_MEMBERS_AVAILABLE" == true ]] || return 1
  printf '%s\n' "$_MEMBERS_LIST" | grep -qxF "$idsid"
}

# Returns 0 if <idsid> already has an open pending request for AGS_NAME.
# Exit 4 (ObjectNotFoundException) = no pending requests.
# Exit 124 = timeout (treated as unknown — proceed cautiously).
# Sets _last_pending_rc so callers can detect timeouts.
_last_pending_rc=0
has_pending_request() {
  local idsid="$1"
  local status_out _rc
  _ags_run status_out status -re "$idsid" --format json && _rc=0 || _rc=$?
  _last_pending_rc=$_rc
  if [[ $_rc -ne 0 ]]; then
    [[ $_rc -eq 124 ]] && warn "  Timed out checking pending requests for $idsid — will proceed."
    [[ $_rc -ne 4 && $_rc -ne 124 ]] && warn "  Could not check pending requests for $idsid (exit $_rc) — will proceed."
    return 1
  fi
  local count
  count=$(printf '%s' "$status_out" | jq --arg name "$AGS_NAME" \
    '[.[] | select(."Requested Entitlement/Role" == $name)] | length' 2>/dev/null) || {
    warn "  Could not parse ags status output for $idsid — will proceed."
    return 1
  }
  [[ "$count" -gt 0 ]]
}

for email in "${EMAILS[@]}"; do
  if [[ ! "$email" =~ ^[a-z0-9._-]+@intel\.com$ ]]; then
    warn "Skipping '$email': not an @intel.com address."
    skipped+=("$email")
    continue
  fi

  # Prefer the authoritatively resolved IDSID; fall back to the email local-part.
  idsid="${_IDSID_MAP[${email,,}]:-}"
  if [[ -z "$idsid" ]]; then
    idsid="${email%@intel.com}"
    warn "  Could not resolve IDSID for $email — using email local-part '$idsid' (may be wrong)."
  fi

  echo "→ $idsid  ($email)"

  if has_entitlement "$idsid"; then
    echo "  ✓ Already has '$AGS_NAME' provisioned — skipping."
    already_granted+=("$email")
    continue
  fi

  if has_pending_request "$idsid"; then
    echo "  ↷ Already has a pending request for '$AGS_NAME' — skipping."
    already_pending+=("$email")
    continue
  elif [[ ${_last_pending_rc:-0} -eq 124 ]]; then
    timed_out+=("$email")
  fi

  cmd=("${_AGS_ENV[@]}" "${_AGS_CMD[@]}" request "$AGS_TYPE" -n "$AGS_NAME" -u "$idsid" -j "$JUSTIFICATION")

  if [[ "$DRY_RUN" == true ]]; then
    echo "  [dry-run] ${cmd[*]}"
    succeeded+=("$email")
  else
    _request_out=""
    if _ags_run_all _request_out request "$AGS_TYPE" -n "$AGS_NAME" -u "$idsid" -j "$JUSTIFICATION"; then
      [[ -n "$_request_out" ]] && printf '%s\n' "$_request_out"
      echo "  ✓ Request submitted"
      succeeded+=("$email")
    else
      [[ -n "$_request_out" ]] && printf '%s\n' "$_request_out"
      if printf '%s' "$_request_out" | grep -qiE 'already has a pending .* request'; then
        echo "  ↷ Already has a pending request for '$AGS_NAME' — skipping."
        already_pending+=("$email")
      else
        warn "  ✗ Request failed for $idsid"
        failed+=("$email")
      fi
    fi
  fi
done

# ---------- Summary ----------------------------------------------------------
echo ""
echo "=== Summary ==="
echo "  Submitted       : ${#succeeded[@]}"
echo "  Already granted : ${#already_granted[@]}"
echo "  Already pending : ${#already_pending[@]}"
echo "  Timed out       : ${#timed_out[@]}"
echo "  Skipped         : ${#skipped[@]}"
echo "  Failed          : ${#failed[@]}"

if [[ ${#timed_out[@]} -gt 0 ]]; then
  # Emit GitHub Actions warning annotation (visible in the Actions UI sidebar)
  echo "::warning::AGS CLI timed out for ${#timed_out[@]} user(s) after ${AGS_TIMEOUT}s: ${timed_out[*]}"
fi

if [[ ${#succeeded[@]} -gt 0 ]]; then
  echo ""
  echo "Submitted (AGS request sent):"
  printf '  %s\n' "${succeeded[@]}"
fi

if [[ ${#already_granted[@]} -gt 0 ]]; then
  echo ""
  echo "Already have '$AGS_NAME' provisioned (no action needed):"
  printf '  %s\n' "${already_granted[@]}"
fi

if [[ ${#already_pending[@]} -gt 0 ]]; then
  echo ""
  echo "Already have a pending request (no duplicate submitted):"
  printf '  %s\n' "${already_pending[@]}"
fi

if [[ ${#skipped[@]} -gt 0 ]]; then
  echo ""
  echo "Skipped (non-Intel or unrecognised addresses):"
  printf '  %s\n' "${skipped[@]}"
fi

if [[ ${#failed[@]} -gt 0 ]]; then
  echo ""
  echo "Failed:"
  printf '  %s\n' "${failed[@]}"
fi

# ---------- Machine-readable results for CI step summary ---------------------
_to_json_array() {
  if [[ $# -eq 0 ]]; then
    printf '[]'
  else
    printf '%s\n' "$@" | jq -R . | jq -s .
  fi
}

cat > ags-results.json <<JSON
{
  "submitted":       $(_to_json_array ${succeeded[@]+"${succeeded[@]}"}),
  "already_granted": $(_to_json_array ${already_granted[@]+"${already_granted[@]}"}),
  "already_pending": $(_to_json_array ${already_pending[@]+"${already_pending[@]}"}),
  "timed_out":       $(_to_json_array ${timed_out[@]+"${timed_out[@]}"}),
  "skipped":         $(_to_json_array ${skipped[@]+"${skipped[@]}"}),
  "failed":          $(_to_json_array ${failed[@]+"${failed[@]}"})
}
JSON

if [[ ${#failed[@]} -gt 0 ]]; then
  exit 1
fi

exit 0
