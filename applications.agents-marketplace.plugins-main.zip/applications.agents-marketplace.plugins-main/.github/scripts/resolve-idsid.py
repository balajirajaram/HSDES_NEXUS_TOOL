#!/usr/bin/env python3
"""
resolve-idsid.py — batch-resolve Intel email addresses to IDSIDs via the AGS LDAP API.

Usage:
    python resolve-idsid.py <ags_cli_dir> email1@intel.com [email2@intel.com ...]

Output:
    One line per input email in the form  "email\tidsid".
    If an email cannot be resolved the idsid column is left empty.

Authentication:
    Same mechanism as the AGS CLI — reads Kerberos ticket or SIMPLE_AUTH / USER /
    PASSWORD environment variables.

Arguments:
    ags_cli_dir   Absolute path to the ags-cli repository checkout (so that
                  its modules can be imported).
"""
import os
import sys

if len(sys.argv) < 2:
    print(f"Usage: {sys.argv[0]} <ags_cli_dir> [email ...]", file=sys.stderr)
    sys.exit(1)

ags_cli_dir = sys.argv[1]
emails = sys.argv[2:]

if not emails:
    sys.exit(0)

sys.path.insert(0, ags_cli_dir)

# token_auth.set_token() inspects sys.argv[1] for telemetry metadata;
# fake a minimal argv so it doesn't raise IndexError when called standalone.
if len(sys.argv) < 3:
    sys.argv = [sys.argv[0], "show", "user"]
_real_argv = sys.argv[:]
sys.argv = [sys.argv[0], "show", "user"]

try:
    import requests
    from token_auth import set_token
    from Helpers.user import UserInfo
    from consts import ldap_api
except ImportError as exc:
    print(f"ERROR: could not import AGS CLI modules from '{ags_cli_dir}': {exc}",
          file=sys.stderr)
    sys.exit(2)

sys.argv = _real_argv


def resolve_email(email: str, headers: dict) -> str:
    """Return the IDSID (sAMAccountName) for an Intel email, or '' on failure."""
    try:
        resp = requests.get(
            ldap_api,
            params={"search": f"(mail={email})", "fields": "sAMAccountName"},
            headers=headers,
            timeout=10,
        )
        resp.raise_for_status()
        data = resp.json()
        # API returns a single JSON object, not a list
        if isinstance(data, dict):
            data = [data]
        if isinstance(data, list) and data:
            attrs = data[0].get("attributes", {})
            sam = attrs.get("sAMAccountName", [])
            if sam:
                return sam[0]
    except Exception as exc:
        print(f"WARN: LDAP lookup failed for {email}: {exc}", file=sys.stderr)
    return ""


try:
    token = UserInfo().token
    headers = set_token(token, cli_api=True)
except Exception as exc:
    print(f"ERROR: AGS authentication failed: {exc}", file=sys.stderr)
    sys.exit(3)

for email in emails:
    idsid = resolve_email(email, headers)
    print(f"{email}\t{idsid}")
