#!/usr/bin/env bash
#
# Validate external-plugins.json files found under plugins/<suborg>/.
#
# This is the single validator used by build, intake, and PR checks.
# Philosophy: reject, never sanitize — invalid data is a hard failure.
#
# Requirements: bash 4+, jq
# Usage:        bash .github/scripts/validate-external-plugins.sh [file ...]
#               If no arguments, discovers all external-plugins.json under plugins/
#
# Exit codes:   0 = valid, 1 = validation errors found
#
set -euo pipefail

REPO_ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
cd "$REPO_ROOT"

errors=0

error() {
  echo "ERROR: $1" >&2
  ((errors++)) || true
}

info() {
  echo "INFO:  $1"
}

# Wrapper: strip \r from jq output (Windows jq.exe emits CRLF via WSL interop)
_jq_bin=$(command -v jq 2>/dev/null || command -v jq.exe 2>/dev/null) || { echo "Error: jq is required but not installed." >&2; exit 1; }
jq() { "$_jq_bin" "$@" | tr -d '\r'; }

# ---------------------------------------------------------------------------
# Collect external-plugins.json files to validate
# ---------------------------------------------------------------------------
if [ $# -gt 0 ]; then
  files=("$@")
else
  mapfile -t files < <(find plugins -name 'external-plugins.json' -type f 2>/dev/null | sort)
fi

if [ ${#files[@]} -eq 0 ]; then
  echo "No external-plugins.json files found."
  exit 0
fi

# ---------------------------------------------------------------------------
# Collect all local plugin names for collision detection
# ---------------------------------------------------------------------------
local_names=()
mapfile -t local_names < <(
  {
    find plugins -not -path '*/.*' -type f -name plugin.json -printf '%h\n'
    find plugins -path '*/.claude-plugin/plugin.json' | sed 's|/\.claude-plugin/plugin\.json$||'
  } | sort -u | while IFS= read -r dir; do
    if [ -f "$dir/.claude-plugin/plugin.json" ]; then
      echo "$dir/.claude-plugin/plugin.json"
    elif [ -f "$dir/plugin.json" ]; then
      echo "$dir/plugin.json"
    fi
  done | xargs -d'\n' jq -r '.name // empty' 2>/dev/null | tr '[:upper:]' '[:lower:]' | tr ' ' '-' | grep -v '^$'
)

# Track all external names across all registry files for cross-file collision detection
all_external_names=()

# ---------------------------------------------------------------------------
# Validate each external-plugins.json
# ---------------------------------------------------------------------------
for file in "${files[@]}"; do
  info "Validating $file"

  # --- JSON syntax ---
  if ! jq empty "$file" 2>/dev/null; then
    error "$file: invalid JSON syntax"
    continue
  fi

  # --- Extract everything from file in a single jq call ---
  file_data=$(jq -c '
    {
      owners_type: (.owners | type),
      owners_count: (if (.owners | type) == "array" then (.owners | length) else 0 end),
      owners: (if (.owners | type) == "array" then .owners else [] end),
      plugins_type: (.plugins | type),
      plugin_count: (if (.plugins | type) == "array" then (.plugins | length) else 0 end),
      plugins: (if (.plugins | type) == "array" then [.plugins[] | {
        name: (.name // ""),
        description: (.description // ""),
        version: (.version // ""),
        owners_type: (.owners | type),
        owners_count: (if (.owners | type) == "array" then (.owners | length) else 0 end),
        owners: (if (.owners | type) == "array" then .owners else [] end),
        repository: (.repository // ""),
        homepage: (.homepage // ""),
        license_type: (.license | type),
        license: (if (.license | type) == "string" then .license else "" end),
        kw_type: (.keywords | type),
        kw_count: (if (.keywords | type) == "array" then (.keywords | length) else 0 end),
        keywords: (if (.keywords | type) == "array" then .keywords else [] end),
        tags_type: (.tags | type),
        tags: (if (.tags | type) == "array" then .tags else [] end),
        src_type: (.source | type),
        src_source: (if (.source | type) == "object" then (.source.source // "") else "" end),
        src_repo: (if (.source | type) == "object" then (.source.repo // "") else "" end),
        src_path: (if (.source | type) == "object" then (.source.path // "") else "" end),
        src_ref: (if (.source | type) == "object" then (.source.ref // "") else "" end),
        src_sha: (if (.source | type) == "object" then (.source.sha // "") else "" end)
      }] else [] end)
    }
  ' "$file")

  # --- Top-level owners ---
  plugin_count=$(printf '%s' "$file_data" | jq -r '.plugin_count')
  owners_type=$(printf '%s' "$file_data" | jq -r '.owners_type')
  if [ "$owners_type" != "array" ]; then
    error "$file: top-level 'owners' must be an array"
  else
    owners_count=$(printf '%s' "$file_data" | jq -r '.owners_count')
    if [ "$owners_count" -lt 2 ] && [ "$plugin_count" -gt 0 ]; then
      error "$file: top-level 'owners' must have at least 2 entries (got $owners_count)"
    fi
    while IFS= read -r owner_email; do
      if [ -z "$owner_email" ]; then
        error "$file: top-level 'owners' contains an empty string"
      elif ! [[ "$owner_email" =~ ^[^@]+@intel\.com$ ]]; then
        error "$file: top-level 'owners' contains invalid email (must be *@intel.com): $owner_email"
      fi
    done < <(printf '%s' "$file_data" | jq -r '.owners[]')
  fi

  # --- plugins array ---
  plugins_type=$(printf '%s' "$file_data" | jq -r '.plugins_type')
  if [ "$plugins_type" != "array" ]; then
    error "$file: 'plugins' must be an array"
    continue
  fi

  plugin_count=$(printf '%s' "$file_data" | jq -r '.plugin_count')
  # Track names within this file for intra-file duplicate detection
  file_names=()

  for ((i = 0; i < plugin_count; i++)); do
    prefix="$file: plugins[$i]"

    # Extract this plugin's pre-computed record (single jq call on in-memory data)
    p_data=$(printf '%s' "$file_data" | jq -c ".plugins[$i]")

    # --- name ---
    name=$(printf '%s' "$p_data" | jq -r '.name')
    if [ -z "$name" ]; then
      error "$prefix: missing required field 'name'"
    elif [ "${#name}" -gt 50 ]; then
      error "$prefix: 'name' exceeds 50 characters"
    elif ! [[ "$name" =~ ^[a-z0-9-]+$ ]]; then
      error "$prefix: 'name' must match /^[a-z0-9-]+$/, got: $name"
    else
      name_lower=$(echo "$name" | tr '[:upper:]' '[:lower:]')

      # Intra-file duplicate check
      for existing in "${file_names[@]+"${file_names[@]}"}"; do
        if [ "$existing" = "$name_lower" ]; then
          error "$prefix: duplicate name '$name' within this file"
          break
        fi
      done

      # Cross-file duplicate check
      for existing in "${all_external_names[@]+"${all_external_names[@]}"}"; do
        if [ "$existing" = "$name_lower" ]; then
          error "$prefix: duplicate name '$name' across external registries"
          break
        fi
      done

      # Local collision check
      for existing in "${local_names[@]+"${local_names[@]}"}"; do
        if [ "$existing" = "$name_lower" ]; then
          error "$prefix: name '$name' collides with a local plugin"
          break
        fi
      done

      file_names+=("$name_lower")
    fi

    # --- description ---
    desc=$(printf '%s' "$p_data" | jq -r '.description')
    if [ -z "$desc" ]; then
      error "$prefix: missing required field 'description'"
    elif [ "${#desc}" -gt 1024 ]; then
      error "$prefix: 'description' exceeds 1024 characters"
    fi

    # --- version ---
    ver=$(printf '%s' "$p_data" | jq -r '.version')
    if [ -z "$ver" ]; then
      error "$prefix: missing required field 'version'"
    elif [ "${#ver}" -gt 100 ]; then
      error "$prefix: 'version' exceeds 100 characters"
    fi

    # --- owners ---
    p_owners_type=$(printf '%s' "$p_data" | jq -r '.owners_type')
    if [ "$p_owners_type" != "array" ]; then
      error "$prefix: 'owners' must be an array"
    else
      p_owners_count=$(printf '%s' "$p_data" | jq -r '.owners_count')
      if [ "$p_owners_count" -lt 2 ]; then
        error "$prefix: 'owners' must have at least 2 entries (got $p_owners_count)"
      fi
      while IFS= read -r email; do
        if [ -z "$email" ]; then
          error "$prefix: 'owners' contains an empty string"
        elif ! [[ "$email" =~ ^[^@]+@intel\.com$ ]]; then
          error "$prefix: 'owners' contains invalid email (must be *@intel.com): $email"
        fi
      done < <(printf '%s' "$p_data" | jq -r '.owners[]')
    fi

    # --- repository (optional) ---
    repo_val=$(printf '%s' "$p_data" | jq -r '.repository')
    if [ -n "$repo_val" ]; then
      if ! [[ "$repo_val" =~ ^https:// ]]; then
        error "$prefix: 'repository' must be a valid HTTPS URL, got: $repo_val"
      fi
    fi

    # --- homepage (optional) ---
    homepage_val=$(printf '%s' "$p_data" | jq -r '.homepage')
    if [ -n "$homepage_val" ]; then
      if ! [[ "$homepage_val" =~ ^https:// ]]; then
        error "$prefix: 'homepage' must be a valid HTTPS URL, got: $homepage_val"
      fi
    fi

    # --- license (optional) ---
    license_type=$(printf '%s' "$p_data" | jq -r '.license_type')
    if [ "$license_type" = "string" ]; then
      license_val=$(printf '%s' "$p_data" | jq -r '.license')
      if [ -z "$license_val" ]; then
        error "$prefix: 'license' must be a non-empty string if present"
      fi
    elif [ "$license_type" != "null" ]; then
      error "$prefix: 'license' must be a string if present"
    fi

    # --- keywords (optional) ---
    kw_type=$(printf '%s' "$p_data" | jq -r '.kw_type')
    if [ "$kw_type" = "array" ]; then
      kw_count=$(printf '%s' "$p_data" | jq -r '.kw_count')
      if [ "$kw_count" -gt 10 ]; then
        error "$prefix: 'keywords' exceeds 10 items (got $kw_count)"
      fi
      while IFS= read -r kw; do
        if [ "${#kw}" -gt 30 ]; then
          error "$prefix: keyword exceeds 30 characters: $kw"
        elif ! [[ "$kw" =~ ^[a-z0-9-]+$ ]]; then
          error "$prefix: keyword must match /^[a-z0-9-]+$/, got: $kw"
        fi
      done < <(printf '%s' "$p_data" | jq -r '.keywords[]')
    elif [ "$kw_type" != "null" ]; then
      error "$prefix: 'keywords' must be an array if present"
    fi

    # --- tags (optional) ---
    tags_type=$(printf '%s' "$p_data" | jq -r '.tags_type')
    if [ "$tags_type" = "array" ]; then
      while IFS= read -r tag; do
        if [ -z "$tag" ]; then
          error "$prefix: 'tags' contains an empty string"
        fi
      done < <(printf '%s' "$p_data" | jq -r '.tags[]')
    elif [ "$tags_type" != "null" ]; then
      error "$prefix: 'tags' must be an array if present"
    fi

    # --- source (required object) ---
    src_type=$(printf '%s' "$p_data" | jq -r '.src_type')
    if [ "$src_type" != "object" ]; then
      error "$prefix: 'source' must be an object"
    else
      src_source=$(printf '%s' "$p_data" | jq -r '.src_source')
      if [ -z "$src_source" ]; then
        error "$prefix: 'source.source' is required"
      elif [ "$src_source" != "github" ]; then
        error "$prefix: 'source.source' must be an allowed type (e.g. \"github\"), got: $src_source"
      fi

      src_repo=$(printf '%s' "$p_data" | jq -r '.src_repo')
      if [ -z "$src_repo" ]; then
        error "$prefix: 'source.repo' is required"
      elif ! [[ "$src_repo" =~ ^[A-Za-z0-9_.\-]+\/[A-Za-z0-9_.\-]+$ ]]; then
        error "$prefix: 'source.repo' must be in 'owner/repo' format, got: $src_repo"
      fi

      src_path=$(printf '%s' "$p_data" | jq -r '.src_path')
      if [ -n "$src_path" ]; then
        if [[ "$src_path" == *".."* ]]; then
          error "$prefix: 'source.path' must not contain '..' segments"
        fi
        if [[ "$src_path" == *"\\"* ]]; then
          error "$prefix: 'source.path' must use forward slashes, not backslashes"
        fi
        if [[ "$src_path" =~ plugin\.json$ ]]; then
          error "$prefix: 'source.path' must be the parent directory, not the manifest file itself"
        fi
        if [ "$src_path" = "." ]; then
          error "$prefix: 'source.path' must not be '.', use '/' for repo root"
        fi
      fi

      src_ref=$(printf '%s' "$p_data" | jq -r '.src_ref')
      if [ -n "$src_ref" ] && [ "$src_ref" = "" ]; then
        error "$prefix: 'source.ref' must be non-empty if present"
      fi

      src_sha=$(printf '%s' "$p_data" | jq -r '.src_sha')
      if [ -n "$src_sha" ]; then
        if ! [[ "$src_sha" =~ ^[0-9a-f]{40}$ ]]; then
          error "$prefix: 'source.sha' must be a 40-character lowercase hex string, got: $src_sha"
        fi
      fi
    fi
  done

  # Add this file's names to the global list for cross-file detection
  all_external_names+=("${file_names[@]+"${file_names[@]}"}")
done

# ---------------------------------------------------------------------------
# Summary
# ---------------------------------------------------------------------------
if [ "$errors" -gt 0 ]; then
  echo ""
  echo "Validation FAILED with $errors error(s)."
  exit 1
fi

echo "All external-plugins.json files are valid."
exit 0
