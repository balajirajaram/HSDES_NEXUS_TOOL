#!/usr/bin/env bash
#
# Validate plugin.json structure and plugin folder conventions.
#
# Requirements: bash 4+, jq
# Usage:        bash .github/scripts/validate-plugins.sh [plugin_dir ...]
#               If no arguments, validates all plugins under plugins/
#
set -euo pipefail

REPO_ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
cd "$REPO_ROOT"

errors=0
warnings=0

error() {
  echo "ERROR: $1" >&2
  ((errors++)) || true
}

warn() {
  echo "WARN:  $1" >&2
  ((warnings++)) || true
}

info() {
  echo "INFO:  $1"
}

# ---------------------------------------------------------------------------
# Collect plugin directories to validate
# ---------------------------------------------------------------------------
if [ $# -gt 0 ]; then
  plugin_dirs=("$@")
else
  mapfile -t plugin_dirs < <(
    {
      find plugins -not -path '*/.*' -type f -name plugin.json | while IFS= read -r f; do dirname "$f"; done
      find plugins -path '*/.claude-plugin/plugin.json' | while IFS= read -r f; do dirname "$(dirname "$f")"; done
    } | sort -u
  )
fi

if [ ${#plugin_dirs[@]} -eq 0 ]; then
  echo "No plugins found to validate."
  exit 0
fi

# ---------------------------------------------------------------------------
# Build a global name → directory map from ALL plugins (not just the ones
# being validated).  This lets us catch duplicates even when CI passes only
# changed directories.
# ---------------------------------------------------------------------------
declare -A all_plugin_names  # name_lower → dir
mapfile -t _all_plugin_jsons < <(
  {
    find plugins -not -path '*/.*' -type f -name plugin.json 2>/dev/null
    find plugins -path '*/.claude-plugin/plugin.json' 2>/dev/null
  } | sort -u
)
for _pj in "${_all_plugin_jsons[@]}"; do
  _n=$(jq -r '.name // empty' "$_pj" 2>/dev/null) || true
  if [ -n "$_n" ]; then
    _nl=$(echo "$_n" | tr '[:upper:]' '[:lower:]')
    _d=$(dirname "$_pj")
    # For .claude-plugin layout, go up one more level
    if [[ "$_d" == */.claude-plugin ]]; then
      _d=$(dirname "$_d")
    fi
    if [ -n "${all_plugin_names[$_nl]+_}" ]; then
      # Two plugins already exist on disk with the same name — record both;
      # the per-plugin loop below will report the error for each.
      all_plugin_names[$_nl]="${all_plugin_names[$_nl]}|$_d"
    else
      all_plugin_names[$_nl]="$_d"
    fi
  fi
done

# ---------------------------------------------------------------------------
# Required fields in plugin.json
# ---------------------------------------------------------------------------
REQUIRED_FIELDS=("name" "description" "version")

# ---------------------------------------------------------------------------
# Validate each plugin
# ---------------------------------------------------------------------------
for dir in "${plugin_dirs[@]}"; do
  # Locate plugin.json
  if [ -f "$dir/.claude-plugin/plugin.json" ]; then
    pjson="$dir/.claude-plugin/plugin.json"
  elif [ -f "$dir/plugin.json" ]; then
    pjson="$dir/plugin.json"
  else
    error "$dir: no plugin.json found"
    continue
  fi

  # Resolve referenced paths relative to where plugin.json lives
  resolve_base=$(dirname "$pjson")

  info "Validating $dir"

  # --- JSON syntax ---
  if ! jq empty "$pjson" 2>/dev/null; then
    error "$pjson: invalid JSON syntax"
    continue
  fi

  # --- Required fields ---
  for field in "${REQUIRED_FIELDS[@]}"; do
    val=$(jq -r --arg f "$field" '.[$f] // empty' "$pjson")
    if [ -z "$val" ]; then
      error "$pjson: missing required field '$field'"
    fi
  done

  # --- Field type checks ---
  name=$(jq -r '.name // empty' "$pjson")
  if [ -n "$name" ]; then
    # Name must be kebab-case: lowercase letters, numbers, and hyphens only
    if ! [[ "$name" =~ ^[a-z0-9]([a-z0-9-]*[a-z0-9])?$ ]]; then
      error "$pjson: 'name' must be kebab-case (lowercase letters, numbers, and hyphens only), got: $name"
    fi

    # --- Duplicate name check (across ALL plugins on disk) ---
    name_lower=$(echo "$name" | tr '[:upper:]' '[:lower:]')
    if [ -n "${all_plugin_names[$name_lower]+_}" ]; then
      owners="${all_plugin_names[$name_lower]}"
      # If the map value contains "|", multiple dirs share this name
      if [[ "$owners" == *"|"* ]]; then
        other_dirs=$(echo "$owners" | tr '|' '\n' | grep -v "^${dir}$" | paste -sd ', ')
        if [ -n "$other_dirs" ]; then
          error "$pjson: duplicate plugin name '$name' — also used by: $other_dirs"
        fi
      fi
    fi
  fi

  version=$(jq -r '.version // empty' "$pjson")
  if [ -n "$version" ]; then
    # Basic semver check (x.y.z with optional pre-release)
    if ! [[ "$version" =~ ^[0-9]+\.[0-9]+\.[0-9]+(-[a-zA-Z0-9.]+)?$ ]]; then
      error "$pjson: 'version' is not valid semver: $version"
    fi
  fi

  description=$(jq -r '.description // empty' "$pjson")
  if [ -n "$description" ]; then
    desc_len=${#description}
    if [ "$desc_len" -gt 1024 ]; then
      error "$pjson: 'description' exceeds 1024 characters (got $desc_len)"
    fi
  fi

  keywords_type=$(jq -r '.keywords | type' "$pjson" 2>/dev/null)
  if [ "$keywords_type" != "null" ] && [ "$keywords_type" != "array" ]; then
    error "$pjson: 'keywords' must be an array"
  fi

  tags_type=$(jq -r '.tags | type' "$pjson" 2>/dev/null)
  if [ "$tags_type" != "null" ] && [ "$tags_type" != "array" ]; then
    error "$pjson: 'tags' must be an array"
  fi

  # --- Source field validation (if present) ---
  SOURCE_SCHEMA_EXAMPLE='Expected: "source": { "source": "github", "repo": "microsoft/skills-for-fabric", "path": "plugins/fabric-authoring" }'
  source_type=$(jq -r '.source | type' "$pjson" 2>/dev/null)
  if [ "$source_type" = "object" ]; then
    # Validate source.source
    source_source=$(jq -r '.source.source // empty' "$pjson")
    if [ -z "$source_source" ]; then
      error "$pjson: 'source' object missing required 'source' field. $SOURCE_SCHEMA_EXAMPLE"
    elif [ "$source_source" != "github" ]; then
      error "$pjson: 'source.source' must be \"github\", got: $source_source. $SOURCE_SCHEMA_EXAMPLE"
    fi

    # Validate source.repo (must be "owner/repo" format)
    source_repo=$(jq -r '.source.repo // empty' "$pjson")
    if [ -z "$source_repo" ]; then
      error "$pjson: 'source' object missing required 'repo' field. $SOURCE_SCHEMA_EXAMPLE"
    elif [[ "$source_repo" =~ ^https?:// ]] || [[ "$source_repo" =~ ^git@ ]]; then
      error "$pjson: 'source.repo' must be 'owner/repo' (not a full URL), got: $source_repo. $SOURCE_SCHEMA_EXAMPLE"
    elif ! [[ "$source_repo" =~ ^[a-zA-Z0-9._-]+/[a-zA-Z0-9._-]+$ ]]; then
      error "$pjson: 'source.repo' must be in 'owner/repo' format, got: $source_repo. $SOURCE_SCHEMA_EXAMPLE"
    fi

    # Validate source.path
    source_path=$(jq -r '.source.path // empty' "$pjson")
    if [ -z "$source_path" ]; then
      error "$pjson: 'source' object missing required 'path' field. $SOURCE_SCHEMA_EXAMPLE"
    fi
  elif [ "$source_type" != "null" ]; then
    error "$pjson: 'source' must be an object, got type: $source_type. $SOURCE_SCHEMA_EXAMPLE"
  fi

  # --- Folder structure checks ---
  # Check that referenced paths exist and have valid internal structure
  agents_type=$(jq -r '.agents | type' "$pjson" 2>/dev/null)
  if [ "$agents_type" = "string" ]; then
    agents_path=$(jq -r '.agents' "$pjson")
    resolved="$resolve_base/$agents_path"
    if [ ! -d "$resolved" ] && [ ! -f "$resolved" ]; then
      error "$pjson: 'agents' path does not exist: $agents_path"
    elif [ -d "$resolved" ]; then
      # Each agent file should be *.agent.md
      agent_files=$(find "$resolved" -maxdepth 1 -type f -name '*.md' 2>/dev/null)
      if [ -z "$agent_files" ]; then
        warn "$dir: agents/ directory has no .md files"
      else
        while IFS= read -r af; do
          af_base=$(basename "$af")
          if [[ ! "$af_base" =~ \.agent\.md$ ]]; then
            warn "$dir: agent file '$af_base' should follow naming convention <name>.agent.md"
          fi
        done <<< "$agent_files"
      fi
    fi
  elif [ "$agents_type" = "array" ]; then
    while IFS= read -r agent_file; do
      resolved="$resolve_base/$agent_file"
      if [ ! -f "$resolved" ]; then
        error "$pjson: 'agents' entry does not exist: $agent_file"
      else
        af_base=$(basename "$agent_file")
        if [[ ! "$af_base" =~ \.agent\.md$ ]]; then
          warn "$dir: agent file '$af_base' should follow naming convention <name>.agent.md"
        fi
      fi
    done < <(jq -r '.agents[]' "$pjson")
  fi

  skills_type=$(jq -r '.skills | type' "$pjson" 2>/dev/null)
  if [ "$skills_type" = "string" ]; then
    skills_path=$(jq -r '.skills' "$pjson")
    resolved="$resolve_base/$skills_path"
    if [ ! -d "$resolved" ] && [ ! -f "$resolved" ]; then
      error "$pjson: 'skills' path does not exist: $skills_path"
    elif [ -d "$resolved" ]; then
      # Every directory containing no subdirectories (leaf) must have a SKILL.md
      # SKILL.md can sit at any depth under skills/
      skill_leaf_dirs=$(find "$resolved" -mindepth 1 -type d 2>/dev/null | while IFS= read -r d; do
        if [ -z "$(find "$d" -mindepth 1 -maxdepth 1 -type d 2>/dev/null)" ]; then
          echo "$d"
        fi
      done)
      if [ -z "$skill_leaf_dirs" ]; then
        warn "$dir: skills/ directory has no skill subdirectories"
      else
        while IFS= read -r sd; do
          # Skip utility directories (shared, test, etc.) — not actual skills
          sd_basename=$(basename "$sd")
          if [[ "$sd_basename" == *shared* ]] || [[ "$sd_basename" == *test* ]]; then
            continue
          fi
          # Search for SKILL.md at this level or any ancestor up to the skills root
          found_skill_md=false
          check_dir="$sd"
          while [ "$check_dir" != "$resolved" ] && [ "$check_dir" != "$(dirname "$check_dir")" ]; do
            if [ -f "$check_dir/SKILL.md" ]; then
              found_skill_md=true
              break
            fi
            check_dir=$(dirname "$check_dir")
          done
          if [ "$found_skill_md" = false ]; then
            error "$dir: skill '$(basename "$sd")' is missing SKILL.md"
          fi
        done <<< "$skill_leaf_dirs"
      fi
    fi
  elif [ "$skills_type" = "array" ]; then
    while IFS= read -r skill_file; do
      resolved="$resolve_base/$skill_file"
      if [ ! -f "$resolved" ] && [ ! -d "$resolved" ]; then
        error "$pjson: 'skills' entry does not exist: $skill_file"
      fi
    done < <(jq -r '.skills[]' "$pjson")
  fi

  mcp_path=$(jq -r '.mcpServers // empty' "$pjson")
  if [ -n "$mcp_path" ]; then
    resolved="$resolve_base/$mcp_path"
    if [ ! -f "$resolved" ]; then
      error "$pjson: 'mcpServers' path does not exist: $mcp_path"
    fi
  fi

  # --- Plugin directory naming convention ---
  dirname_base=$(basename "$dir")
  if [[ "$dirname_base" =~ [[:upper:]] ]]; then
    warn "$dir: folder name contains uppercase characters — prefer lowercase with hyphens"
  fi

  # --- README check ---
  if [ ! -f "$dir/README.md" ]; then
    warn "$dir: missing README.md"
  fi

  # --- Path depth check (plugins/<org>/<group>/<plugin-name>) ---
  depth=$(echo "$dir" | tr '/' '\n' | wc -l)
  if [ "$depth" -lt 4 ]; then
    warn "$dir: expected path depth plugins/<org>/<group>/<name> (depth=$depth)"
  fi

  # --- Plugin must provide content: skills/, agents/, prompts/, mcpServers, or external source ---
  has_content=false

  # Check for skills/agents/prompts directories (from plugin.json or on disk)
  for content_dir in skills agents prompts; do
    ref_path=$(jq -r --arg d "$content_dir" '.[$d] // empty' "$pjson")
    if [ -n "$ref_path" ]; then
      has_content=true
      break
    fi
    if [ -d "$dir/$content_dir" ]; then
      has_content=true
      break
    fi
  done

  # Check for mcpServers reference
  if [ "$has_content" = false ]; then
    mcp_ref=$(jq -r '.mcpServers // empty' "$pjson")
    if [ -n "$mcp_ref" ]; then
      has_content=true
    fi
  fi

  # Check for external source (repo pointing outside this repo)
  if [ "$has_content" = false ]; then
    if [ "$source_type" = "object" ]; then
      source_repo=$(jq -r '.source.repo // empty' "$pjson")
      if [ -n "$source_repo" ] && [[ ! "$source_repo" =~ ^intel-innersource/applications\.agents-marketplace\.plugins$ ]]; then
        has_content=true
      fi
    fi
  fi

  if [ "$has_content" = false ]; then
    error "$dir: plugin must provide at least one of: skills/, agents/, prompts/, mcpServers, or an external source"
  fi

done

# ---------------------------------------------------------------------------
# Summary
# ---------------------------------------------------------------------------
echo ""
echo "=== Validation Summary ==="
echo "Plugins checked: ${#plugin_dirs[@]}"
echo "Errors:          $errors"
echo "Warnings:        $warnings"

if [ "$errors" -gt 0 ]; then
  echo ""
  echo "FAILED: $errors error(s) found."
  exit 1
fi

echo ""
echo "PASSED: all plugins valid."
exit 0
