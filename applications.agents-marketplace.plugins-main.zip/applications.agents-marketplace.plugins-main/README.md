# Agent Plugin Marketplace

A general marketplace of plugins, agents, and MCP servers — organized by organization and team — for use with AI coding agent clients.


---

## Overview

This marketplace is a collection of **agent plugins** — each plugin bundles AI agent definitions, reusable skills, and optional MCP server configuration. Install a plugin in your preferred AI coding agent client (VS Code Copilot, Cursor, Claude Code) to unlock domain-specific workflows without writing custom prompts.

Plugins are organized hierarchically under `plugins/<org>/<group>/<plugin>` so that multiple organizations and teams can contribute and maintain their own plugins.

```
agent-plugin-marketplace/
├── plugins/
│   └── dcg/
│       ├── admabe/
│       │   ├── formal-verification-plugin/        # Debug pipelined DPV/FV proofs (Hector, JasperGold)
│       │   └── shell-improvements-plugin/         # Agent terminal best practices (tcsh/bash, UTF-8, EDA logs)
│       ├── datacenterai/                         # AI Solutions & Customer Engineering
│       │   ├── intel-ai-dev/                      # Agent-assisted AI Solutions development — Intel standards, contracts, compliance from problem statement till production delivery
│       │   └── zephyr-test-plugin/                # Manage Zephyr Scale test cases end-to-end: fetch, update results, create cycles, execute on a live UI via Playwright MCP
│       ├── dcee/
│       │   ├── hsdes-plugin/                      # Query Intel HSDes bug tracking system via EQL
│       │   └── lava-plugin/                       # Query Intel LAVA API for CPU specs by QDF/SSPEC
│       ├── pse/
│       │   ├── geni-plugin/          # Query Intel internal knowledge bases via Geni MCP server
│       │   ├── iconsole-plugin/      # Query iConsole inventory, configurations, and logs
│       │   ├── vdc-plugin/           # Manage Intel Virtual Data Center resources via VDC CLI MCP server
│       │   └── trust-mcp-server/     # Expose TRUST (Rapid Unit Selection Tool) selected features via MCP
│       └── xne/
│           ├── development-svatb-plugin/       # SVATB and Jasper formal development workflow
│           ├── development-verilog-plugin/     # Staged Verilog RTL development workflow
│           ├── hygiene-documentation-source-plugin/ # Documentation hygiene workflow and conformance prompts
│           ├── hygiene-session-summary-plugin/ # End-of-session summary and handoff prompt workflow
│           ├── hygiene-verilog-source-plugin/  # Verilog source hygiene audit and remediation workflow
│           ├── orchestrator-verilog-plugin/    # Top-level orchestration agent for gated workflow sequencing
│           ├── policer-input-collateral-plugin/   # Input/collateral quality gate before downstream generation
│           └── util-session-setup-plugin/      # One-time autonomous session bootstrap and persistent preference setup
│       │   ├── geni-plugin/                       # Query Intel internal knowledge bases via Geni MCP server
│       │   ├── trust-mcp-server/                  # Expose TRUST (Rapid Unit Selection Tool) features via MCP
│       │   └── vdc-plugin/                        # Manage Intel Virtual Data Center resources via VDC CLI MCP server
│       ├── sai/
│       │   └── linux-kernel-oops/                 # Expert x86 Linux kernel crash/oops analyser
│       ├── xne/
│       │   └── policer-input-collateral-plugin/   # Input/collateral quality gate before downstream generation
│       └── xve/
│           ├── dmr-bios-expert/                   # Diamond Rapids (DMR) BIOS firmware knowledge base
│           ├── dmr-s3m-expert/                    # Diamond Rapids (DMR) S3M firmware knowledge base
│           └── redfish-mcp/                       # Manage Dell iDRAC9 servers via Redfish API
└── .github/
    ├── CODEOWNERS                                 # Plugin & repo ownership for PR review routing
    └── plugin/
        └── marketplace.json                       # Plugin registry
```

---

## Plugins

| Plugin                       | Description                                                                 | Category        |
| ---------------------------- | --------------------------------------------------------------------------- | --------------- |
| [`geni-plugin`](#geni-plugin)           | Query Intel internal knowledge bases (Axon, HSD) via the Geni MCP server    | Developer Tools |
| [`vdc-plugin`](#vdc-plugin)             | Manage Intel Virtual Data Center resources via the local VDC CLI MCP server | Developer Tools |
| [`trust-mcp-server`](#trust-mcp-server) | Expose TRUST (Rapid Unit Selection Tool) selected features via MCP           | Developer Tools |
| [`development-svatb-plugin`](#development-svatb-plugin) | SVATB and Jasper formal development workflow with agent, skill, and prompts | Developer Tools |
| [`development-verilog-plugin`](#development-verilog-plugin) | Staged Verilog RTL development workflow with agents, skill, and prompts | Developer Tools |
| [`hygiene-documentation-source-plugin`](#hygiene-documentation-source-plugin) | Documentation hygiene workflow with agent, skill, and conformance prompts | Developer Tools |
| [`hygiene-session-summary-plugin`](#hygiene-session-summary-plugin) | Session-summary workflow packaging the handoff prompt and skill wrapper | Developer Tools |
| [`hygiene-verilog-source-plugin`](#hygiene-verilog-source-plugin) | Verilog hygiene audit workflow with agent, skill, and remediation prompt | Developer Tools |
| [`orchestrator-verilog-plugin`](#orchestrator-verilog-plugin) | Top-level orchestration agent for deterministic stage sequencing | Developer Tools |
| [`policer-input-collateral-plugin`](#policer-input-collateral-plugin) | Quality policer for human input language and human-authored collateral before generation | Developer Tools |
| [`util-session-setup-plugin`](#util-session-setup-plugin) | Session bootstrap workflow packaging the persistent autonomous setup prompt and skill wrapper | Developer Tools |
| Plugin                              | Group        | Description                                                                                                  |
| ----------------------------------- | ------------ | ------------------------------------------------------------------------------------------------------------ |
| `formal-verification-plugin`        | dcg/admabe   | Debug pipelined DPV/FV proofs: CONFLICT diagnosis, CEX interference, constraint phases (Hector, JasperGold). |
| `shell-improvements-plugin`         | dcg/admabe   | Agent terminal best practices: hangs/truncation, UTF-8 patching, non-recursive make, tcsh/bash, EDA logs.    |
| `intel-ai-dev`               | dcg/datacenterai | Agent-assisted AI Solutions development — Intel standards, contracts, and compliance from problem statement till production delivery. Pluggable with Enterprise Inference, ERAG, and more. |
| `zephyr-test-plugin`         | dcg/datacenterai | Manage Zephyr Scale test cases end-to-end: fetch from a folder, write ACTUAL_RESULT into new versions, create test cycles with version + RC metadata, and execute on a live UI via Playwright MCP. Bundles a senior-QA reviewer agent. |
| `hsdes-plugin`                      | dcg/dcee     | Query Intel HSDes bug tracking system using EQL.                                                             |
| `lava-plugin`                       | dcg/dcee     | Query Intel LAVA (Line item AVailability for All) API for CPU specs by QDF/SSPEC or product name.            |
| `astro-rocket-plugin`               | dcg/pse      | Rocket CLI config generation, review, validation, and debug via the astro MCP server (SSH stdio to SUT).     |
| `geni-plugin`                       | dcg/pse      | Query Intel internal knowledge bases (Axon, HSD) via the Geni MCP server.                                    |
| `iconsole-plugin`                   | dcg/pse      | Query iConsole inventory, configurations, and logs via the iConsole MCP server.                              |
| `io-prq-methodology-plugin`         | dcg/pse      | I/O PRQ Methodology Expert agent — queries Intel's I/O PRQ Methodology Index wiki page for EV engineers.     |
| `trust-mcp-server`                  | dcg/pse      | Expose TRUST (Rapid Unit Selection Tool) selected features via MCP.                                          |
| `vdc-plugin`                        | dcg/pse      | Manage Intel Virtual Data Center resources via the local VDC CLI MCP server.                                 |
| `linux-kernel-oops`                 | dcg/sai      | Expert x86 Linux kernel crash/oops analyser for triage and root-cause analysis.                              |
| `policer-input-collateral-plugin`   | dcg/xne      | Quality policer for human input language and human-authored collateral before RTL/doc generation.            |
| `util-session-setup-plugin`         | dcg/xne      | One-time session bootstrap for autonomous defaults, verbose markers, and persistent response footer policy. |
| `dmr-bios-expert`                   | dcg/xve      | Diamond Rapids (DMR) BIOS firmware knowledge base — boot flow, FSP, memory training, RAS, PCIe/CXL.          |
| `dmr-s3m-expert`                    | dcg/xve      | Diamond Rapids (DMR) S3M firmware knowledge base — FMC, RT, VPM, security, DFx debug, CI validation.         |
| `redfish-mcp`                       | dcg/xve      | MCP server for managing Dell iDRAC9 servers via Redfish — power, BIOS, firmware, sensors, logs, virtual media. |

See [`.github/plugin/marketplace.json`](.github/plugin/marketplace.json) for the canonical registry (versions, owners, keywords).

---

## GitHub Pages

This repository now includes a GitHub Pages site under `docs/`.

- Workflow: `.github/workflows/deploy-github-pages.yml`
- Published content: `docs/`
- Marketplace data source: `.github/plugin/marketplace.json` (copied into the site artifact as `marketplace.json` during deployment)

The Pages deployment runs on pushes to `main` when docs or marketplace registry content changes, and can also be run manually via workflow dispatch.

---
