const statusEl = document.getElementById("status");
const metaEl = document.getElementById("meta");
const searchEl = document.getElementById("search");
const gridEl = document.getElementById("grid");
const marketplaceShellEl = document.getElementById("marketplace-shell");
const pluginDetailEl = document.getElementById("plugin-detail");
const cardTemplate = document.getElementById("card-template");
const detailNameEl = document.getElementById("detail-name");
const detailVersionEl = document.getElementById("detail-version");
const detailDescriptionEl = document.getElementById("detail-description");
const detailSourceEl = document.getElementById("detail-source");
const detailOwnersEl = document.getElementById("detail-owners");
const detailTeamEl = document.getElementById("detail-team");
const detailInstallUriEl = document.getElementById("detail-install-uri");
const detailChipsEl = document.getElementById("detail-chips");
const detailInstallBtn = document.getElementById("detail-install");
const detailGithubLink = document.getElementById("detail-github");
const detailEntitySummaryEl = document.getElementById("detail-entity-summary");
const detailMcpListEl = document.getElementById("detail-mcp-list");
const detailSkillsListEl = document.getElementById("detail-skills-list");
const detailAgentsListEl = document.getElementById("detail-agents-list");
const detailPromptsListEl = document.getElementById("detail-prompts-list");
const detailGroupMcpEl = document.getElementById("detail-group-mcp");
const detailGroupSkillsEl = document.getElementById("detail-group-skills");
const detailGroupAgentsEl = document.getElementById("detail-group-agents");
const detailGroupPromptsEl = document.getElementById("detail-group-prompts");
const globalEntitySummaryEl = document.getElementById("global-entity-summary");

let allPlugins = [];
let selectedPluginName = "";
let entityInventory = {};

const REPO_SLUG = "intel-innersource/applications.agents-marketplace.plugins";
const REPO_TREE_ROOT = "https://github.com/intel-innersource/applications.agents-marketplace.plugins/tree/main";

function getInstallUri(pluginName) {
  return `vscode://chat-plugin/install?source=${REPO_SLUG}&plugin=${encodeURIComponent(pluginName)}`;
}

function sourceText(source) {
  if (typeof source === "string") {
    return source;
  }

  if (!source || typeof source !== "object") {
    return "unknown";
  }

  const parts = [];
  if (source.source) {
    parts.push(source.source);
  }
  if (source.url) {
    parts.push(source.url);
  }
  if (source.path) {
    parts.push(source.path);
  }

  return parts.join(" | ") || "unknown";
}

function githubUrl(source) {
  if (typeof source === "string") {
    const clean = source.replace(/^\.\//, "");
    return `${REPO_TREE_ROOT}/${clean}`;
  }

  if (source && typeof source === "object") {
    if (source.url && source.path) {
      return `${source.url}/tree/main/${source.path}`;
    }
    if (source.url) {
      return source.url;
    }
  }

  return "https://github.com/intel-innersource/applications.agents-marketplace.plugins";
}

function getOrgTeam(source) {
  if (typeof source !== "string") {
    return "external-source";
  }

  const parts = source.replace(/^\.\//, "").split("/");
  if (parts.length >= 4 && parts[0] === "plugins") {
    return `${parts[1]}/${parts[2]}`;
  }
  return "unknown";
}

function stringifySource(source) {
  return sourceText(source);
}

function pluginMatches(plugin, query) {
  if (!query) {
    return true;
  }

  const entities = getEntityInfo(plugin.name);
  const entityText = [
    ...entities.mcp.map((item) => item.name),
    ...entities.skills.map((item) => item.name),
    ...entities.agents.map((item) => item.name),
    ...entities.prompts.map((item) => item.name),
  ].join(" ");

  const haystack = [
    plugin.name,
    plugin.description,
    stringifySource(plugin.source),
    entityText,
    ...(plugin.owners || []),
    ...(plugin.keywords || []),
    ...(plugin.tags || []),
  ]
    .join(" ")
    .toLowerCase();

  return haystack.includes(query.toLowerCase());
}

function render(plugins) {
  const q = searchEl.value.trim();
  const visible = plugins.filter((plugin) => pluginMatches(plugin, q));
  gridEl.innerHTML = "";

  document.querySelectorAll(".card.card-selected").forEach((el) => el.classList.remove("card-selected"));

  if (!visible.length) {
    statusEl.textContent = "No plugins match your filter.";
    selectedPluginName = "";
    setDetails(null);
    return;
  }

  statusEl.textContent = `Showing ${visible.length} of ${plugins.length} plugins.`;

  for (const plugin of visible) {
    const clone = cardTemplate.content.cloneNode(true);
    const card = clone.querySelector(".card");
    const cardInstallBtn = clone.querySelector(".card-install");
    const cardDetailsBtn = clone.querySelector(".card-details");
    const statsEl = clone.querySelector(".entity-stats");

    clone.querySelector(".plugin-name").textContent = plugin.name || "Unnamed plugin";
    clone.querySelector(".plugin-version").textContent = plugin.version || "n/a";
    clone.querySelector(".plugin-description").textContent = plugin.description || "No description provided.";
    clone.querySelector(".plugin-source").textContent = `source: ${sourceText(plugin.source)}`;
    clone.querySelector(".plugin-owners").textContent = `owners: ${(plugin.owners || []).join(", ") || "n/a"}`;

    const chips = clone.querySelector(".chips");
    for (const keyword of (plugin.keywords || []).slice(0, 8)) {
      const chip = document.createElement("span");
      chip.textContent = keyword;
      chips.appendChild(chip);
    }

    const counts = getEntityCounts(plugin.name);
    const pills = [
      ["MCP", counts.mcp],
      ["Skills", counts.skills],
      ["Agents", counts.agents],
      ["Prompts", counts.prompts],
    ];
    for (const [label, value] of pills) {
      if (value <= 0) {
        continue;
      }
      const pill = document.createElement("span");
      pill.className = "entity-pill";
      pill.textContent = `${label}: ${value}`;
      statsEl.appendChild(pill);
    }

    const selectPlugin = () => {
      selectedPluginName = plugin.name || "";
      setDetails(plugin);
      document.querySelectorAll(".card.card-selected").forEach((el) => el.classList.remove("card-selected"));
      card.classList.add("card-selected");
    };

    card.addEventListener("click", selectPlugin);
    card.addEventListener("keydown", (event) => {
      if (event.key === "Enter" || event.key === " ") {
        event.preventDefault();
        selectPlugin();
      }
    });

    cardInstallBtn.addEventListener("click", (event) => {
      event.stopPropagation();
      window.location.href = getInstallUri(plugin.name || "");
    });

    cardDetailsBtn.addEventListener("click", (event) => {
      event.stopPropagation();
      selectPlugin();
    });

    gridEl.appendChild(clone);
  }

  if (selectedPluginName) {
    const selectedPlugin = visible.find((plugin) => plugin.name === selectedPluginName);
    if (selectedPlugin) {
      setDetails(selectedPlugin);
      const selectedCard = Array.from(gridEl.querySelectorAll(".card")).find(
        (el) => el.querySelector(".plugin-name")?.textContent === selectedPluginName,
      );
      if (selectedCard) {
        selectedCard.classList.add("card-selected");
      }
      return;
    }
  }

  selectedPluginName = "";
  setDetails(null);
}

function setDetails(plugin) {
  if (!plugin) {
    pluginDetailEl.classList.add("plugin-detail-hidden");
    marketplaceShellEl.classList.remove("marketplace-shell-open");
    detailNameEl.textContent = "No plugin selected";
    detailVersionEl.textContent = "";
    detailDescriptionEl.textContent = "Choose a plugin card to view details.";
    detailSourceEl.textContent = "-";
    detailOwnersEl.textContent = "-";
    detailTeamEl.textContent = "-";
    detailInstallUriEl.textContent = "-";
    detailEntitySummaryEl.innerHTML = "";
    clearEntityLists();
    setEntityGroupVisibility(detailGroupMcpEl, false);
    setEntityGroupVisibility(detailGroupSkillsEl, false);
    setEntityGroupVisibility(detailGroupAgentsEl, false);
    setEntityGroupVisibility(detailGroupPromptsEl, false);
    detailChipsEl.innerHTML = "";
    detailInstallBtn.disabled = true;
    detailGithubLink.href = "#";
    return;
  }

  pluginDetailEl.classList.remove("plugin-detail-hidden");
  marketplaceShellEl.classList.add("marketplace-shell-open");

  detailNameEl.textContent = plugin.name || "Unnamed plugin";
  detailVersionEl.textContent = `v${plugin.version || "n/a"}`;
  detailDescriptionEl.textContent = plugin.description || "No description provided.";
  detailSourceEl.textContent = sourceText(plugin.source);
  detailOwnersEl.textContent = (plugin.owners || []).join(", ") || "n/a";
  detailTeamEl.textContent = getOrgTeam(plugin.source);

  const uri = getInstallUri(plugin.name || "");
  detailInstallUriEl.textContent = uri;
  detailInstallBtn.disabled = false;
  detailInstallBtn.onclick = () => {
    window.location.href = uri;
  };

  detailGithubLink.href = githubUrl(plugin.source);

  const entities = getEntityInfo(plugin.name);
  const counts = getEntityCounts(plugin.name);

  detailEntitySummaryEl.innerHTML = "";
  for (const [label, value] of [["MCP", counts.mcp], ["Skills", counts.skills], ["Agents", counts.agents], ["Prompts", counts.prompts]]) {
    if (value <= 0) {
      continue;
    }
    const chip = document.createElement("span");
    chip.className = "entity-pill";
    chip.textContent = `${label}: ${value}`;
    detailEntitySummaryEl.appendChild(chip);
  }

  renderEntityList(detailMcpListEl, entities.mcp);
  renderEntityList(detailSkillsListEl, entities.skills);
  renderEntityList(detailAgentsListEl, entities.agents);
  renderEntityList(detailPromptsListEl, entities.prompts);

  setEntityGroupVisibility(detailGroupMcpEl, entities.mcp.length > 0);
  setEntityGroupVisibility(detailGroupSkillsEl, entities.skills.length > 0);
  setEntityGroupVisibility(detailGroupAgentsEl, entities.agents.length > 0);
  setEntityGroupVisibility(detailGroupPromptsEl, entities.prompts.length > 0);

  detailChipsEl.innerHTML = "";
  for (const keyword of (plugin.keywords || []).slice(0, 12)) {
    const chip = document.createElement("span");
    chip.textContent = keyword;
    detailChipsEl.appendChild(chip);
  }
}

function clearEntityLists() {
  detailMcpListEl.innerHTML = "";
  detailSkillsListEl.innerHTML = "";
  detailAgentsListEl.innerHTML = "";
  detailPromptsListEl.innerHTML = "";
}

function setEntityGroupVisibility(groupEl, visible) {
  if (!groupEl) {
    return;
  }
  groupEl.style.display = visible ? "block" : "none";
}

function renderEntityList(target, items) {
  target.innerHTML = "";

  if (!items.length) {
    return;
  }

  for (const item of items) {
    const li = document.createElement("li");
    const nameEl = document.createElement("div");
    nameEl.className = "entity-item-name";
    nameEl.textContent = item.name;
    li.appendChild(nameEl);

    const desc = (item.description || item.path || "").trim();
    if (desc) {
      const descEl = document.createElement("div");
      descEl.className = "entity-item-description";
      descEl.textContent = desc;
      li.appendChild(descEl);
    }

    target.appendChild(li);
  }
}

function getEntityInfo(pluginName) {
  const fallback = { mcp: [], skills: [], agents: [], prompts: [] };
  if (!pluginName || !entityInventory || !entityInventory.plugins) {
    return fallback;
  }

  return entityInventory.plugins[pluginName] || fallback;
}

function getEntityCounts(pluginName) {
  const info = getEntityInfo(pluginName);
  return {
    mcp: info.mcp.length,
    skills: info.skills.length,
    agents: info.agents.length,
    prompts: info.prompts.length,
  };
}

function renderGlobalEntitySummary(plugins) {
  const totals = { mcp: 0, skills: 0, agents: 0, prompts: 0 };

  for (const plugin of plugins) {
    const counts = getEntityCounts(plugin.name);
    totals.mcp += counts.mcp;
    totals.skills += counts.skills;
    totals.agents += counts.agents;
    totals.prompts += counts.prompts;
  }

  globalEntitySummaryEl.innerHTML = "";
  const pills = [
    ["Plugins", plugins.length],
    ["MCP", totals.mcp],
    ["Skills", totals.skills],
    ["Agents", totals.agents],
    ["Prompts", totals.prompts],
  ];

  for (const [label, value] of pills) {
    const pill = document.createElement("span");
    pill.className = "entity-pill";
    pill.textContent = `${label}: ${value}`;
    globalEntitySummaryEl.appendChild(pill);
  }
}

async function fetchJsonWithCandidates(candidates) {
  const errors = [];

  for (const url of candidates) {
    try {
      const res = await fetch(url, { cache: "no-cache" });
      if (!res.ok) {
        errors.push(`${url}: HTTP ${res.status}`);
        continue;
      }
      return await res.json();
    } catch (err) {
      errors.push(`${url}: ${err.message}`);
    }
  }

  throw new Error(errors.join(" | "));
}

async function bootstrap() {
  try {
    statusEl.textContent = "Loading plugin catalog...";

    // Only try artifact-root relative layouts to avoid docs-folder fallback noise.
    const marketplaceCandidates = [
      "./marketplace.json",
      "../marketplace.json",
    ];
    const catalog = await fetchJsonWithCandidates(marketplaceCandidates);

    const entityCandidates = [
      "./_internal/.plugin-entities.json",
      "../_internal/.plugin-entities.json",
      "./plugin-entities.json",
      "../plugin-entities.json",
    ];

    try {
      entityInventory = await fetchJsonWithCandidates(entityCandidates);
    } catch {
      entityInventory = { plugins: {} };
    }

    allPlugins = Array.isArray(catalog.plugins) ? catalog.plugins : [];

    const version = catalog?.metadata?.version || "unknown";
    metaEl.textContent = `Catalog version ${version} • ${allPlugins.length} plugins indexed`;
    renderGlobalEntitySummary(allPlugins);

    render(allPlugins);
  } catch (err) {
    statusEl.textContent = `Could not load marketplace catalog (${err.message}).`;
    metaEl.textContent = "Catalog metadata unavailable.";
  }
}

searchEl.addEventListener("input", () => render(allPlugins));

bootstrap();
