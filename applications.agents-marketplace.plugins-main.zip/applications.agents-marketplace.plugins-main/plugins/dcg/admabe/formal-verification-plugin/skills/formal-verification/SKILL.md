---
name: formal-verification
description: "Use when: debugging pipelined DPV/FV proofs, diagnosing CONFLICT (over-constraint), understanding CEX multi-transaction interference, choosing constraint observation phases, reasoning about pipeline timing in sequential equivalence checking, or deciding between stg1 vs stg2 signal observation. General formal verification insights applicable to Hector DPV, JasperGold, or similar tools. For simcex-specific CEX extraction see simcex-debug skill. Project-specific proof parameters (stim/obs cycles, lemma results, RTL configs) are in the workspace copilot-instructions.md."
---

# Formal Verification — Pipeline Proof Debugging Insights

General lessons for proving equivalence between a combinational spec and pipelined
RTL. Applicable to any bounded sequential equivalence proof tool (Hector DPV,
JasperGold, etc.).

---

## 1. Multi-Transaction Interference (The #1 CEX Pattern)

In pipelined proofs, the solver is free to inject **multiple transactions** into
the pipeline unless explicitly constrained. The most common false-CEX pattern:

> A second transaction at cycle `stim+1` races through the pipeline and
> overwrites flop state at the observation phase. Your constraint maps
> spec inputs to the *first* transaction's data, but stg2 actually holds
> the *second* transaction's output.

### Diagnosis

When analyzing a counterexample (text dump, waveform, or CEX viewer), look for:
- **`_dv` signals** (data-valid) firing at unexpected phases (stim+1, stim+2, etc.)
- **M_info / M_data** inputs with non-zero values at phases after stim
- Pipeline control signals (`load_stg1`, `load_addr`) firing multiple times

For simcex-specific CEX extraction syntax, see the **simcex-debug** skill.

### Fix Strategies (from least to most restrictive)

| Strategy | Pro | Con |
|----------|-----|-----|
| **Map constraints to stg2 at obs** | Observes whatever transaction actually produced stg2 output — no conflict risk | Spec input mapping becomes "what stg2 sees" rather than "what was injected at stim" |
| **Block extra `_dv` after stim** | Forces single-transaction mode | May CONFLICT if the pipeline's FIFO stages need multiple valid pulses to advance |
| **Increase obs** | Lets the first transaction propagate fully | Changes what output phase you observe; may not help if second txn still interferes |

### The CONFLICT Trap

Blocking `msgCntxt_agu_dv` at phases `stim+1..obs` while simultaneously
requiring `stg2_valid == 1` at obs **often causes CONFLICT** because:
- The decouple FIFO needs multiple push cycles (each requiring `dma_req_dv`
  and sometimes `agu_dv`) to advance data through intermediate stages.
- A single `agu_dv` may not produce `mem_req_vld_stg2 = 1` within the
  expected latency.

**Rule**: If blocking extra transactions causes all lemmas to show
"conflicting constraints", the pipeline *requires* multiple transactions.
Use the stg2-observation strategy (Strategy 1) instead.

---

## 1b. CONFLICT from Pipeline-Deep Constraint + Transaction Isolation

A subtle over-constraint pattern that causes CONFLICT even when the same
transaction-isolation block works for similar proofs:

### Problem

Constraining a **deeply registered pipeline signal** (e.g. a flag or opcode
copy registered in tileInfo_stg1 at stg1_ph) while also blocking transactions
after stim with the standard isolation loop causes CONFLICT.

**Root cause**: Load-enable gates on pipeline registers (e.g. `load_stg1`,
controlled by FIFO handshake logic) may be inhibited when `msgCntxt_agu_dv`
is blocked at cycles `stim+1..stg1_ph`. The solver cannot find a trajectory
that simultaneously satisfies `stg2_valid == 1` at obs AND the downstream
registered flag at stg1_ph, because loading that flag requires handshake
activity that was blocked.

**Contrast**: Constraining a *spec input mapped to a stg1 signal*
(`spec.foo == impl.tileInfo_stg1.bar(stg1_ph)`) does NOT cause CONFLICT
because the spec input is a free symbolic variable — no pipeline reachability
needed. CONFLICT only appears when you constrain an RTL-computed pipeline
register directly.

### Example (project ADMA AGU, 2026-06-09)

```tcl
# WRONG — constrains a registered pipeline flag, causes CONFLICT:
assume mrow_copy_rowcopy = (impl.tileInfo_stg1.rowCopy($::stg1_ph) == 1)

# CORRECT — constrain the opcode at the primary input (stim), same as tensor proof:
assume mrow_copy_opcode_lo = (impl.msgCntxt_agu.opcode($::stim) >= 10)
assume mrow_copy_opcode_hi = (impl.msgCntxt_agu.opcode($::stim) <= 13)
```

The correct form anchors the constraint at the primary input boundary (stim).
The pipeline then propagates the opcode naturally, letting `load_stg1` fire
without constraint, and satisfying both `stg2_valid` and the downstream
registered state.

### General rule

**Constrain opcode/mode at stim (primary input), not at any downstream
pipeline register.** Downstream registered signals can be *mapped* from free
spec inputs (which is safe), but never directly *constrained* to a fixed value
in combination with transaction isolation.

---

## 2. Constraint Phase Selection — stg1 vs stg2

### Wrong: Constrain stg1 combinational signals at stg1_ph

When multiple transactions flow through the pipeline, `tileInfo_stg1` at
`stg1_ph` may hold data from a *different* transaction than the one that
reaches stg2 one cycle later.

### Correct: Constrain registered stg2 signals at obs

`tileInfo_stg2.field($obs)` is the **registered copy** that directly
drives the stg2 output logic. It always matches the pipeline slot that
produced `mem_req_stg2` at obs — regardless of how many transactions
were in flight.

### Signal naming conventions

Pipelined RTL designs commonly have parallel signals at each stage with
similar base names but different types:

| Pattern | Typical meaning |
|---------|----------------|
| `fooOffset_stg1` | Combinational intermediate at stage 1 |
| `fooOffset_stg2` | **Registered** carry of the same quantity into stage 2 |
| `foo_stg2` (1-bit) | Flag derived FROM `fooOffset_stg1`, not the offset itself |
| `d_coordN[k]` | Combinational coordinate output for dimension k |
| `d_coord_stg2[k]` | Registered copy of the same coordinate at stage 2 |

**Lesson**: Always check RTL declarations — a signal with a similar name at a
different stage may have a completely different width or meaning. Project-specific
signal names for the ADMA AGU are in the workspace `copilot-instructions.md`.

---

## 3. CONFLICT Debugging Quick-Check

When all proofs report `INCOMPLETE` with "N had conflicting constraints":

1. **Recent constraint additions are the prime suspect** — revert one at a time.
2. **`stg2_valid == 1`** + single-transaction blocking is the most common
   conflict pair (pipeline needs multi-cycle FIFO pushes).
3. **Check diagnostic covers** — if ALL covers across ALL proofs show CONFLICT,
   it's a global constraint issue (not mode-specific).
4. **CONFLICT ≠ FAILED** — CONFLICT means no valid input assignment exists that
   satisfies all assumes. It's a modeling error, not a spec mismatch.

---

## 4. CEX Analysis Workflow

### Step 1: Identify unexpected inputs

In the counterexample output (text dump, waveform viewer, or CEX report),
look for signals that are non-zero in phases you didn't expect. Common culprits:
- `_dv` data-valid inputs at phases after stim
- Bus inputs (M_info, M_data, msgCntxt) with unexpected non-zero fields
- Pipeline control signals firing more times than expected

### Step 2: Trace multi-transaction interference

The most common CEX pattern in pipelined DPV proofs:

> The solver sends a **second transaction** at cycle stim+1 that races through
> the pipeline and overwrites state that your constraints assume belongs to the
> first transaction.

**Fix**: Constrain observation-phase state directly (stg2 at obs), or if
single-transaction mode is needed:
```tcl
for {set p [expr {$::stim + 1}]} {$p <= $::obs} {incr p} {
    assume no_extra_agu_dv_$p = (impl.msgCntxt_agu_dv($p) == 0)
}
```

**CAUTION**: Do NOT also block `dma_req_dv` — the decouple FIFO needs it at
multiple cycles to push M_info/M_data through separate pipeline stages.
Blocking it causes CONFLICT (over-constraint → all tasks have conflicting
constraints, nothing is provable).

### Step 3: Decode struct fields

For large bus inputs like `impl_M_info_in` or `impl_msgCntxt_agu_in`, you need
to know the bit positions of fields (e.g., `dMax[0]`, `opcode`, `dataSize`).
Cross-reference with the RTL struct/interface definitions.

### Step 4: Validate constraint timing

A constraint like `assume X(phase_N) == Y` only forces the value at that
exact phase. If the RTL loads a flop at a different phase (e.g., due to a
second transaction arriving earlier), the constraint is satisfied but the
flop holds different data.

---

## Diagnosing CONFLICT (Over-Constraint)

- If a lemma or cover is reported as CONFLICT, it is over-constrained (unsatisfiable).
- Check for mutually exclusive assumptions or constraints that block all legal behaviors.
- Use diagnostic covers to scan for reachable pipeline phases and handshake events.
- Remove or relax constraints incrementally to isolate the conflict.

## Constraint Phase Selection

- The observation phase for a lemma must match the pipeline latency and handshake protocol.
- If the CEX shows a mismatch between stimulus and observation, adjust the phase or handshake constraints.
- For multi-stage pipelines, ensure all stages are properly constrained and handshake signals are not held or invalidated mid-flight.

---
---

## 5–11. Extended Patterns (Reference)

The following topics are documented in detail in
[references/deep-patterns.md](./references/deep-patterns.md):

| Section | Topic |
|---------|-------|
| §5 | Pre-Decouple vs Post-Decouple Signal Selection |
| §6 | Solver Runtime as a Diagnostic Signal |
| §7 | Iterative Proof Debugging Strategy |
| §8 | Assume-Guarantee Decomposition (sub-modules, guarantee task patterns) |
| §9 | Pipeline Latency Determination via Diagnostic Covers |
| §6 (arch) | Proof Architecture Layers (Parse → Mirror → Prove) |
| §10 | Design-Bug Detection Methodology |
| §10 (lemma) | Hector TCL Lemma Format — Single-Line Requirement |
| §11 | Input Completeness for Stride Signal Mappings |
