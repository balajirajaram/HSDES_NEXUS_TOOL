# Formal Verification — Deep Patterns Reference

This file contains extended reference material for the formal-verification skill.
Loaded on demand when specific topics are needed.

See the skill index in `SKILL.md` for a quick summary of all topics.

---

## 5. Pre-Decouple vs Post-Decouple Signal Selection

In pipelined designs with **decouple FIFOs** (also called decoupling buffers or
output staging FIFOs), every pipeline output exists in two forms:

| Signal class | Example naming | Where it lives | Behaviour |
|--------------|----------------|----------------|-----------|
| **Pre-decouple** (internal) | `agu_req_pkt1`, `mem_req_stg2` | Directly after pipeline stage logic | Always reflects the pipeline's current computation result |
| **Post-decouple** (output) | `agu_req_pkt_1`, `agu_req_pkt_0` | After the FIFO output mux/gate | Gated by FIFO-empty flags; may hold stale data or be zeroed when the FIFO is empty |

### Why lemmas on post-decouple signals fail

A common pattern in dual-slot or multi-CL designs:

```
pipeline → mem_req_stg2 → decouple FIFO → agu_req_pkt_0 (output)
                        ↘ agu_req_pkt1 → decouple FIFO → agu_req_pkt_1 (output)
```

The post-decouple output (e.g., `agu_req_pkt_1`) is gated:
```verilog
assign agu_req_pkt_1.addr = decoupleOut1FifoEmpty ? '0 : agu_req_pkt1.addr;
```

If the FIFO's empty flag depends on handshake timing not fully constrained
in the proof, the solver may find a CEX where the FIFO is empty at `$obs`,
so `agu_req_pkt_1.addr == 0` while `spec.out == nonzero`. The arithmetic
is correct in the pipeline, but the FIFO gate masks it.

### Diagnosis

When a lemma comparing `spec.output == impl.<post_decouple_signal>` fails:
1. Check whether the impl signal passes through a FIFO or output-gating mux.
2. In the CEX, look for FIFO-empty or valid-gating signals being deasserted at `$obs`.
3. If the pipeline's internal (pre-decouple) version of the same signal would
   match the spec, the issue is FIFO timing, not pipeline arithmetic.

### Fix strategies

| Strategy | When to use |
|----------|-------------|
| **Use the pre-decouple signal** | Preferred when proving pipeline arithmetic correctness. The pre-decouple signal (`agu_req_pkt1.addr`) directly reflects the pipeline computation without FIFO interference. |
| **Add FIFO-nonempty assume** | If the lemma must check the actual output port, constrain the FIFO to be non-empty: `assume fifo_nonempty = (impl.decoupleOut1FifoEmpty($obs) == 0)`. Risks masking real FIFO bugs. |
| **Separate FIFO-correctness lemma** | Prove FIFO data integrity separately: when the FIFO is non-empty, its output matches what was pushed. This decouples pipeline-correctness from FIFO-correctness. |

### Naming convention clue

In many RTL codebases, a subtle naming difference distinguishes the two:
- `agu_req_pkt1` (no separating underscore before the digit) → internal/pre-decouple
- `agu_req_pkt_1` (underscore before the digit) → output/post-decouple

Always verify by tracing the RTL assignment chain — naming conventions are not
universal.

---

## 6. Solver Runtime as a Diagnostic Signal

| Runtime | Likely meaning |
|---------|----------------|
| < 5 min | Gross constraint or mapping error — solver finds trivial CEX |
| 5–15 min | Moderate issue — likely wrong signal path or constraint phase |
| 30–60 min | Formula is very close — small edge case or off-by-one |
| > 60 min / timeout | Likely correct (or needs lemma decomposition) |

Use early-failure iterations to eliminate structural bugs quickly, then
tighten constraints for the deep solver runs.

---

## 7. Iterative Proof Debugging Strategy

1. **Start broad**: Prove with minimal constraints — quick CEX reveals gross mapping errors.
2. **Add constraints one at a time**: Each constraint that extends solver runtime
   confirms you're on the right track.
3. **Use diagnostic covers**: `cover (spec_out == impl_out)` tells you whether
   equality is *reachable*; `cover (spec_out != impl_out)` tells you mismatch is
   reachable. Both covered → formula partially correct.
4. **Track iteration history**: Name output dirs systematically
   (`out_dir_iter108_stg2_signals`) so you can compare runtimes.
5. **CONFLICT = revert immediately**: Don't waste solver time on contradictory
   constraints. Revert the last change and try a different approach.

---

## 8. Assume-Guarantee Decomposition for Sub-Modules

Assume-guarantee decomposition isolates a sub-module's functional correctness
from the parent proof.  It applies in **two scenarios**:

| Scenario | Why it helps |
|----------|--------------|
| **Unresolved sub-module (true black box)** | `Warning-[SM_URMI]`: outputs are free symbolic variables; lemmas comparing spec to these free outputs FAIL regardless of spec accuracy.  An assume constrains the free outputs. |
| **Compiled sub-module (performance optimization)** | The sub-module IS in the solver's state space, but its internal logic is complex enough that the 3+ property proofs converge much faster when the sub-module's I/O relationship is assumed rather than re-proved in each task.  A separate guarantee task machine-checks the expression once. |

### CRITICAL — Verify Compilation Status Before Claiming Black-Box

**Never assume a module is a black box based on prior conversation context,
document history, or superficial reasoning.**  Always verify by checking the
DPV compile log directly:

```bash
grep -i "adma_elmt_calc\|SM_URMI\|Unresolved" <out_dir>/vcst_rtdb/.internal/hector/impl_compile/simon.log
```

A module listed in the **"List of modules in design which don't have a HDL or
liberty definition supplied"** section at the end of `simon.log` IS a black box.
If the module name does NOT appear there, it is compiled and resolved — its
outputs are NOT free variables.

**Anti-pattern**: Stating "module X is an unresolved black box" because the
conversation started with that assumption, without re-verifying after setup.f
changes.  This led to incorrect skill documentation and unnecessary compensating
complexity in a real project.

### Solution: Assume-Guarantee Decomposition

Add an **assume** that constrains the sub-module's outputs to satisfy a function
of its inputs.  This decomposes the proof into:

1. **Guarantee** (assumed in property proofs, machine-checked separately): the
   sub-module correctly computes its outputs from its inputs.
2. **Property** (proven by solver): the parent module correctly wires the
   constrained outputs to the final observation point.

### Implementation Pattern (Hector DPV / TCL)

```tcl
# Assume-guarantee for <module_name>: constrain output relationship.
# The sub-module may be compiled (for the guarantee task to machine-check)
# or unresolved (in which case the assume is the only constraint on its outputs).
assume <module>_guarantee = (
    impl.<output_signal_A>($::obs) - impl.<output_signal_B>($::obs)
    == spec.<equivalent_computation>($::stim))
```

The spec computes the expected function from inputs that are tied to the
module's RTL inputs via separate `map_*` assumes.

### Key Insights

1. **Verification obligation — soundness risk**: The assume is a formal claim
   about the sub-module that is NOT machine-checked by the property proofs.
   Anything short of a machine-checked proof of the guarantee introduces risk
   of unsoundness — the overall proof chain is only as strong as the weakest
   justification for each assume.  Options, in decreasing order of rigour:
   - **Machine-checked proof (sound)**: Add a separate `solveNB` task in the
     same DPV session that declares the guarantee expression as a **lemma**
     (not an assume).  If the sub-module is compiled (even if it was treated as
     a black box for the property proofs), the solver can verify it directly.
     This is the recommended approach — it closes the assume-guarantee loop
     with no residual proof obligation.
   - **Separate DPV proof** that includes the sub-module compiled and proves
     the same property.  Sound, but requires a second proof environment.
   - **RTL code review**: Manual inspection of the sub-module's logic.  Useful
     as a first-pass sanity check, but not machine-verified — human error can
     miss corner cases (e.g., boundary clipping, carry propagation).
   - **Simulation coverage**: Empirical evidence only.  Complements formal
     proof but cannot replace it; simulation misses the long tail of rare
     input combinations that formal methods catch.

2. **0-based index correction**: RTL element-count signals (like `elmntPerCL`,
   `dMaxN`) are often 0-based maximum indices (element_count - 1). The formula
   needs `(value + 1)` to recover the actual count. This off-by-one is the
   most common spec-vs-RTL mismatch.

3. **Opcode-invariant paths**: If the sub-module is always in the data path
   regardless of opcode/mode, apply the assume unconditionally. Different modes
   may force different input values (e.g., reduce forces `dataSizeN = D8`), but
   the sub-module's transfer function is the same — the spec just needs to
   account for the forced inputs.

4. **Timing of assumes on black-box outputs**: The assume must reference the
   black-box outputs at the phase when the parent consumes them. If the
   sub-module has an internal pipeline register (stg1→stg2 flop), the outputs
   appear one cycle after the inputs. Constraint timing:
   - Map inputs at `$::stg1_ph` (when the sub-module sees them)
   - Constrain outputs at `$::obs` (when the parent consumes them)

### When NOT to Use

- If the sub-module is **small and self-contained** (< 200 lines): just add it
  to setup.f. The solver handles it faster than dealing with assumes.
- If the sub-module output feeds **multiple parent signals** with different
  timing: one assume per output relationship needed; complexity grows fast.
- If the parent's wiring is trivial (direct assignment): the assume becomes
  equivalent to the lemma itself (circular). Only useful when the parent applies
  non-trivial combinational logic between the black-box output and the
  observation point.

### Completing the Guarantee via a 4th Proof Task

The strongest way to close an assume-guarantee decomposition is to machine-check
the guarantee in the **same DPV session** as the property proofs.  Pattern:

1. **Parameterize `input_mappings`** with an optional flag to suppress the assume:

```tcl
proc input_mappings {mode {with_guarantee 1}} {
    # ... all map_* assumes ...
    if {$with_guarantee} {
        assume module_guarantee = (<guarantee expression>)
    }
}
```

2. **Add a guarantee proof proc** that calls `input_mappings "" 0` (suppress
   the assume), then declares the same expression as a **lemma**:

```tcl
proc check_module_guarantee {} {
    input_mappings "" 0           ;# all signal mappings, NO guarantee assume
    reset_dv_model
    reset_quiescent_constraints
    assume stg2_valid = (impl.mem_req_vld_stg2($::obs) == 1)
    # No opcode/mode constraint — guarantee must hold universally
    lemma module_guarantee_check = (<same expression as the assume>)
}
```

3. **Wire a 4th `solveNB`** in the main test proc:

```tcl
set_user_assumes_lemmas_procedure "check_module_guarantee"
solveNB check_module_guarantee
```

4. **Update `report_fv -proof`** to include the new task name.

**Why this works**: The sub-module is compiled in the `impl` design (resolved
via `-y` or listed in `setup.f`).  The 3 property-proof tasks use the guarantee
as an assume to speed convergence; the 4th task proves the assume is correct by
letting the solver reason through the compiled sub-module logic directly.  The
4th task has no opcode constraint because the sub-module's transfer function is
typically opcode-invariant — different modes force different inputs upstream, but
the sub-module logic is the same.

**If the guarantee task fails**: The CEX reveals a spec-RTL mismatch in the
sub-module formula.  Fix the spec, re-run, and iterate.  A failing guarantee
also retroactively invalidates the "PROVEN" status of the property lemmas that
depended on the assume — they were conditional on an incorrect claim.

**Common guarantee CEX causes**:

1. **Invalid input ranges (don't-care outputs)**: The sub-module's output is
   undefined/garbage when inputs are out of valid range (e.g., `d_coordN >
   dMaxN` wraps differently in N-bit RTL arithmetic vs 32-bit spec arithmetic).
   The parent's logic uses a separate valid flag to suppress consumption of
   the output.  Fix: add an `assume valid_input_range = (precondition)` in the
   guarantee proc — the guarantee only needs to hold when the output is
   semantically meaningful.

2. **Sub-byte data types with non-standard arithmetic**: Formats like D4
   (4-bit elements) use divide-by-2 paths in the RTL that the spec must
   explicitly model.  The standard `(count + 1) * bpe - 1` formula doesn't
   apply; the RTL uses `((x + 1) * bpe) / 2 - 1` instead.

3. **dataSize enum values outside expected range**: RTL `case` statements
   may have `default` branches that map unexpected enum values to specific
   behaviors (e.g., `default: bpe = 1`).  The spec must handle ALL possible
   values of the underlying bit-field, not just the named enum members.

4. **Port-width truncation (parent wider than sub-module port)**: If the
   guarantee proof's `map_*` assumes tie spec inputs to PARENT signals that
   are wider than the sub-module's port width, the solver can pick values
   that exceed the port.  The sub-module sees the truncated (lower-bits)
   value while the spec uses the full value → mismatch.  Example: parent
   signal `ledElmtInCL_NInt` is 9+ bits, but elmt_calc port `elmntPerCL`
   is `[CLS_DATA_MAXW-1:0]` = 6 bits.  Fix: add `assume valid_field =
   (spec.field($stim) <= (2^PORT_WIDTH - 1))` in the guarantee proc.
   The property proofs don't hit this because their opcode constraints
   ensure the parent's pipeline only produces fittin values.

5. **Out-of-range opcode values**: If the opcode field is physically wider
   than the documented enum range (e.g., 5+ bits but only values 0-15
   defined), the solver finds CEXs where the pipeline behaves unexpectedly.
   Fix: `assume valid_opcode = (spec.opcode($stim) <= MAX_VALID_OPCODE)`.

**If the sub-module is truly a black box** (unresolved, not in the compile
fileset): the 4th task cannot work because the solver has no RTL to reason
about.  In that case, use one of the fallback justification methods (separate
proof, code review, simulation) and document the residual proof obligation.

### Solver Capacity vs Structural Limitation (Corrected Diagnosis)

When a guarantee lemma FAILS and a CONFLICT occurs under single-transaction
constraints, the initial diagnosis may appear to be a "structural pipeline
limitation."  However, the inductive-step retry (2026-05-13) revealed the
true root cause:

**Misdiagnosis**: "The pipeline requires multiple handshakes; the solver
cannot isolate the first transaction."

**Correct diagnosis**: The sub-module's internal logic (e.g., adma_elmt_calc_l2r)
is too complex for the solver to reason through in a single proof step.  The
assume-guarantee decomposition is a **solver capacity hint**, not a workaround
for a structural design limitation.

**Evidence pattern** (run `check_inductive_step` with `input_mappings "" 0`):

1. Lemmas that DON'T depend on the sub-module's internal computation
   (address, overflow guard, invariant preservation) → PROVEN without guarantee
2. Lemmas that DO depend on the sub-module's output → FAILED (solver capacity)
3. The guarantee formula is structurally equivalent to the output lemma
   (RTL: `totalBytes = (x_end_byte - x_start_byte)[width:0]`)

**Resolution**: The guarantee is sound by RTL inspection (structural
equivalence between the guarantee formula and the output assignment).
Document:
- Which lemmas are UNCONDITIONALLY PROVEN (no guarantee needed)
- Which require the guarantee (solver-capacity limitation only)
- RTL line numbers showing the structural equivalence

This is NOT a failure of verification nor a structural gap — it's a known
solver-capacity pattern where assume-guarantee decomposition provides the
necessary reasoning bridge for complex sub-modules.

### Multi-Dimensional Spec Formula with Bit-Width Truncation

When a spec formula combines a sub-module output with a dimension multiplier:

  `output = (dim0_value + 1) * (dim1_value + 1) - 1`

and the RTL hardware extracts a truncated portion (e.g., the lower 7 bits via
`totalBytesMin1[6:0]`) of this product, a guarantee for the *full* formula fails
because:

1. The expression `(dim0+1)*(dim1+1)-1 == spec.out` is internally consistent
   but `spec.out` already IS the truncated 2D product — circular.
2. The solver cannot bridge the truncated RTL output back to the untruncated
   product when the values can exceed the truncation width.

**Solution — decompose the guarantee by dimension**:

- Add a separate spec output for the dim-0 sub-formula only: `out_dim0 = f(dim0)`.
- Write the guarantee as: `(impl.x_end_byte - impl.x_start_byte == spec.out_dim0)`.
  This is the piece the sub-module computes; the guarantee is structurally simple.
- The main lemma checks the full truncated product:
  `spec.out_totalbytes_min1 == impl.totalBytes` where
  `spec.out_totalbytes_min1 = ((dim0+1)*(dim1+1)-1) & TRUNC_MASK`.

**Why this works**: The dim-0 guarantee pins the sub-module's output to a value
the solver can use as a known quantity. Given that fixed value, the dim-1 multiply
and truncation are straightforward arithmetic that the solver handles directly.

**Spec mask alignment**: Ensure the mask in the spec matches the RTL extraction
width exactly.  For `totalBytesMin1[6:0]` (7-bit extraction): use `& 0x7F`, NOT
`& 0x1FF`.  A 9-bit mask is inconsistent with a 7-bit RTL field and causes false
CEXs when the 2D product lies in `[128, 511]`.

### Pruning Inapplicable Lemmas for Architectural Variants

When extending a proof harness from one module variant to a related variant
with a different pipeline structure:

1. **Don't assume all original lemmas apply** — if a signal path differs, a
   lemma may be structurally invalid (refers to a pipeline stage or signal that
   doesn't exist in the variant).
2. **Remove rather than fail** — a failed lemma from a wrong signal path blocks
   the proof without diagnostic value.  Better to remove it with a note.
3. **Document the removal** — note which lemma was removed, which signal was
   inapplicable, and why (architecture difference).

Example: `eq_base_l2_addr` was valid for the L2 AGU (uses stages stgC→stgB→stg1
to route the base address), but inapplicable for the SLM AGU (uses stgA stage
with different timing).  The lemma was removed from SLM proofs by design, not
oversight.

### Inductive Proofs for Unbounded Transaction Coverage

For the constructive pattern that assembles base-case proofs and inductive-step
lemmas into an unbounded correctness argument (invariant preservation over
multi-transaction execution), see the **hector-dpv** skill §9 ("Inductive Proof
Structure in DPV").

---

## 9. Pipeline Latency Determination via Diagnostic Covers

When extending a proof to a related but architecturally different RTL module
(e.g., a 3-stage SLM AGU vs a 6-stage L2 AGU), do NOT assume the same pipeline
latency.  Use diagnostic covers to measure it empirically.

### Pattern

Add covers that test when `mem_req_vld_stg2` first asserts at each candidate
cycle.  With `stim = 2`, scan a range stim+6 to stim+20:

```tcl
set phase_limit 24            ;# set high enough to span all candidates
cover diag_vld_8  = (impl.mem_req_vld_stg2(8)  == 1)
cover diag_vld_9  = (impl.mem_req_vld_stg2(9)  == 1)
cover diag_vld_10 = (impl.mem_req_vld_stg2(10) == 1)
cover diag_vld_11 = (impl.mem_req_vld_stg2(11) == 1)
cover diag_vld_12 = (impl.mem_req_vld_stg2(12) == 1)
# ... extend as needed
```

Interpret results using DPV output semantics (covers):

| Result    | Meaning                                         |
|-----------|-------------------------------------------------|
| `EQUAL`   | **Unreachable** — pipeline hasn't produced output yet at this cycle |
| `NOT_EQUAL` | **Reachable** — valid output appears at this cycle |

The **first `NOT_EQUAL` cover** is your `obs` cycle.

### Examples

SLM read (4-stage pipeline, stim=2):
- diag_vld_8 through diag_vld_11: EQUAL (unreachable) → still in transit
- diag_vld_12: NOT_EQUAL (covered) → latency = 10 cycles, `obs = 12`

SLM write (3-stage pipeline, stim=2):
- diag_vld_8, diag_vld_9: EQUAL
- diag_vld_10: NOT_EQUAL → latency = 8 cycles, `obs = 10`

L2 read (6-stage + decouple FIFO, stim=2):
- diag_vld_8 through diag_vld_15: EQUAL
- diag_vld_16: NOT_EQUAL → latency = 14 cycles, `obs = 16`

### Deriving timing parameters

Once `obs` is known:

```
stg1_ph    = obs - 1
phase_limit = obs + 8        (for reset_dv_model -phase_limit)
```

For multi-module harnesses with different latencies per module, keep
separate Tcl variables:

```tcl
set l2_obs      16 ; set l2_stg1_ph      15
set slmR_obs    12 ; set slmR_stg1_ph    11
set slmW_obs    10 ; set slmW_stg1_ph     9
```

Also keep mode-specific helper procedures tied to those timing variables
(input mappings, reset/quiescent constraints, and proof drivers). A common
failure mode is correctly splitting `*_obs` variables but accidentally reusing
one module's helper proc in another mode.

### Constraints during the latency scan

During the diagnostic cover run, use **minimal constraints** — just enough
to inject a transaction at stim and suppress resets.  Omit all input
mappings, guarantee assumes, and handshake constraints that limit pipeline
throughput.  Excessive constraining can make all covers report EQUAL
(unreachable) and give a falsely-large latency estimate.

A single `no_reset` constraint and a stimulus `dv` pulse at stim is
sufficient:

```tcl
assume no_reset_after_2 = (impl.reset(p)  == 0)  ;# for each p > 2
assume agu_dv_at_stim   = (impl.agu_dv($::stim) == 1)
```

---

## 6. Proof Architecture Layers (Parse → Mirror → Prove)

When combining a C parser (e.g., Kestrel) with a theorem prover to verify a
hardware spec model, completeness requires three distinct layers:

### Layer 1 — Syntactic/structural (machine-checked by parser)
The C source text is successfully parsed into an AST.  A Phase 3 function-name
inventory confirms that every expected function is present in the translation
unit under the expected name.  Catches: typos, missing definitions, symbol
scoping errors.

### Layer 2 — Algebraic equivalence (machine-checked by defthm)
Hand-written ACL2 mirror functions (faithfully reflecting the C arithmetic by
inspection) are proven equivalent to one another or to a reference arithmetic
specification (e.g., the RTL formula).  Catches: arithmetic errors, incorrect
operator precedence, sign-extension mistakes.

### Layer 3 — AST-to-mirror correspondence (machine-checked by evaluator)
A logic-mode evaluator (see acl2-improvements §16) evaluates each named
function's parsed AST on symbolic inputs and proves the result equals the
corresponding Phase 2 mirror.  Catches: the gap between "I wrote the mirror
correctly by inspection" and "the parser actually read the same function body."

### Completeness argument

All three layers must hold to claim "the real C source is equivalent to the
RTL specification."  Missing Layer 3 means the proof only covers the
hand-written mirrors, not the C text itself.

### Reporting discipline

When reporting proof results, state which layers are covered:

```
Layer 1 (syntactic): 5 translation units parsed; 14 functions present
Layer 2 (algebraic): 12 equivalence theorems proven
Layer 3 (evaluator): 5 evaluator-correctness theorems proven for cmodel fns
Remaining manual gap: wrapper main() functions (API calls prevent full eval)
```

Never claim "proves the C code is equivalent" when only Layer 2 is complete.

### What Layer 3 cannot cover (known manual-review residual)

Wrapper `main()` functions that contain framework API calls (e.g., Hector
`registerInput`/`registerOutput`) and bitfield struct assignments cannot be
mechanically evaluated because the API functions have no C body to evaluate.
Document this residual explicitly and close it by manual review + the Phase 3
name inventory.

---

## 10. Design-Bug Detection Methodology

When a proof fails with a concrete CEX (not CONFLICT), determine if the CEX
represents a genuine RTL bug or a harness/modeling artifact before investing in
additional IHs.

### Step 1 — Classify the CEX by type

| CEX type | Symptom | Next action |
|----------|---------|-------------|
| **Multi-transaction interference** | A second transaction valid signal fires after `stim` in the CEX; downstream pipeline state at `obs` holds the second txn's values | Option A: block the transaction-valid signal during stim+1..obs |
| **Wrong signal path** | CEX shows spec=0 or impl=constant throughout | Check signal hierarchy: is the observation point before or after the correct pipeline stage? |
| **Missing IH** | CEX shows an internal pipeline register differs from the matching spec input or a derived signal | Add an IH that assumes the two signals are equal at the relevant cycle |
| **Possible design bug** | CEX shows spec computes value X from valid inputs, RTL computes Y, no modeling artifact explains the gap | Proceed to Steps 2-3 |

To check for multi-transaction interference: search the CEX dump for a transaction valid/enable signal active at a cycle N > stim.

### Step 2 — Single-transaction isolation (Option A)

Add constraints to block all new transactions after stim (substitute the
design's actual transaction-valid signal name for `<txn_valid>`):

```tcl
for {set p [expr {$::stim + 1}]} {$p <= $::obs} {incr p} {
    assume no_extra_txn_$p = (impl.<txn_valid>($p) == 0)
}
```

**Important**: Do NOT block pipeline-internal handshake signals — many
pipelines require multiple internal ready/valid cycles even for a single
external transaction. Blocking these internal signals causes CONFLICT.

**If this causes CONFLICT** (all lemmas become unsatisfiable): the pipeline
genuinely requires multiple transactions; Option A is not valid. Use the
stg2-observation strategy instead (map spec inputs to `$obs` stg2 signals).

**If this proves the lemma**: the original CEX was a harness artifact
(multi-transaction interference). The design is correct. No further investigation
needed.

**If this still fails** (concrete CEX persists): proceed to Step 3.

### Step 3 — Manual formula verification

Pick a specific concrete input from the CEX and manually compute both sides:

1. Extract input values from the `.cex` file (e.g., `BaseAddr`, `dimOffset[i]`,
   `offsets[k]`, `elmntStride`, `dimStride`).
2. Compute the spec formula by hand (or in Python/shell).
3. Look up the RTL's computed output in the CEX or simcex trace.
4. Compare. If they differ: design bug (or spec bug). If they match: the
   solver found a non-representative CEX — add more constraints and re-run.

### Step 4 — Cover sanity check

Add a cover asking "is the match ever reachable?":

```tcl
cover cov_formula_match    = (spec.<out_signal>($::stim) == impl.<impl_signal>($::obs))
cover cov_formula_mismatch = (spec.<out_signal>($::stim) != impl.<impl_signal>($::obs))
```

| Both covered | Formula is sometimes right, sometimes wrong — narrowing needed |
| Match only covered, mismatch not | Mismatch is infeasible → PROVEN (may not match report yet; re-run) |
| Neither covered | Over-constrained harness (CONFLICT pending) |

### Step 5 — Mutation testing as a sanity check

To confirm the proof machinery CAN detect a bug:

1. Introduce a known-wrong mutation to the RTL (e.g., add 127 to a field).
2. Re-run the same proof. If the lemma changes from PROVEN to FAILED: the
   proof is sensitive to that signal and the overall result is meaningful.
3. Revert the mutation.

Example: add a small constant offset to a key RTL signal (e.g., increment a
base-address or stride register by an arbitrary value). If the lemma changes
from PROVEN to FAILED with a concrete CEX, the proof is sensitive to that
signal and the result is meaningful.

### Intermediate pipeline registers and formal-tool signal accessibility

In formal verification tools, intermediate pipeline registers that are not
referenced by any property or observable output may be **compiled away** —
the solver does not track them. These signals cannot appear in constraint or
lemma expressions.

**Diagnosis**: Check the solver's state-variable list or symbol table for the
signal name. If absent, the signal is inaccessible and cannot be constrained.

**Consequence for IH design**: Use only signals already present in top-level
ports, existing property expressions, or pipeline-stage outputs that the tool
retains. Cannot constrain compiled-away registers directly.

**Workaround**: Use single-transaction isolation (Option A, Step 2) to prevent
multi-transaction interference without referencing inaccessible registers. This
is sufficient when interference is the root cause.

For DPV-specific signal accessibility diagnosis (UAL state file, `task_1.initial`),
see the hector-dpv skill (§12).

---

## 11. Input Completeness for Stride Signal Mappings

When mapping RTL stride signals to spec inputs, map **all individual component
signals** — not just precomputed product registers — to ensure the proof covers
each signal independently.

### Pattern: RTL precomputes products from individual strides

Many pipeline RTLs precompute products of stride components and store them in
registered pipeline signals (e.g. `stride1Bytes_stg1 = elmntStride[1] * dimStride[1]`).
It is tempting to map only the product register to the spec, since that is what
appears in the address formula.

**Problem**: the individual factors (`elmntStride[1]`, `dimStride[1]`) remain
unconstrained relative to each other. The proof then cannot verify that the RTL
correctly computes the product, because those factors are separate RTL signals that
are independently writable (via `stateFetch` or descriptors), and only their
product is observed.

### Correct approach: map all three (product + both factors)

```tcl
assume map_tensor_stride1_bytes = (spec.tensor_stride1_bytes($::stim) == impl.stride1Bytes_stg1($::stg1_ph))
assume map_tensor_dimStride1    = (spec.tensor_dimStride1($::stim)    == impl.tileInfo_stg1.M_stride.dimStride[1]($::stg1_ph))
assume map_tensor_elmntStride1  = (spec.tensor_elmntStride1($::stim)  == impl.tileInfo_stg1.M_stride.elmntStride[1]($::stg1_ph))
```

Then add a **factorization consistency lemma** to the soundness proof:

```tcl
# Proves the RTL correctly pre-multiplies elmntStride[1] * dimStride[1] into stride1Bytes_stg1.
lemma stride1_bytes_factorization = (spec.tensor_stride1_bytes($::stim) == (spec.tensor_elmntStride1($::stim) * spec.tensor_dimStride1($::stim)))
```

### Symmetry check

Verify that the signal mapping is **symmetric across dimensions**:
- dim-0: `addr_dim0_stride` maps `elmntStride[0]`  ← individual component ✓
- dim-1: `tensor_stride1_bytes` maps the product register — `elmntStride[1]`
  additionally needed for symmetry and factorization verification.

Any dimension whose individual stride component signals are NOT mapped is a
potential gap: an incorrect factor could produce a correct product on the
probed inputs by coincidence (or by cancellation), passing the proof while
leaving the individual factor path unverified.

### Where to add in the wrapper + harness

1. **C++ spec wrapper** (`cm_wrapper.cpp`, `cm_wrapper_ro_dis.cpp`): add a
   `uint32_t tensor_elmntStride1` field and `Hector::registerInput(...)` call.
2. **TCL harness** (`fv_cm_access.tcl`): add `map_tensor_elmntStride1` assume in
   `input_mappings_tensor {}` (used by both ro_en and ro_dis tensor proof procs).
3. **Soundness proc** (`check_tensor_addr_bytes`, `check_tensor_addr_bytes_l2_ro_dis`):
   add `stride1_bytes_factorization` lemma after the primary address lemma.

Discovered 2026-06-17 during code review of the ADMA AGU DPV proof.

---

## 10. Hector TCL Lemma Format — Single-Line Requirement

Hector DPV's TCL expression parser does **NOT** support multi-line `lemma`
expressions spanning continuation lines.  If a `lemma` command ends mid-expression
(e.g. with an open `||` at the end of a line before a newline), Hector reports:

```
[Error] IFACE_ERROR_IN_EXPR: In expression 'NAME = (... < 6) ||': syntax error, unexpected $end.
[Error] IND-310: Failed to create lemma 'NAME = (... < 6) ||'.
```

**Rule**: Every `lemma` (and `assume`) must be written as a **single TCL line**,
even if that makes the line long.  Standard TCL does not treat open `(` parentheses
as a line-continuation character.

```tcl
# WRONG — multi-line, Hector sees only the first line as the expression:
lemma eq_foo = (((impl.bar($::stim) < 6) ||
               (impl.bar($::stim) > 13)) ->
               (spec.out($::stim) == impl.out($::obs)))

# CORRECT — single line, even if long:
lemma eq_foo = (((impl.bar($::stim) < 6) || (impl.bar($::stim) > 13)) -> (spec.out($::stim) == impl.out($::obs)))
```

Discovered 2026-06-09 in the ADMA AGU DPV harness: `eq_gmem_cl_addr` in
`check_inductive_step` had been silently failing (not appearing in `Status for proof`
output) since the antecedent was added, because the multi-line format broke the
Hector expression parser.  The proof was not FAILED but simply never ran — it was
dropped from the proof task during harness setup.
