---
name: shell-improvements
description: "Use when: agent terminal sessions hang, output is truncated, background processes need monitoring, UTF-8/Unicode breaks replace_string_in_file, or long-running commands produce stalls. Covers: terminal buffering and output management, background process polling, stall prevention, focus-trap avoidance, UTF-8 file patching (repr() diagnosis, Python line-range patcher), non-recursive make (Rules.mk), and GlobalProtect VPN diagnostics. For tcsh/csh-specific syntax (redirects, loops, quoting pitfalls) see the tcsh-csh reference."
---

# Shell Improvements — Terminal Rules for Agent Sessions

These rules prevent wasted tool calls when working with long-running terminals
in agent sessions. Shell-specific syntax (tcsh vs bash) is in the reference:

- [tcsh/csh reference](./references/tcsh-csh.md) — redirects, loops, quoting,
  SIGTTOU, CORRECT prompts, multiline `bash -c` from tcsh, git commit messages

---

## 1. Fast Rules

- Prefer tool-managed backgrounds (`isBackground: true`) over shell `&`.
- Inspect log files directly for long runs; do not rely on terminal buffers.
- Use bounded checks (`tail`, `wc -l`) for progress polling.
- In TCL scripts, prefer TCL-native path operations (`file normalize`, `file join`).
- If the default shell is tcsh, see the [tcsh/csh reference](./references/tcsh-csh.md)
  for syntax differences (loops, redirects, quoting, globs).

---

## 2. Wrapper Scripts vs Inline Commands

Prefer inline one-shot commands for short tasks.

- Use inline commands for workflows up to ~3 lines.
- Use scripts when logic is reused, has condition branches, or needs sharing.

---

## 3. Background Process Execution and Output Monitoring

When working with long-running processes (formal verification, compilations, builds),
proper monitoring of output is critical. Terminal output truncation and buffering
issues cause frequent "false failure" diagnoses.

### Terminal Reuse and Stale State

`run_in_terminal` output accumulates in a session: after large-output commands,
subsequent output appends and truncates at ~16KB (foreground) or ~60KB
(background). Long-running terminals also accumulate queued commands — any
commands sent while a blocking operation (`sleep`, `vcf`, ACL2) is active
simply queue and execute back-to-back when it finishes.

Rules:
- After any large-output command, **do NOT reuse** that terminal for queries.
- **Never send commands while a terminal is blocked** — they queue silently.
- Don't send `true` or no-ops to "flush" a blocked terminal — they queue too.
- Redirect results: `cmd > /tmp/r.txt && cat /tmp/r.txt`
- **Preferred**: Use `read_file` on the target log directly.
- For progress polling, use `tail -N` (bounded output).

```bash
# GOOD: isolated, avoids terminal session state
bash -c 'wc -l out_dir/vcf.log; tail -20 out_dir/vcf.log'
```

### Background Process Polling

For long-running processes (solvers, verification, compilations):

1. Launch with `isBackground: true` and `|& tee logfile.log`.
2. Wait with a foreground `sleep N` in a **separate** tool call (don't queue commands).
3. Inspect the **log file** directly after process exits:
   ```bash
   bash -c 'wc -l run.log; tail -5 run.log'
   ```
4. Never rely on `get_terminal_output` for verbose background processes.
5. Combine wait+check in one command: `sleep 120 && grep "done" file.log`
6. See "EDA Tool Logs Echo TCL Source" below before grepping for proof keywords.

### EDA Tool Logs Echo TCL Source — Keyword Grep Pitfalls

Hector/vcf echoes the loaded TCL script verbatim into `vcf.log`, including
all comments.  Grepping for proof-result keywords (`PROVEN`, `FAILED`,
`CONFLICT`) matches comment lines that contain those words, producing
misleading results.

```
# Example false positives from TCL comment echoes:
#   - eq_gmem_cl_addr:  PROVEN without guarantee ...   ← comment, not a result
#   - Single-transaction constraint → CONFLICT ...      ← comment, not a result
```

Rules:
- Use `grep 'Status for proof'` to find actual proof status lines.
- Use `grep -B30 'Status for proof "taskname"'` to get the per-lemma table.
- Never use `grep -i 'PROVEN\|FAILED'` alone for outcome assessment.

### Accidental Command Injection into Interactive Prompts

When a foreground process drops to an interactive prompt (e.g. `vcf>`, `python>>>`,
`acl2 !>`), any subsequent `run_in_terminal` call targeting the same terminal
delivers text directly to that prompt's stdin. The interactive program interprets
the text as its own command, not as a shell command.

**Symptoms**:
- Shell commands like `tcsh`, `bash -c '...'`, or `ls` produce errors like
  `Error: unknown command 'tcsh'` (Tcl/Hector), `NameError` (Python), etc.
- ACL2 sessions abort with `Error: interrupt signal` when commands are sent
  to a terminal where ACL2's `ACL2 !>` prompt is active.
- The interactive program may exit or enter an error state, corrupting the session.
- Subsequent terminal reuse shows stale or broken state.

**ACL2-specific variant**:
ACL2 invoked in foreground mode (e.g., via `make` target without I/O
redirection, or `saved_acl2 < script.lisp` without `isBackground: true`)
enters its REPL prompt. Any command the agent sends to that terminal triggers
CCL interrupt signals, aborting include-book and proof steps mid-flight.

**Prevention**:
- Use `isBackground: true` for any long-running process that might drop to an
  interactive prompt — this prevents the agent from accidentally sending
  follow-up commands to it.
- For ACL2 proof runs, always redirect stdin+stdout+stderr AND background:
  `nohup bash -c 'saved_acl2 < script.lisp > /tmp/out.log 2>&1' &`
- Before reusing a terminal after a foreground command, verify it returned to
  a shell prompt (look for `$`, `%`, or `>` from the shell, not from the tool).
- If a process is stuck at an interactive prompt, send `exit` or the appropriate
  quit command for that tool before attempting any other commands.

**Recovery**:
- After accidental injection, the terminal session may be in an unknown state.
  Prefer launching a fresh terminal for subsequent commands.
- Discard any output directories or artifacts that were being written when the
  injection occurred — they may be incomplete or corrupted.

### Background Output Monitoring

Both truncated-cap (~60KB background) and fully-buffered processes (ACL2, Python,
compilations) produce empty or banner-only terminal output during execution.
This looks identical to failure — it is not.

Anti-pattern: launch → see only banner or empty → conclude failure → retry many times.

Correct approach for ALL background/buffered processes:
- Launch with `isBackground: true, timeout: 0` and redirect to a log file:
  ```bash
  bash -c 'cmd < input > /tmp/out.log 2>&1'
  ```
- Monitor from a **separate** foreground terminal:
  ```bash
  bash -c 'wc -l /tmp/out.log; tail -20 /tmp/out.log'
  ```
- If log is growing (`wc -l` increases), run is in progress — do NOT restart.
- Empty terminal / banner-only is NOT evidence of failure.
- `timeout` must exceed the full process runtime, not just the monitoring sleep.

```bash
# WRONG: tool timeout fires before ACL2 finishes buffering
run_in_terminal("acl2 < script.lisp | tail -80", timeout=120000)

# CORRECT:
run_in_terminal("bash -c 'acl2 < script.lisp > /tmp/out.log 2>&1'", isBackground=true, timeout=0)
# Then in a separate call:
run_in_terminal("sleep 50 && tail -30 /tmp/out.log", timeout=70000)
```

### Alternate Buffer Mode and `get_terminal_output`

Terminal emulators maintain two distinct screen buffers:
- **Normal buffer** (main screen): Has scrollback history. This is what
  `get_terminal_output` reads.
- **Alternate buffer** (alternate screen): A secondary full-screen buffer
  with NO scrollback. Programs switch to it via ANSI escape `ESC[?1049h`
  (`tput smcup`); when the program exits it switches back (`tput rmcup`)
  and the alternate buffer content is discarded.

Programs that always use the alternate buffer: `less`, `man`, `vim`/`nano`,
`top`/`htop`, `watch`, `verdi` (interactive mode), `git log`/`git diff`
when piped to a pager, and any ncurses application.

**Agent-session problem**: `get_terminal_output` captures only the normal
buffer. If a command runs a program in alternate buffer mode, the call
returns nothing for that program's output — it lived in a separate screen
that was cleared on exit. This appears identical to "no output / failure"
and causes the agent to retry needlessly.

Anti-pattern:
```bash
# WRONG: less uses alternate buffer; output gone when it exits
run_in_terminal("cmd | less")
get_terminal_output()  # → empty or stale — NOT evidence of failure
```

Rules:
- Suppress alternate buffer mode by preventing pager use:
  - `git --no-pager log`  or  `git log | cat`
  - `MANPAGER=cat man cmd`  or  `man -P cat cmd`
  - `GIT_PAGER=cat git diff`
  - `LESS='-F -X' less file`  (exit immediately if content fits)
- Redirect output to a file first: `cmd > /tmp/out.txt && cat /tmp/out.txt`
- For EDA tools: always use batch flags (`-batch`, `--batch`) rather than
  interactive modal runs.
- Never invoke bare `less`, `man`, `watch`, or full-screen ncurses tools in
  an agent terminal and expect `get_terminal_output` to capture their output.

### `gcc -E -P` Post-Processing Pitfalls

When a C++ -> C pipeline uses `gcc -E -P` to preprocess retained C into an
ACL2-parseable C subset, system `<stdint.h>` expansion can vary across glibc
versions.

Problem: fragile awk anchors.

Anchoring on `int_fast64_t` to trim stdint boilerplate is brittle:
```bash
gcc -E -P -std=c11 file.c | awk '/int_fast64_t/{found=NR} found && NR>found'
```

This fails because:
- `uint8_t`, `uint32_t`, and `uint64_t` typedefs may appear before
  `int_fast64_t` and get trimmed away.
- Internal typedefs (for example `__intmax_t` / `__uintmax_t`) can appear after
  that anchor and leak into output where they are not standalone-safe.

More robust pattern: anchor on the first line of project code.

```bash
{ printf 'typedef unsigned char      uint8_t;\n';
  printf 'typedef unsigned short     uint16_t;\n';
  printf 'typedef unsigned int       uint32_t;\n';
  printf 'typedef unsigned long long uint64_t;\n';
  gcc -E -P -std=c11 file.c | awk '/^int main/{found=1} found';
} | grep -v '^\s*$' > output.c
```

This approach:
- Anchors on project code instead of libc-specific typedef layout.
- Strips system-header noise deterministically.
- Prepends only the typedefs actually required by the generated subset.
- Is more portable across GCC/Clang and different glibc versions.

---

## 4. Included Scripts

For full documentation of each script see
[references/scripts.md](./references/scripts.md).

| Script | Purpose |
|--------|---------|
| `inspect_lines_utf8.py` | Diagnose Unicode bytes hiding from `replace_string_in_file` |
| `patch_utf8_section.py` | Anchor-based in-place replacement for UTF-8 files |
| `patch_bytemasks.py` | Patch `lsc.hpp` bytemasks struct for Hector DPV |
| `patch_tcl_proc.py` | Replace a complete TCL proc body atomically (brace-depth counting) |
| `add_hector_pitfalls.py` | Template: insert SKILL.md pitfall entries via regex anchor |
| `fix_simcex_call.py` | Template: targeted single-line TCL harness substitution |
| `patch_report_proofstatus.py` | Template: multi-section proof-status update for reports |
| `globalprotect_diagnose.sh` | GlobalProtect VPN diagnostics (bash, macOS) |
| `globalprotect_screenshot_extract.py` | OCR screenshot analyzer for GP UI |
| `run_dpv_regression.csh` | Minimal headless tcsh DPV run template (from dpv/, no FV_MODE) |
| `run_dpv_mode.csh` | Headless DPV run template with FV_MODE for multi-module harness |
| `decode_eml.py` | Extract text/plain from .eml files (handles base64/QP; writes to file to avoid tcsh redirect issues) |

### Quick Usage

```bash
# Unicode byte inspector:
python3 ~/.agents/skills/shell-improvements/inspect_lines_utf8.py FILE.txt START END

# UTF-8 section patcher (copy, configure FILE_PATH / ANCHOR_START / ANCHOR_END / NEW_TEXT):
cp ~/.agents/skills/shell-improvements/patch_utf8_section.py /tmp/p.py && python3 /tmp/p.py

# TCL proc patcher (copy, configure FILEPATH / PROC_NAME / NEW_PROC):
cp ~/.agents/skills/shell-improvements/patch_tcl_proc.py /tmp/p.py && python3 /tmp/p.py

# Report multi-patch (copy, configure REPORT path and change pairs):
cp ~/.agents/skills/shell-improvements/patch_report_proofstatus.py /tmp/p.py && python3 /tmp/p.py

# Bytemasks patch (run from workspace root):
python3 ~/.agents/skills/shell-improvements/patch_bytemasks.py

# VPN diagnostics:
bash ~/.agents/skills/shell-improvements/globalprotect_diagnose.sh [screenshot_path]

# DPV run template (from dpv/, default L2 mode) — copy and adjust out_dir:
cp ~/.agents/skills/shell-improvements/run_dpv_regression.csh /tmp/run_dpv.csh

# DPV run template with FV_MODE (from workspace root) — copy, set FV_MODE, adjust out_dir:
cp ~/.agents/skills/shell-improvements/run_dpv_mode.csh /tmp/run_dpv_mode.csh

# Decode .eml files to plain text (works in tcsh — avoids '>' redirect ambiguity):
# python3 ~/.agents/skills/shell-improvements/decode_eml.py ~/Downloads/FILE1.eml ... [-o /tmp/out.txt]
# Output defaults to /tmp/decoded_emails.txt
python3 ~/.agents/skills/shell-improvements/decode_eml.py ~/Downloads/MY.eml -o /tmp/decoded_emails.txt

# C-subset generator: use Rules.mk in the project (make -f Rules.mk)
# The make-c-subset macro handles gcc -E -P for all hector_retained.c sources.
```

---

---

## 5–10. Extended Reference

Detailed guidance on the following topics lives in
[references/terminal-rules.md](./references/terminal-rules.md):

| Section | Topic |
|---------|-------|
| §5 | TCL File Patching Pitfalls (`$::varname`, Unicode, extra-brace trap) |
| §6 | tcsh-Specific Pitfalls (venv, redirects, heredocs, quoting) |
| §7 | Terminal Focus Traps ("Focus Terminal" blocking — causes + prevention) |
| §8 | UTF-8 / Unicode File Patching (diagnosis, `patch_utf8_section.py` workflow) |
| §9 | Agent Stall Prevention and Session Resilience |
| §10 | References (tcsh/csh details, non-recursive make) |
