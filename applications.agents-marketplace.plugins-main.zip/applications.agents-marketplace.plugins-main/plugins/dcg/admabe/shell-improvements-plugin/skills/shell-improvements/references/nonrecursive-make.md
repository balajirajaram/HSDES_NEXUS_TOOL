# Non-Recursive Make — Reference

## Background

Peter Miller's paper *Recursive Make Considered Harmful* (1998) identified
fundamental problems with the common `$(MAKE) -C subdir` pattern: incomplete
dependency graphs, unnecessary rebuilds, and incorrect build ordering caused by
make only seeing one directory's worth of dependency information at a time.

- **Paper (Recursive Make Considered Harmful)**:
  http://www.tip.net.au/~millerp/rmch/recu-make-cons-harm.html
- **Practical implementation** (van Bergen, 2002) — adds portable directory
  stack and target-specific include paths, which the paper did not address:
  https://web.archive.org/web/20170228223859/evbergen.home.xs4all.nl/nonrecursive-make.html

## Core Problem

Recursive make loses cross-directory dependencies. If `ant/foo.o` depends on
`bee/bar.h`, running `$(MAKE) -C ant` never sees `bee/` and may miss rebuilds.
A single make session with a flat dependency graph solves this, but naïvely
flattening a directory tree breaks relative includes and path portability.

## van Bergen's Solution

Use GNU Make's **target-specific variable assignments** and a **string-based
directory stack** to track `$(d)` (current directory) while including
per-directory `Rules.mk` fragments. This gives each subtree its own `-I` path
and relative file references without requiring absolute paths.

---

## Directory Stack Pattern

Every `Rules.mk` begins and ends with these bookends:

```makefile
# --- Top of Rules.mk ---
sp              := $(sp).x        # push: extend stack pointer
dirstack_$(sp)  := $(d)           # save current dir on stack
d               := $(dir)         # set current dir to incoming value

# ... local rules, all paths prefixed with $(d)/ ...

# --- Bottom of Rules.mk ---
-include        $(DEPS_$(d))      # auto-deps (silently skipped if absent)
d               := $(dirstack_$(sp))  # pop: restore previous dir
sp              := $(basename $(sp))  # decrement stack pointer
```

The `sp` variable grows from empty → `.x` → `.x.x` → ... as nesting deepens,
and shrinks back on the way out.

---

## Top-Level Makefile Skeleton

```makefile
CC       = gcc
CF_ALL   = -g -Wall
COMP     = $(CC) $(CF_ALL) $(CF_TGT) -o $@ -c $<
LINK     = $(CC) $(LF_ALL) $(LF_TGT) -o $@ $^ $(LL_TGT) $(LL_ALL)

.SUFFIXES:
.SUFFIXES: .c .o

all: targets

# Include top-level Rules.mk, which chains subdirectory fragments
dir := .
include $(dir)/Rules.mk

# Generic pattern rules — CF_TGT is set per-target by Rules.mk fragments
%.o: %.c
	$(COMP)

.PHONY: targets clean
targets: $(TGT_ALL)
clean:
	rm -f $(CLEAN)

# Prevent make from deleting intermediate build artifacts
.SECONDARY: $(CLEAN)
```

---

## Per-Directory Rules.mk (with subdirs and objects)

```makefile
# Standard things
sp              := $(sp).x
dirstack_$(sp)  := $(d)
d               := $(dir)

# Include subdirectories first (they add to TGT_ALL, CLEAN, etc.)
dir := $(d)/subdir
include $(dir)/Rules.mk

# Local objects and auto-dep files
OBJS_$(d) := $(d)/foo.o $(d)/bar.o
DEPS_$(d) := $(OBJS_$(d):%=%.d)

# Add to global lists
TGT_ALL := $(TGT_ALL) $(d)/mylib.a
CLEAN   := $(CLEAN) $(OBJS_$(d)) $(DEPS_$(d)) $(d)/mylib.a

# Target-specific include path: adds -I<thisdir> for all objects here
$(OBJS_$(d)): CF_TGT := -I$(d)

# Rules
$(d)/mylib.a: $(OBJS_$(d))
	$(AR) rcs $@ $^

# Standard things
-include $(DEPS_$(d))
d  := $(dirstack_$(sp))
sp := $(basename $(sp))
```

---

## Key Constraints

- Requires **GNU Make >= 3.79** (target-specific variable assignments).
- All paths in `Rules.mk` fragments must be relative to the **project root**
  via `$(d)`. Never embed absolute paths.
- The stack trick relies on `$(basename)` stripping `.x` suffixes; `sp` must
  only ever have `.x` appended — do not use `.` or `/` in the suffix.
- Use `-include` (with leading dash) for auto-generated `.d` dependency files
  so make silently skips them on the first build when they don't exist yet.

---

## Referencing Other Directories

Files in other directories must be referenced from the project root:

```makefile
$(TGTS_$(d)): LL_TGT := $(S_LL_INET) common/common.a
$(TGTS_$(d)): $(d)/main.c common/common.a
	$(COMPLINK)
```

To reference a sibling relative to the current directory: `$(d)/../common/common.a`.
This is acceptable for closely related modules, but prefer root-relative paths
for clarity in larger trees.
