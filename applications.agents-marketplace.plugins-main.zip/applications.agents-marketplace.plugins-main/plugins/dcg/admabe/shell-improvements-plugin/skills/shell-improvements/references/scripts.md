# Shell-Improvements Skill — Included Scripts Reference

Full documentation for all scripts bundled with the shell-improvements skill.
For quick usage see the `## 4. Included Scripts` table in `SKILL.md`.

---

## inspect_lines_utf8.py

Diagnoses why `replace_string_in_file` fails with "Could not find matching
text" on files containing Unicode characters (em-dash U+2014, section sign
U+00A7, arrow U+2192, curly quotes).  Prints `repr()` of each line so hidden
multi-byte characters are visible as `\uXXXX` sequences.

```bash
python3 ~/.agents/skills/shell-improvements/inspect_lines_utf8.py \
    report_wrapper_cmodel_connections.txt 438 452
# Example output:
# 441: '    9.11 Multi-transaction\u2014coverage gap\n'
#      ← \u2014 (em-dash) is what broke the match
```

See `## 7. UTF-8 / Unicode File Patching` in `SKILL.md` for the full
diagnosis+patch workflow.

---

## patch_utf8_section.py

Template for replacing a section of any UTF-8 text file using anchor-string
search + line-index replacement — the correct approach when
`replace_string_in_file` fails due to Unicode content.

**Configure three variables at the top**:
```python
FILE_PATH    = "report_wrapper_cmodel_connections.txt"
ANCHOR_START = "9.11 Multi-transaction inductive"   # unique first line of region
ANCHOR_END   = "coverage gap identified in"          # unique last line of region
NEW_TEXT = (
    "    9.11 Multi-transaction inductive closure\n"
    "    ...new content...\n"
    # Use \u00a7 for §, \u2014 for —, \u2192 for → in string literals
)
```

```bash
cp ~/.agents/skills/shell-improvements/patch_utf8_section.py /tmp/mypatch.py
# (edit FILE_PATH, ANCHOR_START, ANCHOR_END, NEW_TEXT)
python3 /tmp/mypatch.py
# Output: File has 745 lines
#         Replacing lines 441-487 (47 lines)
#         Done: file now 699 lines
```

**Key rules for NEW_TEXT**:
- Always end each line with `\n` — missing newline merges with the next line.
- Use `\uXXXX` escapes inside Python string literals for non-ASCII characters.
- Preserve indentation — the patcher does no reformatting.

---

## patch_bytemasks.py

Patches `cmodel/include/lsc/lsc.hpp` to replace the `std::vector<bytemask_t>`
typedef (or a basic struct placeholder) with a fixed-size struct, enabling
cmodel compilation under Hector DPV (which cannot handle dynamic containers).

Upgrades the bytemasks structure to a 512-element array with `size()`,
`insert()`, and tracked size (`sz` member), supporting the cmodel's
`insert(end(), ...)` pattern for multi-CL walks.  Robustly replaces either
the original STL vector declaration or a simplified 64-element interim struct.

```bash
# Run from workspace root:
python3 ~/.agents/skills/shell-improvements/patch_bytemasks.py
```

The script reads and writes `cmodel/include/lsc/lsc.hpp` relative to the
current directory.

`patch_bytemasks_full.py` is a variant that patches the full 512-element
struct from scratch; use if `patch_bytemasks.py` fails due to a very old
baseline.

---

## patch_tcl_proc.py

Template for replacing a complete proc body in a TCL file.  Use this when
`replace_string_in_file` fails on TCL files containing `$::varname` sequences,
Unicode in comments, or long multi-line expressions.

**Configure three variables at the top**:
```python
FILEPATH  = "/path/to/fv_cm_access.tcl"
PROC_NAME = "check_elmt_guarantee"
NEW_PROC  = """proc check_elmt_guarantee {} {
    ...full proc body...
}"""
```

```bash
cp ~/.agents/skills/shell-improvements/patch_tcl_proc.py /tmp/mypatch.py
# Edit FILEPATH, PROC_NAME, NEW_PROC at the top
python3 /tmp/mypatch.py
# Verify:
grep -n "proc check_elmt_guarantee" fv_cm_access.tcl
```

**How it works**: finds the proc by name via regex, locates its brace-matched
closing `}`, and replaces the entire proc body atomically.  Caveats: does not
handle nested proc definitions; the closing `}` detection counts brace levels.

See `## 8. TCL File Patching Pitfalls` in `SKILL.md` for when to use this
and for the extra-close-brace trap explanation.

---

## add_hector_pitfalls.py

One-time script (already applied) that added pitfalls 13–16 to
`~/.agents/skills/hector-dpv/SKILL.md`.  Retained as a reusable template
showing how to inject numbered pitfall entries into a SKILL.md using a
regex-anchor search strategy: locate a known anchor line (e.g., `INDCEX-010`),
then insert the new block immediately before the next major section separator.

```bash
cp ~/.agents/skills/shell-improvements/add_hector_pitfalls.py /tmp/add_pitfalls.py
# Edit FILE_PATH, ANCHOR_LINE, and NEW_BLOCK at the top, then:
python3 /tmp/add_pitfalls.py
```

**Pattern**: open file → find anchor → compute insert position (line after anchor
or before next `---`) → splice in NEW_BLOCK → write file.  Safe for files with
Unicode because it works on the full file as a string, not line-by-line diffs.

---

## fix_simcex_call.py

One-time script (already applied) that removed the spurious proof-name
positional argument from the `simcex` call in `fv_cm_access.tcl`, fixing
CMD-012 (positional arg error).  Retained as a compact template for making
a single targeted line-level substitution in a TCL harness file without
invoking `replace_string_in_file` (which fails on TCL `$::varname` content).

```bash
cp ~/.agents/skills/shell-improvements/fix_simcex_call.py /tmp/fix_harness.py
# Edit FILE_PATH, OLD_LINE, and NEW_LINE at the top, then:
python3 /tmp/fix_harness.py
```

**Pattern**: read file → `content.replace(OLD_LINE, NEW_LINE, 1)` → assert
exactly one replacement occurred → write file.  Simple and safe for
line-granularity fixes.

---

## patch_report_proofstatus.py

Template demonstrating how to apply multiple independent text substitutions
to a proof report in a single script run.  Each substitution is defined as an
`(OLD, NEW)` string pair; the script applies them in order, reporting line
deltas and failing loudly if any OLD string is not found or is ambiguous.

Use this pattern when updating a report whose sections reference obsolete proof
status (e.g., changing `FAILED` annotations to `PROVEN` across multiple
sections after a lemma is resolved).

```bash
cp ~/.agents/skills/shell-improvements/patch_report_proofstatus.py /tmp/p.py
# Edit REPORT path and the (OLD, NEW) pairs in the `changes` list at the top
python3 /tmp/p.py
```

**What each change entry looks like**:
```python
changes = [
    ("Change 1 label", OLD_TEXT_1, NEW_TEXT_1),
    ("Change 2 label", OLD_TEXT_2, NEW_TEXT_2),
    # ...
]
```

For each entry: verifies OLD appears exactly once, replaces with NEW, prints
label + line delta.  Aborts with a clear error if any match fails.

---

## globalprotect_diagnose.sh

Runs 5 comprehensive diagnostic phases to identify GlobalProtect VPN
connection issues on macOS.

```bash
bash ~/.agents/skills/shell-improvements/globalprotect_diagnose.sh [screenshot_path]
```

**Diagnostic phases**:
1. **Network Connectivity** — Wi-Fi/Ethernet IP, DNS resolution, portal reachability
2. **Client State** — GP processes, tunnel interfaces, launchd daemon, recent logs
3. **Certificates & Auth** — System clock sync, Keychain certs, cache age
4. **DNS & Routing** — Internal hostname resolution, VPN routes, DNS servers
5. **System Health** — CPU/memory pressure, uptime, pending OS updates

**Output**: color-coded ✓/✗/⚠ per check, priority-ordered fix suggestions,
exit code 0 (all pass) or 1 (failures).

**Customization** — edit the configuration section at the top of the script:
- `VPN_PORTAL` — change from `vpn.intel.com` to your org's portal
- `EXTERNAL_DNS` — change from `8.8.8.8` to your DNS
- `INTERNAL_HOST` — change from `eclogin.intel.com` to an internal hostname
- `PING_TIMEOUT`, `DNS_TIMEOUT` — adjust for slow networks

**To invoke from tcsh**:
```tcsh
bash ~/.agents/skills/shell-improvements/globalprotect_diagnose.sh
# Or create an alias:
alias gp-diagnose 'bash ~/.agents/skills/shell-improvements/globalprotect_diagnose.sh'
```

**Graceful degradation**: runs all checks if `globalprotect_screenshot_extract.py`
is unavailable; individual checks skip missing macOS-native tools.

---

## globalprotect_screenshot_extract.py

Extracts diagnostic info from a GlobalProtect UI screenshot using OCR.

```bash
python3 ~/.agents/skills/shell-improvements/globalprotect_screenshot_extract.py ~/Downloads/Screenshot.png
```

**Prerequisites**:
```bash
pip3 install Pillow pytesseract
brew install tesseract
```

**Output**: JSON with connection status, portal URL, gateway address, error
messages, visible UI elements (buttons, 2FA prompts), and OCR confidence notes.

Used automatically by `globalprotect_diagnose.sh` when both the script and its
Python dependencies are available.  Falls back gracefully when unavailable.

---

## gen_c_subsets.py

Template for generating ACL2-parseable `c_subset.c` files from
`hector_retained.c` sources via `gcc -E -P`.  Implements the second step of
the C++ → C → ACL2 pipeline:

```
hector_retained.c  (C11 + Hector macro stubs)
    │  (gcc -E -P: expand macros, strip directives)
    ▼
c_subset.c  (pure C11, ACL2-parseable, no # directives)
```

See `## gcc -E -P Post-Processing Pitfalls` in `SKILL.md` for why the anchor
strategy uses `int main` rather than a libc-specific typedef symbol.

**Configure three variables at the top**:

```python
WORKDIR = "/path/to/workspace"   # os.chdir() is called here

TYPEDEF_LINES = """\
typedef unsigned char      uint8_t;
...
"""

FILES = [
    ("cm_wrapper_ro_dis_hector_retained.c", "cm_wrapper_ro_dis_c_subset.c"),
    ("cm_wrapper_slmR_hector_retained.c",   "cm_wrapper_slmR_c_subset.c"),
    # ... add or remove pairs as needed
]
```

```bash
cp ~/.agents/skills/shell-improvements/gen_c_subsets.py /tmp/gen.py
# Edit WORKDIR and FILES at the top, then:
python3 /tmp/gen.py
# Output per file: "<dst>: N lines, compile=OK"
```

**What it does per file**:
1. Runs `gcc -E -P -std=c11 <src>` — expands all `#include` / `#define` / macros,
   strips all preprocessor line markers.
2. Anchors output on the first line starting with `int main` — discards all
   preceding system-header expansion noise.
3. Strips blank lines.
4. Prepends `TYPEDEF_LINES` (four fixed-width integer typedefs).
5. Checks brace balance and warns if non-zero.
6. Writes `<dst>` and verifies it compiles cleanly with
   `gcc -c -std=c11 <dst> -o /dev/null`.

**When to use vs. `Rules.mk`**: `Rules.mk` automates this pipeline for the
L2-read AGU wrapper (`cm_wrapper.cpp`) using the same strategy.  Use
`gen_c_subsets.py` for the manually-maintained wrappers (`ro_dis`, `slmR`,
`slmW`) when you want a quick one-shot regeneration without invoking `make`.

---

## run_dpv_regression.csh

Minimal headless tcsh DPV run script for running an existing harness from the
`model/src/units/admabe/formal/dpv/` directory (regression validation).

```tcsh
#!/bin/tcsh -f
setenv EC_DISABLE_VAL 1
setenv DISPLAY ""
setenv QT_QPA_PLATFORM offscreen
source /nfs/site/disks/sc6_mpmehta/dpv_setup_ww44_2025
cd /path/to/model/src/units/admabe/formal/dpv
vcf -batch -f fv_cm_access.tcl -fmode DPV -fml_elite -out_dir out_dir_name
```

**Usage**: copy to `/tmp/`, adjust `cd` path and `out_dir`, then run via background
terminal (`isBackground: true`) — never write this with `printf '#!/...'` because
the `!` triggers "Event not found" in interactive tcsh. Always use `create_file`
tool.

---

## run_dpv_mode.csh

Headless DPV run script with `FV_MODE` environment variable for multi-module
harnesses.  Set `FV_MODE` to `slmR`, `slmW`, or `l2_ro_en` (default) to select
which AGU module to verify.

```tcsh
#!/bin/tcsh -f
setenv EC_DISABLE_VAL 1
setenv DISPLAY ""
setenv QT_QPA_PLATFORM offscreen
setenv FV_MODE slmR       # <-- change to slmW, l2_ro_en, etc.
source /nfs/site/disks/sc6_mpmehta/dpv_setup_ww44_2025
cd /path/to/workspace_root
vcf -batch -f fv_cm_access.tcl -fmode DPV -fml_elite -out_dir out_dir_slmR_v1
```

**Usage**: copy to `/tmp/`, set `FV_MODE` and `out_dir`, run via background
terminal.  Same `create_file` caveat as `run_dpv_regression.csh`.
