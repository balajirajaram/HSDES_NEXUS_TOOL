# tcsh/csh Reference for Shell Improvements

Detailed tcsh/csh-specific guidance moved out of SKILL.md to keep progressive loading fast.

## 1. tcsh vs bash Syntax

The default shell on these machines is tcsh. Bash-syntax commands fail
silently or trigger CORRECT prompts that block the terminal.

> **`2>&1`, `$()`, and inline env var assignment (`KEY=val cmd`) are not
> supported in tcsh.** The following three patterns fail silently or raise
> errors in tcsh.
>
> **Pattern 1 — Command substitution `$(...)`**
> tcsh raises `Undefined variable.` / `Illegal variable name.`:
> ```tcsh
> # WRONG — tcsh treats $(cmd) as empty-variable expansion:
> set x = $(git rev-parse HEAD)   # → tcsh: HEAD: Undefined variable.
> set x = $(date)                 # → tcsh: date: Undefined variable.
>
> # CORRECT — backticks in tcsh:
> set x = `git rev-parse HEAD`
> set x = `date`
>
> # CORRECT — wrap in bash when bash syntax is unavoidable:
> set x = `bash -c 'echo $(date +%s)'`
> ```
>
> **Pattern 2 — Stderr redirect `2>&1`**
> tcsh treats `2>&1` as literal tokens; `2` goes to stdout and `>1` is
> interpreted as a filename target.  Background `cmd > f 2>&1 &` also
> fails with "Ambiguous output redirect.":
> ```tcsh
> # WRONG — bash-specific fd syntax:
> make 2>&1 | tee build.log   # stderr not merged; &1 is filename
> cmd > out.log 2>&1 &        # Ambiguous output redirect.
>
> # CORRECT — tcsh combined redirect >&:
> make |& tee build.log       # merge stdout+stderr into pipe
> cmd >& out.log              # both to file
> cmd >& out.log &            # both to file, backgrounded
>
> # CORRECT — wrap in bash for full fd control:
> bash -c 'cmd > out.log 2>&1'
> bash -c 'cmd > out.log 2>&1 &'   # all redirects inside the bash string
> ```
>
> **Pattern 3 — Inline env var assignment `KEY=val cmd`**
> tcsh does not support shell-level `KEY=val cmd`; this is bash-specific.
> tcsh raises `KEY=val: Command not found.`:
> ```tcsh
> # WRONG:
> DEBUG=1 make all        # → tcsh: DEBUG=1: Command not found.
> DISPLAY="" vcf -batch   # → tcsh: DISPLAY=: Command not found.
>
> # CORRECT — env(1) passes variables inline without tcsh involvement:
> env DEBUG=1 make all
> env DISPLAY="" QT_QPA_PLATFORM=offscreen vcf -batch -f fv.tcl
>
> # CORRECT — setenv for persistent assignment, then run:
> setenv DEBUG 1
> make all
> unsetenv DEBUG          # clean up afterward if needed
>
> # CORRECT for multiple vars in a subshell:
> bash -c 'DEBUG=1 VERBOSE=1 make all'
> ```

Rules:
- **`$(...)` command substitution**: use backticks (`` `cmd` ``) or `bash -c`.
  Never use `$()` directly in tcsh.
- **`2>&1` stderr redirect**: use `|&` in tcsh to merge to a pipe, `>& file`
  to merge to a file.  For background jobs, all redirects go inside a
  `bash -c '...'` string.  Never place `2>&1` outside the `bash -c` string.
- **Inline env var assignment (`KEY=val cmd`)**: use `env KEY=val cmd` or
  `setenv KEY val; cmd`.  Never use bare `KEY=val cmd` in tcsh.
- `for x in ...; do ... done`: use `foreach x (...) ... end` in tcsh.
- `[[ ... ]]` is not supported in tcsh.
- If a vendor setup script is tcsh-only, prefer a bash-friendly variant when
  one exists instead of forcing the entire workflow through tcsh.

Quick reference:

| Feature | bash | tcsh |
|---------|------|------|
| Command substitution | `$(cmd)` | `` `cmd` `` |
| For loops | `for x in ...; do ... done` | `foreach x (...) ... end` |
| Variable assignment | `VAR=val` | `set VAR = val` / `setenv VAR val` |
| Stderr redirect | `2>&1` | `|&` (pipe both) |
| Suppress stderr only | `cmd 2>/dev/null` | `bash -c 'cmd 2>/dev/null'` |
| Redirect both to file | `cmd &>file` | `cmd >& file` |
| Conditionals | `[[ expr ]]` | `if (expr) then` |
| Glob no-match behavior | Passes literal | Aborts with "No match." |

## 2. tcsh Glob Failures

In tcsh, unmatched globs abort the entire command line.

Rules:
- Wrap in bash: `bash -c 'rm -rf path/PIL path/Pillow*'`
- Or set nonomatch: `set nonomatch; rm -rf path/Pillow*`
- Never chain critical operations after a potentially-unmatched glob.

## 3. Python Heredocs in tcsh

Multi-line Python via heredoc (`<< 'EOF'`) does not work reliably in tcsh.

Rules:
- Write the script to a file first, then run `python3 /tmp/script.py`.
- Avoid nested quoting in `bash -c` when the payload is complex.
- Avoid large multi-line `python3 -c` payloads in tcsh.

## 4. tcsh Redirects and I/O Patterns

tcsh does not support bash fd redirects like `2>/dev/null`.

Rules:
- Use `|&` to merge stdout+stderr, then filter.
- Or wrap command in bash for fd-level redirects.
- `>& /dev/null` redirects both stdout and stderr in tcsh.

Important:
- Tool simplification may inject bash-style redirects in pipes.
- Prefer `cmd |& head` in tcsh, or wrap full pipeline in `bash -c`.

## 5. CORRECT Prompt Traps

tcsh auto-correct can block terminals with interactive CORRECT prompts.

Rules:
- If CORRECT appears, treat terminal as blocked for automation.
- Start a fresh terminal instead of reusing the stuck session.
- Prevention: use exact command paths and avoid typo-prone commands.

## 6. Background Jobs and SIGTTOU in tcsh

`cmd |& tee log &` in tcsh can suspend with tty output signals.  Even
`nohup cmd >& log &` suspends — tcsh registers background jobs with the
controlling terminal.

**What works: direct background with `>& file &`**

A plain `cmd >& file &` (without `nohup`) reliably backgrounds a command in
tcsh.  The combined `>&` redirect keeps stdout+stderr in the file; `&` hands
the job to background.  This is the recommended pattern for long-running
tools (ACL2 proofs, vcf runs, etc.):

```tcsh
# CORRECT: direct background with tcsh combined redirect
~/disk2/git/acl2/saved_acl2 --no-init < script.lisp >& /tmp/proof.log &
echo "Started PID $!"    # prints PID immediately; no blocking
```

**What fails: pipelines, nohup, or bash-style 2>&1**

Rules:
- `cmd | filter &` and `cmd |& tee log &` fail with "Ambiguous output redirect"
  because the pipeline and `&` clash in tcsh's job control.
- `nohup cmd >& log &` also triggers "Ambiguous output redirect" or SIGTTOU.
- `cmd > file 2>&1 &` fails — `2>&1` is bash syntax; tcsh cannot apply it.
- Do not combine `isBackground: true` with shell `&`.

Symptom:
- `Suspended (tty output)` (job stopped by tcsh job control)
- `Ambiguous output redirect.` (tcsh interpretation of pipeline or nohup + `>& file &`)

When you need piped filtering, wrap in bash:
```tcsh
# CORRECT for pipelines: bash subshell escapes tcsh job control
bash -c 'cmd | tail -20 > out.log 2>&1 &'
```

```tcsh
# WRONG: pipeline + & in outer tcsh
cmd | tail -20 > out.log &
# → tcsh: Ambiguous output redirect.

# WRONG: nohup causes Ambiguous in tcsh
nohup cmd >& out.log &
# → tcsh: Ambiguous output redirect.

# WRONG: bash redirect syntax in tcsh
cmd > out.log 2>&1 &
# → tcsh: Ambiguous output redirect.
```

## 7. tcsh Variable Expansion and Bash Substitution

In tcsh-heavy environments, bash-style substitution used in mixed TCL/shell
contexts can trigger errors like `Illegal variable name`.

Rules:
- Wrap complex substitutions in explicit bash when needed.
- Prefer TCL-native `file` commands inside TCL scripts.
- Pre-compute complex values and pass through environment if needed.

## 8. TCL Path Normalization for tcsh-hosted Flows

Prefer TCL-native path APIs over shell path gymnastics.

Correct pattern:

```tcl
set WORKDIR [get_app_dir]
set MODEL   [file normalize $WORKDIR/../../../../../]
set CMODEL  [file normalize $WORKDIR/../../../../../../cmodel]
```

Use `file normalize`, `file join`, and `file dirname`.

## 9. Headless Display Configuration

Some EDA tools still initialize GUI stacks in batch mode.

Recommended environment:

```tcsh
setenv DISPLAY ""
setenv QT_QPA_PLATFORM offscreen
```

Then run the tool with batch flags.

Notes:
- Set both variables defensively; tool versions vary.
- If failures persist, verify tool-build/system compatibility.

## 10. Stable vs Nightly Setup Scripts

Known scripts:
- Stable tcsh setup: `/nfs/site/disks/sc6_mpmehta/dpv_setup_ww44_2025`
- Bash-friendly nightly: `/nfs/site/disks/sc6_mpmehta/dpv_setup_ww19_2026`

Use stable by default, switch to nightly when bash compatibility is required.

## 11. Multiline Commands in `bash -c` from tcsh

When running `bash -c '...'` from a tcsh terminal, backslash line
continuations (`\`) do NOT work as expected — tcsh interprets them before
bash sees the string.

### Problem

```bash
# WRONG: tcsh parses the backslashes, bash sees separate commands
bash -c 'cd /path && rm -rf \
  dir1 \
  dir2 && echo done'
# Result: "dir1: command not found", "dir2: command not found"
```

### Solution: put everything on one line, or use semicolons

```bash
# CORRECT: single line
bash -c 'cd /path && rm -rf dir1 dir2 dir3 && echo done'

# CORRECT: semicolons inside the string
bash -c 'cd /path; rm -rf dir1 dir2 dir3; echo done'
```

If the command is too long for one line, break it into multiple
`run_in_terminal` calls (one per batch) instead of trying to use
backslash continuation inside `bash -c`.

## 12. Redirect Ordering: `2>&1` After `&` in tcsh

When launching a background command from tcsh using `bash -c '...' 2>&1 &`,
tcsh processes the `2>&1` redirect at the outer shell level **after** `&`
has already backgrounded the job.  This produces an "Ambiguous output
redirect" error.

```tcsh
# WRONG from tcsh: 2>&1 is outside the bash -c string; tcsh cannot apply it
bash -c 'cmd > /tmp/out.log' 2>&1 &
# → tcsh: Ambiguous output redirect.
```

```tcsh
# CORRECT: all redirects go inside the bash -c string
bash -c 'cmd > /tmp/out.log 2>&1 &'
```

Or use `isBackground: true` in `run_in_terminal` and omit shell `&`:
```bash
bash -c 'cmd > /tmp/out.log 2>&1'   # no trailing &; isBackground:true handles it
```

## 13. git commit -m Multi-line Messages in tcsh

tcsh parses the entire commit message string before git sees it.
Shell metacharacters inside `-m "..."` — parentheses `()`, arrows `→`,
em-dashes `—`, bullet hyphens at line-start, and Unicode characters —
all trigger errors like `Unmatched '"'` or `Too many ('s`.

```tcsh
# WRONG: tcsh metacharacters in -m cause parse failures
git commit -m "Section 9.11 -- merged eq_minfo_dmin0 (read AGU)"
# → tcsh: Unmatched '"'.  or: Too many ('s.
```

Fix: write the message to a temp file and use `git commit -F`:

```tcsh
# CORRECT: bypass tcsh parsing entirely
cat > /tmp/commit_msg.txt << 'EOF'
Subject line (plain ASCII is safest for the subject)

- Unicode and parentheses are fine inside a heredoc
- tcsh does not re-parse token content after <<
EOF
git commit -F /tmp/commit_msg.txt
```

Alternatively, use the `create_file` tool to write `/tmp/commit_msg.txt`
directly (no shell parsing at all), then run `git commit -F /tmp/commit_msg.txt`.

## 14. tcsh vs bash Loop Mismatch

In tcsh terminals, bash loop syntax triggers parser prompts such as
`CORRECT> ... (y|n|e|a)?` and then fails with `for: Command not found` or
`Undefined variable`.

Use one of these patterns:

```tcsh
# Native tcsh loop
foreach d (out_dir_a out_dir_b)
  if ( -f $d/vcf.log ) then
    wc -l $d/vcf.log
    tail -n 40 $d/vcf.log
  endif
end
```

```bash
# Explicit bash wrapper from tcsh
bash -c 'for d in out_dir_a out_dir_b; do
  if [[ -f "$d/vcf.log" ]]; then
    wc -l "$d/vcf.log"
    tail -n 40 "$d/vcf.log"
  fi
done'
```

## 15. `!` History Expansion in Interactive tcsh

In interactive tcsh, `!` is a history-expansion character even inside
single-quoted strings passed to `echo`.  Shell patterns like
`echo '#!/bin/tcsh'` generate:

```
tcsh: Event not found.
```

The standard `echo '...'` idiom for creating script files DOES NOT work in
interactive tcsh when the string contains `!`.

**`printf` is also affected** in the agent's VS Code tcsh terminal environment:
`printf '#!/bin/tcsh -f\n...'` also triggers "Event not found" because tcsh
expands `!` in the argument string before `printf` executes (observed in
tcsh 6.22 on Intel infra, despite the general rule that `printf` avoids
history expansion in many tcsh builds).

Rules:
- **Always use the `create_file` tool** to write script files that contain
  a shebang (`#!/`) or any other `!` character — it bypasses shell parsing
  entirely.
- Do not rely on `printf` to escape `!` in interactive tcsh agent terminals.
- If `echo` is unavoidable, escape the `!`: `echo '\!/bin/tcsh'`
  (backslash before `!` suppresses expansion in most tcsh versions).
- `printf` without `!` still works correctly for other multi-line content.

## 16. Heredocs (`<< 'EOF'`) Cause Focus Traps in tcsh

tcsh handles `<<` (here-documents) differently from bash.  In interactive
tcsh, `cat << 'EOF'` often leaves the terminal waiting for the close-
delimiter in a way the VS Code terminal integration interprets as
"The terminal is awaiting input."  This triggers a focus trap that blocks
the entire agent session.

Symptom:
```
The terminal is awaiting input.
chmod +x run_dpv_tests.csh Please provide the required input to the terminal.
```

The agent sent a multi-line heredoc command to a tcsh terminal.  tcsh
entered its heredoc-reading mode, but subsequent commands (like `chmod`)
were queued and interpreted as heredoc content, producing a confusing
focus-trap message.

Rules:
- NEVER use `cat << 'EOF' ... EOF` in commands sent to a tcsh terminal.
- Use the `create_file` tool to write multi-line script content — it
  bypasses shell parsing entirely and is always safe.
- If shell-based file creation is absolutely needed, use `printf` with
  explicit `\n` escapes on a SINGLE line, or multiple `echo` calls
  (watching for `!` history expansion per §15).

```tcsh
# WRONG: heredoc in tcsh terminal causes focus trap
cat << 'EOF' > run_tests.csh
#!/bin/tcsh -f
setenv DISPLAY ""
vcf -batch -f test.tcl
EOF

# CORRECT: use create_file tool (no shell involvement)
# Or from bash subshell:
bash -c 'cat > run_tests.csh << '\''EOF'\''\n#!/bin/tcsh -f\nsetenv DISPLAY ""\nvcf -batch -f test.tcl\nEOF'
```

Preferred approach: **always use the `create_file` tool** for multi-line
script content.  It is simpler, safer, and avoids all tcsh parsing issues.
