# Shell Improvements — Extended Terminal Rules Reference

Detailed reference for the shell-improvements skill.
Loaded on demand when specific topics are needed.

See the skill index in `SKILL.md` for quick rules and script reference.

---

## 5. TCL File Patching Pitfalls

`replace_string_in_file` fails silently ("Could not find matching text") on TCL
files for two distinct reasons:

### Reason 1 — `$::varname` sequences

TCL files use `$::varname` for global variable interpolation (e.g. `$::obs`,
`$::stim`).  These are valid Python string content, but constructing a
multi-line oldString that contains them is error-prone because:
- The tool builds a byte-exact match; any whitespace difference causes failure.
- Long UAL expressions span many lines, making multi-line matching fragile.
- Adding/removing lines around the target changes line context between
  iterations.

### Reason 2 — Unicode in comments

TCL harness comments frequently contain Unicode characters copied from docs
(em-dash U+2014 `—`, arrow U+2192 `→`, section sign U+00A7 `§`).
These cause the same "Could not find matching text" failure as in other files
(see §8 for diagnosis).

### When to use `patch_tcl_proc.py`

Use `patch_tcl_proc.py` instead of `replace_string_in_file` when:
- You need to replace an **entire proc body** (the most common DPV case).
- The proc contains `$::varname` expressions or Unicode.
- You've already had `replace_string_in_file` fail once on the file.

```bash
cp ~/.agents/skills/shell-improvements/patch_tcl_proc.py /tmp/p.py
# Set FILEPATH, PROC_NAME, NEW_PROC at the top of the file
python3 /tmp/p.py
# Verify:
grep -n "proc check_elmt_guarantee" fv_cm_access.tcl
```

### Extra close-brace trap

When `replace_string_in_file` IS used to add lines before the closing `}` of
a proc, a common mistake is including the `}` in both oldString and newString,
resulting in `}}` in the output.  Hector's TCL interpreter reports:

```
Error: extra characters after close-brace (CMD-013)
script 'file.tcl' stopped at line N due to error. (CMD-081)
```

**Fix**: use `patch_tcl_proc.py` to replace the full proc, avoiding the need
to reason about closing braces.

If `replace_string_in_file` must be used, omit the closing `}` from both
oldString and newString, and target a unique line several lines before `}`.

---

## 6. tcsh-Specific Pitfalls (Summary)

For full details on tcsh syntax, quoting, multiline `bash -c`, redirect
ordering, and `git commit -m` issues, see the
[tcsh/csh reference](./references/tcsh-csh.md).

### venv activate bash/tcsh incompatibility

`source .venv/bin/activate` from tcsh fails with "Badly placed ()'s." because
tcsh cannot parse bash's `deactivate () {` function definition syntax.

**Fix in activate (bash)**: change `deactivate () {` to `function deactivate {`
(removes the `()`, still valid bash, avoids tcsh parse error).

Also check `activate.csh` for:
1. Wrong VIRTUAL_ENV path (old workspace path hard-coded)
2. `set _OLD_VIRTUAL_PROMPT="$prompt"` — fails in non-interactive tcsh (`$prompt: Undefined variable`).
   Fix: `if ($?prompt) set _OLD_VIRTUAL_PROMPT="$prompt"`

### tcsh vs bash redirection and quoting

Do not assume bash syntax works when the active shell is tcsh.

Common failures:
- `2>/dev/null` or mixed redirection forms produce `Ambiguous output redirect.`
- bash arrays, `shopt`, and some here-doc quoting patterns are misparsed.
- malformed loops or quoted commands trigger tcsh's `CORRECT>` prompt, which
  stalls automation and can corrupt follow-up commands sent to the same terminal.

Rules:
- If a command needs bash features, run it explicitly via `/bin/bash -lc '...'`.
- Keep tcsh one-liners simple; avoid inline `for` loops, here-docs, and mixed redirects.
- After any `CORRECT>` prompt or quoting failure, abandon that terminal for the task
  unless you have explicitly returned it to a clean shell prompt.

### Partial multi-replace failures on UTF-8 files

`multi_replace_string_in_file` can partially succeed: some replacements apply,
then a later one fails because the file contains Unicode punctuation or because
an earlier replacement changed the surrounding context.

Rules:
- After any partial multi-replace failure, immediately re-read the affected region
  before issuing another batch replacement.
- For files with Unicode comments (`—`, `→`, `§`) or long exact-match blocks,
  prefer smaller replacements or use the UTF-8 helpers (`inspect_lines_utf8.py`,
  `patch_utf8_section.py`).
- If one replacement removes a block that later replacements depend on, split the
  edit into ordered steps instead of one large batch.

Quick reminders:
- Backslash line continuations inside `bash -c '...'` break in tcsh — put
  everything on one line or use semicolons.
- **`2>&1` with `&` or `&&` at the tcsh level** causes "Ambiguous output redirect" —
  move ALL redirects inside the `bash -c '...'` string:
  `bash -c 'cmd1 && cmd2 > /tmp/out.txt 2>&1'`
- `echo '...!'` in interactive tcsh triggers "Event not found" (history expansion).
  Use the `create_file` tool to write script files that contain `!`.
- **`printf '#!/...'` also triggers "Event not found"** in the agent's tcsh
  environment — the shell expands `!` before `printf` runs.
  **Always use `create_file` tool** for content that includes `#!/` or any `!`.
- `nohup cmd >& log &` in interactive tcsh still suspends (SIGTTOU). Fix:
  `bash -c 'nohup ./script > log 2>&1 &'`. See
  [tcsh-csh §6](./references/tcsh-csh.md#6-background-jobs-and-sigttou-in-tcsh).
- `git commit -m` with parentheses/Unicode fails — use `git commit -F file`.
- `for ...; do ...; done` is bash syntax — use `bash -c '...'` or tcsh
  `foreach ... end`.
- `cat << 'EOF'` heredocs, bare `#` comment lines, and `printf '...\n'` with
  embedded quotes can all cause focus traps in tcsh — see §7 (Terminal Focus
  Traps) for the full list and `create_file` alternatives.
- **Multi-line `printf` stubs**: prefer multiple `echo` calls chained with `&&`,
  or use the `create_file` tool.

---

## 7. Terminal Focus Traps ("Focus Terminal" Blocking)

VS Code's Copilot terminal integration prompts the user to "focus terminal"
when a foreground process expects stdin or interactive input.  This blocks
the entire agent session until the user manually interacts.

### Causes

1. **Foreground task reading stdin** — a command launched with
   `isBackground: false` that expects keyboard input (e.g., ACL2 interactive
   prompt, Python REPL, `read` in shell).
2. **tcsh startup files triggering interactive prompts** — `.cshrc`/`.tcshrc`
   may contain `stty`, `tty`, or `if ($?prompt)` checks that hang in
   non-interactive contexts.
3. **GUI dialogs from headless tools** — Synopsys/Qt tools trying to open
   X11 windows on a remote/headless session.
4. **Command queue backup** — commands queued behind a blocking operation;
   VS Code can't distinguish "still running" from "waiting for input".

### Prevention checklist

| Measure | Effect |
|---------|--------|
| `tcsh -f -c '...'` | Skip `.cshrc`/`.tcshrc` startup — prevents interactive prompts |
| `isBackground: true` | Terminal runs asynchronously; no focus required |
| `setenv DISPLAY ""` | Disables X11; prevents GUI dialog popups |
| `setenv QT_QPA_PLATFORM offscreen` | Forces Qt offscreen rendering |
| `setenv EC_DISABLE_VAL 1` | Synopsys-specific: disables error collection prompts |
| Redirect to log + background | `cmd > /tmp/out.log 2>&1` avoids stdin expectations |

### Anti-patterns that trigger focus traps

```bash
# WRONG: foreground ACL2 buffers all output; tool timeout fires or
#        terminal gets stuck waiting for focus
run_in_terminal("acl2 --no-init < script.lisp", isBackground=false)

# WRONG: tcsh without -f may trigger .cshrc interactive prompts
run_in_terminal("tcsh -c 'source setup; longcommand'", isBackground=false)

# WRONG: cat << 'EOF' heredoc in ANY tcsh terminal causes "awaiting input" focus
#        trap — tcsh reads << as ambiguous redirect and waits for delimiter
run_in_terminal("cat << 'EOF'\nline1\nEOF", isBackground=false)

# WRONG: bare '#' comment lines sent to an interactive tcsh terminal execute as
#        commands and produce "Command not found" errors, blocking further input
run_in_terminal("# This is a comment\n realcommand", isBackground=false)

# WRONG: '2>&1' combined with '&&' at the outer tcsh level causes
#        "Ambiguous output redirect" regardless of background mode
run_in_terminal("cmd1 && cmd2 2>&1", isBackground=false)
```

### Correct patterns

```bash
# CORRECT: background + log file
run_in_terminal("bash -c 'acl2 --no-init < script.lisp > /tmp/out.log 2>&1'",
                isBackground=true, timeout=0)
# Then check from separate foreground:
run_in_terminal("tail -20 /tmp/out.log")

# CORRECT: tcsh with -f flag + headless env
run_in_terminal("tcsh -f -c 'setenv DISPLAY \"\"; setenv QT_QPA_PLATFORM offscreen; source setup; cmd'",
                isBackground=true)

# CORRECT: write multi-line content using create_file tool, then run it as a script
# (avoids heredoc, '#', '!', and backslash continuation traps entirely)
create_file("/tmp/setup.sh", "#!/bin/bash\nmkdir -p /tmp/htest\necho '#pragma ...' > /tmp/htest/Hector.h\n")
run_in_terminal("bash /tmp/setup.sh", isBackground=false, timeout=10000)

# CORRECT: write stub files using printf one-liners WITHOUT newlines in the format string
# — place all content on a single arg separated by explicit \n
run_in_terminal("printf '%s\\n' '#pragma once' '#include <stdint.h>' > /tmp/stub.h")
```

### "Idle with no output" is NOT a failure signal for background proofs

When `isBackground: true` returns immediately with only the login banner warns:
```
W: (cshrc-val) Your .netrc contains a plain text password
```
This is normal — the process launched successfully and is running.  Do NOT retry;
inspect the log file instead:
```bash
wc -l /tmp/proof.log   # growing → still running
tail -8 /tmp/proof.log # check current progress
```

### VS Code tasks.json

For `tasks.json` entries, always use `-f` on tcsh and `isBackground: true`
for long-running jobs:

```json
{
  "command": "tcsh",
  "args": ["-f", "-c", "setenv EC_DISABLE_VAL 1; source setup; vcf -batch ..."],
  "isBackground": true
}
```

## 8. UTF-8 / Unicode File Patching

The `replace_string_in_file` tool does **byte-exact** string matching.  When a
file contains UTF-8 multi-byte characters, they look identical to ASCII when
rendered on screen, but the bytes do NOT match ASCII oldString values.  This
causes silent "Could not find matching text" failures with no diagnostic clue.

### Common Hidden Characters

| Unicode | Rendered | ASCII lookalike | Escape |
|---------|----------|-----------------|--------|
| U+2014 | — | `--` or `-` | `\u2014` |
| U+2013 | – | `-` | `\u2013` |
| U+00A7 | § | `S` or `sec` | `\u00a7` |
| U+2192 | → | `->` or `=>` | `\u2192` |
| U+2018 | \' | `'` | `\u2018` |
| U+2019 | \' | `'` | `\u2019` |
| U+201C | " | `"` | `\u201c` |
| U+201D | " | `"` | `\u201d` |

Files that commonly contain these characters: formal verification reports,
Markdown documents with auto-corrected typography, email traces saved to disk,
TCL/UAL comments copied from PDFs.

### Diagnosis Workflow

When `replace_string_in_file` returns "Could not find matching text":

1. **Locate the target line** with grep:
   ```bash
   grep -n "unique phrase near target" myfile.txt
   ```

2. **Inspect exact bytes** with `inspect_lines_utf8.py`:
   ```bash
   python3 ~/.agents/skills/shell-improvements/inspect_lines_utf8.py \
       myfile.txt 438 452
   # Output: 441: '    9.11 Multi-transaction\u2014coverage gap\n'
   #          ← the \u2014 (em-dash) is what broke the match
   ```

3. **Choose a fix**:
   - If only a few Unicode chars differ → supply the exact `\uXXXX` escapes
     in your `oldString` (works for short, simple replacements).
   - If the section is long or contains many Unicode chars → use
     `patch_utf8_section.py` (anchor search + line-range replacement).

### Patch Workflow (`patch_utf8_section.py`)

```bash
# 1. Copy the template
cp ~/.agents/skills/shell-improvements/patch_utf8_section.py /tmp/mypatch.py
```

Edit `/tmp/mypatch.py` — set three variables:
```python
FILE_PATH    = "report_wrapper_cmodel_connections.txt"
ANCHOR_START = "9.11 Multi-transaction inductive"      # unique to first line of region
ANCHOR_END   = "coverage gap identified in"            # unique to last  line of region
NEW_TEXT = (
    "    9.11 Multi-transaction inductive closure\n"
    "    ...new content...\n"
    # Use \u00a7 for §, \u2014 for —, \u2192 for → in string literals
)
```

```bash
# 2. Run — file is patched in place
python3 /tmp/mypatch.py
# Output: File has 745 lines
#         Replacing lines 441–487 (47 lines)
#         Done: file now 699 lines
```

```bash
# 3. Verify
python3 ~/.agents/skills/shell-improvements/inspect_lines_utf8.py \
    report_wrapper_cmodel_connections.txt 439 445
```

### Key Rules for NEW_TEXT Strings

- **Always end with `\n`** — missing trailing newline merges the last replaced
  line with the first post-replacement line.
- **Use `\uXXXX` escapes** inside Python string literals for any non-ASCII
  characters, never the rendered glyph (the `create_file` tool will preserve
  the rendered glyph, but the Python string literal in a `.py` file is fine
  with either; use escapes for clarity).
- **Preserve indentation** — the patcher does no reformatting; your NEW_TEXT
  must include all leading spaces.

### Connection to tcsh / Agent Session Pitfalls

- **Do not use `replace_string_in_file` to patch reports with Unicode** —
  use `patch_utf8_section.py` instead.
- **Python source files: em-dash and Unicode escapes in string literals.**
  A `.py` file may store an em-dash in a string literal in two ways:
  (A) as the actual `—` glyph (3 UTF-8 bytes E2 80 94), or (B) as the
  literal 6-char Python escape sequence `\u2014` (bytes 5C 75 32 30 31 34).
  Form (A) is common when the file was typed/saved with the glyph directly;
  form (B) when the programmer typed the escape.  These look identical in an
  editor and in `read_file` output, but their byte representations differ.
  `replace_string_in_file` is byte-exact, so an `oldString` that uses the
  wrong form silently fails.  **Reliable fix**: include a longer multi-line
  `oldString` context that uniquely identifies the location via lines that do
  NOT contain the problematic character, bypassing the glyph/escape mismatch
  entirely.  If you must match the exact line, diagnose first with
  `inspect_lines_utf8.py` to confirm which form is in the file.
- **Do not run Python inline with `python3 -c "..."` in tcsh** when the string
  contains Unicode, double-quotes, parentheses, or section signs — tcsh
  metacharacter parsing mangles them.  Write the script to `/tmp/` first
  using the `create_file` tool (zero shell parsing), then run
  `python3 /tmp/script.py`.
- **`create_file` bypasses all shell quoting** — it is the safe way to
  write any file whose content would be corrupted by shell metacharacter
  expansion (Unicode, curly braces, backticks, sigils).

---

## 9. Agent Stall Prevention and Session Resilience

### Terminal stalls: unique causes not covered by §3

Beyond the terminal reuse and background monitoring rules in §3, two tcsh-specific
conditions can silently block a terminal:

1. **tcsh CORRECT> prompt**: If a command triggered tcsh's spell-correction
   (`CORRECT> ... (y|n|e|a)?`), the terminal is waiting for user input.
   Happens when bash-syntax commands (e.g., `for d in ...; do ...; done`) are
   sent to tcsh. **Prevention**: wrap all non-trivial commands in `bash -c '...'`.
2. **Ctrl-C fallout**: Sends interrupt to the foreground process; terminal may
   remain in an unexpected state. After any suspected stall, use a FRESH terminal.

### Quote and parenthesis errors in tcsh

tcsh aggressively interprets special characters:
- Unmatched `(` or `)` → `Unmatched '('` error
- Unmatched single/double quotes → `Unmatched '"'` or `Unmatched '''`
- `!` in double-quotes → history substitution (`event not found`)
- `{a,b}` → brace expansion (different from bash behavior)

**Prevention**:
- Always wrap complex commands in `bash -c '...'` (single quotes protect
  the content from tcsh interpretation).
- If the command itself contains single quotes, use `bash -c "..."` with
  escaped inner quotes, or write to a file with `create_file` and run it.
- Never use `for ... ; do ... ; done` in tcsh — this is bash syntax.
  Use `bash -c 'for ...'` or tcsh's `foreach ... end`.


---

## 10. References

- [tcsh/csh details](./references/tcsh-csh.md)
- [Non-recursive make](./references/nonrecursive-make.md) — directory-stack pattern for single-session GNU Make (van Bergen / Peter Miller)
