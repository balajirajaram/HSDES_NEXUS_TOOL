# Silicon Platform Manager — VS Code Agent Plugin

A VS Code agent plugin that bundles the **Silicon Platform Manager** MCP server
and four agent skills for managing MMG silicon platforms, deploying Link Manager
firmware, and executing Link Manager test plans.

## What's included

| Component | Path | Description |
|-----------|------|-------------|
| MCP server | `mcp/server.py` | Connects VS Code agent to the Silicon Platform Server over TCP |
| Skill: `lm-fw-deploy` | `skills/lm-fw-deploy/` | Deploy Link Manager firmware to a silicon platform |
| Skill: `lm-test-execution` | `skills/lm-test-execution/` | Execute a Link Manager test plan |
| Skill: `lm-debug` | `skills/lm-debug/` | Debug a failing Link Manager test |
| Skill: `platform-manager-server-install` | `skills/platform-manager-server-install/` | Guide for building and installing the Silicon Platform Server on a remote Windows machine |

## Prerequisites

- Python 3.10+ on the machine running VS Code
- The **Silicon Platform Server** running on the remote Windows machine that
  controls the silicon board (see `silicon platform manager/server/` in the
  workspace)
- MCP Python package: `pip install "mcp>=1.0,<2"`

## Setup

### 1. Install MCP dependencies

```bash
pip install -r mcp/requirements.txt
```

### 2. Configure credentials

Set the following Windows user environment variables so the MCP server can
authenticate with the Silicon Platform Server:

| Variable | Description | Default |
|----------|-------------|---------|
| `SPM_USERNAME` | Username for the Silicon Platform Server | *(required)* |
| `SPM_PASSWORD` | Password for the Silicon Platform Server | *(required)* |
| `SPM_HOST` | Hostname or IP of the Silicon Platform Server | `localhost` |
| `SPM_PORT` | TCP port | `5555` |

To set them permanently in Windows (no restart needed for VS Code):
```powershell
[System.Environment]::SetEnvironmentVariable('SPM_USERNAME', '<your-username>', 'User')
[System.Environment]::SetEnvironmentVariable('SPM_PASSWORD', '<your-password>', 'User')
```

The MCP server inherits these automatically when VS Code starts it. If they are
not set, tool calls will return a clear error message.

### 3. Install the plugin in VS Code

**From source (this repository):**

1. Open the Command Palette (`Ctrl+Shift+P`) and run
   `Chat: Install Plugin From Source`.
2. Enter the repository URL or, if already cloned, add the plugin directory to
   your VS Code settings:

   ```json
   // settings.json
   "chat.pluginLocations": {
    "/path/to/fwrs-silicon-platform-manager": true
   }
   ```

### 4. Enter credentials when prompted

The first time the MCP server starts, VS Code will prompt for:
- **Silicon Platform Server hostname or IP** (default: `localhost`)
- **Username**
- **Password** (stored in VS Code secret storage — never written to disk)

## MCP server details

The MCP server (`mcp/server.py`) exposes the following tools to the agent:

| Tool | Description |
|------|-------------|
| `query_server_version` | Verify connectivity to the Silicon Platform Server |
| `reset_silicon_platform` | Trigger a hardware platform reset (~2 min) |
| `run_link_manager` | Start `ipumgmtd` with the Link Manager on the target |
| `load_library` | Upload the Link Manager shared library (`liblm.so.0.0`) |
| `load_topology` | Upload a link topology binary |
| `copy_file_to_imc` | Copy a local file to an absolute path on the IMC |
| `retrieve_logs` | Download log files from `/var/volatile/` |
| `restore_default_config` | Revert to factory link configuration |
| `set_port_option` | Set the active port-option index |
| `get_port_option` | Read the active and persistent port-option index |
| `set_dnl_config` | Configure DNL runtime mode (HAL vs engine, timings) |
| `get_dnl_config` | Read current DNL configuration |
| `get_platform_status` | Check whether the platform is reachable and LM is running |
| `start_remote_debug` | Launch gdbserver and open an SSH tunnel for GDB |
| `lm_cli_command` | Pipe a command into `lm_interfaces_cli.py` on the server |

## Plugin format

This plugin uses the **Claude** plugin format (`.claude-plugin/plugin.json`).
VS Code detects this automatically and makes `${CLAUDE_PLUGIN_ROOT}` available
in the MCP server configuration so paths resolve correctly regardless of where
the plugin is installed.

## Example prompts

Use these prompts in the **fwrs-silicon-platform-manager** agent to invoke each skill.

### `lm-fw-deploy` — Deploy Link Manager firmware

```
Deploy the Link Manager firmware to the platform at 192.168.1.10
```
```
Rebuild and deploy the Link Manager firmware to my silicon platform
```
```
Deploy LM firmware to 192.168.1.10 using the library at build/liblm.so.0.0
and the topology at config/topology.bin
```

### `lm-test-execution` — Execute a Link Manager test plan

```
Run the test plan at tests/link_bringup_test_plan.md on platforms 192.168.1.10 and 192.168.1.11
```
```
Execute the test plan tests/fec_test_plan.md — Link Manager is already running on the platform
```
```
Run the link bringup test plan and report a pass/fail summary at the end
```

### `lm-debug` — Debug a failing test

```
The set_phy_config step in my test plan failed — help me debug it
```
```
The test reached Step 4 but the expected log line was never printed — debug the failure
```
```
Retrieve the platform logs and analyse why the link did not come up during the test
```

### `platform-manager-server-install` — Install the Silicon Platform Server

```
How do I install the Silicon Platform Server on a remote Windows machine?
```
```
Walk me through setting up the Silicon Platform Server on a new Windows machine
```
```
What are the steps to build and deploy the platform server package to a remote host?
```

---

### Full development cycle example

The following prompt drives the agent through a complete iteration — firmware deployment, test execution, failure diagnosis, code fix, and re-validation — all in a single session:

```
I'm working on a link bringup fix. Here's what I need you to do:

1. Rebuild and deploy the Link Manager firmware to the platform at 192.168.1.10.
   Use the library at build/output/liblm.so.0.0 and topology at config/2port_topology.bin.

2. Once the firmware is running, execute the test plan at tests/link_bringup_test_plan.md.

3. If any test step fails, retrieve the platform logs and debug the failure.
   Identify the root cause and show me the relevant log lines.

4. If the fix requires a code change, locate the relevant source file in the workspace,
   apply the fix, then redeploy and re-run the test plan.

5. Repeat steps 3–4 up to 3 times in total. If the test still fails after 3 fix attempts,
   stop and give me a summary of what was tried, what the current failure is, and what
   you think should be investigated next.

6. If all test steps pass, give me a summary of what was changed and why.
```

---

## Related files in the workspace

- `silicon platform manager/server/` — Silicon Platform Server (deployed on
  the remote Windows machine)
- `silicon platform manager/server/SERVER_DEPLOYMENT.md` — detailed server
  deployment guide
- `silicon platform manager/server/EXTERNAL_DEPENDENCIES.md` — external tool
  installation (Bobcat, PuTTY)
- `silicon platform manager/BUTTON_SETUP.md` — how to capture the reset button
  screenshot for image recognition
