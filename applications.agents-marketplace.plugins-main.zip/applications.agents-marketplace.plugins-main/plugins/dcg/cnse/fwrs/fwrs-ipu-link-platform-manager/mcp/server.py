#!/usr/bin/env python3
# Copyright (C) 2026 Intel Corporation
#
# SPDX-License-Identifier: MIT
"""
MMG Silicon Platform Manager — MCP Server
==========================================
Exposes the Silicon Platform Server's capabilities as MCP tools so that an AI
agent (e.g. GitHub Copilot) can drive the platform directly.

Protocol recap (Silicon Platform Server TCP wire format)
--------------------------------------------------------
  1. Client → Server:  AUTH_REQUEST|<username>
  2. Server → Client:  AUTH_CHALLENGE|<challenge_id>|<challenge>
  3. Client → Server:  AUTH_RESPONSE|<challenge_id>|SHA256(<password>+<challenge>)
  4. Server → Client:  AUTH_SUCCESS|<session_token>
  Subsequent authenticated commands: TOKEN|<session_token>|<COMMAND>
  VERSION is the only unauthenticated command.

Usage
-----
Set environment variables before launching:
  SPM_HOST      – hostname / IP of the Silicon Platform Server (default: localhost)
  SPM_PORT      – TCP port                                       (default: 5555)
  SPM_USERNAME  – server username
  SPM_PASSWORD  – server password

VS Code launches this automatically via .vscode/mcp.json.
"""

import asyncio
import base64
import hashlib
import logging
import os
import re
import socket
import tempfile
from pathlib import Path
from typing import Optional

from mcp.server import Server
from mcp import types
from mcp.server.stdio import stdio_server

# ---------------------------------------------------------------------------
# Logging — always written to a file; console handlers are suppressed so the
# stdio JSON stream used by MCP is never polluted.
# ---------------------------------------------------------------------------

_log_path = os.path.join(tempfile.gettempdir(), "mcp-spm-server.log")
_log_handler = logging.FileHandler(_log_path, encoding="utf-8")
_log_handler.setFormatter(
    logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s")
)
# Configure only this package's logger — leave the root logger and any handlers
# installed by dependencies (including MCP internals) completely untouched.
# propagate=False ensures log records never reach the root logger and therefore
# never reach a StreamHandler that could write to stderr/stdout and corrupt the
# MCP stdio JSON framing.
logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)
logger.addHandler(_log_handler)
logger.propagate = False

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

SPM_HOST: str = os.environ.get("SPM_HOST", "localhost")
SPM_PORT: int = int(os.environ.get("SPM_PORT", "5555"))
SPM_USERNAME: str = os.environ.get("SPM_USERNAME", "")
SPM_PASSWORD: str = os.environ.get("SPM_PASSWORD", "")

# ---------------------------------------------------------------------------
# Per-operation timeouts (seconds)
#
# Rationale:
#   - Fast commands (VERSION, auth round-trips, simple queries) rarely exceed
#     a few seconds, so a tight timeout gives quick failure feedback.
#   - Platform reset blocks for ~2 min while the automation sequence completes.
#   - NVMe flashing can take up to 600 s server-side (dd timeout); add margin.
#   - File/log retrieval pipelines through SCP which may be slow on the LAN.
#   - All values can be overridden via environment variables for unusual setups.
# ---------------------------------------------------------------------------
_TIMEOUT_FAST: float     = float(os.environ.get("SPM_TIMEOUT_FAST",     "15"))    # VERSION, auth
_TIMEOUT_QUERY: float    = float(os.environ.get("SPM_TIMEOUT_QUERY",    "60"))    # read-only getters
_TIMEOUT_UPLOAD: float   = float(os.environ.get("SPM_TIMEOUT_UPLOAD",   "300"))   # file / library upload
_TIMEOUT_RESET: float    = float(os.environ.get("SPM_TIMEOUT_RESET",    "240"))   # platform reset / LM start
_TIMEOUT_NVME: float     = float(os.environ.get("SPM_TIMEOUT_NVME",     "660"))   # NVMe flash (dd ≤ 600 s)
_TIMEOUT_LOGS: float     = float(os.environ.get("SPM_TIMEOUT_LOGS",     "180"))   # log retrieval
_TIMEOUT_DEBUG: float    = float(os.environ.get("SPM_TIMEOUT_DEBUG",    "60"))    # gdbserver tunnel setup

# Legacy alias kept so any call sites that pass TCP_TIMEOUT explicitly still compile.
TCP_TIMEOUT: float = _TIMEOUT_QUERY

# ---------------------------------------------------------------------------
# Session cache (one session per server address; refreshed on expiry/error)
# ---------------------------------------------------------------------------

_session_token: Optional[str] = None
_session_server: tuple = ("", 0)  # host, port that issued the token


# ---------------------------------------------------------------------------
# Low-level TCP helpers
# ---------------------------------------------------------------------------

def _tcp_exchange(host: str, port: int, message: str, timeout: float = TCP_TIMEOUT) -> str:
    """Send *message* (must not contain trailing newline) and return the server's response line."""
    with socket.create_connection((host, port), timeout=timeout) as sock:
        sock.sendall((message + "\n").encode("utf-8"))
        # Read until newline; large responses arrive in chunks.
        # Accumulate into a list and join once to avoid O(n²) byte-string copies.
        chunks: list[bytes] = []
        while True:
            chunk = sock.recv(65536)
            if not chunk:
                break
            chunks.append(chunk)
            if b"\n" in chunk:
                break
        buf = b"".join(chunks)
    return buf.decode("utf-8").strip()


def _authenticate(host: str, port: int, username: str, password: str) -> str:
    """Perform challenge-response authentication and return the session token."""
    # Step 1 — request challenge
    resp1 = _tcp_exchange(host, port, f"AUTH_REQUEST|{username}")
    if not resp1.startswith("AUTH_CHALLENGE|"):
        raise RuntimeError(f"Unexpected auth response: {resp1}")
    _, challenge_id, challenge = resp1.split("|", 2)

    # Step 2 — respond with SHA256(password + challenge)
    digest = hashlib.sha256((password + challenge).encode("utf-8")).hexdigest()
    resp2 = _tcp_exchange(host, port, f"AUTH_RESPONSE|{challenge_id}|{digest}")
    if not resp2.startswith("AUTH_SUCCESS|"):
        raise RuntimeError(f"Authentication failed: {resp2}")
    return resp2.split("|", 1)[1]  # session token


def _get_token(host: str, port: int) -> str:
    """Return the cached session token, re-authenticating if needed."""
    global _session_token, _session_server
    missing = [k for v, k in ((SPM_USERNAME, "SPM_USERNAME"), (SPM_PASSWORD, "SPM_PASSWORD")) if not v]
    if missing:
        raise RuntimeError(
            f"Credentials not configured: {', '.join(missing)} environment variable(s) are not set. "
            "Configure them via the MCP server settings (SPM_USERNAME / SPM_PASSWORD)."
        )
    if _session_token and _session_server == (host, port):
        return _session_token
    _session_token = _authenticate(host, port, SPM_USERNAME, SPM_PASSWORD)
    _session_server = (host, port)
    return _session_token


def _send(command: str, host: str = SPM_HOST, port: int = SPM_PORT,
          timeout: float = _TIMEOUT_QUERY, retry: bool = True) -> str:
    global _session_token
    token = _get_token(host, port)
    try:
        resp = _tcp_exchange(host, port, f"TOKEN|{token}|{command}", timeout=timeout)
    except OSError as exc:
        raise RuntimeError(f"TCP error: {exc}") from exc
    if "Authentication required" in resp or "Invalid session" in resp:
        if retry:
            _session_token = None
            return _send(command, host, port, timeout=timeout, retry=False)
        raise RuntimeError(f"Authentication error: {resp}")
    return resp


def _file_to_b64(local_path: str) -> tuple[str, str]:
    p = Path(local_path)
    if not p.is_file():
        raise FileNotFoundError(f"File not found: {local_path}")
    return p.name, base64.b64encode(p.read_bytes()).decode("ascii")

# ---------------------------------------------------------------------------
# Tool implementations
# ---------------------------------------------------------------------------

def _tool_query_server_version(host: str, port: int) -> str:
    try:
        return _tcp_exchange(host, port, "VERSION", timeout=_TIMEOUT_FAST)
    except OSError as exc:
        return f"ERROR: Cannot reach server at {host}:{port} — {exc}"

def _tool_reset_silicon_platform(host: str, port: int) -> str:
    return _send("RESET", host, port, timeout=_TIMEOUT_RESET)

def _tool_run_link_manager(host: str, port: int) -> str:
    return _send("RUN_LINK_MANAGER", host, port, timeout=_TIMEOUT_RESET)

def _tool_load_library(local_file_path: str, host: str, port: int) -> str:
    # Resolve symlinks locally so we always send the real versioned filename
    # (e.g. liblm.so.0.0) even if the user points at a symlink (liblm.so).
    # This works correctly on Linux where .so files are actual symlinks.
    resolved_path = os.path.realpath(local_file_path)
    filename, b64 = _file_to_b64(resolved_path)
    return _send(f"LOAD_LIBRARY|{filename}|{b64}", host, port, timeout=_TIMEOUT_UPLOAD)

def _tool_load_topology(local_file_path: str, host: str, port: int) -> str:
    filename, b64 = _file_to_b64(local_file_path)
    return _send(f"LOAD_TOPOLOGY|{filename}|{b64}", host, port, timeout=_TIMEOUT_UPLOAD)

# Allowed characters in destination_path: absolute Unix path with alphanumeric,
# slash, dot, dash, underscore.  No consecutive dots (blocks ../traversal).
_DEST_PATH_RE = re.compile(r'^(/[a-zA-Z0-9_.\-]+)+/?$')

def _tool_copy_file_to_imc(local_file_path: str, destination_path: str, host: str, port: int) -> str:
    if not _DEST_PATH_RE.match(destination_path) or '..' in destination_path:
        return "ERROR: Invalid destination_path. Use an absolute path with alphanumeric, slash, dot, dash, or underscore characters only — no path traversal."
    _, b64 = _file_to_b64(local_file_path)
    return _send(f"COPY_FILE_TO_IMC|{destination_path}|{b64}", host, port, timeout=_TIMEOUT_UPLOAD)

def _tool_retrieve_logs(local_folder: str, host: str, port: int) -> str:
    import io, tarfile
    response = _send("RETRIEVE_LOGS", host, port, timeout=_TIMEOUT_LOGS)
    if not response.startswith("SUCCESS|"):
        return response
    parts = response.split('|', 2)
    if len(parts) != 3:
        return "ERROR: Unexpected response format from server."
    _, _filename, b64 = parts
    try:
        tar_bytes = base64.b64decode(b64)
    except Exception as exc:
        return f"ERROR: Failed to decode payload: {exc}"
    dest = Path(local_folder)
    try:
        dest.mkdir(parents=True, exist_ok=True)
    except OSError as exc:
        return f"ERROR: Cannot create destination folder '{local_folder}': {exc}"
    try:
        names = []
        with tarfile.open(fileobj=io.BytesIO(tar_bytes), mode='r:gz') as tf:
            for member in tf.getmembers():
                if not member.isfile():
                    continue
                member.name = os.path.basename(member.name)
                tf.extract(member, path=dest)
                names.append(member.name)
    except tarfile.TarError as exc:
        return f"ERROR: Failed to extract tar.gz: {exc}"
    return f"SUCCESS: {len(names)} file(s) extracted to '{dest}': {', '.join(names)}"

def _tool_restore_default_config(host: str, port: int) -> str:
    return _send("RESTORE_DEFAULT_CONFIG", host, port, timeout=_TIMEOUT_QUERY)

def _tool_set_port_option(port_option_index: int, host: str, port: int) -> str:
    return _send(f"SET_PORT_OPTION|{port_option_index}", host, port, timeout=_TIMEOUT_QUERY)

def _tool_start_remote_debug(host: str, port: int) -> str:
    return _send("START_DEBUG", host, port, timeout=_TIMEOUT_DEBUG)

def _tool_get_port_option(host: str, port: int) -> str:
    return _send("GET_PORT_OPTION", host, port, timeout=_TIMEOUT_QUERY)

def _tool_set_dnl_config(dnl_hal: int, dnl_engine: int, dnl_timings: int, dnl_timings_window: int, host: str, port: int) -> str:
    return _send(f"SET_DNL_CONFIG|{dnl_hal}|{dnl_engine}|{dnl_timings}|{dnl_timings_window}", host, port, timeout=_TIMEOUT_UPLOAD)

def _tool_get_dnl_config(host: str, port: int) -> str:
    return _send("GET_DNL_CONFIG", host, port, timeout=_TIMEOUT_QUERY)

def _tool_get_platform_status(host: str, port: int) -> str:
    return _send("GET_PLATFORM_STATUS", host, port, timeout=_TIMEOUT_QUERY)

# LM_CLI_COMMAND constants (must match server-side values)
_LM_CLI_COMMAND_MAX_LEN = 4096
_LM_CLI_COMMAND_FORBIDDEN = frozenset({'\n', '\r', '\x00'})

def _tool_lm_cli_command(command: str, host: str, port: int, timeout: float) -> str:
    """Pipe *command* into lm_interfaces_cli.py on the server host via LM_CLI_COMMAND."""
    if len(command) > _LM_CLI_COMMAND_MAX_LEN:
        return f"ERROR: Command too long (max {_LM_CLI_COMMAND_MAX_LEN} characters)."
    if any(ch in command for ch in _LM_CLI_COMMAND_FORBIDDEN):
        return "ERROR: Command contains forbidden characters (newline / NUL)."
    raw = _send(f"LM_CLI_COMMAND|{command}", host, port, timeout=timeout)
    # The server escapes embedded newlines as r'\n' so the response fits on a
    # single TCP line.  Unescape here to restore the original multi-line output.
    return raw.replace(r'\n', '\n')

# ---------------------------------------------------------------------------
# MCP tool registry
# ---------------------------------------------------------------------------

_STRING  = {"type": "string"}
_INTEGER = {"type": "integer"}

TOOLS: list[types.Tool] = [
    types.Tool(
        name="query_server_version",
        description=(
            "Query the Silicon Platform Server version and protocol version. "
            "Unauthenticated — use this first to verify connectivity. "
            "Returns a string like 'VERSION|1.1.0|1'."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "host": {**_STRING, "description": "Server hostname/IP", "default": SPM_HOST},
                "port": {**_INTEGER, "description": "Server TCP port", "default": SPM_PORT},
            },
        },
    ),
    types.Tool(
        name="reset_silicon_platform",
        description="Reboot the Silicon platform via serial automation. Blocks until done (~2 min).",
        inputSchema={
            "type": "object",
            "properties": {
                "host": {**_STRING, "default": SPM_HOST},
                "port": {**_INTEGER, "default": SPM_PORT},
            },
        },
    ),
    types.Tool(
        name="run_link_manager",
        description="Start ipumgmtd with the Link Manager on the target and activate the LM TCP relay.",
        inputSchema={
            "type": "object",
            "properties": {
                "host": {**_STRING, "default": SPM_HOST},
                "port": {**_INTEGER, "default": SPM_PORT},
            },
        },
    ),
    types.Tool(
        name="load_library",
        description=(
            "Upload the Link Manager shared library to the target platform. "
            "IMPORTANT: you MUST search for and pass the VERSIONED binary file named exactly "
            "'liblm.so.0.0'. This is the real file, not a symlink. "
            "Never pass 'liblm.so' or 'liblm.so.0' — those are symlinks and will NOT work. "
            "Search build output directories (e.g. build/, out/, install/usr/lib/) for a file "
            "whose name matches 'liblm.so.0.0' and pass its absolute path."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "local_file_path": {**_STRING, "description": "Absolute path to 'liblm.so.0.0' (the versioned binary, NOT a symlink) on this machine"},
                "host": {**_STRING, "default": SPM_HOST},
                "port": {**_INTEGER, "default": SPM_PORT},
            },
            "required": ["local_file_path"],
        },
    ),
    types.Tool(
        name="load_topology",
        description="Upload a link topology binary to the target platform.",
        inputSchema={
            "type": "object",
            "properties": {
                "local_file_path": {**_STRING, "description": "Absolute path to the topology file on this machine"},
                "host": {**_STRING, "default": SPM_HOST},
                "port": {**_INTEGER, "default": SPM_PORT},
            },
            "required": ["local_file_path"],
        },
    ),
    types.Tool(
        name="copy_file_to_imc",
        description=(
            "Copy a local file to an exact destination path on the IMC via the Windows server's pscp. "
            "destination_path must be an absolute path (starts with /) using only alphanumeric, slash, dot, dash, or underscore characters — no path traversal. Enforced server-side."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "local_file_path": {**_STRING, "description": "Absolute local path to the source file"},
                "destination_path": {**_STRING, "description": "Absolute destination path on the IMC"},
                "host": {**_STRING, "default": SPM_HOST},
                "port": {**_INTEGER, "default": SPM_PORT},
            },
            "required": ["local_file_path", "destination_path"],
        },
    ),
    types.Tool(
        name="retrieve_logs",
        description=(
            "Collect all log files from the platform's /var/volatile/ directory, "
            "download them as a zip archive, and extract them into local_folder on this machine. "
            "Returns the list of extracted files on success."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "local_folder": {**_STRING, "description": "Local folder path where log files will be extracted"},
                "host": {**_STRING, "default": SPM_HOST},
                "port": {**_INTEGER, "default": SPM_PORT},
            },
            "required": ["local_folder"],
        },
    ),
    types.Tool(
        name="restore_default_config",
        description="Delete persistent link_config.json on the target, reverting to factory link configuration.",
        inputSchema={
            "type": "object",
            "properties": {
                "host": {**_STRING, "default": SPM_HOST},
                "port": {**_INTEGER, "default": SPM_PORT},
            },
        },
    ),
    types.Tool(
        name="set_port_option",
        description="Set the active port-option index on the target platform (0-based integer).",
        inputSchema={
            "type": "object",
            "properties": {
                "port_option_index": {**_INTEGER, "description": "Desired port option index (0-based)"},
                "host": {**_STRING, "default": SPM_HOST},
                "port": {**_INTEGER, "default": SPM_PORT},
            },
            "required": ["port_option_index"],
        },
    ),
    types.Tool(
        name="start_remote_debug",
        description="Launch gdbserver on the target and open an SSH tunnel for a local GDB client.",
        inputSchema={
            "type": "object",
            "properties": {
                "host": {**_STRING, "default": SPM_HOST},
                "port": {**_INTEGER, "default": SPM_PORT},
            },
        },
    ),
    types.Tool(
        name="get_port_option",
        description=(
            "Read the currently active port-option index from the platform. "
            "Returns both the live (active) value and the persistent (post-reboot) value. "
            "Response format: 'PORT_OPTION:active=<n>,persistent=<m>'. "
            "Requires server protocol v2."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "host": {**_STRING, "default": SPM_HOST},
                "port": {**_INTEGER, "default": SPM_PORT},
            },
        },
    ),
    types.Tool(
        name="set_dnl_config",
        description=(
            "Configure the DNL runtime mode in link_debug_config.json on the platform. "
            "Exactly one of dnl_hal / dnl_engine must be 1 (they are mutually exclusive). "
            "dnl_timings controls whether Link Manager collects DNL timing statistics. "
            "dnl_timings_window sets the timing collection window in minutes (default 10). "
            "Requires server protocol v2."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "dnl_hal":              {**_INTEGER, "description": "1 = use C-converted DNL (HAL mode), 0 = off"},
                "dnl_engine":           {**_INTEGER, "description": "1 = use DNL scripting engine, 0 = off"},
                "dnl_timings":          {**_INTEGER, "description": "1 = collect timing statistics, 0 = skip"},
                "dnl_timings_window":   {**_INTEGER, "description": "Timing collection window in minutes (default 10)", "default": 10},
                "host": {**_STRING, "default": SPM_HOST},
                "port": {**_INTEGER, "default": SPM_PORT},
            },
            "required": ["dnl_hal", "dnl_engine", "dnl_timings"],
        },
    ),
    types.Tool(
        name="get_dnl_config",
        description=(
            "Read the current DNL mode settings (DnlHal, DnlEngine, DnlTimings) from "
            "link_debug_config.json on the platform. "
            "Response format: 'DNL_CONFIG:hal=<0|1>,engine=<0|1>,timings=<0|1>' or "
            "'DNL_CONFIG:missing' if the file has not been created yet. "
            "Requires server protocol v2."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "host": {**_STRING, "default": SPM_HOST},
                "port": {**_INTEGER, "default": SPM_PORT},
            },
        },
    ),
    types.Tool(
        name="get_platform_status",
        description=(
            "Check whether the platform is reachable and whether Link Manager is running. "
            "Returns one of: "
            "'STATUS:NOT_REACHABLE|...' (no ping response), "
            "'STATUS:LM_NOT_RUNNING|...' (reachable but ipumgmtd not found), "
            "'STATUS:RUNNING|...' (Link Manager active). "
            "Requires server protocol v2."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "host": {**_STRING, "default": SPM_HOST},
                "port": {**_INTEGER, "default": SPM_PORT},
            },
        },
    ),
    types.Tool(
        name="lm_cli_command",
        description=(
            "Pipe a command string into lm_interfaces_cli.py on the Silicon Platform Server host. "
            "The command is passed as stdin to the script (no shell involved). "
            "Use this to invoke LM interface CLI operations on the server machine. "
            "Max 4096 characters; newline and NUL characters are forbidden. "
            "Returns 'SUCCESS:<output>' on exit-code 0, or 'ERROR: ...' on failure."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "command": {**_STRING, "description": "Command string to pipe into lm_interfaces_cli.py"},
                "timeout": {**_INTEGER, "description": "Execution timeout in seconds (default 30)", "default": 30},
                "host": {**_STRING, "default": SPM_HOST},
                "port": {**_INTEGER, "default": SPM_PORT},
            },
            "required": ["command"],
        },
    ),
]

# ---------------------------------------------------------------------------
# Tool dispatcher
# ---------------------------------------------------------------------------

def _call_tool(name: str, args: dict) -> str:
    host = args.get("host", SPM_HOST)
    port = int(args.get("port", SPM_PORT))
    if name == "query_server_version":
        return _tool_query_server_version(host, port)
    if name == "reset_silicon_platform":
        return _tool_reset_silicon_platform(host, port)
    if name == "run_link_manager":
        return _tool_run_link_manager(host, port)
    if name == "load_library":
        return _tool_load_library(args["local_file_path"], host, port)
    if name == "load_topology":
        return _tool_load_topology(args["local_file_path"], host, port)
    if name == "copy_file_to_imc":
        return _tool_copy_file_to_imc(args["local_file_path"], args["destination_path"], host, port)
    if name == "retrieve_logs":
        return _tool_retrieve_logs(args["local_folder"], host, port)
    if name == "restore_default_config":
        return _tool_restore_default_config(host, port)
    if name == "set_port_option":
        return _tool_set_port_option(int(args["port_option_index"]), host, port)
    if name == "start_remote_debug":
        return _tool_start_remote_debug(host, port)
    if name == "get_port_option":
        return _tool_get_port_option(host, port)
    if name == "set_dnl_config":
        return _tool_set_dnl_config(
            int(args["dnl_hal"]),
            int(args["dnl_engine"]),
            int(args["dnl_timings"]),
            int(args.get("dnl_timings_window", 10)),
            host, port,
        )
    if name == "get_dnl_config":
        return _tool_get_dnl_config(host, port)
    if name == "get_platform_status":
        return _tool_get_platform_status(host, port)
    if name == "lm_cli_command":
        cmd_timeout = float(args.get("timeout", 30))
        return _tool_lm_cli_command(args["command"], host, port, timeout=cmd_timeout)
    raise ValueError(f"Unknown tool: {name}")

# ---------------------------------------------------------------------------
# MCP server
# ---------------------------------------------------------------------------

server = Server("fwrs-silicon-platform-manager")


async def _elicit_credentials() -> bool:
    """Prompt the user for missing credentials via MCP elicitation.

    Updates the module-level SPM_USERNAME / SPM_PASSWORD globals so that
    subsequent _get_token() calls succeed without re-prompting.

    Returns True if credentials were supplied, False if the user cancelled.
    """
    global SPM_USERNAME, SPM_PASSWORD

    missing_username = not SPM_USERNAME
    missing_password = not SPM_PASSWORD

    if not missing_username and not missing_password:
        return True

    properties: dict = {}
    required: list[str] = []
    if missing_username:
        properties["username"] = {"type": "string", "title": "SPM Username", "description": "Username for the Silicon Platform Server"}
        required.append("username")
    if missing_password:
        properties["password"] = {"type": "string", "title": "SPM Password", "description": "Password for the Silicon Platform Server", "format": "password"}
        required.append("password")

    try:
        session = server.request_context.session
        result = await session.elicit_form(
            message=(
                "Silicon Platform Manager credentials are required.\n"
                "Please enter the username and/or password for the Silicon Platform Server."
            ),
            requestedSchema={
                "type": "object",
                "properties": properties,
                "required": required,
            },
        )
    except Exception as exc:
        logger.warning(f"Elicitation failed: {exc}")
        return False

    if result.action != "accept" or not result.content:
        logger.info(f"User did not supply credentials (action={result.action})")
        return False

    if missing_username and result.content.get("username"):
        SPM_USERNAME = str(result.content["username"])
    if missing_password and result.content.get("password"):
        SPM_PASSWORD = str(result.content["password"])

    logger.info("Credentials supplied via elicitation.")
    return True


@server.list_tools()
async def handle_list_tools() -> list[types.Tool]:
    logger.debug("handle_list_tools called")
    return TOOLS


@server.call_tool()
async def handle_call_tool(name: str, arguments: dict) -> list[types.TextContent]:
    logger.debug(f"handle_call_tool: name={name}")
    try:
        # query_server_version is unauthenticated — skip credential check.
        if name != "query_server_version" and (not SPM_USERNAME or not SPM_PASSWORD):
            supplied = await _elicit_credentials()
            if not supplied:
                return [types.TextContent(
                    type="text",
                    text="ERROR: Credentials not configured — SPM_USERNAME and SPM_PASSWORD are required. "
                         "Please configure them in the MCP server settings (SPM_USERNAME / SPM_PASSWORD) and retry.",
                )]
        text = await asyncio.to_thread(_call_tool, name, arguments or {})
        return [types.TextContent(type="text", text=text)]
    except Exception as exc:
        logger.exception(f"Tool {name} raised an exception")
        return [types.TextContent(type="text", text=f"ERROR: {exc}")]


async def main() -> None:
    logger.info("=== MMG Silicon Platform Manager MCP Server starting ===")
    async with stdio_server() as (read_stream, write_stream):
        await server.run(
            read_stream,
            write_stream,
            server.create_initialization_options(),
        )


if __name__ == "__main__":
    asyncio.run(main())
