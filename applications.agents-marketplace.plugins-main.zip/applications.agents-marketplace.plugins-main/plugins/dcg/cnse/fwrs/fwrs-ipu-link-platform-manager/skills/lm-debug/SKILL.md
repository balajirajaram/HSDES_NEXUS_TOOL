---
name: lm-debug
description: >
  Guides the agent through debugging a failing Link Manager test.
  Activated when a test step or log verification fails during lm-test-execution.
---
# Link Manager Debug

This skill guides the agent through debugging a failing Link Manager test.
It is activated when a test step or log verification fails during `lm_test_execution`.

---

## Step 1 — Retrieve Platform Logs

Use the Platform Manager MCP `retrieve_logs` tool to collect logs from each
platform involved in the test.

**Important — consecutive log files**: Logs accumulate over time while the
Link Manager is running. When the current log file reaches its maximum size, a
new file is created with the next consecutive number in the filename (e.g.
`lm.log.0`, `lm.log.1`, `lm.log.2`, …). Read **all** consecutive log files in
order to get the complete picture — do not stop at the first file.

When reading the logs:
- Translate physical port numbers back to logical port numbers using the
  mapping established in `lm_test_execution` Step 3.
- Identify where the expected flow deviated: missing state transitions,
  unexpected errors, or absent log lines.
- Note the exact log entries (with timestamps if available) that indicate the
  failure point.

---

## Step 2 — Analyse the Failure

Based on the logs, determine the likely failure cause:

- **Expected state/transition missing**: the LM did not reach the expected
  state. Identify the last successful state logged.
- **Error logged**: note the error code and the component that reported it.
- **No relevant logs at all**: the code path may not have been reached, or the
  log level may be insufficient.

If log verbosity is insufficient for the failure area, increase the log level
for the relevant component using `set_logging_level` via the MCP
`lm_cli_command` tool, then re-run the test from `lm_test_execution` and
repeat this debug cycle.

---

## Step 3 — Add Debug Logs to the C Code (if needed)

If the existing logs do not pinpoint the failure, add diagnostic log statements
to the relevant Link Manager C source files in the workspace
(`mev_imc_lm/` source tree).

After adding logs:

1. Use the `lm_fw_deploy` skill to rebuild and redeploy the Link Manager to
   the platform (the platform must be reset as part of redeployment before a
   new library can be loaded).
2. Re-run the test from `lm_test_execution`.
3. Retrieve logs again and repeat analysis (Step 1–2).

---

## Step 4 — Identify a Potential Bug

If analysis points to incorrect behaviour in the C code:

**Before making any fix**, compare the suspect C code against the ground-truth
DNL script at `mev-eth/link.dnl` (or the path as known in the workspace) from
which the C code was derived.

- If the C code **diverges** from `link.dnl` in the suspect area: the
  divergence is the likely bug. Align the C code with the ground-truth script
  and redeploy (Step 3).
- If the C code **matches** `link.dnl`: the C implementation is faithful to
  the ground truth. Proceed to Step 5 to verify using the DNL engine directly.

---

## Step 5 — Run with DNL Engine (Ground Truth Verification)

If the C code matches the ground truth but the test still fails, verify whether
the issue exists in the ground-truth DNL engine itself by switching run mode.

**Important**: A full platform reset is not required to switch DNL run mode —
you can switch by setting the DNL config and performing a Link Reset (LINKR)
via the LM CLI. However, if the Link Manager is not currently running, deploy
it first using `lm_fw_deploy` before issuing the LINKR.

On **each** platform:

1. Configure DNL run mode to **DNL engine** using the MCP `set_dnl_config`
   tool:
   - `dnl_engine = 1`
   - `dnl_hal = 0`
   - `dnl_timings = 0`
   - `dnl_timings_window = 10`
2. Perform a Link Reset (LINKR) via the MCP `lm_cli_command` tool to apply
   the new mode without a full platform reset:
   ```
   reset_imcr_linkr -reset_type 2
   ```

Re-run the test from `lm_test_execution`.

> **Note**: When running in DNL engine mode, log messages from the C DNL HAL
> code will not appear. Only LM framework-level logs will be visible.

---

## Step 6 — Interpret the Ground Truth Result

### Test passes with DNL engine

The ground-truth DNL script works correctly. The bug is in the C DNL HAL
implementation. Go back to Step 4 and fix the C code to align with
`link.dnl`.

### Test fails with DNL engine

The failure is present even in the ground-truth script. The test itself is
not valid under the current platform/configuration. Inform the user:

> "The test failed even when running with the DNL engine (ground truth). The
> test result is not valid under the current platform configuration. Please
> review the test plan or platform setup."

**Stop** — do not attempt further code fixes.

---

## Returning to Normal Operation

After a successful debug cycle and code fix:

1. Switch back to **DNL HAL** mode by setting `set_dnl_config` with
   `dnl_hal=1`, `dnl_engine=0`, then performing a LINKR:
   ```
   reset_imcr_linkr -reset_type 2
   ```
   If the library was updated, use `lm_fw_deploy` to rebuild and redeploy
   (which requires a platform reset before loading the new library).
2. Re-run the full test from `lm_test_execution` to confirm the fix resolves
   the failure.
