---
name: lm-fw-deploy
description: >
  Guides the agent through a complete Link Manager firmware deployment
  on a silicon platform using the Platform Manager MCP tools.
---
# Deploy Link Manager Firmware

This skill guides the agent through a complete Link Manager firmware deployment
on a silicon platform using the Platform Manager MCP tools.

---

## Step 1 — Resolve the Platform Host Address

If the user has **not** specified the host address, ask:

> "What is the host address (hostname or IP) of the target silicon platform?"

Do not proceed until you have the host address.

---

## Step 2 — Rebuild Link Manager Firmware (Optional)

If the user has **not** mentioned whether to rebuild the Link Manager firmware,
ask:

> "Do you want to rebuild the Link Manager firmware before deploying?"

- If the user answers **no**: skip this step and continue to Step 3.
- If the user answers **yes**:
  1. Search the workspace for an MCP tool capable of building the Link Manager.
     Look for MCP server definitions (e.g. `.vscode/mcp.json`, `mcp.json`,
     `*.mcp.json`) and scan their tool lists for a tool whose name or
     description relates to building / compiling the Link Manager (e.g. names
     containing `build`, `compile`, `lm`, `link_manager`, or similar).
  2. **If a matching build tool is found**: invoke it and wait for it to
     complete.
     - If it fails, show:
       > "Link Manager build failed: `<error text>`. Cannot continue deployment."

       **Stop the deployment workflow.**
     - If it succeeds, continue to Step 3.
  3. **If no matching build tool is found**, inform the user:
     > "Could not find an MCP tool for building the Link Manager in this
     > workspace. The build step will be skipped."

     Then ask:
     > "Do you want to continue with deployment using the existing binary?"

     - If the user says **yes**: continue to Step 3.
     - If the user says **no**: **stop the deployment workflow**.

---

## Step 3 — Pre-flight: Gather and Validate File Paths

Before touching the platform, collect and validate **all local file inputs**.
This prevents the workflow from failing mid-way (e.g. after a platform reset)
due to a missing file.

### 3a — Link Manager library

- If the user has **not** specified a library path: resolve the default path by
  joining the workspace root with the relative path
  `userspace/build/mev_imc_lm/mmg/debug/build/debug/lib/liblm.so.0.0` and
  inform the user:
  > "Using default library path: `<resolved_absolute_path>`"
- If the user has **provided** a specific path: use it as-is.

**Verify that the file exists** on the local filesystem at the resolved path.

- If the file **does not exist**, show:
  > "Library file not found at `<path>`. Please provide a valid path to `liblm.so.0.0`."

  Ask the user to supply a corrected path, then re-validate. **Repeat until a
  valid path is confirmed before continuing.**

Store this validated path — it will be used in Step 9 without asking again.

### 3b — Topology file

If the user has **not** mentioned whether a topology file is needed, ask:

> "Do you want to load a new topology file onto the platform?
> If yes, please provide the path to the topology file."

- If the user answers **no**: mark topology as not needed and skip to Step 4.
- If the user provides a path: **verify the file exists** on the local
  filesystem.
  - If the file **does not exist**, show:
    > "Topology file not found at `<path>`. Please provide a valid path or
    > answer 'no' to skip topology loading."

    Ask the user to correct the path or choose to skip. **Repeat until the
    path is valid or the user opts out.**

Store this validated path (or "skip") — it will be used in Step 8 without
asking again.

Only when **all provided paths have been validated** continue to Step 4.

---

## Step 4 — Authenticate with the Platform Server

Call the MCP tool **`query_server_version`** with the provided `host` (and the
default port unless the user specified one).

- If the call **succeeds** (response starts with `VERSION|`): authentication
  is confirmed — continue to Step 5.
- If the call returns an `ERROR:` prefix or raises a connection exception:
  show the user a clear error message, e.g.:

  > "Failed to connect to the platform server at `<host>`. Error: `<error text>`.
  > Please verify the host address and that the Silicon Platform Server is
  > running."

  **Stop the deployment workflow** — do not continue.

---

## Step 5 — Check Platform Status

Call the MCP tool **`get_platform_status`** with the same `host`.

- If the call returns an `ERROR:` prefix or raises an exception:
  show:

  > "Failed to retrieve platform status from `<host>`. Error: `<error text>`."

  **Stop the deployment workflow.**

Parse the response:

| Response prefix | Meaning |
|---|---|
| `STATUS:RUNNING\|…` | Link Manager is already running → go to **Step 6a** |
| `STATUS:LM_NOT_RUNNING\|…` | Platform is alive, LM is not running → go to **Step 6b** |
| `STATUS:NOT_REACHABLE\|…` | Platform is not responding → go to **Step 6a** |

---

## Step 6a — Reset the Platform (Required)

Reached when: Link Manager is already running **or** the platform is not
reachable.

Call the MCP tool **`reset_silicon_platform`** with `host`.

- If the call returns an `ERROR:` prefix or raises an exception, show:

  > "Platform reset failed: `<error text>`. Cannot continue deployment."

  **Stop the deployment workflow.**

After a successful reset, continue to **Step 7**.

## Step 6b — Platform is Ready

Reached when: platform is alive but Link Manager is not running.

No reset is needed. Continue directly to **Step 7**.

---

## Step 7 — Configure DNL Runtime Mode

If the user has **not** specified a running mode, ask:

> "Which running mode should be used for the Link Manager?
> Please choose one of:
> - **DNL engine** — uses the DNL scripting engine
> - **DNL HAL** — uses the C-converted DNL (HAL mode)"

Map the chosen mode to MCP parameters:

| User choice | `dnl_engine` | `dnl_hal` |
|---|---|---|
| DNL engine | `1` | `0` |
| DNL HAL | `0` | `1` |

Always use **timing logging = off** and **timing window = 10**:
- `dnl_timings = 0`
- `dnl_timings_window = 10`

Call the MCP tool **`set_dnl_config`** with:
- `dnl_hal` — from the table above
- `dnl_engine` — from the table above
- `dnl_timings = 0`
- `dnl_timings_window = 10`
- `host`

If the call returns an `ERROR:` prefix or raises an exception, show:

> "Failed to configure DNL mode: `<error text>`. Cannot continue deployment."

**Stop the deployment workflow.**

---

## Step 8 — Load Topology (Optional)

Use the topology path (or skip decision) already resolved and validated in
**Step 3b**. Do **not** ask the user again.

- If topology was marked as **not needed** in Step 3b: skip this step and
  proceed to Step 9.
- Otherwise: call the MCP tool **`load_topology`** with:
  - `local_file_path` — the validated path from Step 3b
  - `host`

  If the call returns an `ERROR:` prefix or raises an exception, show:

  > "Failed to load topology: `<error text>`. Cannot continue deployment."

  **Stop the deployment workflow.**

---

## Step 9 — Load Link Manager Library

**Important**: the library file must be the versioned binary named exactly
`liblm.so.0.0` (the real file, **not** a symlink such as `liblm.so` or
`liblm.so.0`).

Use the library path already resolved and validated in **Step 3a**. Do **not**
ask the user again and do **not** re-check the file existence — it was already
confirmed.

Call the MCP tool **`load_library`** with:
- `local_file_path` — the validated path from Step 3a
- `host`

If the call returns an `ERROR:` prefix or raises an exception, show:

> "Failed to load the Link Manager library: `<error text>`.
> Cannot continue deployment."

**Stop the deployment workflow.**

---

## Step 10 — Run the Link Manager

Call the MCP tool **`run_link_manager`** with `host`.

- If the call returns an `ERROR:` prefix or raises an exception, show:

  > "Failed to start the Link Manager: `<error text>`."

- If the call succeeds, confirm to the user:

  > "Link Manager has been successfully deployed and started on `<host>`."

---

## Error Handling Summary

At every step where an MCP tool call fails:
1. Show a **clear, user-readable error message** that includes the step name
   and the error text returned by the MCP tool.
2. **Stop** the deployment workflow immediately — do not attempt subsequent
   steps.

Never silently swallow errors or continue past a failed step.
