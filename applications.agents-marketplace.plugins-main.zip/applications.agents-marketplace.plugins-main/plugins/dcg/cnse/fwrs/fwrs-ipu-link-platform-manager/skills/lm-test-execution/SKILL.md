---
name: lm-test-execution
description: >
  Guides the agent through executing a Link Manager test plan on silicon
  platforms using the Platform Manager MCP tools and the LM CLI MCP tool.
  Pre-condition: Link Manager must already be running on all target platforms.
  Use the lm-fw-deploy skill first if it is not.
---
# Link Manager Test Execution

This skill guides the agent through executing a Link Manager test plan on
silicon platforms using the Platform Manager MCP tools and the LM CLI MCP tool.

**Pre-condition**: Link Manager must already be running on all target platforms
before starting this skill. Use the `fw_deploy` skill first if it is not.

---

## Step 1 — Locate and Read the Test Plan

If the user has **not** specified the path to the test plan, ask:

> "Please provide the path to the test plan file."

Once the path is known, read the file's full contents so you understand:

- The test steps and their order
- The success criteria for each step
- Any expected log patterns that confirm correct behaviour

Do **not** proceed until the test plan has been fully read. If the file cannot
be found at the provided path, tell the user:

> "Could not find the test plan file at `<path>`. Please verify the path and try again."

---

## Step 2 — LM CLI Command Reference

Commands are sent via the Platform Manager MCP `lm_cli_command` tool, which
pipes the command string into `lm_interfaces_cli.py` on the server.

---

### PHY / Link Configuration

#### `set_phy_config`

Set PHY configuration parameters for a port.
When `auto_link_update=0`, must be followed by `setup_link_and_restart_an` to apply changes.
When `auto_link_update=1`, equivalent to calling `setup_link_and_restart_an` immediately.

| Parameter | Values | Default | Description |
|-----------|--------|---------|-------------|
| `-port_num` | 0–7 | 0 | Port number |
| `-link_enable` | 0–1 | 1 | Enable/disable link |
| `-auto_link_update` | 0–1 | 1 | Auto-apply config changes |
| `-phy_type_0..7` | hex | 0 | PHY type bitmap per lane group |
| `-rsfec_544_req` | 0–1 | 0 | Request RS-FEC 544 |
| `-rsfec_528_req` | 0–1 | 0 | Request RS-FEC 528 |
| `-krfec_25g_req` | 0–1 | 0 | Request KR-FEC (25G) |
| `-krfec_10g_req` | 0–1 | 0 | Request KR-FEC (10G) |
| `-ll_rsfec_272_req` | 0–1 | 0 | Request LL-RS-FEC 272 |
| `-rsfec_int_req` | 0–1 | 0 | Request internal RS-FEC |
| `-krfec_10g_abl` | 0–1 | 0 | Advertise KR-FEC 10G ability |
| `-krfec_25g_abl` | 0–1 | 0 | Advertise KR-FEC 25G ability |
| `-rsfec_528_abl` | 0–1 | 0 | Advertise RS-FEC 528 ability |
| `-ll_rsfec_50g_abl` | 0–1 | 0 | Advertise LL-RS-FEC 50G ability |
| `-ll_rsfec_100g_abl` | 0–1 | 0 | Advertise LL-RS-FEC 100G ability |
| `-ll_rsfec_200g_abl` | 0–1 | 0 | Advertise LL-RS-FEC 200G ability |
| `-no_fec_abl` | 0–1 | 0 | Advertise No-FEC ability |
| `-lesm_en` | 0–1 | 0 | Enable LESM (Link Error State Machine) |

---

#### `setup_link_and_restart_an`

Apply pending `set_phy_config` parameters, restart Auto-Negotiation, or reset the link.

| Parameter | Values | Default | Description |
|-----------|--------|---------|-------------|
| `-port_num` | 0–7 | 0 | Port number |
| `-link_enable` | 0–1 | 1 | Enable/disable link |
| `-link_restart` | 0–1 | 1 | Restart AN or reset link |

---

#### `set_port_option`

Set the active port topology option (e.g., 1×400G, 2×200G, 4×100G).
Must be followed by `reset_imcr_linkr -reset_type 2` (LINKR) to take effect.

| Parameter | Values | Default | Description |
|-----------|--------|---------|-------------|
| `-port_num` | 0–7 | 0 | Port number |
| `-port_option` | 0–15 | 0 | Port topology option index |

---

#### `get_port_option`

Retrieve available port topology options for a port.

| Parameter | Values | Default | Description |
|-----------|--------|---------|-------------|
| `-port_num` | 0–7 | 0 | Port number |

---

#### `get_phy_capabilities`

Query PHY capabilities for a port.

| Parameter | Values | Default | Description |
|-----------|--------|---------|-------------|
| `-port_num` | 0–7 | 0 | Port number |
| `-report_mode` | 0–2 | 0 | 0=topology only, 1=topology+media, 2=active config |

---

#### `get_link_status`

Get current link status, negotiated speed, PHY type, FEC, and operating parameters.

| Parameter | Values | Default | Description |
|-----------|--------|---------|-------------|
| `-port_num` | 0–7 | 0 | Port number |
| `-brief` | 0–1 | 0 | 1 = condensed output |

---

### PHY Debug & Reset

#### `set_phy_debug`

Reset a specific PHY or enable/disable the Link Manager.

| Parameter | Values | Default | Description |
|-----------|--------|---------|-------------|
| `-port_num` | 0–7 | 0 | Port number |
| `-port_valid` | 0–1 | 0 | Whether port_num is valid |
| `-disable_port` | 0–1 | 0 | Disable the specified port |
| `-disable_all_ports` | 0–1 | 0 | Disable all ports |
| `-phy_reset` | 0–2 | 0 | PHY reset type |

---

#### `get_phy_debug`

Retrieve the current Link Manager state.

| Parameter | Values | Default | Description |
|-----------|--------|---------|-------------|
| `-port_num` | 0–7 | 0 | Port number |

---

#### `reset_imcr_linkr`

Trigger an IMC Reset (IMCR) or Link Reset (LINKR).

| Parameter | Values | Default | Description |
|-----------|--------|---------|-------------|
| `-reset_type` | 1–2 | 2 | 1=IMCR (full IMC reset), 2=LINKR (link reset only) |

**Example — trigger LINKR:**
```
reset_imcr_linkr -reset_type 2
```

---

#### `reset_dnl`

Reset the LM firmware and DNL engine without resetting the PHYSS. No parameters required.

---

### Loopback

#### `set_phy_loopback`

Enable or disable PHY loopback. Only one loopback of any type/level is allowed per port at a time.

| Parameter | Values | Default | Description |
|-----------|--------|---------|-------------|
| `-port_num` | 0–7 | 0 | Port number |
| `-lpbk_enable` | 0–1 | 0 | 0=disable, 1=enable |
| `-lpbk_type` | 0–1 | 0 | 0=local (host→host at PHY), 1=remote (line side looped back to LP) |
| `-lpbk_level` | 0–1 | 0 | 0=PMA level, 1=PCS level |

---

#### `set_mac_loopback`

Enable or disable MAC near-end loopback.

| Parameter | Values | Default | Description |
|-----------|--------|---------|-------------|
| `-port_num` | 0–7 | 0 | Port number |
| `-lpbk_enable` | 0–1 | 0 | 0=disable, 1=enable |

---

#### `mac_set_lpbk`

Set MAC loopback mode.

| Parameter | Values | Default | Description |
|-----------|--------|---------|-------------|
| `-mac_port` | 0–7 | 0 | MAC port number |
| `-mac_lpbk_type` | 0–2 | 0 | 0=none, 1=far-end (RX→TX), 2=near-end (TX→RX) |

---

#### `mac_get_lpbk`

Retrieve current MAC loopback mode.

| Parameter | Values | Default | Description |
|-----------|--------|---------|-------------|
| `-mac_port` | 0–7 | 0 | MAC port number |

---

### MAC Control & Status

| Command | Parameters | Description |
|---------|-----------|-------------|
| `mac_init` | — | Initialize all MACs |
| `mac_set_state_enable` | `-mac_port` | Enable a MAC |
| `mac_set_state_disable` | `-mac_port` | Disable a MAC |
| `mac_get_state` | `-mac_port` | Retrieve MAC state |
| `mac_get_status` | `-mac_port` | Retrieve MAC status |
| `mac_get_speed` | `-mac_port` | Retrieve current MAC speed |
| `mac_get_counters` | `-mac_port` | Read MAC traffic counters |
| `mac_clear_statistics` | `-mac_port` | Clear MAC statistics counters |
| `mac_set_max_frame_size` | `-mac_port`, `-max_frame_size` (hex, default 0x600) | Set maximum Ethernet frame size |
| `mac_get_max_frame_size` | `-mac_port` | Get maximum frame size |
| `mac_set_ifg_params` | `-mac_port`, `-ifg_type` (0=fixed/1=DIC), `-ifg_min_byte` (0–68) | Set inter-frame gap parameters |
| `mac_get_ifg_params` | `-mac_port` | Get inter-frame gap parameters |
| `mac_set_src_addr` | `-mac_port`, `-mac_addr_l`, `-mac_addr_h` | Set MAC source address |
| `mac_get_src_addr` | `-mac_port` | Get MAC source address |
| `mac_set_lpi` | `-mac_port`, `-lpi_mode` (0=disabled/1=enabled), `-mac_speed` | Set Low Power Idle mode |
| `mac_get_lpi` | `-mac_port` | Get Low Power Idle mode |
| `mac_set_fc_timer` | `-mac_port`, `-fc_time` (0–65534) | Set flow control timer |
| `mac_get_fc_timer` | `-mac_port` | Get flow control timer |

---

### I2C Access

#### `read_i2c`

| Parameter | Values | Default | Description |
|-----------|--------|---------|-------------|
| `-i2c_bus_addr` | 0–127 | 0x50 | I2C device address |
| `-i2c_offset` | 0–255 | 0 | Register offset to read from |
| `-i2c_data_len` | 0–15 | 1 | Number of bytes to read |
| `-i2c_offset_size` | 0–2 | 1 | Offset size in bytes |
| `-i2c_repeated_start` | 0–1 | 0 | Use I2C repeated start condition |

---

#### `write_i2c`

| Parameter | Values | Default | Description |
|-----------|--------|---------|-------------|
| `-i2c_bus_addr` | 0–127 | 0x50 | I2C device address |
| `-i2c_offset` | 0–255 | 0 | Register offset to write to |
| `-i2c_data_len` | 0–15 | 1 | Number of bytes to write |
| `-i2c_data` | hex | 0 | Data to write |
| `-i2c_offset_size` | 0–2 | 1 | Offset size in bytes |

---

### DNL Scripting & GPIO

#### `dnl_script`

Execute a DNL engine script by activity ID.

| Parameter | Values | Default | Description |
|-----------|--------|---------|-------------|
| `-activity_id` | hex | 0 | Unique script identifier |
| `-dnl_port` | 0–8 | 0 | DNL port |
| `-sto0..3` | hex | 0 | Store registers passed as input to the script |

---

#### `get_gpio_activity`

Get the configuration and current value of a GPIO (activity ID 0x12).

| Parameter | Values | Default | Description |
|-----------|--------|---------|-------------|
| `-node_handle` | 0–127 | 0 | GPIO controller node handle |
| `-gpio_num` | 0–31 | 0 | GPIO pin number |
| `-gpio_polarity` | 0–1 | 0 | 0=active low, 1=active high |

---

#### `set_gpio_activity`

Set the value, direction, polarity, and interrupt mode of a GPIO (activity ID 0x11).

| Parameter | Values | Default | Description |
|-----------|--------|---------|-------------|
| `-node_handle` | 0–127 | 0 | GPIO controller node handle |
| `-gpio_num` | 0–31 | 0 | GPIO pin number |
| `-gpio_mode` | 0–1 | 0 | 0=basic (value only), 1=advanced (full config) |
| `-gpio_direction` | 0–1 | 0 | 0=output, 1=input |
| `-gpio_polarity` | 0–1 | 0 | 0=active low, 1=active high |
| `-gpio_value` | 0–1 | 0 | Output value to set |
| `-gpio_interrupt` | 0–6 | 0 | 0=none, 1=rising, 2=falling, 3=change, 5=high level, 6=low level |

---

### Logging

#### `set_logging_level`

Set the log verbosity for a specific LM firmware component.

| Parameter | Values | Description |
|-----------|--------|-------------|
| `-log_component` | 1–8 | 1=dnl, 2=tpg, 3=lnk, 4=common, 5=lm_server, 6=app, 7=dnl_script, 8=dnl_hal |
| `-log_level` | 0–5 | 0=none, 1=error, 2=warning, 3=info, 4=debug, 5=trace |

---

#### `get_logging_level`

Retrieve the current log level for a specific component.

| Parameter | Values | Description |
|-----------|--------|-------------|
| `-log_component` | 1–8 | See component list above |

---

### General

| Command | Description |
|---------|-------------|
| `help` | List all available commands |
| `help <command>` | Show help for a specific command |
| `quit` | Exit the CLI |

---


## Step 3 — Understand Logical-to-Physical Port Mapping

LM CLI commands operate on **logical ports** (sequential: 0, 1, 2, …).
Platform logs report **physical ports** (aligned to PHY lanes, e.g. 0, 4, 8, …).

Before executing tests:

1. Run `get_port_option -port_num 0` on each platform to read the active port
   topology option (e.g. 1×400G, 2×200G, 4×100G). This tells you how many
   logical ports are active.
2. Run `get_phy_capabilities -port_num <n> -report_mode 2` for each logical
   port to read the active PHY lane assignments, which gives the
   logical → physical port mapping.
3. Record the mapping so it can be used when cross-referencing CLI output with
   log entries throughout the test.

---

## Step 4 — Set DNL HAL Log Level to Debug

On **each** platform involved in the test, use the Platform Manager MCP
`lm_cli_command` tool to set the log level of DNL HAL component (component
number **8**) to **debug**:

```
set_logging_level -log_component 8 -log_level 4
```

(Use the exact command syntax as learned from `mev_imc_lm/tools/` in Step 2.)

- If the command fails on any platform, show:

  > "Failed to set DNL HAL log level on `<host>`: `<error text>`."

  **Stop** the test execution.

---

## Step 5 — Execute the Test Plan Steps

Work through each step in the test plan in order.

For each step:

1. Identify which LM CLI command(s) are required.
2. Send them via the Platform Manager MCP `lm_cli_command` tool on the
   appropriate platform(s).
3. If a step requires actions on **both** platforms, perform them — use
   parallel execution where possible to save time (see `parallel_platform_ops`
   skill if available).
4. Check the immediate command response against the step's expected output.

### On step failure

If any test step command returns an error or an unexpected response:
- Do **not** retry the step.
- Do **not** attempt automatic diagnosis here.
- Record which step failed and the exact error.
- Proceed to the **lm-debug** skill for diagnosis.

---

## Step 6 — Verify Success in Logs

After all test plan steps have been executed and their direct responses look
correct, retrieve logs from each platform using the Platform Manager MCP
`retrieve_logs` tool and verify the expected flow appears in the logs.

When reading logs:

- There may be **multiple consecutive log files** (e.g. `lm.log.0`,
  `lm.log.1`, …) because each file has a maximum size and logging continues in
  the next file. Read all consecutive files in order to get the full picture.
- Translate physical port numbers in the logs back to logical port numbers
  using the mapping established in Step 3.
- Match log entries against the expected log patterns described in the test
  plan.

### Success criteria

A test run is considered **successful** only when **both** of the following
are true:

1. All test plan step responses met the defined success criteria.
2. The logs confirm the expected flow occurred, with no unexpected errors or
   skipped states.

If either criterion is not met, the test has failed — proceed to the
**lm-debug** skill.

---

## Step 7 — Report Result

When all criteria are met, confirm to the user:

> "All test steps passed and logs confirm the expected flow. Test run
> successful."

Include a brief summary of:
- Which platforms were tested
- Which test plan was executed
- Any notable observations from the logs
