---
name: platform-manager-server-install
description: >
  Guides through building the Silicon Platform Server package locally
  and installing it on a remote Windows machine.
---
# Install Platform Server on Remote Machine

This skill guides through building the Silicon Platform Server package locally
and installing it on a remote Windows machine.

---

## Step 1 — Locate the Build Script

Find `create_platform_server_package.bat` in the workspace. It lives under:

```
silicon platform manager/server/create_platform_server_package.bat
```

Confirm the file exists before proceeding. If it is not found, tell the user:

> "Could not find `create_platform_server_package.bat` in the workspace.
> Please verify the silicon platform manager project is present."

**Stop** if the file is not found.

---

## Step 2 — Build the Server Package

Instruct the user to run the build script from the `server/` directory:

```bat
cd "silicon platform manager\server"
create_platform_server_package.bat
```

Explain what the script does:
- Downloads the Python embeddable runtime (requires internet access and `curl`)
- Installs all Python dependencies into the package
- Assembles the complete server package
- Produces **`platform_server_package.zip`** in the `silicon platform manager\server\` directory of the workspace

Let the user know:
- The build may take several minutes (Python and dependencies are downloaded)
- Internet access is required during the build

Wait for the user to confirm the build completed successfully and that
`platform_server_package.zip` exists in `silicon platform manager\server\`
before continuing. Do **not** ask about or wait for any intermediate folder —
only the final zip file matters.

---

## Step 3 — Copy the Zip to the Remote Machine

Present the available copy methods to the user:

**Option A — Windows File Explorer / network share:**
```
Copy <workspace>\silicon platform manager\server\platform_server_package.zip to \\<remote-host>\C$\Silicon Platform Server\
```

**Option B — SCP / PSCP:**
```bat
scp "silicon platform manager\server\platform_server_package.zip" <user>@<remote-host>:"C:/Silicon Platform Server/"
```

**Option C — PowerShell (if WinRM is enabled on the remote machine):**
```powershell
Copy-Item -Path ".\silicon platform manager\server\platform_server_package.zip" `
          -Destination "C:\Silicon Platform Server\" `
          -ToSession (New-PSSession -ComputerName <remote-host>)
```

If the user has not mentioned a preferred method, ask:

> "Which method would you like to use to copy the package to the remote machine
> (Explorer/network share, SCP, or PowerShell)?"

Then ask:

> "Would you like me to run the copy for you, or will you do it yourself?"

- If the user wants the agent to perform the copy: execute the chosen method,
  using `C:\Silicon Platform Server\` as the destination unless the user
  specifies otherwise.
- If the user will do it themselves: show the relevant command/instructions
  and wait for them to confirm the copy is complete before continuing.

---

## Step 4 — Unzip on the Remote Machine

On the remote machine, unzip the package. Suggested command (PowerShell):

```powershell
Expand-Archive -Path "C:\Silicon Platform Server\platform_server_package.zip" `
               -DestinationPath "C:\Silicon Platform Server\" -Force
```

Or with the built-in Windows extraction wizard: right-click the zip →
**Extract All…** → choose `C:\Silicon Platform Server\`.

After extraction the following files and folders should be present inside
`C:\Silicon Platform Server\`:

| Item | Purpose |
|---|---|
| `python\` | Bundled Python runtime |
| `silicon_platform_server.py` | Main server script |
| `resources\` | Button images and other resources |
| `.env.example` | Credentials configuration template |
| `start_server.bat` | Start server in background |
| `start_server_console.bat` | Start server with console output |
| `stop_server.bat` | Stop the background server |
| `check_status.bat` | Check whether the server is running |
| `view_logs.bat` | Tail the server log |
| `README.txt` | Quick-start instructions |

---

## Step 5 — Configure Credentials

On the remote machine:

1. Rename `.env.example` to `.env`.
2. Open `.env` and set:
   - `SPM_USERNAME` — the username clients will authenticate with
   - `SPM_PASSWORD` — the password clients will authenticate with

```
SPM_USERNAME=admin
SPM_PASSWORD=yourpassword
```

> **Important**: the `.env` file must be named exactly `.env` (not `.env.txt`).
> In Windows Explorer, make sure "Hide extensions for known file types" is
> disabled so you can verify the name.

---

## Step 6 — Configure the Server

Open `silicon_platform_server.py` on the remote machine and update the
configuration section near the top of the file:

- `BOBCAT_APP_PATH` — full path to the Bobcat V5 executable
- `PUTTY_APP_PATH` — full path to the PuTTY executable
- `PUTTY_SESSION` or `PUTTY_SERIAL_PORT` — serial connection settings

If the user is unsure about these values, refer them to
`EXTERNAL_DEPENDENCIES.md` in the package for tool installation instructions.

---

## Step 7 — Configure the Reset Button Image

The server uses image recognition to click the platform reset button. A
screenshot of the button is required.

1. Follow the instructions in `BUTTON_SETUP.md` (in the project repository)
   to capture the button screenshot.
2. Save the image as `reset_button.png`.
3. Place it in the `resources\` folder next to `silicon_platform_server.py`
   on the remote machine.

---

## Step 8 — Configure the Firewall

The server listens on **TCP port 5555** by default. On the remote machine,
open an inbound firewall rule for this port:

```powershell
# Run as Administrator
New-NetFirewallRule -DisplayName "Silicon Platform Server" `
                   -Direction Inbound -Protocol TCP -LocalPort 5555 `
                   -Action Allow
```

Or through Windows Defender Firewall → Advanced Settings → Inbound Rules →
New Rule → Port → TCP 5555 → Allow.

---

## Step 9 — Start the Server

On the remote machine, start the server by double-clicking one of the launcher
scripts:

| Script | When to use |
|---|---|
| `start_server_console.bat` | First-time setup — shows live output for debugging |
| `start_server.bat` | Normal operation — runs minimised in the background |

To verify the server started correctly, run `check_status.bat` or inspect
`server_output.log` with `view_logs.bat`.

Confirm to the user:

> "The Silicon Platform Server should now be running on `<remote-host>:5555`.
> You can connect to it from the VS Code extension or the MCP client."
