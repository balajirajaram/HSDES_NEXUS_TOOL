---
name: create-fw-val-env
description: >
  Set up the IPU / NSC / CNIC firmware development and validation
  environment on an Automaton machine. Covers Automaton checkout,
  env_creation.sh execution, Docker configuration, imc_setenv sourcing,
  building all FW components, NVM generation, and Simics bring-up.
  Use this skill when the user asks to create, configure, or
  troubleshoot a FW Validation development or test environment.
  Also use this skill when the user says they are ready to open a
  VS Code workspace, build a dev container, rebuild a container,
  or verify a container after setup.
  Also use this skill when the user says they just built the FW
  validation dev container and wants to verify the environment.
  Also use this skill when the user says "I just built the FW
  validation dev container" even without asking to verify.
---

# FW Validation Environment Setup

Actively execute the environment setup on behalf of the user.
Do not just describe steps — run commands in the terminal,
respond to interactive prompts, check outputs, and report results
at each stage before continuing.

## Entry-point routing

Before doing anything else, determine where in the workflow the user
is and jump directly to that step. Do NOT start at Step 1 if the
user is already mid-workflow.

| If the user says... | Jump to |
|---|---|
| Ready to open VS Code workspace / build the container / imc_setenv is sourced | **Step 7** (ask for repo folder if not known) |
| Just built the container / verify the environment / container is ready / "I just built the FW validation dev container" / "Please verify the environment" | **Step 8** |
| env_creation.sh finished / repo is cloned / ready to source imc_setenv | **Step 6** |
| Starting fresh / set up a new environment / no context given | **Step 1** |

## Prerequisites

Before starting, check whether the **intel-wiki** MCP server is available
by testing if the `#tool:mcp_intel-wiki_confluence_get_page` tool can be
called. If it is **not available**, attempt a best-effort install:

1. Inform the user:
   > The intel-wiki MCP server is not installed. Attempting to install it
   > now for live wiki lookups (best effort — setup will continue either way).

2. Locate the toolkit root and run the install:
   ```bash
   find ~ -maxdepth 5 -name "manifest-basic.json" -path "*/manifests/*" 2>/dev/null | head -1
   ```
   Then from the toolkit root:
   ```bash
   cd <toolkit-root> && python3 setup.py --manifest manifests/manifest-basic.json --level user
   ```

3. After the command completes (success or failure), **continue to the
   next step regardless**. The skill functions without the MCP using the
   documented steps below.

## Dependencies

This skill works best with the **intel-wiki** MCP server (see Prerequisites
above). Without it, wiki sync is skipped and the documented steps below
are used as-is.

## First action — sync with the wiki

**Before giving any instructions**, attempt to fetch the latest
version of both wiki pages using the
`#tool:mcp_intel-wiki_confluence_get_page` tool:

- IPU Automaton Cheat Sheet: `pageId: "4197617394"`
- NSC env getting started: `pageId: "3769121182"`

If the tool is **available and succeeds**: compare the wiki content
against the steps documented below. If the wiki contains **new or
changed steps**, inform the user and follow the **wiki version** (it
is the source of truth).

If the tool is **not available**: show the recommendation above, then
proceed with the documented steps below.

## Execution approach

Follow this workflow for every setup request:

### Step 1 — Collect parameters upfront

Before running anything, use `#tool:vscode_askQuestions` to collect
all required inputs interactively in a single call:

```
questions:
  - header: platform
    question: "Which platform are you setting up?"
    options:
      - label: nsc
        recommended: true
      - label: mmg
      - label: mev
      - label: lwc
    allowFreeformInput: false

  - header: folder_suffix
    question: "Folder suffix — appended to the repo folder name (e.g. 'myteam' → ~/projects/nsc_myteam_repo)"

  - header: branch
    question: "Branch to check out (leave blank for default: nssip-trunk for nsc/lwc, mev-trunk for mmg/mev)"

  - header: threads
    question: "Thread count for repo sync (leave blank for default: 72)"

  - header: copy_ssh
    question: "Copy SSH keys from /mnt/$USER/.ssh backup?"
    options:
      - label: "Yes"
        recommended: true
      - label: "No"
    allowFreeformInput: false

  - header: copy_netrc
    question: "Copy .netrc from /mnt/$USER/.netrc backup?"
    options:
      - label: "Yes"
        recommended: true
      - label: "No"
    allowFreeformInput: false

  - header: install_dt
    question: "Install DT? (skip if .netrc was copied)"
    options:
      - label: "Yes"
        recommended: true
      - label: "No"
    allowFreeformInput: false

  - header: clone_repo
    question: "Clone the repo?"
    options:
      - label: "Yes"
        recommended: true
      - label: "No"
    allowFreeformInput: false

  - header: install_simics
    question: "Install Simics? (only asked if cloning)"
    options:
      - label: "Yes"
        recommended: true
      - label: "No"
    allowFreeformInput: false

  - header: simics_domain
    question: "Simics domain (only if installing Simics)"
    options:
      - label: ger
        recommended: true
      - label: amr
    allowFreeformInput: false

  - header: install_docker
    question: "Install Docker?"
    options:
      - label: "Yes"
        recommended: true
      - label: "No"
    allowFreeformInput: false

  - header: install_swift
    question: "Install SWIFT? (only if cloning)"
    options:
      - label: "No"
        recommended: true
      - label: "Yes"
    allowFreeformInput: false

  - header: cpu_limiter
    question: "Set Simics CPU Limiter?"
    options:
      - label: "No"
        recommended: true
      - label: "Yes"
    allowFreeformInput: false
```

Map the answers to the script prompts before proceeding.

### Step 2 — Verify the terminal is on the Automaton

Run the following to confirm the working environment:

```bash
hostname && whoami && ls ~/gitProj/env_creation.sh
```

If `env_creation.sh` is not found, instruct the user to connect to
the Automaton host first (via Remote-SSH or direct SSH) before
continuing.

### Step 3 — Navigate and launch the script

```bash
cd ~/gitProj
./env_creation.sh <repo_name> <folder_suffix> [-b <branch>] [-j <threads>]
```

### Step 4 — Drive the interactive prompts

The script runs in a configuration phase — all prompts appear before
execution begins. Answer each prompt as it appears in the terminal,
mapping the user's answers collected in Step 1 to the prompt responses:

- `Yes/y/No/n` answers are accepted; the default is shown in `[...]`
- Send just Enter to accept the default

Watch for auto-skip messages (e.g. "SSH files in sync — skipping")
and do not send input for those prompts.

Additional interactive prompts that appear **during execution** (not
the configuration phase) are handled in **Step 5d** below.

### Step 5 — Monitor execution and report progress

**CRITICAL — polling rules (enforce strictly):**
- NEVER say "I'll be automatically notified" or any equivalent.
- NEVER yield back to the user while the script is still running.
- After every terminal check, immediately check again — loop until done.
- The only valid reason to stop looping is: `Environment setup completed
  successfully.` is visible, or an error occurs, or a password prompt appears.

**5a — SSH / .netrc / DT (fast steps)**
Check terminal output after sending each prompt answer. Report
auto-skips as they appear.

**5b — repo sync (long-running polling loop)**

The repo sync phase takes 15–30 minutes. During this entire time, run
a continuous polling loop — do NOT exit the loop to wait for the user:

```
LOOP:
  1. Check terminal output.
  2. If "repo sync" still running (in-progress lines or no new output):
       → Report "repo sync still running, checking again..." and go to step 1.
  3. If output shows SDK install / "imc_create_dockerfile" / Simics starting:
       → Exit loop and proceed immediately to 5c or 5d.
  4. If script printed "Environment setup completed successfully.":
       → Exit loop and proceed to Step 6.
  5. If error output is visible:
       → Stop, show the error, and wait for user instruction.
```

Seeing "in-place progress display" or "output won't change" is NOT a
reason to stop polling — check again immediately regardless.

**5c — imc_create_dockerfile.sh**
Check terminal output. Report when complete, then continue to 5d.

**5d — Simics install (tight monitoring — must not miss prompts)**

Enter the same polling loop as 5b. On EVERY check scan for these prompts:

1. `Enter domain (ger or amr) - blank defaults to ger:`
   → **Immediately** send the user's domain choice (or Enter for `ger`).
   → Then continue polling.

2. `Enter password for <domain>\<user>:`
   → **Do NOT send anything to the terminal.**
   → **Immediately** call `#tool:vscode_askQuestions`:
   ```
   questions:
     - header: simics_password_ack
       question: "⚠️ The Simics installer is waiting for your domain password."
       message: |
         Please switch to the terminal and type your domain password now.
         The terminal is waiting — it will not echo what you type.
         Click **Done** here only after you have pressed Enter in the terminal.
       options:
         - label: Done — I typed my password in the terminal
       allowFreeformInput: false
   ```
   → After the user clicks Done, resume the polling loop.

3. `Missing IMC images: simics_debug_image_128M_*`
   → Known non-fatal warning — continue polling.

**5e — Docker / SWIFT**
Check terminal output. Report when complete.

If any step fails, show the relevant error output and wait for the
user's instruction before continuing.

### Step 6 — Verify the environment and configure auto-load

Once the script prints `Environment setup completed successfully.`,
**immediately execute** the following steps in the terminal —
do not just describe them to the user.

**6a — Source the environment and verify:**

```bash
cd ~/projects/<repo_name>_<suffix>_repo && source imc_setenv <repo_name> && echo "IMC_ROOT=$IMC_ROOT"
```

- If `IMC_ROOT` is set and non-empty: proceed to step 6b.
- If `IMC_ROOT` is empty or the command errors: show the output and
  ask the user how to proceed before continuing.

**6b — Configure auto-load on login (recommended by wiki):**

```bash
echo "source ~/projects/<repo_name>_<suffix>_repo/imc_setenv <repo_name>" | sudo tee /etc/profile.d/setenv.sh > /dev/null && sudo chmod 644 /etc/profile.d/setenv.sh
```

- If this succeeds: report that the environment will now load
  automatically on every login.
- If `sudo` fails (permission denied): inform the user and suggest
  adding the `source` line manually to `~/.bashrc` instead.

Once both sub-steps complete, report:
> **Environment setup complete.**
> - Repo: `~/projects/<repo_name>_<suffix>_repo`
> - `IMC_ROOT`: (show value)
> - Auto-load on login: configured
> - For each new terminal tab, run: `source imc_setenv <repo_name>`

Then immediately proceed to Step 6c.

**6c — Add the Copilot skills mount to devcontainer.json:**

The `.devcontainer/devcontainer.json` generated by `imc_create_dockerfile.sh`
does not mount `~/.copilot` into the container. Without this mount,
Copilot skills are unavailable inside the dev container. Add it now:

```bash
python3 - <<'EOF'
import json, re

path = f"{__import__('os').path.expanduser('~')}/projects/<repo_name>_<suffix>_repo/.devcontainer/devcontainer.json"

with open(path) as f:
    content = f.read()

# Strip JS-style full-line comments before parsing (avoids corrupting URLs)
stripped = '\n'.join(l for l in content.splitlines() if not l.lstrip().startswith('//'))

data = json.loads(stripped)

mount = '--volume=/home/${localEnv:USER}/.copilot:/home/${localEnv:USER}/.copilot:rw'

run_args = data.get('runArgs', [])
if mount not in run_args:
    # Insert after the gitProj volume line
    for i, arg in enumerate(run_args):
        if 'gitProj' in arg:
            run_args.insert(i + 1, mount)
            break
    else:
        run_args.append(mount)
    data['runArgs'] = run_args
    # Write back preserving structure; fall back to json.dumps if gitProj not found
    gitproj_line = next((a for a in run_args if 'gitProj' in a), None)
    if gitproj_line:
        new_content = content.replace(
            f'"{gitproj_line}"',
            f'"{gitproj_line}",\n        "{mount}"'
        )
    else:
        new_content = json.dumps(data, indent=4)
    with open(path, 'w') as f:
        f.write(new_content)
    print("Added .copilot mount to devcontainer.json")
else:
    print(".copilot mount already present")
EOF
```

- If `Added .copilot mount` is printed: proceed to Step 7.
- If the script errors (e.g. JSON parse failure): manually add this
  line to the `runArgs` array in `devcontainer.json`, after the
  `gitProj` volume entry:
  ```
  "--volume=/home/${localEnv:USER}/.copilot:/home/${localEnv:USER}/.copilot:rw",
  ```

Then immediately proceed to Step 7.

### Step 7 — Build the Development Container in VS Code

If you do not know the repo folder path, run:

```bash
find ~/projects -maxdepth 2 -name "*.code-workspace" 2>/dev/null
```

Give the user **all four of the following** in a single response.
Start with 7a — it must be first.

**7a — ⚠️ Session boundary warning (output this first):**

> ⚠️ **Opening the workspace will reload VS Code into the dev container
> and end this chat session.** After the container builds, open a **new
> Remote-SSH VS Code window** connected to the Automaton host (not inside
> the container) to verify the running container in the next step.
> Skills are available inside the container because `~/.copilot` is mounted.
>
> Paste this prompt into that new chat to continue (replace `<REPO_FOLDER>`):
>
> `I just built the FW validation dev container. Please verify the environment. Repo: <REPO_FOLDER>`

**7b — Connect via Remote-SSH**
Open the Remote Explorer and connect to the Automaton host.

**7c — Open the workspace**
File → **Open Workspace From File...** → select the `.code-workspace`
file inside `<REPO_FOLDER>/`.

**7d — Rebuild the container**
`Ctrl+Shift+P` → **Dev Containers: Rebuild Without Cache**

Wait for: `Done. Press any key to close the terminal.`

Do not use `Open Folder in Container` (ignores existing devcontainer
config), `Reopen in Container` (uses cached image), or `Rebuild and
Reopen in Container`.

### Step 8 — Verify the container (Session 2 entry point)

When the user pastes the Session 2 prompt
(`I just built the FW validation dev container.`),
**immediately run:**

```bash
docker ps
```

- If a container is listed: report the container name and status, then output the final report below.
- If no container appears: run `docker ps -a` and report status.

**Final report (when container is running):**

> **Environment verified.**
> - Container: (show name/ID from `docker ps`)
> - Status: Running
>
> **Next step — verify Simics works:**
> ```bash
> cd ~/projects/<repo_folder>/sources/imc/tools/simics/batch/
> ./run_svl.sh
> ```
> If `run_svl.sh` completes without errors, the environment is fully ready.

**Known Docker issues and fixes:**

If the user reports a Docker permission error, run:

```bash
sudo usermod -aG docker "$USER" && sudo chmod 660 /var/run/docker.sock
```

If Docker is not running:

```bash
sudo systemctl start docker && sudo usermod -aG docker "$USER" && sudo chmod 660 /var/run/docker.sock && sudo systemctl enable docker
```

Re-run `docker ps` after fixing.

## When to use

- User asks to set up, create, or bootstrap an NSC / IPU / CNIC FW
  development or validation environment
- User asks how to get started with NSC / FW validation development
- User needs help running `env_creation.sh` or configuring the repo
- User asks about building NSC FW, generating NVM, or running Simics
- User is troubleshooting environment issues on an Automaton machine

---

> **Reference** — The sections below are human-readable documentation.
> The AI should use the **Execution approach** steps above to drive
> the workflow, not these sections.

## Request an Automaton Machine

1. Go to [Automaton IDC](https://automaton.itools.intel.com) and
   request a new checkout.
2. Select the machine name and disk space from the drop-down.
3. Wait ~40 minutes for the checkout to be ready.
4. Access the machine via VNC or SSH.

> **Note:** Automaton machines are erased automatically after a
> maximum of 120 days (default 90, extendable to 120).

## Run the Environment Creation Script

### Step 1 — Connect to the Automaton host

SSH to the Automaton machine and switch to your user account:

```bash
ssh <idsid>@<automaton_IP>   # use the password provided by Automaton
su <idsid>                    # or log in directly as your user
```

If asked to add the Automaton's fingerprint to SSH known hosts, answer `yes`.

### SSH Passwordless Login from Windows

To avoid entering a password every time, set up key-based authentication:

1. **Check and install OpenSSH client on Windows** (if not installed):
   In PowerShell (admin): `Get-WindowsCapability -Online -Name OpenSSH.Client*`
   If `State: NotPresent`: `Add-WindowsCapability -Online -Name OpenSSH.Client~~~~0.0.1.0`

2. **Generate an SSH key pair on Windows:**
   ```powershell
   ssh-keygen -t ed25519
   ssh-keygen -t rsa -b 4096
   ```
   Press Enter to accept default paths. Leave passphrase empty for passwordless login.

3. **Copy the public key to the Linux server:**
   ```powershell
   type $env:USERPROFILE\.ssh\id_ed25519.pub | ssh <user>@<automaton_ip> "mkdir -p ~/.ssh && cat >> ~/.ssh/authorized_keys && chmod 600 ~/.ssh/authorized_keys"
   ```
   Repeat for both your user and root.

4. **Add the host to your SSH config** (`%USERPROFILE%\.ssh\config`):
   ```
   Host <automaton_ip>
       HostName <automaton_ip>
       User <idsid>
       ForwardAgent yes
       ForwardX11 yes
       ForwardX11Trusted yes
   ```

### Step 2 — Navigate to the scripts directory

```bash
cd ~/gitProj
```

### Step 3 — Execute the environment creation script

**Syntax:**

```bash
./env_creation.sh <repo_name> <folder_suffix> [-b branch_name] [-j num_threads]
```

| Argument | Required | Description |
|---|---|---|
| `repo_name` | Yes | Platform: `nsc`, `mmg`, `mev`, or `lwc` |
| `folder_suffix` | Yes | Appended to the repo folder name: `~/projects/<repo_name>_<suffix>_repo` |
| `-b branch_name` | No | Branch to check out. Default: `nssip-trunk` (nsc/lwc), `mev-trunk` (mmg/mev) |
| `-j num_threads` | No | Threads for `repo sync`. Default: `72` |

**Examples:**

```bash
# NSC, folder suffix "myteam", default branch (nssip-trunk):
./env_creation.sh nsc myteam

# NSC, custom branch:
./env_creation.sh nsc myteam -b dev-nssip-trunk

# MMG:
./env_creation.sh mmg myteam

# MMG, custom branch:
./env_creation.sh mmg myteam -b dev-mev-trunk

# LWC:
./env_creation.sh lwc myteam
```

### Step 4 — Answer the configuration prompts

The script collects all answers **before** executing anything.
It auto-detects state and skips prompts that are not needed.

| # | Prompt | Default | Auto-skip condition |
|---|---|---|---|
| 1 | Copy SSH data from `/mnt/$USER/.ssh`? | `Yes` | SSH files already in sync with `~/.ssh` |
| 2 | Copy `.netrc` from `/mnt/$USER/.netrc`? | `Yes` | `.netrc` already in sync with `~/.netrc` |
| 3 | Install DT program? | `Yes` | Skipped if step 2 = Yes, or `.netrc` already in sync |
| 4 | Clone repo? | `Yes` | Never auto-skipped |
| 5 | Install Simics? | `Yes` | Skipped if step 4 = No |
| 6 | Install Docker? | `Yes` | Docker service is already running |
| 7 | Install SWIFT? | `No` | Skipped if step 4 = No |
| 8 | Set Simics CPU Limiter? | `No` | Never auto-skipped |

**First-time machine (nothing backed up yet):**
- SSH prompt is skipped with instructions to create and back up keys.
- `.netrc` prompt is skipped; DT will create it and back it up to `/mnt/$USER/.netrc` automatically.

**Subsequent machines (backup exists):**
- Answer `Yes` to Copy SSH and Copy `.netrc` to restore credentials.
- Answer `No` to Install DT (`.netrc` is already backed up).

### Step 5 — Wait for execution to complete

After all prompts are answered the script runs each selected step in order:

1. Fix SSH daemon
2. Copy SSH keys (if selected)
3. Copy `.netrc` (if selected)
4. Install DT → runs `dt install`, `dt update`, `dt setup`, backs up `.netrc` to `/mnt/$USER/.netrc`
5. Clone repo: creates `~/projects/<repo_name>_<suffix>_repo/`, runs `repo init` + `repo sync` + installs SDK
6. Auto-source `imc_setenv` and run `imc_create_dockerfile.sh`
7. Install Simics (if selected)
8. Set Simics CPU limiter (if selected)
9. Install Docker (if selected)
10. Install SWIFT (if selected)

## Source Environment Variables

After `env_creation.sh` completes, `imc_setenv` and `imc_create_dockerfile.sh`
have already been run automatically by the script.

For every new terminal session, source the environment variables manually:

```bash
cd ~/projects/<repo_name>_<suffix>_repo
source imc_setenv <repo_name>
```

Configure auto-load on login (recommended):

```bash
echo "source ~/projects/<repo_name>_<suffix>_repo/imc_setenv <repo_name>" | sudo tee /etc/profile.d/setenv.sh > /dev/null && sudo chmod 644 /etc/profile.d/setenv.sh
```

Your environment is now ready for use.

> **Important:** Re-run `source imc_setenv <repo_name>` every time you open
> a new terminal tab.

## Building the Container in Visual Studio Code

### Connect to the Remote Host

Use **Remote-SSH** in Visual Studio Code to connect to your Automaton
remote host.

### Open the Project Workspace

Select **File > Open Workspace From File...** and choose the
appropriate workspace file.

### Build the Development Container

> **Note:** If this is your first time ramping up this environment,
> you can skip this step for now.

1. Press `Ctrl+Shift+P` to open the command palette.
2. Type `>` and search for **Dev Containers: Rebuild Without Cache**.
3. Select it and wait for the build to complete.
4. When you see `Done. Press any key to close the terminal.` the
   container is ready.

**If you get a Docker permission error**, run on the Automaton:

```bash
sudo usermod -aG docker "$USER" && sudo chmod 660 /var/run/docker.sock
```

**If Docker is not running**:

```bash
sudo systemctl start docker
sudo usermod -aG docker "$USER"
sudo chmod 660 /var/run/docker.sock
sudo systemctl enable docker
```

**Verify the container was created** — list running containers:

```bash
docker ps
```

List all containers (including stopped):

```bash
docker ps -a
```

Remove a container (if not running):

```bash
docker rm <container_name>
```

Force-stop and remove a running container:

```bash
docker rm -f <container_name>
```

### Docker File (first time only)

`imc_create_dockerfile.sh` is run automatically by `env_creation.sh`.
If you need to re-create it manually:

```bash
cd ~/projects/<repo_name>_<suffix>_repo
source imc_setenv <repo_name>
./imc_create_dockerfile.sh
```

For the full Docker guide, see:
<https://wiki.ith.intel.com/pages/viewpage.action?pageId=3283297208>

## Run Simics

### Step 1 — Verify Simics Works

```bash
cd sources/imc/tools/simics/batch/
./run_svl.sh
```

## Reference

- [IPU Automaton Cheat Sheet](https://wiki.ith.intel.com/spaces/LADFW40G/pages/4197617394/IPU+Automaton+Cheat+Sheet)
- [NSC env — getting started](https://wiki.ith.intel.com/spaces/LADFW40G/pages/3769121182/NSC+env+-+getting+started)
