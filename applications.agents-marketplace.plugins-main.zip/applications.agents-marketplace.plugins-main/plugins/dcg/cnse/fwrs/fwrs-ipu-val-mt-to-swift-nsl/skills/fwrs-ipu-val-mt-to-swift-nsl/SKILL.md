---
name: fwrs-ipu-val-mt-to-swift-nsl
description: 'Convert C# MT (MevRxPathNslApi) tests to Swift silicon platform Python tests. USE FOR: porting MT tests from sources/imc/test/mt-eth-mev or mt-eth-mmg to sources/imc/swift/swift/fwdk_src/tests/nsc_fw_val/MMG400/tests/DP/. Handles SFR API generation, register validation, and test structure conversion.'
argument-hint: 'Path to the C# MT test file to convert'
---

# Convert MT Test to Swift Silicon Platform Test

## When to Use

- Converting a C# test from `sources/imc/test/mt-eth-mmg/` to Swift
- Porting NSL API tests to run on the Swift silicon (Simics) platform
- The C# test calls NSL APIs (e.g., `nslMethods.nsl_hash_*`, `nslMethods.nsl_sem_*`)

**IMPORTANT:** Always use the **MMG** version of the test (`mt-eth-mmg/`) as the reference source, NOT the MEV version (`mt-eth-mev/`). MMG has different VSI max values (2047 vs 1023) and potentially different test parameters.

## Key Paths

| Item | Path |
|------|------|
| C# MT tests (MMG) — **PRIMARY** | `sources/imc/test/mt-eth-mmg/Packages/` |
| C# MT tests (MEV) — reference only | `sources/imc/test/mt-eth-mev/Packages/` |
| Swift test output dir | `sources/imc/swift/swift/fwdk_src/tests/nsc_fw_val/MMG400/tests/DP/` |
| SFR API XML | `sources/imc/swift/swift/fwdk_src/fwdk/blocks/NSL/sfr/autoGen/apiToGenerate.xml` |
| SFR generator script | `sources/imc/swift/swift/fwdk_src/fwdk/blocks/NSL/sfr/autoGen/sfr_command_handler_generator.py` |
| SFR opcodes | `sources/imc/swift/swift/fwdk_src/fwdk/blocks/NSL/sfr/autoGen/sfr_opcodes.py` |
| SFR method classes | `sources/imc/swift/swift/fwdk_src/fwdk/blocks/NSL/sfr/autoGen/sfr_methods/` |
| NSL C header files | `sources/lan/cp/src/CPF/src/NSL/nsl/include/` |
| Register definitions | `sources/imc/swift/swift/fwdk_src/fwdk/blocks/NSL/Registers/register_cmn_fxp_ag.py` |
| Existing triggers | `sources/imc/swift/swift/fwdk_src/fwdk/blocks/NSL/Triggers/` |
| NslFlows base class | `swift.tests.imc_fw.nsl.Flows.nsl_flows` (import path) |
| conftest fixtures | `sources/imc/swift/swift/conftest.py` |

## Conversion Procedure

### Step 1: Identify Required NSL APIs

Read the C# test and list all NSL API calls (e.g., `this.nslMethods.nsl_hash_set_vsi_lut(...)`).

Check which APIs already have SFR opcodes by examining:
```
sources/imc/swift/swift/fwdk_src/fwdk/blocks/NSL/sfr/autoGen/sfr_opcodes.py
```

### Step 2: Add Missing APIs to XML

**CRITICAL: Always add new `<Method>`, `<Structure>`, and `<Enum>` entries at the END of their respective lists in the XML.** Method position determines the SFR opcode number. Inserting in the middle shifts all subsequent opcodes, breaking compatibility with previously deployed firmware.

For each missing API:

1. Find the function signature in the C header file at:
   ```
   sources/lan/cp/src/CPF/src/NSL/nsl/include/nsl_fxp_hash.h  (for hash APIs)
   sources/lan/cp/src/CPF/src/NSL/nsl/include/nsl_fxp_sem.h   (for SEM APIs)
   ```

2. Add a `<Method>` entry to `apiToGenerate.xml` following these rules:

   **Simple parameters** (value types):
   ```xml
   <Parameter Name="vsi" Type="u16" />
   ```

   **Struct pointer parameters** (input/output structs):
   ```xml
   <Parameter Name="cfg" Type="struct nsl_hash_cfg">
       <IsPointer>true</IsPointer>
   </Parameter>
   ```

   **Dynamic array parameters** (variable-length buffers):
   ```xml
   <Parameter Name="lut" Type="u32">
       <IsPointer>true</IsPointer>
       <IsArray>true</IsArray>
       <ArraySize>Dynamic</ArraySize>
   </Parameter>
   ```

   **Return type** (always after Parameters):
   ```xml
   <ReturnType Name="nsl_status" />
   ```

3. If the API uses a struct not yet in `<Structs>`, add it too.

### Step 3: Generate SFR Files

Run the generator:
```bash
cd sources/imc/swift/swift/fwdk_src/fwdk/blocks/NSL/sfr/autoGen
python3 sfr_command_handler_generator.py
```

This generates:
- `sfr_opcodes.py` — new opcode enum entries
- `sfr_methods/sfr_<api_name>.py` — Python SFR class for each API
- `sfr_structs.py` — struct definitions
- `sfr_enums.py` — enum definitions

It also updates userspace SFR generated artifacts under:
- `sources/imc/userspace/mev_imc_sfr/src/sfr_command_handler_ag.c`
- `sources/imc/userspace/mev_imc_sfr/src/sfr_structs_desirialize_serialize_ag.[ch]`

**Do not ignore userspace compile issues introduced by regeneration.**

### Step 3.1: Userspace Header Dependency Gate (Must Pass)

When adding methods/structs, ensure generated userspace files include the owning NSL header for each struct type used in serialization prototypes.

Critical case (already seen):
- If `struct nsl_omh_priv_key` is used, `sfr_structs_desirialize_serialize_ag.h` must include:
    - `#include "nsl_fxp_omh.h"`

Reason:
- Missing owner header can trigger misleading `-Werror=incompatible-pointer-types` errors even when type names look identical.

Validation:
```bash
cd sources/imc/swift/swift/fwdk_src/fwdk/blocks/NSL/sfr/autoGen
python3 sfr_command_handler_generator.py

# then in userspace build env
cd sources/imc/userspace
make -j72 DEBUG=1 MACHINE=hw PROJECT=mmg MEV_TS=0 MEV_1=0 MMG=1
```

Only missing-path noise about unavailable userspace tree locations may be ignored. Real userspace compile errors (type/include mismatches, warnings-as-errors) must be fixed.

### Step 4: Use Enums Instead of Hardcoded Values

The C# test uses enums like `nsl_hash_func.NSL_HASH_FUNC_TOEPLITZ` and `nsl_hash_output_type.NSL_HASH_OUTPUT_TYPE_Q`. The Python test **must** use the auto-generated enum classes — never hardcode integer values.

**Check existing enums** in:
```
sources/imc/swift/swift/fwdk_src/fwdk/blocks/NSL/sfr/autoGen/sfr_enums.py
```

**If the enum exists**, import and use it:
```python
from fwdk.blocks.NSL.sfr.autoGen.sfr_enums import EnumNslHashFunc, EnumNslHashOutputType

h_func_array = [
    EnumNslHashFunc.NSL_HASH_FUNC_TOEPLITZ.value,
    EnumNslHashFunc.NSL_HASH_FUNC_XOR.value,
]
output_type_array = [
    EnumNslHashOutputType.NSL_HASH_OUTPUT_TYPE_Q.value,
]
```

**If the enum does NOT exist**, add it to `apiToGenerate.xml`:
```xml
<Enum Name="enum nsl_hash_func">
    <EnumMember Key="NSL_HASH_FUNC_TOEPLITZ" Value="0" />
    <EnumMember Key="NSL_HASH_FUNC_XOR" Value="1" />
    <EnumMember Key="NSL_HASH_FUNC_COUNT" Value="2" />
</Enum>
```

Then regenerate (Step 3). The generator creates the corresponding `EnumNslHashFunc` class in `sfr_enums.py`.

**Enum naming convention**: C# `nsl_hash_func` → Python `EnumNslHashFunc`. The generator converts `enum nsl_<name>` to `EnumNsl<Name>` in PascalCase.

**Never hardcode enum values** like `h_func = 0` or `output_type = 0`. Always use `EnumClass.MEMBER.value`.

### Step 5: Write the Swift Test

Use this template structure:

```python
"""
Test for <description>.

Converted from MT test: <namespace>/<class>.cs

Test Description:
    <numbered steps>

Test Name: [<ID>][DataPath][<name>]
"""

import pytest
from fwdk.blocks.NSL.sfr.autoGen.sfr_methods.sfr_<api> import <SfrClass>
from fwdk.blocks.NSL.sfr.autoGen.sfr_enums import <EnumClasses>
from fwdk.blocks.NSL.Registers.register_cmn_fxp_ag import <REGISTERS>
from swift.tests.imc_fw.nsl.Flows.nsl_flows import NslFlows
from fwdk.blocks.NSL.sfr.sfr_base import GREEN, RED, RESET


def test_<name>_mmg(
    logger: pytest.fixture,
) -> None:
    """<docstring>"""

    # Prepare the NSL flows (initialize FwDK, start ipumgmtd, etc.)
    # IMPORTANT: Always pass cli_mbx_open_kwargs={"connection_mode": "ssh"} for
    # silicon tests. Omitting it defaults to UART which won't work on silicon.
    nsl_flows = NslFlows(
        logger,
        device_type="MMG_A0",
        platform_type="silicon",
        cli_mbx_open_kwargs={"connection_mode": "ssh"},
    )
    fwdk = nsl_flows._flowsPrepare()

    try:
        # Test logic here...
        pass
    finally:
        nsl_flows._flowsTearDown(fwdk)
```

**CRITICAL: Always include `cli_mbx_open_kwargs={"connection_mode": "ssh"}` for `platform_type="silicon"` tests.** Omitting it defaults to UART communication, which will not work on silicon targets. All tests in `tests/nsc_fw_val/MMG400/tests/DP/` use SSH.

**`NslFlows` constructor parameters:**
- `logger` — pytest logger fixture
- `device_type` — `"MMG_A0"` for MMG tests (default)
- `platform_type` — `"silicon"` for running on real silicon or from a separate terminal; `"simics"` (default) for Simics simulation
- `num_of_hosts` — number of hosts (default 4)
- `cli_mbx_open_kwargs` — optional dict passed to the CLI mailbox open. Use `{"connection_mode": "ssh"}` for silicon tests that communicate via SSH

**For silicon tests using SSH:**
```python
# SSH uses class defaults: host=100.0.0.100, port=22, user=root, key=~/.ssh/imc_ed25519
nsl_flows = NslFlows(
    logger,
    device_type="MMG_A0",
    platform_type="silicon",
    cli_mbx_open_kwargs={"connection_mode": "ssh"},
)
```

**For Simics tests (no SSH needed):**
```python
nsl_flows = NslFlows(logger, device_type="MMG_A0", platform_type="simics")
```

**Do NOT use** the `hifmc_setup_simics_imc` fixture or `HifmcUtils` import. The test should be self-contained using only `NslFlows` with explicit `platform_type`.

### Step 6: Use SFR APIs Correctly

**Standard (fixed-size) SFR call:**
```python
sfr_args = SfrNslHashSetVsiCfg()
sfr_args.request.vsi = vsi
sfr_args.request.cfg.lut_base = lut_base
# ... set other fields ...
fwdk.nsl_block.sfr_manager.send_msg(sfr_args, expected_sfr_fw_ret_val=0)
```

**Dynamic array SFR call** (uses factory pattern):
```python
from fwdk.blocks.NSL.sfr.autoGen.sfr_methods.sfr_nsl_hash_set_vsi_lut import (
    SfrNslHashSetVsiLut,
    struct_nsl_hash_set_vsi_lut_req_factory,
    struct_nsl_hash_set_vsi_lut_resp_factory
)

sfr_args = SfrNslHashSetVsiLut()
sfr_args.request = struct_nsl_hash_set_vsi_lut_req_factory(num_entries)()
sfr_args.response = struct_nsl_hash_set_vsi_lut_resp_factory(num_entries)()

sfr_args.request.vsi = vsi
sfr_args.request.lut_entries = num_entries
for i in range(num_entries):
    sfr_args.request.lut[i] = values[i]

fwdk.nsl_block.sfr_manager.send_msg(sfr_args, expected_sfr_fw_ret_val=0)

# Read response array:
actual = [sfr_args.response.lut[i] for i in range(num_entries)]
```

### Step 6.1: Guard Dynamic SFR Payload Size (Header Uses `u16`)

SFR transport encodes total message size in a 16-bit field. Very large dynamic arrays can fail before reaching firmware with:

`struct.error: ushort format requires 0 <= number <= 65535`

This is a transport/encoding limit, not a firmware return-code failure.

Rules:
- For dynamic array APIs (e.g., `*_set_*_lut`, `*_get_*_lut`), choose `num_entries` so encoded message size stays within `u16` total-size limit.
- If the C# test uses a very large buffer that exceeds SFR transport limits, keep the same negative test intent with a transport-safe size and document it as a deviation in the Python test.
- Prefer preserving semantic intent (e.g., "Q Group has no cVSI context") over preserving oversized payload length that cannot be encoded.

Example deviation comment:
```python
# DEVIATION from MT C# for transport compatibility:
# Original uses lut_entries=32768 for this negative step.
# Swift SFR dynamic payload exceeds u16 header total_size before FW call.
# Using transport-safe lut_entries here to validate the same negative behavior.
```

### Step 7: Register Validation

For direct register validation (matching C# `ValidateHashLutRegisters` pattern):

```python
from fwdk.blocks.NSL.Registers.register_cmn_fxp_ag import FXP_HASH_LUT0, FXP_HASH_LUT1

register = fwdk.platform.registersFactory.get_register(FXP_HASH_LUT0, i=index)
fwdk.platform.registers.read_register(register)
assert register.value == expected_value
```

Hard rules (do not violate):
- `RegisterFactory.get_register` takes the register class/type as the first positional argument.
    - Correct: `get_register(FXP_HASH_VSI_CFG, i=vsi)`
    - Wrong: `get_register(register_type=FXP_HASH_VSI_CFG, i=vsi)`
- Use register service read/write APIs, not platform shortcuts:
    - Read: `fwdk.platform.registers.read_register(register)`
    - Write: `fwdk.platform.registers.write_register(register)`
    - Do not use `fwdk.platform.read_register(register)`.

### Step 7.1: Register Write Semantics (Important)

When clearing or writing an entire register object, use:

```python
register.full_value = 0
```

Do not assume `register.value` exists. In this framework, `value` is usually a field name for specific register types, not a universal register property.

If you need field-level parity with MT C#, set/check named fields explicitly (example for `FXP_HASH_QGRP_CNTX`):
- `parent_vsi`
- `lut_base_high`
- `lut_base`
- `lut_size`

This preserves C# behavior where helper methods validate both API output and backing register fields.

Register types are Union types defined in `register_cmn_fxp_ag.py` that resolve to the correct device-specific register (MEV/MMG/CNIC).

### Step 7.2: HASH_VSI_QTABLE Indexing Rule (SG Qtable)

When validating `nsl_hash_set/get_vsi_sg_qtable` against registers, use this exact mapping:

- `FXP_HASH_VSI_QTABLE` index/field is based on **relative queue id** (`rel_qid`), not absolute queue id (`abs_qid`):
    - `vsi_qtable_idx = rel_qid // 4`
    - `vsi_qtable_field_idx = rel_qid % 4`
- `get_register` argument order for this register is:
    - `get_register(FXP_HASH_VSI_QTABLE, i=vsi, j=vsi_qtable_idx)`
- Expected value in `abs_q_4npX` is the **absolute** queue id:
    - `abs_q_4npX == abs_qid`

For `FXP_HASH_ABSTOREL_QTABLE`, use absolute queue indexing:
- `abstorel_idx = abs_qid // 16`
- `abstorel_field = rel_q_16np{abs_qid % 16}`
- Expected value is the relative queue id (`rel_qid`).

Do not derive `FXP_HASH_VSI_QTABLE` index/field from `abs_qid`; that causes false mismatches.

## C# to Python API Mapping

| C# Pattern | Swift Pattern |
|---|---|
| `this.nslMethods.nsl_<api>(args)` | `fwdk.nsl_block.sfr_manager.send_msg(sfr_args, expected_sfr_fw_ret_val=0)` |
| `this.Registers.Read<RegType>(idx)` | `fwdk.platform.registersFactory.get_register(REG_TYPE, i=idx)` + `fwdk.platform.registers.read_register(reg)` |
| `this.Registers.Write<RegType>(idx, val)` | `register.full_value = val` + `fwdk.platform.registers.write_register(register)` |
| `this.Assert.AreEqual(expected, actual, msg)` | `assert actual == expected, f"{RED}msg{RESET}"` |
| `this.logger.BeginStep("...")` | `logger.info("...")` |
| `nsl_status.NSL_SUCCESS` | `expected_sfr_fw_ret_val=0` in `send_msg` |
| `nsl_hash_func.NSL_HASH_FUNC_TOEPLITZ` | `EnumNslHashFunc.NSL_HASH_FUNC_TOEPLITZ.value` |
| `nsl_hash_output_type.NSL_HASH_OUTPUT_TYPE_Q` | `EnumNslHashOutputType.NSL_HASH_OUTPUT_TYPE_Q.value` |
| C# enum `nsl_<name>.<MEMBER>` (general) | `EnumNsl<Name>.<MEMBER>.value` from `sfr_enums.py` |
| `ConfigureVsiFlow` base class | `NslFlows(logger, device_type="MMG_A0", platform_type="silicon")` |
| Test class constructor | `test_<name>_mmg()` function |
| `Prepare()` method | Code before the loop / `_flowsPrepare()` |
| `Run()` method | Main test body |
| `Clean()` method | `finally:` block / `_flowsTearDown()` |

## NslFlows: Platform Type

`NslFlows` accepts a `platform_type` parameter:
- `"simics"` (default) — for tests running in Simics simulation. No `cli_mbx_open_kwargs` needed.
- `"silicon"` — for tests running on real silicon or when running independently from another terminal. Must include `cli_mbx_open_kwargs={"connection_mode": "ssh"}` to communicate over SSH.

The SSH connection uses class defaults: `host=100.0.0.100`, `port=22`, `user=root`, `key=~/.ssh/imc_ed25519`.

This allows the same test to target different platforms without relying on global fixtures or conftest overrides. Other tests that don't pass `platform_type` continue to use `"simics"` by default.

### Step 8: Validate Conversion Accuracy

After writing the Python test, **compare it against the original MMG C# test** (`sources/imc/test/mt-eth-mmg/`) to verify correctness. The converted test must be a faithful 1:1 port of the **MMG version**, not the MEV version.

**Always use `mt-eth-mmg` as the reference.** The MEV version may have different VSI ranges, array sizes, or test parameters that don't apply to MMG.

### Step 8.1: Mandatory Parity Gate (No Exceptions)

Treat conversion as **failed** unless all gates below pass.

Required gates:
1. **Flow gate**: Every C# `Run()` step exists in Python in the same order.
2. **Data gate**: Every constant/array/scalar value is identical (same element values, lengths, and ordering).
3. **API gate**: Every NSL API call is present exactly once per occurrence in the same sequence.
4. **Assertion gate**: Every C# assertion has a Python assertion that validates the same condition.
5. **Register gate**: If C# validates register content, Python validates the same register fields/indices at the same logical point.
6. **Negative-case gate**: Every expected-error call uses `check_sfr_fw_ret_val=False` and validates `sfr_fw_ret_val != 0` explicitly.

If one gate fails, fix code first. Do not mark conversion complete.

### Step 8.2: Flow-Lock Validation Procedure

Perform this procedure for every converted test:

1. Build a **Step Map** from C# `Run()`:
    - Step index
    - Step text (`BeginStep`/intent)
    - APIs called in step order
    - Validations/assertions in that step

2. Build the same Step Map for Python.

3. Compare maps line-by-line:
    - Same number of steps
    - Same step ordering
    - Same API order inside each step
    - Same validation point (immediately after same operation)

4. Build a **Data Parity Table**:
    - For each array/constant/scalar in C#: record exact value
    - Confirm exact equality in Python (not "equivalent", exact)
    - Include loop bounds and iteration order

5. Build an **API Signature Table**:
    - API name
    - Param names
    - Param values/sources (including generated pointer request fields)
    - Expected FW return behavior (success/failure)
        - For register access helpers, confirm exact call signatures used by folder convention:
            - `registersFactory.get_register(REG_TYPE, i=..., j=...)`
            - `platform.registers.read_register(reg)` / `platform.registers.write_register(reg)`

6. Validate assertions:
    - Ensure each C# `Assert.AreEqual(...)` has Python `assert` on same operands/semantics
    - Ensure failure message includes enough context (index, vsi, qgrp, etc.)

7. Validate register parity when applicable:
    - Same register type(s)
    - Same indexing rules
    - Same field names and expected values

8. Record deviations only if unavoidable:
    - Add `# DEVIATION from MT C#:` comment in code
    - Include exact reason and why semantic intent is preserved
    - Keep deviation as small as possible

9. Produce a short parity report in your response:
    - `Steps`: matched/mismatched
    - `Values`: matched/mismatched
    - `APIs`: matched/mismatched
    - `Assertions`: matched/mismatched
    - `Registers`: matched/mismatched
    - `Deviations`: none or listed

**Verify all of the following match the original:**

1. **Test data values** — All arrays, constants, and parameters must have identical values:
   - VSI indices, LUT values, base addresses, entry counts
   - Enum values (hash functions, output types, modes)
   - Loop bounds and iteration counts

2. **Step order** — Operations must execute in the same sequence as the C# `Run()` method:
   - Map each `this.logger.BeginStep("...")` / `this.logger.EndStep()` block to a corresponding step
   - API calls within each step must be in the same order
   - Validations must happen at the same point in the flow

3. **API calls** — Every NSL API call in the original must have a corresponding SFR call:
   - No APIs should be skipped or added
   - Parameters passed to each API must match
    - For APIs generated from pointer params, initialize all required request-side fields present in generated SFR input structs (even when logically "output" in C#), unless generator docs explicitly state otherwise.

4. **Assertions** — Every `this.Assert.AreEqual(...)` must have a corresponding `assert` statement

5. **Register operations** — Register reads/writes must target the same registers with the same indices

**If any deviation is necessary**, document it explicitly in the test file with a comment explaining why:

```python
# DEVIATION from original C# test:
# Original uses 3 LUT register types (HashLut00Reg, HashLut10Reg, HashLut20Reg)
# with boundary at 32768 and 32768+512.
# Python uses 2 register types (FXP_HASH_LUT0, FXP_HASH_LUT1) with boundary at 32768.
# Reason: MMG register model consolidates LUT10 and LUT20 into a single FXP_HASH_LUT1.
```

**Common mistakes to avoid:**
- Using different/smaller test values "for simplicity" — use the exact original values
- Reordering steps (e.g., moving register validation earlier or later)
- Adding extra operations not in the original (e.g., pre-clearing registers)
- Omitting steps that seem redundant (they may test specific firmware behavior)

## Important Notes

1. **Always use SFR APIs** — don't simulate APIs with direct register writes if an SFR opcode exists or can be added.
2. **Dynamic arrays** require factory pattern — the array size is baked into the class at creation time.
3. **`nsl_hash_set_vsi_cfg` clears LUT** — `nsl_hash_assign_vsi_cfg` does not. Test both behaviors.
4. **Register index boundaries**: `FXP_HASH_LUT0` for indices 0-32767, `FXP_HASH_LUT1` for 32768+.
5. **VSI max values**: MEV=1023, MMG=2047.
6. **Color formatting**: Use `GREEN`/`RED`/`RESET` from `sfr_base` for log messages.
7. **Test file naming**: `test_<descriptive_name>.py` in `tests/nsc_fw_val/MMG400/tests/DP/` directory.
8. **Use enums, not integers** — Always import from `sfr_enums.py` for any C# enum type. Generate if missing.
9. **Faithful conversion** — The Python test must be a 1:1 port of the C# test. Same values, same steps, same order. Document any deviations with reasons.
10. **Always use SSH for silicon tests** — Every `platform_type="silicon"` test MUST include `cli_mbx_open_kwargs={"connection_mode": "ssh"}`. Omitting this defaults to UART, which silently breaks communication on silicon targets.
11. **Negative-case `send_msg` calls** — When the test expects firmware to return an error (negative/boundary cases), do **NOT** use `expected_sfr_fw_ret_val=None`. That still triggers the internal FW return assertion inside `send_msg`, causing the test to fail before your own assertion runs. Instead, use `check_sfr_fw_ret_val=False` to disable the built-in check, then assert the error yourself:
    ```python
    # WRONG — internal assertion fires before your check:
    fwdk.nsl_block.sfr_manager.send_msg(sfr_set, expected_sfr_fw_ret_val=None)
    assert sfr_set.response.ret_val != 0  # also wrong field name

    # CORRECT — disable internal check, then verify FW returned error:
    fwdk.nsl_block.sfr_manager.send_msg(sfr_set, check_sfr_fw_ret_val=False)
    assert sfr_set.response.sfr_fw_ret_val != 0, "Negative case should have failed"
    ```
    Note: the correct response field is `sfr_fw_ret_val`, not `ret_val`.
12. **Dynamic-array transport limit** — SFR header total-size is `u16`; oversized dynamic payloads fail in transport encode before FW (`struct.error ... <= 65535`). Keep negative semantic intent with transport-safe array size and document deviation.
13. **Whole-register clear/write** — Use `register.full_value = ...` for whole-register writes. Do not use `register.value` unless that exact field exists on that register type.
14. **Field parity with MT** — If C# helper validates register fields (not only API return/output), replicate those assertions in Python for true 1:1 conversion.
15. **Pointer-param request fields** — Generated SFR request structs may include fields corresponding to C# `ref` params; initialize them when present (example pattern: `sfr.request.qgrp = qgrp_id` for `nsl_sem_get_default_cvsi_qgrp`).
16. **Userspace include ownership** — For any generated userspace serializer prototype using a struct pointer, ensure the serializer header includes the struct owner header (example: `struct nsl_omh_priv_key` requires `nsl_fxp_omh.h`).
