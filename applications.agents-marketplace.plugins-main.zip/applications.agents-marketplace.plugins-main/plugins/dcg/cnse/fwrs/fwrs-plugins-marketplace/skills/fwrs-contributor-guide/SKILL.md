---
name: fwrs-contributor-guide
description: FWRS-specific conventions and guidance for contributing a plugin to the applications.agents-marketplace.plugins repository. Use when the user wants to create a new plugin, contribute to the marketplace, or needs FWRS plugin naming, location, or tagging conventions.
---

# FWRS Plugins Marketplace — Contributor Guide

## When to Use

- User wants to create or contribute a new FWRS plugin
- User asks about plugin naming, location, or tagging conventions
- User needs guidance on marketplace vs. target repository placement
- User is preparing a PR for the marketplace repository

FWRS maintains its plugins in the [applications.agents-marketplace.plugins](https://github.com/intel-innersource/applications.agents-marketplace.plugins.git) repository.

## Marketplace vs. Target Repository (Mandatory)

Before proceeding with any plugin contribution, you MUST ask the user:

> Should this plugin and its related tools (agents, skills, instructions, etc.) be maintained in the marketplace, or directly in the repository the tools target?

Use the following criteria to guide the decision:

- **Add to the marketplace** if the plugin:
  - Can be used (today or in the future) by multiple repositories, OR
  - Serves different domain roles, OR
  - Is not specific to any single repository

- **Add to the target repository** (highly recommended) if the plugin:
  - Is tightly coupled to a specific repository and unlikely to be reused elsewhere

Do not skip this step. The user must explicitly confirm the placement before continuing.

## Plugin Location

Place your plugin under `plugins/dcg/cnse/` in the marketplace repository following this convention:

- **FWRS-specific plugins** → `plugins/dcg/cnse/fwrs/<your-plugin-name>/`
- **Generic (non-FWRS) plugins** → `plugins/dcg/cnse/<your-plugin-name>/`

## Plugin Naming Convention

Plugins located under the `fwrs/` directory follow this naming pattern, using optional predefined segments as needed to scope the plugin to the correct domain:

```
fwrs-<ipu | fnic>-<team>-<plugin-name>
```

- `fwrs-` — required prefix for all FWRS plugins
- `<ipu | fnic>` — optional product family scope; skip if the plugin is global across products
- `<team>` — optional team scope; skip if the plugin is global across teams
- `<plugin-name>` — descriptive name of the plugin (do not suffix with `-plugin`)

Examples:
- `fwrs-<plugin-name>` — general FWRS plugin
- `fwrs-fnic-<plugin-name>` — FNIC-specific plugin
- `fwrs-ipu-hifmc-<plugin-name>` — IPU plugin scoped to a specific team

## Keywords Convention

The plugin's keywords must include at least `fwrs` and should include the plugin directory name segments to aid discoverability.

For example, a plugin at `plugins/dcg/cnse/fwrs/fwrs-ipu-hifmc-my-plugin/` should have keywords: `["fwrs", "ipu", "hifmc"]`

## Tag Convention

Do not tag a plugin with `intel_global` unless there is strong justification to expose it to all of Intel. Plugins under `fwrs/` are scoped to FWRS by default and should not require global visibility.

## Commit Message Convention

For plugins located under the `fwrs/` directory, prefix the commit message title with `fwrs:`.

The commit body should describe the application effect of the change — rather than implementation details.

Example:
```
fwrs: Add IPU power-flow automation plugin

Automates end-to-end power pipeline for IPU designs, covering
workspace init, collateral population, and post-processing.
```

## Register Plugin in Recommender

After contributing a new plugin, add it to the appropriate user profile(s) in `skills/fwrs-plugin-recommender/SKILL.md` under the **User Profiles** section. Refer to that skill for the profile layout and matching rules.
