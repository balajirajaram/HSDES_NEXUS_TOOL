---
name: fwrs-plugin-recommender
description: Recommends and installs FWRS plugins from the marketplace based on the user's profile (product, team, domain, and role). Use when the user asks to set up plugins, install FWRS tools, configure their environment, or asks what plugins they need.
---

# FWRS Plugin Recommender

## When to Use

- User wants to set up their FWRS development environment
- User asks what plugins they need for their product, team, domain, or role
- User wants to install FWRS plugins from the marketplace
- User is onboarding to a new FWRS team or domain

## Prerequisites

Before recommending or installing any plugins, verify the following:

### Copilot CLI

Run in the terminal:
```
copilot --version
```

- If the command succeeds, proceed to marketplace registration.
- If the command fails (not found), instruct the user to install the Copilot CLI:

> The Copilot CLI is required to install plugins from the marketplace.
> Install it by following the instructions at: https://github.com/intel-innersource/applications.development.ai.github-copilot-cli

Do not proceed until the CLI is confirmed available.

### Marketplace Registration

Verify that the `plugins-marketplace` marketplace is registered and up to date.
Refer to the **Copilot CLI Commands Manual** section below for the exact commands to register, list, and update the marketplace.

Do not proceed with plugin installation until the marketplace is registered and updated.

## Copilot CLI Commands Manual

Register the marketplace:
```
copilot plugin marketplace add intel-innersource/applications.agents-marketplace.plugins
```

Check registered marketplaces:
```
copilot plugin marketplace list
```

Update the catalog to ensure the latest plugin list is available:
```
copilot plugin marketplace update plugins-marketplace
```

Install a plugin:
```
copilot plugin install <plugin-name>@plugins-marketplace
```

Uninstall a plugin:
```
copilot plugin uninstall <plugin-name>
```

List installed plugins:
```
copilot plugin list
```

Browse available plugins (optionally filtered by keyword regex):
```
copilot plugin marketplace browse plugins-marketplace | grep -iE '<regex>'
```

## User Interaction

Ask the user for each of the following profile parameters in a single message, then match their answers against the profiles in the **User Profiles** section to determine which profile(s) apply.

### Profile Parameters

| Parameter | Question                            | Options                                                        |
|-----------|-------------------------------------|----------------------------------------------------------------|
| product   | Which product are you working on?   | ipu, fnic, general                                             |
| team      | Which team are you on?              | fw development, validation, devops, program management, general |
| domain    | Which domain are you working in?    | hifmc, dpcp, management, general                               |
| role      | What is your role?                  | developer, manager, general                                    |

Each parameter includes a `general` option for users who work across multiple areas or do not identify with a specific category.

### Matching Rules

- A profile matches when the user's answer equals one of the profile's **Match** values for every parameter.
- A match value of `any` matches every user answer (including `general`).

### Installation Flow

1. Collect all profile parameters from the user.
2. Resolve all matching profiles. Recursively include any profiles listed in **Include Profiles** and deduplicate the combined plugin list.
3. Check which plugins are already installed (using `copilot plugin list`) and exclude them.
4. Present the matching profile(s) and the final plugin list to the user.
5. Install plugins one by one, asking for user confirmation before each installation.

## User Profiles

Each subsection below follows this layout:

```
### <profile-name>

**Description:** <what this profile is for>

**Match:**

| Parameter | Value                              |
|-----------|-------------------------------------|
| product   | <value(s), comma-separated, or "any"> |
| team      | <value(s), comma-separated, or "any"> |
| domain    | <value(s), comma-separated, or "any"> |
| role      | <value(s), comma-separated, or "any"> |

**Include Profiles:**
- `<profile-name>`

**Plugins:**
- `<plugin-name>`
```

When a profile includes other profiles, recursively resolve their plugins as well.

### fwrs-general

**Description:** Any user working within the FWRS organization, regardless of team or role.

**Match:**

| Parameter | Value |
|-----------|-------|
| product   | any   |
| team      | any   |
| domain    | any   |
| role      | any   |

**Include Profiles:**
- (none)

**Plugins:**
- `fwrs-plugins-marketplace`

<!-- Add new profiles below following the layout above -->

### fwrs-ipu-val

**Description:** Developer who develops validation tests for the FW IPU.

**Match:**

| Parameter | Value      |
|-----------|------------|
| product   | ipu        |
| team      | validation |
| domain    | any        |
| role      | developer  |

**Include Profiles:**
- `fwrs-general`

**Plugins:**
- `fwrs-ipu-val-create-fw-val-env`
- `fwrs-ipu-val-mt-to-swift-nsl`

### fwrs-ipu-link-developer

**Description:** Developer working on IPU Link Manager flows on silicon platform.

**Match:**

| Parameter | Value           |
|-----------|-----------------|
| product   | ipu             |
| team      | fw development  |
| domain    | link management |
| role      | developer       |

**Include Profiles:**
- `fwrs-general`

**Plugins:**
- `fwrs-ipu-link-platform-manager`
