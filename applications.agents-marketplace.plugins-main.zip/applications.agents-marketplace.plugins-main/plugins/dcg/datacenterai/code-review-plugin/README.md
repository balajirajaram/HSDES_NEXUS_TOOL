# Code Review Plugin

A Copilot skill plugin that performs strict, reviewer-quality code reviews on git-changed files within a workspace.

## Overview

This plugin identifies modified files in a git repository, retrieves diffs, and performs a thorough code review against senior-engineering standards. It presents structured findings with severity levels and actionable suggestions — without applying any changes unless explicitly requested.

## When to Use

- Get a code review of changed files
- Find bugs, issues, or improvements in code changes
- Obtain a strict, formal engineering assessment of code quality

## Procedure

### 1. Identify Changed Files

The plugin runs `git status --porcelain` to find modified/added files.

| Prefix | Meaning | Action |
|--------|---------|--------|
| `M` / ` M` | Modified | Review |
| `A` / `AM` | Added | Review |
| `D` | Deleted | Skip |
| `??` | Untracked | Skip (unless explicitly requested) |

To diff against a specific branch:

```powershell
git diff --name-only <branch>
```

### 2. Get the Diff for Each File

For each changed file, the actual diff is retrieved:

```powershell
git diff <file>
git diff --cached <file>   # for staged files
```

The full file content is also read for broader context around the changes.

### 3. Perform Strict Code Review

Each file's changes are reviewed against the following checklist:

#### Correctness & Bugs
- Logic errors, off-by-one errors, incorrect conditionals
- Race conditions or concurrency issues
- Null/None dereferences, unhandled exceptions
- Resource leaks (file handles, connections, locks)
- Incorrect API usage or wrong function signatures
- Missing return statements or unreachable code

#### Security (OWASP-aware)
- Injection vulnerabilities (SQL, command, path traversal)
- Hardcoded secrets, credentials, or tokens
- Insecure deserialization
- Missing input validation at system boundaries
- Improper error handling that leaks sensitive info

#### Code Quality & Maintainability
- Violations of DRY, SOLID, or KISS principles
- Overly complex functions (high cyclomatic complexity)
- Poor naming (ambiguous variables, misleading function names)
- Dead code or commented-out code left in
- Missing or incorrect type hints (for Python)
- Inconsistent code style with the rest of the codebase

#### Error Handling
- Bare `except` or overly broad exception catching
- Swallowed exceptions (caught but not logged/re-raised)
- Missing error handling for I/O, network, or external calls

#### Testing & Robustness
- Untested edge cases visible in the diff
- Test code that doesn't actually assert anything meaningful
- Fragile tests (timing-dependent, order-dependent)

#### Performance
- Unnecessary loops or repeated expensive operations
- N+1 query patterns
- Large allocations in hot paths

#### Documentation & Clarity
- Public APIs missing docstrings
- Complex logic without explanatory comments
- Misleading or outdated comments

### 4. Present Findings

Each issue is presented in a structured format:

```
📄 File: <relative-path-to-file>
📍 Location: Line <number> (or line range)
🏷️ Category: <Bug | Security | Code Quality | Error Handling | Performance | Testing | Documentation>
⚠️ Severity: <Critical | High | Medium | Low | Nit>

❌ Issue:
<Clear description of what is wrong>

💡 Suggestion:
<What the fix should look like — code snippet if helpful>

📝 Rationale:
<Why this matters — what could go wrong if left unfixed>
```

Findings are grouped by file and sorted by severity (Critical → Nit).

### 5. Summary

After reviewing all files, a summary is provided:

- Total issues found (by severity)
- Files with the most issues
- Overall assessment: **Approve**, **Approve with suggestions**, **Request changes**, or **Block** (for critical/security issues)

### 6. Apply Fixes (Only on User Request)

Changes are **never applied automatically**. When the user explicitly requests a fix:

1. Confirm which suggestion(s) to apply.
2. Make the change to the file.
3. Show the applied diff for verification.

## Review Standards

- Constructive but direct — issues are not sugarcoated.
- Blocking issues are distinguished from nice-to-haves.
- Broader codebase context is considered — suggestions align with project conventions.
- Intentional but risky changes are flagged as discussion points rather than defects.
- Genuinely good patterns or improvements are briefly acknowledged.

## Example Invocations

| Command | Behavior |
|---------|----------|
| "Review my code" | Review all changed files |
| "Review changes against main" | Diff against main branch and review |
| "Review src/kayak/domains/security/" | Review only changes in that directory |
| "Apply fix #3" | Apply only the third suggestion from the review |

## Requirements

- Git
- A repository with trackable changes

## Important Notes

- Operates strictly within the designated workspace folder.
- Never applies fixes or changes automatically — only presents suggestions.
- Waits for explicit user permission before modifying any file.
- Treats reviews as formal with strict engineering standards.
