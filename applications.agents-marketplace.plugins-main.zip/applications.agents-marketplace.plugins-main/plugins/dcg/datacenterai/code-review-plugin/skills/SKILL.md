---
name: code-review
description: 'Strict security-focused review of changed and untracked files in C:\Kayak. Reports every vulnerability from low to severe priority and suggests fixes. Use when: user says "review my code", "code review", "review changes", "check for bugs", "find issues in my code", "review my PR", "what is wrong with my code", "strict review".'
argument-hint: 'Optionally specify files or a branch to diff against'
---

# Strict Code Review on Changed & Untracked Files

## When to Use
- User wants a code review of their changed files
- User asks to find bugs, issues, or improvements in their changes
- User wants a strict, reviewer-quality assessment of their code
- User wants every vulnerability flagged — from low to severe priority

## Important Constraints

- **This skill operates strictly within the `C:\Kayak` workspace folder.** Do NOT review, read, or reference files outside `C:\Kayak`. All git commands MUST be run with the working directory set to `C:\Kayak`.
- **NEVER apply fixes or changes automatically.** Only present suggestions. Wait for explicit user permission before modifying any file.
- **Report ALL vulnerabilities** — from Low/Nit severity all the way to Critical/Severe. Do not skip low-priority items.
- Treat this as a formal code review with strict engineering standards.

## Procedure

### 1. Identify Changed and Untracked Files

Run `git status` from `C:\Kayak` to find modified, added, AND untracked files:

```powershell
Set-Location C:\Kayak
git status --porcelain
```

Extract file paths for ALL of the following:
- Modified (`M`) files
- Added (`A`) files
- Untracked (`??`) files — **always include these in the review**

Skip only deleted (`D`) files.

If the user specifies a branch to diff against, use:
```powershell
git diff --name-only <branch>
```
And still include untracked files from `git status --porcelain`.

If there are no changed or untracked files, inform the user and stop.

### 2. Get the Diff / Content for Each File

For each **tracked changed file**, retrieve the actual diff:

```powershell
git diff <file>
```

For staged files:
```powershell
git diff --cached <file>
```

For **untracked files**, read the full file content since there is no diff available:

```powershell
Get-Content <file>
```

Also read the full file content for tracked files to get broader context around the changes.

### 3. Perform Strict Code Review

Review each file's changes (and full content for untracked files) against the following criteria. Be thorough and strict — review as a senior engineer would on a production codebase. **Flag every issue regardless of severity — from low/nit to critical/severe.**

#### Review Checklist

**Correctness & Bugs:**
- Logic errors, off-by-one errors, incorrect conditionals
- Race conditions or concurrency issues
- Null/None dereferences, unhandled exceptions
- Resource leaks (file handles, connections, locks)
- Incorrect API usage or wrong function signatures
- Missing return statements or unreachable code

**Security (OWASP-aware):**
- Injection vulnerabilities (SQL, command, path traversal)
- Hardcoded secrets, credentials, or tokens
- Insecure deserialization
- Missing input validation at system boundaries
- Improper error handling that leaks sensitive info

**Code Quality & Maintainability:**
- Violations of DRY, SOLID, or KISS principles
- Overly complex functions (high cyclomatic complexity)
- Poor naming (ambiguous variables, misleading function names)
- Dead code or commented-out code left in
- Missing or incorrect type hints (for Python)
- Inconsistent code style with the rest of the codebase

**Error Handling:**
- Bare `except` or overly broad exception catching
- Swallowed exceptions (caught but not logged/re-raised)
- Missing error handling for I/O, network, or external calls

**Testing & Robustness:**
- Untested edge cases visible in the diff
- Test code that doesn't actually assert anything meaningful
- Fragile tests (timing-dependent, order-dependent)

**Performance:**
- Unnecessary loops or repeated expensive operations
- N+1 query patterns
- Large allocations in hot paths

**Documentation & Clarity:**
- Public APIs missing docstrings
- Complex logic without explanatory comments
- Misleading or outdated comments

### 4. Present Findings

For each issue found, present it in this structured format:

```
📄 File: <relative-path-to-file>
📍 Location: Line <number> (or line range)
🏷️ Category: <Bug | Security | Code Quality | Error Handling | Performance | Testing | Documentation>
⚠️ Severity: <Critical | High | Medium | Low | Nit>

❌ Issue:
<Clear description of what is wrong>

💡 Suggested Fix:
<What the fix should look like — show the corrected code snippet>

📝 Rationale:
<Why this matters — what could go wrong if left unfixed>
```

Group findings by file, then sort by severity (Critical → Nit). **Do NOT omit low-severity or nit-level findings — report everything.**

### 5. Summary

After reviewing all files, provide a summary:

- Total issues found (by severity)
- Files with the most issues
- Overall assessment: **Approve**, **Approve with suggestions**, **Request changes**, or **Block** (for critical/security issues)

### 6. Apply Fixes (Only on User Request)

**Do NOT apply any changes unless the user explicitly asks.** When the user says to apply a specific fix:

1. Confirm which suggestion(s) they want applied.
2. Make the change to the file in `C:\Kayak`.
3. Show the applied diff for verification.

If the user says "apply all suggestions" or "fix everything," confirm once before proceeding, then apply changes one by one, showing progress.

If the user says "fix it" or "apply" after reviewing findings, ask which specific issues to fix (by number) or confirm they want all applied.

**All file modifications MUST be within `C:\Kayak`.** Never write to files outside this directory.

## Review Standards

- Be constructive but direct. Don't sugarcoat issues.
- Distinguish between blocking issues and nice-to-haves.
- Consider the broader codebase context — don't suggest patterns that contradict project conventions.
- If a change looks intentional but risky, flag it as a discussion point rather than a defect.
- Praise genuinely good patterns or improvements (briefly).

## Example Invocations

- "Review my code" → Review all changed + untracked files in C:\Kayak
- "Review changes against main" → Diff against main branch and review (includes untracked)
- "Review src/kayak/domains/security/" → Review only changes in that directory
- "Apply fix #3" → Apply only the third suggestion from the review
- "Fix all" → Confirm with user, then apply all suggested fixes
