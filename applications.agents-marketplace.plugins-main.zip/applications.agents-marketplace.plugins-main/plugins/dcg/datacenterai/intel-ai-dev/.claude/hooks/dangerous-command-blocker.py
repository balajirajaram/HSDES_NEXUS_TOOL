#!/usr/bin/env python3
# Copyright (C) 2026 Intel Corporation
# SPDX-License-Identifier: Apache-2.0
"""PreToolUse hook: Blocks dangerous shell commands before execution.

Blocks: destructive filesystem ops, privilege escalation, network exfiltration,
fork bombs, disk-level writes, history manipulation.
"""

import json
import re
import sys
from typing import Optional

BLOCKED_PATTERNS: list[tuple[str, str]] = [
    # Filesystem destruction
    (r'rm\s+(-[a-zA-Z]*f[a-zA-Z]*r[a-zA-Z]*|-[a-zA-Z]*r[a-zA-Z]*f[a-zA-Z]*)\s+/', "rm -rf on root"),
    (r'rm\s+-rf\s+~', "rm -rf on home directory"),
    (r'rm\s+-rf\s+\*\s*$', "rm -rf wildcard at current dir"),
    (r'rm\s+-rf\s+\.\s*$', "rm -rf current directory"),

    # Disk-level operations
    (r'mkfs\.', "filesystem formatting"),
    (r'dd\s+if=.+of=/dev/', "dd write to block device"),
    (r'shred\s+.*/dev/', "shred on block device"),
    (r'wipefs\s', "wipefs disk operation"),

    # Privilege escalation
    (r'\bsudo\s+su\b', "sudo su escalation"),
    (r'\bsu\s+-\s*root\b', "switch to root"),
    (r'chmod\s+-R\s+777\s+/', "chmod 777 on root"),
    (r'chown\s+-R\s+root\s+/', "chown root on root"),

    # Fork bomb variants
    (r':\(\)\s*\{', "fork bomb"),
    (r':()\s*\{', "fork bomb variant"),

    # History manipulation
    (r'history\s+-[cw]', "shell history clear/write"),
    (r'cat\s+/dev/null\s*>\s*~/\.bash_history', "bash history wipe"),

    # Network exfiltration of sensitive paths
    (r'(curl|wget|nc|ncat)\s+.*(\.env|id_rsa|\.ssh/)', "potential credential exfiltration"),

    # Python/shell eval with suspicious piped content
    (r'\|\s*(python|python3|bash|sh)\s+-c\s+["\']?\$\(curl', "remote code execution via curl pipe"),
]

WARN_PATTERNS: list[tuple[str, str]] = [
    (r'\bsudo\b', "sudo usage (requires approval)"),
    (r'curl\s+.*\|\s*(bash|sh)\b', "piping curl to shell"),
    (r'wget\s+.*-O\s*-\s*\|', "piping wget to shell"),
    (r'chmod\s+777\b', "overly permissive chmod 777"),
    (r'>\s*/etc/', "writing to /etc"),
]


def get_tool_input() -> dict:
    try:
        return json.loads(sys.stdin.read())
    except (json.JSONDecodeError, EOFError):
        return {}


def check_command(command: str) -> tuple[Optional[str], list[str]]:
    """Returns (block_reason, [warning_messages])."""
    for pattern, label in BLOCKED_PATTERNS:
        if re.search(pattern, command):
            return label, []

    warnings = []
    for pattern, label in WARN_PATTERNS:
        if re.search(pattern, command):
            warnings.append(label)

    return None, warnings


def main() -> None:
    tool_input = get_tool_input()
    command = tool_input.get("command", "")

    if not command:
        sys.exit(0)

    block_reason, warnings = check_command(command)

    if block_reason:
        print(
            f"BLOCKED: Dangerous command pattern detected ({block_reason}). "
            "This command will not execute. Revise and try again.",
            file=sys.stderr,
        )
        sys.exit(1)

    for w in warnings:
        print(f"WARNING: {w}", file=sys.stderr)

    sys.exit(0)


if __name__ == "__main__":
    main()
