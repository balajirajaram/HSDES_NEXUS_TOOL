#!/usr/bin/env python3
"""PostToolUse hook: Validates Intel Apache-2.0 license headers on written files."""

import json
import os
import sys


def get_tool_input():
    try:
        return json.loads(sys.stdin.read())
    except (json.JSONDecodeError, EOFError):
        return {}


def check_header(file_path):
    if not os.path.isfile(file_path):
        return True, ""

    ext = os.path.splitext(file_path)[1].lower()
    applicable = {".py", ".ts", ".tsx", ".js", ".jsx", ".yaml", ".yml"}
    if ext not in applicable:
        return True, ""

    skip = ["node_modules", ".venv", "venv", "__pycache__", ".tox", ".env"]
    if any(p in file_path for p in skip):
        return True, ""

    try:
        with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
            content = f.read(500)
    except OSError:
        return True, ""

    if not content.strip():
        return True, ""

    if "Copyright" in content and "Intel" in content:
        return True, ""

    if "SPDX-License-Identifier" in content:
        return True, ""

    return False, f"Missing Intel copyright header: {os.path.basename(file_path)}"


def main():
    tool_input = get_tool_input()
    file_path = tool_input.get("file_path", "")

    if not file_path:
        sys.exit(0)

    ok, message = check_header(file_path)
    if not ok:
        print(f"WARNING: {message}", file=sys.stderr)

    sys.exit(0)


if __name__ == "__main__":
    main()
