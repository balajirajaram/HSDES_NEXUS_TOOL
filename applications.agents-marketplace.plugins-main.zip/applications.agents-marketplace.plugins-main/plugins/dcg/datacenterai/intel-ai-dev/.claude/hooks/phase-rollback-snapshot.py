#!/usr/bin/env python3
# Copyright (C) 2026 Intel Corporation
# SPDX-License-Identifier: Apache-2.0
"""PreToolUse hook: Creates a WIP git snapshot before destructive phases.

Triggered by: Bash commands that write new files at scale (scaffold.py,
code generation sub-phases). Creates a git commit tagged wip:<phase> so
the developer can git reset --hard to recover from a bad phase.

Usage in settings.json:
  "PreToolUse": [{ "matcher": "Bash", "hooks": [{ "type": "command",
    "command": "python3 .claude/hooks/phase-rollback-snapshot.py 2>/dev/null || true" }] }]
"""

import json
import os
import re
import subprocess
import sys
from datetime import datetime, timezone

# Commands that trigger a WIP snapshot (they write files at scale)
SNAPSHOT_TRIGGERS: list[tuple[str, str]] = [
    (r'scaffold\.py', "scaffold"),
    (r'# Phase 4\b', "phase-4-codegen"),
    (r'# Phase 4\.5\b', "phase-4.5-dev-sanity"),
    (r'# Phase 4\.6\b', "phase-4.6-integration-audit"),
    (r'# Phase 4\.7\b', "phase-4.7-readme"),
    (r'# Phase 4\.9\b', "phase-4.9-completion-gate"),
    (r'alembic\s+upgrade', "db-migration"),
]

SKIP_IF_ALREADY_CLEAN = True  # skip snapshot if git status is clean (nothing to save)


def get_tool_input() -> dict:
    try:
        return json.loads(sys.stdin.read())
    except (json.JSONDecodeError, EOFError):
        return {}


def git_is_available() -> bool:
    try:
        subprocess.run(["git", "rev-parse", "--git-dir"],
                       capture_output=True, check=True, timeout=5)
        return True
    except (subprocess.CalledProcessError, FileNotFoundError, subprocess.TimeoutExpired):
        return False


def has_staged_or_unstaged_changes() -> bool:
    result = subprocess.run(
        ["git", "status", "--porcelain"],
        capture_output=True, text=True, timeout=10,
    )
    return bool(result.stdout.strip())


def create_snapshot(phase_label: str) -> None:
    ts = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S")
    msg = f"wip: snapshot before {phase_label} [{ts}]"

    # Stage all tracked + new files (exclude .env, secrets per .gitignore)
    subprocess.run(["git", "add", "-A"], capture_output=True, timeout=30)

    # Only commit if there's actually something staged
    status = subprocess.run(
        ["git", "diff", "--cached", "--quiet"],
        capture_output=True, timeout=10,
    )
    if status.returncode == 0:
        # Nothing staged — nothing to commit
        return

    subprocess.run(
        ["git", "commit", "-m", msg, "--no-verify"],
        capture_output=True, timeout=30,
    )
    print(
        f"SNAPSHOT: Created rollback point '{msg}'. "
        "To undo this phase: git reset --hard HEAD~1",
        file=sys.stderr,
    )


def main() -> None:
    tool_input = get_tool_input()
    command = tool_input.get("command", "")

    if not command or not git_is_available():
        sys.exit(0)

    matched_label = None
    for pattern, label in SNAPSHOT_TRIGGERS:
        if re.search(pattern, command):
            matched_label = label
            break

    if not matched_label:
        sys.exit(0)

    if SKIP_IF_ALREADY_CLEAN and not has_staged_or_unstaged_changes():
        sys.exit(0)

    try:
        create_snapshot(matched_label)
    except Exception as e:  # noqa: BLE001
        # Never block execution due to snapshot failure
        print(f"SNAPSHOT: Could not create rollback point: {e}", file=sys.stderr)

    sys.exit(0)


if __name__ == "__main__":
    main()
