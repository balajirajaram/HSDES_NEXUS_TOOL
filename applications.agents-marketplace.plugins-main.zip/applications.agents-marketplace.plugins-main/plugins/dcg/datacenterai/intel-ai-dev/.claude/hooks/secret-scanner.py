#!/usr/bin/env python3
# Copyright (C) 2026 Intel Corporation
# SPDX-License-Identifier: Apache-2.0
"""PreToolUse hook: Scans Bash commands for potential secret exposure.

Covers: AWS, GCP, Azure, GitHub, private keys, JWT, DB connection strings,
Intel API keys, Slack tokens, generic high-entropy secrets.
"""

import json
import re
import sys

SECRET_INDICATORS = [
    # Cloud provider keys
    (r'AKIA[0-9A-Z]{16}', "AWS access key"),
    (r'(?i)aws[_\-\s]?secret[_\-\s]?access[_\-\s]?key\s*=\s*[A-Za-z0-9/+=]{40}', "AWS secret key"),
    (r'AIza[0-9A-Za-z\-_]{35}', "GCP API key"),
    (r'(?i)gcp[_\-]?service[_\-]?account.*"private_key"', "GCP service account key"),
    (r'[A-Za-z0-9+/]{76}AAAA', "Azure SAS / base64 blob token"),

    # Source control & CI tokens
    (r'ghp_[a-zA-Z0-9]{36}', "GitHub personal access token"),
    (r'ghs_[a-zA-Z0-9]{36}', "GitHub Actions token"),
    (r'glpat-[a-zA-Z0-9\-]{20}', "GitLab personal access token"),

    # Private keys (PEM)
    (r'-----BEGIN (RSA |EC |DSA |OPENSSH )?PRIVATE KEY-----', "PEM private key"),

    # JWT with signature (3 base64 segments)
    (r'eyJ[A-Za-z0-9_\-]{10,}\.[A-Za-z0-9_\-]{10,}\.[A-Za-z0-9_\-]{10,}', "JWT token"),

    # Database connection strings with embedded credentials
    (r'(?i)(postgresql|mysql|mongodb|redis)://[^:]+:[^@]{6,}@', "DB connection string with password"),

    # Slack
    (r'xox[baprs]-[0-9A-Za-z\-]{10,}', "Slack token"),

    # Intel-style API keys (Bearer / subscription key patterns)
    (r'(?i)(ocp-apim-subscription-key|x-api-key|authorization:\s*bearer)\s*[=:]\s*[A-Za-z0-9\-_]{20,}', "API key / bearer token"),

    # Generic hardcoded passwords in shell assignments
    (r'(?i)(password|passwd|secret|token|api_key)\s*=\s*["\'][^$\{\(][^"\']{8,}["\']', "Hardcoded credential assignment"),

    # Private key passphrases in ssh-keygen / openssl calls
    (r'(?i)(openssl|ssh-keygen).*-passout\s+pass:[^\s]{4,}', "Hardcoded key passphrase"),
]

SKIP_PATTERNS = [
    r'\$\{[^}]+\}',       # shell variable interpolation
    r'\$[A-Z_][A-Z0-9_]+', # plain env var reference
    r'example\.com',
    r'your[_\-]token',
    r'<YOUR',
    r'REPLACE_ME',
    r'changeme',
]


def looks_like_real_secret(command: str, match_start: int, match_end: int) -> bool:
    """Heuristic: skip obvious placeholders."""
    snippet = command[max(0, match_start - 20):match_end + 20]
    for skip in SKIP_PATTERNS:
        if re.search(skip, snippet, re.IGNORECASE):
            return False
    return True


def get_tool_input() -> dict:
    try:
        return json.loads(sys.stdin.read())
    except (json.JSONDecodeError, EOFError):
        return {}


def main() -> None:
    tool_input = get_tool_input()
    command = tool_input.get("command", "")

    if not command:
        sys.exit(0)

    findings = []
    for pattern, label in SECRET_INDICATORS:
        for m in re.finditer(pattern, command):
            if looks_like_real_secret(command, m.start(), m.end()):
                findings.append(label)
                break  # one finding per pattern is enough

    if findings:
        labels = ", ".join(dict.fromkeys(findings))  # deduplicate, preserve order
        print(
            f"WARNING: Command may contain hardcoded secret(s): {labels}. "
            "Use environment variables instead (e.g. $MY_TOKEN).",
            file=sys.stderr,
        )

    sys.exit(0)


if __name__ == "__main__":
    main()
