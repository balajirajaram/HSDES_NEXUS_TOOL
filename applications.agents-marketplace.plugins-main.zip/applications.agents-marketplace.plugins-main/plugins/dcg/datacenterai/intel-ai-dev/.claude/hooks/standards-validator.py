#!/usr/bin/env python3
# Copyright (C) 2026 Intel Corporation
# SPDX-License-Identifier: Apache-2.0
"""PostToolUse hook: Validates written files against Intel coding standards.

Checks:
- Secrets / credential patterns (15 patterns, aligned with secret-scanner.py)
- Python syntax validity
- TypeScript: no console.log left in production code
- YAML: basic parse validity
- Shell scripts: no hardcoded sudo password flags
"""

import ast
import json
import os
import re
import sys
from pathlib import Path

SECRET_PATTERNS: list[tuple[str, str]] = [
    (r'AKIA[0-9A-Z]{16}', "AWS access key"),
    (r'AIza[0-9A-Za-z\-_]{35}', "GCP API key"),
    (r'ghp_[a-zA-Z0-9]{36}', "GitHub PAT"),
    (r'ghs_[a-zA-Z0-9]{36}', "GitHub Actions token"),
    (r'glpat-[a-zA-Z0-9\-]{20}', "GitLab PAT"),
    (r'-----BEGIN (RSA |EC |DSA |OPENSSH )?PRIVATE KEY-----', "PEM private key"),
    (r'eyJ[A-Za-z0-9_\-]{10,}\.[A-Za-z0-9_\-]{10,}\.[A-Za-z0-9_\-]{10,}', "JWT token"),
    (r'(?i)(postgresql|mysql|mongodb)://[^:]+:[^@\s$]{6,}@[^/\s]', "DB URL with embedded password"),
    (r'xox[baprs]-[0-9A-Za-z\-]{10,}', "Slack token"),
    (r'(?i)(password|passwd|secret|api_key)\s*=\s*["\'][^$\{\(][^"\']{8,}["\']', "Hardcoded credential"),
]

SKIP_PATHS = [
    "node_modules", ".venv", "venv", "__pycache__", ".tox",
    ".env.example", ".tmpl", "test", "fixture", "mock",
    "tests/", "/test_", "_test.py",
]

TS_WARN_PATTERNS: list[tuple[str, str]] = [
    (r'\bconsole\.(log|warn|error|debug)\b', "console.* statement in production code"),
    (r'\bany\b\s*;', "TypeScript 'any' type usage"),
    (r'@ts-ignore', "@ts-ignore suppressor"),
]

SH_WARN_PATTERNS: list[tuple[str, str]] = [
    (r'echo\s+["\'][^"\']*["\'][^|]*\|\s*sudo\s+-S', "echo password pipe to sudo -S"),
    (r'HISTFILE\s*=\s*/dev/null', "disabling shell history"),
]


def should_skip(file_path: str) -> bool:
    return any(skip in file_path for skip in SKIP_PATHS)


def check_secrets(content: str, file_path: str) -> list[str]:
    findings = []
    for pattern, label in SECRET_PATTERNS:
        if re.search(pattern, content):
            findings.append(f"Potential {label} in {Path(file_path).name}")
    return findings


def check_python_syntax(file_path: str, content: str) -> list[str]:
    if not file_path.endswith(".py"):
        return []
    try:
        compile(content, file_path, "exec")
        return []
    except SyntaxError as e:
        return [f"Syntax error in {Path(file_path).name}:{e.lineno} — {e.msg}"]


def check_typescript(file_path: str, content: str) -> list[str]:
    if not file_path.endswith((".ts", ".tsx")):
        return []
    findings = []
    for pattern, label in TS_WARN_PATTERNS:
        if re.search(pattern, content):
            findings.append(f"TS: {label} in {Path(file_path).name}")
    return findings


def check_yaml_syntax(file_path: str, content: str) -> list[str]:
    if not file_path.endswith((".yml", ".yaml")):
        return []
    try:
        import yaml  # noqa: PLC0415
        yaml.safe_load(content)
        return []
    except Exception:  # noqa: BLE001
        # yaml may not be installed — degrade gracefully
        try:
            # Minimal bracket/indent sanity: count colons at line starts
            suspicious = [
                i + 1 for i, line in enumerate(content.splitlines())
                if re.match(r'^\s+\S.*:\s*\S.*:\s*\S', line)
            ]
            if suspicious:
                return [f"YAML: possible multi-colon issue on lines {suspicious[:3]} in {Path(file_path).name}"]
        except Exception:  # noqa: BLE001
            pass
    return []


def check_shell(file_path: str, content: str) -> list[str]:
    if not file_path.endswith(".sh"):
        return []
    findings = []
    for pattern, label in SH_WARN_PATTERNS:
        if re.search(pattern, content):
            findings.append(f"Shell: {label} in {Path(file_path).name}")
    return findings


def get_tool_input() -> dict:
    try:
        return json.loads(sys.stdin.read())
    except (json.JSONDecodeError, EOFError):
        return {}


def main() -> None:
    tool_input = get_tool_input()
    file_path = tool_input.get("file_path", "")

    if not file_path or not os.path.isfile(file_path) or should_skip(file_path):
        sys.exit(0)

    ext = Path(file_path).suffix.lower()
    applicable_exts = {".py", ".ts", ".tsx", ".js", ".jsx", ".yaml", ".yml", ".sh"}
    if ext not in applicable_exts:
        sys.exit(0)

    try:
        with open(file_path, encoding="utf-8", errors="ignore") as f:
            content = f.read()
    except OSError:
        sys.exit(0)

    if not content.strip():
        sys.exit(0)

    warnings = (
        check_secrets(content, file_path)
        + check_python_syntax(file_path, content)
        + check_typescript(file_path, content)
        + check_yaml_syntax(file_path, content)
        + check_shell(file_path, content)
    )

    for w in warnings:
        print(f"WARNING: {w}", file=sys.stderr)

    sys.exit(0)


if __name__ == "__main__":
    main()
