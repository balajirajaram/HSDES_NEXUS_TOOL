# Compliance Report Schema

## What `/compliance-agent` produces

### Output Files

| File | Format | Required | Description |
|------|--------|----------|-------------|
| `reports/compliance/security-scan.md` | Markdown | Yes | Human-readable scan summary |
| `reports/compliance/security-scan.json` | JSON | Yes | Machine-readable scan data |
| `reports/compliance/license-inventory.md` | Markdown | Yes | License analysis |
| `reports/compliance/slsa-checklist.md` | Markdown | Yes | SLSA level verification |
| `reports/compliance/openssf-scorecard.md` | Markdown | Yes | OpenSSF score estimate |
| `reports/compliance/ospdt-{slug}.pptx` | PPTX | Yes | OSPDT PowerPoint deck |
| `reports/compliance/sbom-{slug}.json` | JSON | Yes | CycloneDX SBOM |
| `reports/architecture/threat-model.md` | Mermaid | Yes | STRIDE threat model |
| `reports/architecture/data-flow.md` | Mermaid | Yes | DFD levels 0-1 |
| `reports/architecture/component-arch.md` | Mermaid | Yes | Microservice topology |
| `reports/architecture/deployment-arch.md` | Mermaid | Yes | K8s namespace layout |
| `reports/architecture/api-sequences.md` | Mermaid | Yes | Auth + critical API flows |
| `reports/DASHBOARD.md` | Markdown | Yes | Unified summary (generated last) |

### Raw Scan Output (Machine-Readable)

These are intermediate artifacts consumed by the report generator:

| File | Tool | Purpose |
|------|------|---------|
| `reports/compliance/bandit-report.json` | bandit | Python SAST findings |
| `reports/compliance/trivy-fs-report.json` | trivy | Filesystem vulnerability scan |
| `reports/compliance/trivy-image-report.json` | trivy | Container image scan |
| `reports/compliance/pip-audit-report.json` | pip-audit | Python dependency CVEs |
| `reports/compliance/npm-audit-report.json` | npm audit | JS dependency CVEs |
| `reports/compliance/license-report.json` | pip-licenses | License inventory |
| `reports/compliance/secrets-report.json` | detect-secrets | Secret leak detection |

### Security Scan JSON Schema (security-scan.json)

```json
{
  "timestamp": "ISO-8601",
  "project": "{project_slug}",
  "overall_status": "PASS | CONDITIONAL | FAIL",
  "tools_available": ["bandit", "trivy", "pip-audit", "shellcheck", "detect-secrets"],
  "tools_missing": [],
  "scans": {
    "sast": {
      "tool": "bandit",
      "status": "PASS | FAIL | SKIPPED",
      "findings": {
        "high": 0,
        "medium": 2,
        "low": 5
      },
      "auto_fixed": 0,
      "remaining": 7,
      "skipped_rules": ["B101"]
    },
    "container": {
      "tool": "trivy",
      "status": "PASS | FAIL | SKIPPED",
      "findings": {
        "critical": 0,
        "high": 1,
        "medium": 3,
        "low": 8
      }
    },
    "dependencies": {
      "tool": "pip-audit",
      "status": "PASS | FAIL | SKIPPED",
      "cve_count": 0,
      "packages_scanned": 45
    },
    "secrets": {
      "tool": "detect-secrets",
      "status": "PASS | FAIL | SKIPPED",
      "findings": 0
    },
    "shell": {
      "tool": "shellcheck",
      "status": "PASS | FAIL | SKIPPED",
      "errors": 0
    }
  },
  "licenses": {
    "total_packages": 45,
    "permissive": 40,
    "weak_copyleft": 3,
    "strong_copyleft": 0,
    "unknown": 2,
    "status": "APPROVED | REVIEW | BLOCKED",
    "blocked_packages": []
  },
  "slsa": {
    "level": 2,
    "checks": {
      "scripted_build": true,
      "build_service": true,
      "provenance_generated": true,
      "signed_artifacts": false,
      "sbom_attached": true,
      "deps_pinned": true,
      "source_available": true
    }
  },
  "openssf_score": {
    "estimated": 7,
    "max": 10,
    "checks": {
      "branch_protection": true,
      "code_review": true,
      "ci_tests": true,
      "sast": true,
      "dependency_updates": true,
      "signed_releases": false,
      "security_policy": true,
      "license_file": true,
      "no_binaries": true,
      "pinned_deps": true
    }
  }
}
```

### Compliance Report Structure (security-scan.md)

```markdown
# Compliance Report — {project_name}
Date: {YYYY-MM-DD}
Pipeline Iteration: {1|2}

## Executive Summary
| Metric | Value | Status |
|--------|-------|--------|
| Overall | {PASS/CONDITIONAL/FAIL} | {emoji} |
| SLSA Level | {0-3} | Target: 2 |
| OpenSSF Score | {X}/10 | Target: 7 |
| OSPDT | {READY/NEEDS REVIEW/BLOCKED} | — |

## Security Scan Results

### SAST (Bandit)
| Severity | Found | Auto-fixed | Remaining | Status |
|----------|-------|------------|-----------|--------|
| HIGH | X | X | X | PASS/FAIL |
| MEDIUM | X | X | X | — |
| LOW | X | X | X | — |

Skipped rules: B101 (assert in tests)

### Container Vulnerabilities (Trivy)
| Severity | Count | Fixable | Status |
|----------|-------|---------|--------|
| CRITICAL | X | X | PASS/FAIL |
| HIGH | X | X | PASS/FAIL |
| MEDIUM | X | — | — |

### Dependency Audit
| Tool | Packages | CVEs Found | Status |
|------|----------|-----------|--------|
| pip-audit | X | X | PASS/FAIL |
| npm audit | X | X | PASS/FAIL/SKIPPED |

### Secret Detection
Findings: {count} — Status: {PASS/FAIL}

### Shell Scripts (ShellCheck)
Errors: {count} — Status: {PASS/FAIL}

## License Compliance
| Category | Count | Packages | Status |
|----------|-------|----------|--------|
| Permissive (MIT, BSD, Apache-2.0) | X | — | APPROVED |
| Weak Copyleft (LGPL, MPL) | X | {list} | REVIEW |
| Strong Copyleft (GPL, AGPL) | X | {list} | BLOCKED |
| Unknown | X | {list} | REVIEW |

## SLSA Compliance (Level {X})
| Requirement | Status | Evidence |
|------------|--------|----------|
| Scripted build | ✓/✗ | .github/workflows/ci.yml |
| Build service | ✓/✗ | GitHub Actions hosted runners |
| Provenance generated | ✓/✗ | SLSA GitHub generator |
| Signed artifacts | ✓/✗ | cosign in release.yml |
| SBOM attached | ✓/✗ | trivy sbom in release |
| Dependencies pinned | ✓/✗ | requirements.txt + lock |
| Source available | ✓/✗ | GitHub repo |

## OpenSSF Scorecard (Estimated: {X}/10)
| Check | Status | Notes |
|-------|--------|-------|
| Branch protection | ✓/✗ | {detail} |
| Code review | ✓/✗ | {detail} |
| CI tests | ✓/✗ | {detail} |
| SAST enabled | ✓/✗ | {detail} |
| Dependency updates | ✓/✗ | {detail} |
| Signed releases | ✓/✗ | {detail} |
| Security policy | ✓/✗ | {detail} |
| License file | ✓/✗ | {detail} |
| No binaries | ✓/✗ | {detail} |
| Pinned dependencies | ✓/✗ | {detail} |

## SDLE Artifacts
- [Threat Model](../architecture/threat-model.md) — STRIDE analysis
- [Data Flow](../architecture/data-flow.md) — Level 0-1 DFD
- [Component Architecture](../architecture/component-arch.md) — Service topology
- [Deployment Architecture](../architecture/deployment-arch.md) — K8s layout
- [API Sequences](../architecture/api-sequences.md) — Auth + critical flows

## SBOM
- **Format**: CycloneDX 1.5
- **Location**: reports/compliance/sbom-{slug}.json
- **Components**: {count}
- **Generated by**: trivy fs --format cyclonedx

## OSPDT Deck
- **Location**: reports/compliance/ospdt-{slug}.pptx
- **Slides**: 6 (Title, Overview, Inventory, Licenses, Security, Risk)
- **Recommendation**: APPROVE / CONDITIONAL / REJECT
- **Reason**: {one-line justification}

## Action Items (Prioritized)
### Must Fix (blocks OSPDT approval)
1. {Finding}: {remediation with specific command}

### Should Fix (before production)
1. {Finding}: {remediation}

### Informational
1. {Finding}: {context}
```

### OSPDT Deck Specification

| Slide | Title | Content | Styling |
|-------|-------|---------|---------|
| 1 | Title | Project name, team, date, version | Intel blue #003580, Calibri |
| 2 | Project Overview | Description, stack, component count | Bullet points |
| 3 | Open Source Inventory | Color-coded license table | GREEN/YELLOW/RED |
| 4 | License Compliance | Counts by category, compatibility | Pie chart |
| 5 | Security Assessment | Scan summaries, CVE count, SBOM status | Risk meter |
| 6 | Risk Assessment | Overall risk, recommendation, mitigations | Decision box |

Color coding for licenses:
- **GREEN**: MIT, BSD-2-Clause, BSD-3-Clause, Apache-2.0, ISC, Unlicense
- **YELLOW**: MPL-2.0, LGPL-2.1, LGPL-3.0, CC-BY-4.0
- **RED**: GPL-2.0, GPL-3.0, AGPL-3.0, SSPL, BSL

### SDLE Diagram Requirements

Each diagram file MUST contain:
1. Title and description
2. Mermaid code block (renders in GitHub/Confluence)
3. Legend explaining symbols/colors
4. Assumptions section

### Consumed By
- **OSPDT review team** — PowerPoint deck for approval meeting
- **DASHBOARD.md** — reads `security-scan.json` for metric population
- **Wiki** — compliance report published to Confluence
- **Jira** — compliance status updated on EPICs
- **CI/CD** — `security-scan.json` can be parsed by pipeline gates
