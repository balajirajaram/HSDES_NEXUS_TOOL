# Iteration State Schema

Defines the JSON schema for `.iteration-state.json` — the file that tracks pipeline
progress across sessions and iterations.

---

## Location

```
{output-dir}/.iteration-state.json
```

This file is created by `/dev-agent` after project generation and updated by each
subsequent agent (`/validation-agent`, `/compliance-agent`).

---

## JSON Schema

```json
{
  "$schema": "http://json-schema.org/draft-07/schema#",
  "title": "Iteration State",
  "description": "Tracks pipeline progress for Intel AI Solutions Development",
  "type": "object",
  "required": ["project", "current_iteration", "phases", "tool_availability"],
  "properties": {
    "project": {
      "type": "object",
      "required": ["name", "slug", "created_at"],
      "properties": {
        "name": {
          "type": "string",
          "description": "Human-readable project name"
        },
        "slug": {
          "type": "string",
          "description": "kebab-case project identifier"
        },
        "created_at": {
          "type": "string",
          "format": "date-time",
          "description": "ISO 8601 timestamp of initial generation"
        },
        "prd_path": {
          "type": "string",
          "description": "Relative path to the Technical PRD used"
        }
      }
    },
    "current_iteration": {
      "type": "integer",
      "minimum": 1,
      "description": "Current iteration number (1 = local, 2 = with infra)"
    },
    "phases": {
      "type": "object",
      "description": "Status of each pipeline phase. These are the CANONICAL keys that all agents read/write.",
      "properties": {
        "prd": {
          "$ref": "#/definitions/phase_status"
        },
        "generation": {
          "$ref": "#/definitions/phase_status"
        },
        "dev_sanity": {
          "$ref": "#/definitions/phase_status",
          "description": "Dev sanity verification — confirms backend starts, frontend proxies, auth works"
        },
        "validation": {
          "$ref": "#/definitions/phase_status"
        },
        "compliance": {
          "$ref": "#/definitions/phase_status"
        },
        "review": {
          "$ref": "#/definitions/phase_status",
          "description": "Intel code review — contract rules, security, standards"
        },
        "dashboard": {
          "$ref": "#/definitions/phase_status"
        }
      },
      "additionalProperties": {
        "$ref": "#/definitions/phase_status",
        "description": "Dev-agent may store internal sub-phase keys (phase_0, phase_4.5, etc.) for session recovery. These are agent-internal and ignored by other agents."
      }
    },
    "skipped_items": {
      "type": "array",
      "description": "Items skipped in current iteration with reasons",
      "items": {
        "type": "object",
        "required": ["item", "reason", "phase", "needed_for_next"],
        "properties": {
          "item": {
            "type": "string",
            "description": "What was skipped (e.g., 'trivy container scan')"
          },
          "reason": {
            "type": "string",
            "description": "Why it was skipped (e.g., 'trivy not installed')"
          },
          "phase": {
            "type": "string",
            "enum": ["generation", "dev_sanity", "validation", "compliance", "review"],
            "description": "Which phase attempted this"
          },
          "needed_for_next": {
            "type": "string",
            "description": "What to install/configure (e.g., 'Install trivy: brew install trivy')"
          }
        }
      }
    },
    "tool_availability": {
      "type": "object",
      "description": "Which tools were detected as available",
      "properties": {
        "ruff": { "type": "boolean" },
        "mypy": { "type": "boolean" },
        "bandit": { "type": "boolean" },
        "trivy": { "type": "boolean" },
        "pip_audit": { "type": "boolean" },
        "pip_licenses": { "type": "boolean" },
        "detect_secrets": { "type": "boolean" },
        "python_pptx": { "type": "boolean" },
        "helm": { "type": "boolean" },
        "docker": { "type": "boolean" },
        "shellcheck": { "type": "boolean" },
        "cosign": { "type": "boolean" }
      }
    },
    "iteration_history": {
      "type": "array",
      "description": "Record of each iteration run",
      "items": {
        "type": "object",
        "required": ["iteration", "started_at", "phases_run"],
        "properties": {
          "iteration": {
            "type": "integer"
          },
          "started_at": {
            "type": "string",
            "format": "date-time"
          },
          "completed_at": {
            "type": ["string", "null"],
            "format": "date-time"
          },
          "phases_run": {
            "type": "array",
            "items": {
              "type": "string",
              "enum": ["prd", "generation", "dev_sanity", "validation", "compliance", "review", "dashboard"]
            }
          },
          "notes": {
            "type": "string"
          }
        }
      }
    },
    "integrations": {
      "type": "object",
      "description": "Remote integration configuration (set during Integration Setup)",
      "properties": {
        "git": {
          "type": "object",
          "required": ["mode"],
          "properties": {
            "mode": {
              "type": "string",
              "enum": ["remote", "local"],
              "description": "Whether code is pushed to remote or committed locally only"
            },
            "remote_url": {
              "type": "string",
              "description": "Git remote URL (only if mode=remote)"
            },
            "branch": {
              "type": "string",
              "description": "Branch name used for this solution"
            }
          }
        },
        "wiki": {
          "type": "object",
          "properties": {
            "configured": {
              "type": "boolean",
              "description": "Whether Wiki credentials were provided"
            },
            "space": {
              "type": "string",
              "description": "Confluence space key",
              "default": "datacenterai"
            }
          }
        },
        "jira": {
          "type": "object",
          "properties": {
            "configured": {
              "type": "boolean",
              "description": "Whether Jira credentials were provided"
            },
            "project": {
              "type": "string",
              "description": "Jira project key",
              "default": "DCAIDSE8"
            }
          }
        }
      }
    },
    "next_iteration_requirements": {
      "type": "object",
      "description": "What must be set up before the next iteration",
      "properties": {
        "tools_to_install": {
          "type": "array",
          "items": {
            "type": "object",
            "properties": {
              "name": { "type": "string" },
              "install_command": { "type": "string" },
              "purpose": { "type": "string" }
            }
          }
        },
        "configs_needed": {
          "type": "array",
          "items": {
            "type": "object",
            "properties": {
              "config": { "type": "string" },
              "description": { "type": "string" },
              "example": { "type": "string" }
            }
          }
        },
        "services_to_deploy": {
          "type": "array",
          "items": {
            "type": "object",
            "properties": {
              "service": { "type": "string" },
              "purpose": { "type": "string" },
              "how": { "type": "string" }
            }
          }
        }
      }
    }
  },
  "definitions": {
    "phase_status": {
      "type": "object",
      "required": ["status"],
      "properties": {
        "status": {
          "type": "string",
          "enum": ["not_started", "in_progress", "completed", "partial", "skipped"],
          "description": "Current status of this phase"
        },
        "completed_at": {
          "type": ["string", "null"],
          "format": "date-time"
        },
        "iteration": {
          "type": "integer",
          "description": "Which iteration this was completed in"
        },
        "report_path": {
          "type": "string",
          "description": "Relative path to the phase report"
        },
        "notes": {
          "type": "string"
        }
      }
    }
  }
}
```

---

## Example

```json
{
  "project": {
    "name": "Defect Detection Pipeline",
    "slug": "defect-detection-pipeline",
    "created_at": "2026-05-05T10:30:00Z",
    "prd_path": "docs/prd/defect-detection-pipeline-technical.md"
  },
  "current_iteration": 1,
  "phases": {
    "prd": {
      "status": "completed",
      "completed_at": "2026-05-05T10:30:00Z",
      "iteration": 1,
      "report_path": "reports/generation/generation-summary.md"
    },
    "generation": {
      "status": "completed",
      "completed_at": "2026-05-05T11:00:00Z",
      "iteration": 1,
      "report_path": "reports/generation/file-manifest.json"
    },
    "validation": {
      "status": "partial",
      "completed_at": "2026-05-05T11:30:00Z",
      "iteration": 1,
      "report_path": "reports/validation/test-results.md",
      "notes": "Unit tests passed, integration tests need Docker"
    },
    "compliance": {
      "status": "partial",
      "completed_at": "2026-05-05T12:00:00Z",
      "iteration": 1,
      "report_path": "reports/compliance/security-scan.md",
      "notes": "Bandit ran, Trivy skipped (not installed)"
    },
    "dashboard": {
      "status": "completed",
      "completed_at": "2026-05-05T12:05:00Z",
      "iteration": 1,
      "report_path": "reports/DASHBOARD.md"
    }
  },
  "integrations": {
    "git": {
      "mode": "remote",
      "remote_url": "https://github.com/intel-sandbox/defect-detection-pipeline.git",
      "branch": "main"
    },
    "wiki": {
      "configured": true,
      "space": "datacenterai"
    },
    "jira": {
      "configured": false,
      "project": "DCAIDSE8"
    }
  },
  "skipped_items": [
    {
      "item": "Container image scan (Trivy)",
      "reason": "trivy not installed",
      "phase": "compliance",
      "needed_for_next": "Install trivy: brew install trivy (macOS) or see https://trivy.dev"
    },
    {
      "item": "OSPDT deck generation",
      "reason": "python-pptx not installed",
      "phase": "compliance",
      "needed_for_next": "pip install python-pptx"
    },
    {
      "item": "Integration tests with database",
      "reason": "PostgreSQL not running locally",
      "phase": "validation",
      "needed_for_next": "docker compose up -d postgres"
    }
  ],
  "tool_availability": {
    "ruff": true,
    "mypy": true,
    "bandit": true,
    "trivy": false,
    "pip_audit": true,
    "pip_licenses": true,
    "detect_secrets": true,
    "python_pptx": false,
    "helm": false,
    "docker": true,
    "shellcheck": false,
    "cosign": false
  },
  "iteration_history": [
    {
      "iteration": 1,
      "started_at": "2026-05-05T10:00:00Z",
      "completed_at": "2026-05-05T12:05:00Z",
      "phases_run": ["prd", "generation", "validation", "compliance", "dashboard"],
      "notes": "Local validation complete. Need trivy, python-pptx, helm for iteration 2."
    }
  ],
  "next_iteration_requirements": {
    "tools_to_install": [
      {
        "name": "trivy",
        "install_command": "brew install trivy",
        "purpose": "Container and filesystem vulnerability scanning"
      },
      {
        "name": "python-pptx",
        "install_command": "pip install python-pptx",
        "purpose": "OSPDT PowerPoint deck generation"
      },
      {
        "name": "helm",
        "install_command": "brew install helm",
        "purpose": "Helm chart linting and validation"
      }
    ],
    "configs_needed": [
      {
        "config": "WIKI_BASE_URL + WIKI_PAT",
        "description": "Confluence credentials for Wiki publish",
        "example": "export WIKI_BASE_URL=https://wiki.intel.com"
      }
    ],
    "services_to_deploy": [
      {
        "service": "PostgreSQL",
        "purpose": "Integration test database",
        "how": "docker compose up -d postgres"
      }
    ]
  }
}
```

---

## Update Rules

- `/prd-agent` creates `.iteration-state.json` with `integrations` block (from Integration Setup)
- `/dev-agent` adds `phases.generation`, `phases.dev_sanity`, and `tool_availability`; creates `.iteration-state.json` if PRD agent was skipped. May also write internal sub-phase keys (`phase_0`..`phase_4.8`) for its own session recovery — these are agent-internal and other agents ignore them.
- `/validation-agent` updates `phases.validation` and adds to `skipped_items`
- `/compliance-agent` updates `phases.compliance`, `phases.dashboard`, and `tool_availability`
- `/review-agent` updates `phases.review`
- `integrations` block is written ONCE during Integration Setup and never modified (except on auth failure → offer to update)
- When all phases reach `completed` status, increment `current_iteration`
- Never delete history — append to `iteration_history`

### Canonical Phase Keys (MANDATORY)

Every agent MUST write to the canonical keys (`phases.generation`, `phases.validation`, etc.) — not just internal sub-phase keys. Other agents rely on these keys for session recovery and handoff detection. The canonical keys are: `prd`, `generation`, `dev_sanity`, `validation`, `compliance`, `review`, `dashboard`.
