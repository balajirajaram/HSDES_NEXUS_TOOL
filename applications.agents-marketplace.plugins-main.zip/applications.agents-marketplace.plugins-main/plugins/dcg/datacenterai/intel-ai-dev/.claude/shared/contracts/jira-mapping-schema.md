# Jira Mapping Schema

## PRD → Jira Mapping

### Epic Mapping
```
PRD Epic → Jira Epic
  - Summary: Epic title
  - Description: Epic business value + scope
  - Priority: P0 → Highest, P1 → High, P2 → Medium
  - Labels: ["prd-generated", "{project-slug}"]
  - Components: ["{component-name}"]
```

### Story Mapping
```
PRD Story → Jira Story
  - Summary: Story title (As a...)
  - Description: Full story + acceptance criteria (markdown)
  - Story Points: From PRD effort estimate
  - Epic Link: Parent Epic key
  - Priority: Inherited from Epic
  - Labels: ["prd-generated", "{project-slug}"]
```

### Acceptance Criteria Format in Jira
```markdown
## Acceptance Criteria
- [ ] {criterion 1}
- [ ] {criterion 2}
- [ ] {criterion 3}

## Dependencies
- Blocked by: {story-key}
- Blocks: {story-key}

## Technical Notes
{From Technical PRD if available}
```

### Export Script Interface
```bash
# Dry run (preview)
python scripts/export-to-jira.py --dry-run docs/prd/{slug}-breakdown.md

# Export
python scripts/export-to-jira.py --project DCAIDSE8 docs/prd/{slug}-breakdown.md

# Output
{
  "epics_created": [{"key": "DCAIDSE8-100", "summary": "..."}],
  "stories_created": [{"key": "DCAIDSE8-101", "epic": "DCAIDSE8-100", "summary": "..."}],
  "total": {"epics": 5, "stories": 20}
}
```

### Required Environment
- `JIRA_BASE_URL` — Jira instance URL
- `JIRA_PAT` — Personal access token
- `JIRA_PROJECT` — Default project key (override with --project)
