# PRD Output Schema

## What `/prd-agent` produces

### Files
```
docs/prd/{slug}.md              # PRD document
docs/prd/{slug}-breakdown.md    # Feature Breakdown (Epics → Stories → Tasks)
docs/prd/{slug}-technical.md    # Technical PRD (optional)
```

### Handoff Metadata (YAML block at end of PRD)

```yaml
handoff:
  project_name: string          # Human-readable name
  project_slug: string          # kebab-case, <40 chars
  components:
    - name: string              # snake_case component name
      type: enum                # backend | frontend | agent | inference | worker
      port: integer             # Default port (8000, 5173, etc.)
  container_base_image: string  # e.g., "python:3.11-slim"
  helm_required: boolean
  observability: enum           # full | basic | none
  auth: enum                    # keycloak | api-key | none
  security_classification: enum # public | internal | confidential | restricted
  database: enum                # postgresql | none
  cache: enum                   # redis | none
  ai_components:
    llm: boolean
    agents: boolean
    inference: boolean
    vector_db: boolean
  standards_applied: list[string]
```

### Feature Breakdown Structure

```
Epic (5-6 per project)
  ├── priority: P0 | P1 | P2
  ├── business_value: string
  ├── effort: string (e.g., "3 sprints")
  ├── risk_level: LOW | MEDIUM | HIGH
  └── Stories (3-8 per epic)
      ├── title: "As a {role}, I want {action}, so that {benefit}"
      ├── acceptance_criteria: list[string]
      ├── effort: integer (story points)
      ├── dependencies: list[story_id]
      └── Tasks (2-5 per story)
          ├── description: string
          ├── effort: string (hours/days)
          └── deliverables: list[string]
```

### Consumed By
- `/dev-agent` — reads handoff metadata to scaffold project
- `/validation-agent` — reads acceptance criteria to generate tests
- `scripts/export-to-jira.py` — maps Epics/Stories to Jira
