# Test Report Schema

## What `/validation-agent` produces

### Output Files

| File | Format | Required | Description |
|------|--------|----------|-------------|
| `reports/validation/test-results.md` | Markdown | Yes | Human-readable test report |
| `reports/validation/coverage.json` | JSON | Yes | Machine-readable coverage data |
| `reports/validation/gaps-analysis.md` | Markdown | Yes | PRD criteria → test mapping |
| `reports/validation/lint-results.md` | Markdown | Yes | Ruff + mypy findings |

### Report Structure (test-results.md)

```markdown
# Validation Report — {project_name}
Date: {YYYY-MM-DD}
PRD: {slug}
Pipeline Iteration: {1|2}

## Summary
| Metric | Value | Target | Status |
|--------|-------|--------|--------|
| Unit test coverage | X% | 85% | PASS/FAIL |
| Integration tests | X/Y pass | 100% | PASS/FAIL |
| Security tests | X/Y pass | 100% | PASS/FAIL |
| Lint (ruff) | N issues | 0 | PASS/FAIL |
| Type check (mypy) | N issues | 0 | PASS/FAIL |
| Frontend tests | X/Y pass | 100% | PASS/FAIL/SKIPPED |

## Component Results
### {component_name}
- **Tests**: {passed}/{total} passed, {failed} failed, {skipped} skipped
- **Coverage**: {X}% (target: 85%)
- **Uncovered lines**: {file}:{line_range}, ...
- **Duration**: {X}s

## PRD Acceptance Criteria Coverage
| Story ID | Criterion | Test File:Function | Status |
|----------|-----------|-------------------|--------|
| US-{N} | {criterion text} | test_{file}.py::test_{func} | COVERED/MISSING/PARTIAL |

## Gaps Found
- [ ] {Story ID}: {criterion} — No test exists
- [ ] {resource}: Missing negative/edge-case tests for {scenario}
- [ ] Security: No injection test for {endpoint}

## Recommendations
1. {Specific action with file path and test to add}
2. {Specific action}
```

### Coverage JSON Schema (coverage.json)

```json
{
  "timestamp": "ISO-8601",
  "project": "{project_slug}",
  "overall_coverage_pct": 87.3,
  "target_coverage_pct": 85.0,
  "status": "PASS",
  "components": [
    {
      "name": "{component}",
      "coverage_pct": 87.3,
      "tests_passed": 42,
      "tests_failed": 0,
      "tests_skipped": 2,
      "tests_total": 44,
      "duration_seconds": 12.5,
      "uncovered_files": [
        {"file": "app/services/foo.py", "lines_missed": [15, 22, 45]}
      ]
    }
  ],
  "lint": {
    "ruff_issues": 0,
    "mypy_issues": 0
  },
  "prd_coverage": {
    "total_criteria": 24,
    "covered": 20,
    "partial": 2,
    "missing": 2
  }
}
```

### Gaps Analysis Structure (gaps-analysis.md)

```markdown
# PRD Gaps Analysis — {project_name}

## Coverage Matrix
| Epic | Stories | Criteria | Covered | Missing |
|------|---------|----------|---------|---------|
| {epic} | {N} | {N} | {N} | {N} |

## Missing Tests (Prioritized)
### Critical (blocks production)
- **{Story ID}**: {criterion} — Reason: {why this is critical}

### High (should fix before release)
- **{Story ID}**: {criterion}

### Medium (nice to have)
- **{Story ID}**: {criterion}

## Security Test Coverage
| Category | Tests | Status |
|----------|-------|--------|
| SQL Injection | {N} | COVERED/MISSING |
| XSS | {N} | COVERED/MISSING |
| Auth Bypass | {N} | COVERED/MISSING |
| Path Traversal | {N} | COVERED/MISSING |
| SSRF | {N} | COVERED/MISSING |
```

### Test Artifacts Generated

```
src/{component}/tests/
  conftest.py              # Fixtures: db_session, mock_user, client, factories
  unit/
    test_config.py         # Settings validation
    test_schemas.py        # Pydantic model validation
    test_services.py       # Business logic (mocked deps)
    test_{resource}.py     # Per-resource unit tests
  integration/
    test_api.py            # Full HTTP round-trip tests
    test_auth.py           # Auth flow (valid/invalid/expired tokens)
    test_middleware.py     # Middleware chain behavior
    test_health.py         # Health endpoint responses
  security/
    test_injection.py      # SQL/XSS/SSTI/path traversal
    test_auth_bypass.py    # Broken auth, privilege escalation
  performance/
    test_benchmarks.py     # pytest-benchmark stubs for hot paths
frontend/src/
  features/{feature}/components/__tests__/
    {Component}.test.tsx   # Render + interaction tests
  lib/__tests__/
    api-client.test.ts     # API client error handling
```

### Required Fields per Test

Every generated test MUST include:
- **Docstring**: One line linking to PRD criterion (e.g., "Covers US-3 AC-2: items list pagination")
- **Assert**: At least one meaningful assertion (not just status code)
- **Parametrize**: Edge cases use `@pytest.mark.parametrize`

### Consumed By
- `/compliance-agent` — reads `coverage.json` for dashboard metrics
- `reports/DASHBOARD.md` — validation section populated from these files
- Wiki publish — uploaded to Confluence
- Jira update — stories updated with test status (COVERED/MISSING)
