# CI/CD Standards

## GitHub Actions Workflows

### 1. CI Pipeline (`ci.yml`) — on every PR
- **Super-Linter v6.8.0**: Incremental (`VALIDATE_ALL_CODEBASE: false`)
  - VALIDATE_BASH (severity: error)
  - VALIDATE_YAML, VALIDATE_PYTHON_RUFF, VALIDATE_DOCKERFILE_HADOLINT
  - Regex exclude: Helm templates, K8s manifests
- **Per-component tox tests**: Path-filtered triggers (only changed components)
  - `if: success() || failure()` to continue on individual failures
- **Docker build**: Verify all Dockerfiles build successfully

### 2. SDLE Security Scans (`code-scans.yml`) — on every PR
From Enterprise-Inference pattern:
- **Trivy FS scan**: `--severity HIGH,CRITICAL`
- **Trivy image scan**: If Docker image was built
- **Bandit**: SAST, skip B101, exclude tests
- **ShellCheck**: All .sh files
- Artifacts uploaded, retention 30 days

### 3. Release Pipeline (`release.yml`) — on tag push
- Build and push container images
- Sign with cosign/sigstore
- Generate SBOM (CycloneDX via Trivy)
- Generate SLSA build provenance
- Create GitHub Release with artifacts

### 4. Dependency Review (`dependency-review.yml`) — on PR
- Diff dependencies added/removed
- Flag known vulnerabilities
- Flag license changes

### 5. CodeQL (`codeql-analysis.yml`) — on PR + schedule
- Multi-language SAST
- Custom queries for Intel-specific patterns

## Pre-commit Hooks (Enterprise-RAG Pattern)
```yaml
repos:
  - pre-commit-hooks: end-of-file-fixer, check-json, check-yaml, trailing-whitespace
  - Lucas-C/insert-license: Intel Apache-2.0 headers (.py, .yaml, .sh, .ts, Dockerfile)
  - isort, black, ruff --fix
  - detect-secrets, commitlint (conventional commits)
```

## Branch Protection
- 2+ reviewer approvals required
- Dismiss stale reviews on new push
- Require status checks: CI, SDLE scans
- No force push to main/master
- Signed commits enforced

## Artifact Retention
- CI logs: 30 days
- Security scan results: 90 days
- Release artifacts: permanent
- SBOM: permanent (attached to release)
