# Coding Standards

## Python Backend

### Project Setup
- **Build system**: PEP 621 with Hatchling (`pyproject.toml`)
- **Layout**: `src/{component}/app/` — flat source layout per component
- **Python**: 3.11+ required

### Code Style
- **Formatter**: black (line-length=100)
- **Linter**: ruff (line-length=100, target-version=py311)
- **Type checker**: mypy --strict (all code fully typed)
- **Import sorting**: isort (profile=black)
- **Docstrings**: Google style, one-line max

### Patterns
- **Framework**: FastAPI with async endpoints
- **Config**: pydantic-settings with nested models, `@lru_cache` singleton
- **Validation**: Pydantic v2 for all request/response models
- **Database**: SQLAlchemy 2.0 with async sessions (`asyncpg`)
- **HTTP client**: httpx (async native)
- **Task queue**: Celery (if needed)
- **Auth**: PyJWT + Keycloak JWKS

### Type Hints
- All function signatures must have type hints
- Use `from __future__ import annotations` for forward refs
- Prefer `list[str]` over `List[str]` (Python 3.11+)
- Use `T | None` over `Optional[T]`

### Async
- All I/O operations must be async
- Use `async for` for database iteration
- Use `asyncio.gather` for concurrent operations
- Never use `time.sleep` — use `asyncio.sleep`

### Error Handling
- Custom exception hierarchy extending `AppException`
- All HTTP error responses include `correlation_id`
- Never catch bare `Exception` without re-raising

## Frontend

### TypeScript
- `strict: true` in tsconfig.json
- No `any` types — use `unknown` with type guards
- Prefer interfaces over types for object shapes

### React
- Functional components only
- Feature-based folder structure (Bulletproof React)
- Zustand for global state, TanStack Query for server state
- React Hook Form for forms

### Testing
- Vitest + Testing Library
- Test behavior, not implementation
