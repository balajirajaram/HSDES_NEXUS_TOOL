# Container Standards (Enterprise-Inference Pattern)

## Dockerfile Pattern

### Multi-stage Build (Required)

```dockerfile
# Stage 1: Builder
FROM python:3.11-slim AS builder
WORKDIR /build
RUN python -m venv /opt/venv
ENV PATH="/opt/venv/bin:$PATH"
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

# Stage 2: Runtime
FROM python:3.11-slim
RUN apt-get update \
    && apt-get install -y --no-install-recommends curl ca-certificates \
    && rm -rf /var/lib/apt/lists/* \
    && groupadd -r appuser && useradd -r -g appuser -u 1000 appuser
COPY --from=builder /opt/venv /opt/venv
ENV PATH="/opt/venv/bin:$PATH"
WORKDIR /app
COPY app/ ./app/
USER appuser
EXPOSE 8000
HEALTHCHECK --interval=30s --timeout=5s --start-period=30s --retries=3 \
    CMD curl -f http://localhost:8000/healthz || exit 1
CMD ["uvicorn", "app.main:app", "--host", "0.0.0.0", "--port", "8000"]
```

## Required Elements

| Element | Requirement | Why |
|---------|-------------|-----|
| Multi-stage | 2+ stages (builder + runtime) | Smaller image, no build tools in prod |
| Base image | `python:3.11-slim` | Balance of size and compatibility |
| Non-root | `USER appuser` (uid=1000) | Security best practice |
| HEALTHCHECK | curl-based, 30s interval | K8s probe alignment |
| No cache | `--no-cache-dir` on pip | Smaller image |
| Venv | `/opt/venv` isolation | Clean dependency management |
| Minimal pkgs | Only `curl` + `ca-certificates` | Reduce attack surface |
| EXPOSE | Port explicitly declared | Documentation |
| WORKDIR | `/app` | Explicit working directory |

## Prohibited

| Practice | Why | Instead |
|----------|-----|---------|
| `FROM python:latest` | Unpredictable | Pin exact version |
| `FROM python:3.11` (full) | Too large, unnecessary tools | Use `-slim` |
| `RUN pip install` in runtime | No venv isolation | Use builder stage |
| `USER root` in final stage | Security risk | `USER appuser` |
| `COPY .env` | Secrets in image | Use env vars at runtime |
| `COPY . .` | Too broad | Copy specific directories |
| `--privileged` | Security risk | Never use |
| Alpine for Python | musl libc issues | Use slim |

## Frontend Container (nginx)

```dockerfile
FROM node:20-alpine AS builder
WORKDIR /app
COPY package*.json ./
RUN npm ci
COPY . .
RUN npm run build

FROM nginx:1.25-alpine-slim
COPY --from=builder /app/dist /usr/share/nginx/html
COPY nginx.conf /etc/nginx/conf.d/default.conf
EXPOSE 80
HEALTHCHECK --interval=30s --timeout=5s \
    CMD curl -f http://localhost:80/ || exit 1
```

## Alignment with Helm

Container security context MUST match Helm values.yaml:
- `runAsUser: 1000` matches `useradd -u 1000`
- `readOnlyRootFilesystem: true` requires writable `/tmp` volume
- `capabilities.drop: [ALL]` matches minimal container

## Scanning

- **Build time**: `trivy image --severity HIGH,CRITICAL`
- **CI**: Scan on every PR and release
- **Registry**: Enable automatic scanning if available
