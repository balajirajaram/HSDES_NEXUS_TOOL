# Helm Standards (Enterprise-Inference Pattern)

## values.yaml Structure (200+ params)

### Application
```yaml
app:
  replicas: 1
  image:
    registry: ""
    repository: {component}
    tag: "latest"
    digest: ""
    pullPolicy: IfNotPresent
  resources:
    requests: { cpu: "100m", memory: "256Mi" }
    limits: { cpu: "1000m", memory: "1Gi" }
  terminationGracePeriodSeconds: 30
```

### Ingress
- Support both NGINX and APISIX ingress classes
- TLS configuration with secret reference
- Host-based routing

### Autoscaling (HPA)
```yaml
autoscaling:
  enabled: false
  minReplicas: 1
  maxReplicas: 10
  targetCPUUtilizationPercentage: 80
  behavior:
    scaleDown:
      stabilizationWindowSeconds: 300
      policies:
        - type: Percent
          value: 10
          periodSeconds: 60
```

### Pod Disruption Budget
```yaml
pdb:
  enabled: true
  minAvailable: 1
```

### Network Policy (Zero-Trust)
```yaml
networkPolicy:
  enabled: true
  ingress:
    - from:
        - namespaceSelector:
            matchLabels:
              kubernetes.io/metadata.name: {namespace}
  egress:
    - ports: [{protocol: UDP, port: 53}, {protocol: TCP, port: 53}]  # DNS
    - ports: [{protocol: TCP, port: 5432}]   # PostgreSQL
    - ports: [{protocol: TCP, port: 6379}]   # Redis
    - ports: [{protocol: TCP, port: 443}]    # HTTPS
```

### Security Context
```yaml
podSecurityContext:
  runAsNonRoot: true
  runAsUser: 1000
  runAsGroup: 1000
  fsGroup: 1000
containerSecurityContext:
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false
  capabilities:
    drop: [ALL]
```

### Probes
```yaml
probes:
  startup:
    httpGet: { path: /startup, port: http }
    failureThreshold: 30
    periodSeconds: 10
  liveness:
    httpGet: { path: /healthz, port: http }
    periodSeconds: 30
    timeoutSeconds: 5
  readiness:
    httpGet: { path: /readyz, port: http }
    periodSeconds: 10
    timeoutSeconds: 3
```

## deployment.yaml Requirements
- Rolling update: `maxSurge: 1, maxUnavailable: 0`
- Checksum annotations for ConfigMap + Secret (auto-restart on change)
- Init containers (e.g., wait-for-postgresql)
- All 3 probes, security context, resource limits
- Volume mounts for emptyDir /tmp (read-only root fs needs writable /tmp)

## Chart.yaml
- `apiVersion: v2`
- Proper SemVer versioning
- Maintainers with name and email
- Keywords and description

## Testing
- `helm lint` must pass
- `helm template` must render valid YAML
- `tests/test-connection.yaml` for smoke test
