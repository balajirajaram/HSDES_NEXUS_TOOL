# Observability Standards (Enterprise-Inference Pattern)

## 5 Pillars

### 1. Structured Logging (structlog)

```python
import structlog

def configure_logging(environment: str):
    processors = [
        structlog.contextvars.merge_contextvars,
        structlog.processors.add_log_level,
        structlog.processors.TimeStamper(fmt="iso"),
        add_correlation_id,  # Custom: bind from X-Correlation-ID
    ]
    if environment == "production":
        processors.append(structlog.processors.JSONRenderer())
    else:
        processors.append(structlog.dev.ConsoleRenderer())

    structlog.configure(processors=processors)
```

- JSON in production, Console in development
- Always bind `correlation_id` from request header
- Never log secrets, tokens, or PII
- Log levels: DEBUG (dev only), INFO (request/response), WARNING (recoverable), ERROR (failures)

### 2. Prometheus Metrics

```python
from prometheus_client import Counter, Histogram, Gauge

REQUEST_COUNT = Counter(
    "http_requests_total",
    "Total HTTP requests",
    ["method", "endpoint", "status", "user"],
)
REQUEST_DURATION = Histogram(
    "http_request_duration_seconds",
    "Request duration",
    ["method", "endpoint"],
    buckets=[0.01, 0.05, 0.1, 0.25, 0.5, 1.0, 2.5, 5.0, 10.0],
)
ACTIVE_REQUESTS = Gauge(
    "http_active_requests",
    "Currently active requests",
)
```

- Per-user metrics extracted from JWT (for billing/audit)
- Endpoint normalization (strip path params: `/items/123` → `/items/{id}`)
- System metrics via psutil (CPU, memory, disk)
- Expose at `/metrics` endpoint

### 3. Distributed Tracing (OpenTelemetry)

```python
from opentelemetry import trace
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.exporter.otlp.proto.grpc.trace_exporter import OTLPSpanExporter

def configure_tracing(service_name: str, endpoint: str):
    provider = TracerProvider(resource=Resource.create({"service.name": service_name}))
    provider.add_span_processor(BatchSpanProcessor(OTLPSpanExporter(endpoint=endpoint)))
    trace.set_tracer_provider(provider)
```

- Auto-instrumentation: FastAPI, SQLAlchemy, Redis, httpx
- Correlate traces with logs via `trace_id` and `span_id`
- Export to OTEL collector (gRPC, port 4317)

### 4. Health Endpoints

| Endpoint | Probe | Purpose |
|----------|-------|---------|
| `/healthz` | Liveness | Is the process alive? (always 200 if running) |
| `/readyz` | Readiness | Can it serve traffic? (check DB, cache) |
| `/startup` | Startup | Has it finished initializing? |
| `/metrics` | Prometheus | Scraped by Prometheus ServiceMonitor |

### 5. LLM Observability (Langfuse)

- Token usage per request/user
- Latency per model call
- Cost tracking per model provider
- Prompt/completion logging (redacted for PII)
- Evaluation scores

## Middleware Stack (LIFO Order)

Add middlewares in this order (last added = first executed):

1. `CORSMiddleware` — CORS headers
2. `SecurityHeadersMiddleware` — X-Frame-Options, HSTS, CSP
3. `RequestLoggingMiddleware` — Log request/response with structlog
4. `CorrelationIDMiddleware` — Extract/generate X-Correlation-ID
5. `MetricsMiddleware` — Prometheus counters and histograms

## Correlation ID Flow

```
Client → X-Correlation-ID header (or auto-generate UUID)
  → CorrelationIDMiddleware binds to structlog context
  → All log entries include correlation_id
  → All error responses include correlation_id
  → Response header X-Correlation-ID returned to client
```
