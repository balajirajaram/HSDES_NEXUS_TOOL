# Open Source Compliance

## CNCF Required Files (Enterprise-RAG Pattern)

| File | Content | Template |
|------|---------|----------|
| `LICENSE` | Apache-2.0 full text | Static |
| `CODE_OF_CONDUCT.md` | Contributor Covenant v2.1 | Static |
| `CONTRIBUTING.md` | DCO sign-off required, PR guidelines | Templated |
| `SECURITY.md` | Vulnerability reporting process | Templated |
| `THIRD-PARTY-PROGRAMS` | Third-party license inventory | Templated |

## Intel License Header

Every source file MUST include:
```
# Copyright (C) {year} Intel Corporation
# SPDX-License-Identifier: Apache-2.0
```

Enforced via:
- Pre-commit hook: `Lucas-C/insert-license` (auto-insert)
- PostToolUse hook: `license-header-check.py` (warn on missing)

### File types requiring headers
`.py`, `.sh`, `.ts`, `.tsx`, `.js`, `.jsx`, `.yml`, `.yaml`, `Dockerfile`, `.html`

### Exemptions
`__init__.py`, `py.typed`, `.env`, `requirements.txt`, `package-lock.json`, generated files

## License Compatibility Matrix

| License | Use in Product | Distribute Source | Notes |
|---------|---------------|-------------------|-------|
| MIT | YES | YES | Most permissive |
| BSD-2-Clause | YES | YES | Permissive |
| BSD-3-Clause | YES | YES | Permissive |
| Apache-2.0 | YES | YES | Our license |
| ISC | YES | YES | Permissive |
| MPL-2.0 | REVIEW | YES | Weak copyleft, file-level |
| LGPL-2.1/3.0 | REVIEW | YES | Dynamic linking OK |
| EPL-2.0 | REVIEW | YES | Weak copyleft |
| GPL-2.0/3.0 | BLOCKED | - | Strong copyleft |
| AGPL-3.0 | BLOCKED | - | Network copyleft |
| SSPL | BLOCKED | - | Server copyleft |
| Unlicense | YES | YES | Public domain |

## OSPDT Process (Intel Open Source Product Distribution Team)

1. Generate license inventory: `pip-licenses --format json`
2. Review for GPL/AGPL/SSPL (blocked licenses)
3. Generate OSPDT PowerPoint deck
4. Submit to OSPDT for approval
5. Receive clearance before any public distribution

## OpenSSF Scorecard (Target: 8+/10)

| Check | Weight | How to Pass |
|-------|--------|-------------|
| Branch-Protection | High | 2+ reviewers, dismiss stale, require CI |
| Code-Review | High | All PRs reviewed before merge |
| CI-Tests | High | Tests run on every PR |
| SAST | High | Bandit + CodeQL enabled |
| Dependency-Update-Tool | Medium | Dependabot configured |
| Signed-Releases | Medium | cosign on container images |
| Security-Policy | Medium | SECURITY.md present |
| License | Low | LICENSE file present |
| Binary-Artifacts | Low | No binaries in source |
| Pinned-Dependencies | Low | Lock files committed |

## SLSA Levels

| Level | Requirement | Our Implementation |
|-------|-------------|-------------------|
| 1 | Scripted build | GitHub Actions workflows |
| 2 | + Hosted build service | GitHub-hosted runners |
| 2 | + Build provenance | Generated in release.yml |
| 3 | + Isolated build | SLSA GitHub generator |

## SBOM

- Format: CycloneDX (JSON)
- Generated: On every release via Trivy
- Attached: To GitHub Release as artifact
- Content: All direct and transitive dependencies
