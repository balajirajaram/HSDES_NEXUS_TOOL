# Performance Optimization — Intel AI Stack

## Intel Extension for PyTorch (IPEX)
- Enable with `import intel_extension_for_pytorch as ipex`
- Auto-optimize: `model = ipex.optimize(model, dtype=torch.bfloat16)`
- Leverage AMX (Advanced Matrix Extensions) on 4th/5th Gen Xeon
- Use VNNI for INT8 inference on Ice Lake+

## OpenVINO
- Convert models: `mo --input_model model.onnx --output_dir ir/`
- INT8 quantization: NNCF post-training quantization
- Async inference pipeline for throughput
- Model caching: `core.set_property({"CACHE_DIR": ".cache/openvino"})`
- Use OpenVINO Model Server (OVMS) for serving

## vLLM (LLM Serving)
- PagedAttention for efficient KV cache
- Continuous batching for throughput
- Tensor parallelism across GPUs
- INT8/AWQ quantization support

## LiteLLM (LLM Routing)
- Route across multiple LLM providers
- Fallback chains for reliability
- Token budget tracking per user/project
- Rate limiting per model endpoint

## General Optimizations
- **Async I/O**: All database, HTTP, and cache operations async
- **Connection pooling**: SQLAlchemy pool_size=20, max_overflow=10
- **Caching**: Redis for frequently accessed data (TTL-based)
- **Batch processing**: Accumulate requests for batch inference
- **Dynamic batching**: Combine concurrent requests into single model call

## Hardware Targets
- **Intel Xeon Scalable**: 4th Gen (Sapphire Rapids) or 5th Gen (Emerald Rapids)
- **AMX support**: BF16/INT8 matrix operations (4th Gen+)
- **VNNI**: INT8 vector neural network instructions (Ice Lake+)
- **Intel GPU**: Max Series (Ponte Vecchio) for GPU inference
- **Memory**: DDR5 with balanced NUMA configuration

## Benchmarking
- Use `pytest-benchmark` for micro-benchmarks
- Use Locust for load testing
- Track: p50, p95, p99 latency, throughput (req/s)
- Compare: baseline vs. IPEX-optimized vs. OpenVINO-optimized
