# Project Structure Standard

## Microservice Component Layout (Enterprise-RAG Pattern)

Every project follows the `src/{component}/` pattern where each component is an
independently deployable microservice.

```
{project-name}/
├── src/                          # All backend components
│   └── {component}/              # One per PRD component
│       ├── app/
│       │   ├── __init__.py
│       │   ├── py.typed
│       │   ├── main.py           # FastAPI factory + lifespan
│       │   ├── config.py         # Nested pydantic-settings
│       │   ├── api/
│       │   │   ├── deps.py       # Dependency injection
│       │   │   └── v1/
│       │   │       ├── router.py
│       │   │       └── endpoints/
│       │   ├── core/
│       │   │   ├── middleware.py
│       │   │   ├── security.py
│       │   │   └── exceptions.py
│       │   ├── models/
│       │   │   ├── schemas.py    # Pydantic v2
│       │   │   └── db.py         # SQLAlchemy 2.0
│       │   ├── services/         # Business logic
│       │   ├── observability/
│       │   │   ├── telemetry.py
│       │   │   ├── logging.py
│       │   │   └── health.py
│       │   └── db/
│       │       └── session.py
│       ├── tests/
│       │   ├── conftest.py
│       │   ├── unit/
│       │   └── integration/
│       ├── Dockerfile
│       ├── requirements.txt
│       ├── pyproject.toml
│       ├── tox.ini
│       └── alembic.ini
│
├── frontend/                     # React SPA (if applicable)
│   ├── src/
│   │   ├── app/                  # Providers, router
│   │   ├── features/             # Feature-based folders
│   │   └── components/           # Shared components
│   ├── Dockerfile
│   └── package.json
│
├── helm/{project}/               # Kubernetes deployment
├── docker/                       # Docker Compose
├── ansible/                      # Infrastructure automation
├── .github/workflows/            # CI/CD
├── docs/                         # Documentation
├── scripts/                      # Automation scripts
└── (root config files)           # Makefile, README, LICENSE, etc.
```

## Naming Conventions
- **Components**: snake_case (e.g., `api_gateway`, `data_processor`)
- **Python files**: snake_case
- **React components**: PascalCase files in components/, camelCase in hooks/
- **Feature slugs**: kebab-case (e.g., `user-management`)
- **Docker images**: kebab-case
- **Helm releases**: kebab-case

## Rules
- One component = one Dockerfile = one deployable unit
- Each component has its own tests, tox.ini, and requirements.txt
- Shared code goes in a `shared/` component (pip-installable)
- Frontend is optional — driven by PRD
- AI components (agents, inference) are subdirectories within a backend component
