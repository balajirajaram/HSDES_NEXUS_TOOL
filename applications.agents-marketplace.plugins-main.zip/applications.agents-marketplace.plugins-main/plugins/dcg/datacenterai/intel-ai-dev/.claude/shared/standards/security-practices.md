# Security Practices

## Authentication & Authorization
- **Auth provider**: Keycloak (OIDC/JWT)
- **JWT validation**: Verify signature via JWKS endpoint, check expiry and issuer
- **RBAC**: Role-based access on all endpoints
- **API keys**: Only for service-to-service, never for user auth
- **Session tokens**: Short-lived (15min access, 8hr refresh), rotate on use

## Input Validation
- All user input validated via Pydantic v2 models
- Parameterized queries only (SQLAlchemy ORM) — never raw SQL with string formatting
- Request size limits enforced
- File upload: validate MIME type, size, and extension

## Container Security
- Multi-stage Docker builds (builder → runtime)
- Base image: `python:3.11-slim` (not full, not alpine for Python)
- Non-root user: `appuser` with uid=1000
- Read-only root filesystem
- Drop ALL Linux capabilities
- No privileged containers
- HEALTHCHECK in every Dockerfile
- Image scanning with Trivy in CI

## Supply Chain Security
- **SLSA Level 2+**: Scripted builds, build provenance, signed containers
- **Container signing**: cosign/sigstore on every release image
- **SBOM**: CycloneDX format, attached to every release
- **Dependency pinning**: Lock files committed, Dependabot enabled
- **No binary artifacts** in source repo

## Network Security
- TLS 1.3 minimum for all external communication
- Zero-trust NetworkPolicy in Kubernetes (deny-all default)
- Port-specific egress (DNS:53, PostgreSQL:5432, Redis:6379, HTTPS:443)
- CORS restricted to known origins
- Rate limiting via slowapi

## Security Headers
- `X-Content-Type-Options: nosniff`
- `X-Frame-Options: DENY`
- `Strict-Transport-Security: max-age=31536000; includeSubDomains`
- `X-XSS-Protection: 0` (rely on CSP instead)
- `Content-Security-Policy: default-src 'self'`

## Secrets Management
- No secrets in code — use environment variables
- `.env` files in `.gitignore`
- detect-secrets in pre-commit
- Kubernetes Secrets (encrypted etcd)
- Never log secrets or tokens

## Compliance
- Intel Apache-2.0 license header on all source files
- OSPDT clearance before open source distribution
- SDLE threat model and data flow diagrams required
- GDPR/SOC2/HIPAA compliance as specified by project
