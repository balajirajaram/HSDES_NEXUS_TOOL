# Approved Technology Stack

## Backend
| Category | Approved | Version | Notes |
|----------|----------|---------|-------|
| Language | Python | 3.11+ | Type hints required |
| Framework | FastAPI | 0.110+ | Async, Pydantic v2 |
| ORM | SQLAlchemy | 2.0+ | Async with asyncpg |
| Validation | Pydantic | 2.0+ | BaseSettings for config |
| Auth | PyJWT | 2.8+ | Keycloak JWKS |
| HTTP Client | httpx | 0.27+ | Async native |
| Task Queue | Celery | 5.3+ | If async tasks needed |
| Logging | structlog | 24.1+ | JSON in prod |
| Metrics | prometheus-client | 0.20+ | Counters, Histograms |
| Tracing | opentelemetry | 1.24+ | Auto-instrumentation |
| Rate Limiting | slowapi | 0.1+ | Per-endpoint |
| Build | Hatchling | 1.21+ | PEP 621 |
| Testing | pytest + tox | 8.0+ / 4.0+ | Per-component |
| Linting | ruff + mypy | 0.3+ / 1.9+ | Strict mode |
| Migration | Alembic | 1.13+ | Async support |

## Frontend
| Category | Approved | Version | Notes |
|----------|----------|---------|-------|
| Language | TypeScript | 5.4+ | strict: true |
| Framework | React | 18+ | Functional components |
| Build | Vite | 5.0+ | Fast dev server |
| State (global) | Zustand | 4.5+ | Minimal boilerplate |
| State (server) | TanStack Query | 5.0+ | Caching, refetch |
| Forms | React Hook Form | 7.51+ | Validation |
| Router | React Router | 6.22+ | Nested routes |
| Testing | Vitest + Testing Library | 1.4+ | jsdom |
| UI Components | shadcn/ui | latest | Tailwind-based |

## Infrastructure
| Category | Approved | Version | Notes |
|----------|----------|---------|-------|
| Container | Docker | 24+ | Multi-stage builds |
| Orchestration | Kubernetes | 1.28+ | Helm 3 charts |
| Registry | Docker Hub / GHCR | - | Signed images |
| CI/CD | GitHub Actions | - | Super-Linter, SDLE |
| IaC | Ansible | 2.16+ | 3-tier roles |
| Scanning | Trivy | 0.50+ | FS + container |
| SAST | Bandit | 1.7+ | Python SAST |
| Signing | cosign | 2.2+ | Sigstore |
| SBOM | CycloneDX | - | Via Trivy |

## AI/ML
| Category | Approved | Version | Notes |
|----------|----------|---------|-------|
| Inference | OpenVINO | 2024.0+ | INT8, async |
| PyTorch Ext | IPEX | 2.3+ | AMX, BF16 |
| LLM Serving | vLLM | 0.4+ | PagedAttention |
| LLM Routing | LiteLLM | 1.30+ | Multi-provider |
| Agents | LangGraph | 0.1+ | StateGraph |
| Observability | Langfuse | 2.0+ | LLM metrics |
| Vector DB | pgvector / Qdrant | - | Per project |

## Prohibited
| Library | Reason | Use Instead |
|---------|--------|-------------|
| Flask | No async, no Pydantic native | FastAPI |
| Django | Monolithic, sync ORM | FastAPI + SQLAlchemy |
| requests | Sync only | httpx |
| python-jose | Maintenance concerns | PyJWT |
| marshmallow | Not FastAPI native | Pydantic v2 |
| unittest | Less featured | pytest |
