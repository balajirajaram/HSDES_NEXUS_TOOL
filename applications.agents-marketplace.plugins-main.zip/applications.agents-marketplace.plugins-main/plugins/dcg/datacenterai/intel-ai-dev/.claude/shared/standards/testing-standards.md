# Testing Standards

## Coverage Requirements
- **Minimum**: 85% line coverage per component
- **Target**: 90%+ for critical business logic
- CI fails if coverage drops below threshold

## Test Structure (per component)
```
src/{component}/tests/
  conftest.py           # Shared fixtures
  unit/                 # Pure logic, mocked dependencies
  integration/          # API tests with TestClient, real app instance
  e2e/                  # Full user story scenarios (optional)
  performance/          # Benchmarks (optional)
  security/             # Injection, auth bypass tests
```

## Test Runner
- **Framework**: pytest with anyio for async
- **Per-component**: Each component has its own `tox.ini`
- **CI trigger**: Path-filtered (only run tests for changed components)
- **Continuation**: `if: success() || failure()` in CI to run all components

## Unit Tests
- Test pure business logic
- Mock external dependencies (DB, HTTP, cache)
- Use `@pytest.mark.parametrize` for input variations
- Test error paths, not just happy paths

## Integration Tests
- Use `httpx.AsyncClient` with `ASGITransport` for FastAPI testing
- Test full request/response cycle including middleware
- Test auth flows (valid token, expired token, no token, wrong role)
- Test pagination, filtering, sorting on list endpoints

## Fixtures (conftest.py)
```python
@pytest.fixture
def app():
    return create_app()

@pytest.fixture
async def async_client(app):
    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as c:
        yield c

@pytest.fixture
def mock_user():
    return {"sub": "test-user", "email": "test@intel.com", "roles": ["user"]}
```

## Security Tests
- SQL injection payloads on all text inputs
- XSS payloads in string fields
- Path traversal in file-related endpoints
- Auth bypass attempts (missing token, forged token, expired token)
- Rate limiting verification

## Frontend Tests
- Vitest + Testing Library
- Test component rendering and user interactions
- Mock API calls with MSW (Mock Service Worker)
- Snapshot tests for stable UI components

## Pre-commit Test Gate
- `tox` runs on every component before push
- Linters must pass (ruff, mypy)
- No test files without assertions
