# UX Design System

## Architecture: Bulletproof React

Feature-based folder structure (not type-based):

```
frontend/src/
  app/                    # App-level: providers, router, global config
  features/               # Feature modules (self-contained)
    {feature}/
      api/                # TanStack Query hooks
      components/         # Feature-specific components
      hooks/              # Custom hooks
      stores/             # Zustand stores
      types/              # TypeScript interfaces
      index.ts            # Public API (barrel export)
  components/             # Shared components (shadcn/ui)
  lib/                    # Utility functions
  styles/                 # Global styles, Tailwind config
```

## Component Library: shadcn/ui
- Tailwind CSS-based
- Copy-paste components (not npm dependency)
- Intel brand customization via CSS variables
- Accessible (ARIA compliance)

## Intel Brand
- Primary blue: #003580
- Secondary: #00C7FD
- Font: Intel Clear (fallback: system sans-serif)
- Dark mode support

## State Management
- **Global state**: Zustand (minimal stores, no boilerplate)
- **Server state**: TanStack Query (caching, pagination, optimistic updates)
- **Form state**: React Hook Form (validation, performance)
- **URL state**: React Router search params

## API Integration
- TanStack Query for all server state
- Typed API client generated from OpenAPI spec
- Optimistic updates for mutations
- Error boundaries for resilience

## TypeScript
- `strict: true` — no exceptions
- No `any` — use `unknown` with type guards
- Prefer interfaces for object shapes
- Use discriminated unions for state machines

## Testing
- Vitest for unit tests
- Testing Library for component tests
- MSW for API mocking
- Test behavior, not implementation

## Accessibility
- ARIA labels on interactive elements
- Keyboard navigation support
- Color contrast: WCAG 2.1 AA minimum
- Screen reader tested

## Frontend-Design Plugin Override

When the `frontend-design` plugin is active, apply creativity WITHIN the Intel brand system:

- **Colors**: Primary #003580 and accent #00C7FD are non-negotiable. Creativity comes from
  gradients, opacity layers, and complementary neutrals — not overriding brand colors.
- **Typography**: Intel Clear is the required font. Distinctive character comes from weight
  contrast, size hierarchy, and letter-spacing — not alternative font families.
- **Layout & Motion**: This is where bold design choices belong. Asymmetric layouts,
  staggered animations, scroll-triggered reveals, and unexpected spatial composition
  are encouraged — these differentiate without breaking brand.
- **Backgrounds & Texture**: Gradient meshes using brand palette, subtle noise/grain,
  geometric patterns from Intel's design language — all acceptable creative territory.
- **Component Style**: shadcn/ui base with Intel brand CSS variables. Enhance with
  distinctive hover states, transitions, and micro-interactions.

The plugin's instruction to "avoid generic" applies to LAYOUT and MOTION choices,
not to overriding Intel's brand identity (colors, fonts, logos).
