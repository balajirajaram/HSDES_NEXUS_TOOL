# Validation Checklist

## Code Quality
- [ ] All Python files pass `ruff check`
- [ ] All Python files pass `mypy --strict`
- [ ] All TypeScript files pass `tsc --noEmit`
- [ ] No TODO/FIXME/HACK in production code
- [ ] Intel Apache-2.0 header on all source files

## Testing
- [ ] Unit test coverage >= 85%
- [ ] Integration tests for all API endpoints
- [ ] Auth flow tests (valid, expired, missing, wrong role)
- [ ] Error path tests (400, 401, 403, 404, 500)
- [ ] Input validation tests (SQL injection, XSS, path traversal)
- [ ] Frontend component tests for all features

## Security
- [ ] No hardcoded secrets (`detect-secrets scan` clean)
- [ ] Bandit scan: 0 HIGH findings
- [ ] Trivy FS scan: 0 CRITICAL findings
- [ ] Container image scan: 0 CRITICAL findings
- [ ] Dependencies: 0 HIGH/CRITICAL CVEs
- [ ] ShellCheck: 0 errors on all .sh files

## Container
- [ ] Multi-stage Dockerfile (builder → runtime)
- [ ] Non-root user (uid=1000)
- [ ] HEALTHCHECK defined
- [ ] No secrets in image layers
- [ ] Base image: python:3.11-slim (not latest, not full)

## Kubernetes / Helm
- [ ] `helm lint` passes
- [ ] `helm template` renders without errors
- [ ] 3 probes defined (startup, liveness, readiness)
- [ ] Resource requests AND limits set
- [ ] NetworkPolicy: zero-trust (deny-all default)
- [ ] PDB: minAvailable >= 1
- [ ] SecurityContext: runAsNonRoot, readOnlyRootFilesystem, drop ALL
- [ ] ServiceMonitor for Prometheus

## CNCF Compliance
- [ ] LICENSE file (Apache-2.0)
- [ ] CODE_OF_CONDUCT.md
- [ ] CONTRIBUTING.md (DCO requirement)
- [ ] SECURITY.md (vulnerability reporting)
- [ ] THIRD-PARTY-PROGRAMS

## OpenSSF Scorecard (target: 8+/10)
- [ ] Branch protection enabled
- [ ] Code review required (2+ reviewers)
- [ ] CI tests on every PR
- [ ] SAST enabled (Bandit + CodeQL)
- [ ] Dependency updates automated (Dependabot)
- [ ] Signed releases
- [ ] Security policy present
- [ ] No binary artifacts in source

## SLSA Level 2+
- [ ] Scripted builds (GitHub Actions)
- [ ] Hosted CI (not self-hosted runners)
- [ ] Build provenance generated
- [ ] Container images signed (cosign)
- [ ] SBOM attached to releases (CycloneDX)

## 12-Factor App
- [ ] Config via environment variables
- [ ] Stateless processes
- [ ] Port binding (uvicorn)
- [ ] Graceful shutdown (SIGTERM handling)
- [ ] Dev/prod parity (same Dockerfile)
- [ ] Logs to stdout (structured JSON)

## Intel Compliance
- [ ] OSPDT deck generated and reviewed
- [ ] SDLE diagrams (threat model, data flow)
- [ ] License compatibility verified (no GPL/AGPL in production)
- [ ] SBOM generated
