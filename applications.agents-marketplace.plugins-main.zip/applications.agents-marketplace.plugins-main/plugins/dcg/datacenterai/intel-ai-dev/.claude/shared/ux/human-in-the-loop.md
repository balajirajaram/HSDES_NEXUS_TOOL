# Human-in-the-Loop UX Patterns

ALL skills in the Intel AI Solutions Development Pipeline MUST follow these patterns
for every prompt to the developer. Consistent UX across all 4 agents builds trust
and reduces cognitive load.

---

## Decision Prompt Format

Every time an agent needs developer input, use this structure:

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📋 CONTEXT: What just happened
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
• [Bullet list of what was accomplished]
• [Any issues found]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🎯 NEXT STEP: [What the agent wants to do]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
[Clear explanation of what will be created/changed]
[Expected output location]
[Time estimate if applicable]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🔀 YOUR OPTIONS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
1. [Proceed with recommended action]
2. [Alternative action]
3. [Skip / do later]
4. [Customize — provide different input]
```

---

## Rules for Decision Prompts

1. **Always give context first** — the developer needs to know what state they're in
2. **Always explain the output** — where files will be created/modified
3. **Always offer Skip** — never force an action the developer can defer
4. **Always offer Customize** — let them override defaults
5. **Number the options** — so they can just type "1" or "3"
6. **Recommend one option** — mark it clearly (put it as option 1)
7. **Never ask bare yes/no** — always provide context and alternatives

---

## Anti-Patterns (DO NOT DO)

Bad:
```
Publish to Wiki? yes/no
```

Bad:
```
Push to GitHub? (y/n)
```

Bad:
```
Would you like to continue?
```

These lack context, don't explain consequences, and don't offer alternatives.

---

## Iteration Summary Format

After each agent phase completes, show this summary. This is the PRIMARY feedback
mechanism that tells developers what's done and what needs attention.

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
✅ ITERATION {N} COMPLETE — {Phase Name}
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

COVERED:
• [What was tested/validated/generated locally]
• [What passed]
• [Key metrics]

SKIPPED (needs config/infra):
• [What was skipped] — [Why] — [What tool/service is needed]
• [What was skipped] — [Why] — [What tool/service is needed]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📊 REPORTS GENERATED
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
• DASHBOARD: reports/DASHBOARD.md
• [Report name]: [path]
• [Report name]: [path]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
⏭️ FOR ITERATION {N+1}
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
1. Install: [specific tools needed]
2. Configure: [specific configs needed]
3. Deploy: [specific services to start]
4. Then run: [specific command to continue]
```

---

## Phase Transition Format

When one agent completes and the next should run, show:

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🔗 HANDOFF: {current phase} → {next phase}
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
{Current phase} is complete.
Artifacts ready for {next phase}:
• [List of files/reports created]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🔀 YOUR OPTIONS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
1. Run /{next-agent} now
2. Review generated output first
3. Stop here — I'll continue later
```

---

## Progress Indicator Format

For long-running operations, show progress:

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
⏳ IN PROGRESS: {operation}
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
[■■■■■■□□□□] 6/10 files generated
Current: src/detector/app/api/v1/endpoints/detections.py
```

---

## Error Recovery Format

When something fails:

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
⚠️ ISSUE: {what failed}
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
What happened: [explanation]
Impact: [what this means for the output]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🔀 YOUR OPTIONS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
1. Retry with [adjusted approach]
2. Skip this step (mark as skipped in iteration state)
3. Fix manually and resume
```

---

## Phase Announce/Summary Pattern (MANDATORY)

Every phase in every agent MUST follow this pattern:

**BEFORE starting a phase** (after receiving developer input):
```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
▶ STARTING: {Phase Name}
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Based on your input, here's what I'm going to do:
• {Action 1 — specific, not vague}
• {Action 2}
• {Action 3}

Expected output: {what files/changes will be produced}
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

Wait for developer confirmation ("proceed" / adjust). Only skip the wait if
the action is trivially reversible (e.g., reading files).

**AFTER completing a phase:**
```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
✅ COMPLETED: {Phase Name}
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
What was done:
• {Concrete result 1 — file created, test passed, etc.}
• {Concrete result 2}
• {Concrete result 3}

{If issues found:}
Issues to review:
• {Issue 1 — what happened, impact}
• {Issue 2}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🔀 YOUR OPTIONS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
1. Proceed to next phase
2. Iterate on this phase (fix issues, re-run, change approach)
3. Review output before continuing
```

**Why this matters:** The developer can catch discrepancies BEFORE work compounds.
If Phase 2 produces wrong output and Phase 3 builds on it, you waste both phases.
The announce/summary gates catch drift early.

**Rules:**
- NEVER silently start a phase — always announce what you'll do
- NEVER silently finish a phase — always summarize what was achieved
- If the phase produced different results than announced, explain why
- If the developer says "iterate" or "change", re-announce the adjusted plan before re-executing
- Keep announcements brief (3-5 bullets). Keep summaries concrete (what files, what numbers).

---

## Key Principles

1. **Developers are busy** — get to the point, but give enough context
2. **Options, not dead ends** — always provide a way forward
3. **Show the path** — developers want to see where they are in the pipeline
4. **Separate done from pending** — iteration tracking makes this explicit
5. **Consistent formatting** — same visual structure across all 4 agents
6. **Actionable next steps** — never just say "something failed", say what to do
7. **Announce before, summarize after** — every phase has both gates (no silent work)
