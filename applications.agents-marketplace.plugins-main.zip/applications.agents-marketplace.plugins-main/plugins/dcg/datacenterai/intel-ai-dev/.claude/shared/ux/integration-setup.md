# Integration Setup — Credentials & Remote Configuration

Every pipeline session that starts fresh (no prior `.iteration-state.json`) MUST run
this setup before Phase 1. It collects credentials for GitHub, Wiki, and Jira, and
determines whether the solution operates in **connected** or **local-only** mode.

This setup runs ONCE per solution creation. Answers are stored in `.iteration-state.json`
under `integrations` and reused across all 4 agent phases.

---

## When to Trigger

- **PRD Agent**: Always (first agent in pipeline, always starts fresh)
- **Dev Agent**: Only if `.iteration-state.json` does NOT have `integrations` block
- **Validation/Compliance Agents**: Never re-ask — read from `.iteration-state.json`

If user invokes Dev Agent directly (skipping PRD), it runs the setup.

---

## Setup Prompt

Present using the standard decision format:

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🔧 INTEGRATION SETUP (one-time per solution)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Before we begin, I need to know how you want to manage code,
documentation, and tracking for this solution.

┌─────────────────────────────────────────────────────────┐
│ 1️⃣  GIT — Where will the code live?                     │
├─────────────────────────────────────────────────────────┤
│ Options:                                                │
│   G1. Intel GitHub (I'll provide the repo URL)          │
│   G2. Other remote (I'll provide the URL)               │
│   G3. Local only — no remote push                       │
│       (git init locally, commit at each phase)          │
│                                                         │
│ If G1/G2: Provide the remote URL                        │
│   e.g., https://github.com/intel-sandbox/my-project.git │
└─────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────┐
│ 2️⃣  WIKI — Confluence publishing                        │
├─────────────────────────────────────────────────────────┤
│ Options:                                                │
│   W1. I have a Confluence PAT (I'll provide it)         │
│   W2. Skip Wiki — I don't have credentials              │
│       (Reports saved locally, publish later)            │
│                                                         │
│ If W1: Provide your Confluence PAT                      │
│   Base URL: https://wiki.ith.intel.com                  │
│   Space: datacenterai                                   │
│   (Will be used to publish PRD, reports, DASHBOARD)     │
└─────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────┐
│ 3️⃣  JIRA — Ticket creation & updates                    │
├─────────────────────────────────────────────────────────┤
│ Options:                                                │
│   J1. I have a Jira PAT (I'll provide it)               │
│   J2. Skip Jira — I don't have credentials              │
│       (EPICs/Stories exported to local markdown only)    │
│                                                         │
│ If J1: Provide your Jira PAT                            │
│   (Will be used to create EPICs, Stories, updates)      │
└─────────────────────────────────────────────────────────┘

Type your choices (e.g., "G1 W2 J2" or provide details inline):
```

---

## Handling Responses

### Git Responses

**G1/G2 (Remote provided):**
- Store URL in `.iteration-state.json` → `integrations.git.remote_url`
- Store mode as `"remote"` → `integrations.git.mode`
- At checkpoint time: `git push origin {branch}`
- Validate URL format before storing

**G3 (Local only):**
- Store mode as `"local"` → `integrations.git.mode`
- At output directory creation, run `git init` if not already a git repo
- At checkpoint time: commit locally only (no push)
- At EVERY checkpoint, remind user:
  ```
  ⚠️  Code committed locally only (no remote configured).
  To push later: git remote add origin <url> && git push -u origin main
  ```

### Wiki Responses

**W1 (Token provided):**
- Store token in memory for this session (do NOT write to file)
- Set `integrations.wiki.configured` = `true` in `.iteration-state.json`
- Use token with `scripts/publish-to-wiki.py`

**W2 (Skip):**
- Set `integrations.wiki.configured` = `false` in `.iteration-state.json`
- At checkpoint time, Wiki option shows: `"SKIPPED — no credentials"`
- Remind at phase completion that reports are local-only

### Jira Responses

**J1 (Token provided):**
- Store token in memory for this session (do NOT write to file)
- Set `integrations.jira.configured` = `true` in `.iteration-state.json`
- Use token with `scripts/export-to-jira.py`

**J2 (Skip):**
- Set `integrations.jira.configured` = `false` in `.iteration-state.json`
- EPICs/Stories written to `docs/prd/{slug}-breakdown.md` (markdown export)
- At checkpoint time, Jira option shows: `"SKIPPED — no credentials"`

---

## Iteration State Schema Addition

```json
{
  "integrations": {
    "git": {
      "mode": "remote",
      "remote_url": "https://github.com/intel-sandbox/my-project.git",
      "branch": "main"
    },
    "wiki": {
      "configured": true,
      "space": "datacenterai"
    },
    "jira": {
      "configured": true,
      "project": "DCAIDSE8"
    }
  }
}
```

---

## Security Rules

1. **NEVER write tokens to files** — store in env vars or session memory only
2. **NEVER commit `.env` files** containing tokens
3. **If user pastes a token**, acknowledge receipt but do NOT echo it back
4. **Token validation**: If a token is provided, attempt a lightweight API call
   to verify it works before proceeding (e.g., GET wiki space, GET jira project)

---

## Checkpoint Behavior Based on Integration Mode

### Connected Mode (G1/G2 + W1 + J1)
All 3 checkpoints fully functional. Publish, update, push.

### Partial Mode (some skipped)
- Show all 3 checkpoints but mark unconfigured ones as unavailable:
  ```
  │ 1️⃣  WIKI — Publish to Confluence                        │
  │ ⚠️  NOT CONFIGURED — reports saved locally               │
  │ Options: W3 (Skip) is the only option                    │
  ```

### Local-Only Mode (G3 + W2 + J2)
- Wiki checkpoint: Auto-skip with note "saved locally"
- Jira checkpoint: Auto-skip with note "exported to markdown"
- Git checkpoint: Commit locally (STILL MANDATORY)
- Add persistent banner at each phase completion:
  ```
  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  📁 LOCAL MODE — No remote integrations
  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  • Code: committed locally at {output_dir}
  • Reports: saved to {output_dir}/reports/
  • To connect later:
    - Git: git remote add origin <url> && git push -u origin main
    - Wiki: set WIKI_PAT env var, then run scripts/publish-to-wiki.py
    - Jira: set JIRA_PAT env var, then run scripts/export-to-jira.py
  ```

---

## Phase Completion Reminders

At EVERY agent phase completion (after checkpoints), show integration status:

### If remote git configured:
```
✓ Code pushed to: https://github.com/intel-sandbox/my-project.git (branch: feat/my-solution)
```

### If local-only:
```
⚠️  Code committed locally only.
    Path: C:\Users\user\projects\my-solution
    Branch: main
    Commits: 3 (PRD + scaffold + validation)
    
    To push to remote later:
      git remote add origin https://github.com/intel-sandbox/my-project.git
      git push -u origin main
```

### If wiki/jira not configured:
```
⚠️  Wiki/Jira not configured — all reports saved locally in reports/
    To publish later: provide WIKI_PAT and JIRA_PAT env vars
```

---

## Resume Behavior

When an agent resumes (Phase 0 Session Recovery) and finds `integrations` in
`.iteration-state.json`:
- Do NOT re-ask for credentials
- If mode was `"remote"` but push fails (auth expired), offer to:
  1. Provide new credentials
  2. Switch to local-only for this session
  3. Skip push (commit locally, push later manually)

---

## Rules

1. **Ask ONCE per solution** — never re-ask in subsequent agents
2. **Never block on credentials** — always offer local-only fallback
3. **Git commit is ALWAYS mandatory** — local or remote, code must be committed
4. **Remind at every completion** — if local-only, always show the "push later" instructions
5. **Tokens are session-scoped** — if user returns in new session, read mode from
   `.iteration-state.json` but re-request tokens (they're not persisted)
6. **Validate before storing** — test that provided URLs/tokens actually work
7. **Support batch answers** — "G3 W2 J2" should work for quick local-only setup
