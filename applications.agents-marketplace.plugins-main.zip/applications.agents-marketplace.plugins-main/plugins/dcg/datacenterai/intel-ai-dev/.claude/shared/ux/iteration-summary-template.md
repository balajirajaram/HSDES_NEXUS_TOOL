# Iteration Summary Template

This template is used by ALL agents after completing their phase. Copy this structure
and fill in the placeholders. This ensures consistent UX across the pipeline.

---

## Template

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
✅ ITERATION {N} COMPLETE — {Phase Name}
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

COVERED:
• {item_1_covered}
• {item_2_covered}
• {item_3_covered}

SKIPPED (needs config/infra):
• {item_1_skipped} — {reason} — {what_to_install}
• {item_2_skipped} — {reason} — {what_to_install}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📊 REPORTS GENERATED
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
• {report_1_name}: {report_1_path}
• {report_2_name}: {report_2_path}
• {report_3_name}: {report_3_path}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
⏭️ FOR ITERATION {N+1}
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
1. Install: {tools_to_install}
2. Configure: {configs_to_set}
3. Deploy: {services_to_start}
4. Then run: {command_to_continue}
```

---

## Per-Agent Examples

### After /dev-agent (Generation + Dev Sanity)

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
✅ ITERATION 1 COMPLETE — Project Generation + Dev Sanity
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

COVERED:
• Generated 87 files from Technical PRD
• All templates applied with variable substitution
• Python syntax validation passed (all .py files compile)
• Ruff lint check passed (0 issues)
• Dev Sanity: backend starts on :8000 ✓
• Dev Sanity: GET /healthz → 200 ✓
• Dev Sanity: Auth flow (register → login → token) ✓
• Dev Sanity: List endpoints return {items, total} ✓
• Dev Sanity: Frontend serves on :3000 ✓
• Dev Sanity: Vite proxy → backend works ✓

SKIPPED (needs config/infra):
• Docker build validation — Docker not running — Start Docker Desktop
• Helm chart lint — helm CLI not installed — brew install helm

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📊 REPORTS GENERATED
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
• Generation Summary: reports/generation/generation-summary.md
• File Manifest: reports/generation/file-manifest.json

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
⏭️ FOR ITERATION 2
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
1. Install: Docker Desktop, helm (brew install helm)
2. Configure: DB_URL for PostgreSQL (if migrating from dev SQLite)
3. Deploy: n/a
4. Then run: /validation-agent to generate and run tests
```

### After /validation-agent (Validation Phase)

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
ITERATION 1 COMPLETE — Local Validation
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

COVERED (local-only, no external services):
• Unit tests: 56/56 passed
• Integration tests: 18/18 passed
• Security tests: 16/16 passed
• Code coverage: 79% (target: 85%)
• Ruff: 49 issues (17 auto-fixable, 0 critical)
• mypy: deferred

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
COMPONENTS NOT TESTED — Infrastructure Not Available
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

| Component | File | Coverage | Blocked By |
|-----------|------|----------|------------|
| Celery App | app/tasks/celery_app.py | 0% | Redis |
| Pipeline Task | app/tasks/pipeline_task.py | 0% | Redis + Celery worker |
| vLLM Client | app/inference/vllm_client.py | 0% | Running vLLM instance |
| Telemetry | app/observability/telemetry.py | 17% | OTEL Collector |
| Logging | app/observability/logging.py | 42% | (testable locally) |
| Mock Client | app/inference/mock_client.py | 44% | (needs more assertions) |
| EI Client | app/inference/ei_client.py | 53% | Running EI endpoint |
| Parser | app/services/parser.py | 59% | Binary test fixtures |
| Storage | app/storage/backend.py | 67% | Running MinIO |

Gap: 79% actual vs 85% target = 6% shortfall
All business logic is fully tested. Gap is ONLY infrastructure.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
REPORTS GENERATED
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
• Test Results: reports/validation/test-results.md
• Lint Results: reports/validation/lint-results.md
• Gaps Analysis: reports/validation/gaps-analysis.md

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
ITERATION 2 — Come Back When Infrastructure is Ready
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

SETUP CHECKLIST:
  [ ] Docker installed and running
  [ ] docker compose up -d redis minio
  [ ] pip install minio types-redis types-PyYAML
  [ ] Add test fixtures: tests/fixtures/sample.pdf, sample.xlsx

WHAT WILL BE TESTED:
  • Celery tasks — needs Redis — estimated +8% coverage
  • EI client — httpx mocking — estimated +3% coverage
  • MinIO storage — needs MinIO — estimated +3% coverage
  • Telemetry — OTEL mock exporter — estimated +2% coverage

EXPECTED: 79% → ~90% after iteration 2

Run /validation-agent again when ready. It picks up from
.iteration-state.json and targets only skipped modules.
```

### After /compliance-agent (Compliance Phase)

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
✅ ITERATION 1 COMPLETE — Compliance & Security
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

COVERED:
• Bandit SAST: 2 medium findings (documented)
• pip-audit: 0 known CVEs
• detect-secrets: 0 secrets found
• License check: 23 packages, all permissive (MIT/Apache-2.0/BSD)
• SLSA checklist: Level 2 (CI + provenance)
• Architecture diagrams: 5 Mermaid diagrams generated
• DASHBOARD generated with full status matrix

SKIPPED (needs config/infra):
• Trivy container scan — trivy not installed — brew install trivy
• Trivy image scan — no built image available — docker build first
• OSPDT deck — python-pptx not installed — pip install python-pptx
• cosign signing — cosign not installed — brew install cosign

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📊 REPORTS GENERATED
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
• DASHBOARD: reports/DASHBOARD.md
• Security Scan: reports/compliance/security-scan.md
• License Inventory: reports/compliance/license-inventory.md
• SLSA Checklist: reports/compliance/slsa-checklist.md
• Threat Model: reports/architecture/threat-model.md
• Data Flow: reports/architecture/data-flow.md
• Component Arch: reports/architecture/component-arch.md
• Deployment Arch: reports/architecture/deployment-arch.md
• API Sequences: reports/architecture/api-sequences.md

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
⏭️ FOR ITERATION 2
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
1. Install: trivy (brew install trivy), python-pptx (pip install python-pptx), cosign
2. Configure: n/a
3. Deploy: Build Docker images first (make docker-build)
4. Then run: /compliance-agent again to cover container scans + OSPDT deck
```

---

## Rules

1. **Always show both COVERED and SKIPPED** — even if one list is empty
2. **Be specific about what to install** — include the exact command
3. **Always list reports with paths** — developers need to find them
4. **Number the iteration 2 steps** — in the order they should be done
5. **Match the iteration number** — read from .iteration-state.json
6. **Update .iteration-state.json** — after showing this summary, persist the state
