# Output Directory Selection — Interactive Folder Picker

All agents that create output (PRD Agent, Dev Agent) MUST use this pattern to help the
user choose where their project folder lives. This runs AFTER integration setup but
BEFORE any content generation.

---

## When to Trigger

- **PRD Agent**: After Integration Setup, before Mode Selection
- **Dev Agent**: After Integration Setup, before PRD Intake (Step 1: Locate PRD)
- **Validation/Compliance Agents**: NEVER — they read `output_root` from `.iteration-state.json`

If `.iteration-state.json` already has `output_root` set (from a prior agent phase), skip this entirely.

---

## Step 1: Show Directory Options

List the contents of the current working directory AND one level above to help
the user orient. Present like this:

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📂 OUTPUT DIRECTORY SELECTION
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Where should I create the project folder?

📂 Current directory: {cwd}
   Folders: {list of subdirectories — ls output, folders only}

📂 Parent directory: {parent_of_cwd}
   Folders: {list of subdirectories — ls output, folders only}

Pick a ROOT PATH where I should create a new folder.
You can choose from above or type any custom path.

Examples:
  • C:\Users\you\projects
  • /home/you/work
  • D:\dev

Root path:
```

**Implementation**: Use `ls` to list directories in both locations. Show only folder names
(not files). Keep it clean — max 15 entries per location, add "..." if more exist.

---

## Step 2: Ask for Folder Name

Once the user picks a root path:

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📁 FOLDER NAME
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

What should I name the project folder?

This folder will contain everything for this solution:
  {folder-name}/
  ├── {project-slug}/    ← Generated project code (own git repo)
  ├── reports/           ← Pipeline reports (generation, validation, compliance)
  └── .iteration-state.json

Folder name: [suggest a default if PRD slug is known, e.g., "my-solution"]
```

If the PRD slug is already known (e.g., from a prior PRD agent run), suggest it as default.
Otherwise suggest something sensible based on context.

---

## Step 3: Confirm and Create

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
✓ OUTPUT DIRECTORY
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

I'll create: {root_path}/{folder_name}/

All project code and pipeline reports will live here.

Confirm? (yes / change path / change name)
```

On confirmation:
1. Create the directory: `mkdir -p {root_path}/{folder_name}`
2. Store `{root_path}/{folder_name}` as `output_root` in `.iteration-state.json`
3. Proceed to the next phase

---

## Shortcut: User Provides Full Path Directly

If the user directly provides a complete path (e.g., "C:\Users\me\projects\demo-project"),
treat it as BOTH the root path AND folder name combined. Skip to Step 3 (confirm only).

If the path already exists and contains files, warn:
```
⚠️  That folder already exists and contains files.
    Options:
    1. Use it anyway (existing files preserved, new files added alongside)
    2. Choose a different name
```

---

## Iteration State Storage

Store the confirmed path in `.iteration-state.json`:

```json
{
  "output_root": "C:\\Users\\vivekrs\\projects\\my-solution",
  "integrations": { ... }
}
```

All subsequent agents read `output_root` from here and NEVER re-ask.

---

## Rules

1. **NEVER assume a path** — always ask the user
2. **NEVER use the pipeline repo directory** as output — it's the tool, not the workspace
3. **Show real directory listings** — use `ls` to help the user orient
4. **Support shortcuts** — if user types a full path, don't force them through all steps
5. **Create the directory immediately** after confirmation — don't defer to later
6. **Git init inside the project-slug subfolder** (not the output root) — the project
   code is what gets its own repo; reports stay outside the git boundary
7. **One solution = one output folder** — reports and code together, clearly separated
