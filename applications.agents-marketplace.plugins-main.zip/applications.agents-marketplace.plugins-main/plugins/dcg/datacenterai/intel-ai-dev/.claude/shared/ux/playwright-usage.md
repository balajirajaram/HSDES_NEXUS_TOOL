# Playwright MCP — Usage Guide

This document defines exactly when and how Playwright is used in the Intel AI Dev Pipeline.
All agents that invoke Playwright MUST follow this guide to ensure consistent, documented behaviour.

---

## When Playwright Is Active

Playwright runs as a **Claude MCP plugin** (`playwright@claude-plugins-official`), enabled in
`settings.json`. It is invoked by agents — not by hooks — and only in specific phases.

| Agent | Phase | What Playwright Does |
|-------|-------|---------------------|
| `/dev-agent` | Phase 4.5 (Dev Sanity) | Verifies frontend renders in browser, checks for console errors, validates navigation |
| `/review-agent` | Phase 1.4 (Frontend Review) | Visual regression — screenshots key pages, checks for layout breakage |
| `/validation-agent` | Phase 2.3 (E2E Tests) | Drives end-to-end user flows (login → action → result) against running app |

---

## Phase 4.5 — Dev Sanity (dev-agent)

**Goal**: Confirm the generated frontend actually renders in a browser after `npm run dev` starts.

**Playwright steps in this phase:**

```
1. Navigate to http://localhost:5173 (Vite dev server)
2. Assert page title is not blank / not error page
3. Check browser console for uncaught errors (console.error events)
4. Navigate to /login or first route
5. Assert key UI elements are present (header, nav, main content area)
6. Screenshot the page → save to reports/generation/frontend-sanity.png
7. Check that API calls to /api/v1/health return 200 (using fetch in page context)
```

**Failure handling**: If Playwright can't connect (frontend not started), log as SKIPPED
with instruction: "Start frontend (`npm run dev`) then re-run /dev-agent Phase 4.5".

---

## Phase 1.4 — Frontend Visual Review (review-agent)

**Goal**: Detect visual regressions and layout issues in generated UI.

**Playwright steps:**

```
1. Screenshot every unique route in the app (from router.tsx)
2. Check for obvious layout breakage (elements overlapping, blank pages)
3. Run accessibility quick-check: assert <main>, <nav>, page <title> exist
4. Check that no "undefined", "null", or "[object Object]" appears in visible text
5. Save all screenshots to reports/review/screenshots/
```

---

## Phase 2.3 — E2E Test Execution (validation-agent)

**Goal**: Run user-story-level E2E scenarios against a live running stack.

**Playwright steps:**

```
1. Start the full stack (docker compose up or uvicorn + npm run dev)
2. For each user story with an E2E scenario:
   a. Navigate to entry point
   b. Perform actions (fill form, click button, upload file)
   c. Assert expected result (redirect, response, UI change)
3. Record pass/fail per scenario
4. Save report to reports/validation/e2e-results.md
```

**Pre-condition**: Docker must be running with `docker compose up`. If not available,
E2E tests are marked SKIPPED with install instructions.

---

## Playwright Session Logs

The `.playwright-mcp/` directory stores session logs automatically by the MCP plugin.
These are diagnostic — they are NOT part of pipeline output and should be in `.gitignore`.

Add to `.gitignore`:
```
.playwright-mcp/
```

---

## Graceful Degradation

If Playwright is unavailable (plugin not enabled, browser not installed):

- **Phase 4.5**: Skip browser verification. Log: "Playwright unavailable — frontend render unverified. Install: `npx playwright install`"
- **Review Phase 1.4**: Skip visual review. Manual checklist presented instead.
- **Validation Phase 2.3**: Skip E2E. Unit + integration tests still run.

No agent should FAIL because Playwright is missing — always degrade gracefully.
