# Pre-flight Dependency Checks

Every agent MUST run dependency checks at startup before executing any phase.
This prevents mid-execution failures and gives the user actionable install instructions.

---

## When to Run

- At the START of every agent invocation (before Phase 1 work begins)
- After user says "retry" or "continue" (re-check in case they installed something)

---

## Check Procedure

1. Detect which tools are available using `command -v` (Unix) or `where` (Windows)
2. Compare against the required tools for this agent
3. Classify as: REQUIRED (blocks execution) vs OPTIONAL (degrades output)
4. Present results to user before proceeding

---

## Agent Tool Requirements

### /dev-agent
| Tool | Required | Purpose | Install |
|------|----------|---------|---------|
| python 3.11+ | REQUIRED | Backend runtime | python.org |
| node 18+ | REQUIRED (if frontend) | Frontend build | nodejs.org |
| ruff | OPTIONAL | Lint validation | `pip install ruff` |
| docker | OPTIONAL | Build verification | docker.com |
| helm | OPTIONAL | Chart linting | `brew install helm` |

### /validation-agent
| Tool | Required | Purpose | Install |
|------|----------|---------|---------|
| python 3.11+ | REQUIRED | Test runtime | python.org |
| pytest | REQUIRED | Test execution | `pip install pytest` |
| ruff | REQUIRED | Lint checking | `pip install ruff` |
| mypy | REQUIRED | Type checking | `pip install mypy` |
| coverage | REQUIRED | Coverage measurement | `pip install coverage` |
| node 18+ | OPTIONAL (frontend) | Frontend tests | nodejs.org |

### /compliance-agent
| Tool | Required | Purpose | Install |
|------|----------|---------|---------|
| python 3.11+ | REQUIRED | Script runtime | python.org |
| bandit | REQUIRED | Python SAST | `pip install bandit` |
| pip-audit | REQUIRED | Dependency CVEs | `pip install pip-audit` |
| pip-licenses | REQUIRED | License inventory | `pip install pip-licenses` |
| trivy | OPTIONAL | Container scanning | `brew install trivy` |
| shellcheck | OPTIONAL | Shell script analysis | `brew install shellcheck` |
| detect-secrets | OPTIONAL | Secret detection | `pip install detect-secrets` |
| python-pptx | OPTIONAL | OSPDT deck generation | `pip install python-pptx` |
| helm | OPTIONAL | Helm chart validation | `brew install helm` |
| cosign | OPTIONAL | Artifact signing | `brew install cosign` |

---

## Output Format

Present to user as:

```
Pre-flight Check
================
✓ python 3.11.5
✓ bandit 1.7.7
✓ pip-audit 2.7.0
✓ pip-licenses 4.3.4
✗ trivy — NOT FOUND (optional: container/fs scanning)
✗ shellcheck — NOT FOUND (optional: shell script analysis)
✗ python-pptx — NOT FOUND (optional: OSPDT deck generation)

Required tools: 4/4 ✓
Optional tools: 4/7 (3 missing — output will be partial)

Missing optional tools can be installed with:
  pip install python-pptx detect-secrets
  brew install trivy shellcheck cosign

Proceed with available tools? (yes / install first / skip)
```

---

## Plugin Verification & Auto-Installation

After tool checks, verify required Claude Code plugins are installed.
**Auto-install missing plugins** to prevent user friction — plugins are lightweight and safe.

```bash
# Required plugins for full pipeline operation
REQUIRED_PLUGINS="playwright semgrep code-review github frontend-design context7"
MISSING_PLUGINS=""

for plugin in $REQUIRED_PLUGINS; do
  if claude plugin list 2>/dev/null | grep -q "$plugin"; then
    echo "✓ plugin: $plugin"
  else
    MISSING_PLUGINS="$MISSING_PLUGINS $plugin"
  fi
done

# Auto-install missing plugins (no proxy dependency — these are local MCP tools)
if [ -n "$MISSING_PLUGINS" ]; then
  echo ""
  echo "Installing missing plugins for optimal pipeline operation..."
  for plugin in $MISSING_PLUGINS; do
    echo "  Installing $plugin..."
    claude plugin install "$plugin" --scope project 2>/dev/null && \
      echo "  ✓ $plugin installed" || \
      echo "  ✗ $plugin failed (non-blocking, will degrade gracefully)"
  done
  echo ""
  echo "Plugin installation complete. Reloading..."
fi
```

| Plugin | Required By | Purpose | Without It |
|--------|-------------|---------|------------|
| playwright | /dev-agent (Phase 4.5 Step 9) | Browser-based UI verification | Falls back to curl HTML check |
| semgrep | /dev-agent, /compliance-agent | Real-time SAST during code generation | Security caught later by bandit |
| code-review | /review-agent | Multi-agent PR review with confidence scoring | Single-agent review only |
| github | All agents (checkpoints) | Enhanced git/PR operations | Uses direct git commands |
| frontend-design | /dev-agent (Phase 4 frontend) | Distinctive UI generation within Intel brand | Generic shadcn/ui styling |
| context7 | /dev-agent (Phase 4) | Version-specific documentation for correct API usage | Uses training data (may be stale) |

**Important:** Plugins are MCP tools (run locally), NOT CLI commands. The `semgrep` plugin
does NOT require `semgrep` CLI installed — it uses its own bundled analysis. Same for
`playwright` (uses its own Chromium). Don't confuse plugin availability with CLI tool availability.

Plugins enhance quality but the pipeline functions without them — all agents have fallback paths.

---

## Behavior Rules

1. **Never fail silently** — if a required tool is missing, STOP and tell the user
2. **Never install without asking** — present the install commands, let user decide
3. **Record in iteration state** — update `.iteration-state.json` tool_availability
4. **Degrade gracefully** — if optional tools are missing, skip those checks and note in report
5. **Platform-aware** — use `brew` for macOS, `apt` for Linux, `choco`/manual for Windows
6. **Check versions** — some tools need minimum versions (e.g., Python 3.11+, Node 18+)

---

## Integration with Iteration State

After pre-flight, update `.iteration-state.json`:

```bash
python scripts/update-iteration-state.py phase \
  --name {current_phase} \
  --status in_progress \
  --output-dir .
```

For each missing optional tool that causes a skip:
```bash
python scripts/update-iteration-state.py skip \
  --item "Container scan (Trivy)" \
  --reason "trivy not installed" \
  --phase compliance \
  --needed "Install trivy: brew install trivy" \
  --output-dir .
```
