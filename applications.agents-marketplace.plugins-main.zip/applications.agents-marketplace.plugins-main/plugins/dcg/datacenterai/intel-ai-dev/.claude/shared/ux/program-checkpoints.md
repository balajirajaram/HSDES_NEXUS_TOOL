# Program Checkpoints — Mandatory Gates

Every agent phase MUST end with these 3 program checkpoints BEFORE showing the
iteration summary. These are NOT optional suggestions — they are enforcement gates.
The developer must consciously acknowledge each one (proceed or skip with reason).

These checkpoints prevent:
- Knowledge loss (Wiki)
- Tracking drift (Jira)
- Work loss on dev machine (Git)

---

## When to Trigger

Checkpoints trigger at the END of each agent phase:
- After `/prd-agent` completes → PRD + breakdown created
- After `/dev-agent` completes → Project scaffold generated
- After `/validation-agent` completes → Tests run, reports generated
- After `/compliance-agent` completes → Scans done, DASHBOARD generated

---

## Checkpoint Format

Present ALL 3 checkpoints together as a single gate:

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🔒 PROGRAM CHECKPOINTS (3 of 3 required)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
These ensure nothing is lost. Review each and choose an action.

┌─────────────────────────────────────────────────────────┐
│ 1️⃣  WIKI — Publish to Confluence                        │
├─────────────────────────────────────────────────────────┤
│ What will be published:                                 │
│   • [List of documents/reports to publish]              │
│   • Space: datacenterai                                  │
│                                                         │
│ Options:                                                │
│   W1. Publish now                                       │
│   W2. Dry-run (preview only)                            │
│   W3. Skip — reason: _______________                    │
└─────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────┐
│ 2️⃣  JIRA — Update stories and epics                     │
├─────────────────────────────────────────────────────────┤
│ What will be updated:                                   │
│   • [List of Jira tickets to update]                    │
│   • Status change: [current → new]                      │
│   • Comment to add: [summary of what was done]          │
│                                                         │
│ Options:                                                │
│   J1. Update now                                        │
│   J2. Dry-run (preview changes)                         │
│   J3. Skip — reason: _______________                    │
└─────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────┐
│ 3️⃣  GIT — Commit and push changes                       │
├─────────────────────────────────────────────────────────┤
│ What will be committed:                                 │
│   • [List of new/modified files]                        │
│   • Branch: [branch name]                               │
│   • Commit message: "[generated message]"               │
│                                                         │
│ Options:                                                │
│   G1. Commit + Push now                                 │
│   G2. Commit only (push later)                          │
│   G3. Skip — reason: _______________                    │
└─────────────────────────────────────────────────────────┘

Type your choices (e.g., "W1 J2 G1" or "all-1" for all publish/update/push):
```

---

## Checkpoint Content Per Agent Phase

### After /prd-agent

| Checkpoint | Content |
|-----------|---------|
| Wiki | Publish PRD document + Feature Breakdown to Confluence space |
| Jira | Create EPICs and Stories from Feature Breakdown (dry-run first recommended) |
| Git | Commit `docs/prd/` files, push to feature branch |

**Commit message template:**
```
feat(prd): Add PRD for {project_name}

- Technical PRD: docs/prd/{slug}-technical.md
- Feature Breakdown: docs/prd/{slug}-breakdown.md
- {epic_count} epics, {story_count} stories defined
```

### After /dev-agent

| Checkpoint | Content |
|-----------|---------|
| Wiki | Update PRD wiki page with "Code Generated" status + file count |
| Jira | Update all Stories with comment: "Code generated — ready for review" |
| Git | Commit entire generated project, push to feature branch |

**Commit message template:**
```
feat({project_slug}): Generate project scaffold from PRD

- {file_count} files generated from Technical PRD
- Backend: src/{component}/ (FastAPI + SQLAlchemy)
- Frontend: frontend/ (React + TypeScript)
- Helm: helm/{project}/ (K8s deployment)
- CI/CD: .github/workflows/ (5 pipelines)
```

### After /validation-agent

| Checkpoint | Content |
|-----------|---------|
| Wiki | Publish validation report to Confluence |
| Jira | Update Stories with test status (covered/gap) |
| Git | Commit test files + reports, push |

**Commit message template:**
```
test({project_slug}): Add test suite and validation report

- {test_count} tests ({pass_count} pass, {fail_count} fail)
- Coverage: {coverage}%
- Reports: reports/validation/
```

### After /compliance-agent

| Checkpoint | Content |
|-----------|---------|
| Wiki | Publish compliance report + DASHBOARD to Confluence |
| Jira | Update EPICs with compliance status (PASS/CONDITIONAL/FAIL) |
| Git | Commit compliance artifacts + DASHBOARD, push |

**Commit message template:**
```
docs({project_slug}): Add compliance artifacts and DASHBOARD

- Security scan: {findings} findings
- SDLE diagrams: {diagram_count} generated
- SLSA Level: {slsa_level}
- DASHBOARD: reports/DASHBOARD.md
```

---

## Execution Commands

### Wiki Publish
```bash
python scripts/publish-to-wiki.py {file_path} --space datacenterai
```

### Jira Update
```bash
# Create EPICs/Stories (from PRD breakdown) — interactive mode
# Asks: assignee IDSID, component, fix version, sprint, parent epic, story points
python scripts/export-to-jira.py --project DCAIDSE8 docs/prd/{slug}-breakdown.md

# Non-interactive mode (for CI/CD or when fields are known)
python scripts/export-to-jira.py --project DCAIDSE8 \
  --non-interactive --assignee vivekrs --sprint 341470 \
  --component 244608 --fix-version 317502 --story-points 5 \
  docs/prd/{slug}-breakdown.md

# Update existing tickets with comment
python scripts/update-jira-comment.py --project DCAIDSE8 --status {status} --comment "{message}"
```

**IMPORTANT — Jira Interactive Flow:**
When creating tickets, the script MUST ask the user for:
1. **Assignee IDSID** — who owns this work (e.g., `vivekrs`)
2. **Component** — fetched from project, user picks from list
3. **Fix Version** — fetched from project (unreleased only), user picks
4. **Sprint ID** — which sprint to assign stories to
5. **Parent Epic** — create new or link to existing epic key
6. **Story Points** — default per story

Never create tickets with default/blank values for required fields.
The agent should collect these BEFORE calling the script or API.

### Git Commit + Push
```bash
git add {specific_files}
git commit -m "{commit_message}"
git push origin {branch_name}
```

**CRITICAL: No AI attribution in commits.** Never add `Co-Authored-By`, `Generated by`,
or any AI/Claude/Anthropic reference in commit messages. The developer is the sole author.
See `.claude/shared/ux/git-versioning.md` for full commit discipline rules.

---

## Memory Save (4th implicit checkpoint)

After all 3 checkpoints are processed, the agent MUST save project state to Claude memory.
This is NOT presented to the user as a choice — it happens automatically.

### What to save:
- Project name, slug, current iteration
- What phases are complete
- Key decisions made (tech stack, scope cuts, security classification)
- What's blocked and why
- Next steps for the developer

### Memory format:
```markdown
---
name: {Project Name} - Status
description: {one-line project description} — Phase: {current_phase}, Iteration: {N}
type: project
---

# {Project Name}

**Status:** {phase} complete, iteration {N}
**Location:** {output_dir}
**Last updated:** {date}

**Completed:**
- [x] PRD generated ({date})
- [x] Code generated ({file_count} files, {date})
- [ ] Validation ({test_pass}/{test_total} tests)
- [ ] Compliance (pending)

**Key decisions:**
- {decision_1}
- {decision_2}

**Blocked/Pending:**
- {item}

**Next:** {what_to_do_next}
```

---

## Memory Read (Reciprocal to Memory Save)

Every agent has a **Phase 0: Session Recovery** that reads back what was saved here.
See `.claude/shared/ux/resumption-pattern.md` for the full read workflow.

At agent startup:
1. Check `.iteration-state.json` for prior phase statuses
2. Check Claude memory for `"{project_name} - Status"` entries
3. If found → present resumption prompt (Continue / Retry / Review / Fresh)
4. If checkpoints were skipped last time → remind developer immediately

This ensures the memory save (above) is never write-only — it's always read back on next session.

---

## Integration-Aware Behavior

Checkpoints adapt based on the `integrations` block in `.iteration-state.json`
(set during Integration Setup — see `.claude/shared/ux/integration-setup.md`).

### Connected Mode (remote git + wiki + jira configured)
All 3 checkpoints fully functional. Offer publish, update, push.

### Partial Mode (some integrations skipped)
Show all 3 checkpoints but mark unconfigured ones:
```
│ 1️⃣  WIKI — Publish to Confluence                        │
│ ⚠️  NOT CONFIGURED — reports saved locally only          │
│ Auto-skipped (no WIKI_PAT provided at setup)            │
```

### Local-Only Mode (G3 + W2 + J2 from setup)
- Wiki: Auto-skip, note "saved locally in reports/"
- Jira: Auto-skip, note "exported to markdown in docs/prd/"
- Git: Commit locally (STILL MANDATORY — G1 becomes "Commit locally")
- After checkpoints, ALWAYS show:
```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📁 LOCAL MODE — Code saved and committed
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
• Git commit: ✓ (local, no remote push)
• Reports: saved to {output_dir}/reports/
• To connect to remote later:
    git remote add origin <your-repo-url>
    git push -u origin main
• To publish to Wiki later:
    export WIKI_PAT=<your-token>
    python scripts/publish-to-wiki.py reports/DASHBOARD.md --space datacenterai
• To export to Jira later:
    export JIRA_PAT=<your-token>
    python scripts/export-to-jira.py --project DCAIDSE8 docs/prd/{slug}-breakdown.md
```

---

## Rules

1. **NEVER skip checkpoints silently** — always present them to the developer
2. **Allow batch responses** — "W1 J1 G1" should work for speed
3. **If integrations not configured** — read `.iteration-state.json` integrations block to determine mode; auto-skip unconfigured ones with clear note
4. **If no git remote** — commit locally, remind user to push later at EVERY phase completion
5. **Memory save is automatic** — no user prompt needed, just do it
6. **Track skipped checkpoints** — record in .iteration-state.json with reason
7. **Remind on next session** — if checkpoints were skipped, remind developer at start of next session
8. **Git commit is NON-NEGOTIABLE** — always enforce G1 or G2 before ending; G3 (skip) requires explicit reason and is logged as a risk
9. **Remind about remote at every phase** — if local-only mode, every agent completion MUST show the "push later" instructions
10. **Never re-ask credentials** — read integration mode from `.iteration-state.json`, only re-request tokens if a push/publish fails (expired token)
