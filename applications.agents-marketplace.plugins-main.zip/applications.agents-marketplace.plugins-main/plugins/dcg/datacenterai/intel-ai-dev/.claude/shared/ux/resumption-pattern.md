# Session Resumption Pattern

When a developer returns after hours, days, or weeks away, every agent MUST check for
prior session state before starting work. This prevents accidental re-generation,
provides context, and enables seamless continuation.

---

## When This Triggers

This pattern activates when ANY agent skill is invoked (`/prd-agent`, `/dev-agent`,
`/validation-agent`, `/compliance-agent`). It runs as **Phase 0** — before any other phase.

---

## Phase 0: Session Recovery (MANDATORY)

### Step 1: Check for Prior State

Look for these indicators of a prior session (in order):

1. **`.iteration-state.json`** in the current directory or specified output directory
2. **Claude memory** — search for `"{project_name} - Status"` type: project
3. **Git history** — check for recent commits matching pipeline patterns (`feat(prd):`, `feat({slug}):`, `test({slug}):`, `docs({slug}):`)

If NONE found → this is a fresh start, proceed to Phase 1 normally.

If ANY found → present the resumption prompt (Step 2).

### Step 2: Resumption Prompt

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📋 PRIOR SESSION DETECTED
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Project: {project_name}
Location: {output_dir}
Last active: {last_timestamp} ({days_ago} days ago)

Progress:
  {✓|◐|○} PRD — {status_detail}
  {✓|◐|○} Code Generation — {status_detail}
  {✓|◐|○} Validation — {status_detail}
  {✓|◐|○} Compliance — {status_detail}

{IF skipped_items exist:}
Skipped last time (needs tools/config):
  • {item_1} — {reason} — {install_instruction}
  • {item_2} — {reason} — {install_instruction}

{IF pending_checkpoints exist:}
⚠️  Pending checkpoints from last session:
  • {checkpoint} was skipped — reason: {reason}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🔀 YOUR OPTIONS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
1. Continue — Pick up where you left off (next: {next_phase})
2. Retry skipped — Install missing tools and re-run incomplete items
3. Review — Show reports and iteration state in detail
4. Start fresh — Ignore prior state, begin from scratch
```

### Step 3: Execute Based on Choice

**If Continue:**
- Load iteration state
- Jump to the next incomplete phase
- Pre-populate context (project vars, PRD location, output path)
- Do NOT re-ask questions already answered (output dir, PRD location, etc.)

**If Retry skipped:**
- Read `next_iteration_requirements` from `.iteration-state.json`
- Check which tools/configs are now available
- Re-run only the skipped/partial items
- Update iteration state with results

**If Review:**
- Display `reports/DASHBOARD.md` if exists
- Otherwise display `.iteration-state.json` summary
- After review, re-present options 1/2/4

**If Start fresh:**
- Confirm: "This will NOT delete prior generated files. You'll create alongside."
- Proceed to Phase 1 normally

---

## What Gets Saved for Resumption

Each agent automatically saves this state (via program-checkpoints.md Memory Save):

### In `.iteration-state.json`:
- Current iteration number
- Per-phase status: `pending | in_progress | completed | partial`
- Completion timestamps
- Skipped items with reasons
- Tool availability at time of execution
- `next_iteration_requirements` list

### In Claude Memory:
- Project name, slug, output directory
- Phase completion status
- Key decisions made (inference strategy, scope choices, etc.)
- What's blocked and why
- Exact next step for returning developer

### In Git:
- All generated code committed and pushed
- Reports committed
- Branch name documented in memory

---

## Agent-Specific Resumption Context

### /prd-agent Resumption
If PRD Q&A was interrupted mid-way:
- Check if partial PRD exists in `docs/prd/`
- If partial: "PRD was started but incomplete. Continue from Area {N}?"
- If complete: "PRD already exists. Edit it, or generate Technical PRD?"

### /dev-agent Resumption
If code generation was interrupted or completed:
- Check if `src/{component}/` exists
- If exists + iteration-state shows completed: "Project already generated. Run validation?"
- If partial: "Generation was interrupted. Resume from file {N} of {total}?"

### /validation-agent Resumption
If tests were partially run:
- Check `reports/validation/` for prior results
- "Validation ran previously — {pass}/{total} passed. Re-run all or retry failures only?"

### /compliance-agent Resumption
If scans were partially complete:
- Check `reports/compliance/` for prior results
- "Compliance ran previously — some scans skipped. Retry with {tool} now available?"

---

## Rules

1. **Phase 0 is MANDATORY** — never skip session recovery check
2. **Never silently restart** — if prior state exists, always inform the developer
3. **Preserve prior work** — "Start fresh" does not delete anything
4. **Be specific about "next step"** — not "continue the pipeline" but "run /validation-agent to test your generated code"
5. **Show time elapsed** — "Last active: 7 days ago" helps developer orient
6. **Show what's blocked** — "Needs Docker installed" is actionable
7. **Memory saves MUST include output_dir** — so next session knows where files are
