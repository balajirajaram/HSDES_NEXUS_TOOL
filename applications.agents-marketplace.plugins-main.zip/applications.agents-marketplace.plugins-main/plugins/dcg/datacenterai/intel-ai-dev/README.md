# intel-ai-dev - plugin for Agentic AI SDLC

**Agent-assisted AI Solutions development plugin for Datacenter AI Solutions**,
designed to deliver solutions with defined Intel standards, contracts, and
compliance — from problem statement till production delivery. Pluggable with
any Intel solution ecosystem, for example: Enterprise Inference, ERAG, and
more. The plugin assists the developer at every phase — PRD generation,
development, validation and sanity, compliance readiness, and review — through
a defined agent-assisted mode, while leaving the developer in control of
further iterations.

| Agent | What it does |
|---|---|
| `/prd-agent` | Generate a Technical PRD via Socratic Q&A or workshop transcript |
| `/dev-agent` | Scaffold the full project from the PRD (151 templates + LLM sub-phases) |
| `/validation-agent` | Generate tests, run coverage, report PRD-to-test gaps |
| `/compliance-agent` | Bandit/Trivy scans, OSPDT BOM, SDLE diagrams, SBOM, DASHBOARD |
| `/review-agent` | Final code review against Intel contract rules C1-C14 |

Plus 7 quick commands (`/scan`, `/test`, `/lint`, `/deploy`, `/status`,
`/wiki-publish`, `/jira-update`), 4 sub-specialist agents, and 5 enforcement
hooks (secret scanner, dangerous-command blocker, license-header check,
standards validator, phase-rollback snapshot).

---

## Install

```text
/plugin marketplace add intel-innersource/applications.agents-marketplace.plugins
/plugin install intel-ai-dev@plugins-marketplace
```

Verify:

```text
/plugin
```

You should see `intel-ai-dev@plugins-marketplace ✓ enabled v1.0.0`.

Smoke test in any directory:

```text
/prd-agent
```

---

## Usage

### Full pipeline (idea → delivered AI solution)

```text
/prd-agent          # Interactive Q&A → Technical PRD       (~25 min)
/dev-agent          # Tech PRD → project + dev sanity        (~1-2 hours)
/validation-agent   # Tests, coverage, gap analysis          (~30 min)
/compliance-agent   # Scans, OSPDT, SDLE, SBOM, DASHBOARD    (~20 min)
/review-agent       # Final review against Intel standards   (~15 min)
```

Each agent announces what it will do before doing it, asks for approval, and
summarizes after. Stop at any point — `.iteration-state.json` resumes you on
the next session.

---

## Inference for your generated solution

If your solution has a model-serving or inference dependency, the generated
project supports any of the following backends:

| Backend | Description |
|---|---|
| Any OpenAI-compatible endpoint | Enteprise Inference, OVMS, TGI, OpenAI, Azure OpenAI, Ollama, or any compatible service |

The generated code targets a standard OpenAI-compatible API — swap backends
by changing the endpoint URL. If you choose **Enterprise Inference**, the
plugin provides additional vLLM deployment Helm charts for models specified
in your PRD. See
[Enterprise Inference reference](docs/references/enterprise-inference.md) for
deployment patterns and configuration details.

---

## What gets generated

Every solution includes:

| Layer | Stack | Files |
|---|---|---|
| Backend | FastAPI, async, Pydantic v2, structlog, Prometheus | 31 |
| Frontend | React 18, TypeScript strict, Vite, TanStack Query, Tailwind | 44 + 8/feature |
| Containers | Multi-stage Docker, non-root (uid=1000), health checks | 3 |
| Kubernetes | Helm 200+ params, zero-trust NetworkPolicy, HPA, PDB | 16 |
| CI/CD | Super-Linter, Trivy, Bandit, CodeQL, SLSA cosign | 10 |
| Infrastructure | Ansible playbooks + roles, Docker Compose | 11 |
| Config | Makefile, Taskfile, CNCF docs, scripts, .env | 18 |
| AI / Inference | OpenAI-compatible client (works with EI, OVMS, vLLM, or any endpoint) | included |

---

## Generated output structure

After running the full pipeline, here's what you get:

```
{output-dir}/
├── {project-slug}/                    ← Your solution (self-contained, push to its own repo)
│   ├── src/{component}/
│   │   ├── app/
│   │   │   ├── main.py               # FastAPI application
│   │   │   ├── api/                   # Versioned endpoints
│   │   │   ├── models/               # Pydantic schemas
│   │   │   ├── services/             # Business logic
│   │   │   ├── inference/            # OpenAI-compatible client
│   │   │   └── observability/        # Structured logging + metrics
│   │   ├── tests/                    # Unit + integration tests
│   │   ├── Dockerfile                # Multi-stage, non-root
│   │   └── pyproject.toml
│   ├── frontend/                     # React + TypeScript + Vite
│   ├── helm/{project}/               # Helm chart (200+ params, zero-trust)
│   ├── docker/                       # docker-compose (dev + prod)
│   ├── ansible/                      # Playbooks + roles
│   ├── .github/workflows/            # CI/CD pipelines
│   ├── docs/prd/                     # PRD travels with the project
│   ├── README.md
│   ├── Makefile
│   └── LICENSE
│
├── reports/                           ← All pipeline reports
│   ├── DASHBOARD.md                   # One-stop summary linking everything
│   ├── generation/
│   │   ├── generation-summary.md      # What was generated and why
│   │   └── file-manifest.json         # Every file with SHA256 + source
│   ├── validation/
│   │   ├── test-results.md            # Pass/fail counts, coverage %
│   │   ├── lint-results.md            # ruff, mypy, shellcheck findings
│   │   └── gaps-analysis.md           # PRD criteria not yet tested
│   ├── compliance/
│   │   ├── security-scan.md           # Bandit + Trivy + detect-secrets
│   │   ├── license-inventory.md       # All deps with license risk rating
│   │   ├── slsa-checklist.md          # SLSA level + OpenSSF estimate
│   │   └── ospdt-deck.pptx           # Intel OSPDT BOM deck
│   └── architecture/
│       ├── threat-model.md            # Security threat model
│       ├── data-flow.md               # Data flow diagrams
│       ├── component-arch.md          # Component architecture
│       ├── deployment-arch.md         # Deployment topology
│       └── api-sequences.md           # API sequence diagrams
│
└── .iteration-state.json              ← Pipeline progress (resume anytime)
```

**Key principle:** Project code and reports are separated. The project is
self-contained and can be pushed to its own repository independently.
Reports stay in the pipeline workspace for review and iteration.

---

## Architecture

![Architecture](docs/architecture/pipeline-overview.svg)

The full architecture (distribution, agents, hybrid layers, hooks, shared
infra, outputs, integrations) is captured in the SVG above. The plugin's
hybrid scaffold + LLM design avoids context-window exhaustion: a deterministic
scaffold step stamps 151 templates in under 3 seconds, then focused LLM
sub-phases (10–30 KB context each) generate PRD-specific code on top.

---

## Plugin structure

```
intel-ai-dev/
├── plugin.json                    # Manifest
├── README.md                      # This file
├── .claude/
│   ├── skills/                    # 5 main agents
│   ├── agents/                    # 4 sub-specialists
│   ├── commands/                  # 7 quick commands
│   ├── hooks/                     # 5 .py hooks + hooks.json
│   └── shared/
│       ├── standards/             # 13 Intel enterprise standards
│       ├── contracts/             # 6 inter-skill contracts
│       ├── references/            # Ecosystem references (EI, etc.)
│       └── ux/                    # 7 UX patterns
├── scripts/
│   ├── scaffold.py                # Template stamping (< 3s, 0 LLM)
│   ├── publish-to-wiki.py
│   ├── export-to-jira.py
│   ├── generate-ospdt-deck.py
│   ├── generate-sdle-diagrams.py
│   ├── generate-sbom.py
│   ├── fill-dashboard-template.py
│   └── lib/                       # Shared libs
└── docs/
    ├── architecture/
    │   └── pipeline-overview.svg
    ├── references/
    │   └── enterprise-inference.md
    └── extensibility-guide.md
```

---

## Extensibility

This plugin is designed to be modular. New skills, agents, standards, hooks,
contracts, and UX patterns can be added without modifying existing components.
See the [Extensibility Guide](docs/extensibility-guide.md) for detailed
instructions on how to extend the plugin.

---

## Optional environment variables

For Wiki and Jira integration:

```bash
export WIKI_BASE_URL=https://wiki.ith.intel.com
export WIKI_PAT=your-token
export WIKI_SPACE=datacenterai
export JIRA_BASE_URL=https://jira.devtools.intel.com
export JIRA_PAT=your-token
export JIRA_PROJECT=DCAIDSE8
```

Without these, the plugin runs in local-only mode — outputs saved locally,
checkpoints skip external publishing with clear instructions for connecting later.

---

## Owner

DCG / AI Solutions & Customer Engineering — vivek.rs@intel.com / raghavendra.k.ural@intel.com

---

## License

Copyright (C) 2026 Intel Corporation. Licensed under Apache-2.0.
