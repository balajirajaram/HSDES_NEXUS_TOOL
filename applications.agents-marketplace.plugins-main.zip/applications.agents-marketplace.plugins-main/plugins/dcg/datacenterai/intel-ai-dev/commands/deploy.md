---
allowed-tools: Bash, Read, Glob, Grep
description: Deploy to target environment (dev/staging/prod)
argument-hint: [dev|staging|prod]
---

# Deploy

Deploy the project to the specified environment.

## Steps

1. Determine target environment from `$ARGUMENTS` (default: dev)
2. Validate environment is one of: dev, staging, prod
3. For prod, require explicit confirmation

```bash
ENV=${ARGUMENTS:-dev}

case $ENV in
  dev)
    echo "Deploying to dev..."
    docker compose -f docker/docker-compose.yml up -d --build
    ;;
  staging)
    echo "Deploying to staging..."
    helm upgrade --install $(basename $PWD) ./helm/$(basename $PWD) \
      -f helm/$(basename $PWD)/values.yaml \
      -n $(basename $PWD)-staging --create-namespace
    ;;
  prod)
    echo "⚠ Production deployment requires confirmation"
    echo "Run: helm upgrade --install $(basename $PWD) ./helm/$(basename $PWD) \\"
    echo "  -f helm/$(basename $PWD)/values-production.yaml \\"
    echo "  -n $(basename $PWD)-prod --create-namespace"
    ;;
esac
```

4. After deployment, run health checks
5. Report deployment status
