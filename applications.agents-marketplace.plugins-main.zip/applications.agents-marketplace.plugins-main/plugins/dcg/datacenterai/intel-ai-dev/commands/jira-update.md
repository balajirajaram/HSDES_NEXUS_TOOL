---
allowed-tools: Bash, Read, Glob, Grep
description: Update Jira tickets with current project status
argument-hint: [project-key]
---

# Jira Update

Update Jira tickets with the current project status.

## Steps

1. Determine Jira project key from `$ARGUMENTS` (default: DCAIDSE8)
2. Detect current status by checking:
   - Git branch and latest commit
   - Test results (if recent)
   - Scan results (if recent)

3. Run the update script:

```bash
PROJECT=${ARGUMENTS:-DCAIDSE8}

# Find relevant Jira tickets from git branch or PRD
python scripts/update-jira-comment.py \
  --project "$PROJECT" \
  --status "$(git log -1 --format='%s')" \
  --branch "$(git branch --show-current)"
```

4. Report: which tickets were updated, what status was posted

## Requirements
- `JIRA_BASE_URL` and `JIRA_PAT` environment variables set
- Network access to Jira (may need VPN)
