---
allowed-tools: Bash, Read, Glob, Grep
description: Run linters (ruff + mypy + prettier + hadolint)
argument-hint: [component-name]
---

# Lint Check

Run all configured linters on the project.

## Steps

1. If `$ARGUMENTS` is provided, lint only `src/$ARGUMENTS/`; otherwise lint everything

```bash
# Python linting
cd src/${ARGUMENTS:-*} 2>/dev/null
ruff check . 2>/dev/null || echo "Install: pip install ruff"
mypy --strict app/ 2>/dev/null || echo "Install: pip install mypy"

# Dockerfile linting
find . -name "Dockerfile*" -exec hadolint {} \; 2>/dev/null || echo "Install hadolint"

# YAML validation
find . -name "*.yml" -o -name "*.yaml" | head -20 | xargs python -c "
import yaml, sys
for f in sys.argv[1:]:
    try:
        yaml.safe_load(open(f))
    except Exception as e:
        print(f'{f}: {e}')
" 2>/dev/null || true

# Frontend (if exists)
if [ -f frontend/package.json ]; then
  cd frontend && npx prettier --check "src/**/*.{ts,tsx}" 2>/dev/null || true
fi
```

2. Report total issues by linter, suggest `--fix` for auto-fixable issues
