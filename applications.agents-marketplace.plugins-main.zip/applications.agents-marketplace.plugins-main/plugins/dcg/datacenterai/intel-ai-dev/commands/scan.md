---
allowed-tools: Bash, Read, Glob, Grep
description: Run security scans (Bandit + Trivy + detect-secrets) on current project
argument-hint: [component-name]
---

# Security Scan

Run security scans on the current project or a specific component.

## Steps

1. Detect project root (look for `pyproject.toml`, `Makefile`, or `src/` directory)
2. If `$ARGUMENTS` is provided, scan only `src/$ARGUMENTS/`; otherwise scan all of `src/`
3. Run available scanners:

```bash
# Python SAST
bandit -r src/ -s B101 --exclude "*/tests/*" -f screen 2>/dev/null || echo "Install: pip install bandit"

# Filesystem vulnerability scan
trivy fs --severity HIGH,CRITICAL . 2>/dev/null || echo "Install trivy: https://trivy.dev"

# Secret detection
detect-secrets scan --all-files 2>/dev/null || echo "Install: pip install detect-secrets"

# Shell script analysis
find . -name "*.sh" -exec shellcheck {} \; 2>/dev/null || echo "Install: apt-get install shellcheck"
```

4. Summarize findings: count by severity, list HIGH/CRITICAL items
5. Suggest fixes for the top 3 most critical findings
