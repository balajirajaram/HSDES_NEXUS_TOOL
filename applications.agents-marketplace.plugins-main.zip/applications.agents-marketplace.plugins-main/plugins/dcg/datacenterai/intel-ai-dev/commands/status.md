---
allowed-tools: Bash, Read, Glob, Grep
description: Show project compliance status (tests, coverage, scans, OpenSSF estimate)
argument-hint:
---

# Project Status

Show a compliance dashboard for the current project.

## Steps

1. Detect project structure:

```bash
echo "=== Project Status ==="
echo ""

# Components
echo "Components:"
for dir in src/*/; do
  [ -f "$dir/app/main.py" ] && echo "  ✓ $(basename $dir) (backend)"
done
[ -f "frontend/package.json" ] && echo "  ✓ frontend (React)"

# CNCF Files
echo ""
echo "CNCF Compliance:"
[ -f "LICENSE" ] && echo "  ✓ LICENSE" || echo "  ✗ LICENSE"
[ -f "SECURITY.md" ] && echo "  ✓ SECURITY.md" || echo "  ✗ SECURITY.md"
[ -f "CODE_OF_CONDUCT.md" ] && echo "  ✓ CODE_OF_CONDUCT.md" || echo "  ✗ CODE_OF_CONDUCT.md"
[ -f "CONTRIBUTING.md" ] && echo "  ✓ CONTRIBUTING.md" || echo "  ✗ CONTRIBUTING.md"

# CI/CD
echo ""
echo "CI/CD Pipelines:"
[ -f ".github/workflows/ci.yml" ] && echo "  ✓ CI (Super-Linter + tests)" || echo "  ✗ CI"
[ -f ".github/workflows/code-scans.yml" ] && echo "  ✓ SDLE scans" || echo "  ✗ SDLE scans"
[ -f ".github/workflows/release.yml" ] && echo "  ✓ SLSA release" || echo "  ✗ SLSA release"

# Security
echo ""
echo "Security:"
[ -f ".pre-commit-config.yaml" ] && echo "  ✓ Pre-commit hooks" || echo "  ✗ Pre-commit"
[ -f ".github/dependabot.yml" ] && echo "  ✓ Dependabot" || echo "  ✗ Dependabot"

# Helm
echo ""
echo "Kubernetes:"
ls helm/*/Chart.yaml 2>/dev/null && echo "  ✓ Helm charts" || echo "  ✗ No Helm charts"

# Latest scan reports
echo ""
echo "Latest Reports:"
ls -la docs/reports/*.json docs/reports/*.pptx docs/reports/*.md 2>/dev/null || echo "  No reports yet. Run /scan or /compliance-agent"
```

2. Estimate OpenSSF Scorecard based on file presence and CI configuration
3. Suggest next actions for any missing items
