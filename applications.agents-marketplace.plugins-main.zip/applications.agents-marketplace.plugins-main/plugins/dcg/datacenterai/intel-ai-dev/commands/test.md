---
allowed-tools: Bash, Read, Glob, Grep
description: Run tests with coverage for a component
argument-hint: [component-name]
---

# Run Tests

Run tests with coverage for a specific component or all components.

## Steps

1. If `$ARGUMENTS` is provided, run tests for `src/$ARGUMENTS/`
2. If no arguments, discover all components with `tox.ini` and run each

```bash
# Single component
cd src/$ARGUMENTS && tox

# Or with pytest directly
cd src/$ARGUMENTS && pytest tests/ -v --cov=app --cov-report=term-missing --cov-fail-under=85

# All components
for dir in src/*/; do
  if [ -f "$dir/tox.ini" ]; then
    echo "=== Testing $(basename $dir) ==="
    cd "$dir" && tox && cd ../..
  fi
done
```

3. Report: tests passed/failed, coverage percentage, uncovered files
4. Flag if coverage is below 85% target
