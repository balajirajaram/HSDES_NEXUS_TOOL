---
allowed-tools: Bash, Read, Glob, Grep
description: Publish a document to Confluence wiki
argument-hint: [file-path]
---

# Wiki Publish

Publish a markdown document to Confluence.

## Steps

1. If `$ARGUMENTS` is provided, use that as the file path
2. Otherwise, list available documents and let user choose:

```bash
echo "Available documents:"
ls docs/prd/*.md docs/reports/*.md 2>/dev/null
echo ""
echo "Which file to publish?"
```

3. Validate the file exists and is valid markdown
4. Run the publish script:

```bash
python scripts/publish-to-wiki.py "$ARGUMENTS" --space datacenterai
```

5. Report: page URL on success, error details on failure

## Requirements
- `WIKI_BASE_URL` and `WIKI_PAT` environment variables set
- Network access to Confluence (may need VPN)
