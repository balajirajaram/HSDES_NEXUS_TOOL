# Intel AI Solutions Development Pipeline — Architecture Overview

```mermaid
block-beta
    columns 5

    %% Row 1: Developer Input
    block:INPUT:5
        columns 1
        A["DEVELOPER INPUT\nIdea · Workshop Transcript · Technical PRD"]
    end

    %% Row 2: Five Sequential Agents
    block:AGENTS:5
        columns 5
        PRD["/prd-agent\n\nSocratic Q&A →\nTech PRD\n\n12 min"]
        DEV["/dev-agent\n\nScaffold + LLM\nsub-phases\n\n30 min"]
        VAL["/validation\n\nTests · Coverage\nGaps\n\n6 min"]
        COMP["/compliance\n\nOSPDT · SBOM\nScans\n\n5 min"]
        REV["/intel-review\n\nCode review\nC1-C14 · PR check\n\non-demand"]
    end

    %% Row 3: Dev Agent Hybrid Architecture
    space:1
    block:HYBRID:3
        columns 2
        L1["Layer 1: scaffold.py\n\n151 templates · &lt; 3s\n0 LLM context\nDeterministic"]
        L2["Layer 2: LLM Sub-Phases\n\nPhase 4.0 → 4.9\nFocused contexts 10-30KB\nPRD-specific code"]
    end
    space:1

    %% Row 4: Hook Enforcement Layer
    space:1
    block:HOOKS:3
        columns 2
        PRE["PreToolUse\n\n• secret-scanner\n• cmd-blocker\n• rollback-snapshot"]
        POST["PostToolUse\n\n• license-header-check\n• standards-validator"]
    end
    space:1

    %% Row 5: Shared Infrastructure
    block:SHARED:5
        columns 5
        CONTRACTS["6 Contracts\n\n• iter-state\n• output-structure\n• compliance\n• test-report\n• PRD\n• jira-mapping"]
        UX["7 UX Patterns\n\n• human-in-loop\n• resumption\n• checkpoints\n• preflight\n• playwright\n• git-versioning"]
        STANDARDS["13 Standards\n\n• coding · security\n• testing · helm\n• containers · CI/CD\n• observability\n• perf · UX\n• OSPDT · stack"]
        PLUGINS["5 Plugins\n\n• playwright\n• code-review\n• github\n• context7\n• frontend-design"]
        TEMPLATES["151 Templates\n\nBackend (31)\nFrontend (44)\nDocker (3)\nHelm (16)\nCI/CD (10)\nAnsible (11)\nConfig (18)"]
    end

    %% Row 6: Generated Outputs
    block:OUTPUTS:5
        columns 3
        CODE["Project Code\n{project-slug}/\n\n• Backend (FastAPI)\n• Frontend (React)\n• Helm charts\n• Docker configs\n• CI/CD workflows\n• Ansible playbooks"]
        REPORTS["Reports\nreports/\n\n• DASHBOARD.md\n• generation/\n• validation/\n• compliance/\n• architecture/"]
        ARTEFACTS["Compliance Artefacts\n\n• OSPDT BOM (.xlsx)\n• SBOM (CycloneDX)\n• SDLE diagrams\n• License inventory\n• Security scan results"]
    end

    %% Row 7: Integrations
    block:INTEGRATIONS:5
        columns 3
        GH["GitHub\n\n• Push code\n• Create PR\n• Status checks"]
        WIKI["Wiki\n\n• Publish PRD\n• Publish reports\n• WIKI_PAT"]
        JIRA["Jira\n\n• Create epics/stories\n• Update status\n• JIRA_PAT"]
    end

    %% Connections
    INPUT --"▼"--> AGENTS
    AGENTS --"▼"--> HYBRID
    HYBRID --"▼"--> HOOKS
    HOOKS --"▼"--> SHARED
    SHARED --"▼"--> OUTPUTS
    OUTPUTS --"▼"--> INTEGRATIONS

    %% Styles — section blocks
    style INPUT fill:#003580,color:#fff,stroke:#003580
    style AGENTS fill:#0068b5,color:#fff,stroke:#0068b5
    style HYBRID fill:#00c7fd,color:#000,stroke:#00c7fd
    style HOOKS fill:#f5a623,color:#000,stroke:#f5a623
    style SHARED fill:#6c757d,color:#fff,stroke:#6c757d
    style OUTPUTS fill:#28a745,color:#fff,stroke:#28a745
    style INTEGRATIONS fill:#7c3aed,color:#fff,stroke:#7c3aed

    %% Styles — inner nodes
    style A fill:#003580,color:#fff,stroke:#ffffff22
    style PRD fill:#0068b5,color:#fff,stroke:#ffffff33
    style DEV fill:#0068b5,color:#fff,stroke:#ffffff33
    style VAL fill:#0068b5,color:#fff,stroke:#ffffff33
    style COMP fill:#0068b5,color:#fff,stroke:#ffffff33
    style REV fill:#e24b4a,color:#fff,stroke:#ffffff33
    style L1 fill:#00c7fd,color:#000,stroke:#00000022
    style L2 fill:#00c7fd,color:#000,stroke:#00000022
    style PRE fill:#f5a623,color:#000,stroke:#00000022
    style POST fill:#f5a623,color:#000,stroke:#00000022
    style CONTRACTS fill:#6c757d,color:#fff,stroke:#ffffff22
    style UX fill:#6c757d,color:#fff,stroke:#ffffff22
    style STANDARDS fill:#6c757d,color:#fff,stroke:#ffffff22
    style PLUGINS fill:#6c757d,color:#fff,stroke:#ffffff22
    style TEMPLATES fill:#6c757d,color:#fff,stroke:#ffffff22
    style CODE fill:#28a745,color:#fff,stroke:#ffffff22
    style REPORTS fill:#28a745,color:#fff,stroke:#ffffff22
    style ARTEFACTS fill:#28a745,color:#fff,stroke:#ffffff22
    style GH fill:#7c3aed,color:#fff,stroke:#ffffff22
    style WIKI fill:#7c3aed,color:#fff,stroke:#ffffff22
    style JIRA fill:#7c3aed,color:#fff,stroke:#ffffff22
```
