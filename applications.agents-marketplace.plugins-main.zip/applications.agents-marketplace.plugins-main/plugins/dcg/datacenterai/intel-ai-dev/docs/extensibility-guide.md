# Extensibility Guide

This guide explains how to extend the `intel-ai-dev` plugin with new
components. The plugin is modular by design — each component type has a
defined location, structure, and registration path.

---

## Component overview

| Component | Location | Registration |
|---|---|---|
| Skill | `.claude/skills/<name>/SKILL.md` | `plugin.json` → `"skills"` field |
| Agent (sub-specialist) | `.claude/agents/<name>.md` | `plugin.json` → `"agents"` field |
| Command | `.claude/commands/<name>.md` | `plugin.json` → `"commands"` field |
| Standard | `.claude/shared/standards/<name>.md` | Referenced by skills on demand |
| Contract | `.claude/shared/contracts/<name>.md` | Referenced by skills on demand |
| Hook | `.claude/hooks/<name>.py` + `hooks.json` | `hooks.json` entry |
| UX Pattern | `.claude/shared/ux/<name>.md` | Referenced by skills on demand |
| Reference | `.claude/shared/references/<name>.md` | Referenced by skills on demand |

---

## 1. Creating a new skill

Skills are the primary agents in the plugin. Each skill is a self-contained
SKILL.md that defines the agent's behavior, phases, and outputs.

### Directory structure

```
.claude/skills/<skill-name>/
├── SKILL.md                          # Main skill definition (required)
└── references/                       # Optional sub-phase docs
    └── sub-phases/
        ├── phase-1-something.md
        └── phase-2-something.md
```

### SKILL.md structure

```markdown
---
name: <skill-name>
description: <one-line description used for trigger matching>
---

# <Skill Title>

## Trigger
When to invoke this skill (keywords, user intents).

## Phase 0 — Session Recovery
Check for `.iteration-state.json`, resume if found.

## Phase 1 — <First Phase>
What this phase does, approval gates, outputs.

## Phase N — <Last Phase>
Final phase, summary, handoff.

## Contracts referenced
- `contracts/<name>.md` — what data it reads/writes

## Standards enforced
- `standards/<name>.md` — which standards apply
```

### Key principles

- **Progressive loading**: Only load sub-phase reference files when entering
  that phase — never pre-load all phases at once.
- **Human-in-the-loop**: Announce intent → wait for approval → execute →
  summarize. Every phase.
- **Session recovery**: Always check `.iteration-state.json` in Phase 0.
- **Contract compliance**: Read from and write to defined contract schemas so
  downstream skills can consume your outputs.

### Registration

Skills are auto-discovered from the `"skills"` directory in `plugin.json`.
No additional registration needed — placing the `SKILL.md` in the correct
directory is sufficient.

### Chaining with existing skills

If your skill should run after another skill in the pipeline:
1. Read the upstream skill's output contract (e.g., `prd-output-schema.md`)
2. Define your input expectations in your SKILL.md
3. Write your output to a defined contract so downstream skills can consume it

---

## 2. Adding new agents (sub-specialists)

Agents are lightweight specialists that skills delegate to for focused tasks.

### File structure

```
.claude/agents/<agent-name>.md
```

### Agent .md structure

```markdown
---
name: <agent-name>
description: <one-line description>
---

# <Agent Title>

## Purpose
What this agent specializes in.

## Inputs
What it expects (file paths, context, parameters).

## Checks performed
Numbered list of what it validates or produces.

## Output format
What it returns to the calling skill.
```

### How skills delegate to agents

Skills invoke sub-specialist agents for focused validation. The agent
definition provides the system prompt and behavioral contract. Skills
reference agents by name in their SKILL.md:

```markdown
## Phase N — Validation
Delegate Docker compliance to `dockerfile-reviewer` agent.
Delegate Helm validation to `helm-validator` agent.
```

### Registration

Agents are auto-discovered from the `"agents"` directory in `plugin.json`.

---

## 3. Adding new commands

Commands are quick-action shortcuts users invoke directly.

### File structure

```
.claude/commands/<command-name>.md
```

### Command .md structure

```markdown
---
name: <command-name>
description: <one-line description>
---

# /<command-name>

## What it does
Brief description.

## Arguments
- `$1` — optional: component name or file path

## Steps
1. What the command does step by step
2. ...

## Output
What the user sees on completion.
```

### Registration

Commands are auto-discovered from the `"commands"` directory in `plugin.json`.

---

## 4. Adding new standards

Standards define coding, security, and architectural rules that skills enforce.

### Worked example: how Enterprise Inference was added

1. Created `.claude/shared/references/enterprise-inference.md` with EI-specific
   patterns (vLLM deployment, co-deployment, endpoint configuration)
2. Skills reference it conditionally — only loaded when the user selects EI as
   their inference backend during PRD generation
3. The standards themselves (`coding-standards.md`, `security-practices.md`,
   etc.) remain generic — they encode the patterns regardless of origin

### Adding a new standard

1. Create `.claude/shared/standards/<name>.md`
2. Structure it with clear, enforceable rules:

```markdown
# <Standard Name>

## Rules

### S1 — <Rule name>
**What**: What must be true.
**Why**: Rationale.
**Check**: How to verify (command, grep pattern, or manual check).

### S2 — <Rule name>
...
```

3. Reference it from skills that should enforce it:

```markdown
## Standards enforced
- `standards/<your-new-standard>.md`
```

4. Optionally add a validation hook (see section 6) for automatic enforcement.

### No registration needed

Standards are loaded on demand by skills. No `plugin.json` change required.

---

## 5. Adding new contracts

Contracts define machine-readable schemas for data passed between skills.

### File structure

```
.claude/shared/contracts/<name>-schema.md
```

### Contract .md structure

```markdown
# <Contract Name> Schema

## Purpose
What data this contract carries and which skills produce/consume it.

## Producer
Which skill writes this data.

## Consumer(s)
Which skills read this data.

## Schema

```json
{
  "field_name": "type — description",
  ...
}
```

## Example

```json
{
  "field_name": "actual value example"
}
```
```

### Connecting to skills

In your SKILL.md, declare:

```markdown
## Contracts
- **Produces**: `contracts/<your-contract>-schema.md`
- **Consumes**: `contracts/<upstream-contract>-schema.md`
```

This makes the data flow between skills explicit and debuggable.

---

## 6. Adding new hooks

Hooks enforce rules automatically before or after tool operations.

### File structure

```
.claude/hooks/<hook-name>.py      # The hook logic
.claude/hooks/hooks.json          # Registration file
```

### Hook types

| Type | When it runs | Use case |
|---|---|---|
| `PreToolUse` | Before a tool executes | Block dangerous commands, scan for secrets |
| `PostToolUse` | After a tool completes | Validate written files, check headers |

### Hook .py structure

```python
#!/usr/bin/env python3
"""<Brief description of what this hook enforces>."""

import json
import sys


def main():
    # Read hook input from stdin
    input_data = json.loads(sys.stdin.read())

    tool_name = input_data.get("tool_name", "")
    tool_input = input_data.get("tool_input", {})

    # Your validation logic here
    # ...

    # Output: pass (allow) or block (deny with reason)
    if violation_found:
        result = {
            "decision": "block",
            "reason": "Human-readable explanation of why this was blocked"
        }
    else:
        result = {"decision": "allow"}

    print(json.dumps(result))


if __name__ == "__main__":
    main()
```

### Registering in hooks.json

Add your hook entry to `.claude/hooks/hooks.json`:

```json
{
  "hooks": [
    {
      "type": "PreToolUse",
      "command": "python ${CLAUDE_PLUGIN_ROOT}/.claude/hooks/<hook-name>.py",
      "description": "<What this hook enforces>"
    }
  ]
}
```

### Guidelines

- Hooks must be fast (< 2 seconds) — they run on every matching tool call
- Return `{"decision": "allow"}` to pass through silently
- Return `{"decision": "block", "reason": "..."}` to prevent execution
- Keep hook logic focused — one concern per hook
- Test hooks independently: `echo '{"tool_name":"Bash","tool_input":{"command":"rm -rf /"}}' | python your-hook.py`

---

## 7. Adding or modifying UX patterns

UX patterns define interaction behaviors shared across multiple skills.

### File structure

```
.claude/shared/ux/<pattern-name>.md
```

### UX pattern structure

```markdown
# <Pattern Name>

## When to apply
Which skills or phases use this pattern.

## Behavior
Step-by-step interaction flow.

## Example
Concrete example of the pattern in action.
```

### Existing patterns

| Pattern | Purpose |
|---|---|
| `human-in-the-loop.md` | Announce → approve → execute → summarize |
| `resumption-pattern.md` | Session recovery from `.iteration-state.json` |
| `program-checkpoints.md` | Deep reasoning pauses at critical decisions |
| `preflight-checks.md` | Environment verification before execution |
| `output-directory-selection.md` | Where generated files go |
| `git-versioning.md` | When and how to commit during generation |
| `iteration-summary-template.md` | End-of-phase summary format |

### Modifying existing patterns safely

1. Read the pattern file to understand current behavior
2. Check which skills reference it: `grep -r "<pattern-name>" .claude/skills/`
3. Make your change — ensure it's backward compatible with all referencing skills
4. If the change is breaking, update all referencing skills in the same commit

### Adding a new pattern

1. Create `.claude/shared/ux/<pattern-name>.md`
2. Reference it from skills that should follow it:

```markdown
## UX patterns followed
- `ux/<your-pattern-name>.md`
```

---

## Summary: adding a complete new capability

To add a full new capability (e.g., a "performance-benchmarking" phase):

1. **Skill**: `.claude/skills/benchmark-agent/SKILL.md` — defines the agent
2. **Contract**: `.claude/shared/contracts/benchmark-report-schema.md` — output format
3. **Standard** (if needed): `.claude/shared/standards/performance-benchmarks.md`
4. **Agent** (if needed): `.claude/agents/load-tester.md` — sub-specialist
5. **Command** (if needed): `.claude/commands/benchmark.md` — quick action
6. **Hook** (if needed): `.claude/hooks/resource-limit-check.py` — safety gate

All components are independent — add only what you need. The plugin discovers
them automatically from their file locations.
