#!/usr/bin/env python3
# Copyright (C) 2024 Intel Corporation
# SPDX-License-Identifier: Apache-2.0
"""Export PRD Feature Breakdown to Jira as EPICs and Stories.

Interactive mode: asks for assignee IDSID, component, fix version, sprint,
and parent epic before creating tickets. Use --non-interactive for CI/CD.
"""

import argparse
import json
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from lib.jira_client import (
    assign_to_sprint,
    create_epic,
    create_story,
    get_project_components,
    get_project_versions,
)


def extract_epics_and_stories(breakdown_path: str) -> list[dict]:
    content = Path(breakdown_path).read_text(encoding="utf-8")
    epics = []
    current_epic = None
    current_story = None

    for line in content.split("\n"):
        if line.startswith("## Epic") or re.match(r"^## \d+\.", line):
            if current_epic:
                epics.append(current_epic)
            title = re.sub(r"^##\s*(Epic\s*\d*[:.]?\s*)?", "", line).strip()
            current_epic = {"title": title, "stories": [], "priority": "Medium"}
            current_story = None
        elif line.startswith("### ") and current_epic:
            title = line.lstrip("# ").strip()
            current_story = {
                "title": title,
                "acceptance_criteria": [],
                "effort": 3,
                "description": "",
            }
            current_epic["stories"].append(current_story)
        elif current_story and line.strip().startswith("- [ ]"):
            current_story["acceptance_criteria"].append(line.strip()[5:].strip())
        elif current_story and line.strip().startswith("- "):
            criterion = line.strip()[2:]
            if "acceptance" not in criterion.lower():
                current_story["acceptance_criteria"].append(criterion)
        elif re.match(r".*priority.*:.*P0", line, re.IGNORECASE) and current_epic:
            current_epic["priority"] = "Highest"
        elif re.match(r".*priority.*:.*P1", line, re.IGNORECASE) and current_epic:
            current_epic["priority"] = "High"

    if current_epic:
        epics.append(current_epic)
    return epics


def collect_user_inputs(project: str) -> dict:
    """Interactively collect required Jira fields from the user."""
    print("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
    print("JIRA TICKET CONFIGURATION")
    print("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n")

    # Assignee
    assignee = input("Assignee IDSID (e.g., vivekrs): ").strip()
    if not assignee:
        print("WARNING: No assignee provided — tickets will be unassigned")
        assignee = None

    # Components
    print("\nFetching project components...")
    components = get_project_components(project)
    component_id = None
    if components:
        print("\nAvailable components:")
        for i, c in enumerate(components, 1):
            print(f"  {i}. {c['name']} (id: {c['id']})")
        choice = input(f"\nSelect component [1-{len(components)}] or press Enter to skip: ").strip()
        if choice.isdigit() and 1 <= int(choice) <= len(components):
            component_id = components[int(choice) - 1]["id"]
            print(f"  Selected: {components[int(choice) - 1]['name']}")
    else:
        print("  No components found — skipping")

    # Fix Version
    print("\nFetching unreleased versions...")
    versions = get_project_versions(project)
    fix_version_id = None
    if versions:
        print("\nAvailable versions:")
        for i, v in enumerate(versions, 1):
            print(f"  {i}. {v['name']} (id: {v['id']})")
        choice = input(f"\nSelect fix version [1-{len(versions)}] or press Enter to skip: ").strip()
        if choice.isdigit() and 1 <= int(choice) <= len(versions):
            fix_version_id = versions[int(choice) - 1]["id"]
            print(f"  Selected: {versions[int(choice) - 1]['name']}")
    else:
        print("  No unreleased versions found — skipping")

    # Sprint
    sprint_id = None
    sprint_input = input("\nSprint ID (number, or press Enter to skip): ").strip()
    if sprint_input.isdigit():
        sprint_id = int(sprint_input)

    # Parent Epic (for stories created without their own epic)
    parent_epic = input("\nParent Epic key (e.g., DCAIDSE8-1676, or press Enter for new epic): ").strip()
    if parent_epic and not re.match(r"^[A-Z]+-\d+$", parent_epic):
        print(f"  WARNING: '{parent_epic}' doesn't look like a valid key — ignoring")
        parent_epic = None

    # Story Points default
    default_points = input("\nDefault story points per story (default: 3): ").strip()
    default_points = int(default_points) if default_points.isdigit() else 3

    print("\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
    print("CONFIGURATION SUMMARY")
    print("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
    print(f"  Assignee:    {assignee or '(unassigned)'}")
    print(f"  Component:   {component_id or '(none)'}")
    print(f"  Fix Version: {fix_version_id or '(none)'}")
    print(f"  Sprint:      {sprint_id or '(backlog)'}")
    print(f"  Parent Epic: {parent_epic or '(will create new)'}")
    print(f"  Story Points: {default_points}")
    print("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n")

    confirm = input("Proceed? (yes/no): ").strip().lower()
    if confirm not in ("y", "yes"):
        print("Aborted.")
        sys.exit(0)

    return {
        "assignee": assignee,
        "component_id": component_id,
        "fix_version_id": fix_version_id,
        "sprint_id": sprint_id,
        "parent_epic": parent_epic,
        "default_points": default_points,
    }


def dry_run(epics: list[dict]) -> None:
    print("=== Jira Export — Dry Run ===\n")
    for i, epic in enumerate(epics, 1):
        print(f"EPIC {i}: {epic['title']} (Priority: {epic['priority']})")
        for j, story in enumerate(epic["stories"], 1):
            print(f"  Story {i}.{j}: {story['title']}")
            for ac in story["acceptance_criteria"]:
                print(f"    - {ac}")
        print()
    total_stories = sum(len(e["stories"]) for e in epics)
    print(f"Total: {len(epics)} EPICs, {total_stories} Stories")


def export_to_jira(epics: list[dict], project: str, user_config: dict) -> dict:
    results = {"epics_created": [], "stories_created": []}
    all_story_keys = []

    components = [user_config["component_id"]] if user_config.get("component_id") else None

    for epic in epics:
        # Use parent_epic if provided, otherwise create a new one
        if user_config.get("parent_epic"):
            epic_key = user_config["parent_epic"]
            print(f"Using existing EPIC: {epic_key} for '{epic['title']}'")
        else:
            data = create_epic(
                project_key=project,
                summary=epic["title"],
                description=f"Priority: {epic['priority']}",
                assignee=user_config.get("assignee"),
                components=components,
                fix_version_id=user_config.get("fix_version_id"),
            )
            epic_key = data.get("key")
            if not epic_key:
                print(f"ERROR: Failed to create epic '{epic['title']}' — skipping its stories")
                continue
            results["epics_created"].append({"key": epic_key, "summary": epic["title"]})

        for story in epic["stories"]:
            ac_text = "\n".join(f"- {ac}" for ac in story["acceptance_criteria"])
            description = f"{story['title']}\n\n## Acceptance Criteria\n{ac_text}"

            data = create_story(
                project_key=project,
                summary=story["title"],
                description=description,
                epic_key=epic_key,
                assignee=user_config.get("assignee"),
                components=components,
                fix_version_id=user_config.get("fix_version_id"),
                story_points=user_config.get("default_points", 3),
                acceptance_criteria=ac_text,
            )
            story_key = data.get("key")
            if story_key:
                results["stories_created"].append({
                    "key": story_key,
                    "epic": epic_key,
                    "summary": story["title"],
                })
                all_story_keys.append(story_key)

    # Assign to sprint if specified
    if user_config.get("sprint_id") and all_story_keys:
        print(f"\nAssigning {len(all_story_keys)} stories to sprint {user_config['sprint_id']}...")
        success = assign_to_sprint(user_config["sprint_id"], all_story_keys)
        if success:
            print("  Sprint assignment: OK")
        else:
            print("  Sprint assignment: FAILED — assign manually in Jira board")

    print(f"\nDone: {len(results['epics_created'])} EPICs, {len(results['stories_created'])} Stories")
    return results


def main():
    parser = argparse.ArgumentParser(description="Export PRD breakdown to Jira")
    parser.add_argument("breakdown_file", help="Path to feature breakdown markdown")
    parser.add_argument("--project", default="DCAIDSE8", help="Jira project key")
    parser.add_argument("--dry-run", action="store_true", help="Preview without creating")
    parser.add_argument("--non-interactive", action="store_true",
                        help="Skip interactive prompts (use defaults)")
    parser.add_argument("--assignee", help="Assignee IDSID (non-interactive mode)")
    parser.add_argument("--epic", help="Parent epic key (non-interactive mode)")
    parser.add_argument("--sprint", type=int, help="Sprint ID (non-interactive mode)")
    parser.add_argument("--component", help="Component ID (non-interactive mode)")
    parser.add_argument("--fix-version", help="Fix version ID (non-interactive mode)")
    parser.add_argument("--story-points", type=int, default=3,
                        help="Default story points (non-interactive mode)")
    args = parser.parse_args()

    if not Path(args.breakdown_file).exists():
        print(f"Error: {args.breakdown_file} not found")
        sys.exit(1)

    epics = extract_epics_and_stories(args.breakdown_file)

    if not epics:
        print("No epics found in breakdown file")
        sys.exit(1)

    if args.dry_run:
        dry_run(epics)
    elif args.non_interactive:
        user_config = {
            "assignee": args.assignee,
            "component_id": args.component,
            "fix_version_id": args.fix_version,
            "sprint_id": args.sprint,
            "parent_epic": args.epic,
            "default_points": args.story_points,
        }
        results = export_to_jira(epics, args.project, user_config)
        print(json.dumps(results, indent=2))
    else:
        user_config = collect_user_inputs(args.project)
        results = export_to_jira(epics, args.project, user_config)
        print(json.dumps(results, indent=2))


if __name__ == "__main__":
    main()
