#!/usr/bin/env python3
# Copyright (C) 2026 Intel Corporation
# SPDX-License-Identifier: Apache-2.0
"""Fill DASHBOARD.md.tmpl with data from generated reports."""

import argparse
import json
import shutil
import subprocess
import sys
from datetime import datetime
from pathlib import Path


def check_tool(name: str) -> tuple[bool, str]:
    """Check if a CLI tool is available and return version."""
    try:
        result = subprocess.run(
            [name, "--version"], capture_output=True, text=True, timeout=5
        )
        version = result.stdout.strip().split("\n")[0] if result.returncode == 0 else "N/A"
        return result.returncode == 0, version
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return False, "N/A"


def read_report_status(reports_dir: Path, path: str) -> str:
    """Check if a report file exists and return status."""
    full_path = reports_dir / path
    if full_path.exists() and full_path.stat().st_size > 0:
        return "DONE"
    return "PENDING"


def count_findings(reports_dir: Path) -> int:
    """Count security findings from scan report."""
    scan_file = reports_dir / "compliance" / "security-scan.md"
    if not scan_file.exists():
        return 0
    content = scan_file.read_text(encoding="utf-8")
    count = content.count("| HIGH") + content.count("| CRITICAL")
    return count


def count_copyleft(reports_dir: Path) -> int:
    """Count copyleft licenses from inventory."""
    license_file = reports_dir / "compliance" / "license-inventory.md"
    if not license_file.exists():
        return 0
    content = license_file.read_text(encoding="utf-8")
    return content.lower().count("gpl")


def get_test_coverage(reports_dir: Path) -> str:
    """Extract coverage percentage from test results."""
    test_file = reports_dir / "validation" / "test-results.md"
    if not test_file.exists():
        return "—"
    content = test_file.read_text(encoding="utf-8")
    for line in content.split("\n"):
        if "coverage" in line.lower() and "%" in line:
            for part in line.split():
                if "%" in part:
                    return part.replace("%", "").replace("|", "").strip()
    return "—"


def count_lint_issues(reports_dir: Path) -> str:
    """Count lint issues from lint report."""
    lint_file = reports_dir / "validation" / "lint-results.md"
    if not lint_file.exists():
        return "—"
    content = lint_file.read_text(encoding="utf-8")
    for line in content.split("\n"):
        if "total" in line.lower() and ("issue" in line.lower() or "error" in line.lower()):
            for part in line.split():
                if part.isdigit():
                    return part
    return "0"


def count_diagrams(reports_dir: Path) -> int:
    """Count generated architecture diagrams."""
    arch_dir = reports_dir / "architecture"
    if not arch_dir.exists():
        return 0
    return len(list(arch_dir.glob("*.md")))


def count_generated_files(reports_dir: Path) -> str:
    """Get file count from generation manifest."""
    manifest = reports_dir / "generation" / "file-manifest.json"
    if manifest.exists():
        try:
            data = json.loads(manifest.read_text(encoding="utf-8"))
            if isinstance(data, list):
                return str(len(data))
            if isinstance(data, dict) and "files" in data:
                return str(len(data["files"]))
        except (json.JSONDecodeError, KeyError):
            pass
    return "—"


def main():
    parser = argparse.ArgumentParser(description="Generate DASHBOARD.md from reports")
    parser.add_argument("--reports-dir", required=True, help="Path to reports/ directory")
    parser.add_argument("--template", default=None, help="Path to DASHBOARD.md.tmpl")
    parser.add_argument("--project-name", required=True, help="Project display name")
    parser.add_argument("--output", default=None, help="Output path (default: reports/DASHBOARD.md)")
    args = parser.parse_args()

    reports_dir = Path(args.reports_dir)
    if not reports_dir.exists():
        print(f"Error: reports directory not found: {reports_dir}", file=sys.stderr)
        sys.exit(1)

    # Find template
    if args.template:
        template_path = Path(args.template)
    else:
        script_dir = Path(__file__).parent.parent
        template_path = script_dir / "templates" / "dashboard" / "DASHBOARD.md.tmpl"

    if not template_path.exists():
        print(f"Error: template not found: {template_path}", file=sys.stderr)
        sys.exit(1)

    template = template_path.read_text(encoding="utf-8")

    # Check tool availability
    tools = ["ruff", "mypy", "bandit", "trivy", "pip-audit", "pip-licenses", "detect-secrets", "helm", "docker"]
    tool_status = {}
    for tool in tools:
        available, version = check_tool(tool)
        tool_key = tool.replace("-", "_")
        tool_status[f"{tool_key}_available"] = "Yes" if available else "No"
        tool_status[f"{tool_key}_version"] = version if available else "—"

    # python-pptx check (Python module, not CLI)
    try:
        import importlib
        pptx = importlib.import_module("pptx")
        tool_status["python_pptx_available"] = "Yes"
        tool_status["python_pptx_version"] = getattr(pptx, "__version__", "installed")
    except ImportError:
        tool_status["python_pptx_available"] = "No"
        tool_status["python_pptx_version"] = "—"

    # Gather metrics
    test_coverage = get_test_coverage(reports_dir)
    lint_issues = count_lint_issues(reports_dir)
    security_findings = count_findings(reports_dir)
    copyleft_count = count_copyleft(reports_dir)
    diagram_count = count_diagrams(reports_dir)
    files_generated = count_generated_files(reports_dir)

    # Status per phase
    prd_status = read_report_status(reports_dir, "generation/generation-summary.md")
    generation_status = read_report_status(reports_dir, "generation/file-manifest.json")
    validation_status = read_report_status(reports_dir, "validation/test-results.md")
    lint_status = read_report_status(reports_dir, "validation/lint-results.md")
    security_status = read_report_status(reports_dir, "compliance/security-scan.md")
    license_status = read_report_status(reports_dir, "compliance/license-inventory.md")
    slsa_status = read_report_status(reports_dir, "compliance/slsa-checklist.md")
    architecture_status = "DONE" if diagram_count > 0 else "PENDING"
    ospdt_status = read_report_status(reports_dir, "compliance/ospdt-deck.pptx")

    # Build substitution map
    variables = {
        "project_name": args.project_name,
        "generation_date": datetime.now().strftime("%Y-%m-%d %H:%M"),
        "pipeline_version": "1.0.0",
        "current_iteration": "1" if security_status == "PENDING" else "2",
        "prd_status": prd_status,
        "prd_metric": "Technical PRD" if prd_status == "DONE" else "—",
        "generation_status": generation_status,
        "files_generated": files_generated,
        "validation_status": validation_status,
        "test_coverage": test_coverage,
        "lint_status": lint_status,
        "lint_issues": lint_issues,
        "security_status": security_status,
        "security_findings": str(security_findings),
        "license_status": license_status,
        "copyleft_count": str(copyleft_count),
        "slsa_status": slsa_status,
        "slsa_level": "2" if slsa_status == "DONE" else "—",
        "architecture_status": architecture_status,
        "diagram_count": str(diagram_count),
        "ospdt_status": ospdt_status,
        "ospdt_recommendation": "APPROVE" if security_findings == 0 else "CONDITIONAL",
        "iteration_1_status": "COMPLETE" if validation_status == "DONE" else "IN PROGRESS",
        "iteration_1_covered": "- Code generation\n- Lint & type checks\n- Unit/integration tests\n- License inventory",
        "iteration_1_skipped": "- Container scanning (requires Docker)\n- OSPDT deck (requires python-pptx)\n- Image signing (requires cosign)",
        "iteration_2_status": "PENDING",
        "iteration_2_prerequisites": "- Docker installed and running\n- python-pptx pip package\n- Trivy scanner\n- cosign for image signing",
        "iteration_2_scope": "- Container image scanning\n- Full SBOM generation\n- OSPDT PowerPoint deck\n- Image signing verification",
        "next_steps": "1. Review security findings and apply fixes\n2. Install missing tools for Iteration 2\n3. Run compliance-agent again with full tooling\n4. Submit OSPDT deck for review",
        **tool_status,
    }

    # Substitute variables
    output = template
    for key, value in variables.items():
        output = output.replace("{{" + key + "}}", value)

    # Write output
    output_path = Path(args.output) if args.output else reports_dir / "DASHBOARD.md"
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(output, encoding="utf-8")
    print(f"Dashboard generated: {output_path}")


if __name__ == "__main__":
    main()
