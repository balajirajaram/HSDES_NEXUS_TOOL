"""Generate polished PPTX: Dev-Agent Architecture — Claude Code Internals."""

from pptx import Presentation
from pptx.util import Inches, Pt, Emu
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
from pptx.enum.shapes import MSO_SHAPE
import os

# Intel brand colors
INTEL_BLUE = RGBColor(0x00, 0x71, 0xC5)
INTEL_DARK = RGBColor(0x00, 0x3C, 0x71)
INTEL_LIGHT = RGBColor(0xE8, 0xF0, 0xFE)
INTEL_GRAY = RGBColor(0x4A, 0x4A, 0x4A)
INTEL_WHITE = RGBColor(0xFF, 0xFF, 0xFF)
INTEL_GREEN = RGBColor(0x00, 0xA3, 0x5E)
INTEL_ORANGE = RGBColor(0xF5, 0x82, 0x20)
INTEL_RED = RGBColor(0xE0, 0x30, 0x30)
CODE_BG = RGBColor(0x1E, 0x1E, 0x2E)
CODE_FG = RGBColor(0xCD, 0xD6, 0xF4)

prs = Presentation()
prs.slide_width = Inches(13.333)
prs.slide_height = Inches(7.5)

SLIDE_W = Inches(13.333)
SLIDE_H = Inches(7.5)


def add_bg(slide, color=INTEL_DARK):
    """Set slide background color."""
    bg = slide.background
    fill = bg.fill
    fill.solid()
    fill.fore_color.rgb = color


def add_text_box(slide, left, top, width, height, text, font_size=14,
                 bold=False, color=INTEL_WHITE, align=PP_ALIGN.LEFT,
                 font_name='Segoe UI'):
    """Add a text box with specified formatting."""
    txBox = slide.shapes.add_textbox(left, top, width, height)
    tf = txBox.text_frame
    tf.word_wrap = True
    tf.auto_size = None
    p = tf.paragraphs[0]
    p.text = text
    p.font.size = Pt(font_size)
    p.font.bold = bold
    p.font.color.rgb = color
    p.font.name = font_name
    p.alignment = align
    return txBox


def add_multi_text(slide, left, top, width, height, lines, font_size=12,
                   color=INTEL_WHITE, font_name='Segoe UI', line_spacing=1.2):
    """Add text box with multiple lines."""
    txBox = slide.shapes.add_textbox(left, top, width, height)
    tf = txBox.text_frame
    tf.word_wrap = True
    for i, (text, is_bold, txt_color) in enumerate(lines):
        if i == 0:
            p = tf.paragraphs[0]
        else:
            p = tf.add_paragraph()
        p.text = text
        p.font.size = Pt(font_size)
        p.font.bold = is_bold
        p.font.color.rgb = txt_color or color
        p.font.name = font_name
        p.space_after = Pt(font_size * (line_spacing - 1) + 2)
    return txBox


def add_code_box(slide, left, top, width, height, text, font_size=10):
    """Add a code-styled text box."""
    shape = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, left, top, width, height)
    shape.fill.solid()
    shape.fill.fore_color.rgb = CODE_BG
    shape.line.fill.background()
    tf = shape.text_frame
    tf.word_wrap = True
    tf.margin_left = Pt(12)
    tf.margin_top = Pt(8)
    p = tf.paragraphs[0]
    p.text = text
    p.font.size = Pt(font_size)
    p.font.color.rgb = CODE_FG
    p.font.name = 'Cascadia Code'
    return shape


def add_box(slide, left, top, width, height, fill_color, border_color=None, text="",
            font_size=11, font_color=INTEL_WHITE, align=PP_ALIGN.CENTER):
    """Add a rounded rectangle with optional text."""
    shape = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, left, top, width, height)
    shape.fill.solid()
    shape.fill.fore_color.rgb = fill_color
    if border_color:
        shape.line.color.rgb = border_color
        shape.line.width = Pt(1.5)
    else:
        shape.line.fill.background()
    if text:
        tf = shape.text_frame
        tf.word_wrap = True
        tf.vertical_anchor = MSO_ANCHOR.MIDDLE
        tf.margin_left = Pt(6)
        tf.margin_right = Pt(6)
        p = tf.paragraphs[0]
        p.text = text
        p.font.size = Pt(font_size)
        p.font.color.rgb = font_color
        p.font.name = 'Segoe UI'
        p.font.bold = True
        p.alignment = align
    return shape


def add_section_header(slide, title, subtitle=""):
    """Add consistent section header."""
    add_bg(slide, INTEL_DARK)
    add_text_box(slide, Inches(0.8), Inches(0.4), Inches(11), Inches(0.6),
                 title, font_size=28, bold=True, color=INTEL_WHITE)
    if subtitle:
        add_text_box(slide, Inches(0.8), Inches(1.0), Inches(11), Inches(0.4),
                     subtitle, font_size=14, color=RGBColor(0xA0, 0xC0, 0xE0))
    # Bottom accent line
    shape = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(0.8), Inches(1.45), Inches(2), Pt(3))
    shape.fill.solid()
    shape.fill.fore_color.rgb = INTEL_BLUE
    shape.line.fill.background()


# ══════════════════════════════════════════════════════════════════
# SLIDE 1: Title
# ══════════════════════════════════════════════════════════════════
slide = prs.slides.add_slide(prs.slide_layouts[6])
add_bg(slide, INTEL_DARK)

add_text_box(slide, Inches(1), Inches(1.8), Inches(11), Inches(1.2),
             "Dev-Agent Architecture", font_size=44, bold=True, color=INTEL_WHITE)
add_text_box(slide, Inches(1), Inches(3.0), Inches(11), Inches(0.8),
             "How Claude Code Skills, Hooks, Standards & Contracts\nOrchestrate Production Code Generation",
             font_size=20, color=RGBColor(0xA0, 0xC0, 0xE0))
add_text_box(slide, Inches(1), Inches(5.5), Inches(11), Inches(0.5),
             "Intel AI Solutions Engineering  |  May 2026",
             font_size=14, color=RGBColor(0x80, 0x90, 0xA0))

# Accent bar
shape = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(1), Inches(4.2), Inches(3), Pt(4))
shape.fill.solid()
shape.fill.fore_color.rgb = INTEL_BLUE
shape.line.fill.background()

# ══════════════════════════════════════════════════════════════════
# SLIDE 2: What is Claude Code?
# ══════════════════════════════════════════════════════════════════
slide = prs.slides.add_slide(prs.slide_layouts[6])
add_section_header(slide, "What is Claude Code?", "The AI-powered development platform")

items = [
    ("CLI / Desktop / IDE Extension", "Anthropic's agentic coding tool — runs in terminal, VS Code, JetBrains"),
    ("Context-Aware", "Reads your project structure, CLAUDE.md, git history — understands the codebase"),
    ("Tool Use", "Read, Write, Edit files + Execute commands + Web access"),
    ("Extensible", "Skills, Commands, Hooks, Permissions — fully customizable per project"),
    ("Persistent", "Memory system + iteration state — resume across sessions"),
]

y = Inches(1.8)
for title, desc in items:
    add_box(slide, Inches(0.8), y, Inches(0.3), Inches(0.3), INTEL_BLUE, text="")
    add_text_box(slide, Inches(1.3), y - Pt(2), Inches(4), Inches(0.35),
                 title, font_size=14, bold=True, color=INTEL_WHITE)
    add_text_box(slide, Inches(1.3), y + Inches(0.3), Inches(10.5), Inches(0.35),
                 desc, font_size=12, color=RGBColor(0xCC, 0xCC, 0xCC))
    y += Inches(1.0)

# ══════════════════════════════════════════════════════════════════
# SLIDE 3: Platform Component Map
# ══════════════════════════════════════════════════════════════════
slide = prs.slides.add_slide(prs.slide_layouts[6])
add_section_header(slide, "Claude Code Component Map", "4 layers that work together")

# Layer 1: Always Loaded
add_box(slide, Inches(0.5), Inches(1.7), Inches(12.3), Inches(1.1),
        RGBColor(0x1A, 0x4A, 0x7A), INTEL_BLUE,
        text="", font_size=10)
add_text_box(slide, Inches(0.7), Inches(1.75), Inches(3), Inches(0.3),
             "ALWAYS LOADED", font_size=10, bold=True, color=INTEL_BLUE)

add_box(slide, Inches(0.8), Inches(2.1), Inches(2.5), Inches(0.55),
        RGBColor(0x0A, 0x5A, 0x9A), text="CLAUDE.md\n(project context)", font_size=9)
add_box(slide, Inches(3.6), Inches(2.1), Inches(2.8), Inches(0.55),
        RGBColor(0x0A, 0x5A, 0x9A), text="settings.json\n(permissions + hooks)", font_size=9)
add_box(slide, Inches(6.7), Inches(2.1), Inches(2.8), Inches(0.55),
        RGBColor(0x0A, 0x5A, 0x9A), text="Claude Memory\n(cross-session state)", font_size=9)
add_box(slide, Inches(9.8), Inches(2.1), Inches(2.8), Inches(0.55),
        RGBColor(0x0A, 0x5A, 0x9A), text=".iteration-state.json\n(progress tracker)", font_size=9)

# Layer 2: On-Invoke
add_box(slide, Inches(0.5), Inches(3.0), Inches(12.3), Inches(1.1),
        RGBColor(0x1A, 0x3A, 0x5A), INTEL_BLUE,
        text="", font_size=10)
add_text_box(slide, Inches(0.7), Inches(3.05), Inches(4), Inches(0.3),
             "ON-INVOKE (when /command typed)", font_size=10, bold=True, color=INTEL_BLUE)

add_box(slide, Inches(0.8), Inches(3.4), Inches(3.8), Inches(0.55),
        INTEL_GREEN, text="SKILLS (multi-phase playbooks)\n/dev, /prd, /validation, /compliance", font_size=9)
add_box(slide, Inches(4.9), Inches(3.4), Inches(3.8), Inches(0.55),
        RGBColor(0x00, 0x7A, 0xA0), text="COMMANDS (single-task)\n/lint, /test, /scan, /deploy, /status", font_size=9)

# Layer 3: Automatic
add_box(slide, Inches(0.5), Inches(4.3), Inches(12.3), Inches(1.1),
        RGBColor(0x3A, 0x1A, 0x1A), INTEL_ORANGE,
        text="", font_size=10)
add_text_box(slide, Inches(0.7), Inches(4.35), Inches(6), Inches(0.3),
             "AUTOMATIC (harness-executed, invisible to Claude)", font_size=10, bold=True, color=INTEL_ORANGE)

add_box(slide, Inches(0.8), Inches(4.7), Inches(2.8), Inches(0.55),
        RGBColor(0x7A, 0x3A, 0x00), text="PreToolUse HOOKS\nsecret-scanner, cmd-blocker", font_size=9)
add_box(slide, Inches(3.9), Inches(4.7), Inches(3.0), Inches(0.55),
        RGBColor(0x7A, 0x3A, 0x00), text="PostToolUse HOOKS\nlicense-check, standards-validator", font_size=9)
add_box(slide, Inches(7.2), Inches(4.7), Inches(2.8), Inches(0.55),
        RGBColor(0x7A, 0x3A, 0x00), text="PERMISSIONS\nallow/deny per tool", font_size=9)

# Layer 4: Shared Infrastructure
add_box(slide, Inches(0.5), Inches(5.6), Inches(12.3), Inches(1.1),
        RGBColor(0x1A, 0x2A, 0x1A), INTEL_GREEN,
        text="", font_size=10)
add_text_box(slide, Inches(0.7), Inches(5.65), Inches(5), Inches(0.3),
             "SHARED INFRASTRUCTURE (read on-demand by skills)", font_size=10, bold=True, color=INTEL_GREEN)

add_box(slide, Inches(0.8), Inches(6.0), Inches(3.0), Inches(0.55),
        RGBColor(0x1A, 0x5A, 0x1A), text="STANDARDS (12 files)\ncoding, security, containers...", font_size=9)
add_box(slide, Inches(4.1), Inches(6.0), Inches(3.0), Inches(0.55),
        RGBColor(0x1A, 0x5A, 0x1A), text="CONTRACTS (6 files)\ndata shapes between agents", font_size=9)
add_box(slide, Inches(7.4), Inches(6.0), Inches(3.0), Inches(0.55),
        RGBColor(0x1A, 0x5A, 0x1A), text="UX PATTERNS (7 files)\ninteraction templates", font_size=9)

# ══════════════════════════════════════════════════════════════════
# SLIDE 4: Terminology Glossary
# ══════════════════════════════════════════════════════════════════
slide = prs.slides.add_slide(prs.slide_layouts[6])
add_section_header(slide, "Claude Code Terminology", "Key concepts mapped to our project")

terms = [
    ("CLAUDE.md", "Project context always in Claude's window", "Root CLAUDE.md", "Every conversation"),
    ("Skill", "Multi-phase orchestration (1000+ lines)", ".claude/skills/{name}/skill.md", "On /skill invoke"),
    ("Command", "Single-task shortcut (30-50 lines)", ".claude/commands/{name}.md", "On /cmd invoke"),
    ("Hook", "Auto-enforcement (harness runs it)", "settings.json + hooks/*.py", "Every tool call"),
    ("Permission", "Allow/deny rules for tools", ".claude/settings.json", "Every tool call"),
    ("Standard", "Coding guidelines read on demand", ".claude/shared/standards/", "When skill asks"),
    ("Contract", "Data schema between agents", ".claude/shared/contracts/", "Validating output"),
    ("UX Pattern", "Interaction template", ".claude/shared/ux/", "When skill follows it"),
    ("Memory", "Cross-session persistence", "Claude's memory system", "Session start/save"),
    ("Iteration State", "JSON progress tracker", ".iteration-state.json", "Resumption"),
]

# Table headers
headers_y = Inches(1.7)
add_text_box(slide, Inches(0.5), headers_y, Inches(2), Inches(0.3),
             "Term", font_size=11, bold=True, color=INTEL_BLUE)
add_text_box(slide, Inches(2.5), headers_y, Inches(4), Inches(0.3),
             "What It Is", font_size=11, bold=True, color=INTEL_BLUE)
add_text_box(slide, Inches(6.8), headers_y, Inches(3.2), Inches(0.3),
             "File Location", font_size=11, bold=True, color=INTEL_BLUE)
add_text_box(slide, Inches(10.2), headers_y, Inches(2.5), Inches(0.3),
             "When Active", font_size=11, bold=True, color=INTEL_BLUE)

y = Inches(2.1)
for term, what, where, when in terms:
    add_text_box(slide, Inches(0.5), y, Inches(2), Inches(0.3),
                 term, font_size=10, bold=True, color=INTEL_WHITE)
    add_text_box(slide, Inches(2.5), y, Inches(4), Inches(0.3),
                 what, font_size=10, color=RGBColor(0xCC, 0xCC, 0xCC))
    add_text_box(slide, Inches(6.8), y, Inches(3.2), Inches(0.3),
                 where, font_size=9, color=RGBColor(0xAA, 0xBB, 0xCC), font_name='Cascadia Code')
    add_text_box(slide, Inches(10.2), y, Inches(2.5), Inches(0.3),
                 when, font_size=10, color=RGBColor(0xAA, 0xAA, 0xAA))
    y += Inches(0.5)

# ══════════════════════════════════════════════════════════════════
# SLIDE 5: Two-Layer Architecture
# ══════════════════════════════════════════════════════════════════
slide = prs.slides.add_slide(prs.slide_layouts[6])
add_section_header(slide, "Two-Layer Architecture", "Mechanical + Creative — never exhaust context window")

# Layer 1 box
add_box(slide, Inches(0.5), Inches(1.8), Inches(5.8), Inches(2.2),
        RGBColor(0x0A, 0x3A, 0x6A), INTEL_BLUE)
add_text_box(slide, Inches(0.8), Inches(1.9), Inches(5), Inches(0.35),
             "LAYER 1: MECHANICAL", font_size=14, bold=True, color=INTEL_BLUE)
add_text_box(slide, Inches(0.8), Inches(2.3), Inches(5), Inches(0.3),
             "scripts/scaffold.py", font_size=12, bold=True, color=INTEL_WHITE)
lines = [
    ("Zero LLM context consumed", False, INTEL_GREEN),
    ("Input: handoff.yaml (from PRD metadata)", False, RGBColor(0xCC, 0xCC, 0xCC)),
    ("Process: {{var}} substitution across 151 templates", False, RGBColor(0xCC, 0xCC, 0xCC)),
    ("Output: Complete project in <3 seconds", False, RGBColor(0xCC, 0xCC, 0xCC)),
    ("Templates: 8 phase groups (config, github,", False, RGBColor(0xCC, 0xCC, 0xCC)),
    ("  backend, frontend, docker, helm, ansible)", False, RGBColor(0xCC, 0xCC, 0xCC)),
]
add_multi_text(slide, Inches(0.8), Inches(2.65), Inches(5.2), Inches(1.3),
               lines, font_size=11)

# Layer 2 box
add_box(slide, Inches(6.8), Inches(1.8), Inches(6.0), Inches(2.2),
        RGBColor(0x2A, 0x1A, 0x4A), RGBColor(0x88, 0x44, 0xCC))
add_text_box(slide, Inches(7.1), Inches(1.9), Inches(5), Inches(0.35),
             "LAYER 2: LLM CREATIVE", font_size=14, bold=True, color=RGBColor(0x88, 0x44, 0xCC))
add_text_box(slide, Inches(7.1), Inches(2.3), Inches(5), Inches(0.3),
             "Focused sub-phases (~10-30KB each)", font_size=12, bold=True, color=INTEL_WHITE)
lines = [
    ("Phase 4: PRD-specific code gen (~30KB)", False, RGBColor(0xCC, 0xCC, 0xCC)),
    ("Phase 4.5: Dev Sanity with real infra (~10KB)", False, RGBColor(0xCC, 0xCC, 0xCC)),
    ("Phase 4.6: Integration audit (~15KB)", False, RGBColor(0xCC, 0xCC, 0xCC)),
    ("Phase 4.7: README generation (~20KB)", False, RGBColor(0xCC, 0xCC, 0xCC)),
    ("Phase 4.8: Developer validates (~5KB)", False, RGBColor(0xCC, 0xCC, 0xCC)),
]
add_multi_text(slide, Inches(7.1), Inches(2.65), Inches(5.5), Inches(1.2),
               lines, font_size=11)

# Arrow between layers
add_text_box(slide, Inches(5.9), Inches(2.7), Inches(1), Inches(0.4),
             "  >>>", font_size=20, bold=True, color=INTEL_ORANGE)

# Bottom insight box
add_box(slide, Inches(0.5), Inches(4.3), Inches(12.3), Inches(0.7),
        RGBColor(0x1A, 0x3A, 0x1A), INTEL_GREEN,
        text="KEY INSIGHT: Same PRD = Same output. 151 template files scaffolded deterministically, then LLM adds only PRD-specific business logic",
        font_size=12, font_color=INTEL_WHITE)

# Phase flow at bottom
phases = [
    ("Phase 0\nRecovery", RGBColor(0x4A, 0x4A, 0x4A)),
    ("Phase 1\nPRD Intake", RGBColor(0x4A, 0x4A, 0x6A)),
    ("Phase 2-3\nScaffold", INTEL_BLUE),
    ("Phase 4\nPRD Code", RGBColor(0x55, 0x33, 0x88)),
    ("Phase 4.5\nDev Sanity", RGBColor(0x88, 0x44, 0x00)),
    ("Phase 4.6\nAudit", RGBColor(0x00, 0x6A, 0x4A)),
    ("Phase 4.7\nREADME", RGBColor(0x00, 0x5A, 0x8A)),
    ("Phase 6\nCheckpoints", RGBColor(0x3A, 0x3A, 0x3A)),
]

x = Inches(0.5)
for label, color in phases:
    add_box(slide, x, Inches(5.3), Inches(1.5), Inches(0.9), color, text=label, font_size=9)
    x += Inches(1.6)

# Arrows between phases
for i in range(7):
    add_text_box(slide, Inches(1.85 + i * 1.6), Inches(5.55), Inches(0.3), Inches(0.3),
                 ">", font_size=14, bold=True, color=INTEL_ORANGE)

# ══════════════════════════════════════════════════════════════════
# SLIDE 6: One Call Flow — Part 1 (Discovery + Context)
# ══════════════════════════════════════════════════════════════════
slide = prs.slides.add_slide(prs.slide_layouts[6])
add_section_header(slide, "One Call Flow: /dev-agent", "Step 1-3: Discovery, Context, Recovery")

# Step 1
add_box(slide, Inches(0.5), Inches(1.7), Inches(3.8), Inches(1.5),
        RGBColor(0x0A, 0x3A, 0x6A), INTEL_BLUE)
add_text_box(slide, Inches(0.7), Inches(1.8), Inches(3.4), Inches(0.3),
             "1. SKILL DISCOVERY", font_size=12, bold=True, color=INTEL_BLUE)
lines = [
    ("User types: /dev-agent", True, INTEL_WHITE),
    ("", False, None),
    ("Claude Code searches:", False, RGBColor(0xCC, 0xCC, 0xCC)),
    (".claude/skills/dev-agent/", False, RGBColor(0xAA, 0xDD, 0xFF)),
    ("", False, None),
    ("Loads 1,595 lines of", False, RGBColor(0xCC, 0xCC, 0xCC)),
    ("orchestration into context", False, RGBColor(0xCC, 0xCC, 0xCC)),
]
add_multi_text(slide, Inches(0.7), Inches(2.15), Inches(3.4), Inches(1.0),
               lines, font_size=10)

# Step 2
add_box(slide, Inches(4.7), Inches(1.7), Inches(3.8), Inches(1.5),
        RGBColor(0x1A, 0x4A, 0x1A), INTEL_GREEN)
add_text_box(slide, Inches(4.9), Inches(1.8), Inches(3.4), Inches(0.3),
             "2. CONTEXT (always loaded)", font_size=12, bold=True, color=INTEL_GREEN)
lines = [
    ("Already in Claude's window:", True, INTEL_WHITE),
    ("", False, None),
    ("CLAUDE.md = big picture", False, RGBColor(0xCC, 0xCC, 0xCC)),
    ("Permissions = allow/deny", False, RGBColor(0xCC, 0xCC, 0xCC)),
    ("Memory = last session state", False, RGBColor(0xCC, 0xCC, 0xCC)),
]
add_multi_text(slide, Inches(4.9), Inches(2.15), Inches(3.4), Inches(1.0),
               lines, font_size=10)

# Step 3
add_box(slide, Inches(8.9), Inches(1.7), Inches(3.9), Inches(1.5),
        RGBColor(0x3A, 0x2A, 0x1A), INTEL_ORANGE)
add_text_box(slide, Inches(9.1), Inches(1.8), Inches(3.5), Inches(0.3),
             "3. SESSION RECOVERY", font_size=12, bold=True, color=INTEL_ORANGE)
lines = [
    ("Skill: \"Follow resumption-", True, INTEL_WHITE),
    ("pattern.md\"", True, INTEL_WHITE),
    ("", False, None),
    ("Reads .iteration-state.json", False, RGBColor(0xCC, 0xCC, 0xCC)),
    ("Reads Claude Memory", False, RGBColor(0xCC, 0xCC, 0xCC)),
    ("Reads git log", False, RGBColor(0xCC, 0xCC, 0xCC)),
    ("ASK: Resume or Fresh?", False, INTEL_ORANGE),
]
add_multi_text(slide, Inches(9.1), Inches(2.15), Inches(3.5), Inches(1.0),
               lines, font_size=10)

# Connection arrows
add_text_box(slide, Inches(4.1), Inches(2.3), Inches(0.5), Inches(0.3),
             ">>>", font_size=12, bold=True, color=INTEL_ORANGE)
add_text_box(slide, Inches(8.3), Inches(2.3), Inches(0.5), Inches(0.3),
             ">>>", font_size=12, bold=True, color=INTEL_ORANGE)

# Key insight
add_box(slide, Inches(0.5), Inches(3.5), Inches(12.3), Inches(0.6),
        RGBColor(0x1A, 0x1A, 0x3A), INTEL_BLUE,
        text="KEY: Skill.md is the orchestration playbook. CLAUDE.md is the overview. Standards/Contracts/UX are read ON-DEMAND during execution.",
        font_size=11, font_color=RGBColor(0xCC, 0xDD, 0xFF))

# Detailed call flow bottom
add_code_box(slide, Inches(0.5), Inches(4.4), Inches(12.3), Inches(2.7),
             "/dev-agent\n"
             "  -> .claude/skills/dev-agent/skill.md LOADED (1595 lines)\n"
             "  -> Phase 0: READ .claude/shared/ux/resumption-pattern.md\n"
             "              READ .iteration-state.json  (CONTRACT: iteration-state-schema.md)\n"
             "              READ Claude Memory\n"
             "              READ git log --oneline -20\n"
             "              DECISION: resume Phase 4.5? start fresh? -> ASK developer\n"
             "  -> Phase 0.5: READ .claude/shared/ux/integration-setup.md\n"
             "                ASK: Git remote? Wiki PAT? Jira PAT?\n"
             "                WRITE: integrations block -> .iteration-state.json",
             font_size=10)

# ══════════════════════════════════════════════════════════════════
# SLIDE 7: One Call Flow — Part 2 (PRD + Scaffold)
# ══════════════════════════════════════════════════════════════════
slide = prs.slides.add_slide(prs.slide_layouts[6])
add_section_header(slide, "One Call Flow: /dev-agent", "Step 4-5: PRD Intake + Scaffold (Layer 1)")

add_code_box(slide, Inches(0.5), Inches(1.7), Inches(12.3), Inches(5.3),
             "Phase 1: PRD INTAKE\n"
             "  skill.md: \"Follow .claude/shared/ux/output-directory-selection.md\"\n"
             "  skill.md: \"Validate per .claude/shared/contracts/prd-output-schema.md\"\n"
             "  \n"
             "  -> READ UX Pattern -> knows HOW to ask developer (list dirs, confirm)\n"
             "  -> READ Contract   -> knows WHAT to extract from PRD\n"
             "  -> READ Technical PRD -> parses handoff metadata block\n"
             "  -> EXTRACT: project_name, slug, components[], tech requirements\n"
             "  -> ASK developer: \"Does this look correct?\"\n"
             "  -> WRITE: handoff.yaml (variables for scaffolding)\n"
             "\n"
             "Phase 2-3: SCAFFOLD (Zero LLM context)\n"
             "  skill.md: \"Run scripts/scaffold.py --vars handoff.yaml\"\n"
             "  \n"
             "  -> Claude calls: Bash(python scripts/scaffold.py ...)\n"
             "       |\n"
             "       +-- HOOK FIRES: PreToolUse(Bash) -> secret-scanner.py\n"
             "       |   (harness checks command for secrets BEFORE execution)\n"
             "       |\n"
             "       +-- PERMISSION CHECK: settings.json allows Bash(python:*) -> PASS\n"
             "       |\n"
             "       +-- scaffold.py executes:\n"
             "       |     load_vars(handoff.yaml)\n"
             "       |     FOR EACH phase IN [config, github, backend, frontend,\n"
             "       |                        frontend_features, docker, helm, ansible]:\n"
             "       |       FOR EACH template IN templates/project-scaffold/{phase}/:\n"
             "       |         content = read(template)\n"
             "       |         content = substitute(content, vars)  # {{var}} -> value\n"
             "       |         write(output_path, content)\n"
             "       |\n"
             "       +-- OUTPUT: 151 files written in <3 seconds\n"
             "       +-- MANIFEST: reports/generation/scaffold-manifest.json",
             font_size=10)

# ══════════════════════════════════════════════════════════════════
# SLIDE 8: One Call Flow — Part 3 (Phase 4: Creative)
# ══════════════════════════════════════════════════════════════════
slide = prs.slides.add_slide(prs.slide_layouts[6])
add_section_header(slide, "One Call Flow: /dev-agent", "Step 6: PRD-Specific Code (Layer 2 — LLM Creative)")

add_code_box(slide, Inches(0.5), Inches(1.7), Inches(6.0), Inches(5.3),
             "Phase 4: PRD-SPECIFIC CODE (~30KB context)\n"
             "  skill.md: \"Read standards before generating\"\n"
             "\n"
             "  -> READ .claude/shared/standards/coding-standards.md\n"
             "  -> READ .claude/shared/standards/security-practices.md\n"
             "  -> READ .claude/shared/standards/tech-stack.md\n"
             "  -> READ .claude/shared/standards/container-standards.md\n"
             "  -> READ .claude/shared/standards/testing-standards.md\n"
             "  -> READ .claude/shared/standards/observability-standards.md\n"
             "\n"
             "  FOR EACH resource IN PRD:\n"
             "    -> GENERATE: API endpoint (CRUD + custom)\n"
             "    -> GENERATE: SQLAlchemy model\n"
             "    -> GENERATE: Pydantic schemas\n"
             "    -> GENERATE: Service layer\n"
             "\n"
             "  FOR EACH write:\n"
             "    -> HOOK: license-header-check.py\n"
             "    -> HOOK: standards-validator.py\n"
             "    -> PERMISSION: Write(**/*.py) -> PASS",
             font_size=10)

# Right side: what hooks do
add_box(slide, Inches(6.8), Inches(1.7), Inches(6.0), Inches(2.2),
        RGBColor(0x3A, 0x1A, 0x1A), INTEL_ORANGE)
add_text_box(slide, Inches(7.0), Inches(1.8), Inches(5.5), Inches(0.3),
             "HOOKS FIRING (automatic, silent)", font_size=13, bold=True, color=INTEL_ORANGE)
lines = [
    ("Every time Claude calls Write tool:", True, INTEL_WHITE),
    ("", False, None),
    ("1. Harness intercepts the call", False, RGBColor(0xCC, 0xCC, 0xCC)),
    ("2. Runs license-header-check.py", False, RGBColor(0xCC, 0xCC, 0xCC)),
    ("   -> Is Intel copyright present?", False, RGBColor(0xAA, 0xAA, 0xAA)),
    ("3. Runs standards-validator.py", False, RGBColor(0xCC, 0xCC, 0xCC)),
    ("   -> Does code follow standards?", False, RGBColor(0xAA, 0xAA, 0xAA)),
    ("4. If violation -> warning to stderr", False, INTEL_ORANGE),
    ("5. File still written (not blocked)", False, RGBColor(0xCC, 0xCC, 0xCC)),
    ("", False, None),
    ("Claude NEVER sees this happening.", True, INTEL_RED),
    ("The harness enforces compliance.", False, RGBColor(0xCC, 0xCC, 0xCC)),
]
add_multi_text(slide, Inches(7.0), Inches(2.2), Inches(5.5), Inches(1.5),
               lines, font_size=10)

# Right side: permissions
add_box(slide, Inches(6.8), Inches(4.2), Inches(6.0), Inches(2.0),
        RGBColor(0x1A, 0x1A, 0x3A), INTEL_BLUE)
add_text_box(slide, Inches(7.0), Inches(4.3), Inches(5.5), Inches(0.3),
             "PERMISSIONS (access control)", font_size=13, bold=True, color=INTEL_BLUE)
lines = [
    ("settings.json enforces:", True, INTEL_WHITE),
    ("", False, None),
    ("ALLOW: Bash(python:*), Write(**/*.py)", False, INTEL_GREEN),
    ("ALLOW: Bash(pip:*), Bash(git:*)", False, INTEL_GREEN),
    ("ALLOW: Read(**/*.*)", False, INTEL_GREEN),
    ("", False, None),
    ("DENY: Bash(sudo:*), Read(.env)", False, INTEL_RED),
    ("DENY: Bash(rm -rf /), Bash(chmod 777)", False, INTEL_RED),
]
add_multi_text(slide, Inches(7.0), Inches(4.7), Inches(5.5), Inches(1.2),
               lines, font_size=10)

# ══════════════════════════════════════════════════════════════════
# SLIDE 9: One Call Flow — Part 4 (Dev Sanity)
# ══════════════════════════════════════════════════════════════════
slide = prs.slides.add_slide(prs.slide_layouts[6])
add_section_header(slide, "One Call Flow: /dev-agent", "Step 7: Dev Sanity — Real Infrastructure Testing")

add_code_box(slide, Inches(0.5), Inches(1.7), Inches(7.5), Inches(5.3),
             "Phase 4.5: DEV SANITY (~10KB context)\n"
             "  skill.md: \"Test with REAL infrastructure, not mocks\"\n"
             "  skill.md: \"Follow .claude/shared/ux/human-in-the-loop.md\"\n"
             "\n"
             "  UX PATTERN (Announce/Context/Options/Wait):\n"
             "  +------------------------------------------+\n"
             "  | ANNOUNCE: Need to verify EI connectivity  |\n"
             "  | CONTEXT:  EI required for AI flows        |\n"
             "  | OPTIONS:  1. Provide URL                  |\n"
             "  |           2. Deploy EI first              |\n"
             "  |           3. Skip AI flows only           |\n"
             "  | -> WAIT for developer                     |\n"
             "  +------------------------------------------+\n"
             "\n"
             "  -> ASK: EI endpoint + token (MANDATORY)\n"
             "  -> VALIDATE: curl {EI}/v1/models -> confirm models\n"
             "  -> ASK: Redis or inline? MinIO or local? PostgreSQL or SQLite?\n"
             "  -> WRITE: .env with real values\n"
             "  -> RUN: pip install + npm install\n"
             "  -> RUN: uvicorn -> verify /healthz\n"
             "  -> VERIFY: Frontend-backend contracts (C1, C9, C14)\n"
             "  -> VERIFY: Auth flow (register -> login -> token)\n"
             "  -> VERIFY: Full E2E (CREATE->PROCESS->READ->LIST->DELETE)\n"
             "  -> RUN: vite -> verify proxy routes\n"
             "  -> RUN: docker build (if available)",
             font_size=10)

# Right side: contract enforcement
add_box(slide, Inches(8.3), Inches(1.7), Inches(4.5), Inches(2.5),
        RGBColor(0x1A, 0x3A, 0x1A), INTEL_GREEN)
add_text_box(slide, Inches(8.5), Inches(1.8), Inches(4), Inches(0.3),
             "CONTRACT ENFORCEMENT", font_size=12, bold=True, color=INTEL_GREEN)
lines = [
    ("14 mandatory rules verified:", True, INTEL_WHITE),
    ("", False, None),
    ("C1: List -> {items,total,page,size}", False, RGBColor(0xCC, 0xCC, 0xCC)),
    ("C2: All entities have UUID id", False, RGBColor(0xCC, 0xCC, 0xCC)),
    ("C5: API paths: /api/v1/...", False, RGBColor(0xCC, 0xCC, 0xCC)),
    ("C8: DB portable (SQLite/PG)", False, RGBColor(0xCC, 0xCC, 0xCC)),
    ("C9: Frontend fields = backend", False, RGBColor(0xCC, 0xCC, 0xCC)),
    ("C11: Dev mode = prod code paths", False, RGBColor(0xCC, 0xCC, 0xCC)),
    ("C13: Deterministic output", False, RGBColor(0xCC, 0xCC, 0xCC)),
    ("C14: No orphan code", False, RGBColor(0xCC, 0xCC, 0xCC)),
]
add_multi_text(slide, Inches(8.5), Inches(2.15), Inches(4), Inches(2.0),
               lines, font_size=10)

# Right side: what happens on failure
add_box(slide, Inches(8.3), Inches(4.5), Inches(4.5), Inches(1.5),
        RGBColor(0x3A, 0x1A, 0x1A), INTEL_RED)
add_text_box(slide, Inches(8.5), Inches(4.6), Inches(4), Inches(0.3),
             "IF ANY CHECK FAILS:", font_size=12, bold=True, color=INTEL_RED)
lines = [
    ("1. Identify root cause", False, RGBColor(0xCC, 0xCC, 0xCC)),
    ("2. Fix generated code (real fix)", False, RGBColor(0xCC, 0xCC, 0xCC)),
    ("3. Re-run entire failing step", False, RGBColor(0xCC, 0xCC, 0xCC)),
    ("4. Max 3 iterations", False, RGBColor(0xCC, 0xCC, 0xCC)),
    ("5. Then report to developer", False, INTEL_ORANGE),
]
add_multi_text(slide, Inches(8.5), Inches(5.0), Inches(4), Inches(1.0),
               lines, font_size=10)

# ══════════════════════════════════════════════════════════════════
# SLIDE 10: One Call Flow — Part 5 (Checkpoints)
# ══════════════════════════════════════════════════════════════════
slide = prs.slides.add_slide(prs.slide_layouts[6])
add_section_header(slide, "One Call Flow: /dev-agent", "Step 8-9: Audit, README, Checkpoints")

add_code_box(slide, Inches(0.5), Inches(1.7), Inches(6.0), Inches(2.5),
             "Phase 4.6: INTEGRATION AUDIT\n"
             "  10 cross-file checks:\n"
             "  - All imports resolve\n"
             "  - All endpoints in router\n"
             "  - Frontend types = backend schemas\n"
             "  - Env vars consistent everywhere\n"
             "  - Dockerfile paths correct\n"
             "  - Helm values match app config\n"
             "\n"
             "Phase 4.7: README GENERATION\n"
             "  Documents ONLY what exists and works\n"
             "  Architecture diagram + Quick Start + Config",
             font_size=10)

# Checkpoints
add_box(slide, Inches(6.8), Inches(1.7), Inches(6.0), Inches(2.5),
        RGBColor(0x2A, 0x1A, 0x3A), RGBColor(0x88, 0x44, 0xCC))
add_text_box(slide, Inches(7.0), Inches(1.8), Inches(5.5), Inches(0.3),
             "PROGRAM CHECKPOINTS (mandatory)", font_size=13, bold=True, color=RGBColor(0xBB, 0x77, 0xFF))
lines = [
    ("skill.md: \"Follow program-checkpoints.md\"", False, RGBColor(0xAA, 0xBB, 0xCC)),
    ("", False, None),
    ("1. WIKI  -> /wiki-publish (command)", False, RGBColor(0xCC, 0xCC, 0xCC)),
    ("   Publish to Confluence space", False, RGBColor(0xAA, 0xAA, 0xAA)),
    ("2. JIRA  -> /jira-update (command)", False, RGBColor(0xCC, 0xCC, 0xCC)),
    ("   Update stories with status", False, RGBColor(0xAA, 0xAA, 0xAA)),
    ("3. GIT   -> commit + push", False, RGBColor(0xCC, 0xCC, 0xCC)),
    ("   Feature branch with all changes", False, RGBColor(0xAA, 0xAA, 0xAA)),
    ("", False, None),
    ("Then: SAVE to Claude Memory", True, INTEL_GREEN),
    ("Then: UPDATE .iteration-state.json", True, INTEL_GREEN),
]
add_multi_text(slide, Inches(7.0), Inches(2.2), Inches(5.5), Inches(2.0),
               lines, font_size=10)

# Skill -> Command delegation
add_box(slide, Inches(0.5), Inches(4.5), Inches(12.3), Inches(2.5),
        RGBColor(0x1A, 0x1A, 0x2A), INTEL_BLUE)
add_text_box(slide, Inches(0.7), Inches(4.6), Inches(11), Inches(0.3),
             "SKILL -> COMMAND DELEGATION (Skills orchestrate, Commands execute)",
             font_size=12, bold=True, color=INTEL_BLUE)

add_code_box(slide, Inches(0.8), Inches(5.1), Inches(11.7), Inches(1.7),
             "skill.md (Phase 6):\n"
             "  \"Present 3 checkpoints. If developer chooses W1, execute wiki-publish.\"\n"
             "       |                                    |\n"
             "       v                                    v\n"
             "  .claude/commands/wiki-publish.md    .claude/commands/jira-update.md\n"
             "  (30 lines: call wiki API)           (40 lines: call Jira API)\n"
             "       |                                    |\n"
             "       v                                    v\n"
             "  Returns to skill flow              Returns to skill flow",
             font_size=10)

# ══════════════════════════════════════════════════════════════════
# SLIDE 11: 7 Interconnection Points
# ══════════════════════════════════════════════════════════════════
slide = prs.slides.add_slide(prs.slide_layouts[6])
add_section_header(slide, "7 Interconnection Points", "How every component talks to the others")

connections = [
    ("1", "Skill -> Standard", "On-demand reading", "skill.md says \"Read coding-standards.md\" -> Claude fetches file -> applies rules during code gen", INTEL_BLUE),
    ("2", "Skill -> Contract", "Validation schema", "skill.md says \"Validate per prd-output-schema\" -> Claude checks data shape matches", INTEL_GREEN),
    ("3", "Skill -> UX Pattern", "Interaction template", "skill.md says \"Follow human-in-the-loop.md\" -> Claude uses Announce/Context/Options format", RGBColor(0x88, 0x44, 0xCC)),
    ("4", "Hook -> Tool Call", "Auto enforcement", "Claude writes file -> harness intercepts -> runs license-check.py (Claude never knows)", INTEL_ORANGE),
    ("5", "Permission -> Tool", "Access control", "Claude wants sudo -> settings.json DENY -> blocked before execution", INTEL_RED),
    ("6", "Memory -> Recovery", "Cross-session", "Day 1 saves status -> Day 7 reads it -> resumes at correct phase", RGBColor(0x00, 0x7A, 0xA0)),
    ("7", "Skill -> Command", "Delegation", "Skill checkpoint says \"publish\" -> invokes /wiki-publish command -> returns", RGBColor(0x4A, 0x4A, 0x4A)),
]

y = Inches(1.7)
for num, title, subtitle, desc, color in connections:
    add_box(slide, Inches(0.5), y, Inches(0.4), Inches(0.4), color, text=num, font_size=11)
    add_text_box(slide, Inches(1.0), y, Inches(2.5), Inches(0.3),
                 title, font_size=11, bold=True, color=color)
    add_text_box(slide, Inches(3.5), y, Inches(1.5), Inches(0.3),
                 subtitle, font_size=9, color=RGBColor(0xAA, 0xAA, 0xAA))
    add_text_box(slide, Inches(5.0), y, Inches(8), Inches(0.35),
                 desc, font_size=10, color=RGBColor(0xCC, 0xCC, 0xCC))
    y += Inches(0.75)

# Key insight box
add_box(slide, Inches(0.5), Inches(6.5), Inches(12.3), Inches(0.6),
        RGBColor(0x1A, 0x3A, 0x1A), INTEL_GREEN,
        text="All connections are EXPLICIT (no magic). Every reference is plaintext in skill.md. Standards updated independently without reloading skills.",
        font_size=11, font_color=RGBColor(0xCC, 0xFF, 0xCC))

# ══════════════════════════════════════════════════════════════════
# SLIDE 12: File System Layout
# ══════════════════════════════════════════════════════════════════
slide = prs.slides.add_slide(prs.slide_layouts[6])
add_section_header(slide, "File System Layout", "What the team sees in the repo")

add_code_box(slide, Inches(0.3), Inches(1.7), Inches(6.3), Inches(5.4),
             ".claude/\n"
             "|\n"
             "+-- settings.json          <- PERMISSIONS + HOOKS\n"
             "|   permissions.allow: [Bash(python:*), ...]\n"
             "|   permissions.deny:  [Bash(sudo:*), ...]\n"
             "|   hooks: PreToolUse, PostToolUse\n"
             "|\n"
             "+-- skills/                <- ORCHESTRATION\n"
             "|   +-- dev-agent/skill.md     (1595L)\n"
             "|   +-- prd-agent/skill.md     (1200L)\n"
             "|   +-- validation-agent/      (800L)\n"
             "|   +-- compliance-agent/      (900L)\n"
             "|\n"
             "+-- commands/              <- SINGLE TASKS\n"
             "|   lint.md, test.md, scan.md,\n"
             "|   deploy.md, status.md,\n"
             "|   wiki-publish.md, jira-update.md\n"
             "|\n"
             "+-- hooks/                 <- ENFORCEMENT SCRIPTS\n"
             "|   secret-scanner.py\n"
             "|   dangerous-command-blocker.py\n"
             "|   license-header-check.py\n"
             "|   standards-validator.py\n"
             "|\n"
             "+-- shared/                <- REFERENCE LIBRARY\n"
             "    +-- standards/ (12)    coding, security, tech-stack...\n"
             "    +-- contracts/ (6)     iteration-state, output, prd...\n"
             "    +-- ux/ (7)           human-in-loop, checkpoints...",
             font_size=9)

# Right side: what each does
add_box(slide, Inches(6.9), Inches(1.7), Inches(6.0), Inches(1.2),
        RGBColor(0x0A, 0x3A, 0x6A), INTEL_BLUE)
add_text_box(slide, Inches(7.1), Inches(1.8), Inches(5.5), Inches(0.3),
             "Skills = Playbooks", font_size=13, bold=True, color=INTEL_BLUE)
add_text_box(slide, Inches(7.1), Inches(2.15), Inches(5.5), Inches(0.5),
             "1000+ lines orchestrating 6+ phases with decision gates.\nLoaded ONLY when /skill invoked. Keeps context lean.",
             font_size=10, color=RGBColor(0xCC, 0xCC, 0xCC))

add_box(slide, Inches(6.9), Inches(3.1), Inches(6.0), Inches(1.2),
        RGBColor(0x3A, 0x1A, 0x1A), INTEL_ORANGE)
add_text_box(slide, Inches(7.1), Inches(3.2), Inches(5.5), Inches(0.3),
             "Hooks = Silent Cops", font_size=13, bold=True, color=INTEL_ORANGE)
add_text_box(slide, Inches(7.1), Inches(3.55), Inches(5.5), Inches(0.5),
             "Run by HARNESS (not Claude). Enforce security + compliance\nautomatically. Developer never sees them unless violation.",
             font_size=10, color=RGBColor(0xCC, 0xCC, 0xCC))

add_box(slide, Inches(6.9), Inches(4.5), Inches(6.0), Inches(1.2),
        RGBColor(0x1A, 0x3A, 0x1A), INTEL_GREEN)
add_text_box(slide, Inches(7.1), Inches(4.6), Inches(5.5), Inches(0.3),
             "Standards + Contracts = Guardrails", font_size=13, bold=True, color=INTEL_GREEN)
add_text_box(slide, Inches(7.1), Inches(4.95), Inches(5.5), Inches(0.5),
             "Read ON-DEMAND by skills. Not pre-loaded (saves context).\nCan be updated independently without touching skills.",
             font_size=10, color=RGBColor(0xCC, 0xCC, 0xCC))

add_box(slide, Inches(6.9), Inches(5.9), Inches(6.0), Inches(1.0),
        RGBColor(0x2A, 0x1A, 0x3A), RGBColor(0x88, 0x44, 0xCC))
add_text_box(slide, Inches(7.1), Inches(6.0), Inches(5.5), Inches(0.3),
             "Memory + State = Session Bridge", font_size=13, bold=True, color=RGBColor(0xBB, 0x77, 0xFF))
add_text_box(slide, Inches(7.1), Inches(6.35), Inches(5.5), Inches(0.4),
             "Close laptop Friday. Reopen Monday. Resume exact phase.",
             font_size=10, color=RGBColor(0xCC, 0xCC, 0xCC))

# ══════════════════════════════════════════════════════════════════
# SLIDE 13: Data Flow Summary
# ══════════════════════════════════════════════════════════════════
slide = prs.slides.add_slide(prs.slide_layouts[6])
add_section_header(slide, "End-to-End Data Flow", "From PRD to production-ready project")

# Flow boxes
flow_steps = [
    ("Technical PRD\n(markdown)", INTEL_BLUE, Inches(0.3), Inches(1.8)),
    ("Parse & Extract\nHandoff Metadata", RGBColor(0x0A, 0x5A, 0x9A), Inches(0.3), Inches(2.9)),
    ("handoff.yaml\n(variables)", RGBColor(0x0A, 0x7A, 0x5A), Inches(0.3), Inches(4.0)),
    ("scaffold.py\n151 files (<3s)", INTEL_GREEN, Inches(0.3), Inches(5.1)),
    ("LLM: PRD Code\n(~30KB context)", RGBColor(0x55, 0x33, 0x88), Inches(0.3), Inches(6.2)),
]

for text, color, left, top in flow_steps:
    add_box(slide, left, top, Inches(2.3), Inches(0.8), color, text=text, font_size=10)

# Arrows
for i in range(4):
    add_text_box(slide, Inches(0.9), Inches(2.55 + i * 1.1), Inches(0.5), Inches(0.3),
                 "v", font_size=14, bold=True, color=INTEL_ORANGE, align=PP_ALIGN.CENTER)

# Right side continuation
flow_steps_2 = [
    ("Dev Sanity\nReal Infra Tests", INTEL_ORANGE, Inches(3.0), Inches(1.8)),
    ("Integration Audit\n14 Contract Checks", RGBColor(0x00, 0x6A, 0x4A), Inches(3.0), Inches(2.9)),
    ("README Gen\nDocuments Reality", RGBColor(0x00, 0x5A, 0x8A), Inches(3.0), Inches(4.0)),
    ("Developer Validates\nAs Customer", RGBColor(0x4A, 0x4A, 0x6A), Inches(3.0), Inches(5.1)),
    ("Checkpoints\nWiki/Jira/Git", RGBColor(0x3A, 0x3A, 0x3A), Inches(3.0), Inches(6.2)),
]

for text, color, left, top in flow_steps_2:
    add_box(slide, left, top, Inches(2.3), Inches(0.8), color, text=text, font_size=10)

for i in range(4):
    add_text_box(slide, Inches(3.6), Inches(2.55 + i * 1.1), Inches(0.5), Inches(0.3),
                 "v", font_size=14, bold=True, color=INTEL_ORANGE, align=PP_ALIGN.CENTER)

# Connecting arrow from left col to right col
add_text_box(slide, Inches(2.35), Inches(6.4), Inches(0.7), Inches(0.3),
             ">>>", font_size=12, bold=True, color=INTEL_ORANGE)

# Right side: what fires at each step
add_box(slide, Inches(5.8), Inches(1.7), Inches(7.0), Inches(5.5),
        RGBColor(0x0A, 0x1A, 0x2A), RGBColor(0x4A, 0x6A, 0x8A))
add_text_box(slide, Inches(6.0), Inches(1.8), Inches(6.5), Inches(0.3),
             "What Fires at Each Step", font_size=13, bold=True, color=INTEL_WHITE)

lines = [
    ("PRD Parse:", True, INTEL_BLUE),
    ("  Contract: prd-output-schema.md validates structure", False, RGBColor(0xCC, 0xCC, 0xCC)),
    ("  UX: output-directory-selection.md guides folder choice", False, RGBColor(0xCC, 0xCC, 0xCC)),
    ("", False, None),
    ("Scaffold:", True, INTEL_GREEN),
    ("  Hook: secret-scanner.py checks Bash command", False, RGBColor(0xCC, 0xCC, 0xCC)),
    ("  Permission: Bash(python:*) allowed", False, RGBColor(0xCC, 0xCC, 0xCC)),
    ("", False, None),
    ("PRD Code:", True, RGBColor(0x88, 0x44, 0xCC)),
    ("  Standards: 6 files read before generating", False, RGBColor(0xCC, 0xCC, 0xCC)),
    ("  Hooks: license-check + standards-validator on every Write", False, RGBColor(0xCC, 0xCC, 0xCC)),
    ("", False, None),
    ("Dev Sanity:", True, INTEL_ORANGE),
    ("  UX: human-in-the-loop.md for decision gates", False, RGBColor(0xCC, 0xCC, 0xCC)),
    ("  Contracts: 14 rules enforced during testing", False, RGBColor(0xCC, 0xCC, 0xCC)),
    ("", False, None),
    ("Checkpoints:", True, RGBColor(0xAA, 0xAA, 0xAA)),
    ("  UX: program-checkpoints.md for 3 gates", False, RGBColor(0xCC, 0xCC, 0xCC)),
    ("  Commands: /wiki-publish, /jira-update delegated", False, RGBColor(0xCC, 0xCC, 0xCC)),
    ("  Memory: Project status saved for next session", False, RGBColor(0xCC, 0xCC, 0xCC)),
]
add_multi_text(slide, Inches(6.0), Inches(2.2), Inches(6.5), Inches(4.5),
               lines, font_size=10)

# ══════════════════════════════════════════════════════════════════
# SLIDE 14: Key Takeaways
# ══════════════════════════════════════════════════════════════════
slide = prs.slides.add_slide(prs.slide_layouts[6])
add_section_header(slide, "Key Takeaways", "10 design principles for the team")

takeaways = [
    ("1", "CLAUDE.md = Always On", "Project context loaded every conversation. Orients Claude.", INTEL_BLUE),
    ("2", "Skills = Playbooks", "1000+ line orchestration specs. The 'brain' of each phase.", INTEL_GREEN),
    ("3", "Commands = Quick Actions", "30-50 lines. Used standalone or delegated by skills.", RGBColor(0x00, 0x7A, 0xA0)),
    ("4", "Hooks = Silent Cops", "Harness enforces compliance. Claude never sees them.", INTEL_ORANGE),
    ("5", "Standards = Rulebook", "Read on-demand. Not pre-loaded. Updated independently.", RGBColor(0x88, 0x44, 0xCC)),
    ("6", "Contracts = Agent APIs", "Data shapes one agent outputs, next expects.", INTEL_BLUE),
    ("7", "UX = Consistency", "Every agent: Announce -> Execute -> Summarize -> Checkpoint.", INTEL_GREEN),
    ("8", "Memory = Cross-Session", "Close laptop. Reopen next week. Resume exactly.", RGBColor(0x00, 0x7A, 0xA0)),
    ("9", "Iteration State = Save Game", "JSON tracks phases, tools, skipped items.", INTEL_ORANGE),
    ("10", "Two Layers = Efficiency", "Mechanical (0 context) + Creative (focused ~30KB). Never exhausts.", RGBColor(0x88, 0x44, 0xCC)),
]

y = Inches(1.7)
for num, title, desc, color in takeaways:
    add_box(slide, Inches(0.5), y, Inches(0.45), Inches(0.45), color, text=num, font_size=11)
    add_text_box(slide, Inches(1.1), y + Pt(2), Inches(3.0), Inches(0.3),
                 title, font_size=12, bold=True, color=color)
    add_text_box(slide, Inches(4.2), y + Pt(2), Inches(8.5), Inches(0.3),
                 desc, font_size=11, color=RGBColor(0xCC, 0xCC, 0xCC))
    y += Inches(0.55)

# ══════════════════════════════════════════════════════════════════
# SLIDE 15: Summary / Closing
# ══════════════════════════════════════════════════════════════════
slide = prs.slides.add_slide(prs.slide_layouts[6])
add_bg(slide, INTEL_DARK)

add_text_box(slide, Inches(1), Inches(2.0), Inches(11), Inches(1.0),
             "One Developer + Claude Code\n= Production-Ready AI Projects",
             font_size=36, bold=True, color=INTEL_WHITE, align=PP_ALIGN.CENTER)

add_text_box(slide, Inches(1), Inches(3.8), Inches(11), Inches(1.5),
             "Skills orchestrate  |  Commands execute  |  Hooks enforce\n"
             "Standards guide  |  Contracts connect  |  Memory persists",
             font_size=18, color=RGBColor(0xA0, 0xC0, 0xE0), align=PP_ALIGN.CENTER)

# Accent bar
shape = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(5), Inches(3.5), Inches(3.333), Pt(4))
shape.fill.solid()
shape.fill.fore_color.rgb = INTEL_BLUE
shape.line.fill.background()

add_text_box(slide, Inches(1), Inches(5.5), Inches(11), Inches(0.5),
             "Intel AI Solutions Engineering  |  Agentic AI Stack  |  2026",
             font_size=14, color=RGBColor(0x80, 0x90, 0xA0), align=PP_ALIGN.CENTER)

# Save
output_path = r'C:\Users\vivekrs\.claude\intel-ai-solutions-dev\docs\presentations\DevAgent-Architecture-ClaudeCode.pptx'
os.makedirs(os.path.dirname(output_path), exist_ok=True)
prs.save(output_path)
print(f"Saved: {output_path}")
print(f"Slides: {len(prs.slides)}")
