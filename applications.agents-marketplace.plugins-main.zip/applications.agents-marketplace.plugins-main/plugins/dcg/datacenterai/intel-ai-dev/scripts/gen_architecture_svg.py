#!/usr/bin/env python3
# Copyright (C) 2026 Intel Corporation
# SPDX-License-Identifier: Apache-2.0
"""Generate pixel-perfect SVG architecture diagram for the AI Solutions Pipeline.

Produces a grid-based diagram matching the ASCII layout with Intel brand colors.
Output: docs/architecture/pipeline-overview.svg

Usage:
    python scripts/gen_architecture_svg.py
    python scripts/gen_architecture_svg.py --output path/to/output.svg
"""

import argparse
from pathlib import Path

# Intel brand colors
COLORS = {
    "input": "#003580",
    "agents": "#0068b5",
    "hybrid": "#00c7fd",
    "hooks": "#f5a623",
    "infra": "#4a5568",
    "outputs": "#28a745",
    "integrations": "#7c3aed",
    "distribution": "#0d4f8b",
    "text_light": "#ffffff",
    "text_dark": "#000000",
    "border": "#ffffff",
    "arrow": "#334155",
    "bg": "#f8fafc",
    "review": "#e24b4a",
}

SVG_WIDTH = 1400
MARGIN = 40
COL_GAP = 12
ROW_GAP = 24
ARROW_GAP = 36


def rect(x, y, w, h, fill, rx=6):
    return f'  <rect x="{x}" y="{y}" width="{w}" height="{h}" fill="{fill}" rx="{rx}" />'


def _escape_xml(s: str) -> str:
    return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace('"', "&quot;")


def text(x, y, content, size=14, fill="#fff", bold=False, anchor="middle"):
    weight = 'font-weight="bold"' if bold else ""
    safe = _escape_xml(content)
    return f'  <text x="{x}" y="{y}" font-size="{size}" fill="{fill}" text-anchor="{anchor}" font-family="Inter, Segoe UI, -apple-system, Arial, sans-serif" {weight}>{safe}</text>'


def multiline_text(x, y, lines, size=13, fill="#fff", bold_first=False, line_height=18):
    elements = []
    for i, line in enumerate(lines):
        bold = bold_first and i == 0
        s = size + 2 if bold else size
        elements.append(text(x, y + i * line_height, line, size=s, fill=fill, bold=bold))
    return "\n".join(elements)


def arrow_down(x, y1, y2):
    mid_x = x
    return (
        f'  <line x1="{mid_x}" y1="{y1}" x2="{mid_x}" y2="{y2 - 6}" '
        f'stroke="{COLORS["arrow"]}" stroke-width="2" />\n'
        f'  <polygon points="{mid_x - 5},{y2 - 8} {mid_x + 5},{y2 - 8} {mid_x},{y2}" '
        f'fill="{COLORS["arrow"]}" />'
    )


def section_label(x, y, label, sublabel=None, fill="#fff"):
    elements = [text(x, y, label, size=13, fill=fill, bold=True)]
    if sublabel:
        elements.append(text(x, y + 16, sublabel, size=10, fill=fill))
    return "\n".join(elements)


def generate_svg() -> str:
    parts = []
    content_width = SVG_WIDTH - 2 * MARGIN
    y = MARGIN

    # --- Row 0: Distribution (Claude Code plugin or repo clone) ---
    box_h = 175
    parts.append(rect(MARGIN, y, content_width, box_h, COLORS["distribution"], rx=8))
    parts.append(text(SVG_WIDTH // 2, y + 22, "DISTRIBUTION — Claude Code Plugin", size=15, fill=COLORS["text_light"], bold=True))
    parts.append(text(SVG_WIDTH // 2, y + 40, "(One-time setup. Pick the path that fits your team.)", size=12, fill=COLORS["text_light"]))

    dist_data = [
        ("A. Plugin install (team)", [
            "/plugin marketplace add",
            "  intel-sandbox/",
            "  intel-ai-dev-template@plugin",
            "/plugin install intel-ai-dev",
            "→ skills available everywhere",
        ]),
        ("B. Repo clone (current)", [
            "git clone <repo>",
            "cd intel-ai-dev-template",
            "open in Claude Code",
            ".claude/skills/ auto-loads",
            "→ unchanged, still works",
        ]),
    ]
    col_w = (content_width - COL_GAP * 3) // 2
    inner_y = y + 50
    inner_h = box_h - 58

    for i, (title, lines) in enumerate(dist_data):
        cx = MARGIN + COL_GAP * (i + 1) + col_w * i
        parts.append(rect(cx, inner_y, col_w, inner_h, "#1a6cb0", rx=4))
        parts.append(text(cx + col_w // 2, inner_y + 20, title, size=13, fill=COLORS["text_light"], bold=True))
        for j, line in enumerate(lines):
            parts.append(text(cx + col_w // 2, inner_y + 42 + j * 17, line, size=12, fill=COLORS["text_light"]))

    y += box_h

    # Arrow
    parts.append(arrow_down(SVG_WIDTH // 2, y, y + ARROW_GAP))
    y += ARROW_GAP

    # --- Row 1: Developer Input ---
    box_h = 80
    parts.append(rect(MARGIN, y, content_width, box_h, COLORS["input"]))
    parts.append(text(SVG_WIDTH // 2, y + 32, "DEVELOPER INPUT", size=18, fill=COLORS["text_light"], bold=True))
    parts.append(text(SVG_WIDTH // 2, y + 56, "Idea · Workshop Transcript · Technical PRD", size=14, fill=COLORS["text_light"]))
    y += box_h

    # Arrow
    parts.append(arrow_down(SVG_WIDTH // 2, y, y + ARROW_GAP))
    y += ARROW_GAP

    # --- Row 2: Five Sequential Agents ---
    box_h = 165
    parts.append(rect(MARGIN, y, content_width, box_h, COLORS["agents"], rx=8))
    parts.append(text(SVG_WIDTH // 2, y + 22, "FIVE SEQUENTIAL AGENTS", size=15, fill=COLORS["text_light"], bold=True))

    agent_data = [
        ("/prd-agent", ["Socratic Q&A →", "Tech PRD", "", "12 min"]),
        ("/dev-agent", ["Scaffold + LLM", "sub-phases", "", "30 min"]),
        ("/validation", ["Tests · Coverage", "Gaps", "", "6 min"]),
        ("/compliance", ["OSPDT · SBOM", "Scans", "", "5 min"]),
        ("/intel-review", ["Code review", "C1-C14 · PR check", "", "on-demand"]),
    ]
    agent_w = (content_width - COL_GAP * 6) // 5
    agent_y = y + 34
    agent_h = box_h - 44

    for i, (name, lines) in enumerate(agent_data):
        ax = MARGIN + COL_GAP * (i + 1) + agent_w * i
        fill = COLORS["review"] if i == 4 else "#1a7fc4"
        parts.append(rect(ax, agent_y, agent_w, agent_h, fill, rx=4))
        parts.append(text(ax + agent_w // 2, agent_y + 22, name, size=14, fill=COLORS["text_light"], bold=True))
        for j, line in enumerate(lines):
            parts.append(text(ax + agent_w // 2, agent_y + 42 + j * 18, line, size=12, fill=COLORS["text_light"]))

    y += box_h

    # Arrow
    parts.append(arrow_down(SVG_WIDTH // 2, y, y + ARROW_GAP))
    y += ARROW_GAP

    # --- Row 3: Dev Agent Hybrid Architecture ---
    box_h = 155
    hybrid_w = content_width * 0.65
    hybrid_x = MARGIN + (content_width - hybrid_w) / 2
    parts.append(rect(hybrid_x, y, hybrid_w, box_h, COLORS["hybrid"], rx=8))
    parts.append(text(SVG_WIDTH // 2, y + 22, "DEV AGENT — HYBRID ARCHITECTURE", size=15, fill=COLORS["text_dark"], bold=True))

    half_w = (hybrid_w - COL_GAP * 3) / 2
    inner_y = y + 36
    inner_h = box_h - 44

    # Layer 1
    l1_x = hybrid_x + COL_GAP
    parts.append(rect(l1_x, inner_y, half_w, inner_h, "#00b0e0", rx=4))
    l1_lines = ["Layer 1: scaffold.py", "", "151 templates", "< 3 seconds", "0 LLM context", "Deterministic"]
    for j, line in enumerate(l1_lines):
        parts.append(text(l1_x + half_w // 2, inner_y + 22 + j * 16, line, size=13,
                          fill=COLORS["text_dark"], bold=(j == 0)))

    # Layer 2
    l2_x = hybrid_x + COL_GAP * 2 + half_w
    parts.append(rect(l2_x, inner_y, half_w, inner_h, "#00b0e0", rx=4))
    l2_lines = ["Layer 2: LLM Sub-Phases", "", "Phase 4.0 → 4.9", "Focused contexts 10-30KB", "PRD-specific code", "100% completion"]
    for j, line in enumerate(l2_lines):
        parts.append(text(l2_x + half_w // 2, inner_y + 22 + j * 16, line, size=13,
                          fill=COLORS["text_dark"], bold=(j == 0)))

    y += box_h

    # Arrow
    parts.append(arrow_down(SVG_WIDTH // 2, y, y + ARROW_GAP))
    y += ARROW_GAP

    # --- Row 4: Hook Enforcement Layer ---
    box_h = 145
    hook_w = content_width * 0.65
    hook_x = MARGIN + (content_width - hook_w) / 2
    parts.append(rect(hook_x, y, hook_w, box_h, COLORS["hooks"], rx=8))
    parts.append(text(SVG_WIDTH // 2, y + 22, "HOOK ENFORCEMENT LAYER", size=15, fill=COLORS["text_dark"], bold=True))
    parts.append(text(SVG_WIDTH // 2, y + 40, "(Fires on EVERY bash command & file write)", size=12, fill=COLORS["text_dark"]))

    half_w = (hook_w - COL_GAP * 3) / 2
    inner_y = y + 50
    inner_h = box_h - 58

    # PreToolUse
    pre_x = hook_x + COL_GAP
    parts.append(rect(pre_x, inner_y, half_w, inner_h, "#e09b1d", rx=4))
    pre_lines = ["PreToolUse", "", "• secret-scanner", "• cmd-blocker", "• rollback-snapshot"]
    for j, line in enumerate(pre_lines):
        parts.append(text(pre_x + half_w // 2, inner_y + 20 + j * 15, line, size=13,
                          fill=COLORS["text_dark"], bold=(j == 0)))

    # PostToolUse
    post_x = hook_x + COL_GAP * 2 + half_w
    parts.append(rect(post_x, inner_y, half_w, inner_h, "#e09b1d", rx=4))
    post_lines = ["PostToolUse", "", "• license-header-check", "• standards-validator"]
    for j, line in enumerate(post_lines):
        parts.append(text(post_x + half_w // 2, inner_y + 20 + j * 15, line, size=13,
                          fill=COLORS["text_dark"], bold=(j == 0)))

    y += box_h

    # Arrow
    parts.append(arrow_down(SVG_WIDTH // 2, y, y + ARROW_GAP))
    y += ARROW_GAP

    # --- Row 5: Shared Infrastructure ---
    box_h = 225
    parts.append(rect(MARGIN, y, content_width, box_h, COLORS["infra"], rx=8))
    parts.append(text(SVG_WIDTH // 2, y + 22, "SHARED INFRASTRUCTURE — Cross-cuts all 5 agents", size=15, fill=COLORS["text_light"], bold=True))

    infra_data = [
        ("6 Contracts", ["• iter-state", "• output-structure", "• compliance", "• test-report", "• PRD", "• jira-mapping"]),
        ("7 UX Patterns", ["• human-in-loop", "• resumption", "• checkpoints", "• preflight", "• playwright", "• git-versioning"]),
        ("13 Standards", ["• coding · security", "• testing · helm", "• containers · CI/CD", "• observability", "• perf · UX", "• OSPDT · stack"]),
        ("5 Plugins", ["• playwright", "• code-review", "• github", "• context7", "• frontend-design"]),
        ("151 Templates", ["Backend (31)", "Frontend (44)", "Docker (3)", "Helm (16)", "CI/CD (10)", "Ansible (11)", "Config (18)"]),
    ]
    col_w = (content_width - COL_GAP * 6) // 5
    inner_y = y + 36
    inner_h = box_h - 44

    for i, (title, lines) in enumerate(infra_data):
        cx = MARGIN + COL_GAP * (i + 1) + col_w * i
        parts.append(rect(cx, inner_y, col_w, inner_h, "#5a6577", rx=4))
        parts.append(text(cx + col_w // 2, inner_y + 20, title, size=13, fill=COLORS["text_light"], bold=True))
        for j, line in enumerate(lines):
            parts.append(text(cx + col_w // 2, inner_y + 42 + j * 17, line, size=12, fill=COLORS["text_light"]))

    y += box_h

    # Arrow
    parts.append(arrow_down(SVG_WIDTH // 2, y, y + ARROW_GAP))
    y += ARROW_GAP

    # --- Row 6: Generated Outputs ---
    box_h = 215
    parts.append(rect(MARGIN, y, content_width, box_h, COLORS["outputs"], rx=8))
    parts.append(text(SVG_WIDTH // 2, y + 22, "GENERATED OUTPUTS", size=15, fill=COLORS["text_light"], bold=True))

    output_data = [
        ("Project Code", ["{project-slug}/", "", "• Backend (FastAPI)", "• Frontend (React)", "• Helm charts", "• Docker configs", "• CI/CD workflows", "• Ansible playbooks"]),
        ("Reports", ["reports/", "", "• DASHBOARD.md", "• generation/", "• validation/", "• compliance/", "• architecture/"]),
        ("Compliance Artefacts", ["", "• OSPDT BOM (.xlsx)", "• SBOM (CycloneDX)", "• SDLE diagrams", "• License inventory", "• Security scan results"]),
    ]
    col_w = (content_width - COL_GAP * 4) // 3
    inner_y = y + 36
    inner_h = box_h - 44

    for i, (title, lines) in enumerate(output_data):
        cx = MARGIN + COL_GAP * (i + 1) + col_w * i
        parts.append(rect(cx, inner_y, col_w, inner_h, "#22963e", rx=4))
        parts.append(text(cx + col_w // 2, inner_y + 20, title, size=13, fill=COLORS["text_light"], bold=True))
        for j, line in enumerate(lines):
            parts.append(text(cx + col_w // 2, inner_y + 40 + j * 17, line, size=12, fill=COLORS["text_light"]))

    y += box_h

    # Arrow
    parts.append(arrow_down(SVG_WIDTH // 2, y, y + ARROW_GAP))
    y += ARROW_GAP

    # --- Row 7: Integrations ---
    box_h = 140
    parts.append(rect(MARGIN, y, content_width, box_h, COLORS["integrations"], rx=8))
    parts.append(text(SVG_WIDTH // 2, y + 22, "INTEGRATIONS — Env-var auth or local-only fallback", size=15, fill=COLORS["text_light"], bold=True))

    integ_data = [
        ("GitHub", ["• Push code", "• Create PR", "• Status checks"]),
        ("Wiki", ["• Publish PRD", "• Publish reports", "• WIKI_PAT"]),
        ("Jira", ["• Create epics/stories", "• Update status", "• JIRA_PAT"]),
    ]
    col_w = (content_width - COL_GAP * 4) // 3
    inner_y = y + 36
    inner_h = box_h - 44

    for i, (title, lines) in enumerate(integ_data):
        cx = MARGIN + COL_GAP * (i + 1) + col_w * i
        parts.append(rect(cx, inner_y, col_w, inner_h, "#6530b8", rx=4))
        parts.append(text(cx + col_w // 2, inner_y + 22, title, size=14, fill=COLORS["text_light"], bold=True))
        for j, line in enumerate(lines):
            parts.append(text(cx + col_w // 2, inner_y + 42 + j * 17, line, size=13, fill=COLORS["text_light"]))

    y += box_h + MARGIN

    # Assemble SVG
    svg = f'''<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {SVG_WIDTH} {y}" width="{SVG_WIDTH}" height="{y}">
  <rect width="{SVG_WIDTH}" height="{y}" fill="{COLORS['bg']}" />
{chr(10).join(parts)}
</svg>'''
    return svg


def main():
    parser = argparse.ArgumentParser(description="Generate pipeline architecture SVG")
    parser.add_argument("--output", default="docs/architecture/pipeline-overview.svg",
                        help="Output SVG path")
    args = parser.parse_args()

    svg = generate_svg()
    output_path = Path(args.output)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(svg, encoding="utf-8")
    print(f"Generated: {output_path} ({output_path.stat().st_size:,} bytes)")


if __name__ == "__main__":
    main()
