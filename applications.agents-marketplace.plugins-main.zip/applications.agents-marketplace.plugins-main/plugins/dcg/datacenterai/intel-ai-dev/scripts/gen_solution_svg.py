#!/usr/bin/env python3
# Copyright (C) 2026 Intel Corporation
# SPDX-License-Identifier: Apache-2.0
"""Generate industry-standard SVG architecture diagram for a generated solution.

Reads the actual project structure (components, config, dependencies) and produces
a pixel-perfect architecture diagram with Intel brand colors.

This is the BASE script. The dev-agent (Phase 4.7) and compliance-agent (Phase 4)
both call this to generate the solution's README-embedded architecture diagram.

Usage:
    python scripts/gen_solution_svg.py --project-dir ./my-project --project-name "My AI App"
    python scripts/gen_solution_svg.py --project-dir ./my-project --output ./custom-path.svg
    python scripts/gen_solution_svg.py --project-dir ./my-project --components backend,frontend,workers
"""

import argparse
import json
import re
from pathlib import Path

# Intel brand colors
COLORS = {
    "external": "#6c757d",
    "app_bg": "#e8f4fd",
    "backend": "#003580",
    "frontend": "#0068b5",
    "worker": "#00c7fd",
    "database": "#28a745",
    "cache": "#f5a623",
    "storage": "#7c3aed",
    "inference": "#e24b4a",
    "auth": "#6c757d",
    "text_light": "#ffffff",
    "text_dark": "#1a202c",
    "arrow": "#334155",
    "bg": "#ffffff",
    "border_external": "#dee2e6",
    "border_app": "#003580",
}

SVG_WIDTH = 900
MARGIN = 40


def _escape_xml(s: str) -> str:
    return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace('"', "&quot;")


def _rect(x, y, w, h, fill, rx=8, stroke=None, stroke_width=2, opacity=1.0):
    s = f'stroke="{stroke}" stroke-width="{stroke_width}"' if stroke else 'stroke="none"'
    o = f'opacity="{opacity}"' if opacity < 1.0 else ""
    return f'  <rect x="{x}" y="{y}" width="{w}" height="{h}" fill="{fill}" rx="{rx}" {s} {o}/>'


def _text(x, y, content, size=12, fill="#fff", bold=False, anchor="middle"):
    weight = 'font-weight="bold"' if bold else ""
    safe = _escape_xml(content)
    return f'  <text x="{x}" y="{y}" font-size="{size}" fill="{fill}" text-anchor="{anchor}" font-family="Segoe UI, Arial, sans-serif" {weight}>{safe}</text>'


def _arrow(x1, y1, x2, y2, label="", dashed=False):
    dash = 'stroke-dasharray="5,5"' if dashed else ""
    lines = [
        f'  <line x1="{x1}" y1="{y1}" x2="{x2}" y2="{y2}" '
        f'stroke="{COLORS["arrow"]}" stroke-width="1.5" {dash} marker-end="url(#arrowhead)"/>'
    ]
    if label:
        mx, my = (x1 + x2) / 2, (y1 + y2) / 2 - 8
        lines.append(_text(mx, my, label, size=9, fill=COLORS["arrow"]))
    return "\n".join(lines)


def _component_box(x, y, w, h, name, tech, port, fill):
    parts = []
    parts.append(_rect(x, y, w, h, fill, rx=6))
    parts.append(_text(x + w / 2, y + h / 2 - 12, name, size=11, fill=COLORS["text_light"], bold=True))
    parts.append(_text(x + w / 2, y + h / 2 + 4, tech, size=9, fill=COLORS["text_light"]))
    if port:
        parts.append(_text(x + w / 2, y + h / 2 + 19, f":{port}", size=9, fill=COLORS["text_light"]))
    return "\n".join(parts)


def discover_project(project_dir: Path) -> dict:
    """Discover project components by reading actual files."""
    info = {
        "components": [],
        "external": [],
        "has_frontend": False,
        "has_workers": False,
        "has_agents": False,
        "has_rag": False,
        "database": None,
        "cache": None,
        "storage": None,
        "inference": None,
        "auth": None,
    }

    # Check for frontend
    if (project_dir / "frontend" / "package.json").exists():
        info["has_frontend"] = True
        info["components"].append({"name": "Frontend", "tech": "React + Vite", "port": "5173", "type": "frontend"})

    # Check for backend
    src_dir = project_dir / "src"
    if src_dir.exists():
        for component_dir in src_dir.iterdir():
            if component_dir.is_dir() and (component_dir / "app" / "main.py").exists():
                info["components"].append({"name": "Backend API", "tech": "FastAPI", "port": "8000", "type": "backend"})
                break

    # Check for workers/celery
    for pattern in ["**/tasks.py", "**/celery_app.py", "**/worker.py"]:
        if list(project_dir.glob(pattern)):
            info["has_workers"] = True
            info["components"].append({"name": "Workers", "tech": "Celery/ARQ", "port": None, "type": "worker"})
            break

    # Check for agents
    for pattern in ["**/agents/**/*.py", "**/agent_graph.py"]:
        if list(project_dir.glob(pattern)):
            info["has_agents"] = True
            info["components"].append({"name": "Agent Orchestrator", "tech": "LangGraph", "port": None, "type": "worker"})
            break

    # Check for RAG
    for pattern in ["**/rag/**/*.py", "**/retriever.py", "**/vector_store.py"]:
        if list(project_dir.glob(pattern)):
            info["has_rag"] = True
            info["components"].append({"name": "RAG Pipeline", "tech": "Retrieval + Embeddings", "port": None, "type": "worker"})
            break

    # Check config/requirements for external deps
    req_files = list(project_dir.glob("**/requirements.txt"))
    env_files = list(project_dir.glob("**/.env.example")) + list(project_dir.glob("**/config.py"))
    all_text = ""
    for f in req_files + env_files:
        try:
            all_text += f.read_text(encoding="utf-8", errors="ignore")
        except Exception:
            pass

    # Database
    if "postgresql" in all_text.lower() or "asyncpg" in all_text.lower():
        info["database"] = "PostgreSQL"
    elif "sqlite" in all_text.lower():
        info["database"] = "SQLite"

    # Cache
    if "redis" in all_text.lower():
        info["cache"] = "Redis"

    # Storage
    if "minio" in all_text.lower() or "s3" in all_text.lower() or "boto3" in all_text.lower():
        info["storage"] = "MinIO/S3"

    # Inference
    if "enterprise" in all_text.lower() and "inference" in all_text.lower():
        info["inference"] = "Enterprise Inference"
    elif "vllm" in all_text.lower():
        info["inference"] = "vLLM (Direct)"
    elif "openai" in all_text.lower() or "litellm" in all_text.lower():
        info["inference"] = "LLM (OpenAI-compat)"

    # Auth
    if "keycloak" in all_text.lower():
        info["auth"] = "Keycloak"
    elif "jwt" in all_text.lower() or "auth" in all_text.lower():
        info["auth"] = "JWT Auth"

    # Vector DB (for RAG)
    if "chroma" in all_text.lower() or "pgvector" in all_text.lower() or "milvus" in all_text.lower():
        info["external"].append({"name": "Vector DB", "tech": "Chroma/pgvector"})

    # Build external dependencies list
    if info["inference"]:
        info["external"].append({"name": info["inference"], "tech": "OpenAI-compat /v1 API"})
    if info["auth"]:
        info["external"].append({"name": info["auth"], "tech": "OIDC/OAuth2"})

    return info


def generate_svg(project_info: dict, project_name: str) -> str:
    """Generate SVG from discovered project info."""
    parts = []
    y = MARGIN

    # Title
    parts.append(_text(SVG_WIDTH / 2, y + 20, f"{project_name} — Solution Architecture",
                       size=16, fill=COLORS["text_dark"], bold=True))
    y += 50

    # External services section
    ext_services = project_info["external"]
    if ext_services:
        ext_h = 70
        ext_w = SVG_WIDTH - 2 * MARGIN
        parts.append(_rect(MARGIN, y, ext_w, ext_h, "#f8f9fa", rx=8, stroke=COLORS["border_external"]))
        parts.append(_text(MARGIN + 10, y + 16, "External Services", size=10,
                           fill=COLORS["external"], bold=True, anchor="start"))

        box_w = min(180, (ext_w - 20) // max(len(ext_services), 1) - 10)
        for i, svc in enumerate(ext_services):
            bx = MARGIN + 15 + i * (box_w + 15)
            color = COLORS["inference"] if "Inference" in svc["name"] or "LLM" in svc["name"] or "vLLM" in svc["name"] else COLORS["auth"]
            parts.append(_component_box(bx, y + 25, box_w, 38, svc["name"], svc["tech"], None, color))

        y += ext_h + 20

    # Arrows from external to app
    arrow_start_y = y - 10
    app_start_y = y

    # Application boundary
    app_components = project_info["components"]
    infra_items = []
    if project_info["database"]:
        infra_items.append(("database", project_info["database"], "5432"))
    if project_info["cache"]:
        infra_items.append(("cache", project_info["cache"], "6379"))
    if project_info["storage"]:
        infra_items.append(("storage", project_info["storage"], "9000"))

    # Calculate app section height
    has_middle_row = project_info["has_workers"] or project_info["has_agents"] or project_info["has_rag"]
    app_h = 180 if has_middle_row else 120
    if infra_items:
        app_h += 70

    app_w = SVG_WIDTH - 2 * MARGIN
    parts.append(_rect(MARGIN, y, app_w, app_h, COLORS["app_bg"], rx=10, stroke=COLORS["border_app"]))
    parts.append(_text(MARGIN + 10, y + 18, "Application", size=10,
                       fill=COLORS["border_app"], bold=True, anchor="start"))

    # Top row: Frontend + Backend
    row_y = y + 30
    top_components = [c for c in app_components if c["type"] in ("frontend", "backend")]
    col_w = 160
    col_gap = 40
    total_top_w = len(top_components) * col_w + (len(top_components) - 1) * col_gap
    start_x = MARGIN + (app_w - total_top_w) / 2

    component_positions = {}
    for i, comp in enumerate(top_components):
        cx = start_x + i * (col_w + col_gap)
        color = COLORS["frontend"] if comp["type"] == "frontend" else COLORS["backend"]
        parts.append(_component_box(cx, row_y, col_w, 55, comp["name"], comp["tech"], comp["port"], color))
        component_positions[comp["type"]] = (cx + col_w / 2, row_y + 55)

    # Arrow between frontend and backend
    if "frontend" in component_positions and "backend" in component_positions:
        fx, fy = component_positions["frontend"]
        bx, by = component_positions["backend"]
        parts.append(_arrow(fx + col_w / 2 - 10, fy - 27, bx - col_w / 2 + 10, by - 27, "REST /api/v1"))

    # Middle row: Workers / Agents / RAG
    if has_middle_row:
        mid_y = row_y + 75
        middle_components = [c for c in app_components if c["type"] == "worker"]
        total_mid_w = len(middle_components) * col_w + (len(middle_components) - 1) * col_gap
        mid_start_x = MARGIN + (app_w - total_mid_w) / 2

        for i, comp in enumerate(middle_components):
            cx = mid_start_x + i * (col_w + col_gap)
            parts.append(_component_box(cx, mid_y, col_w, 50, comp["name"], comp["tech"], comp["port"], COLORS["worker"]))

        # Arrow from backend to workers
        if "backend" in component_positions and middle_components:
            bx, by = component_positions["backend"]
            parts.append(_arrow(bx, by, bx, mid_y, "async"))

    # Infrastructure row
    if infra_items:
        infra_y = row_y + (150 if has_middle_row else 75)
        infra_w = 120
        infra_gap = 30
        total_infra_w = len(infra_items) * infra_w + (len(infra_items) - 1) * infra_gap
        infra_start_x = MARGIN + (app_w - total_infra_w) / 2

        for i, (itype, iname, iport) in enumerate(infra_items):
            ix = infra_start_x + i * (infra_w + infra_gap)
            color = COLORS.get(itype, COLORS["database"])
            parts.append(_component_box(ix, infra_y, infra_w, 45, iname, "", iport, color))

    y += app_h + MARGIN

    # Legend
    legend_y = y + 10
    legend_items = [
        (COLORS["backend"], "Backend"),
        (COLORS["frontend"], "Frontend"),
        (COLORS["worker"], "Workers/Agents"),
        (COLORS["database"], "Database"),
        (COLORS["inference"], "AI/Inference"),
    ]
    parts.append(_text(MARGIN, legend_y, "Legend:", size=9, fill=COLORS["text_dark"], bold=True, anchor="start"))
    for i, (color, label) in enumerate(legend_items):
        lx = MARGIN + 50 + i * 130
        parts.append(f'  <rect x="{lx}" y="{legend_y - 8}" width="12" height="12" fill="{color}" rx="2"/>')
        parts.append(_text(lx + 18, legend_y + 2, label, size=9, fill=COLORS["text_dark"], anchor="start"))

    y = legend_y + 30

    # Arrow marker definition
    defs = '''  <defs>
    <marker id="arrowhead" markerWidth="10" markerHeight="7" refX="9" refY="3.5" orient="auto">
      <polygon points="0 0, 10 3.5, 0 7" fill="#334155"/>
    </marker>
  </defs>'''

    svg = f'''<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {SVG_WIDTH} {y}" width="{SVG_WIDTH}" height="{y}">
{defs}
  <rect width="{SVG_WIDTH}" height="{y}" fill="{COLORS['bg']}" />
{chr(10).join(parts)}
</svg>'''
    return svg


def main():
    parser = argparse.ArgumentParser(description="Generate solution architecture SVG")
    parser.add_argument("--project-dir", required=True, help="Path to the generated project")
    parser.add_argument("--project-name", default="AI Solution", help="Project display name")
    parser.add_argument("--output", default=None, help="Output SVG path (default: project-dir/docs/architecture/solution-overview.svg)")
    parser.add_argument("--components", default=None, help="Comma-separated component override (backend,frontend,workers)")
    args = parser.parse_args()

    project_dir = Path(args.project_dir)
    if not project_dir.exists():
        print(f"Error: {project_dir} not found")
        return

    output_path = Path(args.output) if args.output else project_dir / "docs" / "architecture" / "solution-overview.svg"
    output_path.parent.mkdir(parents=True, exist_ok=True)

    # Discover or use overrides
    project_info = discover_project(project_dir)

    if not project_info["components"]:
        print("WARNING: No components discovered — generating minimal diagram")
        project_info["components"] = [{"name": "Backend API", "tech": "FastAPI", "port": "8000", "type": "backend"}]

    print(f"Discovered: {len(project_info['components'])} components, {len(project_info['external'])} external deps")
    for c in project_info["components"]:
        print(f"  - {c['name']} ({c['tech']}) :{c.get('port', '—')}")
    for e in project_info["external"]:
        print(f"  - [ext] {e['name']} ({e['tech']})")

    svg = generate_svg(project_info, args.project_name)
    output_path.write_text(svg, encoding="utf-8")
    print(f"\nGenerated: {output_path} ({output_path.stat().st_size:,} bytes)")


if __name__ == "__main__":
    main()
