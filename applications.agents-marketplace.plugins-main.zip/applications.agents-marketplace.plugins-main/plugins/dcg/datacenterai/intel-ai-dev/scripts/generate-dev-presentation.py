# Copyright (C) 2026 Intel Corporation
# SPDX-License-Identifier: Apache-2.0
"""Generate enterprise presentation: Intel AI Solutions Development Pipeline.
Updated: 2026-05-07 — reflects hardened dev-agent, real-infra sanity, C1-C14 rules.
"""

from pptx import Presentation
from pptx.util import Inches, Pt, Emu
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
from pptx.enum.shapes import MSO_SHAPE
import os

# Intel brand colors
INTEL_BLUE = RGBColor(0x00, 0x35, 0x80)
INTEL_LIGHT_BLUE = RGBColor(0x00, 0xC7, 0xFD)
INTEL_DARK = RGBColor(0x1A, 0x1A, 0x2E)
INTEL_GRAY = RGBColor(0x4A, 0x4A, 0x4A)
INTEL_LIGHT_GRAY = RGBColor(0xF0, 0xF0, 0xF5)
WHITE = RGBColor(0xFF, 0xFF, 0xFF)
GREEN = RGBColor(0x00, 0x80, 0x4B)
RED = RGBColor(0xC0, 0x39, 0x2B)
ORANGE = RGBColor(0xE6, 0x7E, 0x22)
YELLOW_DARK = RGBColor(0xB8, 0x86, 0x0B)


def set_slide_bg(slide, color):
    bg = slide.background
    fill = bg.fill
    fill.solid()
    fill.fore_color.rgb = color


def add_text_box(slide, left, top, width, height, text, font_size=14,
                 bold=False, color=INTEL_GRAY, align=PP_ALIGN.LEFT, font_name="Segoe UI"):
    txBox = slide.shapes.add_textbox(left, top, width, height)
    tf = txBox.text_frame
    tf.word_wrap = True
    p = tf.paragraphs[0]
    p.text = text
    p.font.size = Pt(font_size)
    p.font.bold = bold
    p.font.color.rgb = color
    p.font.name = font_name
    p.alignment = align
    return tf


def add_bullet_slide(slide, bullets, left, top, width, height,
                     font_size=13, color=INTEL_GRAY, spacing=Pt(6)):
    txBox = slide.shapes.add_textbox(left, top, width, height)
    tf = txBox.text_frame
    tf.word_wrap = True
    for i, bullet in enumerate(bullets):
        if i == 0:
            p = tf.paragraphs[0]
        else:
            p = tf.add_paragraph()
        p.text = bullet
        p.font.size = Pt(font_size)
        p.font.color.rgb = color
        p.font.name = "Segoe UI"
        p.space_after = spacing
        p.level = 0
    return tf


def add_title_bar(slide, title, subtitle=""):
    shape = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, 0, 0, Inches(13.33), Inches(1.3))
    shape.fill.solid()
    shape.fill.fore_color.rgb = INTEL_BLUE
    shape.line.fill.background()

    add_text_box(slide, Inches(0.5), Inches(0.2), Inches(12), Inches(0.7),
                 title, font_size=26, bold=True, color=WHITE)
    if subtitle:
        add_text_box(slide, Inches(0.5), Inches(0.8), Inches(12), Inches(0.4),
                     subtitle, font_size=13, color=INTEL_LIGHT_BLUE)


def add_section_divider(prs, title, subtitle=""):
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    set_slide_bg(slide, INTEL_DARK)

    add_text_box(slide, Inches(1), Inches(2.5), Inches(11), Inches(1),
                 title, font_size=36, bold=True, color=WHITE, align=PP_ALIGN.CENTER)
    if subtitle:
        add_text_box(slide, Inches(1), Inches(3.6), Inches(11), Inches(0.8),
                     subtitle, font_size=18, color=INTEL_LIGHT_BLUE, align=PP_ALIGN.CENTER)

    shape = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(5), Inches(3.3),
                                   Inches(3.33), Inches(0.05))
    shape.fill.solid()
    shape.fill.fore_color.rgb = INTEL_LIGHT_BLUE
    shape.line.fill.background()


def add_status_badge(slide, x, y, text, color):
    badge = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE,
                                   x, y, Inches(1.8), Inches(0.32))
    badge.fill.solid()
    badge.fill.fore_color.rgb = color
    badge.line.fill.background()
    badge_tf = badge.text_frame
    badge_tf.word_wrap = False
    badge_tf.vertical_anchor = MSO_ANCHOR.MIDDLE
    bp = badge_tf.paragraphs[0]
    bp.text = text
    bp.font.size = Pt(9)
    bp.font.bold = True
    bp.font.color.rgb = WHITE
    bp.alignment = PP_ALIGN.CENTER


def create_presentation():
    prs = Presentation()
    prs.slide_width = Inches(13.33)
    prs.slide_height = Inches(7.5)

    # =========================================================================
    # TITLE SLIDE
    # =========================================================================
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    set_slide_bg(slide, INTEL_BLUE)

    add_text_box(slide, Inches(1), Inches(1.5), Inches(11), Inches(1.2),
                 "Intel AI Solutions Development Pipeline",
                 font_size=36, bold=True, color=WHITE, align=PP_ALIGN.CENTER)

    add_text_box(slide, Inches(1), Inches(2.8), Inches(11), Inches(0.8),
                 "One Developer + Claude Code = Production-Ready AI Products",
                 font_size=20, color=INTEL_LIGHT_BLUE, align=PP_ALIGN.CENTER)

    add_text_box(slide, Inches(1), Inches(4.0), Inches(11), Inches(1.5),
                 "Structured Execution \u2022 No Missed Steps \u2022 Deterministic Output\n"
                 "Real Infrastructure Testing \u2022 Complete Working Product",
                 font_size=16, color=WHITE, align=PP_ALIGN.CENTER)

    add_text_box(slide, Inches(1), Inches(6.2), Inches(11), Inches(0.5),
                 "Intel Corporation  |  AI Software Engineering  |  May 2026",
                 font_size=12, color=INTEL_LIGHT_BLUE, align=PP_ALIGN.CENTER)

    # =========================================================================
    # PART 1: WHY THIS EXISTS (Pain Points + Value)
    # =========================================================================
    add_section_divider(prs, "PART 1", "Why This Pipeline Exists \u2014 The Problem & The Solution")

    # --- SLIDE: What Developers Say ---
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    set_slide_bg(slide, WHITE)
    add_title_bar(slide, "What Developers Say", "\"I have Claude/Copilot. I can ask it to build anything.\"")

    bullets = [
        "True. But here's what ACTUALLY happens:",
        "",
        "\u2022 Claude generates 50 files \u2014 10 have broken imports, routes unregistered",
        "\u2022 Frontend calls endpoints that don't exist (phantom endpoints)",
        "\u2022 Auth store expects 'token', backend sends 'access_token'",
        "\u2022 App starts \u2014 but upload a file? Nothing happens. Job stays 'pending' forever.",
        "\u2022 Dev A asks Claude for a dashboard: Material UI + Redux",
        "  Dev B asks the same thing: Tailwind + Zustand. No consistency.",
        "\u2022 Production readiness? Dockerfile, Helm, CI/CD, SBOM, OSPDT \u2014 all manual",
        "",
        "Result: 2\u20134 WEEKS from idea to deployable product.",
        "Developer spends 60% of time on integration and fixing AI-generated errors.",
    ]
    add_bullet_slide(slide, bullets, Inches(0.7), Inches(1.6), Inches(12), Inches(5.5),
                     font_size=14)

    # --- SLIDE: 5 Pain Points ---
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    set_slide_bg(slide, WHITE)
    add_title_bar(slide, "5 Pain Points This Pipeline Addresses")

    pain_points = [
        ("1. Generated code doesn't integrate", "Files exist but don't connect. You spend days wiring."),
        ("2. Every developer gets different output", "No consistency \u2014 same prompt, different patterns, different UI."),
        ("3. \"It starts\" but doesn't actually work", "Server runs but no functional flow completes end-to-end."),
        ("4. Production readiness = separate effort", "Docker, Helm, CI/CD, SBOM, OSPDT \u2014 adds weeks."),
        ("5. No traceability", "Requirement \u2192 code \u2192 test chain doesn't exist. Drift is invisible."),
    ]
    y = Inches(1.5)
    for title, desc in pain_points:
        add_text_box(slide, Inches(0.5), y, Inches(12), Inches(0.4),
                     title, font_size=14, bold=True, color=INTEL_BLUE)
        add_text_box(slide, Inches(0.5), y + Inches(0.38), Inches(12), Inches(0.4),
                     desc, font_size=12, color=INTEL_GRAY)
        y += Inches(0.95)

    # --- SLIDE: The Comparison ---
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    set_slide_bg(slide, WHITE)
    add_title_bar(slide, "Claude Alone vs Claude + Structured Pipeline",
                  "Same AI, radically different outcome")

    left_bullets = [
        "Claude/Copilot ALONE:",
        "",
        "\u2022 Output quality: Variable",
        "\u2022 Integration: Manual wiring",
        "\u2022 Functional testing: \"App starts\"",
        "\u2022 Team consistency: Every dev different",
        "\u2022 Production ready: Weeks of hardening",
        "\u2022 Compliance: Manual audit",
        "\u2022 Traceability: None",
        "\u2022 Time to deploy: 2\u20134 weeks",
    ]
    right_bullets = [
        "Claude + THIS PIPELINE:",
        "",
        "\u2022 Output quality: Deterministic",
        "\u2022 Integration: Pre-integrated templates",
        "\u2022 Functional testing: \"Product works E2E\"",
        "\u2022 Team consistency: Same PRD = Same output",
        "\u2022 Production ready: Day 1",
        "\u2022 Compliance: Automated (one command)",
        "\u2022 Traceability: PRD \u2192 Code \u2192 Test \u2192 Deploy",
        "\u2022 Time to deploy: 2\u20134 hours",
    ]
    add_bullet_slide(slide, left_bullets, Inches(0.5), Inches(1.6), Inches(6), Inches(5.5),
                     font_size=14, color=RED)
    add_bullet_slide(slide, right_bullets, Inches(6.8), Inches(1.6), Inches(6), Inches(5.5),
                     font_size=14, color=GREEN)

    # --- SLIDE: What Claude Does Well vs What It Cannot ---
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    set_slide_bg(slide, WHITE)
    add_title_bar(slide, "What We're NOT Replacing",
                  "Claude is excellent at some things. We add what it cannot do alone.")

    left_bullets = [
        "Claude ALONE excels at:",
        "",
        "\u2022 Code completion in existing files",
        "\u2022 Explaining code & concepts",
        "\u2022 Debugging specific errors",
        "\u2022 One-off scripts & utilities",
        "\u2022 Answering questions",
        "\u2022 Refactoring known patterns",
    ]
    right_bullets = [
        "Pipeline ADDS (Claude alone cannot):",
        "",
        "\u2022 Ensure cross-file integration",
        "\u2022 Enforce team-wide patterns",
        "\u2022 Validate E2E flows with real infra",
        "\u2022 Generate compliance artifacts",
        "\u2022 Track PRD \u2192 code \u2192 test traceability",
        "\u2022 Guarantee deterministic output",
        "\u2022 Make production-readiness decisions",
        "\u2022 Announce/iterate between phases",
    ]
    add_bullet_slide(slide, left_bullets, Inches(0.5), Inches(1.6), Inches(6), Inches(5.5),
                     font_size=14)
    add_bullet_slide(slide, right_bullets, Inches(6.8), Inches(1.6), Inches(6), Inches(5.5),
                     font_size=14)

    add_text_box(slide, Inches(1), Inches(6.5), Inches(11), Inches(0.5),
                 "The pipeline doesn't replace Claude \u2014 it gives Claude RAILS TO RUN ON.",
                 font_size=14, bold=True, color=INTEL_BLUE, align=PP_ALIGN.CENTER)

    # =========================================================================
    # PART 2: HOW IT WORKS
    # =========================================================================
    add_section_divider(prs, "PART 2", "How It Works \u2014 4 Agents, Structured Execution")

    # --- SLIDE: The Pipeline Flow ---
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    set_slide_bg(slide, WHITE)
    add_title_bar(slide, "The Pipeline", "4 agents \u2014 each phase announces, executes, summarizes")

    phases = [
        ("/prd-agent", "Requirements\n25-35 min Q&A", "docs/prd/", INTEL_BLUE),
        ("/dev-agent", "Product Generation\n+ Dev Sanity", "Working product", RGBColor(0x00, 0x50, 0xA0)),
        ("/validation", "Test Generation\n+ Execution", "reports/validation/", RGBColor(0x00, 0x6B, 0xC0)),
        ("/compliance", "Security + OSPDT\n+ SBOM + SDLE", "reports/DASHBOARD.md", RGBColor(0x00, 0x85, 0xD0)),
    ]

    x_start = Inches(0.5)
    for i, (name, desc, output, box_color) in enumerate(phases):
        x = x_start + Inches(i * 3.2)
        shape = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE,
                                       x, Inches(2.0), Inches(2.8), Inches(2.5))
        shape.fill.solid()
        shape.fill.fore_color.rgb = box_color
        shape.line.fill.background()
        tf = shape.text_frame
        tf.word_wrap = True
        tf.vertical_anchor = MSO_ANCHOR.MIDDLE
        p = tf.paragraphs[0]
        p.text = name
        p.font.size = Pt(15)
        p.font.bold = True
        p.font.color.rgb = WHITE
        p.alignment = PP_ALIGN.CENTER
        p2 = tf.add_paragraph()
        p2.text = desc
        p2.font.size = Pt(11)
        p2.font.color.rgb = INTEL_LIGHT_BLUE
        p2.alignment = PP_ALIGN.CENTER

        add_text_box(slide, x, Inches(4.7), Inches(2.8), Inches(0.5),
                     f"Output: {output}", font_size=9, color=INTEL_GRAY,
                     align=PP_ALIGN.CENTER)

        if i < 3:
            arrow_x = x + Inches(2.8)
            add_text_box(slide, arrow_x, Inches(2.9), Inches(0.4), Inches(0.5),
                         "\u2192", font_size=24, bold=True, color=INTEL_BLUE,
                         align=PP_ALIGN.CENTER)

    add_text_box(slide, Inches(0.5), Inches(5.5), Inches(12), Inches(1.5),
                 "EVERY phase: Announce what you'll do \u2192 Execute \u2192 Summarize what was achieved \u2192 Developer iterates or proceeds\n"
                 "EVERY phase boundary: Program Checkpoints (Wiki + Jira + Git) \u2192 Memory Save\n"
                 "Developer has FULL CONTROL at every step. Nothing happens silently.",
                 font_size=12, color=INTEL_GRAY, align=PP_ALIGN.CENTER)

    # --- SLIDE: Phase Announce/Summary Pattern ---
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    set_slide_bg(slide, WHITE)
    add_title_bar(slide, "Developer Control: Announce \u2192 Execute \u2192 Summarize",
                  "No silent work. Developer catches discrepancies before they compound.")

    left_bullets = [
        "BEFORE every phase:",
        "",
        "\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500",
        "\u25b6 STARTING: Phase Name",
        "\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500",
        "Based on your input:",
        "\u2022 Action 1 (specific)",
        "\u2022 Action 2 (specific)",
        "\u2022 Action 3 (specific)",
        "",
        "Expected output: {files}",
        "\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500",
        "",
        "Developer confirms or adjusts.",
    ]
    right_bullets = [
        "AFTER every phase:",
        "",
        "\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500",
        "\u2705 COMPLETED: Phase Name",
        "\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500",
        "What was done:",
        "\u2022 Result 1 (concrete)",
        "\u2022 Result 2 (concrete)",
        "Issues found:",
        "\u2022 Issue (if any)",
        "",
        "OPTIONS:",
        "1. Proceed to next phase",
        "2. Iterate (fix/change/re-run)",
        "3. Review output",
    ]
    add_bullet_slide(slide, left_bullets, Inches(0.5), Inches(1.6), Inches(6), Inches(5.5),
                     font_size=12)
    add_bullet_slide(slide, right_bullets, Inches(6.8), Inches(1.6), Inches(6), Inches(5.5),
                     font_size=12)

    # --- SLIDE: Dev Agent — The Product Builder ---
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    set_slide_bg(slide, WHITE)
    add_title_bar(slide, "Dev Agent: Not a Code Generator \u2014 A Product Builder",
                  "At exit, developer holds a COMPLETE WORKING PRODUCT")

    bullets = [
        "Phase 1-3: Generate project (templates + PRD-specific code)",
        "Phase 4: PRD-specific endpoints, models, services, frontend features",
        "",
        "Phase 4.5: DEV SANITY (the differentiator)",
        "  \u2022 Ask developer: What REAL infrastructure do you have?",
        "  \u2022 Validate: EI reachable? Redis pingable? DB connectable?",
        "  \u2022 Test EVERY functional flow end-to-end with REAL services",
        "  \u2022 NO MOCKS \u2014 if flow doesn't work, fix it. Iterate until it does.",
        "",
        "Phase 4.6: Code Integration Audit (10-point check)",
        "  \u2022 All imports resolve, all routes registered, all types match",
        "",
        "Phase 4.7: Production-Ready README (generated AFTER code is verified)",
        "",
        "Phase 4.8: Developer validates README as a customer would",
        "  \u2022 Follow it from scratch. If anything fails, fix and re-generate.",
    ]
    add_bullet_slide(slide, bullets, Inches(0.5), Inches(1.6), Inches(12), Inches(5.5),
                     font_size=13)

    # --- SLIDE: Dev Sanity — Real Infra, No Mocks ---
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    set_slide_bg(slide, WHITE)
    add_title_bar(slide, "Dev Sanity = Production Sanity \u2212 Kubernetes",
                  "Test with REAL infrastructure. Mock exists for CI only.")

    left_bullets = [
        "Infrastructure Decision Gate:",
        "",
        "1. LLM Inference:",
        "   \u2192 Provide your EI endpoint + token",
        "   \u2192 EI not available? Deploy first.",
        "",
        "2. Task Queue:",
        "   A) Redis running \u2192 provide URL",
        "   B) Inline processing (same code)",
        "",
        "3. Storage:",
        "   A) MinIO running \u2192 credentials",
        "   B) Local filesystem (./data/)",
        "",
        "4. Database:",
        "   A) PostgreSQL \u2192 connection URL",
        "   B) SQLite (same ORM)",
        "",
        "5. Auth:",
        "   A) Keycloak \u2192 realm URL",
        "   B) Dev bypass (middleware active)",
    ]
    right_bullets = [
        "What Gets Verified (ALL mandatory):",
        "",
        "\u2022 Backend starts, /healthz responds",
        "\u2022 EI connectivity confirmed (real models)",
        "\u2022 CREATE resource \u2192 returns ID",
        "\u2022 PROCESS completes (real EI output)",
        "\u2022 DOWNLOAD output file exists, valid",
        "\u2022 LIST/GET/DELETE \u2192 CRUD works",
        "\u2022 Frontend serves HTML",
        "\u2022 Vite proxy routes to backend",
        "\u2022 Frontend types match backend",
        "\u2022 Docker images build",
        "",
        "If ANY flow fails:",
        "  1. Identify root cause",
        "  2. Fix generated code",
        "  3. Re-run (max 3 iterations)",
        "  4. Report to developer",
    ]
    add_bullet_slide(slide, left_bullets, Inches(0.3), Inches(1.6), Inches(6.2), Inches(5.5),
                     font_size=11)
    add_bullet_slide(slide, right_bullets, Inches(6.6), Inches(1.6), Inches(6.5), Inches(5.5),
                     font_size=11)

    # --- SLIDE: Contract Enforcement C1-C14 ---
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    set_slide_bg(slide, WHITE)
    add_title_bar(slide, "14 Contract Enforcement Rules",
                  "Violations are IMPOSSIBLE in generated output \u2014 enforced at template level")

    rules = [
        ("C1", "List endpoints always return {items, total, page, size}"),
        ("C2", "All entity IDs are 'id' (never 'job_id', 'upload_id')"),
        ("C3", "Auth contract: backend returns {access_token, user: {id, username}}"),
        ("C4", "Frontend types extend BaseEntity {id, created_at, updated_at}"),
        ("C5", "API paths: always /api/v1/... (Vite proxy catches /api/*)"),
        ("C6", "No reserved column names (metadata, type, input, key)"),
        ("C7", "Celery dev-mode: inline processing (same pipeline code)"),
        ("C8", "DB portability: UUIDType(CHAR(36)) works on SQLite + PostgreSQL"),
        ("C9", "Frontend field names EXACTLY match backend schema fields"),
        ("C10", "Every frontend API call has a registered backend endpoint"),
        ("C11", "Dev-mode exercises SAME code paths (substitutes infra, not logic)"),
        ("C12", "Projects with output files MUST have download + report endpoints"),
        ("C13", "DETERMINISTIC: Same PRD = same files, same UI, same patterns"),
        ("C14", "NO ORPHAN CODE: every file reachable from main.py / main.tsx"),
    ]
    y = Inches(1.5)
    for code, desc in rules:
        add_status_badge(slide, Inches(0.3), y, code, INTEL_BLUE)
        add_text_box(slide, Inches(2.2), y, Inches(10.8), Inches(0.35),
                     desc, font_size=11, color=INTEL_GRAY)
        y += Inches(0.4)

    # --- SLIDE: Deterministic Output ---
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    set_slide_bg(slide, WHITE)
    add_title_bar(slide, "Determinism: Same PRD = Same Product",
                  "Two developers, same PRD \u2192 identical project structure, UI, and code patterns")

    bullets = [
        "Three tiers of generated content:",
        "",
        "Tier 1 \u2014 Static Templates (70% of files):",
        "  \u2022 Exact copy with variable substitution only",
        "  \u2022 Makefile, Dockerfile, CI workflows, Helm charts",
        "  \u2022 Bit-for-bit identical across runs",
        "",
        "Tier 2 \u2014 Pattern-Based Generation (20% of files):",
        "  \u2022 Follow embedded code patterns (items.py.tmpl \u2192 any resource)",
        "  \u2022 Same structure, PRD-specific field names",
        "  \u2022 Frontend ALWAYS: Tailwind + Intel design, sidebar layout, feature folders",
        "",
        "Tier 3 \u2014 PRD-Specific Logic (10% of files):",
        "  \u2022 Business logic stubs from acceptance criteria",
        "  \u2022 Template-guided: same input \u2192 same output",
        "",
        "Rule C13 enforces: no creative decisions. Template defaults or PRD specifies.",
    ]
    add_bullet_slide(slide, bullets, Inches(0.5), Inches(1.6), Inches(12), Inches(5.5),
                     font_size=13)

    # --- SLIDE: What Gets Generated ---
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    set_slide_bg(slide, WHITE)
    add_title_bar(slide, "What Gets Generated", "Complete project \u2014 not scaffolding")

    left_bullets = [
        "Backend (FastAPI + SQLAlchemy 2.0 async):",
        "  \u2022 API endpoints from PRD user stories",
        "  \u2022 Inference client (EI or vLLM)",
        "  \u2022 Storage abstraction (local / MinIO)",
        "  \u2022 Pipeline runner (inline + Celery)",
        "  \u2022 Auth (local JWT or Keycloak)",
        "  \u2022 Observability (structlog + Prometheus + OTEL)",
        "  \u2022 Security headers, CORS, rate limiting",
        "",
        "Frontend (React 18 + TypeScript strict):",
        "  \u2022 Feature-folder architecture",
        "  \u2022 Intel design system (Tailwind)",
        "  \u2022 Auth flow (login/register)",
        "  \u2022 API client with type safety",
    ]
    right_bullets = [
        "Infrastructure:",
        "  \u2022 Helm chart (200+ params, zero-trust)",
        "  \u2022 Docker (multi-stage, uid=1000)",
        "  \u2022 CI/CD (5 GitHub Actions workflows)",
        "  \u2022 Ansible playbooks (6 plays)",
        "  \u2022 Docker Compose (full stack)",
        "",
        "Compliance (built-in, not bolted on):",
        "  \u2022 Intel Apache-2.0 headers",
        "  \u2022 CNCF governance files",
        "  \u2022 Security scans config",
        "  \u2022 .env.example (documented)",
        "  \u2022 README (14 required sections)",
        "",
        "Total: 150\u2013200 files per project",
    ]
    add_bullet_slide(slide, left_bullets, Inches(0.5), Inches(1.6), Inches(6), Inches(5.5),
                     font_size=12)
    add_bullet_slide(slide, right_bullets, Inches(6.8), Inches(1.6), Inches(6), Inches(5.5),
                     font_size=12)

    # =========================================================================
    # PART 3: CURRENT STATE & VALIDATION STATUS
    # =========================================================================
    add_section_divider(prs, "PART 3", "Current State \u2014 What's Validated, What's Next")

    # --- SLIDE: Pipeline Validation Status ---
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    set_slide_bg(slide, WHITE)
    add_title_bar(slide, "Pipeline Validation Status", "As of 2026-05-07")

    items = [
        ("VALIDATED", "PRD Agent \u2014 15-area Q&A, handoff metadata, Wiki/Jira export", GREEN),
        ("VALIDATED", "Dev Agent \u2014 Template generation, variable substitution, file structure", GREEN),
        ("VALIDATED", "Dev Sanity \u2014 Backend startup, health, auth, contract checks", GREEN),
        ("VALIDATED", "Contract Rules C1\u2013C14 \u2014 Frontend-backend consistency enforcement", GREEN),
        ("VALIDATED", "Template System \u2014 55 backend + 55 frontend + infra templates", GREEN),
        ("VALIDATED", "Session Continuity \u2014 .iteration-state.json + memory + git", GREEN),
        ("HARDENED", "Dev Agent Phase 4.5\u20134.8 \u2014 Real-infra sanity, code audit, README verify", ORANGE),
        ("HARDENED", "Announce/Summary Pattern \u2014 All 4 agents updated", ORANGE),
        ("NEEDS TEST", "Validation Agent \u2014 Test generation from PRD criteria (structure done)", YELLOW_DARK),
        ("NEEDS TEST", "Compliance Agent \u2014 Scans + OSPDT + SDLE + SBOM (structure done)", YELLOW_DARK),
        ("NEEDS TEST", "Multi-developer determinism \u2014 Same PRD different devs", YELLOW_DARK),
        ("NOT STARTED", "Agentic Stack integration \u2014 Planned Q2 2026", RED),
    ]
    y = Inches(1.5)
    for status, desc, color in items:
        add_status_badge(slide, Inches(0.3), y, status, color)
        add_text_box(slide, Inches(2.3), y, Inches(10.7), Inches(0.35),
                     desc, font_size=11, color=INTEL_DARK)
        y += Inches(0.47)

    # --- SLIDE: What Was Fixed (Latest Hardening) ---
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    set_slide_bg(slide, WHITE)
    add_title_bar(slide, "Latest Hardening (This Session)", "19 files modified/created")

    bullets = [
        "Philosophy Change: Dev Sanity now tests with REAL infrastructure (no mocks)",
        "",
        "Template Fixes:",
        "  \u2022 Added __init__.py for storage/, services/, inference/ packages",
        "  \u2022 Added list_models() to EIClient (was missing)",
        "  \u2022 Pipeline runner now imports storage backend + has stage guidance",
        "  \u2022 Frontend .env with VITE_AUTH_REQUIRED documented",
        "  \u2022 Makefile: added 'dev' (parallel start), 'logs', all Docker builds",
        "  \u2022 dev-sanity.sh: loads .env, tests real EI connectivity, 60s timeout",
        "  \u2022 conftest: added ei_client fixture for tests",
        "",
        "Skill Updates:",
        "  \u2022 Phase 4.5 rewritten: real infra mandatory, PRD-agnostic flow testing",
        "  \u2022 Rules C13 (determinism) + C14 (no orphan code) added",
        "  \u2022 Frontend generation list: was 7 files, now 20 files complete",
        "  \u2022 Announce/Summary pattern added to ALL 4 agents",
        "  \u2022 Shared UX spec updated with new pattern definition",
    ]
    add_bullet_slide(slide, bullets, Inches(0.5), Inches(1.6), Inches(12), Inches(5.5),
                     font_size=12)

    # --- SLIDE: What Needs End-to-End Validation ---
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    set_slide_bg(slide, WHITE)
    add_title_bar(slide, "What Needs End-to-End Validation",
                  "Structure exists \u2014 needs a real PRD run through all 4 agents")

    bullets = [
        "Validation Agent (structure complete, not battle-tested):",
        "  \u2022 Test generation from PRD acceptance criteria \u2192 pytest files",
        "  \u2022 Coverage measurement + gap analysis vs PRD",
        "  \u2022 Security test patterns (injection, auth bypass)",
        "  \u2022 Iteration 2 with Docker (integration tests)",
        "",
        "Compliance Agent (structure complete, not battle-tested):",
        "  \u2022 Bandit + Trivy + detect-secrets scan execution",
        "  \u2022 OSPDT PowerPoint generation (python-pptx)",
        "  \u2022 SDLE Mermaid diagrams (threat model, data flow, component arch)",
        "  \u2022 SBOM generation (CycloneDX format)",
        "  \u2022 SLSA checklist + OpenSSF scorecard estimate",
        "  \u2022 Unified DASHBOARD.md generation",
        "",
        "Multi-Developer Test:",
        "  \u2022 Two developers run dev-agent with same PRD",
        "  \u2022 Compare: file structure, UI patterns, API surface, code patterns",
        "  \u2022 Expected: identical (enforced by C13 + templates)",
    ]
    add_bullet_slide(slide, bullets, Inches(0.5), Inches(1.6), Inches(12), Inches(5.5),
                     font_size=12)

    # --- SLIDE: Enterprise Inference Integration ---
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    set_slide_bg(slide, WHITE)
    add_title_bar(slide, "Enterprise Inference Integration",
                  "Two modes, same interface, PRD decides which")

    left_bullets = [
        "Enterprise Inference (EI):",
        "(opea-project/Enterprise-Inference)",
        "",
        "\u2022 WE generate: REST client only",
        "\u2022 EI is REMOTE \u2014 user deploys it",
        "\u2022 OpenAI-compatible /v1/chat/completions",
        "\u2022 Auth: Bearer token or Keycloak",
        "\u2022 Topology: same-cluster or remote",
        "\u2022 Helm: NetworkPolicy egress to EI",
        "\u2022 Mock client for CI tests only",
        "",
        "Generated files:",
        "  ei_client.py (httpx async)",
        "  config.py (InferenceSettings)",
        "  mock_client.py (unit tests)",
    ]
    right_bullets = [
        "Direct vLLM:",
        "(self-contained deployment)",
        "",
        "\u2022 WE OWN full deployment E2E",
        "\u2022 Helm subchart for vLLM",
        "\u2022 Docker container with model",
        "\u2022 HuggingFace token for download",
        "\u2022 HPA for scaling",
        "\u2022 Startup probe waits for model load",
        "",
        "Generated files:",
        "  vllm_client.py (httpx async)",
        "  config.py (same settings interface)",
        "  Helm: vllm/ subchart",
        "  Docker: vLLM container",
        "  Ansible: model deploy playbook",
    ]
    add_bullet_slide(slide, left_bullets, Inches(0.5), Inches(1.6), Inches(6), Inches(5.5),
                     font_size=12)
    add_bullet_slide(slide, right_bullets, Inches(6.8), Inches(1.6), Inches(6), Inches(5.5),
                     font_size=12)

    # =========================================================================
    # PART 4: ARCHITECTURE & TECHNICAL DETAILS
    # =========================================================================
    add_section_divider(prs, "PART 4", "Architecture & Technical Deep-Dive")

    # --- SLIDE: System Architecture ---
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    set_slide_bg(slide, WHITE)
    add_title_bar(slide, "Pipeline Repository Structure", "What developers clone")

    content = (
        "intel-ai-solutions-dev/             \u2190 Pipeline repository\n"
        "\u251c\u2500\u2500 .claude/\n"
        "\u2502   \u251c\u2500\u2500 skills/                    \u2190 4 agent skills (800+ lines each)\n"
        "\u2502   \u2514\u2500\u2500 shared/\n"
        "\u2502       \u251c\u2500\u2500 standards/             \u2190 13 enterprise standards files\n"
        "\u2502       \u251c\u2500\u2500 contracts/             \u2190 Output schemas, iteration state\n"
        "\u2502       \u2514\u2500\u2500 ux/                    \u2190 UX patterns (HiL, announce/summary)\n"
        "\u251c\u2500\u2500 templates/project-scaffold/    \u2190 130+ template files (.tmpl)\n"
        "\u2502   \u251c\u2500\u2500 backend/                   55 files (FastAPI full stack)\n"
        "\u2502   \u251c\u2500\u2500 frontend/                  55 files (React + TypeScript)\n"
        "\u2502   \u251c\u2500\u2500 helm/                      15 files (K8s Helm chart)\n"
        "\u2502   \u251c\u2500\u2500 docker/                    Docker Compose configs\n"
        "\u2502   \u251c\u2500\u2500 ansible/                   Infrastructure playbooks\n"
        "\u2502   \u251c\u2500\u2500 github/                    CI/CD workflows\n"
        "\u2502   \u2514\u2500\u2500 automation/                README, Makefile, dev-sanity\n"
        "\u251c\u2500\u2500 scripts/                       Presentation + utility generators\n"
        "\u2514\u2500\u2500 CLAUDE.md                      Pipeline instructions for Claude\n"
    )
    add_text_box(slide, Inches(0.5), Inches(1.5), Inches(12), Inches(5.5),
                 content, font_size=12, color=INTEL_DARK, font_name="Consolas")

    # --- SLIDE: Generated Project Architecture ---
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    set_slide_bg(slide, WHITE)
    add_title_bar(slide, "Generated Project Architecture",
                  "What the developer gets after /dev-agent completes")

    content = (
        "\u250c\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2510    \u250c\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2510    \u250c\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2510\n"
        "\u2502  Frontend  \u2502\u2500\u2500\u2500\u25b6\u2502  FastAPI API      \u2502\u2500\u2500\u2500\u25b6\u2502  Workers (Celery / inline)        \u2502\n"
        "\u2502  React+Vite\u2502    \u2502  Port {port}       \u2502    \u2502                                   \u2502\n"
        "\u2502  Port 3000 \u2502    \u2502                    \u2502    \u2502  Pipeline Stages:                 \u2502\n"
        "\u2514\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2518    \u2502  Endpoints:        \u2502    \u2502  \u250c\u2500\u2500\u2500\u2500\u2500\u2510\u2500\u250c\u2500\u2500\u2500\u2500\u2500\u2510\u2500\u250c\u2500\u2500\u2500\u2500\u2510\u2500\u250c\u2500\u2500\u2500\u2500\u2500\u2510 \u2502\n"
        "              \u2502  \u2022 /healthz        \u2502    \u2502  \u2502Parse\u2502\u2192\u2502Chunk\u2502\u2192\u2502PII \u2502\u2192\u2502 Gen \u2502 \u2502\n"
        "              \u2502  \u2022 /api/v1/...     \u2502    \u2502  \u2514\u2500\u2500\u2500\u2500\u2500\u2518 \u2514\u2500\u2500\u2500\u2500\u2500\u2518 \u2514\u2500\u2500\u2500\u2500\u2518 \u2514\u2500\u2500\u252c\u2500\u2500\u2518 \u2502\n"
        "              \u2502  \u2022 /api/docs       \u2502    \u2502                             \u2193     \u2502\n"
        "              \u2514\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u252c\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2518    \u2502  \u250c\u2500\u2500\u2500\u2500\u2500\u2500\u2510 \u250c\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2510  \u2502\n"
        "                       \u2502                \u2502  \u2502Format\u2502\u2190\u2502Verify (via EI)    \u2502  \u2502\n"
        "                  \u250c\u2500\u2500\u2500\u2500\u2534\u2500\u2500\u2500\u2500\u2510           \u2502  \u2514\u2500\u2500\u252c\u2500\u2500\u2500\u2518 \u2514\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2518  \u2502\n"
        "                  \u2502Database \u2502           \u2514\u2500\u2500\u2500\u2500\u2500\u252c\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2518\n"
        "                  \u2502(PG/SQLite)\u2502               \u2193\n"
        "                  \u2502+ Redis   \u2502         \u250c\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2510\n"
        "                  \u2502+ Storage \u2502         \u2502 Output    \u2502\n"
        "                  \u2514\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2518         \u2502 (JSONL +  \u2502\n"
        "                                        \u2502  Report)  \u2502\n"
        "                                        \u2514\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2518\n"
        "                                              \u2191 LLM calls\n"
        "                                  \u250c\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2510\n"
        "                                  \u2502 Enterprise Inference   \u2502\n"
        "                                  \u2502 (Remote \u2014 you deploy)  \u2502\n"
        "                                  \u2514\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2518\n"
    )
    add_text_box(slide, Inches(0.3), Inches(1.4), Inches(12.5), Inches(6),
                 content, font_size=9, color=INTEL_DARK, font_name="Consolas")

    # --- SLIDE: Standards Matrix ---
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    set_slide_bg(slide, WHITE)
    add_title_bar(slide, "13 Enterprise Standards Enforced", "All checked before code generation")

    standards = [
        ("Coding", "Python 3.11+, async, mypy --strict, ruff, Pydantic v2"),
        ("Security", "JWT/JWKS, RBAC, parameterized queries, TLS, CORS"),
        ("Testing", "85%+ coverage, pytest+tox, parametrize, security tests"),
        ("Containers", "Multi-stage, slim, uid=1000, HEALTHCHECK, read-only fs"),
        ("Helm", "200+ params, 3 probes, zero-trust NetworkPolicy, HPA+PDB"),
        ("Observability", "structlog + Prometheus + OpenTelemetry + health probes"),
        ("CI/CD", "Super-Linter, Bandit, Trivy, CodeQL, signed releases"),
        ("Open Source", "Apache-2.0 headers, CNCF files, OSPDT, SBOM"),
        ("Structure", "Microservice layout, feature-based frontend"),
        ("Tech Stack", "Approved/prohibited libraries list"),
        ("Performance", "OpenVINO, IPEX, vLLM, async I/O, connection pooling"),
        ("UX Design", "Intel design system, Tailwind, strict TypeScript"),
        ("Validation", "Pre-merge gates: code + tests + security + containers"),
    ]
    y = Inches(1.5)
    for name, desc in standards:
        add_text_box(slide, Inches(0.5), y, Inches(2.8), Inches(0.35),
                     f"\u2022 {name}", font_size=10, bold=True, color=INTEL_BLUE)
        add_text_box(slide, Inches(3.4), y, Inches(9.5), Inches(0.35),
                     desc, font_size=10, color=INTEL_GRAY)
        y += Inches(0.42)

    # --- SLIDE: Session Continuity ---
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    set_slide_bg(slide, WHITE)
    add_title_bar(slide, "Session Continuity", "Leave Friday, resume Monday \u2014 no context loss")

    bullets = [
        "Three persistence mechanisms work together:",
        "",
        "1. .iteration-state.json \u2014 tracks phase status, decisions, skipped items",
        "2. Claude Memory \u2014 saves project state, blockers, next steps across sessions",
        "3. Git commits \u2014 enforced at every phase boundary (non-negotiable)",
        "",
        "Developer returns \u2192 Agent detects prior session \u2192 Presents:",
        "  \u2022 Continue \u2014 pick up at next incomplete phase",
        "  \u2022 Retry skipped \u2014 install missing tools, re-run",
        "  \u2022 Review \u2014 see current state and reports",
        "  \u2022 Start fresh \u2014 begin new without destroying prior work",
        "",
        "Program Checkpoints (after every phase):",
        "  1. Wiki \u2014 publish to Confluence",
        "  2. Jira \u2014 update EPICs/Stories",
        "  3. Git \u2014 commit + push (cannot be skipped without reason)",
    ]
    add_bullet_slide(slide, bullets, Inches(0.5), Inches(1.6), Inches(12), Inches(5.5),
                     font_size=13)

    # =========================================================================
    # PART 5: ROADMAP & NEXT STEPS
    # =========================================================================
    add_section_divider(prs, "PART 5", "Roadmap & Next Steps")

    # --- SLIDE: Roadmap ---
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    set_slide_bg(slide, WHITE)
    add_title_bar(slide, "Pipeline Roadmap", "From current state to full platform")

    roadmap = [
        ("DONE", "4 agents: PRD \u2192 Dev \u2192 Validation \u2192 Compliance", GREEN),
        ("DONE", "Enterprise Inference integration (EI + Direct vLLM)", GREEN),
        ("DONE", "130+ templates, 14 contract rules, 13 standards", GREEN),
        ("DONE", "Session continuity + iteration tracking", GREEN),
        ("DONE", "Dev Sanity: real-infra E2E testing + code audit + README verify", GREEN),
        ("DONE", "Phase announce/summary pattern across all agents", GREEN),
        ("VALIDATE", "End-to-end run: fresh PRD through all 4 agents", ORANGE),
        ("VALIDATE", "Multi-developer determinism test", ORANGE),
        ("VALIDATE", "Compliance agent full execution (Trivy, OSPDT deck, SBOM)", ORANGE),
        ("PLANNED", "Agentic Stack client templates (Q2 2026)", INTEL_BLUE),
        ("PLANNED", "Auto-deploy to K8s (Helm + ArgoCD integration)", INTEL_BLUE),
        ("PLANNED", "LLM eval pipeline (quality gates before release)", INTEL_BLUE),
    ]
    y = Inches(1.5)
    for status, desc, color in roadmap:
        add_status_badge(slide, Inches(0.3), y, status, color)
        add_text_box(slide, Inches(2.3), y, Inches(10.7), Inches(0.35),
                     desc, font_size=11, color=INTEL_DARK)
        y += Inches(0.47)

    # --- SLIDE: Getting Started ---
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    set_slide_bg(slide, WHITE)
    add_title_bar(slide, "Getting Started", "5 commands \u2192 production-ready AI product")

    content = (
        "# 1. Clone the pipeline\n"
        "git clone <pipeline-repo-url> && cd intel-ai-solutions-dev\n"
        "\n"
        "# 2. Create PRD (25-35 min interactive Q&A)\n"
        "/prd-agent\n"
        "\n"
        "# 3. Generate complete product (tests with REAL infra)\n"
        "/dev-agent\n"
        "\n"
        "# 4. Generate tests + validate coverage\n"
        "/validation-agent\n"
        "\n"
        "# 5. Security scans + compliance artifacts\n"
        "/compliance-agent\n"
        "\n"
        "# DEPLOY:\n"
        "helm install my-app ./helm/my-app/ -f values-production.yaml\n"
    )
    add_text_box(slide, Inches(1), Inches(1.5), Inches(11), Inches(5.5),
                 content, font_size=13, color=INTEL_DARK, font_name="Consolas")

    # --- SLIDE: The 30-Second Pitch ---
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    set_slide_bg(slide, WHITE)
    add_title_bar(slide, "The 30-Second Pitch")

    add_text_box(slide, Inches(1), Inches(2.0), Inches(11), Inches(4.5),
                 "Claude can write any code you ask for.\n\n"
                 "But it can't ensure that code integrates,\n"
                 "that it works end-to-end with real infrastructure,\n"
                 "that it's consistent across your team,\n"
                 "that it meets Intel security standards,\n"
                 "or that it's production-deployable.\n\n"
                 "This pipeline gives Claude STRUCTURE.\n"
                 "Same input \u2192 same output. Every time.\n"
                 "From idea to production in hours, not weeks.\n"
                 "With compliance built in, not bolted on.",
                 font_size=18, color=INTEL_DARK, align=PP_ALIGN.CENTER)

    # =========================================================================
    # CLOSING SLIDE
    # =========================================================================
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    set_slide_bg(slide, INTEL_BLUE)

    add_text_box(slide, Inches(1), Inches(2.0), Inches(11), Inches(1),
                 "One Developer. One Pipeline. Production-Ready AI.",
                 font_size=30, bold=True, color=WHITE, align=PP_ALIGN.CENTER)

    add_text_box(slide, Inches(1), Inches(3.2), Inches(11), Inches(1.8),
                 "Deterministic \u2022 Real-Infrastructure Tested \u2022 Contract-Enforced\n"
                 "Standards-Compliant \u2022 Session-Resumable \u2022 Developer-Controlled\n"
                 "Production-Ready from Day 1",
                 font_size=16, color=INTEL_LIGHT_BLUE, align=PP_ALIGN.CENTER)

    add_text_box(slide, Inches(1), Inches(5.5), Inches(11), Inches(1),
                 "Questions & Live Demo",
                 font_size=22, bold=True, color=WHITE, align=PP_ALIGN.CENTER)

    add_text_box(slide, Inches(1), Inches(6.5), Inches(11), Inches(0.5),
                 "Intel Corporation  |  AI Software Engineering  |  2026",
                 font_size=11, color=INTEL_LIGHT_BLUE, align=PP_ALIGN.CENTER)

    # Save
    output_dir = os.path.join(
        os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
        "docs", "presentations",
    )
    os.makedirs(output_dir, exist_ok=True)
    output_path = os.path.join(
        output_dir,
        "Intel_AI_Solutions_Dev_Pipeline_Developer_Presentation.pptx"
    )
    try:
        prs.save(output_path)
    except PermissionError:
        output_path = os.path.join(
            output_dir,
            "Intel_AI_Solutions_Dev_Pipeline_Developer_Presentation_v2.pptx"
        )
        prs.save(output_path)
    print(f"Presentation saved to: {output_path}")
    print(f"Total slides: {len(prs.slides)}")


if __name__ == "__main__":
    create_presentation()
