#!/usr/bin/env python3
# Copyright (C) 2024 Intel Corporation
# SPDX-License-Identifier: Apache-2.0
"""Generate executive pitch deck for Intel AI Solutions Development.

24-slide investor-style presentation for Head of Organization.
16:9 widescreen, Intel branding, Intel logo on every slide.
"""

from pathlib import Path

from pptx import Presentation
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE
from pptx.enum.text import MSO_ANCHOR, PP_ALIGN
from pptx.util import Emu, Inches, Pt

# ── Paths ────────────────────────────────────────────────────────────────────
SCRIPT_DIR = Path(__file__).resolve().parent
REPO_ROOT = SCRIPT_DIR.parent
LOGO_PATH = REPO_ROOT / "templates" / "intellogo.png"

# ── Slide Dimensions (16:9) ─────────────────────────────────────────────────
SLIDE_W = Emu(12192000)
SLIDE_H = Emu(6858000)

# ── Intel Brand ──────────────────────────────────────────────────────────────
INTEL_BLUE = RGBColor(0, 104, 181)
INTEL_DARK = RGBColor(0, 53, 128)
INTEL_CYAN = RGBColor(0, 199, 253)
WHITE = RGBColor(255, 255, 255)
BODY = RGBColor(51, 51, 51)
CAPTION = RGBColor(102, 102, 102)
LIGHT_TEXT = RGBColor(180, 210, 255)
FAINT_TEXT = RGBColor(150, 190, 240)
TABLE_ALT = RGBColor(237, 243, 250)
RULE_COLOR = RGBColor(200, 215, 235)
GREEN = RGBColor(0, 150, 64)
AMBER = RGBColor(210, 140, 0)
RED = RGBColor(200, 30, 30)
MUTED_RED = RGBColor(160, 45, 45)

M_LEFT = Inches(0.75)
CONTENT_W = Inches(11.833)
FONT = "Calibri"
FOOTER_TEXT = "Intel AI Solutions Development \u2014 Executive Briefing"

_sn = 0


# ═════════════════════════════════════════════════════════════════════════════
#  PRIMITIVES
# ═════════════════════════════════════════════════════════════════════════════

def _prs():
    p = Presentation()
    p.slide_width = SLIDE_W
    p.slide_height = SLIDE_H
    return p

def _sl(prs, reset=False):
    global _sn
    if reset: _sn = 0
    _sn += 1
    return prs.slides.add_slide(prs.slide_layouts[6])

def _bg(s, c):
    f = s.background.fill; f.solid(); f.fore_color.rgb = c

def _r(s, l, t, w, h, c):
    sh = s.shapes.add_shape(MSO_SHAPE.RECTANGLE, l, t, w, h)
    sh.fill.solid(); sh.fill.fore_color.rgb = c; sh.line.fill.background()
    return sh

def _t(s, l, t, w, h, txt="", sz=14, b=False, c=BODY, a=PP_ALIGN.LEFT, f=FONT):
    bx = s.shapes.add_textbox(l, t, w, h)
    tf = bx.text_frame; tf.word_wrap = True
    if txt:
        p = tf.paragraphs[0]; p.text = txt; p.font.size = Pt(sz)
        p.font.bold = b; p.font.color.rgb = c; p.font.name = f; p.alignment = a
    return tf

def _bl(tf, items, sz=12, c=BODY, bp=False):
    for item in items:
        p = tf.add_paragraph(); p.space_before = Pt(3); p.space_after = Pt(1)
        if bp and ": " in item:
            pre, rest = item.split(": ", 1)
            r1 = p.add_run(); r1.text = pre + ": "; r1.font.bold = True
            r1.font.size = Pt(sz); r1.font.color.rgb = c; r1.font.name = FONT
            r2 = p.add_run(); r2.text = rest
            r2.font.size = Pt(sz); r2.font.color.rgb = c; r2.font.name = FONT
        else:
            p.text = item; p.font.size = Pt(sz); p.font.color.rgb = c; p.font.name = FONT

def _logo(s, x=None, y=None, w=None):
    if not LOGO_PATH.exists(): return
    s.shapes.add_picture(str(LOGO_PATH),
        x or Inches(12.1), y or Inches(7.0), width=w or Inches(0.85))

def _hdr(s, title):
    _r(s, Inches(0), Inches(0), SLIDE_W, Inches(0.6), INTEL_DARK)
    _r(s, Inches(0), Inches(0.6), SLIDE_W, Inches(0.04), INTEL_CYAN)
    _t(s, M_LEFT, Inches(0.1), CONTENT_W, Inches(0.45), title, sz=24, b=True, c=WHITE)

def _ftr(s):
    _r(s, Inches(0.5), Inches(6.83), Inches(12.333), Inches(0.008), RULE_COLOR)
    _t(s, M_LEFT, Inches(6.88), Inches(5), Inches(0.3), FOOTER_TEXT, sz=8, c=CAPTION)
    _t(s, Inches(8.5), Inches(6.88), Inches(2.5), Inches(0.3),
       "Intel Confidential", sz=8, c=CAPTION, a=PP_ALIGN.CENTER)
    _t(s, Inches(11.5), Inches(6.88), Inches(0.8), Inches(0.3),
       str(_sn), sz=8, c=CAPTION, a=PP_ALIGN.RIGHT)
    _logo(s)

def _cs(prs, title):
    s = _sl(prs); _hdr(s, title); _ftr(s); return s

def _tc(s, lt, li, rt, ri, y=None):
    y = y or Inches(0.9)
    cw = Inches(5.55); g = Inches(0.7); rx = M_LEFT + cw + g
    _r(s, M_LEFT, y, cw, Inches(0.4), INTEL_BLUE)
    _t(s, M_LEFT+Inches(0.12), y+Inches(0.03), cw, Inches(0.35), lt, sz=13, b=True, c=WHITE)
    tf = _t(s, M_LEFT+Inches(0.12), y+Inches(0.5), Inches(5.3), Inches(5.2), "", sz=12)
    _bl(tf, li, sz=12, bp=True)
    _r(s, rx, y, cw, Inches(0.4), INTEL_BLUE)
    _t(s, rx+Inches(0.12), y+Inches(0.03), cw, Inches(0.35), rt, sz=13, b=True, c=WHITE)
    tf2 = _t(s, rx+Inches(0.12), y+Inches(0.5), Inches(5.3), Inches(5.2), "", sz=12)
    _bl(tf2, ri, sz=12, bp=True)

def _tbl(s, rows, y=None, cw=None, fs=10):
    y = y or Inches(1.1)
    nr = len(rows); nc = len(rows[0])
    tw = sum(cw) if cw else CONTENT_W
    ts = s.shapes.add_table(nr, nc, M_LEFT, y, tw, Inches(0.36)*nr)
    tbl = ts.table
    if cw:
        for j, w in enumerate(cw): tbl.columns[j].width = w
    for i, rd in enumerate(rows):
        for j, val in enumerate(rd):
            cell = tbl.cell(i, j); cell.vertical_anchor = MSO_ANCHOR.MIDDLE
            cell.margin_left = Inches(0.08); cell.margin_right = Inches(0.08)
            cell.margin_top = Inches(0.04); cell.margin_bottom = Inches(0.04)
            if isinstance(val, tuple): txt, tc = val
            else: txt, tc = val, None
            cell.text = txt
            for p in cell.text_frame.paragraphs:
                p.font.size = Pt(fs); p.font.name = FONT
                p.space_before = Pt(0); p.space_after = Pt(0)
                if i == 0: p.font.bold = True; p.font.color.rgb = WHITE
                elif tc: p.font.color.rgb = tc; p.font.bold = True
                else: p.font.color.rgb = BODY
                if j == 0 and i > 0 and not tc: p.font.bold = True
            if i == 0: cell.fill.solid(); cell.fill.fore_color.rgb = INTEL_DARK
            elif i % 2 == 0: cell.fill.solid(); cell.fill.fore_color.rgb = TABLE_ALT
    return ts

def _title_sl(s, title, sub="", tag="", author=""):
    _bg(s, INTEL_DARK)
    _r(s, Inches(0), Inches(0), SLIDE_W, Inches(0.06), INTEL_CYAN)
    _logo(s, x=Inches(5.55), y=Inches(1.0), w=Inches(2.2))
    _t(s, Inches(1.5), Inches(2.4), Inches(10.333), Inches(1.2),
       title, sz=36, b=True, c=WHITE, a=PP_ALIGN.CENTER)
    if sub:
        _t(s, Inches(1.5), Inches(3.6), Inches(10.333), Inches(0.8),
           sub, sz=20, c=LIGHT_TEXT, a=PP_ALIGN.CENTER)
    _r(s, Inches(4.5), Inches(4.65), Inches(4.333), Inches(0.04), INTEL_CYAN)
    if tag:
        _t(s, Inches(1.5), Inches(4.95), Inches(10.333), Inches(0.6),
           tag, sz=15, c=FAINT_TEXT, a=PP_ALIGN.CENTER)
    if author:
        _t(s, Inches(1.5), Inches(5.75), Inches(10.333), Inches(0.5),
           author, sz=13, c=RGBColor(140, 175, 220), a=PP_ALIGN.CENTER)
    _r(s, Inches(0), Inches(7.3), SLIDE_W, Inches(0.2), INTEL_BLUE)

def _section_sl(s, num, title, sub=""):
    _bg(s, INTEL_DARK)
    _r(s, Inches(0), Inches(0), SLIDE_W, Inches(0.06), INTEL_CYAN)
    if num:
        _t(s, Inches(1.5), Inches(2.0), Inches(10.333), Inches(1.2),
           f"{num:02d}", sz=60, b=True, c=INTEL_CYAN, a=PP_ALIGN.CENTER)
    _t(s, Inches(1.5), Inches(3.2), Inches(10.333), Inches(1),
       title, sz=32, b=True, c=WHITE, a=PP_ALIGN.CENTER)
    if sub:
        _t(s, Inches(1.5), Inches(4.3), Inches(10.333), Inches(0.6),
           sub, sz=16, c=LIGHT_TEXT, a=PP_ALIGN.CENTER)
    _r(s, Inches(5), Inches(5.2), Inches(3.333), Inches(0.04), INTEL_CYAN)
    _logo(s, x=Inches(5.8), y=Inches(5.7), w=Inches(1.7))
    _r(s, Inches(0), Inches(7.3), SLIDE_W, Inches(0.2), INTEL_BLUE)

def _closing_sl(s, title, sub="", tag=""):
    _bg(s, INTEL_DARK)
    _r(s, Inches(0), Inches(0), SLIDE_W, Inches(0.06), INTEL_CYAN)
    _logo(s, x=Inches(5.55), y=Inches(1.8), w=Inches(2.2))
    _t(s, Inches(1.5), Inches(3.2), Inches(10.333), Inches(1),
       title, sz=40, b=True, c=WHITE, a=PP_ALIGN.CENTER)
    if sub:
        _t(s, Inches(1.5), Inches(4.3), Inches(10.333), Inches(0.7),
           sub, sz=20, c=LIGHT_TEXT, a=PP_ALIGN.CENTER)
    _r(s, Inches(4.5), Inches(5.2), Inches(4.333), Inches(0.04), INTEL_CYAN)
    if tag:
        _t(s, Inches(1.5), Inches(5.5), Inches(10.333), Inches(0.6),
           tag, sz=15, c=FAINT_TEXT, a=PP_ALIGN.CENTER)
    _r(s, Inches(0), Inches(7.3), SLIDE_W, Inches(0.2), INTEL_BLUE)


# ═════════════════════════════════════════════════════════════════════════════
#  SLIDE BUILDERS
# ═════════════════════════════════════════════════════════════════════════════

def generate_executive_pitch(output_path: str):
    prs = _prs()

    # ═══ SLIDE 1: Title ═══
    s = _sl(prs, reset=True)
    _title_sl(s,
        "Intel AI Solutions Development",
        "Agentic AI-Powered SDLC Pipeline",
        "Every Developer, 10x Output, Production-Grade from Day One",
        "Vivek RS  |  DCAI Software Engineering  |  2025")

    # ═══ SLIDE 2: Section — The Problem ═══
    s = _sl(prs)
    _section_sl(s, 1, "The Problem",
        "What happens when developers use AI without structure?")

    # ═══ SLIDE 3: Unstructured AI — The Current Reality ═══
    s = _cs(prs, "Unstructured AI \u2014 The Current Reality")
    _tc(s,
        "What Developers Do Today", [
            "Each developer scaffolds projects from scratch (2-3 days)",
            "Everyone picks different libraries, patterns, quality levels",
            "Dockerfiles vary widely \u2014 many run as root, no health checks",
            "Helm charts are basic or missing \u2014 no NetworkPolicy",
            "Security scans happen at the end, if at all",
            "OSPDT compliance takes days of manual work",
            "No connection between PRD \u2192 Code \u2192 Tests \u2192 Compliance",
        ],
        "The Chaos This Creates", [
            "Every project looks different \u2014 no reviewable standard",
            "Code reviews catch infrastructure issues, not business logic",
            "Secrets leak into commits (no pre-execution scanning)",
            "License headers forgotten \u2014 blocks open source release",
            "Jira updates are manual afterthoughts",
            "Wiki docs are stale or nonexistent",
            "Compliance is a 2-week bottleneck before every release",
        ])

    # Chaos boxes at bottom
    chaos = [
        ("Flask", AMBER, 0.8, 5.9), ("requests", RED, 2.3, 6.05),
        ("root Docker", RED, 3.9, 5.85), ("no tests", AMBER, 5.6, 6.1),
        ("Django", AMBER, 7.0, 5.9), ("manual OSPDT", RED, 8.5, 6.0),
        ("no SBOM", RED, 10.2, 5.95), ("curl|bash", AMBER, 11.5, 6.08),
    ]
    for label, color, x, y in chaos:
        _r(s, Inches(x), Inches(y), Inches(1.15), Inches(0.38), color)
        _t(s, Inches(x+0.05), Inches(y+0.05), Inches(1.05), Inches(0.3),
           label, sz=8, b=True, c=WHITE, a=PP_ALIGN.CENTER)

    # ═══ SLIDE 4: Cost of Doing Nothing ═══
    s = _cs(prs, "The Cost of Doing Nothing")

    metrics = [
        ("2\u20133\nDAYS", "To scaffold\none project", RED),
        ("2\nWEEKS", "OSPDT compliance\nper release", RED),
        ("60%", "Developer time on\nboilerplate, not logic", AMBER),
        ("0%", "Projects on a\nstandardized stack", RED),
    ]
    for i, (num, label, color) in enumerate(metrics):
        x = Inches(0.75 + i * 3.0)
        _r(s, x, Inches(1.1), Inches(2.7), Inches(3.2), color)
        _t(s, x, Inches(1.4), Inches(2.7), Inches(1.5),
           num, sz=44, b=True, c=WHITE, a=PP_ALIGN.CENTER)
        _t(s, x, Inches(3.0), Inches(2.7), Inches(1.0),
           label, sz=13, c=WHITE, a=PP_ALIGN.CENTER)

    _t(s, M_LEFT, Inches(4.7), CONTENT_W, Inches(0.8),
       "Every project that ships without this pipeline carries hidden costs: "
       "rework, security debt, compliance delays, inconsistent quality.",
       sz=14, b=True, c=INTEL_BLUE)
    _t(s, M_LEFT, Inches(5.4), CONTENT_W, Inches(0.6),
       "These costs multiply with every new project and every new developer.",
       sz=13, c=BODY)

    # ═══ SLIDE 5: Section — The Solution ═══
    s = _sl(prs)
    _section_sl(s, 2, "The Solution",
        "Structured AI that multiplies every developer")

    # ═══ SLIDE 6: The Vision ═══
    s = _sl(prs)
    _bg(s, INTEL_DARK)
    _r(s, Inches(0), Inches(0), SLIDE_W, Inches(0.06), INTEL_CYAN)
    _t(s, Inches(1.5), Inches(0.8), Inches(10.333), Inches(0.8),
       "Every Developer, 10x Output", sz=34, b=True, c=WHITE, a=PP_ALIGN.CENTER)
    _t(s, Inches(1.5), Inches(1.6), Inches(10.333), Inches(0.6),
       "Production-Grade from Day One", sz=22, c=INTEL_CYAN, a=PP_ALIGN.CENTER)
    _r(s, Inches(4), Inches(2.4), Inches(5.333), Inches(0.04), INTEL_CYAN)
    _t(s, Inches(1.5), Inches(2.7), Inches(10.333), Inches(0.8),
       "CNCF-compliant  \u2502  OpenSSF 8+  \u2502  SLSA Level 2+  \u2502  12-Factor  \u2502  OSPDT-ready",
       sz=14, c=FAINT_TEXT, a=PP_ALIGN.CENTER)

    # Pipeline row
    stages = ["/prd-agent", "/dev-agent", "/validation-agent", "/compliance-agent"]
    labels = ["Define", "Build", "Validate", "Comply"]
    for i, (cmd, lbl) in enumerate(zip(stages, labels)):
        x = Inches(0.9 + i * 3.1)
        _r(s, x, Inches(3.8), Inches(2.7), Inches(0.9), INTEL_BLUE)
        _t(s, x, Inches(3.85), Inches(2.7), Inches(0.45),
           cmd, sz=14, b=True, c=WHITE, a=PP_ALIGN.CENTER)
        _t(s, x, Inches(4.25), Inches(2.7), Inches(0.35),
           lbl, sz=12, c=LIGHT_TEXT, a=PP_ALIGN.CENTER)
        if i < 3:
            _t(s, Inches(3.7 + i * 3.1), Inches(4.0), Inches(0.3), Inches(0.4),
               "\u25b6", sz=18, b=True, c=INTEL_CYAN, a=PP_ALIGN.CENTER)

    _t(s, Inches(1.5), Inches(5.2), Inches(10.333), Inches(1),
       "4 AI skills  \u2502  13 standards  \u2502  75 templates  \u2502  4 auto-enforcement hooks\n"
       "Every project starts production-ready. Every developer ships faster.",
       sz=14, c=RGBColor(200, 220, 250), a=PP_ALIGN.CENTER)
    _logo(s, x=Inches(5.8), y=Inches(6.5), w=Inches(1.7))
    _r(s, Inches(0), Inches(7.3), SLIDE_W, Inches(0.2), INTEL_BLUE)

    # ═══ SLIDE 7: How It Works — 4-Stage Pipeline ═══
    s = _cs(prs, "How It Works \u2014 The 4-Stage Pipeline")

    cards = [
        ("1. Define", "/prd-agent",
         "Interactive Q&A (25 min)\nor meeting transcript\n\n"
         "Outputs:\n\u2022 PRD + Feature Breakdown\n\u2022 Technical PRD\n\n"
         "Integrations:\n\u2192 Wiki publish\n\u2192 Jira EPICs/Stories"),
        ("2. Build", "/dev-agent",
         "Reads Technical PRD\nGenerates complete project\n\n"
         "Outputs:\n\u2022 80+ production files\n\u2022 FastAPI + React + Helm\n\u2022 CI/CD + Docker + Ansible\n\n"
         "Integrations:\n\u2192 GitHub push\n\u2192 Jira update"),
        ("3. Validate", "/validation-agent",
         "Maps PRD acceptance\ncriteria to test cases\n\n"
         "Outputs:\n\u2022 Unit + integration tests\n\u2022 Security test stubs\n\u2022 85%+ coverage\n\n"
         "Integrations:\n\u2192 Wiki report\n\u2192 Jira update"),
        ("4. Comply", "/compliance-agent",
         "Security scans +\ncompliance artifacts\n\n"
         "Outputs:\n\u2022 OSPDT PowerPoint\n\u2022 SDLE diagrams + SBOM\n\u2022 OpenSSF scorecard\n\n"
         "Integrations:\n\u2192 Wiki publish\n\u2192 OSPDT submission"),
    ]
    for i, (hdr, sub, body) in enumerate(cards):
        x = Inches(0.55 + i * 3.0)
        _r(s, x, Inches(0.95), Inches(2.7), Inches(0.7), INTEL_BLUE)
        _t(s, x+Inches(0.1), Inches(0.97), Inches(2.5), Inches(0.35),
           hdr, sz=13, b=True, c=WHITE)
        _t(s, x+Inches(0.1), Inches(1.3), Inches(2.5), Inches(0.3),
           sub, sz=10, c=LIGHT_TEXT)
        _r(s, x, Inches(1.7), Inches(2.7), Inches(4.8), TABLE_ALT)
        _t(s, x+Inches(0.12), Inches(1.8), Inches(2.46), Inches(4.6),
           body, sz=10, c=BODY)
        if i < 3:
            _t(s, Inches(3.3 + i * 3.0), Inches(1.15), Inches(0.2), Inches(0.35),
               "\u25b6", sz=14, b=True, c=INTEL_CYAN, a=PP_ALIGN.CENTER)

    # ═══ SLIDE 8: Section — Human + AI ═══
    s = _sl(prs)
    _section_sl(s, 3, "Human + AI",
        "AI generates. Humans govern. Every step has a checkpoint.")

    # ═══ SLIDE 9: 8 Human Checkpoints ═══
    s = _cs(prs, "8 Human Checkpoints Across the Pipeline")
    _t(s, M_LEFT, Inches(0.85), CONTENT_W, Inches(0.4),
       "AI never acts without human approval. Every critical decision requires explicit confirmation.",
       sz=14, b=True, c=INTEL_BLUE)

    checks = [
        ("\u2713 PRD Review & Approval",
         "PM reviews generated PRD before any code is written"),
        ("\u2713 Generation Plan Confirmation",
         "Developer sees numbered file list, confirms before creation"),
        ("\u2713 Code Review of AI Output",
         "Standard PR review \u2014 AI generates, humans approve merge"),
        ("\u2713 Test Results Analysis",
         "Developer reviews coverage gaps, decides what to add"),
        ("\u2713 Security Scan Triage",
         "Engineer triages findings: accept / fix / waive with justification"),
        ("\u2713 OSPDT Deck Review",
         "Compliance lead reviews deck before OSPDT submission"),
        ("\u2713 Deployment Approval Gates",
         "CI/CD gates: staging needs lead approval, prod needs 2 reviewers"),
        ("\u2713 Standards Feedback Loop",
         "Human expertise improves standards for all future projects"),
    ]
    for i, (label, desc) in enumerate(checks):
        col = 0 if i < 4 else 1
        row = i % 4
        x = M_LEFT + col * Inches(6.1)
        y = Inches(1.5) + row * Inches(1.3)
        _r(s, x, y, Inches(0.3), Inches(0.3), GREEN)
        _t(s, x + Inches(0.02), y + Inches(0.02), Inches(0.26), Inches(0.26),
           "\u2713", sz=14, b=True, c=WHITE, a=PP_ALIGN.CENTER)
        _t(s, x + Inches(0.4), y + Inches(0.0), Inches(5.3), Inches(0.35),
           label.replace("\u2713 ", ""), sz=14, b=True, c=BODY)
        _t(s, x + Inches(0.4), y + Inches(0.38), Inches(5.3), Inches(0.7),
           desc, sz=11, c=CAPTION)

    # ═══ SLIDE 10: The Multiplier Effect ═══
    s = _cs(prs, "The Multiplier Effect \u2014 Human + AI")
    _tc(s,
        "What AI Does Best", [
            "Scaffolds 80+ files in minutes (no typos, no forgotten configs)",
            "Applies 13 standards consistently across every project",
            "Runs 6 security scanners and consolidates findings",
            "Generates OSPDT deck, SDLE diagrams, SBOM automatically",
            "Never forgets a license header or pre-commit hook",
            "Translates PRD acceptance criteria into test cases",
            "Updates Jira and Wiki without context-switching",
        ],
        "What Humans Do Best", [
            "Define the product vision and business requirements",
            "Make architectural tradeoffs (cost vs. performance vs. time)",
            "Write business logic that requires domain expertise",
            "Review AI output for correctness and edge cases",
            "Triage security findings with organizational context",
            "Improve standards based on real-world experience",
            "Make deployment decisions (when, where, rollback plan)",
        ])
    _t(s, M_LEFT, Inches(5.8), CONTENT_W, Inches(0.6),
       "Result: Developers spend 90% of time on business logic, not boilerplate. "
       "AI handles the undifferentiated heavy lifting.",
       sz=14, b=True, c=INTEL_BLUE)

    # ═══ SLIDE 11: Section — Impact ═══
    s = _sl(prs)
    _section_sl(s, 4, "Impact",
        "Measured productivity across the software development lifecycle")

    # ═══ SLIDE 12: Productivity Table ═══
    s = _cs(prs, "Developer Productivity \u2014 Before vs After")
    _tbl(s, [
        ("Activity", "Without Pipeline", "With Pipeline", "Improvement"),
        ("Project Scaffolding", "2-3 days", "15 minutes", ("100x faster", GREEN)),
        ("OSPDT Compliance", "2 weeks", "30 minutes", ("40x faster", GREEN)),
        ("Test Coverage (0 \u2192 85%)", "1-2 weeks", "1 hour", ("80x faster", GREEN)),
        ("Time to First PR", "2 weeks", "2 days", ("5x faster", GREEN)),
        ("Stack Standardization", "0% consistent", "100% consistent", ("Complete", GREEN)),
        ("Security Scanning", "End of project", "Every commit", ("Shift-left", GREEN)),
        ("Jira + Wiki Updates", "Manual / forgotten", "Automatic", ("Always current", GREEN)),
    ], y=Inches(0.95), cw=[Inches(2.8), Inches(2.5), Inches(2.5), Inches(4.033)], fs=11)

    _t(s, M_LEFT, Inches(4.3), CONTENT_W, Inches(0.5),
       "Each developer saves ~44 days/year on non-differentiated work \u2014 "
       "redirected to business logic, AI/ML, and user experience.",
       sz=14, b=True, c=INTEL_BLUE)

    # ═══ SLIDE 13: What Changes for Each Developer ═══
    s = _cs(prs, "What Changes for Each Developer")
    _t(s, M_LEFT, Inches(0.85), CONTENT_W, Inches(0.4),
       "From weeks of setup to writing business logic on day two.",
       sz=14, b=True, c=INTEL_BLUE)

    timeline = [
        ("Day 1", "PRD in 30 Minutes",
         "/prd-agent creates PRD, Feature Breakdown,\n"
         "Technical PRD. Auto-publishes to Wiki,\n"
         "creates Jira EPICs and Stories.", INTEL_BLUE),
        ("Day 2", "Code in 15 Minutes",
         "/dev-agent scaffolds the entire project:\n"
         "FastAPI, React, Helm, CI/CD, Docker,\n"
         "Ansible. You start business logic TODAY.", INTEL_BLUE),
        ("Week 1", "Tests Built-In",
         "/validation-agent generates 85%+ test\n"
         "coverage from PRD acceptance criteria.\n"
         "Tests exist BEFORE your first PR.", GREEN),
        ("Before Release", "Compliance in 30 Min",
         "/compliance-agent runs 6 scanners,\n"
         "generates OSPDT deck, SDLE diagrams,\n"
         "SBOM. Not a 2-week bottleneck.", GREEN),
    ]
    for i, (when, what, detail, color) in enumerate(timeline):
        x = Inches(0.55 + i * 3.05)
        _r(s, x, Inches(1.5), Inches(2.8), Inches(0.55), color)
        _t(s, x+Inches(0.1), Inches(1.52), Inches(1.0), Inches(0.5),
           when, sz=14, b=True, c=WHITE)
        _t(s, x+Inches(1.1), Inches(1.52), Inches(1.6), Inches(0.5),
           what, sz=11, c=LIGHT_TEXT)
        _r(s, x, Inches(2.1), Inches(2.8), Inches(3.0), TABLE_ALT)
        _t(s, x+Inches(0.12), Inches(2.2), Inches(2.56), Inches(2.8),
           detail, sz=11, c=BODY)
        if i < 3:
            _t(s, Inches(3.4 + i * 3.05), Inches(1.6), Inches(0.2), Inches(0.35),
               "\u25b6", sz=14, b=True, c=INTEL_CYAN, a=PP_ALIGN.CENTER)

    _t(s, M_LEFT, Inches(5.5), CONTENT_W, Inches(0.6),
       "Net effect: 90% of developer time on what matters \u2014 "
       "business logic, AI/ML, user experience \u2014 instead of 60% on infrastructure and boilerplate.",
       sz=13, b=True, c=INTEL_BLUE)

    # ═══ SLIDE 14: Section — Go-Live Plan ═══
    s = _sl(prs)
    _section_sl(s, 5, "Go-Live Plan",
        "From pilot to production in 12 weeks")

    # ═══ SLIDE 15: Phased Rollout Timeline ═══
    s = _cs(prs, "Phased Rollout \u2014 12 Weeks to Production")

    phases = [
        ("Phase 1", "Pilot", "Weeks 1\u20133",
         "\u2022 5 developers, 2 real projects\n"
         "\u2022 Hands-on pairing with creator\n"
         "\u2022 Validate templates against real PRDs\n"
         "\u2022 Collect feedback, fix gaps\n"
         "\u2022 Measure: scaffold time, quality", AMBER),
        ("Phase 2", "Workshop & Expand", "Weeks 4\u20136",
         "\u2022 Workshop for full team\n"
         "\u2022 3 sessions: Kickoff, Deep Dive, Office Hrs\n"
         "\u2022 All new projects use pipeline\n"
         "\u2022 Standards v2 from pilot feedback\n"
         "\u2022 Jira + Confluence integrated", INTEL_BLUE),
        ("Phase 3", "Full Adoption", "Weeks 7\u20139",
         "\u2022 All developers onboarded\n"
         "\u2022 Pipeline is default for new projects\n"
         "\u2022 Weekly office hours for support\n"
         "\u2022 Template library growing\n"
         "\u2022 Measure: productivity metrics", INTEL_BLUE),
        ("Phase 4", "Optimize", "Weeks 10\u201312",
         "\u2022 Refine based on real-world usage\n"
         "\u2022 Add project-type templates\n"
         "\u2022 ROI report to leadership\n"
         "\u2022 Plan cross-team expansion\n"
         "\u2022 V2 roadmap finalized", GREEN),
    ]
    for i, (phase, name, weeks, detail, color) in enumerate(phases):
        x = Inches(0.55 + i * 3.05)
        _r(s, x, Inches(0.95), Inches(2.8), Inches(0.7), color)
        _t(s, x+Inches(0.1), Inches(0.97), Inches(1.2), Inches(0.35),
           phase, sz=13, b=True, c=WHITE)
        _t(s, x+Inches(1.3), Inches(0.97), Inches(1.4), Inches(0.35),
           name, sz=11, c=LIGHT_TEXT)
        _t(s, x+Inches(0.1), Inches(1.32), Inches(2.6), Inches(0.28),
           weeks, sz=10, c=RGBColor(220, 230, 245))
        _r(s, x, Inches(1.7), Inches(2.8), Inches(4.8), TABLE_ALT)
        _t(s, x+Inches(0.12), Inches(1.8), Inches(2.56), Inches(4.6),
           detail, sz=10, c=BODY)
        if i < 3:
            _t(s, Inches(3.4 + i * 3.05), Inches(1.15), Inches(0.2), Inches(0.35),
               "\u25b6", sz=14, b=True, c=INTEL_CYAN, a=PP_ALIGN.CENTER)

    # ═══ SLIDE 16: Initial Challenges ═══
    s = _cs(prs, "Initial Challenges & Plan to Overcome")
    _t(s, M_LEFT, Inches(0.85), CONTENT_W, Inches(0.4),
       "We anticipate these challenges and have concrete mitigations planned.",
       sz=14, b=True, c=INTEL_BLUE)
    _tc(s,
        "Expected Challenges", [
            "Template gaps: Not every project type covered in V1 (worker services, ML pipelines, MCP tools)",
            "Developer skepticism: \"AI-generated code can't be trusted\" \u2014 natural resistance to new workflow",
            "Edge-case PRDs: Real PRDs are messy \u2014 ambiguous requirements, missing sections, unusual architectures",
            "Standards tuning: Initial standards sourced from 2 reference projects \u2014 may not fit every team's needs",
            "Compliance nuance: OSPDT reviewers may have project-specific requirements not in templates",
        ],
        "Mitigation Plan", [
            "Pair sessions: Creator pairs with each pilot developer for first project \u2014 real-time fixes",
            "Feedback loop: Dedicated Slack channel + weekly office hours \u2014 issues resolved within days",
            "Living standards: Standards are .md files \u2014 any developer can propose improvements via PR",
            "Template variants: Pilot feedback drives new template types in Phase 2",
            "OSPDT liaison: Work directly with OSPDT reviewer during pilot to calibrate generated deck",
        ],
        y=Inches(1.4))

    # ═══ SLIDE 17: Workshop Plan ═══
    s = _cs(prs, "Workshop Plan \u2014 3 Sessions to Full Adoption")

    workshops = [
        ("Session 1: Kickoff", "2 hours", "Week 4",
         "\u2022 What is agentic coding?\n"
         "\u2022 Live demo: /prd-agent (create PRD)\n"
         "\u2022 Live demo: /dev-agent (generate project)\n"
         "\u2022 Hands-on: run /dev-agent with sample PRD\n"
         "\u2022 Q&A + feedback", INTEL_BLUE),
        ("Session 2: Deep Dive", "2 hours", "Week 5",
         "\u2022 Demo: /validation-agent (test generation)\n"
         "\u2022 Demo: /compliance-agent (OSPDT + scans)\n"
         "\u2022 Quick commands: /scan, /test, /lint, /status\n"
         "\u2022 Understanding the 13 standards\n"
         "\u2022 How to customize templates", INTEL_BLUE),
        ("Session 3: Office Hours", "1 hour/week", "Ongoing",
         "\u2022 Weekly drop-in for questions\n"
         "\u2022 Live debugging of real projects\n"
         "\u2022 Standards improvement proposals\n"
         "\u2022 Template gap identification\n"
         "\u2022 Shared learnings across team", GREEN),
    ]
    for i, (name, dur, when, detail, color) in enumerate(workshops):
        x = Inches(0.55 + i * 4.0)
        _r(s, x, Inches(0.95), Inches(3.7), Inches(0.7), color)
        _t(s, x+Inches(0.1), Inches(0.97), Inches(2.3), Inches(0.35),
           name, sz=13, b=True, c=WHITE)
        _t(s, x+Inches(0.1), Inches(1.32), Inches(1.5), Inches(0.28),
           dur, sz=10, c=LIGHT_TEXT)
        _t(s, x+Inches(2.0), Inches(1.32), Inches(1.5), Inches(0.28),
           when, sz=10, c=LIGHT_TEXT)
        _r(s, x, Inches(1.7), Inches(3.7), Inches(4.8), TABLE_ALT)
        _t(s, x+Inches(0.12), Inches(1.8), Inches(3.46), Inches(4.6),
           detail, sz=11, c=BODY)

    # ═══ SLIDE 18: Section — Investment ═══
    s = _sl(prs)
    _section_sl(s, 6, "Investment",
        "What it costs, what it returns")

    # ═══ SLIDE 19: Cost Model ═══
    s = _cs(prs, "Investment Model \u2014 Per Developer, Scales to Any Team")
    _tbl(s, [
        ("Item", "Per Developer/Month", "Notes"),
        ("Claude Code License (Max Plan)", "$100", "AI engine \u2014 the core investment"),
        ("GitHub Actions (CI/CD)", "$0 incremental", "Already included in GitHub Enterprise"),
        ("Infrastructure", "$0", "Runs on developer laptops + existing CI runners"),
        ("Training Workshop", "$0", "Internal delivery (3 sessions over 3 weeks)"),
        ("Platform Maintenance (shared)", "~$6", "0.5 FTE shared across team for template/standard updates"),
        ("Standards Evolution (shared)", "~$6", "0.5 FTE shared across team for feedback incorporation"),
        ("TOTAL PER DEVELOPER", "~$112/month", "$1,344/year per developer"),
    ], y=Inches(0.95), cw=[Inches(4.0), Inches(3.0), Inches(4.833)], fs=11)

    _t(s, M_LEFT, Inches(4.2), CONTENT_W, Inches(0.8),
       "The investment is linear and predictable. No infrastructure buildout. "
       "No new services to operate. The pipeline runs where developers already work.",
       sz=13, b=True, c=INTEL_BLUE)

    # ═══ SLIDE 20: The Real Comparison ═══
    s = _cs(prs, "The Real Comparison")

    # Blue box — Pipeline
    _r(s, Inches(0.75), Inches(1.0), Inches(5.3), Inches(5.2), INTEL_BLUE)
    _t(s, Inches(0.75), Inches(1.1), Inches(5.3), Inches(0.5),
       "Option A: AI Pipeline", sz=16, b=True, c=WHITE, a=PP_ALIGN.CENTER)
    _t(s, Inches(0.75), Inches(1.7), Inches(5.3), Inches(1.2),
       "$1,344", sz=52, b=True, c=WHITE, a=PP_ALIGN.CENTER)
    _t(s, Inches(0.75), Inches(2.8), Inches(5.3), Inches(0.4),
       "per developer / year", sz=14, c=LIGHT_TEXT, a=PP_ALIGN.CENTER)
    tf = _t(s, Inches(1.1), Inches(3.4), Inches(4.6), Inches(2.5), "", sz=13)
    _bl(tf, [
        "Every developer AI-augmented from day one",
        "100% projects on standardized stack",
        "Compliance automated, not manual",
        "Scales instantly \u2014 add developers, not infrastructure",
        "Every project is production-grade",
        "ROI realized from first project",
    ], sz=13, c=WHITE)

    # Red box — Hiring
    _r(s, Inches(6.75), Inches(1.0), Inches(5.3), Inches(5.2), MUTED_RED)
    _t(s, Inches(6.75), Inches(1.1), Inches(5.3), Inches(0.5),
       "Option B: Hire Equivalent Output", sz=16, b=True, c=WHITE, a=PP_ALIGN.CENTER)
    _t(s, Inches(6.75), Inches(1.7), Inches(5.3), Inches(1.2),
       "$225K", sz=52, b=True, c=WHITE, a=PP_ALIGN.CENTER)
    _t(s, Inches(6.75), Inches(2.8), Inches(5.3), Inches(0.4),
       "per additional headcount / year", sz=14, c=RGBColor(255, 180, 180), a=PP_ALIGN.CENTER)
    tf2 = _t(s, Inches(7.1), Inches(3.4), Inches(4.6), Inches(2.5), "", sz=13)
    _bl(tf2, [
        "6-month ramp to full productivity",
        "Still no standardization guarantee",
        "Still manual compliance processes",
        "Each hire adds one person's output",
        "Does not scale \u2014 need more hires for more projects",
        "Headcount is the bottleneck, not tooling",
    ], sz=13, c=WHITE)

    _t(s, M_LEFT, Inches(6.3), CONTENT_W, Inches(0.4),
       "The pipeline multiplies every developer you already have. Hiring adds linearly.",
       sz=14, b=True, c=INTEL_BLUE)

    # ═══ SLIDE 21: Risk Assessment ═══
    s = _cs(prs, "Risk Assessment & Governance")

    # 2x2 grid
    risks = [
        ("AI Hallucination in Code", AMBER,
         "Mitigation: 70% template-driven (deterministic).\n"
         "Hooks auto-enforce standards on every file.\n"
         "Human code review required before merge."),
        ("Developer Adoption Friction", AMBER,
         "Mitigation: Phased rollout with pairing sessions.\n"
         "Hands-on workshop (not slides). Opt-in pilot first.\n"
         "Show 100x scaffold speed in live demo."),
        ("Claude API Dependency", GREEN,
         "Mitigation: Generated code works fully offline.\n"
         "Pipeline is development-time only, not runtime.\n"
         "Fallback: manual workflow always available."),
        ("Templates Need Updates", GREEN,
         "Mitigation: Living document model \u2014 .md files.\n"
         "0.5 FTE platform maintenance. Feedback loop\n"
         "from every project. Community-driven PRs."),
    ]
    positions = [
        (Inches(0.75), Inches(1.0)), (Inches(6.55), Inches(1.0)),
        (Inches(0.75), Inches(3.7)), (Inches(6.55), Inches(3.7)),
    ]
    for (title, color, desc), (x, y) in zip(risks, positions):
        _r(s, x, y, Inches(5.5), Inches(2.4), color)
        _t(s, x+Inches(0.15), y+Inches(0.1), Inches(5.2), Inches(0.5),
           title, sz=15, b=True, c=WHITE)
        _t(s, x+Inches(0.15), y+Inches(0.65), Inches(5.2), Inches(1.6),
           desc, sz=11, c=WHITE)

    # Axis labels
    _t(s, Inches(0.75), Inches(0.7), Inches(5.5), Inches(0.3),
       "Higher Impact", sz=9, b=True, c=CAPTION)
    _t(s, Inches(0.75), Inches(3.4), Inches(5.5), Inches(0.3),
       "Lower Impact", sz=9, b=True, c=CAPTION)
    _t(s, Inches(0.75), Inches(6.2), Inches(3), Inches(0.3),
       "\u2190 Lower Likelihood", sz=9, b=True, c=CAPTION)
    _t(s, Inches(9.0), Inches(6.2), Inches(3.5), Inches(0.3),
       "Higher Likelihood \u2192", sz=9, b=True, c=CAPTION, a=PP_ALIGN.RIGHT)

    # ═══ SLIDE 22: V1 Scope ═══
    s = _cs(prs, "V1 Scope \u2014 What Ships Now")
    _t(s, M_LEFT, Inches(0.85), CONTENT_W, Inches(0.4),
       "V1 is complete and ready for pilot deployment.",
       sz=14, b=True, c=INTEL_BLUE)
    _tc(s,
        "V1 \u2014 Ready Now", [
            "4 AI Skills: /prd-agent, /dev-agent, /validation-agent, /compliance-agent",
            "13 Standards: coding, security, testing, performance, helm, containers, CI/CD, UX, observability, compliance",
            "75 Project Templates: backend, frontend, Helm, Ansible, CI/CD, Docker, CNCF files",
            "4 Auto-Enforcement Hooks: secret scanning, license headers, dangerous commands, standards validation",
            "7 Quick Commands: /scan, /test, /lint, /deploy, /status, /wiki-publish, /jira-update",
            "9 Pipeline Scripts: Jira, Wiki, GitHub, OSPDT, SBOM, security scans, tests",
            "Intel Enterprise Branding: OSPDT deck generation, 16:9 presentations",
            "Sample PRD: Ready-to-test Document Q&A Assistant example",
        ],
        "What\u2019s NOT in V1 (Planned for V2)", [
            "MCP Integrations: Native Jira MCP, Confluence MCP, GitHub MCP servers",
            "Multi-Language Templates: Java/Spring, Go, Rust, .NET project scaffolds",
            "ML Pipeline Templates: Fine-tuning, dataset processing, model serving",
            "Metrics Dashboard: Grafana dashboards for pipeline usage and productivity",
            "Cross-BU Templates: Templates customized for other Intel business units",
            "Advanced Agents: Code reviewer agent, architecture advisor, cost estimator",
            "Plugin Marketplace: Community-contributed skills and templates",
            "Intel-Wide Rollout: Packaging for deployment across all Intel orgs",
        ],
        y=Inches(1.4))

    # ═══ SLIDE 23: V2 Roadmap ═══
    s = _cs(prs, "V2 Roadmap \u2014 What Comes Next")
    _tbl(s, [
        ("Priority", "V2 Feature", "Impact", "Target"),
        ("P0", "MCP Jira + Confluence Integration", "Native tool integration replaces curl scripts", "Q3 2025"),
        ("P0", "ML Pipeline Templates", "Fine-tuning, dataset processing, model serving scaffolds", "Q3 2025"),
        ("P1", "Java/Spring + Go Templates", "Extends pipeline beyond Python/FastAPI", "Q3 2025"),
        ("P1", "Productivity Metrics Dashboard", "Grafana dashboards tracking pipeline ROI", "Q4 2025"),
        ("P2", "Advanced Sub-Agents", "Architecture advisor, cost estimator, perf profiler", "Q4 2025"),
        ("P2", "Cross-BU Template Library", "Reusable templates across Intel business units", "Q1 2026"),
        ("P3", "Community Plugin System", "Developer-contributed skills and templates", "Q1 2026"),
        ("P3", "Intel-Wide Rollout Package", "Packaging + documentation for org-wide deployment", "Q2 2026"),
    ], y=Inches(0.95), cw=[Inches(1.0), Inches(3.5), Inches(5.0), Inches(2.333)], fs=10)

    _t(s, M_LEFT, Inches(4.5), CONTENT_W, Inches(0.8),
       "V2 roadmap is driven by real-world feedback from V1 pilot and team adoption. "
       "Priorities will be re-evaluated based on developer needs.",
       sz=13, b=True, c=INTEL_BLUE)

    # ═══ SLIDE 24: Closing — The Ask ═══
    s = _sl(prs)
    _bg(s, INTEL_DARK)
    _r(s, Inches(0), Inches(0), SLIDE_W, Inches(0.06), INTEL_CYAN)
    _logo(s, x=Inches(5.55), y=Inches(0.5), w=Inches(2.2))

    _t(s, Inches(1.5), Inches(1.6), Inches(10.333), Inches(0.8),
       "Ready for V1 Go-Live", sz=36, b=True, c=WHITE, a=PP_ALIGN.CENTER)
    _r(s, Inches(4.5), Inches(2.5), Inches(4.333), Inches(0.04), INTEL_CYAN)

    # Three ask boxes
    asks = [
        ("Immediate", "Approve Claude Code\nlicenses for pilot team",
         "Designate 2 pilot projects", INTEL_BLUE),
        ("Month 1", "Schedule kickoff\nworkshop (2 hours)",
         "Assign pilot developers", INTEL_BLUE),
        ("Month 3", "Review pilot results\nand approve expansion",
         "Fund 0.5 FTE platform role", INTEL_CYAN),
    ]
    for i, (when, action, detail, color) in enumerate(asks):
        x = Inches(0.75 + i * 4.1)
        _r(s, x, Inches(2.9), Inches(3.7), Inches(2.2), color)
        _t(s, x+Inches(0.15), Inches(2.95), Inches(3.4), Inches(0.4),
           when, sz=14, b=True, c=WHITE)
        _t(s, x+Inches(0.15), Inches(3.4), Inches(3.4), Inches(0.9),
           action, sz=13, c=WHITE)
        _t(s, x+Inches(0.15), Inches(4.3), Inches(3.4), Inches(0.6),
           detail, sz=11, c=LIGHT_TEXT)

    _t(s, Inches(1.5), Inches(5.5), Inches(10.333), Inches(0.6),
       "Every developer, 10x output, production-grade from day one.",
       sz=18, b=True, c=INTEL_CYAN, a=PP_ALIGN.CENTER)
    _t(s, Inches(1.5), Inches(6.2), Inches(10.333), Inches(0.5),
       "Vivek RS  |  vivek.rs@intel.com  |  DCAI Software Engineering",
       sz=13, c=RGBColor(140, 175, 220), a=PP_ALIGN.CENTER)
    _r(s, Inches(0), Inches(7.3), SLIDE_W, Inches(0.2), INTEL_BLUE)

    # Save
    Path(output_path).parent.mkdir(parents=True, exist_ok=True)
    prs.save(output_path)
    print(f"Executive Pitch saved: {output_path}")


if __name__ == "__main__":
    generate_executive_pitch(
        "docs/presentations/Intel_AI_Solutions_Dev_Executive_Pitch.pptx")
