#!/usr/bin/env python3
# Copyright (C) 2024 Intel Corporation
# SPDX-License-Identifier: Apache-2.0
"""Generate OSPDT PowerPoint deck from scan results."""

import argparse
import json
import sys
from datetime import date
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from lib.pptx_generator import generate_ospdt_deck


def load_json_report(path: str) -> dict | list:
    p = Path(path)
    if not p.exists():
        print(f"Warning: {path} not found, using empty data")
        return {}
    return json.loads(p.read_text(encoding="utf-8"))


def main():
    parser = argparse.ArgumentParser(description="Generate OSPDT PowerPoint deck")
    parser.add_argument("--project-name", required=True, help="Project name")
    parser.add_argument("--license-report", help="pip-licenses JSON report")
    parser.add_argument("--security-report", help="Bandit JSON report")
    parser.add_argument("--trivy-report", help="Trivy JSON report")
    parser.add_argument("--output", help="Output .pptx path")
    args = parser.parse_args()

    licenses = load_json_report(args.license_report) if args.license_report else []
    security = load_json_report(args.security_report) if args.security_report else {}
    trivy = load_json_report(args.trivy_report) if args.trivy_report else {}

    if isinstance(licenses, dict):
        licenses = licenses.get("packages", [])

    # Merge scan results into a single summary dict
    scan_results: dict = {}
    if isinstance(security, dict):
        scan_results.update(security)
    if isinstance(trivy, dict):
        for key in ("critical", "high", "medium", "low", "total"):
            if key in trivy:
                scan_results[key] = scan_results.get(key, 0) + trivy[key]
    if not scan_results.get("scanner"):
        scan_results["scanner"] = "Trivy + Bandit + pip-audit"

    output_path = args.output or f"docs/reports/ospdt-{date.today().isoformat()}.pptx"
    Path(output_path).parent.mkdir(parents=True, exist_ok=True)

    generate_ospdt_deck(
        project_name=args.project_name,
        dependencies=licenses,
        scan_results=scan_results,
        output_path=output_path,
    )
    print(f"OSPDT deck generated: {output_path}")


if __name__ == "__main__":
    main()
