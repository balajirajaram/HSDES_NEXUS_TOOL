#!/usr/bin/env python3
# Copyright (C) 2024 Intel Corporation
# SPDX-License-Identifier: Apache-2.0
"""Generate enterprise-quality presentation decks for Intel AI Solutions Development.

Produces two 16:9 widescreen PowerPoint files with Intel branding:
  1. Technical Landscape — architecture, technology, benefits
  2. Developer Workshop — hands-on guide for the pipeline

Design: 13.333" x 7.5" (standard 16:9), Intel logo on every slide,
consistent header/footer system, professional table styling.
"""

from pathlib import Path

from pptx import Presentation
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE
from pptx.enum.text import MSO_ANCHOR, PP_ALIGN
from pptx.util import Emu, Inches, Pt

# ── Paths ────────────────────────────────────────────────────────────────────
SCRIPT_DIR = Path(__file__).resolve().parent
REPO_ROOT = SCRIPT_DIR.parent
LOGO_PATH = REPO_ROOT / "templates" / "intellogo.png"

# ── Slide Dimensions (exact 16:9 widescreen) ────────────────────────────────
SLIDE_W = Emu(12192000)   # 13.333 inches
SLIDE_H = Emu(6858000)    # 7.5 inches

# ── Intel Brand Palette ──────────────────────────────────────────────────────
INTEL_BLUE = RGBColor(0, 104, 181)       # #0068B5 — primary brand (logo text)
INTEL_DARK = RGBColor(0, 53, 128)        # #003580 — dark blue (title bars)
INTEL_CYAN = RGBColor(0, 199, 253)       # #00C7FD — accent (logo dot)
WHITE = RGBColor(255, 255, 255)
BODY = RGBColor(51, 51, 51)              # #333333
CAPTION = RGBColor(102, 102, 102)        # #666666
LIGHT_TEXT = RGBColor(180, 210, 255)     # for text on dark backgrounds
FAINT_TEXT = RGBColor(150, 190, 240)     # lighter variant
TABLE_ALT = RGBColor(237, 243, 250)      # #EDF3FA — alternating rows
RULE_COLOR = RGBColor(200, 215, 235)     # #C8D7EB — thin separators

# ── Layout Grid ──────────────────────────────────────────────────────────────
M_LEFT = Inches(0.75)
M_RIGHT = Inches(0.75)
CONTENT_W = Inches(11.833)               # 13.333 - 0.75 - 0.75
FONT = "Calibri"

# Logo dimensions (1280 x 497 px → aspect 2.575:1)
LOGO_FOOTER_W = Inches(0.85)
LOGO_FOOTER_X = Inches(12.1)
LOGO_FOOTER_Y = Inches(7.0)
LOGO_TITLE_W = Inches(2.2)
LOGO_SECTION_W = Inches(1.7)

# Slide counter
_slide_num = 0


# ═══════════════════════════════════════════════════════════════════════════════
#  LAYOUT PRIMITIVES
# ═══════════════════════════════════════════════════════════════════════════════

def _new_prs():
    prs = Presentation()
    prs.slide_width = SLIDE_W
    prs.slide_height = SLIDE_H
    return prs


def _slide(prs, reset=False):
    global _slide_num
    if reset:
        _slide_num = 0
    _slide_num += 1
    return prs.slides.add_slide(prs.slide_layouts[6])


def _bg(slide, color):
    fill = slide.background.fill
    fill.solid()
    fill.fore_color.rgb = color


def _rect(slide, left, top, width, height, color):
    s = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, left, top, width, height)
    s.fill.solid()
    s.fill.fore_color.rgb = color
    s.line.fill.background()
    return s


def _tb(slide, left, top, width, height, text="", sz=14, bold=False,
        color=BODY, align=PP_ALIGN.LEFT, font=FONT):
    box = slide.shapes.add_textbox(left, top, width, height)
    tf = box.text_frame
    tf.word_wrap = True
    if text:
        p = tf.paragraphs[0]
        p.text = text
        p.font.size = Pt(sz)
        p.font.bold = bold
        p.font.color.rgb = color
        p.font.name = font
        p.alignment = align
    return tf


def _bullets(tf, items, sz=12, color=BODY, bold_prefix=False):
    for item in items:
        p = tf.add_paragraph()
        p.space_before = Pt(3)
        p.space_after = Pt(1)
        if bold_prefix and ": " in item:
            prefix, rest = item.split(": ", 1)
            r1 = p.add_run()
            r1.text = prefix + ": "
            r1.font.bold = True
            r1.font.size = Pt(sz)
            r1.font.color.rgb = color
            r1.font.name = FONT
            r2 = p.add_run()
            r2.text = rest
            r2.font.size = Pt(sz)
            r2.font.color.rgb = color
            r2.font.name = FONT
        else:
            p.text = item
            p.font.size = Pt(sz)
            p.font.color.rgb = color
            p.font.name = FONT
        p.level = 0


def _logo(slide, x=None, y=None, w=None):
    if not LOGO_PATH.exists():
        return
    slide.shapes.add_picture(
        str(LOGO_PATH),
        x if x is not None else LOGO_FOOTER_X,
        y if y is not None else LOGO_FOOTER_Y,
        width=w if w is not None else LOGO_FOOTER_W,
    )


# ── Composite Layouts ────────────────────────────────────────────────────────

def _header(slide, title):
    _rect(slide, Inches(0), Inches(0), SLIDE_W, Inches(0.6), INTEL_DARK)
    _rect(slide, Inches(0), Inches(0.6), SLIDE_W, Inches(0.04), INTEL_CYAN)
    _tb(slide, M_LEFT, Inches(0.1), CONTENT_W, Inches(0.45),
        title, sz=24, bold=True, color=WHITE)


def _footer(slide, text="Intel AI Solutions Development"):
    _rect(slide, Inches(0.5), Inches(6.83), Inches(12.333), Inches(0.008), RULE_COLOR)
    _tb(slide, M_LEFT, Inches(6.88), Inches(4), Inches(0.3),
        text, sz=8, color=CAPTION)
    _tb(slide, Inches(5.5), Inches(6.88), Inches(3), Inches(0.3),
        "Intel Confidential", sz=8, color=CAPTION, align=PP_ALIGN.CENTER)
    _tb(slide, Inches(11.2), Inches(6.88), Inches(0.8), Inches(0.3),
        str(_slide_num), sz=8, color=CAPTION, align=PP_ALIGN.RIGHT)
    _logo(slide)


def _content_slide(prs, title, footer_text="Intel AI Solutions Development"):
    s = _slide(prs)
    _header(s, title)
    _footer(s, footer_text)
    return s


def _title_slide_layout(slide, title, subtitle="", tagline="", author=""):
    _bg(slide, INTEL_DARK)
    _rect(slide, Inches(0), Inches(0), SLIDE_W, Inches(0.06), INTEL_CYAN)
    _logo(slide, x=Inches(5.55), y=Inches(1.0), w=LOGO_TITLE_W)
    _tb(slide, Inches(1.5), Inches(2.4), Inches(10.333), Inches(1.2),
        title, sz=36, bold=True, color=WHITE, align=PP_ALIGN.CENTER)
    if subtitle:
        _tb(slide, Inches(1.5), Inches(3.6), Inches(10.333), Inches(0.8),
            subtitle, sz=20, color=LIGHT_TEXT, align=PP_ALIGN.CENTER)
    _rect(slide, Inches(4.5), Inches(4.65), Inches(4.333), Inches(0.04), INTEL_CYAN)
    if tagline:
        _tb(slide, Inches(1.5), Inches(4.95), Inches(10.333), Inches(0.6),
            tagline, sz=15, color=FAINT_TEXT, align=PP_ALIGN.CENTER)
    if author:
        _tb(slide, Inches(1.5), Inches(5.75), Inches(10.333), Inches(0.5),
            author, sz=13, color=RGBColor(140, 175, 220), align=PP_ALIGN.CENTER)
    _rect(slide, Inches(0), Inches(7.3), SLIDE_W, Inches(0.2), INTEL_BLUE)


def _section_layout(slide, num, title, subtitle=""):
    _bg(slide, INTEL_DARK)
    _rect(slide, Inches(0), Inches(0), SLIDE_W, Inches(0.06), INTEL_CYAN)
    if num:
        _tb(slide, Inches(1.5), Inches(2.0), Inches(10.333), Inches(1.2),
            f"{num:02d}", sz=60, bold=True, color=INTEL_CYAN, align=PP_ALIGN.CENTER)
    _tb(slide, Inches(1.5), Inches(3.2), Inches(10.333), Inches(1),
        title, sz=32, bold=True, color=WHITE, align=PP_ALIGN.CENTER)
    if subtitle:
        _tb(slide, Inches(1.5), Inches(4.3), Inches(10.333), Inches(0.6),
            subtitle, sz=16, color=LIGHT_TEXT, align=PP_ALIGN.CENTER)
    _rect(slide, Inches(5), Inches(5.2), Inches(3.333), Inches(0.04), INTEL_CYAN)
    _logo(slide, x=Inches(5.8), y=Inches(5.7), w=LOGO_SECTION_W)
    _rect(slide, Inches(0), Inches(7.3), SLIDE_W, Inches(0.2), INTEL_BLUE)


def _two_col(slide, l_title, l_items, r_title, r_items, y=None):
    y = y or Inches(0.9)
    col_w = Inches(5.55)
    gap = Inches(0.7)
    rx = M_LEFT + col_w + gap

    _rect(slide, M_LEFT, y, col_w, Inches(0.4), INTEL_BLUE)
    _tb(slide, M_LEFT + Inches(0.12), y + Inches(0.03), col_w, Inches(0.35),
        l_title, sz=13, bold=True, color=WHITE)
    tf_l = _tb(slide, M_LEFT + Inches(0.12), y + Inches(0.5), Inches(5.3), Inches(5.2),
               "", sz=12)
    _bullets(tf_l, l_items, sz=12, bold_prefix=True)

    _rect(slide, rx, y, col_w, Inches(0.4), INTEL_BLUE)
    _tb(slide, rx + Inches(0.12), y + Inches(0.03), col_w, Inches(0.35),
        r_title, sz=13, bold=True, color=WHITE)
    tf_r = _tb(slide, rx + Inches(0.12), y + Inches(0.5), Inches(5.3), Inches(5.2),
               "", sz=12)
    _bullets(tf_r, r_items, sz=12, bold_prefix=True)


def _make_table(slide, rows, y=None, col_widths=None, font_sz=10):
    y = y or Inches(1.1)
    n_rows = len(rows)
    n_cols = len(rows[0])
    total_w = sum(col_widths) if col_widths else CONTENT_W
    row_h = Inches(0.36)

    ts = slide.shapes.add_table(n_rows, n_cols, M_LEFT, y, total_w, row_h * n_rows)
    tbl = ts.table

    if col_widths:
        for j, w in enumerate(col_widths):
            tbl.columns[j].width = w

    for i, row_data in enumerate(rows):
        for j, val in enumerate(row_data):
            cell = tbl.cell(i, j)
            cell.text = val
            cell.vertical_anchor = MSO_ANCHOR.MIDDLE
            cell.margin_left = Inches(0.08)
            cell.margin_right = Inches(0.08)
            cell.margin_top = Inches(0.04)
            cell.margin_bottom = Inches(0.04)

            for para in cell.text_frame.paragraphs:
                para.font.size = Pt(font_sz)
                para.font.name = FONT
                para.space_before = Pt(0)
                para.space_after = Pt(0)
                if i == 0:
                    para.font.bold = True
                    para.font.color.rgb = WHITE
                else:
                    para.font.color.rgb = BODY
                if j == 0 and i > 0:
                    para.font.bold = True

            if i == 0:
                cell.fill.solid()
                cell.fill.fore_color.rgb = INTEL_DARK
            elif i % 2 == 0:
                cell.fill.solid()
                cell.fill.fore_color.rgb = TABLE_ALT

    return ts


def _closing_slide(slide, title, subtitle="", tagline=""):
    _bg(slide, INTEL_DARK)
    _rect(slide, Inches(0), Inches(0), SLIDE_W, Inches(0.06), INTEL_CYAN)
    _logo(slide, x=Inches(5.55), y=Inches(1.8), w=LOGO_TITLE_W)
    _tb(slide, Inches(1.5), Inches(3.2), Inches(10.333), Inches(1),
        title, sz=40, bold=True, color=WHITE, align=PP_ALIGN.CENTER)
    if subtitle:
        _tb(slide, Inches(1.5), Inches(4.3), Inches(10.333), Inches(0.7),
            subtitle, sz=22, color=LIGHT_TEXT, align=PP_ALIGN.CENTER)
    _rect(slide, Inches(4.5), Inches(5.2), Inches(4.333), Inches(0.04), INTEL_CYAN)
    if tagline:
        _tb(slide, Inches(1.5), Inches(5.5), Inches(10.333), Inches(0.6),
            tagline, sz=15, color=FAINT_TEXT, align=PP_ALIGN.CENTER)
    _rect(slide, Inches(0), Inches(7.3), SLIDE_W, Inches(0.2), INTEL_BLUE)


# ═══════════════════════════════════════════════════════════════════════════════
#  PPT 1: TECHNICAL LANDSCAPE & ARCHITECTURE
# ═══════════════════════════════════════════════════════════════════════════════

def generate_tech_landscape(output_path: str):
    prs = _new_prs()

    # ── Slide 1: Title ──
    s = _slide(prs, reset=True)
    _title_slide_layout(
        s,
        "Intel AI Solutions Development",
        "Technical Landscape & Architecture",
        "How Agentic Coding Transforms Enterprise AI Development",
        "DCAI Software Engineering  |  2025",
    )

    # ── Slide 2: The Problem ──
    s = _content_slide(prs, "The Problem We're Solving")
    _tb(s, M_LEFT, Inches(0.85), CONTENT_W, Inches(0.5),
        "~30-person AI Solutions team. Everyone codes differently. No standardized pipeline.",
        sz=15, bold=True, color=INTEL_BLUE)
    tf = _tb(s, M_LEFT, Inches(1.45), CONTENT_W, Inches(5.0), "", sz=13)
    _bullets(tf, [
        "Each developer scaffolds from scratch (2-3 days per project)",
        "Different libraries, different patterns, different quality levels",
        "Dockerfiles vary widely — many run as root, no health checks",
        "Helm charts are basic or missing — no NetworkPolicy, no PDB, no HPA",
        "Security scans happen at the end (if at all) — OSPDT takes days manually",
        "No connection between Planning (PRD) \u2192 Code \u2192 Tests \u2192 Compliance",
        "Jira updates are manual, Wiki docs are afterthoughts",
        "Intel license headers forgotten, pre-commit hooks absent",
        "No SBOM, no container signing, no SLSA provenance",
        "Result: Inconsistent quality, slow time-to-production, compliance bottlenecks",
    ], sz=13)

    # ── Slide 3: Vision ──
    s = _slide(prs)
    _bg(s, INTEL_DARK)
    _rect(s, Inches(0), Inches(0), SLIDE_W, Inches(0.06), INTEL_CYAN)
    _tb(s, Inches(1.5), Inches(1.5), Inches(10.333), Inches(1),
        "The Vision", sz=36, bold=True, color=WHITE, align=PP_ALIGN.CENTER)
    _tb(s, Inches(1.5), Inches(2.8), Inches(10.333), Inches(1),
        "1 Developer + Claude Code = 10 Developers\u2019 Output",
        sz=28, bold=True, color=INTEL_CYAN, align=PP_ALIGN.CENTER)
    _rect(s, Inches(4.5), Inches(4.0), Inches(4.333), Inches(0.04), INTEL_CYAN)
    _tb(s, Inches(1.5), Inches(4.4), Inches(10.333), Inches(2),
        "Every project meets the highest open source AND Intel compliance bar from day one.\n\n"
        "CNCF-compliant  \u2502  OpenSSF 8+/10  \u2502  SLSA Level 2+  \u2502  12-Factor\n"
        "Production containers  \u2502  Zero-trust networking  \u2502  Full observability  \u2502  OSPDT-ready",
        sz=15, color=RGBColor(200, 220, 250), align=PP_ALIGN.CENTER)
    _logo(s, x=Inches(5.8), y=Inches(6.3), w=LOGO_SECTION_W)
    _rect(s, Inches(0), Inches(7.3), SLIDE_W, Inches(0.2), INTEL_BLUE)

    # ── Slide 4: What is Agentic Coding? ──
    s = _content_slide(prs, "What is Agentic Coding?")
    _tb(s, M_LEFT, Inches(0.85), CONTENT_W, Inches(0.5),
        "AI that doesn\u2019t just suggest code \u2014 it plans, generates, validates, and enforces standards autonomously.",
        sz=14, bold=True, color=INTEL_BLUE)
    _two_col(s,
        "Claude Code \u2014 The Foundation", [
            "CLI tool: AI coding assistant in the terminal",
            "Reads your codebase, understands full context",
            "Creates/edits files, runs commands, iterates",
            "Skills: Multi-phase AI workflows (our 4 agents)",
            "Commands: Quick slash-command shortcuts",
            "Hooks: Auto-enforcement on every action",
            "Agents: Specialist sub-agents for focused tasks",
            "Settings: Permission profiles (dev / CI / read-only)",
        ],
        "Why Agentic, Not Copilot?", [
            "Copilot: Suggests the next line of code",
            "Agentic: Plans the entire project architecture",
            "Copilot: Developer drives every decision",
            "Agentic: AI executes a multi-step workflow",
            "Copilot: No enforcement, no standards",
            "Agentic: Hooks auto-enforce on every file write",
            "Copilot: Works on one file at a time",
            "Agentic: Generates 80+ files in one workflow",
        ],
        y=Inches(1.5),
    )

    # ── Slide 5: The 4-Stage Pipeline ──
    s = _content_slide(prs, "The End-to-End Pipeline")

    stages = [
        ("1. /prd-agent", "PRD Creation",
         "Socratic Q&A or meeting\ntranscript processing\n\n"
         "Outputs:\n\u2022 PRD document\n\u2022 Feature Breakdown\n\u2022 Technical PRD\n\n"
         "Integrations:\n\u2192 Wiki publish\n\u2192 Jira EPICs/Stories"),
        ("2. /dev-agent", "Code Generation",
         "Reads Technical PRD +\nhandoff metadata\n\n"
         "Outputs:\n\u2022 80+ production files\n\u2022 FastAPI + React + Helm\n\u2022 CI/CD + Docker + Ansible\n\n"
         "Integrations:\n\u2192 GitHub push\n\u2192 Jira update"),
        ("3. /validation-agent", "Testing & QA",
         "Maps PRD acceptance\ncriteria to test cases\n\n"
         "Outputs:\n\u2022 Unit + integration tests\n\u2022 Security test stubs\n\u2022 Coverage report\n\n"
         "Integrations:\n\u2192 Wiki report\n\u2192 Jira update"),
        ("4. /compliance-agent", "Compliance",
         "Security scans +\ncompliance artifacts\n\n"
         "Outputs:\n\u2022 OSPDT PowerPoint\n\u2022 SDLE diagrams\n\u2022 SBOM (CycloneDX)\n\n"
         "Integrations:\n\u2192 Wiki publish\n\u2192 OSPDT submission"),
    ]

    card_w = Inches(2.7)
    gap = Inches(0.2)
    start_x = Inches(0.55)

    for idx, (label, sub, content) in enumerate(stages):
        x = start_x + idx * (card_w + gap)
        # Card header
        _rect(s, x, Inches(0.95), card_w, Inches(0.7), INTEL_BLUE)
        _tb(s, x + Inches(0.1), Inches(0.97), card_w - Inches(0.2), Inches(0.35),
            label, sz=13, bold=True, color=WHITE)
        _tb(s, x + Inches(0.1), Inches(1.3), card_w - Inches(0.2), Inches(0.3),
            sub, sz=10, color=LIGHT_TEXT)
        # Card body
        _rect(s, x, Inches(1.7), card_w, Inches(4.8), TABLE_ALT)
        _tb(s, x + Inches(0.12), Inches(1.8), card_w - Inches(0.24), Inches(4.6),
            content, sz=10, color=BODY)
        # Arrow between cards
        if idx < 3:
            ax = x + card_w + Inches(0.02)
            _tb(s, ax, Inches(1.15), Inches(0.18), Inches(0.35),
                "\u25b6", sz=14, bold=True, color=INTEL_CYAN, align=PP_ALIGN.CENTER)

    # ── Slide 6: Claude Code Component Architecture ──
    s = _content_slide(prs, "Claude Code Component Architecture")

    _make_table(s, [
        ("Component", "Location", "Purpose", "Count"),
        ("Skills", ".claude/skills/{name}/SKILL.md", "4 main agents (prd, dev, validation, compliance)", "4"),
        ("Commands", ".claude/commands/{name}.md", "Quick actions: /scan, /test, /lint, /deploy, /status, /wiki-publish, /jira-update", "7"),
        ("Hooks", ".claude/hooks/*.py", "Auto-enforce: secrets, licenses, dangerous cmds, standards", "4"),
        ("Agents", ".claude/agents/{name}.md", "Sub-specialists: security-reviewer, helm-validator, dockerfile-reviewer, test-gap", "4"),
        ("Standards", ".claude/shared/standards/*.md", "13 source-of-truth standards (coding, security, helm, containers, CI/CD, ...)", "13"),
        ("Contracts", ".claude/shared/contracts/*.md", "Inter-skill data schemas (PRD output, test report, compliance report, Jira mapping)", "4"),
        ("Settings", ".claude/settings.json", "Permissions (allow/deny glob patterns) + hook wiring configuration", "1"),
    ], y=Inches(0.95), col_widths=[Inches(1.5), Inches(3.2), Inches(5.8), Inches(1.333)], font_sz=11)

    _tb(s, M_LEFT, Inches(4.3), CONTENT_W, Inches(0.5),
        "Total: 37 Claude Code components + 75 project scaffold templates + 18 scripts = 149 files",
        sz=14, bold=True, color=INTEL_BLUE)

    # ── Slide 7: Template-Driven Determinism ──
    s = _content_slide(prs, "Template-Driven Determinism")
    _tb(s, M_LEFT, Inches(0.85), CONTENT_W, Inches(0.5),
        "~70% of generated output is deterministic templates with variable substitution \u2014 no hallucination.",
        sz=14, bold=True, color=INTEL_BLUE)
    _two_col(s,
        "75 Scaffold Templates", [
            "Backend: 22 files (FastAPI, config, middleware, auth, observability, models, DB, tests)",
            "Frontend: 7 files (React, TypeScript, Vite, providers, router)",
            "Helm: 16 files (200+ params, zero-trust NetworkPolicy, HPA, PDB, 3 probes)",
            "Ansible: 11 files (6 playbooks, 3 role tiers, inventory)",
            "CI/CD: 10 files (Super-Linter, SDLE scans, SLSA release, CodeQL, Dependabot)",
            "CNCF: 5 files (LICENSE, CODE_OF_CONDUCT, CONTRIBUTING, SECURITY, THIRD-PARTY)",
            "Automation: 9 files (Makefile, Taskfile, pre-commit, .gitignore, .env, CLAUDE.md, README)",
        ],
        "Variables from PRD Handoff", [
            "{{project_name}}: Human-readable project name",
            "{{project_slug}}: kebab-case slug",
            "{{package_name}}: Python package (snake_case)",
            "{{port}}: Default backend port (8000)",
            "{{year}}: Current year for copyright",
            "{{github_org}}: GitHub organization",
            "{{description}}: From PRD summary",
            "",
            "Same PRD \u2192 Same output every time",
            "No improvisation, no hallucination",
        ],
        y=Inches(1.5),
    )

    # ── Slide 8: Gold Standards ──
    s = _content_slide(prs, "Gold Standards \u2014 Sourced from OPEA Enterprise Projects")

    _make_table(s, [
        ("Standard", "Source", "Key Patterns"),
        ("FastAPI Backend", "Enterprise-Inference", "Lifespan manager, LIFO middleware stack, pydantic-settings, structlog"),
        ("Container Security", "Enterprise-Inference", "Multi-stage build, slim+curl runtime, uid=1000, HEALTHCHECK"),
        ("Helm Charts", "Enterprise-Inference", "200+ params, zero-trust NetworkPolicy, HPA stabilization, PDB, 3 probes"),
        ("CI/CD Security", "Enterprise-Inference", "Trivy + Bandit + ShellCheck, 30-day artifact retention"),
        ("Pre-commit", "Enterprise-RAG", "Intel license insertion, ruff, black, detect-secrets, commitlint"),
        ("Super-Linter", "Enterprise-RAG", "v6.8.0 incremental, Bash/YAML/Python/Dockerfile validation"),
        ("Per-component Tests", "Enterprise-RAG", "tox per component, path-filtered CI triggers"),
        ("Ansible IaC", "Enterprise-RAG", "3-tier roles (common/infra/app), 6 playbooks, multi-env inventory"),
        ("CNCF Files", "Enterprise-RAG", "Apache-2.0, Contributor Covenant, DCO, SECURITY.md"),
        ("React Frontend", "Bulletproof React", "Feature-based folders, strict TypeScript, Zustand + TanStack Query"),
        ("Observability", "Enterprise-Inference", "structlog + Prometheus + OpenTelemetry + 4 health endpoints"),
        ("Supply Chain", "SLSA / OpenSSF", "cosign signing, CycloneDX SBOM, provenance, Dependabot"),
    ], y=Inches(0.95), col_widths=[Inches(2.2), Inches(2.5), Inches(7.133)], font_sz=10)

    # ── Slide 9: Auto-Enforcement ──
    s = _content_slide(prs, "Auto-Enforcement \u2014 Hooks Run Without Developer Action")
    _two_col(s,
        "PreToolUse Hooks (Before Execution)", [
            "Secret Scanner: Scans every Bash command for API keys, passwords, tokens, private keys before execution",
            "Dangerous Command Blocker: Blocks rm -rf /, git push --force, sudo, chmod 777, curl|bash",
            "",
            "How it works:",
            "1. Developer types a command",
            "2. Hook intercepts via stdin (JSON)",
            "3. Regex patterns check for violations",
            "4. Returns {decision: block/approve}",
            "5. Blocked = command never executes",
        ],
        "PostToolUse Hooks (After File Write)", [
            "License Header Check: Warns if .py/.ts/.sh files are missing Intel Apache-2.0 copyright header",
            "Standards Validator: Checks Python files use snake_case, React components use PascalCase",
            "",
            "How it works:",
            "1. Developer creates/edits a file",
            "2. Hook reads the file path + content",
            "3. Checks against standards",
            "4. Returns warning message (non-blocking)",
            "5. Developer sees reminder automatically",
        ],
    )

    # ── Slide 10: Security Architecture ──
    s = _content_slide(prs, "Security Architecture \u2014 Defense in Depth")
    _two_col(s,
        "Container & Network Security", [
            "Multi-stage Docker: builder(venv) \u2192 runtime(slim+curl)",
            "Non-root: appuser uid=1000, gid=1000",
            "Read-only root filesystem (writable /tmp only)",
            "Drop ALL Linux capabilities",
            "No privileged containers",
            "HEALTHCHECK in every Dockerfile",
            "",
            "Zero-trust K8s NetworkPolicy:",
            "  \u2022 Default deny all ingress/egress",
            "  \u2022 Allow: same namespace ingress only",
            "  \u2022 Egress: DNS:53, PostgreSQL:5432, Redis:6379, HTTPS:443",
        ],
        "Supply Chain & Scanning", [
            "SLSA Level 2+: Scripted builds, hosted CI, provenance",
            "Container signing: cosign/sigstore on release images",
            "SBOM: CycloneDX format on every release",
            "Dependency pinning: Lock files, Dependabot",
            "",
            "CI Security Scans (every PR):",
            "  \u2022 Bandit: Python SAST",
            "  \u2022 Trivy: Filesystem + container image",
            "  \u2022 ShellCheck: Shell script analysis",
            "  \u2022 detect-secrets: Secret scanning",
            "  \u2022 CodeQL: Multi-language SAST",
            "  \u2022 pip-audit / npm audit: Dependency CVEs",
        ],
    )

    # ── Slide 11: Before vs After (10x Impact) ──
    s = _content_slide(prs, "The 10x Impact \u2014 Before vs After")

    _make_table(s, [
        ("Without Pipeline", "With Pipeline", "Impact"),
        ("Scaffold from scratch (2-3 days)", "/dev-agent \u2192 complete project (15 min)", "100x faster scaffolding"),
        ("Every dev picks different libraries", "Same approved stack, every time", "Consistent quality"),
        ("Dockerfiles vary, many insecure", "Multi-stage, slim, uid=1000 from template", "Secure by default"),
        ("No Helm or basic Helm", "200+ params, zero-trust, PDB, HPA, 3 probes", "Production-grade K8s"),
        ("Manual Jira updates", "Auto-comments from every pipeline stage", "Always up to date"),
        ("Security scan at end (if at all)", "SDLE scans in CI from day one", "Shift-left security"),
        ("OSPDT deck manually (days)", "Auto-generated PowerPoint in minutes", "Compliance velocity"),
        ("Tests as afterthought", "85%+ coverage generated WITH the code", "Quality built-in"),
        ("No license headers", "Auto-inserted via pre-commit + hooks", "Always compliant"),
        ("Secrets leak into commits", "Hooks scan every command before execution", "Zero secret leaks"),
    ], y=Inches(0.95), col_widths=[Inches(3.5), Inches(4.5), Inches(3.833)], font_sz=10)

    # ── Slide 12: Integration Points ──
    s = _content_slide(prs, "Integration Points")
    _two_col(s,
        "External Systems", [
            "Jira: Auto-create EPICs/Stories from Feature Breakdown, auto-comment with pipeline status",
            "Confluence: Auto-publish PRDs, test reports, compliance reports",
            "GitHub: Auto-init repo, push, create branches (git CLI, no gh dependency)",
            "Intel F5 BigIP: curl subprocess bypass for internal APIs",
            "",
            "All via scripts/lib/ (9 modules):",
            "  curl_wrapper.py \u2014 F5-compatible HTTP",
            "  jira_client.py \u2014 Jira REST API",
            "  wiki_client.py \u2014 Confluence REST API",
            "  github_client.py \u2014 Git CLI wrapper",
        ],
        "Pipeline Scripts (9)", [
            "export-to-jira.py: PRD breakdown \u2192 EPICs + Stories",
            "publish-to-wiki.py: Markdown \u2192 Confluence page",
            "push-to-github.py: Init + commit + push",
            "update-jira-comment.py: Status updates on tickets",
            "generate-ospdt-deck.py: License/scan data \u2192 PPTX",
            "generate-sdle-diagrams.py: Project \u2192 Mermaid diagrams",
            "generate-sbom.py: CycloneDX via Trivy (fallback: pip)",
            "run-security-scan.py: Bandit + Trivy + ShellCheck + secrets",
            "run-tests.py: Per-component tox with coverage report",
        ],
    )

    # ── Slide 13: Repository at a Glance ──
    s = _content_slide(prs, "Repository at a Glance \u2014 149 Files")

    tree = (
        "intel-ai-solutions-dev/\n"
        "  .claude/\n"
        "    skills/            4 SKILL.md files (prd, dev, validation, compliance)\n"
        "    commands/          7 slash commands (scan, test, lint, deploy, status, wiki-publish, jira-update)\n"
        "    agents/            4 sub-specialists (security-reviewer, helm-validator, dockerfile-reviewer, test-gap)\n"
        "    hooks/             4 Python enforcement scripts (secret-scanner, license, dangerous-cmd, standards)\n"
        "    shared/standards/  13 standards (coding, security, testing, helm, container, observability, ...)\n"
        "    shared/contracts/  4 inter-skill data schemas (PRD output, test report, compliance, Jira mapping)\n"
        "    settings.json      Permissions + hook wiring\n"
        "\n"
        "  scripts/\n"
        "    lib/               9 shared modules (curl, jira, wiki, github, pptx, diagrams, markdown, config)\n"
        "    (9 scripts)        export-to-jira, publish-to-wiki, run-security-scan, run-tests, ...\n"
        "\n"
        "  templates/\n"
        "    project-scaffold/  75 template files (backend, frontend, helm, ansible, CI/CD, CNCF, automation)\n"
        "    ospdt/             OSPDT deck sections template\n"
        "    sdle/              Threat model + data flow diagram templates\n"
        "    licenses/          Intel Apache-2.0 header text\n"
        "\n"
        "  examples/            Sample Technical PRD for testing\n"
        "  docs/                PRDs, reports, presentations\n"
        "  CLAUDE.md            Root instructions for Claude Code\n"
        "  README.md            User-facing documentation\n"
        "  Makefile + Taskfile  Build automation\n"
        "  requirements.txt     Pipeline dependencies"
    )
    _tb(s, M_LEFT, Inches(0.9), CONTENT_W, Inches(5.6),
        tree, sz=11, color=BODY, font="Consolas")

    # ── Slide 14: Technology Summary ──
    s = _content_slide(prs, "Technology Summary")

    _make_table(s, [
        ("Layer", "Technology", "Role"),
        ("AI Engine", "Claude Code (Opus 4.6)", "Agentic coding \u2014 plans, generates, validates, iterates"),
        ("Skill System", "SKILL.md (YAML frontmatter)", "Multi-phase AI workflows with progressive disclosure"),
        ("Auto-Enforcement", "Hooks (Python via settings.json)", "PreToolUse / PostToolUse interception on every action"),
        ("Backend", "FastAPI + SQLAlchemy 2.0 + Pydantic v2", "Async API with nested config, structlog, Prometheus"),
        ("Frontend", "React 18 + TypeScript + Vite + Zustand", "Feature-based architecture (Bulletproof React pattern)"),
        ("Containers", "Docker multi-stage (python:3.11-slim)", "Non-root uid=1000, HEALTHCHECK, venv isolation"),
        ("Orchestration", "Helm 3 + Kubernetes 1.28+", "200+ params, zero-trust NetworkPolicy, HPA, PDB, ServiceMonitor"),
        ("CI/CD", "GitHub Actions + Super-Linter v6.8.0", "SDLE scans, SLSA release, CodeQL, Dependabot"),
        ("IaC", "Ansible (3-tier roles, 6 playbooks)", "Setup, infrastructure, application, validate, backup, pre-upgrade"),
        ("Observability", "structlog + Prometheus + OpenTelemetry", "JSON logs, metrics, distributed traces, 4 health endpoints"),
        ("Compliance", "Trivy + Bandit + cosign + CycloneDX", "SBOM, container signing, SLSA provenance, OSPDT deck"),
        ("Integrations", "curl subprocess (F5 BigIP bypass)", "Jira REST API, Confluence REST API, GitHub via git CLI"),
    ], y=Inches(0.95), col_widths=[Inches(2.0), Inches(3.8), Inches(6.033)], font_sz=10)

    # ── Slide 15: What's Next ──
    s = _slide(prs)
    _bg(s, INTEL_DARK)
    _rect(s, Inches(0), Inches(0), SLIDE_W, Inches(0.06), INTEL_CYAN)
    _tb(s, Inches(1.5), Inches(1.0), Inches(10.333), Inches(0.8),
        "What\u2019s Next", sz=32, bold=True, color=WHITE, align=PP_ALIGN.CENTER)
    _rect(s, Inches(5), Inches(1.85), Inches(3.333), Inches(0.04), INTEL_CYAN)
    tf = _tb(s, Inches(1.5), Inches(2.2), Inches(10.333), Inches(4.5),
             "", sz=15, color=WHITE)
    _bullets(tf, [
        "Phase 1 (Complete): Foundation \u2014 149 files, all templates, all 4 skills",
        "Phase 2: Battle-test with real projects (Document Q&A, Dataset Maker)",
        "Phase 3: Refine standards with real-world feedback from 5+ developers",
        "Phase 4: Add MCP integrations (Jira MCP, Confluence MCP, GitHub MCP)",
        "Phase 5: Add more template variants (worker services, ML pipelines, MCP tools)",
        "Phase 6: Measure \u2014 Did 1 developer actually produce 10x output?",
        "",
        "The standards are a living document. They need YOUR expertise to improve.",
        "The templates are a starting point. Real projects will reveal gaps.",
        "The goal: Every Intel AI project starts from this pipeline.",
    ], sz=14, color=RGBColor(210, 225, 250))
    _logo(s, x=Inches(5.8), y=Inches(6.5), w=LOGO_SECTION_W)
    _rect(s, Inches(0), Inches(7.3), SLIDE_W, Inches(0.2), INTEL_BLUE)

    Path(output_path).parent.mkdir(parents=True, exist_ok=True)
    prs.save(output_path)
    print(f"Technical Landscape PPT saved: {output_path}")


# ═══════════════════════════════════════════════════════════════════════════════
#  PPT 2: DEVELOPER WORKSHOP
# ═══════════════════════════════════════════════════════════════════════════════

def generate_workshop(output_path: str):
    prs = _new_prs()
    FT = "Developer Workshop"

    # ── Slide 1: Title ──
    s = _slide(prs, reset=True)
    _title_slide_layout(
        s,
        "Developer Workshop",
        "Intel AI Solutions Development Pipeline",
        "From PRD to Production in Minutes, Not Weeks",
        "Hands-On Session  |  DCAI Software Engineering  |  2025",
    )

    # ── Slide 2: Agenda ──
    s = _content_slide(prs, "Agenda", FT)
    tf = _tb(s, M_LEFT, Inches(0.9), CONTENT_W, Inches(5.6), "", sz=14)
    _bullets(tf, [
        "1.   What Problem This Solves (5 min)",
        "2.   Setup & Prerequisites (5 min)",
        "3.   The Pipeline: Which Skill to Use When (5 min)",
        "4.   Demo: /prd-agent \u2014 Creating a PRD (10 min)",
        "5.   Demo: /dev-agent \u2014 Generating a Project (15 min)",
        "6.   Demo: /validation-agent \u2014 Generating Tests (10 min)",
        "7.   Demo: /compliance-agent \u2014 Security & OSPDT (10 min)",
        "8.   Quick Commands: /scan, /test, /lint, /status (5 min)",
        "9.   Understanding the Standards (10 min)",
        "10.  How to Extend & Contribute (5 min)",
        "11.  Current Limitations & Where We Need Help (5 min)",
        "12.  Hands-On Exercise (15 min)",
        "13.  Q&A (10 min)",
    ], sz=14)

    # ── Slide 3: Setup ──
    s = _content_slide(prs, "Setup & Prerequisites", FT)
    _two_col(s,
        "Prerequisites", [
            "Python 3.11+ installed",
            "Claude Code CLI installed (claude)",
            "Git configured with SSH or PAT",
            "Docker Desktop (optional, for container testing)",
            "Helm 3 + kubectl (optional, for K8s testing)",
            "Node.js 20+ (optional, for frontend development)",
        ],
        "Setup Steps", [
            "Step 1: Clone the repo",
            "  git clone <repo-url>",
            "  cd intel-ai-solutions-dev",
            "",
            "Step 2: Install dependencies",
            "  pip install -r requirements.txt",
            "",
            "Step 3: Open Claude Code",
            "  claude",
            "",
            "Step 4: You're ready!",
            "  Type /prd-agent or /dev-agent to begin",
        ],
    )

    # ── Slide 4: Which Skill When ──
    s = _content_slide(prs, "Which Skill Should I Use?", FT)

    _make_table(s, [
        ("I am a...", "I want to...", "Use this skill"),
        ("PM / Product Owner", "Create a PRD from an idea", "/prd-agent (Mode A: Interactive Q&A)"),
        ("PM with meeting notes", "Extract PRD from transcript", "/prd-agent (Mode B: Transcript)"),
        ("Developer with a PRD", "Generate production-ready code", "/dev-agent"),
        ("QE / Developer", "Generate tests for an existing project", "/validation-agent"),
        ("Release Engineer", "Run compliance scans + generate OSPDT", "/compliance-agent"),
        ("Any developer", "Quick security scan", "/scan"),
        ("Any developer", "Run tests with coverage report", "/test"),
        ("Any developer", "Check overall project compliance status", "/status"),
    ], y=Inches(0.95), col_widths=[Inches(3.0), Inches(4.2), Inches(4.633)], font_sz=11)

    # ── Slide 5: Demo /prd-agent ──
    s = _content_slide(prs, "Demo: /prd-agent \u2014 Creating a PRD", FT)
    _two_col(s,
        "What It Does", [
            "Walks you through 15 question areas using Socratic method",
            "Asks ONE question at a time (MCQ with 'Other' option)",
            "Covers: Vision, Scope, Tech Approach, Security, Deployment, ...",
            "Generates PRD + Feature Breakdown (Epics/Stories/Tasks)",
            "Optional: Technical PRD for /dev-agent consumption",
            "",
            "Takes 25-35 minutes for full PRD",
            "Or upload a meeting transcript (Mode B)",
        ],
        "After Generation", [
            "Files created:",
            "  docs/prd/{slug}.md",
            "  docs/prd/{slug}-breakdown.md",
            "  docs/prd/{slug}-technical.md",
            "",
            "Optional integrations:",
            "  \u2192 Publish PRD to Confluence Wiki",
            "  \u2192 Export EPICs/Stories to Jira (dry-run first)",
            "",
            "Handoff metadata block at bottom of PRD",
            "  (dev-agent reads this automatically)",
        ],
    )

    # ── Slide 6: Demo /dev-agent ──
    s = _content_slide(prs, "Demo: /dev-agent \u2014 Generating a Project", FT)
    _tb(s, M_LEFT, Inches(0.85), CONTENT_W, Inches(0.4),
        "The 10x multiplier. Reads Technical PRD \u2192 Generates complete production project.",
        sz=14, bold=True, color=INTEL_BLUE)
    _two_col(s,
        "What Gets Generated", [
            "Backend: FastAPI + SQLAlchemy + structlog + Prometheus + Keycloak JWT",
            "Frontend: React 18 + TypeScript + Vite + Zustand + TanStack Query",
            "Docker: Multi-stage build (slim, non-root, health check)",
            "Helm: 200+ params, zero-trust NetworkPolicy, HPA, PDB, 3 probes",
            "CI/CD: Super-Linter, SDLE scans, SLSA release, CodeQL, Dependabot",
            "Ansible: 6 playbooks, 3-tier roles, multi-env inventory",
            "CNCF: LICENSE, CODE_OF_CONDUCT, SECURITY, CONTRIBUTING",
            "Pre-commit: Intel license headers, detect-secrets, ruff, black",
        ],
        "How It Works", [
            "1. You point to a Technical PRD (or use sample PRD)",
            "2. Dev-agent parses the handoff metadata block",
            "3. Shows a numbered file list for your confirmation",
            "4. YOU CONFIRM before any file is created",
            "5. Reads templates from templates/project-scaffold/",
            "6. Applies variable substitution from PRD metadata",
            "7. Generates PRD-specific code (endpoints, models, services)",
            "8. Runs validation (syntax, lint, docker build, helm lint)",
            "",
            "Try it now: /dev-agent \u2192 examples/sample-prd/",
        ],
        y=Inches(1.4),
    )

    # ── Slide 7: Demo /validation-agent ──
    s = _content_slide(prs, "Demo: /validation-agent \u2014 Test Generation & QA", FT)
    _two_col(s,
        "What It Generates", [
            "Unit tests: Per-resource, parametrized, edge cases",
            "Integration tests: Full API with TestClient + auth flows",
            "Security tests: Injection, XSS, auth bypass attempts",
            "Performance stubs: pytest-benchmark / Locust scripts",
            "",
            "Test structure per component:",
            "  tests/unit/test_*.py",
            "  tests/integration/test_api.py",
            "  tests/security/test_injection.py",
            "  conftest.py (shared fixtures)",
        ],
        "How It Works", [
            "1. Discovers project components (src/*/)",
            "2. Reads PRD acceptance criteria",
            "3. Maps each criterion to a test case",
            "4. Generates test files following patterns",
            "5. Runs: tox (or pytest --cov)",
            "6. Reports: coverage %, pass/fail, gaps",
            "",
            "Target: 85% line coverage minimum",
            "CI fails if coverage drops below threshold",
            "",
            "Publishes report to Wiki + updates Jira tickets",
        ],
    )

    # ── Slide 8: Demo /compliance-agent ──
    s = _content_slide(prs, "Demo: /compliance-agent \u2014 Security & OSPDT", FT)
    _two_col(s,
        "Security Scans", [
            "Bandit: Python SAST (skip B101, exclude tests)",
            "Trivy: Filesystem + container image scanning",
            "ShellCheck: Shell script analysis",
            "detect-secrets: Find leaked credentials",
            "pip-audit / npm audit: Dependency CVEs",
            "pip-licenses: License inventory + compatibility check",
            "",
            "Auto-fix (safe only):",
            "  Minor/patch dep upgrades for known CVEs",
            "  Bandit/ruff safe auto-fixes",
            "  ALL fixes presented for YOUR confirmation",
        ],
        "Compliance Artifacts", [
            "OSPDT PowerPoint deck (Intel branded):",
            "  Title, Overview, License Inventory (color-coded),",
            "  Security Assessment, Risk + Recommendations",
            "",
            "SDLE Diagrams (Mermaid):",
            "  Threat model, Data flow, Component architecture,",
            "  Deployment topology, API sequence diagrams",
            "",
            "SBOM: CycloneDX JSON (via Trivy)",
            "SLSA: Build provenance verification",
            "OpenSSF: Scorecard estimate (target 8+/10)",
        ],
    )

    # ── Slide 9: Quick Commands ──
    s = _content_slide(prs, "Quick Commands \u2014 One Slash, Done", FT)

    _make_table(s, [
        ("Command", "What It Does", "When to Use"),
        ("/scan", "Bandit + Trivy + detect-secrets + ShellCheck", "Before any PR, or anytime"),
        ("/test", "pytest --cov per component (or tox)", "After writing code"),
        ("/lint", "ruff + mypy --strict + hadolint + prettier", "Before committing"),
        ("/deploy [env]", "Docker Compose (dev) or Helm (staging/prod)", "When ready to deploy"),
        ("/status", "Compliance dashboard (CNCF files, CI pipelines, scan results)", "To check project health"),
        ("/wiki-publish [file]", "Publish markdown to Confluence wiki", "After generating reports"),
        ("/jira-update [project]", "Update Jira tickets with current status", "After milestones"),
    ], y=Inches(0.95), col_widths=[Inches(2.5), Inches(5.2), Inches(4.133)], font_sz=11)

    # ── Slide 10: Understanding Standards ──
    s = _content_slide(prs, "Understanding the Standards \u2014 Source of Truth", FT)
    _tb(s, M_LEFT, Inches(0.85), CONTENT_W, Inches(0.4),
        "13 standards files in .claude/shared/standards/ \u2014 every skill reads these before generating code.",
        sz=13, bold=True, color=INTEL_BLUE)

    _make_table(s, [
        ("Standard File", "What It Defines"),
        ("coding-standards.md", "PEP 621, Hatchling, strict mypy, ruff, async patterns, type hints"),
        ("security-practices.md", "Keycloak JWT, SLSA, cosign, zero-trust, container security, secrets mgmt"),
        ("testing-standards.md", "pytest + tox per-component, 85% coverage, parametrize, security tests"),
        ("performance-optimization.md", "IPEX, OpenVINO, vLLM, LiteLLM, AMX/VNNI, dynamic batching"),
        ("tech-stack.md", "Approved/Prohibited libraries (FastAPI yes, Flask no; httpx yes, requests no)"),
        ("project-structure.md", "src/{component}/app/ layout, naming conventions, feature-based frontend"),
        ("ci-cd-standards.md", "Super-Linter v6.8.0, SDLE code-scans, SLSA release, per-component tests"),
        ("ux-design-system.md", "Bulletproof React, shadcn/ui, Zustand + TanStack, Intel brand (#003580)"),
        ("validation-checklist.md", "Complete checklist: code quality, security, container, Helm, CNCF, SLSA"),
        ("helm-standards.md", "200+ params, zero-trust NetworkPolicy, HPA stabilization, PDB, 3 probes"),
        ("container-standards.md", "Multi-stage, slim+curl runtime, uid=1000, HEALTHCHECK, no secrets in layers"),
        ("observability-standards.md", "structlog + Prometheus + OTEL, middleware stack, correlation IDs, per-user metrics"),
        ("opensource-compliance.md", "CNCF files, OpenSSF criteria, SLSA levels, license compatibility matrix, OSPDT"),
    ], y=Inches(1.35), col_widths=[Inches(3.5), Inches(8.333)], font_sz=9)

    # ── Slide 11: Limitations & Where We Need Help ──
    s = _content_slide(prs, "Current Limitations & Where We Need Your Expertise", FT)
    _tb(s, M_LEFT, Inches(0.85), CONTENT_W, Inches(0.4),
        "This is V1. The foundation is solid, but it needs real-world battle-testing to mature.",
        sz=14, bold=True, color=INTEL_BLUE)
    _two_col(s,
        "What Needs Improvement", [
            "Standards are a starting point: Sourced from Enterprise-Inference + Enterprise-RAG, but haven't been tested across all project types",
            "Templates may not cover every edge case: Agentic AI projects vary (RAG, fine-tuning, multi-agent, MCP tools)",
            "Helm values need tuning per project: Resource limits, scaling thresholds, egress rules",
            "Ansible roles are skeletal: Need real deployment experience to fill in",
            "Frontend templates are basic: Need more feature patterns and Intel brand components",
            "MCP integrations not yet wired: Jira/Confluence use scripts, not native MCP servers",
        ],
        "How You Can Help", [
            "USE IT on your next project: Real usage reveals real gaps",
            "File issues: When a template doesn't match your project needs",
            "Improve standards: You know your domain better than any template",
            "Add template variants: Worker services, ML pipelines, MCP servers",
            "Share patterns: If you build something reusable, contribute it back",
            "Test the pipeline end-to-end: PRD \u2192 code \u2192 tests \u2192 compliance",
            "",
            "The standards are a LIVING DOCUMENT.",
            "Your hands-on expertise makes them better.",
        ],
        y=Inches(1.4),
    )

    # ── Slide 12: How This Helps Daily Work ──
    s = _content_slide(prs, "How This Helps Your Daily Product Development", FT)
    tf = _tb(s, M_LEFT, Inches(0.9), CONTENT_W, Inches(5.5), "", sz=13)
    _bullets(tf, [
        "Day 1 of a new project: /prd-agent creates your PRD in 30 minutes, not 3 days of meetings and Google Docs",
        "",
        "Day 2: /dev-agent scaffolds the entire project \u2014 FastAPI, React, Helm, CI/CD, Docker, Ansible \u2014 in 15 minutes",
        "    \u2192 You start writing BUSINESS LOGIC on day 2, not configuring pyproject.toml and Dockerfiles",
        "",
        "Week 1: /validation-agent generates 85%+ test coverage from your PRD acceptance criteria",
        "    \u2192 Tests exist BEFORE your first PR, not as a 'we'll add tests later' promise",
        "",
        "Before release: /compliance-agent produces OSPDT deck, SDLE diagrams, SBOM in minutes",
        "    \u2192 Compliance is a 30-minute step, not a 2-week bottleneck",
        "",
        "Every day: /scan, /test, /lint give you instant feedback without remembering tool flags",
        "",
        "Every commit: Hooks auto-check for secrets, missing license headers, dangerous commands",
        "    \u2192 Security is automatic, not a checklist you forget to follow",
        "",
        "Net effect: You spend 90% of time on what matters (business logic, AI/ML, user experience)",
        "instead of 60% on infrastructure, boilerplate, compliance paperwork, and config files.",
    ], sz=12)

    # ── Slide 13: Template System ──
    s = _content_slide(prs, "How Templates Work \u2014 Extending & Customizing", FT)
    _two_col(s,
        "Template Mechanics", [
            "Location: templates/project-scaffold/",
            "Format: Regular files with {{variable}} placeholders",
            "Static files: Copied as-is (.gitignore, LICENSE, etc.)",
            "Template files (.tmpl): Variable substitution applied",
            "",
            "Example from main.py.tmpl:",
            '  app = FastAPI(title="{{project_name}}")',
            "  \u2192 becomes \u2192",
            '  app = FastAPI(title="Doc QA Assistant")',
            "",
            "Variables come from PRD handoff metadata block",
        ],
        "How to Customize", [
            "To modify a standard pattern:",
            "  1. Edit the template in templates/project-scaffold/",
            "  2. All future projects get the update automatically",
            "",
            "To add a new template type:",
            "  1. Create .tmpl file with {{variables}}",
            "  2. Add to dev-agent SKILL.md generation list",
            "",
            "To add a new standard:",
            "  1. Create .md in .claude/shared/standards/",
            "  2. Reference from relevant SKILL.md files",
            "",
            "To add a new command:",
            "  1. Create .md in .claude/commands/",
            "  2. Add YAML frontmatter (tools, description)",
        ],
    )

    # ── Slide 14: Integration Setup ──
    s = _content_slide(prs, "Setting Up Integrations (Optional)", FT)
    _two_col(s,
        "Jira Integration", [
            "Set environment variables:",
            "  export JIRA_BASE_URL=https://jira.example.com",
            "  export JIRA_PAT=your-personal-access-token",
            "",
            "How to get a PAT:",
            "  Jira \u2192 Profile \u2192 Personal Access Tokens",
            "",
            "Usage:",
            "  /prd-agent \u2192 exports EPICs/Stories automatically",
            "  /jira-update \u2192 comments on tickets with status",
            "",
            "Dry-run always available (\u2011\u2011dry-run flag)",
        ],
        "Confluence Integration", [
            "Set environment variables:",
            "  export WIKI_BASE_URL=https://wiki.example.com",
            "  export WIKI_PAT=your-personal-access-token",
            "",
            "How to get a PAT:",
            "  Confluence \u2192 Profile \u2192 Personal Access Tokens",
            "",
            "Usage:",
            "  /wiki-publish docs/prd/my-project.md",
            "  /prd-agent \u2192 auto-publishes after generation",
            "  /compliance-agent \u2192 publishes compliance reports",
            "",
            "Note: Uses curl subprocess to bypass Intel F5 BigIP",
        ],
    )

    # ── Slide 15: Hands-On Exercise ──
    s = _content_slide(prs, "Hands-On Exercise (15 min)", FT)
    _tb(s, M_LEFT, Inches(0.85), CONTENT_W, Inches(0.4),
        "Try it yourself! Generate a project from the sample PRD.",
        sz=14, bold=True, color=INTEL_BLUE)
    tf = _tb(s, M_LEFT, Inches(1.4), CONTENT_W, Inches(5.0), "", sz=13)
    _bullets(tf, [
        "Step 1: Open a terminal in intel-ai-solutions-dev/",
        "",
        "Step 2: Start Claude Code",
        "  $ claude",
        "",
        "Step 3: Run the dev agent",
        "  > /dev-agent",
        "  > Point to: examples/sample-prd/sample-technical-prd.md",
        "  > Review the generation plan, then confirm 'yes'",
        "",
        "Step 4: Explore the generated project",
        "  > /status     (check compliance dashboard)",
        "  > /scan       (run security scan)",
        "  > /test       (run tests \u2014 may need deps installed first)",
        "",
        "Step 5: Try /prd-agent with your own project idea",
        "",
        "Bonus: Look at the generated Helm values.yaml \u2014 count the parameters!",
    ], sz=13)

    # ── Slide 16: Next Steps ──
    s = _slide(prs)
    _bg(s, INTEL_DARK)
    _rect(s, Inches(0), Inches(0), SLIDE_W, Inches(0.06), INTEL_CYAN)
    _tb(s, Inches(1.5), Inches(0.9), Inches(10.333), Inches(0.8),
        "Next Steps", sz=32, bold=True, color=WHITE, align=PP_ALIGN.CENTER)
    _rect(s, Inches(5), Inches(1.75), Inches(3.333), Inches(0.04), INTEL_CYAN)
    tf = _tb(s, Inches(1.5), Inches(2.1), Inches(10.333), Inches(4.5),
             "", sz=14, color=WHITE)
    _bullets(tf, [
        "1. Clone the repo and run pip install -r requirements.txt",
        "2. Try /dev-agent with the sample PRD today",
        "3. Next week: Try /prd-agent with YOUR actual project",
        "4. File issues when templates don't fit your use case",
        "5. Propose standard improvements in PRs",
        "6. Share your experience with the team",
        "",
        "Remember: The standards are intentionally imperfect.",
        "They need your domain expertise to become great.",
        "Every improvement you make benefits the entire team.",
        "",
        "Contact: Vivek RS (DCAI Software Engineering)",
        "Repo: intel-ai-solutions-dev",
    ], sz=14, color=RGBColor(210, 225, 250))
    _logo(s, x=Inches(5.8), y=Inches(6.5), w=LOGO_SECTION_W)
    _rect(s, Inches(0), Inches(7.3), SLIDE_W, Inches(0.2), INTEL_BLUE)

    # ── Slide 17: Thank You ──
    s = _slide(prs)
    _closing_slide(s,
        "Thank You",
        "Questions?",
        "1 developer + Claude Code = 10 developers\u2019 output",
    )

    Path(output_path).parent.mkdir(parents=True, exist_ok=True)
    prs.save(output_path)
    print(f"Developer Workshop PPT saved: {output_path}")


# ═══════════════════════════════════════════════════════════════════════════════
#  MAIN
# ═══════════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    out = "docs/presentations"
    generate_tech_landscape(f"{out}/Intel_AI_Solutions_Dev_Technical_Landscape.pptx")
    generate_workshop(f"{out}/Intel_AI_Solutions_Dev_Developer_Workshop.pptx")
    print("\nBoth presentations generated!")
