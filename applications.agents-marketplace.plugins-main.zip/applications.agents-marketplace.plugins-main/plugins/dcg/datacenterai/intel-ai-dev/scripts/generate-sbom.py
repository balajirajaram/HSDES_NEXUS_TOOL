#!/usr/bin/env python3
# Copyright (C) 2024 Intel Corporation
# SPDX-License-Identifier: Apache-2.0
"""Generate SBOM (Software Bill of Materials) in CycloneDX format."""

import argparse
import json
import subprocess
import sys
from pathlib import Path


def run_trivy_sbom(target: str, output_path: str, scan_type: str = "fs") -> bool:
    cmd = ["trivy", scan_type, "--format", "cyclonedx", "--output", output_path, target]
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=300)
        if result.returncode == 0:
            return True
        print(f"Trivy warning: {result.stderr[:200]}")
        return result.returncode == 0
    except FileNotFoundError:
        print("Trivy not installed. Install: https://trivy.dev")
        return False
    except subprocess.TimeoutExpired:
        print("Trivy timed out after 5 minutes")
        return False


def generate_pip_sbom(project_dir: str, output_path: str) -> bool:
    try:
        result = subprocess.run(
            ["pip", "list", "--format", "json"],
            capture_output=True, text=True, timeout=60,
        )
        if result.returncode != 0:
            return False

        packages = json.loads(result.stdout)
        sbom = {
            "bomFormat": "CycloneDX",
            "specVersion": "1.5",
            "version": 1,
            "components": [
                {
                    "type": "library",
                    "name": pkg["name"],
                    "version": pkg["version"],
                    "purl": f"pkg:pypi/{pkg['name']}@{pkg['version']}",
                }
                for pkg in packages
            ],
        }
        Path(output_path).write_text(json.dumps(sbom, indent=2), encoding="utf-8")
        return True
    except Exception as e:
        print(f"Fallback SBOM generation failed: {e}")
        return False


def main():
    parser = argparse.ArgumentParser(description="Generate SBOM")
    parser.add_argument("--project-dir", default=".", help="Project directory")
    parser.add_argument("--format", default="cyclonedx", choices=["cyclonedx"],
                        help="SBOM format")
    parser.add_argument("--output", help="Output file path")
    parser.add_argument("--image", help="Container image to scan (optional)")
    args = parser.parse_args()

    slug = Path(args.project_dir).resolve().name
    output_path = args.output or f"docs/reports/sbom-{slug}.json"
    Path(output_path).parent.mkdir(parents=True, exist_ok=True)

    success = run_trivy_sbom(args.project_dir, output_path, "fs")

    if not success:
        print("Falling back to pip-based SBOM generation...")
        success = generate_pip_sbom(args.project_dir, output_path)

    if success:
        size = Path(output_path).stat().st_size
        print(f"SBOM generated: {output_path} ({size} bytes)")
    else:
        print("Failed to generate SBOM. Install trivy or check pip installation.")
        sys.exit(1)

    if args.image:
        image_output = output_path.replace(".json", "-image.json")
        if run_trivy_sbom(args.image, image_output, "image"):
            print(f"Image SBOM generated: {image_output}")


if __name__ == "__main__":
    main()
