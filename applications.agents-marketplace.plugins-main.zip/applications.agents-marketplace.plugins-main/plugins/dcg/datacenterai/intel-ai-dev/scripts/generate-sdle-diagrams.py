#!/usr/bin/env python3
# Copyright (C) 2024 Intel Corporation
# SPDX-License-Identifier: Apache-2.0
"""Generate SDLE diagrams (Mermaid) from project structure."""

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from lib.diagram_generator import (
    generate_component_architecture,
    generate_data_flow,
    generate_deployment_diagram,
    generate_threat_model,
)


def discover_components(project_dir: str) -> list[str]:
    src_dir = Path(project_dir) / "src"
    components = []
    if src_dir.exists():
        for d in src_dir.iterdir():
            if d.is_dir() and (d / "app" / "main.py").exists():
                components.append(d.name)
    return components


def main():
    parser = argparse.ArgumentParser(description="Generate SDLE Mermaid diagrams")
    parser.add_argument("--project-dir", default=".", help="Project root directory")
    parser.add_argument("--output-dir", default="docs/architecture/diagrams",
                        help="Output directory for diagrams")
    parser.add_argument("--project-name", default="Project", help="Project name for titles")
    args = parser.parse_args()

    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    components = discover_components(args.project_dir)
    has_frontend = (Path(args.project_dir) / "frontend" / "package.json").exists()
    has_helm = bool(list(Path(args.project_dir).glob("helm/*/Chart.yaml")))

    print(f"Discovered: {len(components)} backend components, "
          f"frontend={'yes' if has_frontend else 'no'}, "
          f"helm={'yes' if has_helm else 'no'}")

    generate_threat_model(
        project_name=args.project_name,
        components=components,
        output_path=str(output_dir / "threat-model.md"),
    )
    print(f"  Generated: {output_dir}/threat-model.md")

    generate_data_flow(
        project_name=args.project_name,
        components=components,
        output_path=str(output_dir / "data-flow.md"),
    )
    print(f"  Generated: {output_dir}/data-flow.md")

    generate_component_architecture(
        project_name=args.project_name,
        components=components,
        has_frontend=has_frontend,
        output_path=str(output_dir / "component-architecture.md"),
    )
    print(f"  Generated: {output_dir}/component-architecture.md")

    generate_deployment_diagram(
        project_name=args.project_name,
        components=components,
        has_frontend=has_frontend,
        output_path=str(output_dir / "deployment-architecture.md"),
    )
    print(f"  Generated: {output_dir}/deployment-architecture.md")

    print(f"\nDone: 4 SDLE diagrams in {output_dir}/")


if __name__ == "__main__":
    main()
