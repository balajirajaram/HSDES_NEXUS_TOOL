#!/usr/bin/env python3
# Copyright (C) 2026 Intel Corporation
# SPDX-License-Identifier: Apache-2.0
"""Generate animated video presentation for Intel AI Solutions Development Pipeline.

Uses moviepy + Pillow to create a professional animated explainer video
with narration text, transitions, and diagrams.

Output: docs/presentations/Intel_AI_Solutions_Dev_Pipeline.mp4
"""

from __future__ import annotations

import math
import os
import textwrap
from pathlib import Path

import numpy as np
from moviepy import (
    ColorClip,
    CompositeVideoClip,
    ImageClip,
    TextClip,
    concatenate_videoclips,
    vfx,
)
from PIL import Image, ImageDraw, ImageFont

# --- Configuration ---
WIDTH, HEIGHT = 1920, 1080
FPS = 30
INTEL_BLUE = (0, 53, 128)
INTEL_LIGHT_BLUE = (0, 113, 197)
INTEL_ACCENT = (0, 168, 225)
WHITE = (255, 255, 255)
LIGHT_GRAY = (240, 243, 247)
DARK_GRAY = (45, 55, 72)
GREEN = (56, 161, 105)
ORANGE = (221, 107, 32)
RED = (197, 48, 48)

OUTPUT_DIR = Path(__file__).parent.parent / "docs" / "presentations"
OUTPUT_FILE = OUTPUT_DIR / "Intel_AI_Solutions_Dev_Pipeline.mp4"


def get_font(size: int, bold: bool = False) -> ImageFont.FreeTypeFont:
    """Get a font, falling back to default if system fonts unavailable."""
    font_names = [
        "calibri.ttf", "calibrib.ttf",
        "arial.ttf", "arialbd.ttf",
        "C:/Windows/Fonts/calibri.ttf",
        "C:/Windows/Fonts/calibrib.ttf",
        "C:/Windows/Fonts/arial.ttf",
        "C:/Windows/Fonts/arialbd.ttf",
    ]
    if bold:
        font_names = [f for f in font_names if "b." in f or "bd." in f or "Bold" in f] + font_names

    for name in font_names:
        try:
            return ImageFont.truetype(name, size)
        except (OSError, IOError):
            continue
    return ImageFont.load_default()


def create_frame(
    title: str = "",
    subtitle: str = "",
    body_lines: list[str] | None = None,
    diagram: Image.Image | None = None,
    bg_color: tuple = INTEL_BLUE,
    title_color: tuple = WHITE,
    body_color: tuple = WHITE,
    narration: str = "",
    show_narration: bool = True,
    section_label: str = "",
) -> Image.Image:
    """Create a single presentation frame as PIL Image."""
    img = Image.new("RGB", (WIDTH, HEIGHT), bg_color)
    draw = ImageDraw.Draw(img)

    # Intel brand bar at top
    draw.rectangle([(0, 0), (WIDTH, 6)], fill=INTEL_ACCENT)

    # Section label (top-right)
    if section_label:
        font_section = get_font(20)
        draw.text((WIDTH - 300, 20), section_label, fill=(*INTEL_ACCENT, 180), font=font_section)

    y_offset = 80

    # Title
    if title:
        font_title = get_font(52, bold=True)
        # Wrap title if too long
        wrapped = textwrap.wrap(title, width=45)
        for line in wrapped:
            draw.text((100, y_offset), line, fill=title_color, font=font_title)
            y_offset += 65
        y_offset += 20

    # Subtitle
    if subtitle:
        font_sub = get_font(30)
        draw.text((100, y_offset), subtitle, fill=(*title_color[:3],), font=font_sub)
        y_offset += 60

    # Body lines
    if body_lines:
        font_body = get_font(26)
        for line in body_lines:
            if line.startswith("##"):
                # Section header
                font_h = get_font(32, bold=True)
                draw.text((100, y_offset), line[2:].strip(), fill=INTEL_ACCENT, font=font_h)
                y_offset += 50
            elif line.startswith("->"):
                # Arrow/highlight item
                draw.text((120, y_offset), f"→  {line[2:].strip()}", fill=GREEN, font=font_body)
                y_offset += 40
            elif line.startswith("!"):
                # Warning/emphasis
                draw.text((120, y_offset), f"⚠  {line[1:].strip()}", fill=ORANGE, font=font_body)
                y_offset += 40
            elif line.startswith("*"):
                # Bullet
                draw.text((120, y_offset), f"•  {line[1:].strip()}", fill=body_color, font=font_body)
                y_offset += 40
            elif line == "---":
                # Separator
                draw.line([(100, y_offset + 10), (WIDTH - 100, y_offset + 10)],
                          fill=(*INTEL_ACCENT, 100), width=1)
                y_offset += 30
            elif line == "":
                y_offset += 20
            else:
                draw.text((100, y_offset), line, fill=body_color, font=font_body)
                y_offset += 40

    # Diagram overlay
    if diagram:
        # Place diagram in center-right area
        dw, dh = diagram.size
        dx = WIDTH - dw - 80
        dy = max(200, (HEIGHT - dh) // 2)
        img.paste(diagram, (dx, dy), diagram if diagram.mode == "RGBA" else None)

    # Narration bar at bottom
    if show_narration and narration:
        # Semi-transparent dark bar
        bar_height = 100
        bar_y = HEIGHT - bar_height
        overlay = Image.new("RGBA", (WIDTH, bar_height), (0, 0, 0, 200))
        img_rgba = img.convert("RGBA")
        img_rgba.paste(overlay, (0, bar_y), overlay)
        img = img_rgba.convert("RGB")
        draw = ImageDraw.Draw(img)

        font_narr = get_font(22)
        wrapped_narr = textwrap.wrap(narration, width=100)
        ny = bar_y + 15
        for line in wrapped_narr[:3]:
            draw.text((60, ny), line, fill=WHITE, font=font_narr)
            ny += 28

    # Intel logo text (bottom-left)
    font_logo = get_font(18)
    draw.text((40, HEIGHT - 30), "Intel AI Solutions Development Pipeline", fill=(*INTEL_ACCENT,), font=font_logo)

    return img


def create_diagram_pipeline() -> Image.Image:
    """Create the 4-phase pipeline diagram."""
    img = Image.new("RGBA", (800, 400), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)
    font = get_font(22, bold=True)
    font_sm = get_font(16)

    phases = [
        ("PRD Agent", "Requirements", INTEL_BLUE),
        ("Dev Agent", "Code Gen", INTEL_LIGHT_BLUE),
        ("Validation", "Testing", GREEN),
        ("Compliance", "Security", ORANGE),
    ]

    box_w, box_h = 160, 80
    gap = 40
    start_x = 20
    y = 160

    for i, (name, desc, color) in enumerate(phases):
        x = start_x + i * (box_w + gap)
        # Box with rounded corners (approximate with rectangle)
        draw.rounded_rectangle([(x, y), (x + box_w, y + box_h)], radius=10, fill=color)
        draw.text((x + 20, y + 15), name, fill=WHITE, font=font)
        draw.text((x + 20, y + 45), desc, fill=(*WHITE[:3], 200), font=font_sm)

        # Arrow
        if i < len(phases) - 1:
            ax = x + box_w + 5
            draw.polygon(
                [(ax, y + box_h // 2 - 8), (ax + 30, y + box_h // 2), (ax, y + box_h // 2 + 8)],
                fill=INTEL_ACCENT,
            )

    # Output label
    draw.text((start_x, y + box_h + 30), "Output: Production-Ready AI Solution + DASHBOARD",
              fill=WHITE, font=font_sm)

    return img


def create_diagram_architecture() -> Image.Image:
    """Create architecture diagram showing layers."""
    img = Image.new("RGBA", (750, 500), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)
    font = get_font(20, bold=True)
    font_sm = get_font(16)

    layers = [
        ("Frontend (React + TypeScript)", INTEL_ACCENT, 50),
        ("Backend API (FastAPI + Async)", INTEL_LIGHT_BLUE, 130),
        ("Inference Layer (EI / vLLM)", INTEL_BLUE, 210),
        ("Data Layer (PostgreSQL + Redis)", DARK_GRAY, 290),
        ("Infrastructure (K8s + Helm)", (80, 80, 80), 370),
    ]

    for name, color, y in layers:
        draw.rounded_rectangle([(30, y), (720, y + 65)], radius=8, fill=color)
        draw.text((50, y + 20), name, fill=WHITE, font=font)

    # Arrows between layers
    for i in range(len(layers) - 1):
        y1 = layers[i][2] + 65
        y2 = layers[i + 1][2]
        mid_x = 375
        draw.line([(mid_x, y1), (mid_x, y2)], fill=INTEL_ACCENT, width=2)

    return img


def create_diagram_standards() -> Image.Image:
    """Create standards matrix visual."""
    img = Image.new("RGBA", (700, 450), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)
    font = get_font(18)
    font_h = get_font(22, bold=True)

    draw.text((20, 10), "13 Enterprise Standards Enforced", fill=WHITE, font=font_h)

    standards = [
        "Coding Standards", "Security Practices", "Testing Standards",
        "Container Standards", "Helm Standards", "Observability",
        "CI/CD Standards", "Open Source Compliance", "Project Structure",
        "Tech Stack", "Performance", "UX Design", "Validation Checklist",
    ]

    cols = 3
    col_w = 220
    row_h = 35
    start_y = 60

    for i, std in enumerate(standards):
        col = i % cols
        row = i // cols
        x = 20 + col * col_w
        y = start_y + row * row_h
        draw.text((x, y), f"✓ {std}", fill=GREEN, font=font)

    return img


def make_slide_clip(frame: Image.Image, duration: float) -> ImageClip:
    """Convert PIL Image to moviepy clip with given duration."""
    arr = np.array(frame)
    return ImageClip(arr, duration=duration)


def add_fade(clip, fade_in: float = 0.5, fade_out: float = 0.5):
    """Add fade in/out to a clip."""
    return clip.with_effects([
    ]).fadein(fade_in).fadeout(fade_out)


def build_video():
    """Build the complete animated presentation video."""
    print("Generating Intel AI Solutions Dev Pipeline video...")
    print("=" * 60)

    slides = []

    # --- SCENE 1: Title (5s) ---
    print("[1/15] Title slide...")
    frame = create_frame(
        title="Intel AI Solutions Development",
        subtitle="One Developer + Claude Code = Production-Ready AI Projects",
        body_lines=[
            "",
            "",
            "Complete pipeline from idea to production-grade, compliant AI solutions",
            "",
            "Automated: Requirements → Code → Tests → Security → Deployment",
            "",
            "",
            "Data Center AI Solutions Engineering",
        ],
        narration="Welcome to Intel AI Solutions Development Pipeline — transforming how Intel developers build AI applications.",
        section_label="INTRODUCTION",
    )
    slides.append(make_slide_clip(frame, 6))

    # --- SCENE 2: The Problem (6s) ---
    print("[2/15] Problem statement...")
    frame = create_frame(
        title="The Problem We Solve",
        subtitle="Building production AI at Intel is slow and inconsistent",
        body_lines=[
            "",
            "## Current Pain Points",
            "*Every team reinvents: project structure, CI/CD, security, observability",
            "*Compliance takes weeks: OSPDT, SDLE, SBOM, license reviews",
            "*Knowledge loss: context evaporates between sessions and team changes",
            "*No standard patterns: 10 teams = 10 different approaches",
            "",
            "## The Cost",
            "!6-12 weeks to first deployment (should be days)",
            "!Security gaps discovered late in the cycle",
            "!Inconsistent quality across AI solutions",
        ],
        narration="Today, building a production AI solution at Intel takes 6-12 weeks. Teams reinvent infrastructure, compliance takes weeks, and there's no consistency.",
        section_label="PROBLEM",
    )
    slides.append(make_slide_clip(frame, 7))

    # --- SCENE 3: Our Approach (6s) ---
    print("[3/15] Our approach...")
    frame = create_frame(
        title="Our Approach: Structured Automation",
        subtitle="4 AI agents that encode Intel's best practices into code",
        body_lines=[
            "",
            "## Key Insight",
            "->Don't just generate code — encode 13 enterprise standards into every file",
            "->Don't just scaffold — produce compliance-ready artifacts automatically",
            "->Don't just build — ensure nothing is lost between sessions",
            "",
            "## Principles",
            "*Template-first: 133 enterprise templates (deterministic output)",
            "*Standards-driven: Every file passes ruff, mypy --strict, bandit",
            "*Human-in-the-loop: Developer approves every major decision",
            "*Session continuity: Never lose context, even across weeks",
        ],
        narration="Our approach encodes Intel's 13 enterprise standards into 133 templates. Four AI agents handle the heavy lifting while the developer stays in control.",
        section_label="APPROACH",
    )
    slides.append(make_slide_clip(frame, 7))

    # --- SCENE 4: Pipeline Overview (7s) ---
    print("[4/15] Pipeline overview with diagram...")
    diagram = create_diagram_pipeline()
    frame = create_frame(
        title="The 4-Phase Pipeline",
        subtitle="Each phase builds on the previous — clear handoffs, tracked state",
        body_lines=[
            "",
            "## Phase 1: /prd-agent",
            "*Socratic Q&A (15 areas, 4 stakeholder roles)",
            "*Outputs: PRD + Feature Breakdown + Technical PRD",
            "",
            "## Phase 2: /dev-agent",
            "*Reads Technical PRD → generates complete project",
            "*133 templates, variable substitution, PRD-specific code",
            "",
            "## Phase 3: /validation-agent",
            "*Maps PRD acceptance criteria → test cases",
            "",
            "## Phase 4: /compliance-agent",
            "*Security scans, OSPDT, SDLE, SBOM, DASHBOARD",
        ],
        narration="Four phases: PRD for requirements, Dev for code generation, Validation for testing, Compliance for security. Each has clear inputs and outputs.",
        section_label="PIPELINE",
    )
    slides.append(make_slide_clip(frame, 8))

    # --- SCENE 5: PRD Agent Deep Dive (6s) ---
    print("[5/15] PRD agent...")
    frame = create_frame(
        title="Phase 1: PRD Agent",
        subtitle="From idea to structured requirements in 25-35 minutes",
        body_lines=[
            "",
            "## Two Modes",
            "*Mode A: Interactive Socratic Q&A (one question at a time)",
            "*Mode B: Workshop transcript processing (team meetings)",
            "",
            "## 15 Question Areas (4 Stakeholder Roles)",
            "*Problem & Vision (PM) → Business Context → User Stories",
            "*Technical Approach (Architect) → Intel Optimizations → NFRs",
            "*Implementation (Developer) → Testing → Risks",
            "*Timeline (Eng Lead) → Deployment → Security → Scalability",
            "",
            "## Inference Strategy Decision (captured here)",
            "->Enterprise Inference (recommended) OR Direct vLLM",
            "->Auth mode: GenAI Gateway vs APISIX+Keycloak",
            "->Topology: Same cluster vs Remote",
        ],
        narration="The PRD Agent asks targeted questions across 15 areas. It captures the inference strategy decision that drives all downstream code generation.",
        section_label="PHASE 1",
    )
    slides.append(make_slide_clip(frame, 7))

    # --- SCENE 6: Dev Agent Deep Dive (7s) ---
    print("[6/15] Dev agent...")
    frame = create_frame(
        title="Phase 2: Dev Agent",
        subtitle="Technical PRD → Complete production project",
        body_lines=[
            "",
            "## What Gets Generated",
            "*Backend: FastAPI + async SQLAlchemy + Pydantic v2 + structlog",
            "*Frontend: React 18 + TypeScript strict + TanStack Query + Zustand",
            "*Infrastructure: Helm charts (zero-trust), Docker (multi-stage)",
            "*CI/CD: 5 GitHub Actions workflows (lint, test, scan, build, release)",
            "*Ansible: 3-tier deployment playbooks",
            "",
            "## Code Quality (Built-in)",
            "->PyJWT + Keycloak JWKS (not python-jose)",
            "->All functions typed, from __future__ import annotations",
            "->Correlation ID tracking, structured JSON logging",
            "->Rate limiting, security headers, health probes",
            "",
            "## Inference Client (strategy-driven)",
            "*EI mode: async httpx REST client → Enterprise Inference",
            "*vLLM mode: bundled deployment with full Helm subchart",
        ],
        narration="The Dev Agent generates a complete production project — backend, frontend, Helm, CI/CD, Ansible — all from the Technical PRD. Inference strategy drives the architecture.",
        section_label="PHASE 2",
    )
    slides.append(make_slide_clip(frame, 8))

    # --- SCENE 7: Architecture (6s) ---
    print("[7/15] Architecture diagram...")
    diagram = create_diagram_architecture()
    frame = create_frame(
        title="Generated Architecture",
        subtitle="Every layer follows Enterprise-RAG and Enterprise-Inference patterns",
        body_lines=[
            "",
            "*Frontend: Feature-based (Bulletproof React)",
            "*Backend: Component-based microservices",
            "*Inference: EI client or bundled vLLM",
            "*Data: Async PostgreSQL + Redis cache",
            "*Infra: Zero-trust K8s + Helm 3",
            "",
            "",
            "",
            "",
            "",
            "",
            "->Pattern source: OPEA Enterprise-Inference",
            "->Architecture source: OPEA Enterprise-RAG",
        ],
        narration="The architecture follows proven OPEA patterns — Enterprise-RAG for structure, Enterprise-Inference for AI serving. Every layer is production-hardened.",
        section_label="ARCHITECTURE",
    )
    slides.append(make_slide_clip(frame, 7))

    # --- SCENE 8: Validation Agent (6s) ---
    print("[8/15] Validation agent...")
    frame = create_frame(
        title="Phase 3: Validation Agent",
        subtitle="PRD acceptance criteria → comprehensive test suites",
        body_lines=[
            "",
            "## Test Generation",
            "*Unit tests: Schema validation, business logic (mocked DB)",
            "*Integration tests: Full API with TestClient + real app",
            "*Security tests: Input injection, auth bypass, SSTI attempts",
            "*E2E scenarios: User story flows end-to-end",
            "*Performance stubs: pytest-benchmark ready",
            "",
            "## Quality Gates",
            "->85% coverage minimum (enforced in pyproject.toml)",
            "->ruff + mypy --strict must pass",
            "->Every PRD acceptance criterion mapped to a test",
            "",
            "## Gap Analysis",
            "*Untested criteria flagged with reason and priority",
            "*Iteration 2 plan: what needs infra to test",
        ],
        narration="The Validation Agent maps every PRD acceptance criterion to a test case. It runs them, reports coverage, and flags gaps with clear remediation paths.",
        section_label="PHASE 3",
    )
    slides.append(make_slide_clip(frame, 7))

    # --- SCENE 9: Compliance Agent (6s) ---
    print("[9/15] Compliance agent...")
    frame = create_frame(
        title="Phase 4: Compliance Agent",
        subtitle="Security scans, OSPDT, SDLE diagrams, SBOM — automated",
        body_lines=[
            "",
            "## Security Scanning",
            "*SAST: Bandit (Python static analysis)",
            "*Dependencies: pip-audit (CVE database)",
            "*Secrets: detect-secrets (credential scanning)",
            "*Containers: Trivy (filesystem + image scanning)",
            "*Shell: shellcheck (script analysis)",
            "",
            "## Compliance Artifacts",
            "->OSPDT PowerPoint deck (Intel brand, license inventory)",
            "->SDLE Mermaid diagrams (threat model, data flow, deployment)",
            "->CycloneDX SBOM (industry standard)",
            "->SLSA Level 2+ checklist",
            "->OpenSSF Scorecard estimate",
            "",
            "## Final Output: DASHBOARD.md",
            "*One-stop summary of entire pipeline results",
        ],
        narration="Compliance Agent automates what usually takes weeks — security scans, license review, architecture diagrams, and SBOM. Produces the unified DASHBOARD as final output.",
        section_label="PHASE 4",
    )
    slides.append(make_slide_clip(frame, 7))

    # --- SCENE 10: Standards (6s) ---
    print("[10/15] Standards enforcement...")
    diagram = create_diagram_standards()
    frame = create_frame(
        title="13 Enterprise Standards — Enforced Automatically",
        subtitle="Not suggestions — every generated file MUST comply",
        body_lines=[
            "",
            "## Applied At Generation Time",
            "*Coding: Python 3.11+, type hints, async, Pydantic v2",
            "*Security: PyJWT, non-root containers, zero-trust NetworkPolicy",
            "*Testing: pytest + tox, 85%+ coverage, parametrized",
            "*Containers: Multi-stage, slim base, uid=1000, HEALTHCHECK",
            "*Helm: 200+ params, HPA, PDB, probes, security context",
            "*CI/CD: Super-Linter, CodeQL, Dependabot, cosign",
            "",
            "## Prohibited (Hard Block)",
            "!python-jose, Flask, Django, requests (sync), marshmallow",
            "!Alpine for Python, root containers, COPY . .",
            "!Secrets in code, binary artifacts, unpinned dependencies",
        ],
        narration="Thirteen enterprise standards are enforced automatically. Prohibited libraries trigger hard blocks. Every file passes strict linting and security checks.",
        section_label="STANDARDS",
    )
    slides.append(make_slide_clip(frame, 7))

    # --- SCENE 11: Session Continuity (6s) ---
    print("[11/15] Session continuity...")
    frame = create_frame(
        title="Session Continuity — Never Lose Context",
        subtitle="Developers leave for weekends. The pipeline remembers everything.",
        body_lines=[
            "",
            "## 3-Layer Persistence",
            "*1. .iteration-state.json — phase status, skipped items, tool availability",
            "*2. Claude Memory — project decisions, key choices, next steps",
            "*3. Git commits — enforced at every phase (non-negotiable)",
            "",
            "## Phase 0: Session Recovery (every agent startup)",
            "->Check iteration state → what's done vs pending",
            "->Read Claude memory → project context and decisions",
            "->Check git log → what was committed and when",
            "",
            "## Resumption Prompt",
            "*Continue where you left off / Retry skipped / Review / Start fresh",
            "*Never re-asks questions already answered",
            "",
            "## Integration Setup (one-time)",
            "->Git remote URL + Wiki PAT + Jira PAT (or local-only mode)",
        ],
        narration="Session continuity is a first-class feature. Three persistence layers ensure nothing is lost — even if the developer returns after weeks. Every agent starts with recovery.",
        section_label="CONTINUITY",
    )
    slides.append(make_slide_clip(frame, 7))

    # --- SCENE 12: Program Checkpoints (5s) ---
    print("[12/15] Program checkpoints...")
    frame = create_frame(
        title="Program Checkpoints — Mandatory Gates",
        subtitle="3 checkpoints after every agent phase prevent knowledge and work loss",
        body_lines=[
            "",
            "## After Every Phase Completion",
            "",
            "->1. WIKI — Publish to Confluence (space: datacenterai)",
            "   Ensures knowledge is shared, not trapped on one machine",
            "",
            "->2. JIRA — Update EPICs/Stories (project: DCAIDSE8)",
            "   Keeps tracking accurate, stakeholders informed",
            "",
            "->3. GIT — Commit + Push (NON-NEGOTIABLE)",
            "   Code must be committed. Skip requires explicit reason.",
            "",
            "## Modes",
            "*Connected: full publish/push to remote",
            "*Local-only: commit locally, remind to push at every phase",
            "*Partial: unconfigured services auto-skipped with instructions",
        ],
        narration="Three mandatory checkpoints after every phase: Wiki publish, Jira update, Git commit. The pipeline adapts to your integration mode but Git commit is always enforced.",
        section_label="CHECKPOINTS",
    )
    slides.append(make_slide_clip(frame, 6))

    # --- SCENE 13: Inference Strategy (6s) ---
    print("[13/15] Inference strategy...")
    frame = create_frame(
        title="Inference Strategy — First-Class Decision",
        subtitle="Captured in PRD, drives code generation end-to-end",
        body_lines=[
            "",
            "## Decision Tree",
            "*Does your app need LLM inference?",
            "  → No: Skip inference layer entirely",
            "  → Yes: Choose strategy below",
            "",
            "## Option A: Enterprise Inference (Recommended)",
            "->Shared production platform (OPEA)",
            "->Auth: GenAI Gateway (simple token) OR APISIX+Keycloak (OAuth)",
            "->Topology: Same cluster (internal DNS) OR Remote (external URL)",
            "->We generate: REST client only. EI deployment is their repo.",
            "",
            "## Option B: Direct vLLM (Self-contained)",
            "->We own the FULL deployment end-to-end",
            "->Helm subchart, Docker, model lifecycle, HPA, health probes",
            "->Hardware requirements, HuggingFace token, GPU/CPU config",
        ],
        narration="Inference strategy is captured in the PRD and drives everything downstream. Enterprise Inference means we generate a REST client. Direct vLLM means we own the full deployment.",
        section_label="INFERENCE",
    )
    slides.append(make_slide_clip(frame, 7))

    # --- SCENE 14: Output Structure (5s) ---
    print("[14/15] Output structure...")
    frame = create_frame(
        title="What You Get — Complete Output",
        subtitle="One command at a time, four phases, full production solution",
        body_lines=[
            "",
            "## Project Code",
            "*src/{component}/ — Backend microservices (FastAPI)",
            "*frontend/ — React SPA (TypeScript strict)",
            "*helm/{project}/ — Kubernetes deployment (zero-trust)",
            "*docker/ — Docker Compose (dev + prod)",
            "*.github/workflows/ — 5 CI/CD pipelines",
            "*ansible/ — Infrastructure playbooks",
            "",
            "## Reports",
            "*reports/DASHBOARD.md — One-stop unified summary",
            "*reports/generation/ — File manifest + generation summary",
            "*reports/validation/ — Test results + gaps analysis",
            "*reports/compliance/ — Security scan + license + SLSA",
            "*reports/architecture/ — Mermaid diagrams (5 types)",
            "",
            "## Tracking",
            "*.iteration-state.json — Progress across sessions",
        ],
        narration="The output is a complete, production-ready project with reports, architecture diagrams, and a unified dashboard. Everything tracked in iteration state for continuity.",
        section_label="OUTPUT",
    )
    slides.append(make_slide_clip(frame, 6))

    # --- SCENE 15: Call to Action (5s) ---
    print("[15/15] Closing slide...")
    frame = create_frame(
        title="Get Started Today",
        subtitle="Clone → /prd-agent → /dev-agent → /validation-agent → /compliance-agent",
        body_lines=[
            "",
            "",
            "## Quick Start",
            "->1. Clone the intel-ai-solutions-dev repository",
            "->2. Open in Claude Code (CLI, Desktop, or IDE extension)",
            "->3. Type /prd-agent — answer questions about your AI solution",
            "->4. Type /dev-agent — watch your project materialize",
            "->5. Type /validation-agent — comprehensive test suite",
            "->6. Type /compliance-agent — security + DASHBOARD",
            "",
            "",
            "## Result",
            "*Complete AI solution: code + tests + compliance + deployment",
            "*Days instead of weeks. Consistent quality. Full audit trail.",
            "",
            "",
            "Data Center AI Solutions Engineering | Intel Corporation",
        ],
        narration="Get started today. Four commands turn your AI idea into a production-ready, compliant solution. Days instead of weeks. Consistent quality every time.",
        section_label="GET STARTED",
    )
    slides.append(make_slide_clip(frame, 6))

    # --- Compose final video ---
    print("\nComposing video with transitions...")

    # Add simple crossfade between slides
    final_clips = []
    for i, clip in enumerate(slides):
        if i == 0:
            clip = clip.with_effects([vfx.FadeIn(1.0)])
        if i == len(slides) - 1:
            clip = clip.with_effects([vfx.FadeOut(1.5)])
        final_clips.append(clip)

    video = concatenate_videoclips(final_clips, method="compose")

    # Write output
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    print(f"\nWriting video to: {OUTPUT_FILE}")
    print(f"Duration: {video.duration:.1f}s | Resolution: {WIDTH}x{HEIGHT} | FPS: {FPS}")

    video.write_videofile(
        str(OUTPUT_FILE),
        fps=FPS,
        codec="libx264",
        audio=False,
        preset="medium",
        bitrate="5000k",
        logger="bar",
    )

    print(f"\n{'=' * 60}")
    print(f"Video generated: {OUTPUT_FILE}")
    print(f"Duration: {video.duration:.1f} seconds ({video.duration/60:.1f} min)")
    print(f"Slides: {len(slides)}")
    print("=" * 60)


if __name__ == "__main__":
    build_video()
