"""
Intel AI Dev Pipeline Workshop — Executive PPTX Generator
Premium enterprise design with visual layouts, color-coded sections, and flow diagrams.
"""
from pptx import Presentation
from pptx.util import Inches, Pt, Emu
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
from pptx.enum.dml import MSO_THEME_COLOR

# ═══════════════════════════════════════════════════════════════════
# DESIGN SYSTEM
# ═══════════════════════════════════════════════════════════════════

# Intel Brand Colors
INTEL_BLUE = RGBColor(0, 104, 181)
INTEL_DARK = RGBColor(0, 38, 62)
INTEL_NAVY = RGBColor(0, 53, 95)

# Section Accent Colors (one per section for visual variety)
ACCENT_CYAN = RGBColor(0, 188, 212)
ACCENT_ORANGE = RGBColor(255, 152, 0)
ACCENT_GREEN = RGBColor(76, 175, 80)
ACCENT_PURPLE = RGBColor(156, 39, 176)
ACCENT_RED = RGBColor(244, 67, 54)
ACCENT_TEAL = RGBColor(0, 150, 136)
ACCENT_AMBER = RGBColor(255, 193, 7)

# Neutral Palette
WHITE = RGBColor(255, 255, 255)
OFF_WHITE = RGBColor(248, 250, 252)
LIGHT_GRAY = RGBColor(241, 245, 249)
MID_GRAY = RGBColor(148, 163, 184)
DARK_GRAY = RGBColor(51, 65, 85)
CHARCOAL = RGBColor(30, 41, 59)
BLACK = RGBColor(15, 23, 42)

# Typography
FONT_HEADING = "Segoe UI"
FONT_BODY = "Segoe UI"
FONT_MONO = "Cascadia Code"

# Slide dimensions (16:9)
SLIDE_W = Inches(13.333)
SLIDE_H = Inches(7.5)

prs = Presentation()
prs.slide_width = SLIDE_W
prs.slide_height = SLIDE_H


# ═══════════════════════════════════════════════════════════════════
# DESIGN HELPERS
# ═══════════════════════════════════════════════════════════════════

def blank_slide():
    return prs.slides.add_slide(prs.slide_layouts[6])


def fill_bg(slide, color):
    """Fill entire slide background."""
    bg = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, 0, 0, SLIDE_W, SLIDE_H)
    bg.fill.solid()
    bg.fill.fore_color.rgb = color
    bg.line.fill.background()
    return bg


def accent_bar(slide, color, x=0, y=0, w=None, h=Inches(0.08)):
    """Thin accent color bar."""
    w = w or SLIDE_W
    bar = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, x, y, w, h)
    bar.fill.solid()
    bar.fill.fore_color.rgb = color
    bar.line.fill.background()
    return bar


def side_stripe(slide, color, width=Inches(0.4)):
    """Left side accent stripe."""
    stripe = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, 0, 0, width, SLIDE_H)
    stripe.fill.solid()
    stripe.fill.fore_color.rgb = color
    stripe.line.fill.background()
    return stripe


def card(slide, x, y, w, h, fill_color=WHITE, border_color=None, shadow=False):
    """Rounded card shape."""
    c = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, x, y, w, h)
    c.fill.solid()
    c.fill.fore_color.rgb = fill_color
    if border_color:
        c.line.color.rgb = border_color
        c.line.width = Pt(1.5)
    else:
        c.line.fill.background()
    return c


def add_text(slide, text, x, y, w, h, size=13, bold=False, color=DARK_GRAY,
             align=PP_ALIGN.LEFT, font=FONT_BODY, valign=MSO_ANCHOR.TOP):
    """Add a text box with styling."""
    tb = slide.shapes.add_textbox(x, y, w, h)
    tf = tb.text_frame
    tf.word_wrap = True
    tf.vertical_anchor = valign
    p = tf.paragraphs[0]
    p.text = text
    p.font.size = Pt(size)
    p.font.bold = bold
    p.font.color.rgb = color
    p.font.name = font
    p.alignment = align
    return tb


def add_multiline(slide, lines, x, y, w, h, size=12, color=DARK_GRAY,
                  bullet=False, spacing=6, font=FONT_BODY, bold_first=False):
    """Add multi-line text with spacing."""
    tb = slide.shapes.add_textbox(x, y, w, h)
    tf = tb.text_frame
    tf.word_wrap = True
    for i, line in enumerate(lines):
        p = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
        p.text = line
        p.font.size = Pt(size)
        p.font.color.rgb = color
        p.font.name = font
        p.space_after = Pt(spacing)
        if bold_first and i == 0:
            p.font.bold = True
    return tb


def icon_circle(slide, x, y, size, color, text="", text_color=WHITE):
    """Colored circle with icon text (emoji or letter)."""
    s = slide.shapes.add_shape(MSO_SHAPE.OVAL, x, y, size, size)
    s.fill.solid()
    s.fill.fore_color.rgb = color
    s.line.fill.background()
    if text:
        tf = s.text_frame
        tf.vertical_anchor = MSO_ANCHOR.MIDDLE
        p = tf.paragraphs[0]
        p.text = text
        p.font.size = Pt(int(size / Inches(1) * 14))
        p.font.color.rgb = text_color
        p.font.bold = True
        p.alignment = PP_ALIGN.CENTER
    return s


def slide_number(slide, num):
    """Add slide number footer."""
    add_text(slide, str(num), Inches(12.5), Inches(7.1), Inches(0.6), Inches(0.3),
             size=9, color=MID_GRAY, align=PP_ALIGN.RIGHT)


def footer_bar(slide, accent_color=INTEL_BLUE):
    """Bottom accent line + branding."""
    accent_bar(slide, accent_color, y=Inches(7.3), h=Inches(0.06))
    add_text(slide, "Intel AI Development Pipeline | Confidential",
             Inches(0.6), Inches(7.05), Inches(5), Inches(0.3),
             size=8, color=MID_GRAY)


# ═══════════════════════════════════════════════════════════════════
# SECTION DIVIDER TEMPLATE
# ═══════════════════════════════════════════════════════════════════

def section_divider(num, title, subtitle, accent_color):
    """Full-bleed section divider with gradient-like design."""
    sl = blank_slide()
    fill_bg(sl, INTEL_DARK)
    # Large accent circle (decorative)
    c = sl.shapes.add_shape(MSO_SHAPE.OVAL, Inches(8.5), Inches(-2), Inches(8), Inches(8))
    c.fill.solid()
    c.fill.fore_color.rgb = INTEL_NAVY
    c.line.fill.background()
    # Accent bar
    accent_bar(sl, accent_color, x=Inches(0.8), y=Inches(3.0), w=Inches(3), h=Inches(0.1))
    # Section label
    add_text(sl, f"SECTION {num}", Inches(0.8), Inches(2.3), Inches(4), Inches(0.5),
             size=14, bold=True, color=accent_color, font=FONT_HEADING)
    # Title
    add_text(sl, title, Inches(0.8), Inches(3.4), Inches(10), Inches(1.2),
             size=40, bold=True, color=WHITE, font=FONT_HEADING)
    # Subtitle
    add_text(sl, subtitle, Inches(0.8), Inches(4.8), Inches(10), Inches(0.6),
             size=18, color=MID_GRAY, font=FONT_HEADING)
    slide_number(sl, len(prs.slides))
    return sl


# ═══════════════════════════════════════════════════════════════════
# CONTENT SLIDE TEMPLATE
# ═══════════════════════════════════════════════════════════════════

def content_slide(title, subtitle=None, accent_color=INTEL_BLUE):
    """Standard content slide with header bar."""
    sl = blank_slide()
    fill_bg(sl, OFF_WHITE)
    # Header area
    hdr = sl.shapes.add_shape(MSO_SHAPE.RECTANGLE, 0, 0, SLIDE_W, Inches(1.4))
    hdr.fill.solid()
    hdr.fill.fore_color.rgb = WHITE
    hdr.line.fill.background()
    # Accent top bar
    accent_bar(sl, accent_color, h=Inches(0.06))
    # Title
    add_text(sl, title, Inches(0.8), Inches(0.25), Inches(11), Inches(0.7),
             size=24, bold=True, color=CHARCOAL, font=FONT_HEADING)
    # Subtitle
    if subtitle:
        add_text(sl, subtitle, Inches(0.8), Inches(0.85), Inches(11), Inches(0.4),
                 size=12, color=MID_GRAY, font=FONT_HEADING)
    # Footer
    footer_bar(sl, accent_color)
    slide_number(sl, len(prs.slides))
    return sl


# ═══════════════════════════════════════════════════════════════════
# SLIDES BEGIN
# ═══════════════════════════════════════════════════════════════════

# ─── SLIDE 1: TITLE ─────────────────────────────────────────────
sl = blank_slide()
fill_bg(sl, INTEL_DARK)
# Decorative shapes
c1 = sl.shapes.add_shape(MSO_SHAPE.OVAL, Inches(9), Inches(-3), Inches(10), Inches(10))
c1.fill.solid()
c1.fill.fore_color.rgb = INTEL_NAVY
c1.line.fill.background()
c2 = sl.shapes.add_shape(MSO_SHAPE.OVAL, Inches(10.5), Inches(4), Inches(5), Inches(5))
c2.fill.solid()
c2.fill.fore_color.rgb = RGBColor(0, 70, 120)
c2.line.fill.background()
# Accent line
accent_bar(sl, ACCENT_CYAN, x=Inches(0.8), y=Inches(2.0), w=Inches(4), h=Inches(0.1))
# Main title
add_text(sl, "Intel AI Development\nPipeline", Inches(0.8), Inches(2.3), Inches(8), Inches(2),
         size=44, bold=True, color=WHITE, font=FONT_HEADING)
# Subtitle
add_text(sl, "Claude Code + Enterprise Standards = Production-Ready AI in 70 Minutes",
         Inches(0.8), Inches(4.4), Inches(8), Inches(0.6),
         size=18, color=ACCENT_CYAN, font=FONT_HEADING)
# Presenter info
add_text(sl, "Vivek RS\nData Center AI Software Engineering\nMay 2026",
         Inches(0.8), Inches(5.8), Inches(5), Inches(1.2),
         size=13, color=MID_GRAY)
# Bottom bar
accent_bar(sl, ACCENT_CYAN, y=Inches(7.35), h=Inches(0.06))

# ─── SLIDE 2: AGENDA ─────────────────────────────────────────────
sl = content_slide("Workshop Agenda", "90 Minutes: Concepts \u2192 Problem \u2192 Solution \u2192 Demo \u2192 Hands-On", INTEL_BLUE)
sections_data = [
    ("1", "Claude Code Concepts", "15 min", "Terminology, architecture, building blocks", ACCENT_CYAN),
    ("2", "The Problem", "10 min", "Developer pain points & cost of status quo", ACCENT_RED),
    ("3", "Our Solution", "20 min", "4 agents, hybrid architecture, contracts", ACCENT_GREEN),
    ("4", "Live Demo: Dataset Maker", "10 min", "Real project with Enterprise Inference", ACCENT_ORANGE),
    ("5", "Hands-On Workshop", "45 min", "Generate your own project from PRD", ACCENT_PURPLE),
]
for i, (num, title, time, desc, color) in enumerate(sections_data):
    y_pos = Inches(1.7 + i * 1.05)
    # Card background
    card(sl, Inches(0.6), y_pos, Inches(12), Inches(0.9), fill_color=WHITE, border_color=LIGHT_GRAY)
    # Color indicator
    indicator = sl.shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(0.6), y_pos, Inches(0.12), Inches(0.9))
    indicator.fill.solid()
    indicator.fill.fore_color.rgb = color
    indicator.line.fill.background()
    # Section number
    add_text(sl, num, Inches(1.0), y_pos, Inches(0.5), Inches(0.9),
             size=20, bold=True, color=color, valign=MSO_ANCHOR.MIDDLE)
    # Title
    add_text(sl, title, Inches(1.5), y_pos, Inches(4), Inches(0.9),
             size=15, bold=True, color=CHARCOAL, valign=MSO_ANCHOR.MIDDLE)
    # Description
    add_text(sl, desc, Inches(5.5), y_pos, Inches(5), Inches(0.9),
             size=12, color=DARK_GRAY, valign=MSO_ANCHOR.MIDDLE)
    # Time badge
    add_text(sl, time, Inches(11.0), y_pos, Inches(1.4), Inches(0.9),
             size=11, bold=True, color=color, align=PP_ALIGN.RIGHT, valign=MSO_ANCHOR.MIDDLE)


# ═══════════════════════════════════════════════════════════════════
# SECTION 1: CLAUDE CODE CONCEPTS
# ═══════════════════════════════════════════════════════════════════

section_divider("1", "Claude Code", "Concepts, Terminology & Building Blocks", ACCENT_CYAN)

# ─── SLIDE 4: What is Claude Code ─────────────────────────────────
sl = content_slide("What is Claude Code?", "AI-powered agentic development environment by Anthropic", ACCENT_CYAN)
# Left column - description
add_multiline(sl, [
    "An intelligent coding assistant that lives in your terminal, IDE, or desktop.",
    "It reads entire codebases, executes commands, edits files, and builds",
    "complete projects through natural language conversation.",
    "",
    "Not just autocomplete — it's a full development partner that",
    "understands context, follows standards, and delivers production code.",
], Inches(0.8), Inches(1.6), Inches(6), Inches(2.5), size=13, color=DARK_GRAY, spacing=4)

# Right column - capabilities cards
caps = [
    ("\u26A1", "Code Understanding", "100K+ file analysis", ACCENT_CYAN),
    ("\u270F\uFE0F", "Code Generation", "Context-aware editing", ACCENT_GREEN),
    ("\u2699\uFE0F", "Tool Execution", "Shell, tests, builds", ACCENT_ORANGE),
    ("\U0001F4C1", "Multi-File Editing", "Coordinated changes", ACCENT_PURPLE),
]
for i, (icon, name, desc, color) in enumerate(caps):
    y = Inches(1.7 + i * 1.1)
    card(sl, Inches(7.5), y, Inches(5), Inches(0.95), fill_color=WHITE, border_color=LIGHT_GRAY)
    icon_circle(sl, Inches(7.7), Inches(y / Inches(1) * 914400 + Emu(Inches(0.12))),
                Inches(0.6), color)
    add_text(sl, name, Inches(8.5), y, Inches(3), Inches(0.55),
             size=13, bold=True, color=CHARCOAL)
    add_text(sl, desc, Inches(8.5), Inches(y / Inches(1) + 0.5), Inches(3), Inches(0.4),
             size=10, color=MID_GRAY)

# Platforms bar at bottom
add_text(sl, "CLI  \u2022  VS Code  \u2022  JetBrains  \u2022  Desktop App  \u2022  Web (claude.ai/code)",
         Inches(0.8), Inches(6.4), Inches(12), Inches(0.4),
         size=12, bold=True, color=INTEL_BLUE, align=PP_ALIGN.CENTER)

# ─── SLIDE 5: Architecture Overview ─────────────────────────────────
sl = content_slide("The Big Picture", "How all Claude Code pieces connect in a session", ACCENT_CYAN)

# Central flow diagram using cards
# Session box (center)
card(sl, Inches(4.5), Inches(1.7), Inches(4.3), Inches(1.2), fill_color=INTEL_BLUE)
add_text(sl, "SESSION", Inches(4.5), Inches(1.8), Inches(4.3), Inches(0.5),
         size=11, bold=True, color=ACCENT_CYAN, align=PP_ALIGN.CENTER)
add_text(sl, "~200K token context window", Inches(4.5), Inches(2.2), Inches(4.3), Inches(0.4),
         size=16, bold=True, color=WHITE, align=PP_ALIGN.CENTER)

# Left column items
left_items = [
    ("CLAUDE.md", "Project instructions", ACCENT_CYAN),
    ("Memory", "Cross-session state", ACCENT_GREEN),
    ("Skills", "/slash commands", ACCENT_ORANGE),
]
for i, (name, desc, color) in enumerate(left_items):
    y = Inches(3.3 + i * 1.1)
    card(sl, Inches(0.6), y, Inches(3.5), Inches(0.9), border_color=color)
    add_text(sl, name, Inches(0.9), y, Inches(2), Inches(0.55),
             size=13, bold=True, color=color)
    add_text(sl, desc, Inches(0.9), Inches(y / Inches(1) + 0.45), Inches(3), Inches(0.35),
             size=10, color=MID_GRAY)

# Right column items
right_items = [
    ("Sub-Agents", "Parallel workers", ACCENT_PURPLE),
    ("Hooks", "Lifecycle events", ACCENT_RED),
    ("MCP Servers", "External tools", ACCENT_TEAL),
]
for i, (name, desc, color) in enumerate(right_items):
    y = Inches(3.3 + i * 1.1)
    card(sl, Inches(9.2), y, Inches(3.5), Inches(0.9), border_color=color)
    add_text(sl, name, Inches(9.5), y, Inches(2), Inches(0.55),
             size=13, bold=True, color=color)
    add_text(sl, desc, Inches(9.5), Inches(y / Inches(1) + 0.45), Inches(3), Inches(0.35),
             size=10, color=MID_GRAY)

# Bottom row
bottom_items = [
    ("Permissions", "Access control"),
    ("Checkpoints", "Undo safety"),
    ("Worktrees", "Parallel branches"),
    ("Plan Mode", "Read-only analysis"),
]
for i, (name, desc) in enumerate(bottom_items):
    x = Inches(1.0 + i * 3.1)
    card(sl, x, Inches(6.3), Inches(2.8), Inches(0.65), fill_color=LIGHT_GRAY)
    add_text(sl, f"{name}: {desc}", x, Inches(6.3), Inches(2.8), Inches(0.65),
             size=10, bold=False, color=DARK_GRAY, align=PP_ALIGN.CENTER, valign=MSO_ANCHOR.MIDDLE)

# ─── SLIDE 6: CLAUDE.md Deep Dive ─────────────────────────────────
sl = content_slide("CLAUDE.md \u2014 The Project Brain", "Auto-loaded every session. Replaces tribal knowledge.", ACCENT_CYAN)

add_multiline(sl, [
    "What It Does:",
    "  \u2022  Loaded automatically when Claude Code starts in a directory",
    "  \u2022  Defines architecture rules, coding standards, allowed patterns",
    "  \u2022  Lives in git \u2192 entire team shares same instructions",
    "  \u2022  Cascading: root CLAUDE.md + .claude/CLAUDE.md (both loaded)",
    "",
    "What Goes In It:",
    "  \u2022  Project structure & architecture decisions",
    "  \u2022  Build/test/deploy commands",
    "  \u2022  Coding conventions & naming rules",
    "  \u2022  Integration points (APIs, databases, services)",
    "  \u2022  Security requirements & prohibited patterns",
    "",
    "Our Pipeline's CLAUDE.md:",
    "  \u2022  Documents the 4-agent workflow & hybrid architecture",
    "  \u2022  Links to all standards, templates, and contracts",
    "  \u2022  Ensures consistent behavior regardless of who runs the pipeline",
], Inches(0.8), Inches(1.6), Inches(7), Inches(5.5), size=12, color=DARK_GRAY, spacing=3)

# Code preview card on right
card(sl, Inches(8.2), Inches(1.7), Inches(4.5), Inches(5.0), fill_color=CHARCOAL)
add_multiline(sl, [
    "# CLAUDE.md",
    "",
    "## Quick Start",
    "  /prd-agent    \u2192 Create PRD",
    "  /dev-agent    \u2192 Generate project",
    "  /validation   \u2192 Run tests",
    "  /compliance   \u2192 Security scans",
    "",
    "## Standards",
    "  See .claude/shared/standards/",
    "",
    "## Architecture",
    "  Hybrid: scaffold.py + LLM",
    "  151 templates, 14 contracts",
    "",
    "## Security Gate",
    "  Must pass: ruff, mypy, bandit",
], Inches(8.5), Inches(1.9), Inches(4), Inches(4.8),
    size=10, color=ACCENT_CYAN, font=FONT_MONO, spacing=2)

# ─── SLIDE 7: Skills & Commands ─────────────────────────────────
sl = content_slide("Skills & Commands", "Domain expertise packaged as /slash-commands", ACCENT_CYAN)

# Skills section
add_text(sl, "SKILLS \u2014 Multi-step conversational workflows", Inches(0.8), Inches(1.6),
         Inches(6), Inches(0.4), size=14, bold=True, color=ACCENT_CYAN)

skills = [
    ("/prd-agent", "500 lines", "Socratic Q&A \u2192 PRD + Feature Breakdown"),
    ("/dev-agent", "800 lines", "scaffold.py + LLM \u2192 Complete project"),
    ("/validation-agent", "400 lines", "Auto-generate tests + coverage report"),
    ("/compliance-agent", "600 lines", "OSPDT + SDLE + SBOM + DASHBOARD"),
]
for i, (cmd, size_str, desc) in enumerate(skills):
    y = Inches(2.1 + i * 0.7)
    add_text(sl, cmd, Inches(0.8), y, Inches(2.5), Inches(0.5),
             size=12, bold=True, color=CHARCOAL, font=FONT_MONO)
    add_text(sl, size_str, Inches(3.3), y, Inches(1.2), Inches(0.5),
             size=10, color=MID_GRAY)
    add_text(sl, desc, Inches(4.6), y, Inches(5), Inches(0.5),
             size=11, color=DARK_GRAY)

# Commands section
add_text(sl, "COMMANDS \u2014 Quick single-execution actions", Inches(0.8), Inches(5.0),
         Inches(6), Inches(0.4), size=14, bold=True, color=ACCENT_ORANGE)

commands = ["/scan", "/test", "/lint", "/status", "/deploy", "/wiki-publish", "/jira-update"]
add_text(sl, "  \u2022  ".join(commands), Inches(0.8), Inches(5.5), Inches(11), Inches(0.5),
         size=11, color=DARK_GRAY)

# Difference callout
card(sl, Inches(7.5), Inches(1.7), Inches(5.2), Inches(3.0), fill_color=LIGHT_GRAY)
add_multiline(sl, [
    "Skills vs Commands",
    "",
    "Skills: 25+ minutes",
    "  Interactive, phase gates",
    "  Human-in-the-loop decisions",
    "  Complex multi-step workflows",
    "",
    "Commands: 30 seconds",
    "  Fire-and-forget execution",
    "  Immediate result returned",
    "  Single focused action",
], Inches(7.8), Inches(1.9), Inches(4.8), Inches(2.8),
    size=11, color=DARK_GRAY, spacing=2, bold_first=True)

# ─── SLIDE 8: Memory & Sub-Agents ─────────────────────────────────
sl = content_slide("Memory & Sub-Agents", "Cross-session persistence and parallel execution", ACCENT_CYAN)

# Memory section (left)
add_text(sl, "MEMORY", Inches(0.8), Inches(1.6), Inches(5), Inches(0.4),
         size=16, bold=True, color=ACCENT_GREEN)
mem_types = [
    ("\U0001F464 User", "Role, goals, expertise level"),
    ("\U0001F4AC Feedback", "Corrections & validated approaches"),
    ("\U0001F4CB Project", "Ongoing work, decisions, deadlines"),
    ("\U0001F517 Reference", "External system pointers"),
]
for i, (mtype, desc) in enumerate(mem_types):
    y = Inches(2.2 + i * 0.75)
    add_text(sl, mtype, Inches(0.8), y, Inches(2.5), Inches(0.5),
             size=12, bold=True, color=CHARCOAL)
    add_text(sl, desc, Inches(3.2), y, Inches(3), Inches(0.5),
             size=11, color=DARK_GRAY)

add_multiline(sl, [
    "Stored: ~/.claude/projects/*/memory/",
    "First 200 lines loaded each session",
    "Claude saves automatically (\"remember this\")",
], Inches(0.8), Inches(5.3), Inches(5.5), Inches(1.5), size=10, color=MID_GRAY, spacing=2)

# Sub-Agents section (right)
add_text(sl, "SUB-AGENTS", Inches(7.2), Inches(1.6), Inches(5), Inches(0.4),
         size=16, bold=True, color=ACCENT_PURPLE)
add_multiline(sl, [
    "\u2022  Fresh Claude instances (isolated context)",
    "\u2022  Run in parallel or background",
    "\u2022  Don't pollute main context window",
    "\u2022  Return single result to parent",
    "",
    "Built-in Types:",
    "   Explore \u2014 Fast codebase search",
    "   Plan \u2014 Architecture design",
    "   General \u2014 Multi-step research",
    "",
    "Custom Agents:",
    "   Full isolation, own tools/permissions",
    "   Agent SDK for building production agents",
], Inches(7.2), Inches(2.1), Inches(5.5), Inches(4.5), size=12, color=DARK_GRAY, spacing=3)

# ─── SLIDE 9: Hooks, Permissions, MCP ─────────────────────────────
sl = content_slide("Hooks, Permissions & MCP", "Guardrails and external integrations", ACCENT_CYAN)

# Three columns
col_data = [
    ("Hooks", ACCENT_RED, [
        "Event-triggered shell commands",
        "",
        "PreToolUse:",
        "  Block dangerous operations",
        "  Validate before execution",
        "",
        "PostToolUse:",
        "  Log changes to audit trail",
        "  Trigger CI pipelines",
        "",
        "SessionStart:",
        "  Setup environment vars",
        "  Load credentials",
    ]),
    ("Permissions", ACCENT_ORANGE, [
        "Fine-grained access control",
        "",
        "Priority: deny > ask > allow",
        "",
        "Examples:",
        "  allow: Bash(npm run *)",
        "  allow: Read(**)",
        "  ask: Edit(src/**)",
        "  deny: Bash(rm -rf *)",
        "",
        "Scoped per project or user",
        "Cascading settings files",
    ]),
    ("MCP Servers", ACCENT_TEAL, [
        "Model Context Protocol",
        "",
        "Standardized external tools:",
        "  \u2022 Databases (Postgres, Redis)",
        "  \u2022 APIs (GitHub, Jira, Slack)",
        "  \u2022 Filesystems (S3, GCS)",
        "  \u2022 Custom services",
        "",
        "Configured in settings.json",
        "Tools appear like built-ins",
        "Secure credential handling",
    ]),
]
for i, (title, color, lines) in enumerate(col_data):
    x = Inches(0.5 + i * 4.2)
    # Column header
    accent_bar(sl, color, x=x, y=Inches(1.6), w=Inches(3.8), h=Inches(0.06))
    add_text(sl, title, x, Inches(1.75), Inches(3.8), Inches(0.5),
             size=14, bold=True, color=color)
    # Content
    add_multiline(sl, lines, x, Inches(2.3), Inches(3.8), Inches(4.5),
                  size=10, color=DARK_GRAY, spacing=2)


# ═══════════════════════════════════════════════════════════════════
# SECTION 2: THE PROBLEM
# ═══════════════════════════════════════════════════════════════════

section_divider("2", "The Problem", "Why Enterprise AI Development is Broken", ACCENT_RED)

# ─── SLIDE 11: Pain Points ─────────────────────────────────────────
sl = content_slide("Developer Pain Points", "8 problems we face on every project", ACCENT_RED)

pains = [
    ("'Where do I start?'", "No canonical structure. 2+ weeks onboarding per project."),
    ("'Standards exist\nbut nobody follows'", "13 Confluence docs. Found at PR review (too late)."),
    ("'Compliance is a tax'", "OSPDT: 1-2 weeks manual work. Copy-paste from last project."),
    ("'AI integration is\na black box'", "EI docs sparse. Every team writes own client."),
    ("'Can't staff this'", "Need: BE + FE + DevOps + ML + Security. Have: 2-3 devs."),
    ("'Estimation impossible'", "'How long for K8s-ready?' Nobody agrees."),
    ("'No consistency'", "5 teams, 5 structures. Bug in one EI client unfixed in others."),
    ("'Proving compliance\nis manual'", "Every OSPDT: manual evidence gathering. No dashboard."),
]
for i, (pain, desc) in enumerate(pains):
    col = i % 2
    row = i // 2
    x = Inches(0.6 + col * 6.3)
    y = Inches(1.6 + row * 1.4)
    card(sl, x, y, Inches(6.0), Inches(1.2), border_color=LIGHT_GRAY)
    # Red number
    add_text(sl, str(i + 1), Inches(x / Inches(1) + 0.15), y, Inches(0.5), Inches(1.2),
             size=20, bold=True, color=ACCENT_RED, valign=MSO_ANCHOR.MIDDLE)
    # Pain title
    add_text(sl, pain.replace("\n", " "), Inches(x / Inches(1) + 0.6), y, Inches(2.3), Inches(1.2),
             size=11, bold=True, color=CHARCOAL, valign=MSO_ANCHOR.MIDDLE)
    # Description
    add_text(sl, desc, Inches(x / Inches(1) + 2.9), y, Inches(2.9), Inches(1.2),
             size=10, color=DARK_GRAY, valign=MSO_ANCHOR.MIDDLE)

# ─── SLIDE 12: Cost Comparison ─────────────────────────────────────
sl = content_slide("The Cost of Status Quo", "10-14 weeks per project vs. 70 minutes", ACCENT_RED)

# Before (left card - red tint)
card(sl, Inches(0.6), Inches(1.7), Inches(5.8), Inches(4.8), fill_color=WHITE, border_color=ACCENT_RED)
add_text(sl, "BEFORE (Manual)", Inches(0.6), Inches(1.8), Inches(5.8), Inches(0.5),
         size=14, bold=True, color=ACCENT_RED, align=PP_ALIGN.CENTER)

before_items = [
    ("PRD & Design", "2-4 weeks"),
    ("Project Setup", "1-2 weeks"),
    ("Implementation", "3-4 weeks"),
    ("Security/Compliance", "1-2 weeks"),
    ("Testing", "1-2 weeks"),
]
for i, (item, time) in enumerate(before_items):
    y = Inches(2.5 + i * 0.6)
    add_text(sl, item, Inches(1.0), y, Inches(3.5), Inches(0.5), size=12, color=DARK_GRAY)
    add_text(sl, time, Inches(4.5), y, Inches(1.5), Inches(0.5),
             size=12, bold=True, color=ACCENT_RED, align=PP_ALIGN.RIGHT)

add_text(sl, "TOTAL: 10-14 weeks", Inches(0.6), Inches(5.7), Inches(5.8), Inches(0.5),
         size=16, bold=True, color=ACCENT_RED, align=PP_ALIGN.CENTER)

# After (right card - green tint)
card(sl, Inches(6.9), Inches(1.7), Inches(5.8), Inches(4.8), fill_color=WHITE, border_color=ACCENT_GREEN)
add_text(sl, "AFTER (Pipeline)", Inches(6.9), Inches(1.8), Inches(5.8), Inches(0.5),
         size=14, bold=True, color=ACCENT_GREEN, align=PP_ALIGN.CENTER)

after_items = [
    ("/prd-agent", "25 min"),
    ("/dev-agent", "25 min"),
    ("/validation-agent", "10 min"),
    ("/compliance-agent", "10 min"),
    ("+ Polish & customize", "1-2 weeks"),
]
for i, (item, time) in enumerate(after_items):
    y = Inches(2.5 + i * 0.6)
    add_text(sl, item, Inches(7.3), y, Inches(3.5), Inches(0.5),
             size=12, color=DARK_GRAY, font=FONT_MONO if item.startswith("/") else FONT_BODY)
    add_text(sl, time, Inches(10.8), y, Inches(1.5), Inches(0.5),
             size=12, bold=True, color=ACCENT_GREEN, align=PP_ALIGN.RIGHT)

add_text(sl, "TOTAL: 70 min + polish", Inches(6.9), Inches(5.7), Inches(5.8), Inches(0.5),
         size=16, bold=True, color=ACCENT_GREEN, align=PP_ALIGN.CENTER)

# Savings banner
card(sl, Inches(2.5), Inches(6.6), Inches(8.3), Inches(0.55), fill_color=ACCENT_GREEN)
add_text(sl, "85% TIME SAVED  \u2022  85% COST SAVED  \u2022  100% COMPLIANCE FROM DAY ONE",
         Inches(2.5), Inches(6.6), Inches(8.3), Inches(0.55),
         size=12, bold=True, color=WHITE, align=PP_ALIGN.CENTER, valign=MSO_ANCHOR.MIDDLE)


# ═══════════════════════════════════════════════════════════════════
# SECTION 3: OUR SOLUTION
# ═══════════════════════════════════════════════════════════════════

section_divider("3", "Our Solution", "Intel AI Development Pipeline \u2014 4 Agents, 70 Minutes", ACCENT_GREEN)

# ─── SLIDE 14: Pipeline Overview Flow ─────────────────────────────
sl = content_slide("End-to-End Pipeline Flow", "From idea to production-ready project in one session", ACCENT_GREEN)

# Flow boxes connected with arrows
flow_steps = [
    ("\U0001F4A1", "YOUR IDEA", "", RGBColor(100, 100, 100)),
    ("1", "/prd-agent", "25 min", ACCENT_CYAN),
    ("2", "/dev-agent", "25 min", ACCENT_GREEN),
    ("3", "/validation", "10 min", ACCENT_ORANGE),
    ("4", "/compliance", "10 min", ACCENT_PURPLE),
    ("\u2713", "PRODUCTION\nREADY", "", ACCENT_GREEN),
]
for i, (num, label, time, color) in enumerate(flow_steps):
    x = Inches(0.4 + i * 2.15)
    y = Inches(2.0)
    # Box
    card(sl, x, y, Inches(1.9), Inches(1.6), fill_color=color if i in (0, 5) else WHITE, border_color=color)
    # Number circle
    if num not in ("\U0001F4A1", "\u2713"):
        icon_circle(sl, Inches(x / Inches(1) + 0.65), Inches(2.1), Inches(0.6), color, num)
    # Label
    lbl_color = WHITE if i in (0, 5) else CHARCOAL
    add_text(sl, label, x, Inches(2.8 if i not in (0, 5) else 2.3), Inches(1.9), Inches(0.8),
             size=10, bold=True, color=lbl_color, align=PP_ALIGN.CENTER)
    # Time
    if time:
        add_text(sl, time, x, Inches(3.3), Inches(1.9), Inches(0.3),
                 size=9, color=MID_GRAY, align=PP_ALIGN.CENTER)
    # Arrow (except last)
    if i < len(flow_steps) - 1:
        arrow_x = Inches(x / Inches(1) + 1.95)
        add_text(sl, "\u25B6", arrow_x, Inches(2.5), Inches(0.3), Inches(0.5),
                 size=14, color=MID_GRAY, valign=MSO_ANCHOR.MIDDLE)

# Output descriptions below
outputs = [
    ("PRD Agent Output:", "PRD + Feature Breakdown + Technical PRD + Jira Stories", ACCENT_CYAN),
    ("Dev Agent Output:", "151 template files + PRD-specific code + verified E2E", ACCENT_GREEN),
    ("Validation Output:", "Test suite + coverage report + lint results + gap analysis", ACCENT_ORANGE),
    ("Compliance Output:", "Security scans + OSPDT deck + SBOM + DASHBOARD.md", ACCENT_PURPLE),
]
for i, (title, desc, color) in enumerate(outputs):
    y = Inches(4.2 + i * 0.7)
    accent_bar(sl, color, x=Inches(0.8), y=y, w=Inches(0.08), h=Inches(0.5))
    add_text(sl, title, Inches(1.1), y, Inches(2.5), Inches(0.5),
             size=11, bold=True, color=color)
    add_text(sl, desc, Inches(3.5), y, Inches(9), Inches(0.5),
             size=11, color=DARK_GRAY)

# ─── SLIDE 15: Hybrid Architecture ─────────────────────────────────
sl = content_slide("Hybrid Architecture", "Solving context window exhaustion with two layers", ACCENT_GREEN)

# Problem statement
card(sl, Inches(0.6), Inches(1.6), Inches(12), Inches(0.9), fill_color=RGBColor(254, 242, 242), border_color=ACCENT_RED)
add_text(sl, "PROBLEM: 151 templates (228KB) + standards (120KB) + PRD (30KB) = 378KB  \u2192  Context window ~200KB  \u2192  OVERFLOW",
         Inches(0.6), Inches(1.6), Inches(12), Inches(0.9),
         size=12, bold=True, color=ACCENT_RED, align=PP_ALIGN.CENTER, valign=MSO_ANCHOR.MIDDLE)

# Layer 1
card(sl, Inches(0.6), Inches(2.8), Inches(5.8), Inches(3.5), fill_color=WHITE, border_color=ACCENT_CYAN)
add_text(sl, "LAYER 1: scaffold.py", Inches(0.8), Inches(2.9), Inches(5.5), Inches(0.5),
         size=14, bold=True, color=ACCENT_CYAN)
add_text(sl, "Zero LLM Context \u2014 Pure Python", Inches(0.8), Inches(3.3), Inches(5.5), Inches(0.4),
         size=10, color=MID_GRAY)
add_multiline(sl, [
    "\u2022  Reads 151 .tmpl template files",
    "\u2022  Applies {{variable}} substitution from handoff.yaml",
    "\u2022  Generates complete project in <3 seconds",
    "\u2022  100% deterministic: same input = same output",
    "\u2022  No LLM token cost, no hallucination risk",
    "",
    "  python scripts/scaffold.py \\",
    "    --vars handoff.yaml --output ./project/",
], Inches(0.8), Inches(3.8), Inches(5.5), Inches(2.5), size=11, color=DARK_GRAY, spacing=3)

# Layer 2
card(sl, Inches(6.9), Inches(2.8), Inches(5.8), Inches(3.5), fill_color=WHITE, border_color=ACCENT_ORANGE)
add_text(sl, "LAYER 2: LLM Sub-Phases", Inches(7.1), Inches(2.9), Inches(5.5), Inches(0.5),
         size=14, bold=True, color=ACCENT_ORANGE)
add_text(sl, "Focused Creative Work \u2014 Claude Code", Inches(7.1), Inches(3.3), Inches(5.5), Inches(0.4),
         size=10, color=MID_GRAY)
add_multiline(sl, [
    "Phase 4:   Custom code (endpoints, models)   ~30KB",
    "Phase 4.5: Dev sanity (start, verify E2E)    ~10KB",
    "Phase 4.6: Integration audit (no orphans)    ~15KB",
    "Phase 4.7: README generation                 ~20KB",
    "",
    "Each phase independent \u2014 context never accumulates",
    "If one fails, retry without losing others",
    "Focused scope = higher quality output",
], Inches(7.1), Inches(3.8), Inches(5.5), Inches(2.5), size=11, color=DARK_GRAY, spacing=3)

# Bottom summary
card(sl, Inches(3.0), Inches(6.5), Inches(7.3), Inches(0.5), fill_color=ACCENT_GREEN)
add_text(sl, "Result: 100% file coverage + creative customization \u2014 no context overflow",
         Inches(3.0), Inches(6.5), Inches(7.3), Inches(0.5),
         size=11, bold=True, color=WHITE, align=PP_ALIGN.CENTER, valign=MSO_ANCHOR.MIDDLE)

# ─── SLIDE 16: PRD Agent Phases ─────────────────────────────────
sl = content_slide("/prd-agent \u2014 Phases & Output", "From idea to machine-readable Technical PRD", ACCENT_CYAN)

prd_phases = [
    ("0", "Session Recovery", "Check for prior state, resume if interrupted"),
    ("0.5", "Integration Setup", "Git remote, Wiki PAT, Jira PAT (or local-only)"),
    ("0.6", "Output Directory", "Interactive folder selection for all outputs"),
    ("1", "Socratic Q&A", "15 areas, one question at a time, MCQ preferred"),
    ("2", "PRD Generation", "PRD + Feature Breakdown (5-6 Epics, Stories)"),
    ("3", "Technical PRD", "Code snippets, architecture diagrams, handoff YAML"),
    ("4", "Checkpoints", "Wiki publish + Jira export + Git commit"),
]
for i, (phase, name, desc) in enumerate(prd_phases):
    y = Inches(1.6 + i * 0.78)
    # Phase number badge
    badge = sl.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE,
                                 Inches(0.8), y, Inches(0.7), Inches(0.55))
    badge.fill.solid()
    badge.fill.fore_color.rgb = ACCENT_CYAN
    badge.line.fill.background()
    tf = badge.text_frame
    tf.vertical_anchor = MSO_ANCHOR.MIDDLE
    p = tf.paragraphs[0]
    p.text = phase
    p.font.size = Pt(10)
    p.font.bold = True
    p.font.color.rgb = WHITE
    p.alignment = PP_ALIGN.CENTER
    # Phase name
    add_text(sl, name, Inches(1.7), y, Inches(2.5), Inches(0.55),
             size=12, bold=True, color=CHARCOAL, valign=MSO_ANCHOR.MIDDLE)
    # Description
    add_text(sl, desc, Inches(4.2), y, Inches(5), Inches(0.55),
             size=11, color=DARK_GRAY, valign=MSO_ANCHOR.MIDDLE)

# Output callout
card(sl, Inches(9.8), Inches(1.7), Inches(3), Inches(4.5), fill_color=LIGHT_GRAY)
add_multiline(sl, [
    "OUTPUT FILES:",
    "",
    "\U0001F4C4 {slug}.md",
    "    Full PRD",
    "",
    "\U0001F4CB {slug}-breakdown.md",
    "    Epics + Stories",
    "",
    "\U0001F527 {slug}-technical.md",
    "    Handoff metadata",
    "    Code snippets",
    "    Architecture",
], Inches(10.0), Inches(1.9), Inches(2.8), Inches(4.2),
    size=10, color=DARK_GRAY, spacing=2, bold_first=True)

# ─── SLIDE 17: Dev Agent Phases ─────────────────────────────────
sl = content_slide("/dev-agent \u2014 Phases & Output", "Technical PRD \u2192 Production-ready project", ACCENT_GREEN)

dev_phases = [
    ("0", "Session Recovery", "Resume interrupted generation"),
    ("1", "PRD Intake", "Parse handoff metadata, validate requirements"),
    ("2", "Generation Plan", "Build file list, resolve variables, confirm"),
    ("3", "Scaffold", "scaffold.py stamps 151 template files (<3s)"),
    ("4", "PRD-Specific Code", "Endpoints, models, schemas, services"),
    ("4.5", "Dev Sanity", "Start servers, verify E2E, auto-fix 3x"),
    ("4.6", "Integration Audit", "No orphan code, no broken imports"),
    ("4.7", "README", "Production-ready, customer-testable docs"),
]
for i, (phase, name, desc) in enumerate(dev_phases):
    y = Inches(1.5 + i * 0.7)
    # Phase badge
    badge = sl.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE,
                                 Inches(0.8), y, Inches(0.7), Inches(0.5))
    badge.fill.solid()
    badge.fill.fore_color.rgb = ACCENT_GREEN
    badge.line.fill.background()
    tf = badge.text_frame
    tf.vertical_anchor = MSO_ANCHOR.MIDDLE
    p = tf.paragraphs[0]
    p.text = phase
    p.font.size = Pt(9)
    p.font.bold = True
    p.font.color.rgb = WHITE
    p.alignment = PP_ALIGN.CENTER
    # Name + desc
    add_text(sl, name, Inches(1.7), y, Inches(2.3), Inches(0.5),
             size=11, bold=True, color=CHARCOAL, valign=MSO_ANCHOR.MIDDLE)
    add_text(sl, desc, Inches(4.0), y, Inches(5.5), Inches(0.5),
             size=10, color=DARK_GRAY, valign=MSO_ANCHOR.MIDDLE)

# Output stats
card(sl, Inches(9.8), Inches(1.5), Inches(3), Inches(5.0), fill_color=LIGHT_GRAY)
add_multiline(sl, [
    "OUTPUT:",
    "",
    "151 files generated:",
    "  18 root config",
    "  10 GitHub Actions",
    "  31 backend",
    "  44 frontend",
    "  3 Docker",
    "  16 Helm",
    "  11 Ansible",
    "  2 scripts",
    "",
    "+ PRD-specific code",
    "+ Verified working E2E",
    "+ Production README",
], Inches(10.0), Inches(1.6), Inches(2.8), Inches(4.8),
    size=10, color=DARK_GRAY, spacing=2, bold_first=True)

# ─── SLIDE 18: Validation Agent ─────────────────────────────────
sl = content_slide("/validation-agent \u2014 Phases & Output", "Automated test generation and quality gates", ACCENT_ORANGE)

val_phases = [
    ("1", "Analyze Project", "Read generated code, identify testable surfaces"),
    ("2", "Generate Tests", "Unit tests + integration tests + security tests"),
    ("3", "Execute Tests", "pytest with coverage, ruff lint, mypy type-check"),
    ("4", "Gap Analysis", "Map PRD acceptance criteria \u2192 test coverage"),
    ("5", "Report", "test-results.md + lint-results.md + gaps-analysis.md"),
]
for i, (phase, name, desc) in enumerate(val_phases):
    y = Inches(1.6 + i * 0.9)
    badge = sl.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE,
                                 Inches(0.8), y, Inches(0.6), Inches(0.6))
    badge.fill.solid()
    badge.fill.fore_color.rgb = ACCENT_ORANGE
    badge.line.fill.background()
    tf = badge.text_frame
    tf.vertical_anchor = MSO_ANCHOR.MIDDLE
    p = tf.paragraphs[0]
    p.text = phase
    p.font.size = Pt(12)
    p.font.bold = True
    p.font.color.rgb = WHITE
    p.alignment = PP_ALIGN.CENTER
    add_text(sl, name, Inches(1.7), y, Inches(2.5), Inches(0.6),
             size=13, bold=True, color=CHARCOAL, valign=MSO_ANCHOR.MIDDLE)
    add_text(sl, desc, Inches(4.2), y, Inches(8), Inches(0.6),
             size=12, color=DARK_GRAY, valign=MSO_ANCHOR.MIDDLE)

# Quality gates
card(sl, Inches(0.8), Inches(6.0), Inches(12), Inches(0.8), fill_color=LIGHT_GRAY)
add_text(sl, "Quality Gates:  Coverage > 50%  \u2022  Zero ruff errors  \u2022  mypy --strict passes  \u2022  No OWASP Top 10 gaps",
         Inches(0.8), Inches(6.0), Inches(12), Inches(0.8),
         size=12, bold=True, color=DARK_GRAY, align=PP_ALIGN.CENTER, valign=MSO_ANCHOR.MIDDLE)

# ─── SLIDE 19: Compliance Agent ─────────────────────────────────
sl = content_slide("/compliance-agent \u2014 Phases & Output", "Security scans, OSPDT, SDLE, and unified DASHBOARD", ACCENT_PURPLE)

comp_phases = [
    ("1", "Security Scans", "Bandit (SAST) + detect-secrets + pip-audit + Trivy"),
    ("2", "License Audit", "pip-licenses \u2192 Apache-2.0/MIT/BSD compliance check"),
    ("3", "Architecture Diagrams", "5 Mermaid diagrams (threat model, data flow, etc.)"),
    ("4", "OSPDT Deck", "Auto-generated .pptx for security review board"),
    ("5", "SDLE Artifacts", "Security Development Lifecycle evidence"),
    ("6", "DASHBOARD.md", "Unified status matrix \u2014 one file, full picture"),
]
for i, (phase, name, desc) in enumerate(comp_phases):
    y = Inches(1.6 + i * 0.85)
    badge = sl.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE,
                                 Inches(0.8), y, Inches(0.6), Inches(0.55))
    badge.fill.solid()
    badge.fill.fore_color.rgb = ACCENT_PURPLE
    badge.line.fill.background()
    tf = badge.text_frame
    tf.vertical_anchor = MSO_ANCHOR.MIDDLE
    p = tf.paragraphs[0]
    p.text = phase
    p.font.size = Pt(11)
    p.font.bold = True
    p.font.color.rgb = WHITE
    p.alignment = PP_ALIGN.CENTER
    add_text(sl, name, Inches(1.7), y, Inches(2.5), Inches(0.55),
             size=12, bold=True, color=CHARCOAL, valign=MSO_ANCHOR.MIDDLE)
    add_text(sl, desc, Inches(4.2), y, Inches(8), Inches(0.55),
             size=11, color=DARK_GRAY, valign=MSO_ANCHOR.MIDDLE)

# ─── SLIDE 20: Contract Enforcement ─────────────────────────────
sl = content_slide("Contract Enforcement", "14 rules that prevent frontend-backend integration failures", ACCENT_GREEN)

contracts = [
    ("C1", "List endpoints return {items, total, page, size}"),
    ("C2", "Entity IDs always 'id' (UUID string)"),
    ("C3", "Auth returns {access_token, user: {id, username}}"),
    ("C4", "Frontend types extend BaseEntity {id, created_at, updated_at}"),
    ("C5", "All API paths use /api/v1/ prefix"),
    ("C6", "No SQLAlchemy reserved words (metadata, type, status)"),
    ("C7", "Celery/Redis guarded \u2014 dev mode uses inline processing"),
    ("C8", "UUID as CHAR(36) \u2014 works on SQLite + PostgreSQL"),
    ("C9", "Frontend field names MUST match backend schema exactly"),
    ("C10", "Every frontend call has matching backend endpoint"),
    ("C11", "Dev mode = same code paths, different infra"),
    ("C12", "Output files have download endpoints"),
    ("C13", "Same PRD = same scaffold output (deterministic)"),
    ("C14", "No orphan code \u2014 every file reachable from entry point"),
]
for i, (code, desc) in enumerate(contracts):
    col = i % 2
    row = i // 2
    x = Inches(0.6 + col * 6.4)
    y = Inches(1.6 + row * 0.75)
    add_text(sl, code, x, y, Inches(0.7), Inches(0.6),
             size=10, bold=True, color=ACCENT_GREEN, font=FONT_MONO, valign=MSO_ANCHOR.MIDDLE)
    add_text(sl, desc, Inches(x / Inches(1) + 0.7), y, Inches(5.5), Inches(0.6),
             size=10, color=DARK_GRAY, valign=MSO_ANCHOR.MIDDLE)

# Enforcement note
card(sl, Inches(2.5), Inches(6.5), Inches(8.3), Inches(0.5), fill_color=ACCENT_GREEN)
add_text(sl, "Enforced automatically by Phase 4.5 (Dev Sanity) \u2014 violations auto-fixed up to 3x",
         Inches(2.5), Inches(6.5), Inches(8.3), Inches(0.5),
         size=11, bold=True, color=WHITE, align=PP_ALIGN.CENTER, valign=MSO_ANCHOR.MIDDLE)

# ─── SLIDE 21: Enterprise Inference ─────────────────────────────
sl = content_slide("Enterprise Inference Integration", "How AI models get into your app", ACCENT_GREEN)

# Two strategy cards
# Card 1: Enterprise Inference
card(sl, Inches(0.6), Inches(1.7), Inches(5.8), Inches(4.0), fill_color=WHITE, border_color=ACCENT_CYAN)
add_text(sl, "\u2605 Enterprise Inference (Recommended)", Inches(0.8), Inches(1.8), Inches(5.5), Inches(0.5),
         size=13, bold=True, color=ACCENT_CYAN)
add_multiline(sl, [
    "Intel shared LLM serving platform (OPEA)",
    "",
    "\u2022  OpenAI-compatible /v1/chat/completions",
    "\u2022  Centrally deployed & managed",
    "\u2022  Models: Llama 3.3 70B, Llama 3.1 8B+",
    "\u2022  You deploy EI separately, app connects via REST",
    "",
    "Generated: ei_client.py (async httpx)",
    "\u2022  Auto-retry 429/503",
    "\u2022  Token refresh on 401",
    "\u2022  Mock mode: INFERENCE_API_ENDPOINT=mock://",
], Inches(0.8), Inches(2.3), Inches(5.5), Inches(3.3), size=11, color=DARK_GRAY, spacing=2)

# Card 2: Direct vLLM
card(sl, Inches(6.9), Inches(1.7), Inches(5.8), Inches(4.0), fill_color=WHITE, border_color=ACCENT_ORANGE)
add_text(sl, "Direct vLLM (Self-Contained)", Inches(7.1), Inches(1.8), Inches(5.5), Inches(0.5),
         size=13, bold=True, color=ACCENT_ORANGE)
add_multiline(sl, [
    "You own the full model deployment",
    "",
    "\u2022  vLLM container bundled with your app",
    "\u2022  Helm subchart: deployment, HPA, GPU config",
    "\u2022  Docker Compose includes vLLM service",
    "\u2022  Model download + HuggingFace token setup",
    "",
    "Best for:",
    "\u2022  Edge deployments",
    "\u2022  Custom/fine-tuned models",
    "\u2022  Air-gapped environments",
], Inches(7.1), Inches(2.3), Inches(5.5), Inches(3.3), size=11, color=DARK_GRAY, spacing=2)

# Dev mode callout
card(sl, Inches(0.6), Inches(6.0), Inches(12), Inches(0.8), fill_color=CHARCOAL)
add_text(sl, "DEV MODE:  INFERENCE_API_ENDPOINT=mock://  \u2192  Deterministic responses, no real LLM needed, full pipeline runs",
         Inches(0.6), Inches(6.0), Inches(12), Inches(0.8),
         size=12, bold=True, color=ACCENT_CYAN, align=PP_ALIGN.CENTER, valign=MSO_ANCHOR.MIDDLE)


# ═══════════════════════════════════════════════════════════════════
# SECTION 4: LIVE DEMO - DATASET MAKER
# ═══════════════════════════════════════════════════════════════════

section_divider("4", "Live Demo", "Dataset Maker \u2014 Real Enterprise Inference, Real Results", ACCENT_ORANGE)

# ─── SLIDE 23: Dataset Maker Overview ─────────────────────────────
sl = content_slide("Dataset Maker \u2014 What It Does", "Documents \u2192 High-Quality Instruction-Tuning Datasets", ACCENT_ORANGE)

add_multiline(sl, [
    "INPUT:  Any document (PDF, DOCX, TXT, XLSX, CSV)",
    "",
    "OUTPUT: JSONL dataset for fine-tuning LLMs (ChatML or Alpaca format)",
    "",
    "WHY THIS DEMO (not a simple CRUD app):",
], Inches(0.8), Inches(1.6), Inches(11), Inches(1.8), size=13, color=DARK_GRAY, spacing=4)

# Why cards
why_items = [
    ("\U0001F9E0", "CPU Compute", "PII detection with regex patterns (email, phone, SSN, Intel badge IDs)", ACCENT_CYAN),
    ("\U0001F916", "Multiple EI Calls", "Generation (creates pairs) + Verification (LLM-as-judge)", ACCENT_GREEN),
    ("\U0001F504", "Real Pipeline", "6 stages with progress tracking, not just CRUD", ACCENT_ORANGE),
    ("\U0001F4C2", "File I/O", "Upload \u2192 Process \u2192 Download workflow", ACCENT_PURPLE),
    ("\U0001F5A5\uFE0F", "Full-Stack", "FastAPI backend + React frontend + real inference", ACCENT_TEAL),
]
for i, (icon, title, desc, color) in enumerate(why_items):
    y = Inches(3.5 + i * 0.7)
    accent_bar(sl, color, x=Inches(0.8), y=y, w=Inches(0.08), h=Inches(0.5))
    add_text(sl, title, Inches(1.1), y, Inches(2.2), Inches(0.5),
             size=12, bold=True, color=color, valign=MSO_ANCHOR.MIDDLE)
    add_text(sl, desc, Inches(3.3), y, Inches(9), Inches(0.5),
             size=11, color=DARK_GRAY, valign=MSO_ANCHOR.MIDDLE)

# ─── SLIDE 24: 6-Stage Pipeline Flow ─────────────────────────────
sl = content_slide("Dataset Maker \u2014 6-Stage Pipeline", "Each stage tracked with real-time progress in the UI", ACCENT_ORANGE)

stages = [
    ("1", "PARSE", "CPU", "Extract text from uploaded document", ACCENT_CYAN),
    ("2", "CHUNK", "CPU", "Split into 512-word chunks for processing", ACCENT_CYAN),
    ("3", "PII DETECT", "CPU", "Regex scan: emails, phones, SSNs, Intel IDs", ACCENT_ORANGE),
    ("4", "GENERATE", "EI (LLM)", "Create instruction-response pairs via Llama 3.3 70B", ACCENT_GREEN),
    ("5", "VERIFY", "EI (Judge)", "LLM-as-judge scores quality (threshold: 0.7)", ACCENT_GREEN),
    ("6", "FORMAT", "CPU", "Output as JSONL (ChatML or Alpaca format)", ACCENT_PURPLE),
]
for i, (num, name, compute, desc, color) in enumerate(stages):
    y = Inches(1.6 + i * 0.95)
    # Stage card
    card(sl, Inches(0.6), y, Inches(12), Inches(0.8), fill_color=WHITE, border_color=color)
    # Number
    badge = sl.shapes.add_shape(MSO_SHAPE.OVAL, Inches(0.8), Inches(y / Inches(1) + 0.1),
                                 Inches(0.6), Inches(0.6))
    badge.fill.solid()
    badge.fill.fore_color.rgb = color
    badge.line.fill.background()
    tf = badge.text_frame
    tf.vertical_anchor = MSO_ANCHOR.MIDDLE
    p = tf.paragraphs[0]
    p.text = num
    p.font.size = Pt(12)
    p.font.bold = True
    p.font.color.rgb = WHITE
    p.alignment = PP_ALIGN.CENTER
    # Stage name
    add_text(sl, name, Inches(1.6), y, Inches(2), Inches(0.8),
             size=14, bold=True, color=color, valign=MSO_ANCHOR.MIDDLE)
    # Compute type badge
    add_text(sl, f"[{compute}]", Inches(3.5), y, Inches(1.5), Inches(0.8),
             size=10, bold=True, color=MID_GRAY, valign=MSO_ANCHOR.MIDDLE, font=FONT_MONO)
    # Description
    add_text(sl, desc, Inches(5.2), y, Inches(7), Inches(0.8),
             size=12, color=DARK_GRAY, valign=MSO_ANCHOR.MIDDLE)

# ─── SLIDE 25: Demo Results ─────────────────────────────────────
sl = content_slide("Demo Results \u2014 Real Execution", "Output from Enterprise Inference (Llama 3.3 70B)", ACCENT_ORANGE)

# Input card
card(sl, Inches(0.6), Inches(1.6), Inches(5.5), Inches(1.2), fill_color=LIGHT_GRAY)
add_text(sl, "INPUT", Inches(0.8), Inches(1.7), Inches(1.5), Inches(0.4),
         size=10, bold=True, color=MID_GRAY)
add_text(sl, "intel-xeon-technical-doc.txt", Inches(0.8), Inches(2.0), Inches(5), Inches(0.4),
         size=13, bold=True, color=CHARCOAL)
add_text(sl, "1.6 KB  \u2022  245 words  \u2022  1 chunk", Inches(0.8), Inches(2.4), Inches(5), Inches(0.3),
         size=10, color=MID_GRAY)

# Results cards
results = [
    ("\u2713 PII Detected", "3 findings", "support@intel.com \u2192 [REDACTED]\n1-800-555-0199 \u2192 [REDACTED]\nINTL-12345 \u2192 [REDACTED]", ACCENT_ORANGE),
    ("\u2713 Pairs Generated", "3 pairs", "High-quality instruction-response\npairs from document content\nvia Llama 3.3 70B", ACCENT_GREEN),
    ("\u2713 Verified", "3/3 passed", "Average quality score: 0.91\nThreshold: 0.7\nAll pairs production-ready", ACCENT_CYAN),
]
for i, (title, metric, details, color) in enumerate(results):
    x = Inches(0.6 + i * 4.3)
    y = Inches(3.2)
    card(sl, x, y, Inches(4.0), Inches(3.0), fill_color=WHITE, border_color=color)
    add_text(sl, title, x, Inches(3.3), Inches(4.0), Inches(0.4),
             size=11, bold=True, color=color, align=PP_ALIGN.CENTER)
    add_text(sl, metric, x, Inches(3.7), Inches(4.0), Inches(0.6),
             size=22, bold=True, color=CHARCOAL, align=PP_ALIGN.CENTER)
    add_multiline(sl, details.split("\n"), Inches(x / Inches(1) + 0.3), Inches(4.5),
                  Inches(3.5), Inches(1.5), size=10, color=DARK_GRAY, spacing=3)

# Output
card(sl, Inches(6.5), Inches(1.6), Inches(6.2), Inches(1.2), fill_color=CHARCOAL)
add_text(sl, "OUTPUT:  dataset.jsonl  (ChatML format) \u2014 Ready for fine-tuning",
         Inches(6.5), Inches(1.6), Inches(6.2), Inches(1.2),
         size=12, bold=True, color=ACCENT_GREEN, align=PP_ALIGN.CENTER, valign=MSO_ANCHOR.MIDDLE)

# ─── SLIDE 26: Dataset Maker Frontend ─────────────────────────────
sl = content_slide("Dataset Maker \u2014 Frontend UI", "React + TanStack Query + Real-Time Pipeline Progress", ACCENT_ORANGE)

# UI description cards
ui_pages = [
    ("Job List", "Table view with status badges, pipeline stages, pair counts,\nPII detections, model info, and timestamps", ACCENT_CYAN),
    ("Upload Form", "Drag-and-drop file upload, model selection\n(Llama 3.3 70B default), output format, chunk config", ACCENT_GREEN),
    ("Job Detail", "6-stage progress visualization with animated spinner\nfor active stage, quality metrics, download button", ACCENT_ORANGE),
]
for i, (page, desc, color) in enumerate(ui_pages):
    y = Inches(1.7 + i * 1.7)
    card(sl, Inches(0.6), y, Inches(7.5), Inches(1.5), fill_color=WHITE, border_color=color)
    add_text(sl, page, Inches(0.9), y, Inches(3), Inches(0.5),
             size=14, bold=True, color=color)
    add_multiline(sl, desc.split("\n"), Inches(0.9), Inches(y / Inches(1) + 0.5),
                  Inches(7), Inches(1.0), size=11, color=DARK_GRAY, spacing=3)

# Tech stack card
card(sl, Inches(8.5), Inches(1.7), Inches(4.2), Inches(5.0), fill_color=LIGHT_GRAY)
add_multiline(sl, [
    "TECH STACK:",
    "",
    "React 19 + TypeScript",
    "TanStack Query (auto-refetch)",
    "Tailwind CSS + shadcn/ui",
    "Vite dev server + proxy",
    "Zustand state management",
    "",
    "REAL-TIME FEATURES:",
    "",
    "Job list: polls every 5s",
    "Job detail: polls every 2s",
    "Progress: stage-by-stage",
    "Auto-stop on completion",
], Inches(8.7), Inches(1.9), Inches(4.0), Inches(4.8),
    size=10, color=DARK_GRAY, spacing=2, bold_first=True)


# ═══════════════════════════════════════════════════════════════════
# SECTION 5: HANDS-ON WORKSHOP
# ═══════════════════════════════════════════════════════════════════

section_divider("5", "Hands-On Workshop", "45 Minutes \u2014 Generate Your Own Project from PRD", ACCENT_PURPLE)

# ─── SLIDE 28: Prerequisites ─────────────────────────────────────
sl = content_slide("Workshop Setup", "Prerequisites and environment preparation", ACCENT_PURPLE)

# Prerequisites card
card(sl, Inches(0.6), Inches(1.6), Inches(6.0), Inches(2.5), fill_color=WHITE, border_color=ACCENT_PURPLE)
add_text(sl, "PREREQUISITES", Inches(0.8), Inches(1.7), Inches(5.5), Inches(0.4),
         size=12, bold=True, color=ACCENT_PURPLE)
add_multiline(sl, [
    "\u2022  Python 3.11+ installed",
    "\u2022  Node.js 18+ installed",
    "\u2022  Git installed and configured",
    "\u2022  Claude Code CLI (claude command)",
    "\u2022  pip install pyyaml ruff",
    "\u2022  Intel VPN connected (for EI access)",
], Inches(0.8), Inches(2.2), Inches(5.5), Inches(1.8), size=12, color=DARK_GRAY, spacing=4)

# Setup steps card
card(sl, Inches(6.9), Inches(1.6), Inches(5.8), Inches(2.5), fill_color=CHARCOAL)
add_text(sl, "SETUP COMMANDS", Inches(7.1), Inches(1.7), Inches(5.5), Inches(0.4),
         size=12, bold=True, color=ACCENT_CYAN)
add_multiline(sl, [
    "git clone https://github.com/",
    "  intel-sandbox/intel-ai-dev-template",
    "",
    "cd intel-ai-dev-template",
    "git checkout v1",
    "",
    "# Start Claude Code",
    "claude",
], Inches(7.1), Inches(2.2), Inches(5.5), Inches(1.8),
    size=11, color=ACCENT_CYAN, font=FONT_MONO, spacing=3)

# Activity steps
add_text(sl, "WORKSHOP ACTIVITY", Inches(0.8), Inches(4.4), Inches(11), Inches(0.4),
         size=14, bold=True, color=ACCENT_PURPLE)

steps = [
    ("1", "Start Claude Code in the repo directory"),
    ("2", "Type: /dev-agent"),
    ("3", "Point to PRD: docs/prd/dataset-maker-agent-technical.md"),
    ("4", "Choose output directory (any folder outside this repo)"),
    ("5", "Watch scaffold.py generate 151 files in 3 seconds"),
    ("6", "Watch LLM generate pipeline-specific code (endpoints, models)"),
    ("7", "Verify: backend starts, curl healthz, curl /api/v1/jobs"),
]
for i, (num, step) in enumerate(steps):
    y = Inches(4.9 + i * 0.35)
    add_text(sl, f"  {num}.", Inches(0.8), y, Inches(0.5), Inches(0.3),
             size=11, bold=True, color=ACCENT_PURPLE)
    add_text(sl, step, Inches(1.5), y, Inches(11), Inches(0.3),
             size=11, color=DARK_GRAY)

# ─── SLIDE 29: What to Explore ─────────────────────────────────────
sl = content_slide("After Generation \u2014 Explore & Extend", "What to look at once your project is running", ACCENT_PURPLE)

# API testing
card(sl, Inches(0.6), Inches(1.6), Inches(6.0), Inches(2.8), fill_color=CHARCOAL)
add_text(sl, "TEST THE API", Inches(0.8), Inches(1.7), Inches(5.5), Inches(0.4),
         size=11, bold=True, color=ACCENT_CYAN)
add_multiline(sl, [
    "# Health check",
    "curl http://localhost:8000/healthz",
    "",
    "# List jobs (empty)",
    "curl http://localhost:8000/api/v1/jobs",
    "",
    "# Upload document",
    "curl -X POST -F 'file=@doc.txt' \\",
    "  http://localhost:8000/api/v1/jobs",
    "",
    "# Download result",
    "curl http://localhost:8000/api/v1/jobs/{id}/download",
], Inches(0.8), Inches(2.1), Inches(5.5), Inches(2.3),
    size=10, color=ACCENT_CYAN, font=FONT_MONO, spacing=2)

# Key files to explore
card(sl, Inches(6.9), Inches(1.6), Inches(5.8), Inches(2.8), fill_color=WHITE, border_color=LIGHT_GRAY)
add_text(sl, "KEY FILES TO EXPLORE", Inches(7.1), Inches(1.7), Inches(5.5), Inches(0.4),
         size=11, bold=True, color=ACCENT_PURPLE)
add_multiline(sl, [
    "src/*/app/services/pipeline.py",
    "  \u2192 6-stage pipeline orchestration",
    "",
    "src/*/app/inference/ei_client.py",
    "  \u2192 Enterprise Inference client",
    "",
    "src/*/app/models/db.py",
    "  \u2192 SQLAlchemy async models",
    "",
    "frontend/src/features/jobs/",
    "  \u2192 React components (list, form, detail)",
    "",
    "helm/*/values.yaml",
    "  \u2192 Kubernetes configuration",
], Inches(7.1), Inches(2.1), Inches(5.5), Inches(2.3), size=10, color=DARK_GRAY, spacing=2)

# Next steps
add_text(sl, "NEXT STEPS", Inches(0.8), Inches(4.7), Inches(11), Inches(0.4),
         size=14, bold=True, color=ACCENT_PURPLE)
next_steps = [
    ("/validation-agent", "Auto-generate tests + run coverage"),
    ("/compliance-agent", "Security scans + DASHBOARD.md"),
    ("/prd-agent (YOUR idea)", "Try the full pipeline from scratch with your own project"),
    ("Compare outputs", "Same PRD = same scaffold (deterministic guarantee)"),
]
for i, (cmd, desc) in enumerate(next_steps):
    y = Inches(5.2 + i * 0.5)
    add_text(sl, cmd, Inches(1.0), y, Inches(3.5), Inches(0.4),
             size=11, bold=True, color=ACCENT_PURPLE, font=FONT_MONO)
    add_text(sl, desc, Inches(4.5), y, Inches(8), Inches(0.4),
             size=11, color=DARK_GRAY)


# ═══════════════════════════════════════════════════════════════════
# CLOSING SLIDES
# ═══════════════════════════════════════════════════════════════════

# ─── SLIDE 30: Key Takeaways ─────────────────────────────────────
sl = blank_slide()
fill_bg(sl, INTEL_DARK)
accent_bar(sl, ACCENT_CYAN, y=Inches(0), h=Inches(0.08))

add_text(sl, "Key Takeaways", Inches(0.8), Inches(0.5), Inches(10), Inches(0.8),
         size=32, bold=True, color=WHITE, font=FONT_HEADING)

takeaways = [
    ("1", "FOUR COMMANDS REPLACE 12 WEEKS", "/prd \u2192 /dev \u2192 /validation \u2192 /compliance", ACCENT_CYAN),
    ("2", "HYBRID = DETERMINISTIC + CREATIVE", "scaffold.py (fast, 100%) + LLM (smart, focused)", ACCENT_GREEN),
    ("3", "STANDARDS ARE THE PRODUCT", "Fix template once \u2192 all future projects benefit", ACCENT_ORANGE),
    ("4", "BORN COMPLIANT", "Security, OSPDT, SDLE satisfied from day one", ACCENT_PURPLE),
]
for i, (num, title, desc, color) in enumerate(takeaways):
    y = Inches(1.8 + i * 1.35)
    # Number circle
    icon_circle(sl, Inches(0.8), y, Inches(0.8), color, num)
    # Title
    add_text(sl, title, Inches(1.9), y, Inches(10), Inches(0.5),
             size=18, bold=True, color=WHITE)
    # Description
    add_text(sl, desc, Inches(1.9), Inches(y / Inches(1) + 0.55), Inches(10), Inches(0.4),
             size=13, color=MID_GRAY)

slide_number(sl, len(prs.slides))

# ─── SLIDE 31: Resources & Contact ─────────────────────────────────
sl = blank_slide()
fill_bg(sl, INTEL_DARK)
accent_bar(sl, ACCENT_CYAN, y=Inches(0), h=Inches(0.08))

add_text(sl, "Resources & Contact", Inches(0.8), Inches(0.5), Inches(10), Inches(0.8),
         size=32, bold=True, color=WHITE, font=FONT_HEADING)

# Resources
resources = [
    ("Repository", "https://github.com/intel-sandbox/intel-ai-dev-template"),
    ("Branch", "v1"),
    ("Workshop PRD", "docs/prd/dataset-maker-agent-technical.md"),
    ("Enterprise Inference", "https://github.com/opea-project/Enterprise-Inference"),
    ("Enterprise RAG", "https://github.com/opea-project/Enterprise-RAG"),
]
for i, (label, value) in enumerate(resources):
    y = Inches(1.8 + i * 0.6)
    add_text(sl, label, Inches(0.8), y, Inches(3), Inches(0.5),
             size=13, bold=True, color=ACCENT_CYAN)
    add_text(sl, value, Inches(3.8), y, Inches(9), Inches(0.5),
             size=12, color=WHITE, font=FONT_MONO)

# Contact
add_text(sl, "Contact", Inches(0.8), Inches(5.0), Inches(10), Inches(0.5),
         size=16, bold=True, color=ACCENT_CYAN)
add_text(sl, "Vivek RS  |  Data Center AI Software Engineering  |  #dcai-dev-pipeline",
         Inches(0.8), Inches(5.5), Inches(10), Inches(0.5),
         size=14, color=WHITE)

# Big Q
add_text(sl, "Questions?", Inches(0.8), Inches(6.4), Inches(10), Inches(0.8),
         size=28, bold=True, color=ACCENT_AMBER)

slide_number(sl, len(prs.slides))

# ═══════════════════════════════════════════════════════════════════
# SAVE
# ═══════════════════════════════════════════════════════════════════

out_path = "C:/Users/vivekrs/.claude/intel-ai-solutions-dev/docs/presentations/Intel_AI_Dev_Pipeline_Workshop.pptx"
prs.save(out_path)
print(f"Created: {out_path}")
print(f"Total slides: {len(prs.slides)}")
