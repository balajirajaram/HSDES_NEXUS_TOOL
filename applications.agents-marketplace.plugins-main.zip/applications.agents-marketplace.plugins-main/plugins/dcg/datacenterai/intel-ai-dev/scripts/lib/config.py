# Copyright (C) 2026 Intel Corporation
# SPDX-License-Identifier: Apache-2.0

import os


class PipelineConfig:
    """Centralized configuration from environment variables."""

    @property
    def wiki_base_url(self) -> str:
        return os.environ.get("WIKI_BASE_URL", "https://wiki.ith.intel.com")

    @property
    def wiki_pat(self) -> str:
        val = os.environ.get("WIKI_PAT", "")
        if not val:
            print("WARNING: WIKI_PAT not set — Wiki operations will fail")
        return val

    @property
    def jira_base_url(self) -> str:
        return os.environ.get("JIRA_BASE_URL", "https://jira.devtools.intel.com")

    @property
    def jira_pat(self) -> str:
        val = os.environ.get("JIRA_PAT", "")
        if not val:
            print("WARNING: JIRA_PAT not set — Jira operations will fail")
        return val

    @property
    def github_org(self) -> str:
        return os.environ.get("GITHUB_ORG", "intel-sandbox")

    @property
    def no_proxy(self) -> str:
        return os.environ.get(
            "NO_PROXY",
            "wiki.ith.intel.com,jira.devtools.intel.com,*.intel.com",
        )


config = PipelineConfig()
