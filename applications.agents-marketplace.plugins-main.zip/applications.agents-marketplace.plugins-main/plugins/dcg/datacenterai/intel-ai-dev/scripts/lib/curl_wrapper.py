# Copyright (C) 2026 Intel Corporation
# SPDX-License-Identifier: Apache-2.0

import json
import platform
import subprocess
from typing import Any


def _curl_bin() -> str:
    # Windows PowerShell aliases curl to Invoke-WebRequest; use curl.exe explicitly
    return "curl.exe" if platform.system() == "Windows" else "curl"


def curl_request(
    url: str,
    method: str = "GET",
    headers: dict[str, str] | None = None,
    data: str | None = None,
    timeout: int = 30,
) -> tuple[int, str]:
    """Execute HTTP request via curl, bypassing Intel F5 BigIP gateway.

    Returns (status_code, response_body).
    """
    cmd = [
        _curl_bin(),
        "-sk",
        "--noproxy", "*",
        "-X", method,
        "--max-time", str(timeout),
        "-w", "\n%{http_code}",
    ]

    if headers:
        for key, value in headers.items():
            cmd.extend(["-H", f"{key}: {value}"])

    if data:
        cmd.extend(["-d", data])
        if "Content-Type" not in (headers or {}):
            cmd.extend(["-H", "Content-Type: application/json"])

    cmd.append(url)

    try:
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=timeout + 5,
        )
        output = result.stdout.strip()
        lines = output.rsplit("\n", 1)
        if len(lines) == 2:
            body, code_str = lines
            status_code = int(code_str)
        else:
            body = output
            status_code = 0

        if result.returncode != 0 and status_code == 0:
            print(f"WARNING: curl failed: {result.stderr.strip()}")
            return 0, result.stderr.strip()

        return status_code, body

    except subprocess.TimeoutExpired:
        print(f"WARNING: curl timed out after {timeout}s for {url}")
        return 0, "timeout"
    except FileNotFoundError:
        print("ERROR: curl not found. Install curl or ensure it's in PATH.")
        return 0, "curl not found"


def curl_json(
    url: str,
    method: str = "GET",
    headers: dict[str, str] | None = None,
    data: Any = None,
    timeout: int = 30,
) -> tuple[int, Any]:
    """Execute request and parse JSON response."""
    payload = json.dumps(data) if data and not isinstance(data, str) else data
    status, body = curl_request(url, method, headers, payload, timeout)
    try:
        parsed = json.loads(body) if body else {}
    except json.JSONDecodeError:
        parsed = {"raw": body}
    return status, parsed
