# Copyright (C) 2026 Intel Corporation
# SPDX-License-Identifier: Apache-2.0

"""Generate SDLE Mermaid diagrams from project component discovery."""

from pathlib import Path


def _write_diagram(content: str, output_path: str) -> str:
    Path(output_path).parent.mkdir(parents=True, exist_ok=True)
    Path(output_path).write_text(content, encoding="utf-8")
    return output_path


def generate_threat_model(
    project_name: str,
    components: list[str],
    output_path: str,
) -> str:
    """Generate threat model diagram as Mermaid markdown."""
    lines = [
        f"# Threat Model — {project_name}",
        "",
        "## Architecture",
        "",
        "```mermaid",
        "graph TD",
        '    User["External User"]:::external',
    ]

    for comp in components:
        cid = comp.replace("-", "_").replace(" ", "_")
        lines.append(f'    {cid}["{comp}"]')

    lines.append('    DB[("PostgreSQL")]')
    lines.append('    Cache[("Redis")]')
    lines.append("")
    lines.append("    User --> |HTTPS| API_Gateway")

    for comp in components:
        cid = comp.replace("-", "_").replace(" ", "_")
        lines.append(f"    API_Gateway --> {cid}")

    for comp in components:
        cid = comp.replace("-", "_").replace(" ", "_")
        lines.append(f"    {cid} --> DB")
        lines.append(f"    {cid} --> Cache")

    lines.extend([
        "",
        "    classDef external fill:#f96,stroke:#333,stroke-width:2px",
        "```",
        "",
        "## Trust Boundaries",
        "",
        "| Boundary | Components | Classification |",
        "|----------|-----------|----------------|",
        "| External | User, API Gateway | Untrusted |",
    ])

    for comp in components:
        lines.append(f"| Internal | {comp} | Trusted |")

    lines.append("| Data | PostgreSQL, Redis | Restricted |")
    lines.extend([
        "",
        "## STRIDE Analysis",
        "",
        "| Threat | Component | Risk | Mitigation |",
        "|--------|-----------|------|------------|",
        "| Spoofing | API Gateway | HIGH | JWT validation, mTLS |",
        "| Tampering | Database | MEDIUM | Input validation, parameterized queries |",
        "| Repudiation | All services | LOW | Structured audit logging |",
        "| Information Disclosure | API responses | MEDIUM | Response filtering, RBAC |",
        "| Denial of Service | API Gateway | HIGH | Rate limiting, HPA |",
        "| Elevation of Privilege | Auth service | HIGH | RBAC, principle of least privilege |",
    ])

    return _write_diagram("\n".join(lines), output_path)


def generate_data_flow(
    project_name: str,
    components: list[str],
    output_path: str,
) -> str:
    """Generate data flow diagram."""
    lines = [
        f"# Data Flow — {project_name}",
        "",
        "## Level 0: Context Diagram",
        "",
        "```mermaid",
        "flowchart LR",
        '    User(("User")) --> |API Request| System["' + project_name + '"]',
        '    System --> |Response| User',
        '    System --> |Persist| DB[("PostgreSQL")]',
        '    System --> |Cache| Redis[("Redis")]',
        "```",
        "",
        "## Level 1: Component Interactions",
        "",
        "```mermaid",
        "flowchart LR",
    ]

    for comp in components:
        cid = comp.replace("-", "_").replace(" ", "_")
        lines.append(f'    {cid}["{comp}"]')

    lines.append('    DB[("PostgreSQL")]')
    lines.append('    Cache[("Redis")]')
    lines.append("")

    for i, comp in enumerate(components):
        cid = comp.replace("-", "_").replace(" ", "_")
        lines.append(f"    {cid} -->|SQL| DB")
        lines.append(f"    {cid} -->|GET/SET| Cache")
        if i > 0:
            prev_cid = components[i - 1].replace("-", "_").replace(" ", "_")
            lines.append(f"    {prev_cid} -->|Internal API| {cid}")

    lines.extend([
        "```",
        "",
        "## Data Classification",
        "",
        "| Data Type | Classification | Storage | Encryption |",
        "|-----------|---------------|---------|------------|",
        "| User credentials | Restricted | PostgreSQL | bcrypt hashed |",
        "| API tokens | Confidential | Redis (TTL) | JWT signed |",
        "| Business data | Internal | PostgreSQL | At-rest (AES-256) |",
        "| Logs | Internal | Stdout/OTEL | In-transit (TLS) |",
    ])

    return _write_diagram("\n".join(lines), output_path)


def generate_component_architecture(
    project_name: str,
    components: list[str],
    has_frontend: bool,
    output_path: str,
) -> str:
    """Generate component architecture diagram."""
    lines = [
        f"# Component Architecture — {project_name}",
        "",
        "```mermaid",
        "graph TB",
    ]

    if has_frontend:
        lines.append('    subgraph presentation["Presentation Layer"]')
        lines.append('        Frontend["Frontend (React + Vite)"]')
        lines.append("    end")
        lines.append("")

    lines.append('    subgraph application["Application Layer"]')
    for comp in components:
        cid = comp.replace("-", "_").replace(" ", "_")
        lines.append(f'        {cid}["{comp}<br/>(FastAPI)"]')
    lines.append("    end")
    lines.append("")

    lines.append('    subgraph data["Data Layer"]')
    lines.append('        DB[("PostgreSQL")]')
    lines.append('        Cache[("Redis")]')
    lines.append("    end")
    lines.append("")

    lines.append('    subgraph observability["Observability"]')
    lines.append('        Prometheus["Prometheus"]')
    lines.append('        OTEL["OpenTelemetry Collector"]')
    lines.append("    end")
    lines.append("")

    if has_frontend:
        lines.append("    Frontend --> application")

    for comp in components:
        cid = comp.replace("-", "_").replace(" ", "_")
        lines.append(f"    {cid} --> DB")
        lines.append(f"    {cid} --> Cache")
        lines.append(f"    {cid} -.-> Prometheus")
        lines.append(f"    {cid} -.-> OTEL")

    lines.extend(["```", ""])

    lines.extend([
        "## Communication Patterns",
        "",
        "| From | To | Protocol | Pattern |",
        "|------|----|----------|---------|",
    ])

    if has_frontend:
        lines.append("| Frontend | Backend | HTTPS | REST (sync) |")

    for comp in components:
        lines.append(f"| {comp} | PostgreSQL | TCP/5432 | Async SQLAlchemy |")
        lines.append(f"| {comp} | Redis | TCP/6379 | Async (cache/queue) |")

    return _write_diagram("\n".join(lines), output_path)


def generate_deployment_diagram(
    project_name: str,
    components: list[str],
    has_frontend: bool,
    output_path: str,
) -> str:
    """Generate deployment architecture diagram."""
    lines = [
        f"# Deployment Architecture — {project_name}",
        "",
        "```mermaid",
        "graph TB",
        '    subgraph ingress["Ingress"]',
        '        LB["Load Balancer"]',
        "    end",
        "",
        f'    subgraph namespace["{project_name} Namespace"]',
    ]

    if has_frontend:
        lines.append('        FE["Frontend<br/>replicas: 2"]')

    for comp in components:
        cid = comp.replace("-", "_").replace(" ", "_")
        lines.append(f'        {cid}["{comp}<br/>replicas: 2"]')

    lines.extend([
        "    end",
        "",
        '    subgraph data["Managed Services"]',
        '        PG[("PostgreSQL<br/>HA cluster")]',
        '        RD[("Redis<br/>Sentinel")]',
        "    end",
        "",
    ])

    if has_frontend:
        lines.append("    LB --> FE")
    lines.append("    LB --> namespace")

    for comp in components:
        cid = comp.replace("-", "_").replace(" ", "_")
        lines.append(f"    {cid} --> PG")
        lines.append(f"    {cid} --> RD")

    lines.extend([
        "```",
        "",
        "## Resource Allocation",
        "",
        "| Component | CPU Request | CPU Limit | Memory Request | Memory Limit |",
        "|-----------|-------------|-----------|----------------|--------------|",
    ])

    if has_frontend:
        lines.append("| Frontend | 100m | 500m | 128Mi | 256Mi |")

    for comp in components:
        lines.append(f"| {comp} | 250m | 1000m | 256Mi | 512Mi |")

    lines.extend([
        "| PostgreSQL | 500m | 2000m | 512Mi | 2Gi |",
        "| Redis | 100m | 500m | 128Mi | 256Mi |",
    ])

    return _write_diagram("\n".join(lines), output_path)
