# Copyright (C) 2026 Intel Corporation
# SPDX-License-Identifier: Apache-2.0

import subprocess
from pathlib import Path

from .config import config


def _run(cmd: list[str], cwd: str | None = None) -> tuple[int, str]:
    result = subprocess.run(cmd, capture_output=True, text=True, cwd=cwd)
    output = result.stdout.strip()
    if result.returncode != 0:
        output = result.stderr.strip() or output
    return result.returncode, output


def init_repo(path: str) -> bool:
    """Initialize a git repository."""
    code, out = _run(["git", "init"], cwd=path)
    if code != 0:
        print(f"WARNING: git init failed: {out}")
        return False
    _run(["git", "checkout", "-b", "main"], cwd=path)
    return True


def create_branch(branch_name: str, cwd: str | None = None) -> bool:
    """Create and checkout a new branch."""
    code, out = _run(["git", "checkout", "-b", branch_name], cwd=cwd)
    if code != 0:
        print(f"WARNING: git checkout -b {branch_name} failed: {out}")
        return False
    return True


def commit_and_push(
    message: str,
    branch: str = "main",
    cwd: str | None = None,
) -> bool:
    """Stage all changes, commit, and push."""
    code, out = _run(["git", "add", "-A"], cwd=cwd)
    if code != 0:
        print(f"WARNING: git add failed: {out}")
        return False

    code, out = _run(["git", "commit", "-m", message], cwd=cwd)
    if code != 0:
        print(f"WARNING: git commit failed: {out}")
        return False

    code, out = _run(["git", "push", "-u", "origin", branch], cwd=cwd)
    if code != 0:
        print(f"WARNING: git push failed: {out}")
        return False

    return True


def create_and_push(
    path: str,
    remote_url: str,
    branch: str = "main",
    commit_message: str = "Initial commit",
) -> bool:
    """Initialize repo, add remote, commit all, and push."""
    if not init_repo(path):
        return False

    code, out = _run(["git", "remote", "add", "origin", remote_url], cwd=path)
    if code != 0:
        print(f"WARNING: git remote add failed: {out}")
        return False

    return commit_and_push(commit_message, branch, cwd=path)


def get_remote_url(org: str | None = None, repo_name: str = "") -> str:
    """Build GitHub remote URL."""
    org = org or config.github_org
    return f"https://github.com/{org}/{repo_name}.git"
