# Copyright (C) 2026 Intel Corporation
# SPDX-License-Identifier: Apache-2.0

from typing import Any

from .config import config
from .curl_wrapper import curl_json


def _headers() -> dict[str, str]:
    return {
        "Authorization": f"Bearer {config.jira_pat}",
        "Content-Type": "application/json",
        "Accept": "application/json",
    }


def _api(path: str) -> str:
    return f"{config.jira_base_url}/rest/api/2{path}"


def _agile_api(path: str) -> str:
    return f"{config.jira_base_url}/rest/agile/1.0{path}"


def get_project_components(project_key: str) -> list[dict[str, Any]]:
    """Fetch available components for a project."""
    status, data = curl_json(_api(f"/project/{project_key}/components"), headers=_headers())
    if status != 200:
        print(f"WARNING: Failed to fetch components: {status}")
        return []
    return data if isinstance(data, list) else []


def get_project_versions(project_key: str) -> list[dict[str, Any]]:
    """Fetch available versions (fix versions / sprints) for a project."""
    status, data = curl_json(_api(f"/project/{project_key}/versions"), headers=_headers())
    if status != 200:
        print(f"WARNING: Failed to fetch versions: {status}")
        return []
    return [v for v in data if not v.get("released", False)] if isinstance(data, list) else []


def assign_to_sprint(sprint_id: int, issue_keys: list[str]) -> bool:
    """Move issues into a sprint via the Agile API."""
    payload = {"issues": issue_keys}
    status, _ = curl_json(
        _agile_api(f"/sprint/{sprint_id}/issue"),
        method="POST",
        headers=_headers(),
        data=payload,
    )
    if status not in (200, 204):
        print(f"WARNING: Sprint assignment returned {status}")
        return False
    return True


def create_epic(
    project_key: str,
    summary: str,
    description: str,
    assignee: str | None = None,
    components: list[str] | None = None,
    fix_version_id: str | None = None,
) -> dict[str, Any]:
    """Create a Jira EPIC.

    Args:
        project_key: Jira project key (e.g., DCAIDSE8)
        summary: Epic title
        description: Epic description
        assignee: Intel IDSID of the assignee (e.g., vivekrs)
        components: List of component IDs
        fix_version_id: Fix version ID for scheduling
    """
    payload: dict[str, Any] = {
        "fields": {
            "project": {"key": project_key},
            "summary": summary,
            "description": description,
            "issuetype": {"name": "Epic"},
            "customfield_11901": summary,  # Epic Name field (DCAIDSE8)
        }
    }
    if assignee:
        payload["fields"]["assignee"] = {"name": assignee}
    if components:
        payload["fields"]["components"] = [{"id": c} for c in components]
    if fix_version_id:
        payload["fields"]["fixVersions"] = [{"id": fix_version_id}]

    status, data = curl_json(_api("/issue"), method="POST", headers=_headers(), data=payload)
    if status not in (200, 201):
        print(f"WARNING: Jira create_epic returned {status}: {data}")
    else:
        print(f"Created EPIC: {data.get('key', 'unknown')}")
    return data


def create_story(
    project_key: str,
    summary: str,
    description: str,
    epic_key: str | None = None,
    assignee: str | None = None,
    components: list[str] | None = None,
    fix_version_id: str | None = None,
    story_points: int | None = None,
    acceptance_criteria: str | None = None,
) -> dict[str, Any]:
    """Create a Jira Story, optionally linked to an EPIC.

    Args:
        project_key: Jira project key (e.g., DCAIDSE8)
        summary: Story title
        description: Story description
        epic_key: Parent epic key (e.g., DCAIDSE8-1676)
        assignee: Intel IDSID of the assignee
        components: List of component IDs
        fix_version_id: Fix version ID for scheduling
        story_points: Estimated story points
        acceptance_criteria: Acceptance criteria text
    """
    payload: dict[str, Any] = {
        "fields": {
            "project": {"key": project_key},
            "summary": summary,
            "description": description,
            "issuetype": {"name": "Story"},
        }
    }
    if epic_key:
        payload["fields"]["customfield_11900"] = epic_key  # Epic Link (DCAIDSE8)
    if assignee:
        payload["fields"]["assignee"] = {"name": assignee}
    if components:
        payload["fields"]["components"] = [{"id": c} for c in components]
    if fix_version_id:
        payload["fields"]["fixVersions"] = [{"id": fix_version_id}]
    if story_points:
        payload["fields"]["customfield_11204"] = story_points  # Story Points (DCAIDSE8)
    if acceptance_criteria:
        payload["fields"]["customfield_11609"] = acceptance_criteria  # AC (DCAIDSE8)

    status, data = curl_json(_api("/issue"), method="POST", headers=_headers(), data=payload)
    if status not in (200, 201):
        print(f"WARNING: Jira create_story returned {status}: {data}")
    else:
        print(f"Created Story: {data.get('key', 'unknown')}")
    return data


def add_comment(issue_key: str, comment_body: str) -> dict[str, Any]:
    """Add a comment to a Jira issue."""
    payload = {"body": comment_body}
    status, data = curl_json(
        _api(f"/issue/{issue_key}/comment"),
        method="POST",
        headers=_headers(),
        data=payload,
    )
    if status not in (200, 201):
        print(f"WARNING: Jira add_comment {issue_key} returned {status}")
    return data


def transition_issue(issue_key: str, transition_id: str) -> bool:
    """Transition an issue to a new status."""
    payload = {"transition": {"id": transition_id}}
    status, _ = curl_json(
        _api(f"/issue/{issue_key}/transitions"),
        method="POST",
        headers=_headers(),
        data=payload,
    )
    if status != 204:
        print(f"WARNING: Jira transition {issue_key} returned {status}")
        return False
    return True


def search_issues(jql: str, max_results: int = 50) -> list[dict[str, Any]]:
    """Search issues via JQL."""
    payload = {"jql": jql, "maxResults": max_results}
    status, data = curl_json(
        _api("/search"),
        method="POST",
        headers=_headers(),
        data=payload,
    )
    if status != 200:
        print(f"WARNING: Jira search returned {status}")
        return []
    return data.get("issues", [])
