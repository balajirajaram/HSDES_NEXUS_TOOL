# Copyright (C) 2026 Intel Corporation
# SPDX-License-Identifier: Apache-2.0

import re
from pathlib import Path
from typing import Any


def parse_prd(prd_path: str) -> dict[str, Any]:
    """Parse a Technical PRD markdown into structured data.

    Returns dict with: project_name, description, components, features,
    tech_requirements, security_classification.
    """
    text = Path(prd_path).read_text(encoding="utf-8")

    result: dict[str, Any] = {
        "project_name": "",
        "description": "",
        "components": [],
        "features": [],
        "tech_requirements": {},
        "security_classification": "internal",
        "raw_sections": {},
    }

    frontmatter, body = _extract_frontmatter(text)
    result.update(frontmatter)

    sections = _parse_sections(body)
    result["raw_sections"] = sections

    if not result["project_name"]:
        result["project_name"] = _extract_title(body)

    if not result["description"]:
        for key in ["overview", "description", "summary", "executive summary"]:
            if key in sections:
                result["description"] = sections[key]["content"].strip()
                break

    for key in ["components", "microservices", "services", "architecture components"]:
        if key in sections:
            result["components"] = _parse_component_list(sections[key])
            break

    for key in ["features", "user stories", "functional requirements", "requirements"]:
        if key in sections:
            result["features"] = _parse_feature_list(sections[key])
            break

    for key in ["technical requirements", "tech stack", "technology stack", "technical stack"]:
        if key in sections:
            result["tech_requirements"] = _parse_kv_list(sections[key])
            break

    for key in ["security", "security classification", "security requirements"]:
        if key in sections:
            content = sections[key]["content"].lower()
            if "confidential" in content:
                result["security_classification"] = "confidential"
            elif "public" in content:
                result["security_classification"] = "public"
            break

    return result


def _extract_frontmatter(text: str) -> tuple[dict[str, Any], str]:
    """Extract YAML frontmatter if present."""
    if not text.startswith("---"):
        return {}, text

    end = text.find("---", 3)
    if end == -1:
        return {}, text

    fm_text = text[3:end].strip()
    body = text[end + 3:].strip()

    meta: dict[str, Any] = {}
    for line in fm_text.split("\n"):
        if ":" in line:
            key, _, value = line.partition(":")
            meta[key.strip().lower().replace(" ", "_")] = value.strip()

    return meta, body


def _extract_title(body: str) -> str:
    """Extract first H1 heading as project name."""
    for line in body.split("\n"):
        if line.startswith("# "):
            return line[2:].strip()
    return "Untitled Project"


def _parse_sections(body: str) -> dict[str, dict[str, Any]]:
    """Parse markdown into sections by ## headings."""
    sections: dict[str, dict[str, Any]] = {}
    current_heading = ""
    current_content: list[str] = []
    current_subsections: dict[str, str] = {}
    current_sub = ""
    sub_content: list[str] = []

    for line in body.split("\n"):
        if line.startswith("## "):
            if current_heading:
                if current_sub:
                    current_subsections[current_sub] = "\n".join(sub_content)
                sections[current_heading.lower()] = {
                    "content": "\n".join(current_content),
                    "subsections": current_subsections,
                }
            current_heading = line[3:].strip()
            current_content = []
            current_subsections = {}
            current_sub = ""
            sub_content = []
        elif line.startswith("### "):
            if current_sub:
                current_subsections[current_sub] = "\n".join(sub_content)
            current_sub = line[4:].strip()
            sub_content = []
        else:
            current_content.append(line)
            if current_sub:
                sub_content.append(line)

    if current_heading:
        if current_sub:
            current_subsections[current_sub] = "\n".join(sub_content)
        sections[current_heading.lower()] = {
            "content": "\n".join(current_content),
            "subsections": current_subsections,
        }

    return sections


def _parse_component_list(section: dict[str, Any]) -> list[dict[str, str]]:
    """Extract component list from a section."""
    components = []

    if section.get("subsections"):
        for name, content in section["subsections"].items():
            components.append({
                "name": name,
                "description": content.strip().split("\n")[0] if content.strip() else "",
                "type": _infer_component_type(name, content),
            })
    else:
        for line in section["content"].split("\n"):
            line = line.strip()
            if line.startswith("- ") or line.startswith("* "):
                text = line[2:].strip()
                if ":" in text:
                    name, _, desc = text.partition(":")
                else:
                    name, desc = text, ""
                name = re.sub(r"\*\*(.+?)\*\*", r"\1", name).strip()
                components.append({
                    "name": name,
                    "description": desc.strip(),
                    "type": _infer_component_type(name, desc),
                })

    return components


def _infer_component_type(name: str, description: str) -> str:
    """Infer component type from name/description."""
    combined = (name + " " + description).lower()
    if any(w in combined for w in ["frontend", "ui", "dashboard", "web app"]):
        return "frontend"
    if any(w in combined for w in ["agent", "llm", "ml", "inference", "model"]):
        return "agent"
    if any(w in combined for w in ["database", "db", "postgres", "redis", "store"]):
        return "datastore"
    if any(w in combined for w in ["gateway", "proxy", "ingress", "load balancer"]):
        return "gateway"
    return "backend"


def _parse_feature_list(section: dict[str, Any]) -> list[dict[str, Any]]:
    """Extract features from a section."""
    features = []
    if section.get("subsections"):
        for name, content in section["subsections"].items():
            stories = []
            for line in content.split("\n"):
                line = line.strip()
                if line.startswith("- ") or line.startswith("* "):
                    stories.append(line[2:].strip())
            features.append({"name": name, "stories": stories})
    else:
        for line in section["content"].split("\n"):
            line = line.strip()
            if line.startswith("- ") or line.startswith("* "):
                features.append({"name": line[2:].strip(), "stories": []})
    return features


def _parse_kv_list(section: dict[str, Any]) -> dict[str, str]:
    """Extract key-value pairs from bullet list."""
    result = {}
    for line in section["content"].split("\n"):
        line = line.strip()
        if (line.startswith("- ") or line.startswith("* ")) and ":" in line:
            text = line[2:].strip()
            key, _, value = text.partition(":")
            key = re.sub(r"\*\*(.+?)\*\*", r"\1", key).strip()
            result[key] = value.strip()
    return result
