# Copyright (C) 2024 Intel Corporation
# SPDX-License-Identifier: Apache-2.0
"""Enterprise-quality OSPDT PowerPoint generator with Intel branding.

Produces 16:9 widescreen (13.333" x 7.5") slides with Intel logo,
consistent header/footer, branded tables, and color-coded risk levels.
"""

from pathlib import Path
from typing import Any

try:
    from pptx import Presentation
    from pptx.dml.color import RGBColor
    from pptx.enum.shapes import MSO_SHAPE
    from pptx.enum.text import MSO_ANCHOR, PP_ALIGN
    from pptx.util import Emu, Inches, Pt
except ImportError:
    Presentation = None  # type: ignore

# ── Paths ────────────────────────────────────────────────────────────────────
_LIB_DIR = Path(__file__).resolve().parent
_REPO_ROOT = _LIB_DIR.parent.parent
LOGO_PATH = _REPO_ROOT / "templates" / "intellogo.png"

# ── Slide Dimensions (16:9 widescreen) ──────────────────────────────────────
SLIDE_W = Emu(12192000)   # 13.333 inches
SLIDE_H = Emu(6858000)    # 7.5 inches

# ── Intel Brand Palette ──────────────────────────────────────────────────────
INTEL_BLUE = RGBColor(0, 104, 181)       # #0068B5 — primary brand
INTEL_DARK = RGBColor(0, 53, 128)        # #003580 — dark blue (headers)
INTEL_CYAN = RGBColor(0, 199, 253)       # #00C7FD — accent
WHITE = RGBColor(255, 255, 255)
BODY = RGBColor(51, 51, 51)
CAPTION = RGBColor(102, 102, 102)
LIGHT_TEXT = RGBColor(180, 210, 255)
FAINT_TEXT = RGBColor(150, 190, 240)
TABLE_ALT = RGBColor(237, 243, 250)      # #EDF3FA
RULE_COLOR = RGBColor(200, 215, 235)

# Risk colors
GREEN = RGBColor(0, 150, 64)
AMBER = RGBColor(210, 140, 0)
RED = RGBColor(200, 30, 30)

# ── Layout Constants ─────────────────────────────────────────────────────────
M_LEFT = Inches(0.75)
CONTENT_W = Inches(11.833)
FONT = "Calibri"

LICENSE_COLORS = {
    "MIT": GREEN,
    "Apache-2.0": GREEN,
    "BSD-2-Clause": GREEN,
    "BSD-3-Clause": GREEN,
    "ISC": GREEN,
    "Unlicense": GREEN,
    "MPL-2.0": AMBER,
    "LGPL-2.1": AMBER,
    "LGPL-3.0": AMBER,
    "EPL-2.0": AMBER,
    "GPL-2.0": RED,
    "GPL-3.0": RED,
    "AGPL-3.0": RED,
    "SSPL": RED,
}

_slide_num = 0


# ═══════════════════════════════════════════════════════════════════════════════
#  LAYOUT PRIMITIVES (same design system as generate-presentations.py)
# ═══════════════════════════════════════════════════════════════════════════════

def _new_prs():
    prs = Presentation()
    prs.slide_width = SLIDE_W
    prs.slide_height = SLIDE_H
    return prs


def _slide(prs, reset=False):
    global _slide_num
    if reset:
        _slide_num = 0
    _slide_num += 1
    return prs.slides.add_slide(prs.slide_layouts[6])


def _bg(slide, color):
    fill = slide.background.fill
    fill.solid()
    fill.fore_color.rgb = color


def _rect(slide, left, top, width, height, color):
    s = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, left, top, width, height)
    s.fill.solid()
    s.fill.fore_color.rgb = color
    s.line.fill.background()
    return s


def _tb(slide, left, top, width, height, text="", sz=14, bold=False,
        color=BODY, align=PP_ALIGN.LEFT, font=FONT):
    box = slide.shapes.add_textbox(left, top, width, height)
    tf = box.text_frame
    tf.word_wrap = True
    if text:
        p = tf.paragraphs[0]
        p.text = text
        p.font.size = Pt(sz)
        p.font.bold = bold
        p.font.color.rgb = color
        p.font.name = font
        p.alignment = align
    return tf


def _bullets(tf, items, sz=12, color=BODY):
    for item in items:
        p = tf.add_paragraph()
        p.space_before = Pt(3)
        p.space_after = Pt(1)
        p.text = item
        p.font.size = Pt(sz)
        p.font.color.rgb = color
        p.font.name = FONT
        p.level = 0


def _logo(slide, x=None, y=None, w=None):
    if not LOGO_PATH.exists():
        return
    slide.shapes.add_picture(
        str(LOGO_PATH),
        x if x is not None else Inches(12.1),
        y if y is not None else Inches(7.0),
        width=w if w is not None else Inches(0.85),
    )


def _header(slide, title):
    _rect(slide, Inches(0), Inches(0), SLIDE_W, Inches(0.6), INTEL_DARK)
    _rect(slide, Inches(0), Inches(0.6), SLIDE_W, Inches(0.04), INTEL_CYAN)
    _tb(slide, M_LEFT, Inches(0.1), CONTENT_W, Inches(0.45),
        title, sz=24, bold=True, color=WHITE)


def _footer(slide, text="OSPDT Review"):
    _rect(slide, Inches(0.5), Inches(6.83), Inches(12.333), Inches(0.008), RULE_COLOR)
    _tb(slide, M_LEFT, Inches(6.88), Inches(4), Inches(0.3),
        text, sz=8, color=CAPTION)
    _tb(slide, Inches(5.5), Inches(6.88), Inches(3), Inches(0.3),
        "Intel Confidential", sz=8, color=CAPTION, align=PP_ALIGN.CENTER)
    _tb(slide, Inches(11.2), Inches(6.88), Inches(0.8), Inches(0.3),
        str(_slide_num), sz=8, color=CAPTION, align=PP_ALIGN.RIGHT)
    _logo(slide)


def _content_slide(prs, title):
    s = _slide(prs)
    _header(s, title)
    _footer(s)
    return s


def _make_table(slide, rows, y=None, col_widths=None, font_sz=10):
    y = y or Inches(1.1)
    n_rows = len(rows)
    n_cols = len(rows[0])
    total_w = sum(col_widths) if col_widths else CONTENT_W
    row_h = Inches(0.36)

    ts = slide.shapes.add_table(n_rows, n_cols, M_LEFT, y, total_w, row_h * n_rows)
    tbl = ts.table

    if col_widths:
        for j, w in enumerate(col_widths):
            tbl.columns[j].width = w

    for i, row_data in enumerate(rows):
        for j, val in enumerate(row_data):
            cell = tbl.cell(i, j)
            cell.vertical_anchor = MSO_ANCHOR.MIDDLE
            cell.margin_left = Inches(0.08)
            cell.margin_right = Inches(0.08)
            cell.margin_top = Inches(0.04)
            cell.margin_bottom = Inches(0.04)

            if isinstance(val, tuple):
                text, text_color = val
            else:
                text, text_color = val, None

            cell.text = text
            for para in cell.text_frame.paragraphs:
                para.font.size = Pt(font_sz)
                para.font.name = FONT
                para.space_before = Pt(0)
                para.space_after = Pt(0)
                if i == 0:
                    para.font.bold = True
                    para.font.color.rgb = WHITE
                elif text_color:
                    para.font.color.rgb = text_color
                    para.font.bold = True
                else:
                    para.font.color.rgb = BODY
                if j == 0 and i > 0 and not text_color:
                    para.font.bold = True

            if i == 0:
                cell.fill.solid()
                cell.fill.fore_color.rgb = INTEL_DARK
            elif i % 2 == 0:
                cell.fill.solid()
                cell.fill.fore_color.rgb = TABLE_ALT

    return ts


def _two_col(slide, l_title, l_items, r_title, r_items, y=None):
    y = y or Inches(0.9)
    col_w = Inches(5.55)
    gap = Inches(0.7)
    rx = M_LEFT + col_w + gap

    _rect(slide, M_LEFT, y, col_w, Inches(0.4), INTEL_BLUE)
    _tb(slide, M_LEFT + Inches(0.12), y + Inches(0.03), col_w, Inches(0.35),
        l_title, sz=13, bold=True, color=WHITE)
    tf_l = _tb(slide, M_LEFT + Inches(0.12), y + Inches(0.5), Inches(5.3), Inches(5.2),
               "", sz=12)
    _bullets(tf_l, l_items, sz=12)

    _rect(slide, rx, y, col_w, Inches(0.4), INTEL_BLUE)
    _tb(slide, rx + Inches(0.12), y + Inches(0.03), col_w, Inches(0.35),
        r_title, sz=13, bold=True, color=WHITE)
    tf_r = _tb(slide, rx + Inches(0.12), y + Inches(0.5), Inches(5.3), Inches(5.2),
               "", sz=12)
    _bullets(tf_r, r_items, sz=12)


# ═══════════════════════════════════════════════════════════════════════════════
#  OSPDT SLIDE BUILDERS
# ═══════════════════════════════════════════════════════════════════════════════

def _add_title_slide(prs, project_name: str, description: str = ""):
    s = _slide(prs, reset=True)
    _bg(s, INTEL_DARK)
    _rect(s, Inches(0), Inches(0), SLIDE_W, Inches(0.06), INTEL_CYAN)
    _logo(s, x=Inches(5.55), y=Inches(1.0), w=Inches(2.2))
    _tb(s, Inches(1.5), Inches(2.4), Inches(10.333), Inches(1),
        "OSPDT Review", sz=36, bold=True, color=WHITE, align=PP_ALIGN.CENTER)
    _tb(s, Inches(1.5), Inches(3.5), Inches(10.333), Inches(0.8),
        project_name, sz=22, color=LIGHT_TEXT, align=PP_ALIGN.CENTER)
    _rect(s, Inches(4.5), Inches(4.5), Inches(4.333), Inches(0.04), INTEL_CYAN)
    _tb(s, Inches(1.5), Inches(4.8), Inches(10.333), Inches(0.6),
        "Open Source Product Distribution Team", sz=15, color=FAINT_TEXT, align=PP_ALIGN.CENTER)
    if description:
        _tb(s, Inches(1.5), Inches(5.5), Inches(10.333), Inches(0.5),
            description, sz=12, color=RGBColor(140, 175, 220), align=PP_ALIGN.CENTER)
    _rect(s, Inches(0), Inches(7.3), SLIDE_W, Inches(0.2), INTEL_BLUE)


def _add_overview_slide(prs, project_name: str, description: str,
                        dep_count: int, scan_summary: dict):
    s = _content_slide(prs, "Project Overview")

    _two_col(s,
        "Project Details", [
            f"Project: {project_name}",
            f"Description: {description or 'AI solution for Intel internal use'}",
            "",
            "This deck catalogs all open source dependencies,",
            "their licenses, and security posture for OSPDT clearance.",
            "",
            f"Total dependencies cataloged: {dep_count}",
            f"Scan date: Current",
        ],
        "Security Summary", [
            f"Critical vulnerabilities: {scan_summary.get('critical', 0)}",
            f"High vulnerabilities: {scan_summary.get('high', 0)}",
            f"Medium vulnerabilities: {scan_summary.get('medium', 0)}",
            f"Low vulnerabilities: {scan_summary.get('low', 0)}",
            f"Total: {scan_summary.get('total', 0)}",
            "",
            f"Scanner: {scan_summary.get('scanner', 'Trivy + Bandit + pip-audit')}",
            "SBOM format: CycloneDX JSON",
        ],
    )


def _add_inventory_slide(prs, dependencies: list[dict[str, str]]):
    max_per_slide = 15
    chunks = [dependencies[i:i + max_per_slide]
              for i in range(0, max(len(dependencies), 1), max_per_slide)]

    for page, chunk in enumerate(chunks):
        title = "Open Source Inventory"
        if len(chunks) > 1:
            title += f" ({page + 1}/{len(chunks)})"

        s = _content_slide(prs, title)

        rows = [("Package", "Version", "License", "Risk Level")]
        for dep in chunk:
            name = dep.get("name", dep.get("Name", ""))
            version = dep.get("version", dep.get("Version", ""))
            lic = dep.get("license", dep.get("License", "Unknown"))
            color = LICENSE_COLORS.get(lic, AMBER)
            if color == GREEN:
                risk_text, risk_color = "Low", GREEN
            elif color == AMBER:
                risk_text, risk_color = "Medium", AMBER
            else:
                risk_text, risk_color = "High", RED

            rows.append((name, version, lic, (risk_text, risk_color)))

        _make_table(s, rows, y=Inches(0.95),
                    col_widths=[Inches(3.5), Inches(2.0), Inches(3.5), Inches(2.833)],
                    font_sz=10)

        if not dependencies:
            _tb(s, M_LEFT, Inches(2.0), CONTENT_W, Inches(1),
                "No dependency data provided. Run pip-licenses or npm list to generate inventory.",
                sz=14, color=CAPTION)


def _add_license_compliance_slide(prs, dependencies: list[dict[str, str]]):
    s = _content_slide(prs, "License Compliance")

    permissive = []
    weak_copyleft = []
    strong_copyleft = []
    unknown = []

    for dep in dependencies:
        lic = dep.get("license", dep.get("License", "Unknown"))
        name = dep.get("name", dep.get("Name", ""))
        color = LICENSE_COLORS.get(lic, None)
        if color == GREEN:
            permissive.append(f"{name} ({lic})")
        elif color == AMBER:
            weak_copyleft.append(f"{name} ({lic})")
        elif color == RED:
            strong_copyleft.append(f"{name} ({lic})")
        else:
            unknown.append(f"{name} ({lic})")

    _two_col(s,
        "Permissive Licenses (Approved)", [
            f"{len(permissive)} packages with permissive licenses",
            "MIT, Apache-2.0, BSD, ISC \u2014 no restrictions",
            "",
            *([f"  \u2022 {p}" for p in permissive[:8]] if permissive else ["  (none)"]),
            *(["  \u2022 ...and more"] if len(permissive) > 8 else []),
        ],
        "Copyleft / Unknown (Review Required)", [
            f"{len(weak_copyleft)} weak copyleft (LGPL, MPL, EPL)",
            "Dynamic linking OK, static linking needs review",
            *([f"  \u2022 {p}" for p in weak_copyleft[:4]] if weak_copyleft else []),
            "",
            f"{len(strong_copyleft)} strong copyleft (GPL, AGPL)",
            "BLOCKED for proprietary distribution" if strong_copyleft else "None found",
            *([f"  \u2022 {p}" for p in strong_copyleft[:4]] if strong_copyleft else []),
            "",
            f"{len(unknown)} unknown / unclassified",
            *([f"  \u2022 {p}" for p in unknown[:4]] if unknown else []),
        ],
    )


def _add_security_slide(prs, scan_results: dict[str, Any]):
    s = _content_slide(prs, "Security Assessment")

    critical = scan_results.get("critical", 0)
    high = scan_results.get("high", 0)
    medium = scan_results.get("medium", 0)
    low = scan_results.get("low", 0)
    total = scan_results.get("total", 0)

    rows = [
        ("Severity", "Count", "Status"),
        (("Critical", RED), str(critical),
         ("Remediate immediately" if critical > 0 else "Clear", RED if critical > 0 else GREEN)),
        (("High", RED if high > 0 else BODY), str(high),
         ("Remediation plan required" if high > 0 else "Clear", AMBER if high > 0 else GREEN)),
        ("Medium", str(medium),
         ("Monitor" if medium > 0 else "Clear", AMBER if medium > 0 else GREEN)),
        ("Low", str(low),
         ("Accepted risk" if low > 0 else "Clear", GREEN)),
        ("Total", str(total), ""),
    ]

    _make_table(s, rows, y=Inches(0.95),
                col_widths=[Inches(3.0), Inches(2.0), Inches(6.833)], font_sz=12)

    scanner = scan_results.get("scanner", "Trivy + Bandit + pip-audit")
    _tb(s, M_LEFT, Inches(3.5), CONTENT_W, Inches(2),
        f"Scanners: {scanner}\n\n"
        "Coverage: SAST (Bandit), Container (Trivy), Dependencies (pip-audit / npm audit),\n"
        "Secrets (detect-secrets), Shell (ShellCheck), SBOM (CycloneDX)",
        sz=12, color=CAPTION)


def _add_risk_slide(prs, scan_results: dict[str, Any],
                    dependencies: list[dict[str, str]]):
    s = _content_slide(prs, "Risk Assessment & Recommendation")

    critical = scan_results.get("critical", 0)
    high = scan_results.get("high", 0)

    copyleft_count = sum(
        1 for d in dependencies
        if LICENSE_COLORS.get(d.get("license", d.get("License", "")), None) == RED
    )

    if critical > 0:
        verdict = "BLOCK"
        verdict_detail = "Critical vulnerabilities must be remediated before release"
        verdict_color = RED
    elif high > 0 or copyleft_count > 0:
        verdict = "CONDITIONAL APPROVAL"
        verdict_detail = "High vulnerabilities or copyleft licenses require remediation plan"
        verdict_color = AMBER
    else:
        verdict = "APPROVED"
        verdict_detail = "No critical/high vulnerabilities, all licenses permissive"
        verdict_color = GREEN

    _tb(s, M_LEFT, Inches(0.85), CONTENT_W, Inches(0.5),
        f"Recommendation: {verdict}", sz=22, bold=True, color=verdict_color)
    _tb(s, M_LEFT, Inches(1.4), CONTENT_W, Inches(0.4),
        verdict_detail, sz=14, color=BODY)

    _two_col(s,
        "Risk Factors", [
            f"Critical CVEs: {critical}",
            f"High CVEs: {high}",
            f"Strong copyleft packages: {copyleft_count}",
            f"Total dependencies: {len(dependencies)}",
            "",
            "Vulnerability trend: Initial scan",
            "License compatibility: Reviewed",
        ],
        "Mitigation Steps", [
            "1. Upgrade dependencies with known CVEs (minor/patch)",
            "2. Review and fix SAST findings from Bandit",
            "3. Replace GPL/AGPL packages with permissive alternatives",
            "4. Generate and publish CycloneDX SBOM",
            "5. Sign container images with cosign",
            "6. Re-scan and regenerate this deck after fixes",
            "",
            "Contact OSPDT for clearance after remediation.",
        ],
        y=Inches(1.9),
    )


# ═══════════════════════════════════════════════════════════════════════════════
#  PUBLIC API
# ═══════════════════════════════════════════════════════════════════════════════

def generate_ospdt_deck(
    project_name: str,
    dependencies: list[dict[str, str]],
    scan_results: dict[str, Any],
    output_path: str,
    description: str = "",
) -> str:
    """Generate OSPDT PowerPoint deck with Intel enterprise branding.

    Args:
        project_name: Name of the project
        dependencies: List of dicts with keys: name, version, license
        scan_results: Dict with keys: critical, high, medium, low, total, scanner
        output_path: Where to save the .pptx file
        description: Project description for overview slide

    Returns:
        Path to the saved .pptx file, or empty string on failure.
    """
    if Presentation is None:
        print("ERROR: python-pptx not installed. Run: pip install python-pptx")
        return ""

    prs = _new_prs()

    _add_title_slide(prs, project_name, description)
    _add_overview_slide(prs, project_name, description, len(dependencies), scan_results)
    _add_inventory_slide(prs, dependencies)
    _add_license_compliance_slide(prs, dependencies)
    _add_security_slide(prs, scan_results)
    _add_risk_slide(prs, scan_results, dependencies)

    Path(output_path).parent.mkdir(parents=True, exist_ok=True)
    prs.save(output_path)
    print(f"OSPDT deck saved: {output_path}")
    return output_path
