# Copyright (C) 2026 Intel Corporation
# SPDX-License-Identifier: Apache-2.0

import json
from typing import Any

from .config import config
from .curl_wrapper import curl_json


def _headers() -> dict[str, str]:
    return {
        "Authorization": f"Bearer {config.wiki_pat}",
        "Content-Type": "application/json",
        "Accept": "application/json",
    }


def _api(path: str) -> str:
    return f"{config.wiki_base_url}/rest/api/content{path}"


def get_page(page_id: str) -> dict[str, Any]:
    """Fetch page content by ID."""
    status, data = curl_json(
        f"{_api(f'/{page_id}')}?expand=body.storage,version",
        headers=_headers(),
    )
    if status != 200:
        print(f"WARNING: Wiki get_page {page_id} returned {status}")
    return data


def create_page(
    space_key: str,
    title: str,
    body_html: str,
    parent_id: str | None = None,
) -> dict[str, Any]:
    """Create a new Confluence page."""
    payload: dict[str, Any] = {
        "type": "page",
        "title": title,
        "space": {"key": space_key},
        "body": {
            "storage": {
                "value": body_html,
                "representation": "storage",
            }
        },
    }
    if parent_id:
        payload["ancestors"] = [{"id": parent_id}]

    status, data = curl_json(_api(""), method="POST", headers=_headers(), data=payload)
    if status not in (200, 201):
        print(f"WARNING: Wiki create_page returned {status}: {data}")
    return data


def update_page(
    page_id: str,
    title: str,
    body_html: str,
    version_number: int,
) -> dict[str, Any]:
    """Update an existing page (increments version)."""
    payload = {
        "id": page_id,
        "type": "page",
        "title": title,
        "version": {"number": version_number + 1},
        "body": {
            "storage": {
                "value": body_html,
                "representation": "storage",
            }
        },
    }
    status, data = curl_json(
        _api(f"/{page_id}"),
        method="PUT",
        headers=_headers(),
        data=payload,
    )
    if status != 200:
        print(f"WARNING: Wiki update_page {page_id} returned {status}: {data}")
    return data


def get_page_children(page_id: str) -> list[dict[str, Any]]:
    """List child pages."""
    status, data = curl_json(
        _api(f"/{page_id}/child/page"),
        headers=_headers(),
    )
    if status != 200:
        print(f"WARNING: Wiki get_page_children {page_id} returned {status}")
        return []
    return data.get("results", [])
