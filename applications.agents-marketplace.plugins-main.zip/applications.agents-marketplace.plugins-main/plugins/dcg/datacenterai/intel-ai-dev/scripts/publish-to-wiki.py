#!/usr/bin/env python3
# Copyright (C) 2024 Intel Corporation
# SPDX-License-Identifier: Apache-2.0
"""Publish a markdown document to Confluence wiki."""

import argparse
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from lib.wiki_client import WikiClient


def markdown_to_confluence_html(md_content: str) -> str:
    html = md_content
    html = re.sub(r"^### (.+)$", r"<h3>\1</h3>", html, flags=re.MULTILINE)
    html = re.sub(r"^## (.+)$", r"<h2>\1</h2>", html, flags=re.MULTILINE)
    html = re.sub(r"^# (.+)$", r"<h1>\1</h1>", html, flags=re.MULTILINE)
    html = re.sub(r"\*\*(.+?)\*\*", r"<strong>\1</strong>", html)
    html = re.sub(r"\*(.+?)\*", r"<em>\1</em>", html)
    html = re.sub(r"`(.+?)`", r"<code>\1</code>", html)

    lines = html.split("\n")
    result = []
    in_code = False
    in_list = False

    for line in lines:
        if line.startswith("```"):
            if in_code:
                result.append("</ac:plain-text-body></ac:structured-macro>")
                in_code = False
            else:
                lang = line[3:].strip() or "text"
                result.append(
                    f'<ac:structured-macro ac:name="code">'
                    f'<ac:parameter ac:name="language">{lang}</ac:parameter>'
                    f"<ac:plain-text-body><![CDATA["
                )
                in_code = True
            continue

        if in_code:
            result.append(line)
            continue

        if line.startswith("- "):
            if not in_list:
                result.append("<ul>")
                in_list = True
            result.append(f"<li>{line[2:]}</li>")
        else:
            if in_list:
                result.append("</ul>")
                in_list = False
            if line.strip():
                if not line.startswith("<h"):
                    result.append(f"<p>{line}</p>")
                else:
                    result.append(line)

    if in_list:
        result.append("</ul>")
    return "\n".join(result)


def main():
    parser = argparse.ArgumentParser(description="Publish markdown to Confluence")
    parser.add_argument("file", help="Markdown file to publish")
    parser.add_argument("--space", default="datacenterai", help="Confluence space key")
    parser.add_argument("--parent-id", help="Parent page ID (optional)")
    parser.add_argument("--dry-run", action="store_true", help="Preview HTML without publishing")
    args = parser.parse_args()

    file_path = Path(args.file)
    if not file_path.exists():
        print(f"Error: {file_path} not found")
        sys.exit(1)

    md_content = file_path.read_text(encoding="utf-8")
    title_match = re.match(r"^#\s+(.+)$", md_content, re.MULTILINE)
    title = title_match.group(1) if title_match else file_path.stem.replace("-", " ").title()

    html_content = markdown_to_confluence_html(md_content)

    if args.dry_run:
        print(f"Title: {title}")
        print(f"Space: {args.space}")
        print(f"HTML length: {len(html_content)} chars")
        print("---")
        print(html_content[:500])
        return

    client = WikiClient()
    existing = client.get_page(args.space, title)

    if existing:
        page_id = existing["id"]
        version = existing["version"]["number"] + 1
        client.update_page(page_id, title, html_content, version)
        print(f"Updated: {title} (version {version})")
    else:
        result = client.create_page(args.space, title, html_content, args.parent_id)
        print(f"Created: {title}")
        if result:
            print(f"URL: {result.get('_links', {}).get('webui', 'N/A')}")


if __name__ == "__main__":
    main()
