#!/usr/bin/env python3
# Copyright (C) 2024 Intel Corporation
# SPDX-License-Identifier: Apache-2.0
"""Push generated project to GitHub repository."""

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from lib.github_client import GitHubClient


def main():
    parser = argparse.ArgumentParser(description="Push project to GitHub")
    parser.add_argument("--org", required=True, help="GitHub organization")
    parser.add_argument("--repo", required=True, help="Repository name")
    parser.add_argument("--branch", default="main", help="Branch name")
    parser.add_argument("--message", default="Initial project scaffold", help="Commit message")
    parser.add_argument("--dir", default=".", help="Project directory")
    args = parser.parse_args()

    project_dir = Path(args.dir).resolve()
    if not project_dir.exists():
        print(f"Error: {project_dir} not found")
        sys.exit(1)

    client = GitHubClient()

    if not (project_dir / ".git").exists():
        print("Initializing git repository...")
        client.init_repo(str(project_dir))

    remote_url = f"https://github.com/{args.org}/{args.repo}.git"
    print(f"Pushing to {remote_url} (branch: {args.branch})")

    client.create_and_push(
        repo_dir=str(project_dir),
        remote_url=remote_url,
        branch=args.branch,
        message=args.message,
    )
    print(f"Done! Repository: https://github.com/{args.org}/{args.repo}")


if __name__ == "__main__":
    main()
