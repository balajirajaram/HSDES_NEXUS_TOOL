#!/usr/bin/env python3
# Copyright (C) 2024 Intel Corporation
# SPDX-License-Identifier: Apache-2.0
"""Run security scans (Bandit + Trivy + ShellCheck + detect-secrets)."""

import argparse
import json
import subprocess
import sys
from pathlib import Path


def run_command(cmd: list[str], timeout: int = 300) -> tuple[int, str, str]:
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        return result.returncode, result.stdout, result.stderr
    except FileNotFoundError:
        return -1, "", f"{cmd[0]} not installed"
    except subprocess.TimeoutExpired:
        return -2, "", f"{cmd[0]} timed out"


def run_bandit(src_dir: str, output_dir: str) -> dict:
    output_file = f"{output_dir}/bandit-report.json"
    code, stdout, stderr = run_command([
        "bandit", "-r", src_dir, "-f", "json", "-o", output_file,
        "-s", "B101", "--exclude", "*/tests/*",
    ])
    if code == -1:
        return {"tool": "bandit", "status": "not_installed", "findings": 0}

    try:
        report = json.loads(Path(output_file).read_text())
        findings = len(report.get("results", []))
        by_severity = {}
        for r in report.get("results", []):
            sev = r.get("issue_severity", "UNKNOWN")
            by_severity[sev] = by_severity.get(sev, 0) + 1
        return {"tool": "bandit", "status": "complete", "findings": findings, "by_severity": by_severity}
    except Exception:
        return {"tool": "bandit", "status": "complete", "findings": 0}


def run_trivy(project_dir: str, output_dir: str) -> dict:
    output_file = f"{output_dir}/trivy-fs-report.json"
    code, stdout, stderr = run_command([
        "trivy", "fs", "--severity", "HIGH,CRITICAL", "--format", "json",
        "-o", output_file, project_dir,
    ])
    if code == -1:
        return {"tool": "trivy", "status": "not_installed", "findings": 0}

    try:
        report = json.loads(Path(output_file).read_text())
        vulns = 0
        for result in report.get("Results", []):
            vulns += len(result.get("Vulnerabilities", []))
        return {"tool": "trivy", "status": "complete", "findings": vulns}
    except Exception:
        return {"tool": "trivy", "status": "complete", "findings": 0}


def run_shellcheck(project_dir: str) -> dict:
    sh_files = list(Path(project_dir).rglob("*.sh"))
    if not sh_files:
        return {"tool": "shellcheck", "status": "skipped", "findings": 0}

    findings = 0
    for sh_file in sh_files:
        code, stdout, stderr = run_command(["shellcheck", "-f", "json", str(sh_file)])
        if code == -1:
            return {"tool": "shellcheck", "status": "not_installed", "findings": 0}
        try:
            issues = json.loads(stdout) if stdout else []
            findings += len(issues)
        except json.JSONDecodeError:
            pass
    return {"tool": "shellcheck", "status": "complete", "findings": findings}


def run_detect_secrets(project_dir: str, output_dir: str) -> dict:
    output_file = f"{output_dir}/secrets-report.json"
    code, stdout, stderr = run_command([
        "detect-secrets", "scan", "--all-files", project_dir,
    ])
    if code == -1:
        return {"tool": "detect-secrets", "status": "not_installed", "findings": 0}

    try:
        report = json.loads(stdout)
        Path(output_file).write_text(json.dumps(report, indent=2))
        findings = sum(len(v) for v in report.get("results", {}).values())
        return {"tool": "detect-secrets", "status": "complete", "findings": findings}
    except Exception:
        return {"tool": "detect-secrets", "status": "complete", "findings": 0}


def main():
    parser = argparse.ArgumentParser(description="Run security scans")
    parser.add_argument("--project-dir", default=".", help="Project directory")
    parser.add_argument("--output-dir", default="docs/reports", help="Report output directory")
    args = parser.parse_args()

    Path(args.output_dir).mkdir(parents=True, exist_ok=True)
    src_dir = str(Path(args.project_dir) / "src")

    print("=== Security Scan ===\n")
    results = []

    print("Running Bandit (Python SAST)...")
    results.append(run_bandit(src_dir, args.output_dir))

    print("Running Trivy (filesystem scan)...")
    results.append(run_trivy(args.project_dir, args.output_dir))

    print("Running ShellCheck...")
    results.append(run_shellcheck(args.project_dir))

    print("Running detect-secrets...")
    results.append(run_detect_secrets(args.project_dir, args.output_dir))

    print("\n=== Results ===")
    total = 0
    for r in results:
        status = r["status"].upper()
        print(f"  {r['tool']:20s} {status:15s} {r['findings']} findings")
        if r["status"] == "complete":
            total += r["findings"]

    print(f"\nTotal findings: {total}")
    overall = "PASS" if total == 0 else "NEEDS ATTENTION"
    print(f"Overall: {overall}")


if __name__ == "__main__":
    main()
