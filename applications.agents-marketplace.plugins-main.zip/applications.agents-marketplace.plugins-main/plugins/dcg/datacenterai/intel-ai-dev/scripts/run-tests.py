#!/usr/bin/env python3
# Copyright (C) 2024 Intel Corporation
# SPDX-License-Identifier: Apache-2.0
"""Run tests for all components with coverage reporting."""

import argparse
import subprocess
import sys
from pathlib import Path


def discover_components(project_dir: str) -> list[Path]:
    src = Path(project_dir) / "src"
    components = []
    if src.exists():
        for d in sorted(src.iterdir()):
            if d.is_dir() and (d / "tox.ini").exists():
                components.append(d)
    return components


def run_component_tests(component_dir: Path, use_tox: bool = True) -> dict:
    name = component_dir.name
    result = {"component": name, "passed": 0, "failed": 0, "coverage": 0.0, "status": "unknown"}

    if use_tox:
        cmd = ["tox"]
    else:
        cmd = [
            "pytest", "tests/", "-v",
            "--cov=app", "--cov-report=term-missing",
            "--cov-fail-under=85", "--tb=short",
        ]

    try:
        proc = subprocess.run(
            cmd, cwd=str(component_dir),
            capture_output=True, text=True, timeout=600,
        )
        output = proc.stdout + proc.stderr

        for line in output.split("\n"):
            if "passed" in line:
                import re
                m = re.search(r"(\d+) passed", line)
                if m:
                    result["passed"] = int(m.group(1))
                m = re.search(r"(\d+) failed", line)
                if m:
                    result["failed"] = int(m.group(1))
            if "TOTAL" in line and "%" in line:
                import re
                m = re.search(r"(\d+)%", line)
                if m:
                    result["coverage"] = float(m.group(1))

        result["status"] = "passed" if proc.returncode == 0 else "failed"

    except FileNotFoundError:
        result["status"] = "tool_not_found"
    except subprocess.TimeoutExpired:
        result["status"] = "timeout"

    return result


def main():
    parser = argparse.ArgumentParser(description="Run tests for all components")
    parser.add_argument("--project-dir", default=".", help="Project directory")
    parser.add_argument("--component", help="Specific component to test")
    parser.add_argument("--no-tox", action="store_true", help="Use pytest directly instead of tox")
    args = parser.parse_args()

    if args.component:
        comp_dir = Path(args.project_dir) / "src" / args.component
        if not comp_dir.exists():
            print(f"Error: Component {args.component} not found")
            sys.exit(1)
        components = [comp_dir]
    else:
        components = discover_components(args.project_dir)

    if not components:
        print("No components with tox.ini found in src/")
        sys.exit(1)

    print(f"=== Running Tests ({len(components)} components) ===\n")
    results = []

    for comp in components:
        print(f"Testing {comp.name}...")
        result = run_component_tests(comp, use_tox=not args.no_tox)
        results.append(result)
        status_icon = "PASS" if result["status"] == "passed" else "FAIL"
        print(f"  {status_icon}: {result['passed']} passed, {result['failed']} failed, "
              f"coverage: {result['coverage']}%\n")

    print("=== Summary ===")
    all_passed = True
    for r in results:
        status = "PASS" if r["status"] == "passed" else "FAIL"
        coverage_status = "OK" if r["coverage"] >= 85 else "LOW"
        print(f"  {r['component']:30s} {status:6s} {r['coverage']:5.1f}% [{coverage_status}]")
        if r["status"] != "passed":
            all_passed = False

    sys.exit(0 if all_passed else 1)


if __name__ == "__main__":
    main()
