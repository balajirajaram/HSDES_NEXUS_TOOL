#!/usr/bin/env python3
# Copyright (C) 2026 Intel Corporation
# SPDX-License-Identifier: Apache-2.0
"""
Intel AI Solutions — Project Scaffold Generator (Option B)

Mechanically stamps out ALL template files from templates/project-scaffold/
using variable substitution from a YAML handoff file. Zero LLM context needed.

Usage:
    python scripts/scaffold.py --vars handoff.yaml --output ./my-project/
    python scripts/scaffold.py --vars handoff.yaml --output ./my-project/ --dry-run
    python scripts/scaffold.py --vars handoff.yaml --output ./my-project/ --phase backend
    python scripts/scaffold.py --vars handoff.yaml --output ./my-project/ --phase all

The LLM (dev-agent) then only needs to generate PRD-specific custom code
(endpoints, services, AI logic) — saving ~70% of context window.

Phases (can be run independently for Option A sub-agent approach):
    config    — Root config files (.gitignore, README, Makefile, CNCF, scripts)
    github    — .github/ workflows, templates, dependabot
    backend   — src/{component}/ Python scaffold
    frontend  — frontend/ React+Vite+Tailwind scaffold
    docker    — docker/ compose files + nginx
    helm      — helm/ Kubernetes chart
    ansible   — ansible/ playbooks + roles
    all       — Everything (default)
"""

import argparse
import os
import re
import shutil
import sys
from datetime import datetime
from pathlib import Path

import yaml


SCRIPT_DIR = Path(__file__).resolve().parent
REPO_ROOT = SCRIPT_DIR.parent
TEMPLATES_DIR = REPO_ROOT / "templates" / "project-scaffold"

# Template categories mapped to their source directories and output paths
PHASE_MAP = {
    "config": {
        "sources": [
            ("automation/.gitignore", ".gitignore"),
            ("automation/.pre-commit-config.yaml", ".pre-commit-config.yaml"),
            ("automation/.env.example.tmpl", ".env.example"),
            ("automation/Makefile.tmpl", "Makefile"),
            ("automation/Taskfile.yml.tmpl", "Taskfile.yml"),
            ("automation/CLAUDE.md.tmpl", "CLAUDE.md"),
            ("automation/README.md.tmpl", "README.md"),
            ("automation/dev-sanity.sh.tmpl", "scripts/dev-sanity.sh"),
            ("automation/install.sh.tmpl", "scripts/install.sh"),
            ("automation/start.bat.tmpl", "scripts/start.bat"),
            ("cncf/LICENSE", "LICENSE"),
            ("cncf/CODE_OF_CONDUCT.md", "CODE_OF_CONDUCT.md"),
            ("cncf/CONTRIBUTING.md.tmpl", "CONTRIBUTING.md"),
            ("cncf/SECURITY.md.tmpl", "SECURITY.md"),
            ("cncf/THIRD-PARTY-PROGRAMS.tmpl", "THIRD-PARTY-PROGRAMS"),
            ("scripts/healthcheck.sh.tmpl", "scripts/healthcheck.sh"),
            ("scripts/migrate.sh.tmpl", "scripts/migrate.sh"),
            ("scripts/seed-data.py.tmpl", "scripts/seed-data.py"),
            ("scripts/wait-for-deps.sh.tmpl", "scripts/wait-for-deps.sh"),
        ]
    },
    "github": {
        "sources": [
            ("github/workflows/ci.yml.tmpl", ".github/workflows/ci.yml"),
            ("github/workflows/code-scans.yml.tmpl", ".github/workflows/code-scans.yml"),
            ("github/workflows/release.yml.tmpl", ".github/workflows/release.yml"),
            ("github/workflows/dependency-review.yml.tmpl", ".github/workflows/dependency-review.yml"),
            ("github/workflows/codeql-analysis.yml.tmpl", ".github/workflows/codeql-analysis.yml"),
            ("github/dependabot.yml.tmpl", ".github/dependabot.yml"),
            ("github/CODEOWNERS.tmpl", ".github/CODEOWNERS"),
            ("github/ISSUE_TEMPLATE/bug_report.yml", ".github/ISSUE_TEMPLATE/bug_report.yml"),
            ("github/ISSUE_TEMPLATE/feature_request.yml", ".github/ISSUE_TEMPLATE/feature_request.yml"),
            ("github/PULL_REQUEST_TEMPLATE.md", ".github/PULL_REQUEST_TEMPLATE.md"),
        ]
    },
    "backend": {
        "sources": [
            ("backend/Dockerfile.tmpl", "src/{package_name}/Dockerfile"),
            ("backend/alembic.ini.tmpl", "src/{package_name}/alembic.ini"),
            ("backend/tox.ini.tmpl", "src/{package_name}/tox.ini"),
            ("backend/pyproject.toml.tmpl", "src/{package_name}/pyproject.toml"),
            ("backend/requirements.txt.tmpl", "src/{package_name}/requirements.txt"),
            ("backend/tests/conftest.py.tmpl", "src/{package_name}/tests/conftest.py"),
            ("backend/app/__init__.py.tmpl", "src/{package_name}/app/__init__.py"),
            ("backend/app/py.typed.tmpl", "src/{package_name}/app/py.typed"),
            ("backend/app/main.py.tmpl", "src/{package_name}/app/main.py"),
            ("backend/app/config.py.tmpl", "src/{package_name}/app/config.py"),
            ("backend/app/core/exceptions.py.tmpl", "src/{package_name}/app/core/exceptions.py"),
            ("backend/app/core/middleware.py.tmpl", "src/{package_name}/app/core/middleware.py"),
            ("backend/app/core/rate_limit.py.tmpl", "src/{package_name}/app/core/rate_limit.py"),
            ("backend/app/core/security.py.tmpl", "src/{package_name}/app/core/security.py"),
            ("backend/app/core/security_local.py.tmpl", "src/{package_name}/app/core/security_local.py"),
            ("backend/app/api/deps.py.tmpl", "src/{package_name}/app/api/deps.py"),
            ("backend/app/api/v1/router.py.tmpl", "src/{package_name}/app/api/v1/router.py"),
            ("backend/app/api/v1/endpoints/items.py.tmpl", "src/{package_name}/app/api/v1/endpoints/items.py"),
            ("backend/app/api/v1/endpoints/auth.py.tmpl", "src/{package_name}/app/api/v1/endpoints/auth.py"),
            ("backend/app/models/db.py.tmpl", "src/{package_name}/app/models/db.py"),
            ("backend/app/models/schemas.py.tmpl", "src/{package_name}/app/models/schemas.py"),
            ("backend/app/db/session.py.tmpl", "src/{package_name}/app/db/session.py"),
            ("backend/app/observability/health.py.tmpl", "src/{package_name}/app/observability/health.py"),
            ("backend/app/observability/logging.py.tmpl", "src/{package_name}/app/observability/logging.py"),
            ("backend/app/observability/telemetry.py.tmpl", "src/{package_name}/app/observability/telemetry.py"),
            ("backend/app/inference/__init__.py.tmpl", "src/{package_name}/app/inference/__init__.py"),
            ("backend/app/inference/config.py.tmpl", "src/{package_name}/app/inference/config.py"),
            ("backend/app/inference/mock_client.py.tmpl", "src/{package_name}/app/inference/mock_client.py"),
            ("backend/app/inference/ei_client.py.tmpl", "src/{package_name}/app/inference/ei_client.py"),
            ("backend/app/inference/vllm_client.py.tmpl", "src/{package_name}/app/inference/vllm_client.py"),
            ("backend/app/services/__init__.py.tmpl", "src/{package_name}/app/services/__init__.py"),
            ("backend/app/services/pipeline_runner.py.tmpl", "src/{package_name}/app/services/pipeline_runner.py"),
            ("backend/app/storage/__init__.py.tmpl", "src/{package_name}/app/storage/__init__.py"),
            ("backend/app/storage/backend.py.tmpl", "src/{package_name}/app/storage/backend.py"),
        ]
    },
    "frontend": {
        "sources": [
            ("frontend/package.json.tmpl", "frontend/package.json"),
            ("frontend/tsconfig.json.tmpl", "frontend/tsconfig.json"),
            ("frontend/tsconfig.node.json.tmpl", "frontend/tsconfig.node.json"),
            ("frontend/vite.config.ts.tmpl", "frontend/vite.config.ts"),
            ("frontend/vitest.config.ts.tmpl", "frontend/vitest.config.ts"),
            ("frontend/tailwind.config.ts.tmpl", "frontend/tailwind.config.ts"),
            ("frontend/postcss.config.js.tmpl", "frontend/postcss.config.js"),
            ("frontend/index.html.tmpl", "frontend/index.html"),
            ("frontend/Dockerfile.tmpl", "frontend/Dockerfile"),
            ("frontend/nginx.conf.tmpl", "frontend/nginx.conf"),
            ("frontend/.env.tmpl", "frontend/.env"),
            ("frontend/.env.example.tmpl", "frontend/.env.example"),
            ("frontend/src/main.tsx.tmpl", "frontend/src/main.tsx"),
            ("frontend/src/index.css.tmpl", "frontend/src/index.css"),
            ("frontend/src/vite-env.d.ts.tmpl", "frontend/src/vite-env.d.ts"),
            ("frontend/src/test-setup.ts.tmpl", "frontend/src/test-setup.ts"),
            ("frontend/src/app/providers.tsx.tmpl", "frontend/src/app/providers.tsx"),
            ("frontend/src/app/router.tsx.tmpl", "frontend/src/app/router.tsx"),
            ("frontend/src/app/layout.tsx.tmpl", "frontend/src/app/layout.tsx"),
            ("frontend/src/app/error-boundary.tsx.tmpl", "frontend/src/app/error-boundary.tsx"),
            ("frontend/src/app/not-found.tsx.tmpl", "frontend/src/app/not-found.tsx"),
            ("frontend/src/lib/api-client.ts.tmpl", "frontend/src/lib/api-client.ts"),
            ("frontend/src/lib/auth.tsx.tmpl", "frontend/src/lib/auth.tsx"),
            ("frontend/src/lib/cn.ts.tmpl", "frontend/src/lib/cn.ts"),
            ("frontend/src/lib/constants.ts.tmpl", "frontend/src/lib/constants.ts"),
            ("frontend/src/hooks/use-auth.ts.tmpl", "frontend/src/hooks/use-auth.ts"),
            ("frontend/src/hooks/use-toast.ts.tmpl", "frontend/src/hooks/use-toast.ts"),
            ("frontend/src/stores/auth-store.ts.tmpl", "frontend/src/stores/auth-store.ts"),
            ("frontend/src/stores/ui-store.ts.tmpl", "frontend/src/stores/ui-store.ts"),
            ("frontend/src/pages/login.tsx.tmpl", "frontend/src/pages/login.tsx"),
            ("frontend/src/pages/dashboard.tsx.tmpl", "frontend/src/pages/dashboard.tsx"),
            ("frontend/src/types/api.ts.tmpl", "frontend/src/types/api.ts"),
            ("frontend/src/types/common.ts.tmpl", "frontend/src/types/common.ts"),
            ("frontend/src/components/layout/header.tsx.tmpl", "frontend/src/components/layout/header.tsx"),
            ("frontend/src/components/layout/sidebar.tsx.tmpl", "frontend/src/components/layout/sidebar.tsx"),
            ("frontend/src/components/layout/content-area.tsx.tmpl", "frontend/src/components/layout/content-area.tsx"),
            ("frontend/src/components/layout/page-header.tsx.tmpl", "frontend/src/components/layout/page-header.tsx"),
            ("frontend/src/components/ui/badge.tsx.tmpl", "frontend/src/components/ui/badge.tsx"),
            ("frontend/src/components/ui/button.tsx.tmpl", "frontend/src/components/ui/button.tsx"),
            ("frontend/src/components/ui/card.tsx.tmpl", "frontend/src/components/ui/card.tsx"),
            ("frontend/src/components/ui/empty-state.tsx.tmpl", "frontend/src/components/ui/empty-state.tsx"),
            ("frontend/src/components/ui/input.tsx.tmpl", "frontend/src/components/ui/input.tsx"),
            ("frontend/src/components/ui/modal.tsx.tmpl", "frontend/src/components/ui/modal.tsx"),
            ("frontend/src/components/ui/select.tsx.tmpl", "frontend/src/components/ui/select.tsx"),
            ("frontend/src/components/ui/skeleton.tsx.tmpl", "frontend/src/components/ui/skeleton.tsx"),
            ("frontend/src/components/ui/spinner.tsx.tmpl", "frontend/src/components/ui/spinner.tsx"),
            ("frontend/src/components/ui/table.tsx.tmpl", "frontend/src/components/ui/table.tsx"),
            ("frontend/src/components/ui/toast.tsx.tmpl", "frontend/src/components/ui/toast.tsx"),
            ("frontend/src/components/feedback/error-display.tsx.tmpl", "frontend/src/components/feedback/error-display.tsx"),
            ("frontend/src/components/feedback/loading-overlay.tsx.tmpl", "frontend/src/components/feedback/loading-overlay.tsx"),
        ]
    },
    "frontend_features": {
        "feature_templates": [
            ("frontend/src/features/__feature__/api/api.ts.tmpl", "frontend/src/features/{feature_slug}/api/api.ts"),
            ("frontend/src/features/__feature__/api/queries.ts.tmpl", "frontend/src/features/{feature_slug}/api/queries.ts"),
            ("frontend/src/features/__feature__/components/detail.tsx.tmpl", "frontend/src/features/{feature_slug}/components/detail.tsx"),
            ("frontend/src/features/__feature__/components/form.tsx.tmpl", "frontend/src/features/{feature_slug}/components/form.tsx"),
            ("frontend/src/features/__feature__/components/list.tsx.tmpl", "frontend/src/features/{feature_slug}/components/list.tsx"),
            ("frontend/src/features/__feature__/hooks/use-feature.ts.tmpl", "frontend/src/features/{feature_slug}/hooks/use-{feature_slug}.ts"),
            ("frontend/src/features/__feature__/index.ts.tmpl", "frontend/src/features/{feature_slug}/index.ts"),
            ("frontend/src/features/__feature__/types.ts.tmpl", "frontend/src/features/{feature_slug}/types.ts"),
        ]
    },
    "docker": {
        "sources": [
            ("docker/docker-compose.yml.tmpl", "docker/docker-compose.yml"),
            ("docker/docker-compose.prod.yml.tmpl", "docker/docker-compose.prod.yml"),
            ("docker/nginx/nginx.conf.tmpl", "docker/nginx/nginx.conf"),
        ]
    },
    "helm": {
        "sources": [
            ("helm/Chart.yaml.tmpl", "helm/{project_slug}/Chart.yaml"),
            ("helm/values.yaml.tmpl", "helm/{project_slug}/values.yaml"),
            ("helm/values-production.yaml.tmpl", "helm/{project_slug}/values-production.yaml"),
            ("helm/templates/_helpers.tpl.tmpl", "helm/{project_slug}/templates/_helpers.tpl"),
            ("helm/templates/deployment.yaml.tmpl", "helm/{project_slug}/templates/deployment.yaml"),
            ("helm/templates/service.yaml.tmpl", "helm/{project_slug}/templates/service.yaml"),
            ("helm/templates/hpa.yaml.tmpl", "helm/{project_slug}/templates/hpa.yaml"),
            ("helm/templates/pdb.yaml.tmpl", "helm/{project_slug}/templates/pdb.yaml"),
            ("helm/templates/networkpolicy.yaml.tmpl", "helm/{project_slug}/templates/networkpolicy.yaml"),
            ("helm/templates/serviceaccount.yaml.tmpl", "helm/{project_slug}/templates/serviceaccount.yaml"),
            ("helm/templates/configmap.yaml.tmpl", "helm/{project_slug}/templates/configmap.yaml"),
            ("helm/templates/secret.yaml.tmpl", "helm/{project_slug}/templates/secret.yaml"),
            ("helm/templates/ingress.yaml.tmpl", "helm/{project_slug}/templates/ingress.yaml"),
            ("helm/templates/servicemonitor.yaml.tmpl", "helm/{project_slug}/templates/servicemonitor.yaml"),
            ("helm/templates/NOTES.txt.tmpl", "helm/{project_slug}/templates/NOTES.txt"),
            ("helm/templates/tests/test-connection.yaml.tmpl", "helm/{project_slug}/templates/tests/test-connection.yaml"),
        ]
    },
    "ansible": {
        "sources": [
            ("ansible/ansible.cfg.tmpl", "ansible/ansible.cfg"),
            ("ansible/inventory/dev.yml.tmpl", "ansible/inventory/dev.yml"),
            ("ansible/playbooks/setup.yaml.tmpl", "ansible/playbooks/setup.yaml"),
            ("ansible/playbooks/infrastructure.yaml.tmpl", "ansible/playbooks/infrastructure.yaml"),
            ("ansible/playbooks/application.yaml.tmpl", "ansible/playbooks/application.yaml"),
            ("ansible/playbooks/validate.yaml.tmpl", "ansible/playbooks/validate.yaml"),
            ("ansible/playbooks/backup.yaml.tmpl", "ansible/playbooks/backup.yaml"),
            ("ansible/playbooks/pre_upgrade.yaml.tmpl", "ansible/playbooks/pre_upgrade.yaml"),
            ("ansible/roles/common/tasks/main.yml.tmpl", "ansible/roles/common/tasks/main.yml"),
            ("ansible/roles/infrastructure/tasks/main.yml.tmpl", "ansible/roles/infrastructure/tasks/main.yml"),
            ("ansible/roles/application/tasks/main.yml.tmpl", "ansible/roles/application/tasks/main.yml"),
        ]
    },
}


def load_vars(vars_file: Path) -> dict:
    """Load variables from YAML handoff file."""
    with open(vars_file) as f:
        data = yaml.safe_load(f)

    # Support both flat vars and nested handoff structure
    if "handoff" in data:
        handoff = data["handoff"]
        variables = {
            "project_name": handoff.get("project_name", ""),
            "project_slug": handoff.get("project_slug", ""),
            "package_name": handoff.get("components", [{}])[0].get("name", "app"),
            "port": str(handoff.get("components", [{}])[0].get("port", 8000)),
            "description": handoff.get("description", data.get("description", "")),
            "python_version": handoff.get("python_version", "3.11"),
            "year": str(datetime.now().year),
            "author": handoff.get("author", "Intel AI Team"),
            "app_name": handoff.get("project_name", ""),
        }
        # Extract features: check handoff block first, then top-level
        variables["features"] = handoff.get("features", data.get("features", []))
        variables["_handoff"] = handoff
    else:
        variables = data
        variables.setdefault("year", str(datetime.now().year))
        variables.setdefault("python_version", "3.11")
        variables.setdefault("author", "Intel AI Team")

    return variables


def substitute(content: str, variables: dict) -> str:
    """
    Replace {{variable}} patterns with values from variables dict.

    Preserves:
    - Helm/Go template expressions like {{ .Values.x }} (has spaces + dot notation)
    - GitHub Actions ${{ }} (has dollar prefix)
    - Taskfile {{` `}} escaped blocks
    """
    def replacer(match):
        key = match.group(1).strip()
        # Skip Helm/Go templates (start with . or contain spaces with Go syntax)
        if key.startswith(".") or key.startswith("- ") or " " in key:
            return match.group(0)
        # Skip Taskfile escaped templates
        if key.startswith("`") or key.endswith("`"):
            return match.group(0)
        # Skip if it looks like a Go range/if/end/define block
        go_keywords = ("range", "if", "else", "end", "define", "template", "block", "with", "include")
        if any(key.startswith(kw) for kw in go_keywords):
            return match.group(0)
        # Replace known variables
        if key in variables:
            return str(variables[key])
        return match.group(0)

    # Match {{...}} but NOT ${{...}}
    # Negative lookbehind for $ to skip GitHub Actions
    result = re.sub(r'(?<!\$)\{\{([^}]+)\}\}', replacer, content)
    return result


def resolve_path(path_template: str, variables: dict) -> str:
    """Resolve {variable} in output path strings."""
    result = path_template
    for key, value in variables.items():
        if isinstance(value, str):
            result = result.replace(f"{{{key}}}", value)
    return result


def process_file(src: Path, dst: Path, variables: dict, dry_run: bool = False) -> bool:
    """Process a single template file. Returns True if file was written."""
    if not src.exists():
        print(f"  [SKIP] Template not found: {src.relative_to(TEMPLATES_DIR)}")
        return False

    # Read source
    try:
        content = src.read_text(encoding="utf-8")
    except UnicodeDecodeError:
        # Binary file — copy as-is
        if not dry_run:
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src, dst)
        return True

    # Apply substitution only for .tmpl files
    if src.name.endswith(".tmpl"):
        content = substitute(content, variables)

    if dry_run:
        return True

    # Write output
    dst.parent.mkdir(parents=True, exist_ok=True)
    dst.write_text(content, encoding="utf-8")

    # Make shell scripts executable
    if dst.suffix in (".sh", "") and content.startswith("#!"):
        try:
            os.chmod(dst, 0o755)
        except OSError:
            pass

    return True


def generate_phase(phase: str, output_dir: Path, variables: dict, dry_run: bool = False) -> list[str]:
    """Generate files for a single phase. Returns list of generated file paths."""
    generated = []
    phase_config = PHASE_MAP[phase]

    if "sources" in phase_config:
        for src_rel, dst_rel in phase_config["sources"]:
            src = TEMPLATES_DIR / src_rel
            dst_resolved = resolve_path(dst_rel, variables)
            dst = output_dir / dst_resolved

            if process_file(src, dst, variables, dry_run):
                generated.append(dst_resolved)
                if not dry_run:
                    print(f"  [OK] {dst_resolved}")

    if "feature_templates" in phase_config:
        features = variables.get("features", [])
        for feature in features:
            feature_vars = {**variables}
            feature_vars["feature_name"] = feature.get("name", "")
            feature_vars["feature_slug"] = feature.get("slug", "")
            feature_vars["resource_name"] = feature.get("resource_name", feature.get("name", ""))
            feature_vars["resource_name_lower"] = feature_vars["resource_name"].lower()
            feature_vars["resource_plural"] = feature.get("resource_plural", feature_vars["resource_name"] + "s")
            feature_vars["resource_plural_lower"] = feature_vars["resource_plural"].lower()

            for src_rel, dst_rel in phase_config["feature_templates"]:
                src = TEMPLATES_DIR / src_rel
                dst_resolved = resolve_path(dst_rel, feature_vars)
                dst = output_dir / dst_resolved

                if process_file(src, dst, feature_vars, dry_run):
                    generated.append(dst_resolved)
                    if not dry_run:
                        print(f"  [OK] {dst_resolved}")

    return generated


def create_init_files(output_dir: Path, package_name: str):
    """Create __init__.py files for Python package structure."""
    dirs_needing_init = [
        f"src/{package_name}/app/core",
        f"src/{package_name}/app/api",
        f"src/{package_name}/app/api/v1",
        f"src/{package_name}/app/api/v1/endpoints",
        f"src/{package_name}/app/models",
        f"src/{package_name}/app/db",
        f"src/{package_name}/app/observability",
        f"src/{package_name}/app/inference",
        f"src/{package_name}/app/services",
        f"src/{package_name}/app/storage",
        f"src/{package_name}/tests",
        f"src/{package_name}/tests/unit",
        f"src/{package_name}/tests/integration",
        f"src/{package_name}/tests/security",
    ]
    for d in dirs_needing_init:
        dir_path = output_dir / d
        dir_path.mkdir(parents=True, exist_ok=True)
        init_file = dir_path / "__init__.py"
        if not init_file.exists():
            init_file.write_text("")


def main():
    parser = argparse.ArgumentParser(
        description="Intel AI Solutions — Project Scaffold Generator",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__,
    )
    parser.add_argument("--vars", required=True, type=Path, help="YAML variables/handoff file")
    parser.add_argument("--output", required=True, type=Path, help="Output directory")
    parser.add_argument(
        "--phase",
        choices=["all", "config", "github", "backend", "frontend", "frontend_features", "docker", "helm", "ansible"],
        default="all",
        help="Which phase to generate (default: all)",
    )
    parser.add_argument("--dry-run", action="store_true", help="Show what would be generated without writing")
    parser.add_argument("--force", action="store_true", help="Overwrite existing files")

    args = parser.parse_args()

    if not args.vars.exists():
        print(f"ERROR: Variables file not found: {args.vars}")
        sys.exit(1)

    variables = load_vars(args.vars)

    # Validate required variables
    required = ["project_name", "project_slug", "package_name", "port"]
    missing = [k for k in required if not variables.get(k)]
    if missing:
        print(f"ERROR: Missing required variables: {', '.join(missing)}")
        sys.exit(1)

    output_dir = args.output.resolve()

    if not args.force and output_dir.exists() and any(output_dir.iterdir()):
        # Check for conflict only if not forcing
        pass

    print(f"{'[DRY RUN] ' if args.dry_run else ''}Scaffolding: {variables['project_name']}")
    print(f"  Output: {output_dir}")
    print(f"  Phase:  {args.phase}")
    print(f"  Vars:   project_slug={variables['project_slug']}, package_name={variables['package_name']}, port={variables['port']}")
    print()

    phases_to_run = list(PHASE_MAP.keys()) if args.phase == "all" else [args.phase]
    total_generated = []

    for phase in phases_to_run:
        print(f"--- Phase: {phase} ---")
        generated = generate_phase(phase, output_dir, variables, args.dry_run)
        total_generated.extend(generated)

    # Create __init__.py files for Python packages
    if args.phase in ("all", "backend") and not args.dry_run:
        create_init_files(output_dir, variables["package_name"])

    print()
    print(f"{'[DRY RUN] ' if args.dry_run else ''}Generated {len(total_generated)} files.")

    if not args.dry_run:
        # Write manifest for traceability
        manifest_dir = output_dir / "reports" / "generation"
        manifest_dir.mkdir(parents=True, exist_ok=True)
        manifest = {
            "generator": "scripts/scaffold.py",
            "timestamp": datetime.now().isoformat(),
            "variables": {k: v for k, v in variables.items() if isinstance(v, (str, int, float, bool))},
            "phases": phases_to_run,
            "files_generated": total_generated,
            "total_count": len(total_generated),
        }
        import json
        (manifest_dir / "scaffold-manifest.json").write_text(
            json.dumps(manifest, indent=2), encoding="utf-8"
        )

    return 0


if __name__ == "__main__":
    sys.exit(main())
