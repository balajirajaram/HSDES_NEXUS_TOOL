# Copyright (C) 2025 Intel Corporation
# SPDX-License-Identifier: Apache-2.0

"""Updates .iteration-state.json after each pipeline phase completes."""

from __future__ import annotations

import argparse
import json
import shutil
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

TOOLS = {
    "ruff": "ruff --version",
    "mypy": "mypy --version",
    "bandit": "bandit --version",
    "trivy": "trivy --version",
    "pip_audit": "pip-audit --version",
    "pip_licenses": "pip-licenses --version",
    "detect_secrets": "detect-secrets --version",
    "python_pptx": "python -c \"import pptx\"",
    "helm": "helm version --short",
    "docker": "docker --version",
    "shellcheck": "shellcheck --version",
    "cosign": "cosign version",
}


def check_tool(cmd: str) -> bool:
    try:
        subprocess.run(
            cmd, shell=True, capture_output=True, timeout=10
        )
        return True
    except (subprocess.TimeoutExpired, FileNotFoundError, OSError):
        return False


def detect_tools() -> dict[str, bool]:
    return {name: check_tool(cmd) for name, cmd in TOOLS.items()}


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def load_state(state_path: Path) -> dict:
    if state_path.exists():
        return json.loads(state_path.read_text(encoding="utf-8"))
    return {}


def initialize_state(project_name: str, project_slug: str, prd_path: str = "") -> dict:
    return {
        "project": {
            "name": project_name,
            "slug": project_slug,
            "created_at": now_iso(),
            "prd_path": prd_path,
        },
        "current_iteration": 1,
        "phases": {
            "prd": {"status": "not_started"},
            "generation": {"status": "not_started"},
            "validation": {"status": "not_started"},
            "compliance": {"status": "not_started"},
            "dashboard": {"status": "not_started"},
        },
        "skipped_items": [],
        "tool_availability": detect_tools(),
        "iteration_history": [],
        "next_iteration_requirements": {
            "tools_to_install": [],
            "configs_needed": [],
            "services_to_deploy": [],
        },
    }


def update_phase(state: dict, phase: str, status: str, report_path: str = "", notes: str = "") -> dict:
    if phase not in state.get("phases", {}):
        print(f"ERROR: Unknown phase '{phase}'. Valid: prd, generation, validation, compliance, dashboard")
        sys.exit(1)

    phase_data = state["phases"][phase]
    phase_data["status"] = status
    phase_data["iteration"] = state["current_iteration"]

    if status in ("completed", "partial"):
        phase_data["completed_at"] = now_iso()
    if report_path:
        phase_data["report_path"] = report_path
    if notes:
        phase_data["notes"] = notes

    state["tool_availability"] = detect_tools()
    return state


def add_skipped(state: dict, item: str, reason: str, phase: str, needed: str) -> dict:
    state.setdefault("skipped_items", [])
    entry = {
        "item": item,
        "reason": reason,
        "phase": phase,
        "needed_for_next": needed,
    }
    existing = [s for s in state["skipped_items"] if s["item"] == item]
    if not existing:
        state["skipped_items"].append(entry)
    return state


def complete_iteration(state: dict, notes: str = "") -> dict:
    phases_run = [p for p, d in state["phases"].items() if d.get("status") != "not_started"]
    state.setdefault("iteration_history", [])
    state["iteration_history"].append({
        "iteration": state["current_iteration"],
        "started_at": state["project"]["created_at"],
        "completed_at": now_iso(),
        "phases_run": phases_run,
        "notes": notes,
    })

    missing_tools = [name for name, available in state.get("tool_availability", {}).items() if not available]
    tools_info = []
    install_hints = {
        "trivy": ("brew install trivy", "Container/filesystem vulnerability scanning"),
        "helm": ("brew install helm", "Helm chart linting and validation"),
        "python_pptx": ("pip install python-pptx", "OSPDT PowerPoint deck generation"),
        "shellcheck": ("brew install shellcheck", "Shell script analysis"),
        "cosign": ("brew install cosign", "Container image signing"),
        "detect_secrets": ("pip install detect-secrets", "Secret leak detection"),
    }
    for tool in missing_tools:
        if tool in install_hints:
            cmd, purpose = install_hints[tool]
            tools_info.append({"name": tool, "install_command": cmd, "purpose": purpose})

    state["next_iteration_requirements"]["tools_to_install"] = tools_info
    return state


def save_state(state: dict, state_path: Path) -> None:
    state_path.write_text(json.dumps(state, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(f"Updated: {state_path}")


def main():
    parser = argparse.ArgumentParser(description="Update .iteration-state.json")
    sub = parser.add_subparsers(dest="command", required=True)

    init_p = sub.add_parser("init", help="Initialize state for a new project")
    init_p.add_argument("--project-name", required=True)
    init_p.add_argument("--project-slug", required=True)
    init_p.add_argument("--prd-path", default="")
    init_p.add_argument("--output-dir", default=".")

    phase_p = sub.add_parser("phase", help="Update a phase status")
    phase_p.add_argument("--name", required=True, choices=["prd", "generation", "validation", "compliance", "dashboard"])
    phase_p.add_argument("--status", required=True, choices=["not_started", "in_progress", "completed", "partial", "skipped"])
    phase_p.add_argument("--report-path", default="")
    phase_p.add_argument("--notes", default="")
    phase_p.add_argument("--output-dir", default=".")

    skip_p = sub.add_parser("skip", help="Record a skipped item")
    skip_p.add_argument("--item", required=True)
    skip_p.add_argument("--reason", required=True)
    skip_p.add_argument("--phase", required=True)
    skip_p.add_argument("--needed", required=True)
    skip_p.add_argument("--output-dir", default=".")

    done_p = sub.add_parser("complete", help="Mark current iteration complete")
    done_p.add_argument("--notes", default="")
    done_p.add_argument("--output-dir", default=".")

    args = parser.parse_args()
    output_dir = Path(args.output_dir)
    state_path = output_dir / ".iteration-state.json"

    if args.command == "init":
        state = initialize_state(args.project_name, args.project_slug, args.prd_path)
        save_state(state, state_path)

    elif args.command == "phase":
        state = load_state(state_path)
        if not state:
            print("ERROR: No .iteration-state.json found. Run 'init' first.")
            sys.exit(1)
        state = update_phase(state, args.name, args.status, args.report_path, args.notes)
        save_state(state, state_path)

    elif args.command == "skip":
        state = load_state(state_path)
        if not state:
            print("ERROR: No .iteration-state.json found. Run 'init' first.")
            sys.exit(1)
        state = add_skipped(state, args.item, args.reason, args.phase, args.needed)
        save_state(state, state_path)

    elif args.command == "complete":
        state = load_state(state_path)
        if not state:
            print("ERROR: No .iteration-state.json found. Run 'init' first.")
            sys.exit(1)
        state = complete_iteration(state, args.notes)
        state["current_iteration"] += 1
        save_state(state, state_path)


if __name__ == "__main__":
    main()
