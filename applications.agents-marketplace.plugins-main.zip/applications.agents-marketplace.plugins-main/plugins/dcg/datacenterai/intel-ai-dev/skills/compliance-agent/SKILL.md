---
name: compliance-agent
description: Run the full Intel compliance stack on a generated project — Bandit/Trivy security scans, OSPDT PowerPoint deck, SDLE architecture diagrams, SBOM, license inventory, and unified DASHBOARD.md. Use this skill whenever the user mentions compliance, security scan, OSPDT, SDLE, SBOM, license inventory, compliance-agent, or asks "is this Intel-compliant" or "ready to ship". Re-verifies contract rules C1-C14. Always runs Phase 0 session recovery first.
---

---

# Intel AI Compliance Agent — Security & Open Source Compliance

> **UX Reference**: Follow `.claude/shared/ux/human-in-the-loop.md` for ALL user prompts.
> Use the structured decision format (context → next step → options) for every gate.
> **MANDATORY**: Follow the Phase Announce/Summary pattern — at EVERY phase, tell the
> developer what you're about to do BEFORE doing it, and summarize what you achieved AFTER.
> Developer must have the opportunity to iterate or change direction between phases.

Runs security scans, generates OSPDT PowerPoint deck, creates SDLE diagrams,
produces SBOM, and publishes compliance reports. Mirrors Enterprise-Inference
code-scans.yaml patterns.

## Model
opus

## Trigger
When user says: "run compliance", "security scan", "generate OSPDT", "compliance check",
"SDLE diagrams", "compliance-agent"

---

## Phase 0: Session Recovery (MANDATORY — runs FIRST)

Before any work, check for prior session state. Follow `.claude/shared/ux/resumption-pattern.md` exactly.

1. Check if `.iteration-state.json` exists (look for compliance phase status)
2. Check if `reports/compliance/` already has results from a prior run
3. Search Claude memory for project status entries

**If prior compliance found (partial):** "Compliance scans ran previously — some skipped. Retry skipped scans, re-run all, or generate DASHBOARD from current results?"
**If prior compliance found (complete):** "Compliance already complete. Re-run, or view DASHBOARD?"
**If skipped items from prior run (e.g., Trivy not installed):** Check if tools are now available, offer to retry.
**If no prior state:** Proceed to Phase 1 normally.

---

## Phase 1: Security Scanning

### Step 1: Discover Project

```
I'll run a full compliance scan on your project.

What would you like to do?
1. Full compliance (scans + OSPDT + SDLE + SBOM)
2. Security scans only
3. OSPDT deck only
4. SDLE diagrams only
5. SBOM generation only
```

### Step 1.5: Contract Rules Verification (C1-C14)

Before security scanning, verify structural compliance with dev-agent contract rules:

```bash
# Quick contract check (same as validation-agent Phase 1.5)
echo "Checking contract rules C1-C14..."

# C1: List endpoints use PaginatedResponse
C1_PASS=$(grep -r "PaginatedResponse" src/ | wc -l)
echo "C1 (PaginatedResponse): $C1_PASS endpoints verified"

# C9: Frontend-backend field alignment
echo "C9 (Field alignment): checking..."
# Compare TypeScript interface fields vs Pydantic schema fields

# C10: No phantom endpoints
echo "C10 (Route coverage): checking registered vs implemented..."

# C14: No orphan files
ORPHANS=$(find src/ -name "*.py" ! -name "__init__.py" ! -name "conftest.py" -exec basename {} .py \; | \
  while read m; do grep -rq "$m" src/ --include="*.py" || echo "$m"; done | wc -l)
echo "C14 (Orphan files): $ORPHANS potential orphans"
```

Include contract compliance results in the final DASHBOARD.

### Step 2: Run Scans

**Activate project venv first** (scanning tools read installed packages for license/audit):

```bash
cd src/{component}
source .venv/Scripts/activate 2>/dev/null || source .venv/bin/activate
python -c "import sys; assert '.venv' in sys.prefix, 'NOT IN VENV'"
cd ../..
```

If tools (bandit, pip-audit, pip-licenses, detect-secrets) are not in the venv,
install them: `pip install bandit pip-audit pip-licenses detect-secrets`
Or invoke via `python -m bandit`, `python -m pip_audit`, `python -m piplicenses`, etc.

Execute all security scans (mirrors Enterprise-Inference code-scans.yml):

```bash
# SAST — Semgrep (if plugin available — preferred over Bandit for breadth)
# The semgrep plugin runs via MCP — use it for OWASP Top 10, Python security, TypeScript security
# If semgrep plugin not available, fall back to Bandit

# SAST — Bandit (Python) — always run as baseline
python -m bandit -r src/ -f json -o docs/reports/bandit-report.json \
  -s B101 --exclude "*/tests/*" 2>/dev/null || echo "bandit not installed"

# SAST — CodeQL (if available)
# Runs in CI via .github/workflows/codeql-analysis.yml

# Shell script analysis
find . -name "*.sh" -exec shellcheck {} \; 2>/dev/null || echo "shellcheck not installed"

# Container scanning
trivy fs --severity HIGH,CRITICAL --format json \
  -o docs/reports/trivy-fs-report.json . 2>/dev/null || echo "trivy not installed"

# Container image scanning (if image exists)
trivy image --severity HIGH,CRITICAL --format json \
  -o docs/reports/trivy-image-report.json {image}:latest 2>/dev/null || true

# Dependency audit — Python
python -m pip_audit --format json --output docs/reports/pip-audit-report.json \
  2>/dev/null || echo "pip-audit not installed"

# Dependency audit — Node.js (if frontend exists)
cd frontend && npm audit --json > ../docs/reports/npm-audit-report.json 2>/dev/null || true
cd ..

# License check
python -m piplicenses --format json --output-file docs/reports/license-report.json \
  2>/dev/null || echo "pip-licenses not installed"

# Secret scanning
python -m detect_secrets scan --all-files > docs/reports/secrets-report.json \
  2>/dev/null || echo "detect-secrets not installed"
```

### Step 3: Scan Summary

```
Security Scan Results
=====================
SAST (Bandit):       {HIGH} high, {MEDIUM} medium, {LOW} low findings
Container (Trivy):   {CRITICAL} critical, {HIGH} high vulnerabilities
Dependencies:        {count} known CVEs
Licenses:            {permissive} permissive, {copyleft} copyleft, {unknown} unknown
Secrets:             {count} potential secrets detected

Overall: {PASS / NEEDS ATTENTION / CRITICAL}
```

---

## Phase 2: Auto-Fix (Safe Only)

For findings with safe auto-fixes:

```
Safe auto-fixes available:
1. Upgrade {package} {old_ver} → {new_ver} (fixes CVE-{id})
2. Fix Bandit B102: Use subprocess with shell=False
3. Fix ruff: {description}

Apply these fixes? (yes / review each / skip)
```

Rules for auto-fix:
- **Minor/patch dependency upgrades only** — never major version bumps
- **Ruff style fixes only** — formatting, import sorting, unused imports
- **NEVER auto-fix Bandit security findings** — security fixes require understanding context
  (e.g., B102 subprocess: removing shell=True may break the command if it uses shell features)
- **Present ALL proposed fixes for developer review** — never auto-commit
- **Create a separate commit** for auto-fixes
- **After fixing, re-run the scan** — verify fix didn't introduce new issues
- **If fix breaks imports or tests** — revert immediately, flag as "manual fix required"

---

## Phase 3: OSPDT BOM Excel Generation

Extract project dependencies and generate a formatted Excel BOM for OSPDT submission.

### Step 1: Extract BOM

```bash
python .claude/skills/compliance-agent/scripts/extract_bom.py \
  --project-dir {project_path} \
  --output {output_dir}/bom.json
```

Sources scanned:
- **Python**: pip-licenses (if venv active) or requirements.txt / pyproject.toml
- **Node**: package.json (production + dev dependencies)
- **Docker**: FROM directives in Dockerfiles
- **Helm**: Chart.yaml dependencies

### Step 2: Generate Excel

```bash
python .claude/skills/compliance-agent/scripts/generate_bom_excel.py \
  --bom {output_dir}/bom.json \
  --project-name "{project_name}" \
  --output {output_dir}/ospdt-bom-{project_slug}.xlsx
```

### Excel Output Format

**Sheet 1: BOM**

| Component Name | Origin | Version | License | Distributed by You? | Purpose/Comments |
|----------------|--------|---------|---------|---------------------|------------------|

- Origin = python / node / docker / helm
- "Distributed by You?" = Yes for all (bundled in container)
- Intel blue (#003580) header styling

**Sheet 2: Summary**

| Origin | Count |
|--------|-------|
| Python | {n} |
| Node | {n} |
| Docker | {n} |
| Helm | {n} |
| **Total** | **{n}** |

### Report Status

After generation, update the DASHBOARD status matrix:
- OSPDT row: status = READY, recommendation = APPROVE (if 0 copyleft) or REVIEW (if copyleft found)

---

## Phase 4: Architecture Diagrams (Mermaid + SVG)

Generate diagrams following Intel SDLE requirements. Two formats are produced:
- **Mermaid** — for inline rendering in GitHub, Confluence, and documentation
- **SVG** — industry-standard pixel-perfect diagrams for README and presentations

### Step 1: Generate Mermaid Diagrams (SDLE)

```bash
python scripts/generate-sdle-diagrams.py \
  --project-dir . \
  --output-dir reports/architecture/
```

#### Mermaid Diagrams Generated

1. **Threat Model** (`reports/architecture/threat-model.md`)
   - STRIDE analysis diagram (Mermaid flowchart)
   - Trust boundaries as subgraphs
   - Attack surface annotations

2. **Data Flow** (`reports/architecture/data-flow.md`)
   - Level 0: Context diagram (Mermaid flowchart)
   - Level 1: Component interactions with data labels
   - Data classification labels on each flow

3. **Component Architecture** (`reports/architecture/component-arch.md`)
   - Microservice topology (Mermaid flowchart)
   - Communication patterns (sync/async arrows)
   - Shared infrastructure

4. **Deployment Architecture** (`reports/architecture/deployment-arch.md`)
   - Kubernetes namespace layout (Mermaid flowchart with subgraphs)
   - NetworkPolicy visualization
   - Ingress/egress paths

5. **Sequence Diagrams** (`reports/architecture/api-sequences.md`)
   - Auth flow (Mermaid sequence diagram)
   - Critical API flows from PRD
   - Error handling paths

### Step 2: Generate Final SVG Architecture Diagram (MANDATORY)

After all scans and Mermaid diagrams are complete, generate the **final industry-standard
SVG** that reflects the actual deployed code state (not the PRD's initial design).

```bash
python scripts/gen_solution_svg.py \
  --project-dir {project_dir} \
  --project-name "{project_name}" \
  --output {project_dir}/docs/architecture/solution-overview.svg
```

This SVG is the **authoritative architecture diagram** because:
- It reads the ACTUAL project structure (not assumptions from PRD)
- It discovers components, ports, dependencies from code/config
- It reflects any changes made during dev-agent iterations
- It uses Intel brand colors for professional presentation

**After generating, update the project's README.md:**
```markdown
## Architecture

![Solution Architecture](docs/architecture/solution-overview.svg)
```

If the README already has an `## Architecture` section (from dev-agent Phase 4.7),
replace the existing diagram with this final SVG. The compliance-phase SVG is
authoritative because it's generated from the final code state after all iterations.

### Step 3: Verify Diagram Accuracy

Cross-check the generated diagrams against actual code:
- Every component in SVG must have a corresponding directory in `src/` or `frontend/`
- Every external dependency (EI, Keycloak, DB) must be in config/requirements
- Port numbers must match config files
- Data flow arrows must match actual API call patterns

If discrepancies found, regenerate from code — never leave stale diagrams.

---

## Phase 5: SBOM Generation

```bash
python scripts/generate-sbom.py \
  --project-dir . \
  --format cyclonedx \
  --output docs/reports/sbom-{project_slug}.json
```

Or using Trivy:
```bash
trivy fs --format cyclonedx --output docs/reports/sbom.json .
trivy image --format cyclonedx --output docs/reports/sbom-image.json {image}:latest
```

---

## Phase 6: SLSA Verification

Check SLSA Level 2+ compliance:

```
SLSA Compliance Check
=====================
☐ Scripted build (GitHub Actions CI)        → {✓/✗}
☐ Build service (hosted runners)             → {✓/✗}
☐ Build provenance generated                 → {✓/✗}
☐ Container images signed (cosign)           → {✓/✗}
☐ SBOM attached to release                   → {✓/✗}
☐ Dependencies pinned (lock files)           → {✓/✗}
☐ Source available (public/internal repo)     → {✓/✗}

SLSA Level: {0 / 1 / 2 / 3}
```

---

## Phase 7: OpenSSF Scorecard Check

```
OpenSSF Scorecard Estimate
==========================
☐ Branch protection (2+ reviewers)           → {✓/✗}
☐ Code review required                       → {✓/✗}
☐ CI tests on PR                             → {✓/✗}
☐ SAST enabled                               → {✓/✗}
☐ Dependency updates (Dependabot)            → {✓/✗}
☐ Signed releases                            → {✓/✗}
☐ Security policy (SECURITY.md)              → {✓/✗}
☐ License (LICENSE file)                     → {✓/✗}
☐ No binary artifacts                        → {✓/✗}
☐ Pinned dependencies                        → {✓/✗}

Estimated Score: {X}/10
```

---

## Phase 8: Generate Reports

Create reports in the standard output structure (see `.claude/shared/contracts/output-structure-schema.md`):

### `reports/compliance/security-scan.md`

```markdown
# Security Scan Report — {project_name}
Date: {date}

## Executive Summary
Overall Status: {PASS / CONDITIONAL / FAIL}

## SAST (Bandit)
| Severity | Count | Auto-fixed | Remaining |
|----------|-------|------------|-----------|
| HIGH     | X     | X          | X         |
| MEDIUM   | X     | X          | X         |
| LOW      | X     | X          | X         |

## Container Vulnerabilities (Trivy)
{Results if trivy available, otherwise: "SKIPPED — trivy not installed"}

## Dependency Audit (pip-audit)
{Results if pip-audit available}

## Secret Scanning (detect-secrets)
{Results if detect-secrets available}

## Action Items
1. {Fix HIGH severity findings}
2. {Upgrade vulnerable dependencies}
```

### `reports/compliance/license-inventory.md`

```markdown
# License Inventory — {project_name}
Date: {date}

## Summary
| License Type | Count | Status |
|-------------|-------|--------|
| Permissive (MIT, BSD, Apache-2.0) | X | ✓ APPROVED |
| Weak Copyleft (MPL-2.0, LGPL) | X | ⚠ REVIEW |
| Copyleft (GPL, AGPL) | X | ✗ BLOCKED |

## Full Inventory
| Package | Version | License | Classification |
|---------|---------|---------|----------------|
| ... | ... | ... | GREEN/YELLOW/RED |
```

### `reports/compliance/slsa-checklist.md`

```markdown
# SLSA & OpenSSF Assessment — {project_name}
Date: {date}

## SLSA Compliance
SLSA Level: {X}
{checklist items with ✓/✗}

## OpenSSF Scorecard Estimate
Score: {X}/10
{checklist items with ✓/✗}

## OSPDT Status
Status: {READY / NEEDS REVIEW}
Recommendation: {APPROVE / CONDITIONAL / REJECT}
Deck: reports/compliance/ospdt-deck.pptx (if generated)
```

### `reports/architecture/` directory

Architecture diagrams go to `reports/architecture/`:
- `reports/architecture/threat-model.md` — STRIDE analysis, trust boundaries
- `reports/architecture/data-flow.md` — Level 0 + Level 1 diagrams
- `reports/architecture/component-arch.md` — Microservice topology
- `reports/architecture/deployment-arch.md` — K8s namespace layout, NetworkPolicy
- `reports/architecture/api-sequences.md` — Auth flow, critical API paths

All diagrams use Mermaid syntax for rendering in GitHub and Confluence.

### `reports/compliance/ospdt-deck.pptx`

Generated only when python-pptx is available. If not available, mark as skipped
in iteration state and note in the SLSA checklist.

---

## Phase 9: Generate Dashboard & Publish

### Step 1: Generate Dashboard (FINAL STEP)

As the **FINAL step** of the entire pipeline, generate `reports/DASHBOARD.md` from the
dashboard template at `templates/dashboard/DASHBOARD.md.tmpl`.

Fill in all `{{variable}}` placeholders:
- Read `.iteration-state.json` for phase statuses and tool availability
- Read all generated reports for metrics (coverage %, findings count, etc.)
- Determine next steps based on what was skipped

This is the one-stop summary that ties all outputs together.

### Step 2: Update Iteration State

Update `.iteration-state.json` — add/update the CANONICAL phase keys:

```json
{
  "phases": {
    "compliance": {
      "status": "completed",
      "completed_at": "2026-05-14T14:00:00Z",
      "iteration": 1,
      "report_path": "reports/compliance/security-scan.md",
      "notes": "Bandit + pip-audit + detect-secrets + license inventory"
    },
    "dashboard": {
      "status": "completed",
      "completed_at": "2026-05-14T14:05:00Z",
      "iteration": 1,
      "report_path": "reports/DASHBOARD.md"
    }
  }
}
```

Also:
- Add any skipped items to `skipped_items` array
- Update `tool_availability` with all detected tools
- Record in `iteration_history`
- Do NOT remove existing keys (dev-agent sub-phases, integrations, etc.)

### Step 3: Show Iteration Summary

Use the format from `.claude/shared/ux/iteration-summary-template.md`:

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
✅ ITERATION 1 COMPLETE — Compliance & Security
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

COVERED:
• Bandit SAST: {findings summary}
• pip-audit: {findings summary}
• detect-secrets: {findings summary}
• License check: {package count} packages analyzed
• SLSA checklist: Level {X}
• Architecture diagrams: {count} Mermaid diagrams generated
• DASHBOARD generated with full status matrix

SKIPPED (needs config/infra):
• Trivy container scan — trivy not installed — {install command}
• OSPDT deck — python-pptx not installed — pip install python-pptx
• Container image scan — no built image — docker build first
• cosign signing — cosign not installed — {install command}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📊 REPORTS GENERATED
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
• DASHBOARD: reports/DASHBOARD.md
• Security Scan: reports/compliance/security-scan.md
• License Inventory: reports/compliance/license-inventory.md
• SLSA Checklist: reports/compliance/slsa-checklist.md
• Threat Model: reports/architecture/threat-model.md
• Data Flow: reports/architecture/data-flow.md
• Component Arch: reports/architecture/component-arch.md
• Deployment Arch: reports/architecture/deployment-arch.md
• API Sequences: reports/architecture/api-sequences.md

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
⏭️ FOR ITERATION 2
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
1. Install: {tools needed with commands}
2. Configure: {configs needed}
3. Deploy: {build Docker images, etc.}
4. Then run: /compliance-agent again to cover container scans + OSPDT deck
```

### Step 4: Program Checkpoints (MANDATORY)

**After compliance completes, you MUST present the Program Checkpoints gate.**

Follow `.claude/shared/ux/program-checkpoints.md` exactly. Present ALL 3 checkpoints together:

1. **Wiki** — Publish compliance report + DASHBOARD to Confluence
2. **Jira** — Update EPICs with compliance status (PASS/CONDITIONAL/FAIL)
3. **Git** — Commit compliance artifacts + DASHBOARD, push

**Commit message:**
```
docs({project_slug}): Add compliance artifacts and DASHBOARD

- Security scan: {findings} findings
- SDLE diagrams: {diagram_count} generated
- SLSA Level: {slsa_level}
- DASHBOARD: reports/DASHBOARD.md
```

**After checkpoints are processed:** Save project state to Claude memory automatically (see program-checkpoints.md § Memory Save).

Then show pipeline completion:
```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
✅ PIPELINE COMPLETE — All 4 phases done
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
• PRD → Code → Tests → Compliance ✓
• Dashboard: reports/DASHBOARD.md
• All checkpoints processed

🔀 YOUR OPTIONS
1. Open reports/DASHBOARD.md for full summary
2. Re-run specific phase with fixes
3. Done — start a new project
```

---

## Critical Rules

1. **Never auto-fix without confirmation** — present all fixes, wait for approval
2. **Flag copyleft licenses immediately** — GPL/AGPL blocks Intel distribution
3. **All scan results saved as JSON** — for audit trail
4. **OSPDT deck uses Intel brand** — #003580 blue, Calibri font
5. **Mermaid for all diagrams** — renders in GitHub and Confluence
6. **CycloneDX format for SBOM** — industry standard
7. **Report ALL findings** — don't suppress or minimize

---

## Tools Used

| Tool | Purpose | Install |
|------|---------|---------|
| bandit | Python SAST | `pip install bandit` |
| trivy | Container + FS scanning | system install |
| shellcheck | Shell script analysis | system install |
| pip-audit | Python dependency audit | `pip install pip-audit` |
| pip-licenses | License inventory | `pip install pip-licenses` |
| detect-secrets | Secret scanning | `pip install detect-secrets` |
| python-pptx | OSPDT deck generation | `pip install python-pptx` |
| cosign | Container signing | system install |

---

## Standards Applied
- `.claude/shared/standards/security-practices.md`
- `.claude/shared/standards/opensource-compliance.md`
- `.claude/shared/standards/container-standards.md`
- `.claude/shared/standards/ci-cd-standards.md`
