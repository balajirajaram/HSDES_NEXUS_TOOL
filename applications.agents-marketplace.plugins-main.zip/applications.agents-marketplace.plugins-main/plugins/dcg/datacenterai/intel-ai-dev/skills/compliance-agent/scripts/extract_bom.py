#!/usr/bin/env python3
"""Extract Bill of Materials (BOM) from a project's dependency files.

Scans requirements.txt, package.json, Dockerfiles, and Chart.yaml to produce
a unified BOM JSON suitable for OSPDT deck generation.
"""
from __future__ import annotations

import argparse
import json
import re
import subprocess
import sys
from pathlib import Path


def extract_python_deps(project_dir: Path) -> list[dict]:
    """Extract Python dependencies from requirements.txt or pip-licenses."""
    deps = []

    # Try pip-licenses first (most accurate)
    try:
        result = subprocess.run(
            [sys.executable, "-m", "piplicenses", "--format=json"],
            capture_output=True, text=True, cwd=project_dir, timeout=60
        )
        if result.returncode == 0:
            packages = json.loads(result.stdout)
            for pkg in packages:
                deps.append({
                    "name": pkg["Name"],
                    "version": pkg.get("Version", ""),
                    "license": pkg.get("License", "Unknown"),
                    "origin": "Python Package",
                    "distributed": "No",
                    "comments": "",
                })
            return deps
    except (subprocess.TimeoutExpired, FileNotFoundError, json.JSONDecodeError):
        pass

    # Fallback: parse requirements.txt
    req_files = list(project_dir.rglob("requirements*.txt"))
    seen = set()
    for req_file in req_files:
        if "node_modules" in str(req_file):
            continue
        for line in req_file.read_text(encoding="utf-8", errors="ignore").splitlines():
            line = line.strip()
            if not line or line.startswith("#") or line.startswith("-"):
                continue
            # Parse package name (before ==, >=, etc.)
            match = re.match(r"^([a-zA-Z0-9_.-]+)", line)
            if match:
                name = match.group(1)
                if name.lower() not in seen:
                    seen.add(name.lower())
                    version = ""
                    ver_match = re.search(r"[=><]+(.+)", line)
                    if ver_match:
                        version = ver_match.group(1).strip()
                    deps.append({
                        "name": name,
                        "version": version,
                        "license": "Unknown",
                        "origin": "Python Package",
                        "distributed": "No",
                        "comments": "",
                    })
    return deps


def extract_node_deps(project_dir: Path) -> list[dict]:
    """Extract Node.js dependencies from package.json files."""
    deps = []
    seen = set()

    for pkg_json in project_dir.rglob("package.json"):
        if "node_modules" in str(pkg_json):
            continue
        try:
            data = json.loads(pkg_json.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            continue

        all_deps = {}
        all_deps.update(data.get("dependencies", {}))
        all_deps.update(data.get("devDependencies", {}))

        for name, version in all_deps.items():
            if name.lower() not in seen:
                seen.add(name.lower())
                deps.append({
                    "name": name,
                    "version": version.lstrip("^~>=<"),
                    "license": "Unknown",
                    "origin": "Node Package",
                    "distributed": "No",
                    "comments": "",
                })
    return deps


def extract_docker_images(project_dir: Path) -> list[dict]:
    """Extract Docker base images from Dockerfiles."""
    deps = []
    seen = set()

    for dockerfile in project_dir.rglob("Dockerfile*"):
        if "node_modules" in str(dockerfile):
            continue
        try:
            content = dockerfile.read_text(encoding="utf-8", errors="ignore")
        except OSError:
            continue

        for match in re.finditer(r"^FROM\s+(\S+)", content, re.MULTILINE):
            image = match.group(1)
            if image.lower() not in seen and image != "scratch":
                seen.add(image.lower())
                # Determine license based on image
                license_guess = "Unknown"
                if "python" in image:
                    license_guess = "PSF/Debian"
                elif "node" in image or "npm" in image:
                    license_guess = "MIT"
                elif "nginx" in image:
                    license_guess = "BSD-2-Clause"
                elif "alpine" in image:
                    license_guess = "MIT"
                elif "ubuntu" in image or "debian" in image:
                    license_guess = "Various (Debian)"

                deps.append({
                    "name": image.split(":")[0].split("/")[-1],
                    "version": image.split(":")[-1] if ":" in image else "latest",
                    "license": license_guess,
                    "origin": "Container Image",
                    "distributed": "No",
                    "comments": f"FROM {image}",
                })
    return deps


def extract_helm_deps(project_dir: Path) -> list[dict]:
    """Extract Helm chart dependencies."""
    deps = []

    for chart_yaml in project_dir.rglob("Chart.yaml"):
        if "node_modules" in str(chart_yaml):
            continue
        try:
            import yaml
            data = yaml.safe_load(chart_yaml.read_text(encoding="utf-8"))
        except (ImportError, OSError):
            continue

        for dep in data.get("dependencies", []):
            deps.append({
                "name": dep.get("name", "unknown"),
                "version": dep.get("version", ""),
                "license": "Apache-2.0",
                "origin": "Helm Chart",
                "distributed": "No",
                "comments": f"repo: {dep.get('repository', 'N/A')}",
            })
    return deps


def main():
    parser = argparse.ArgumentParser(description="Extract BOM from project")
    parser.add_argument("--project-dir", required=True, help="Path to project root")
    parser.add_argument("--output", required=True, help="Output JSON path")
    args = parser.parse_args()

    project_dir = Path(args.project_dir)
    output_path = Path(args.output)

    python_deps = extract_python_deps(project_dir)
    node_deps = extract_node_deps(project_dir)
    docker_deps = extract_docker_images(project_dir)
    helm_deps = extract_helm_deps(project_dir)

    all_deps = python_deps + node_deps + docker_deps + helm_deps

    bom = {
        "project_dir": str(project_dir),
        "total": len(all_deps),
        "summary": {
            "python": len(python_deps),
            "node": len(node_deps),
            "docker": len(docker_deps),
            "helm": len(helm_deps),
        },
        "dependencies": all_deps,
    }

    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(json.dumps(bom, indent=2), encoding="utf-8")
    print(f"BOM extracted: {len(all_deps)} dependencies")
    print(f"  Python: {len(python_deps)}, Node: {len(node_deps)}, "
          f"Docker: {len(docker_deps)}, Helm: {len(helm_deps)}")


if __name__ == "__main__":
    main()
