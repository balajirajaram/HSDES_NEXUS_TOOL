#!/usr/bin/env python3
"""Generate OSPDT BOM Excel from extracted dependency data.

Takes the BOM JSON from extract_bom.py and produces a formatted Excel spreadsheet
suitable for attaching to an OSPDT submission.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path


def generate_excel_bom(deps: list[dict], output_path: Path, project_name: str = ""):
    """Generate Excel BOM for OSPDT submission."""
    try:
        from openpyxl import Workbook
        from openpyxl.styles import Font, PatternFill, Alignment
    except ImportError:
        print("ERROR: openpyxl not installed. Install with: pip install openpyxl")
        return None

    wb = Workbook()
    ws = wb.active
    ws.title = "BOM"

    # Header
    headers = ["Component Name", "Origin", "Version", "License",
               "Distributed by You?", "Purpose/Comments"]
    header_fill = PatternFill(start_color="003580", end_color="003580", fill_type="solid")
    header_font = Font(bold=True, color="FFFFFF", size=11)

    for col, header in enumerate(headers, 1):
        cell = ws.cell(row=1, column=col, value=header)
        cell.fill = header_fill
        cell.font = header_font
        cell.alignment = Alignment(horizontal="center")

    # Data
    for row_idx, dep in enumerate(deps, 2):
        ws.cell(row=row_idx, column=1, value=dep["name"])
        ws.cell(row=row_idx, column=2, value=dep.get("origin", ""))
        ws.cell(row=row_idx, column=3, value=dep.get("version", ""))
        ws.cell(row=row_idx, column=4, value=dep.get("license", "Unknown"))
        ws.cell(row=row_idx, column=5, value=dep.get("distributed", "No"))
        ws.cell(row=row_idx, column=6, value=dep.get("comments", ""))

    # Auto-width columns
    for col in ws.columns:
        max_len = max(len(str(cell.value or "")) for cell in col)
        ws.column_dimensions[col[0].column_letter].width = min(max_len + 2, 50)

    # Summary sheet
    ws2 = wb.create_sheet("Summary")
    if project_name:
        ws2.cell(row=1, column=1, value=f"BOM Summary — {project_name}")
    else:
        ws2.cell(row=1, column=1, value="BOM Summary")
    ws2.cell(row=1, column=1).font = Font(bold=True, size=14)

    # Count by origin
    origins = {}
    for dep in deps:
        origin = dep.get("origin", "Unknown")
        origins[origin] = origins.get(origin, 0) + 1

    ws2.cell(row=3, column=1, value="Origin")
    ws2.cell(row=3, column=2, value="Count")
    ws2.cell(row=3, column=1).font = Font(bold=True)
    ws2.cell(row=3, column=2).font = Font(bold=True)

    row = 4
    for origin, count in sorted(origins.items()):
        ws2.cell(row=row, column=1, value=origin)
        ws2.cell(row=row, column=2, value=count)
        row += 1

    ws2.cell(row=row + 1, column=1, value="Total")
    ws2.cell(row=row + 1, column=1).font = Font(bold=True)
    ws2.cell(row=row + 1, column=2, value=len(deps))

    wb.save(output_path)
    return output_path


def main():
    parser = argparse.ArgumentParser(description="Generate OSPDT BOM Excel")
    parser.add_argument("--bom", required=True, help="Path to BOM JSON from extract_bom.py")
    parser.add_argument("--project-name", default="", help="Project name for header")
    parser.add_argument("--output", required=True, help="Output Excel path (.xlsx)")
    args = parser.parse_args()

    bom_data = json.loads(Path(args.bom).read_text(encoding="utf-8"))
    deps = bom_data["dependencies"]

    output_path = Path(args.output)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    result = generate_excel_bom(deps, output_path, args.project_name)
    if result:
        print(f"OSPDT BOM Excel generated: {output_path}")
        print(f"  Total dependencies: {len(deps)}")
        print(f"  Python: {bom_data['summary'].get('python', 0)}")
        print(f"  Node: {bom_data['summary'].get('node', 0)}")
        print(f"  Docker: {bom_data['summary'].get('docker', 0)}")
        print(f"  Helm: {bom_data['summary'].get('helm', 0)}")


if __name__ == "__main__":
    main()
