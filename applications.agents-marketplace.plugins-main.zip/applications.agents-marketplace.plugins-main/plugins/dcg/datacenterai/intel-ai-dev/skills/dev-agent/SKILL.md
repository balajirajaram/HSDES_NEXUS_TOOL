---
name: dev-agent
description: Generate complete Intel AI project from a Technical PRD — backend, frontend, Helm, CI/CD, compliance baked in. Use this skill whenever the user mentions scaffold a project, generate project, start dev, create project from PRD, dev-agent, references a PRD file, or asks to build an Intel AI solution. Uses Intel standards and a hybrid scaffold+LLM architecture to avoid context exhaustion.
---

# Intel AI Dev Agent — Gold-Standard Project Generator

> **UX Reference**: Follow `.claude/shared/ux/human-in-the-loop.md` for ALL user prompts.
> Use the structured decision format (context → next step → options) for every gate.
> **MANDATORY**: Follow the Phase Announce/Summary pattern — at EVERY phase, tell the
> developer what you're about to do BEFORE doing it, and summarize what you achieved AFTER.
> Developer must have the opportunity to iterate or change direction between phases.

Reads a Technical PRD (from `/prd-agent`) and generates a complete, production-ready
project. Every generated file follows Enterprise-Inference and Enterprise-RAG patterns.

## Architecture: Hybrid Scaffold + Sub-Agent

This agent uses a two-layer approach to avoid context window exhaustion:

1. **scaffold.py** (Layer 1) — Mechanically stamps 150+ template files in 2 seconds.
   Zero LLM context needed. Handles config, GitHub, backend infra, frontend infra,
   Docker, Helm, Ansible. Run via: `python scripts/scaffold.py --vars handoff.yaml --output ./`

2. **LLM Sub-Phases** (Layer 2) — Focused creative work in separate context windows:
   - Phase 4: PRD-specific endpoints, models, schemas, services (~30KB context)
   - Phase 4.5: Dev sanity with real infrastructure (~10KB context per iteration)
   - Phase 4.6: Integration audit (~15KB context)
   - Phase 4.7: README generation (~20KB context)

**Why this matters:** The old approach tried to read 151 templates (228KB) + standards
(120KB) + PRD (30KB) in one context → context exhaustion at ~40% completion.
The hybrid approach guarantees 100% template coverage + focused creative generation.

## Progressive Disclosure — Phase Reference Files

Each phase has a dedicated reference file in `references/sub-phases/`. Load only the
phase you're currently executing — do NOT pre-load all phases. This is the core of
the hybrid architecture and what keeps the context window healthy.

| Phase | Reference File | When to Load |
|-------|---------------|--------------|
| Phase 1 — PRD Intake & Validation | `references/sub-phases/phase-1-prd-intake.md` | After Phase 0/0.5 complete |
| Phase 1.5 — Implementation Planning | `references/sub-phases/phase-1.5-planning.md` | After PRD validated |
| Phase 2 — Generate handoff.yaml & Run Scaffold | `references/sub-phases/phase-2-scaffold-run.md` | After plan approved |
| Phase 3 — Template Scaffold Output | `references/sub-phases/phase-3-template-scaffold.md` | After scaffold.py completes |
| Phase 4 — PRD-Specific Code Generation | `references/sub-phases/phase-4-code-generation.md` | After scaffold verified |
| Phase 4.5 — Dev Sanity Verification | `references/sub-phases/phase-4.5-dev-sanity.md` | After Phase 4 code complete |
| Phase 4.5b — User Acceptance Sanity | `references/sub-phases/phase-4.5b-user-acceptance.md` | After dev sanity passes |
| Phase 4.6 — Code Integration Audit | `references/sub-phases/phase-4.6-integration-audit.md` | After user acceptance passes |
| Phase 4.7 — Production-Ready README | `references/sub-phases/phase-4.7-readme.md` | After integration audit |
| Phase 4.8 — Developer README Verification | `references/sub-phases/phase-4.8-dev-validation.md` | After README generated |
| Phase 5 — Validation Handoff | `references/sub-phases/phase-5-validation.md` | After README signed off |
| Phase 6 — Post-Generation Reports & Checkpoints | `references/sub-phases/phase-6-post-generation.md` | Final phase |
| Code Patterns & Determinism Guarantees | `references/sub-phases/code-patterns-and-determinism.md` | Load when generating code in Phase 4 |

**Critical**: When entering a phase, read its reference file. The reference contains
all the exact prompts, checks, and Intel-specific requirements. The main SKILL.md
(this file) is the orchestrator only.

## Model
opus

## Trigger
When user says: "start dev", "generate project", "scaffold project", "create project from PRD",
"dev-agent", or references a Technical PRD file.

---

## Phase 0: Session Recovery (MANDATORY — runs FIRST)

Before any work, check for prior session state. Follow `.claude/shared/ux/resumption-pattern.md` exactly.

1. Check if `.iteration-state.json` exists in the working directory or any recent output directory
2. Search Claude memory for project status entries
3. Check git log for pipeline commits (`feat(prd):`, `feat({slug}):`)

**If prior state found:** Present the resumption prompt with progress, skipped items, and options (Continue / Retry skipped / Review / Start fresh). Do NOT re-ask questions already answered (output dir, PRD location, etc.) if continuing.

**If no prior state:** Check for integration setup, then proceed to Phase 1.

---

## Phase 0.5: Integration Setup (if not already configured)

If `.iteration-state.json` does NOT exist or does NOT have an `integrations` block,
run the integration setup from `.claude/shared/ux/integration-setup.md`.

This is critical when the user skips PRD agent and starts directly with Dev agent.
The setup collects Git remote URL, Wiki PAT, and Jira PAT (or local-only fallback).

**Auth precedence**: Environment variables (`WIKI_PAT`, `JIRA_PAT`) take priority over
interactive prompts. If env vars are set, use them silently and confirm with "Using
WIKI_PAT and JIRA_PAT from environment." Session memory is only the fallback for
interactive use.

**If integrations already configured** (from a prior PRD agent run): Skip this step entirely.
**If not configured**: Present the full integration setup prompt and store results.

---

## Phase 0.6: Preflight Dependency Check (MANDATORY)

Run preflight checks from `.claude/shared/ux/preflight-checks.md`:

- REQUIRED: python 3.11+, node 18+ (if frontend in PRD)
- OPTIONAL: ruff, docker, helm

If REQUIRED tools missing → block with install instructions.
If OPTIONAL tools missing → warn and continue, marking those checks as skipped in iteration-state.

---

## Execution Loop

For each phase in order (1 → 1.5 → 2 → 3 → 4 → 4.5 → 4.5b → 4.6 → 4.7 → 4.8 → 5 → 6):

1. **Read** the corresponding reference file from `references/sub-phases/`
2. **Announce** the phase using the human-in-the-loop pattern (what you'll do, expected output, time estimate)
3. **Wait** for developer confirmation unless the action is trivially reversible
4. **Execute** the steps in the reference file exactly
5. **Summarize** at completion (what was done, issues found, files affected)
6. **Offer options** (proceed / iterate / review)
7. **Save state** to `.iteration-state.json` after every phase
8. **Suggest git commit** — follow `.claude/shared/ux/git-versioning.md` exactly.
   Present the commit message and wait for developer acknowledgment before committing.
   Never add co-author/AI attribution lines. Only the developer is the author.

**Git commit triggers (in addition to phase completion):**
- Developer says "proceed" / "all good" / "looks good" → suggest commit
- 3+ files changed during an iteration loop → suggest checkpoint commit
- 10+ iterations without a commit → insist on checkpoint commit
- Before any destructive operation → suggest commit first

If at any point the developer says "iterate", re-announce the adjusted plan, then re-execute.
If they say "stop", save state, suggest a final commit, and present a clean handoff message.

---

## Standards & Contracts (Cross-Cutting — Always Apply)

These apply to EVERY phase. Do not skip even if the reference file doesn't explicitly mention them.

### Standards (from `.claude/shared/standards/`)
- `coding-standards.md` — ruff, mypy --strict, black, async patterns
- `tech-stack.md` — approved libraries and versions
- `security-practices.md` — OWASP, secrets, TLS, CORS, rate limiting
- `testing-standards.md` — pytest structure, coverage thresholds
- `helm-standards.md` — values parameterization, probes, resource limits
- `container-standards.md` — multi-stage, non-root uid=1000, healthchecks
- `ci-cd-standards.md` — pipeline stages, artifact management
- `observability-standards.md` — structured logging, metrics, traces
- `opensource-compliance.md` — license compatibility, OSPDT requirements
- `performance-optimization.md` — async, caching, query optimization
- `project-structure.md` — directory layout, module organization
- `ux-design-system.md` — Tailwind tokens, typography, spacing
- `validation-checklist.md` — pre-merge gate

### Contracts (from `.claude/shared/contracts/`)
- `iteration-state-schema.md` — the JSON shape of `.iteration-state.json` (write to this exactly)
- `output-structure-schema.md` — where every file goes
- `prd-output-schema.md` — what the PRD must contain to be parseable
- `compliance-report-schema.md`, `test-report-schema.md`, `jira-mapping-schema.md` — downstream contracts

### Contract Rules C1–C14 (enforced in Phase 4.6 and re-checked by validation/compliance/review agents)
- C1: List endpoints return `{items, total, page, size}` (CRITICAL)
- C2: All entity responses have `id: UUID` not prefixed (CRITICAL)
- C3: Auth contract matches template (CRITICAL)
- C4: Frontend types extend `BaseEntity` (HIGH)
- C5: API paths follow `/api/v1/{resource}` (HIGH)
- C6: SQLAlchemy columns snake_case (MEDIUM)
- C7: Task queue has dev-mode inline fallback (HIGH)
- C8: SQLite in dev, PostgreSQL in prod (HIGH)
- C9: Frontend field names EXACTLY match backend schemas (CRITICAL)
- C10: Every router endpoint is implemented — no phantoms (CRITICAL)
- C11: Dev-mode exercises production code paths — no mocks (HIGH)
- C12: Download/report endpoints if PRD requires (MEDIUM)
- C13: Deterministic output — same PRD = same product (LOW)
- C14: No orphan code — every file reachable from entrypoint (HIGH)

These are detailed in `references/sub-phases/code-patterns-and-determinism.md`.

---

## Plugin Usage

This agent leverages installed plugins:

- **playwright** — Phase 4.5 frontend render verification (see `.claude/shared/ux/playwright-usage.md`)
- **frontend-design** — auto-invokes during Phase 4 frontend generation
- **github** — Phase 6 commits, branch management, PR creation
- **context7** — Phase 4 library API lookups (FastAPI, React, Helm current versions)
- **code-review** — Phase 5 handoff to validation/review agents

---

## Failure Modes & Recovery

| Failure | Recovery |
|---------|----------|
| scaffold.py exits non-zero | Read its stderr, fix handoff.yaml, re-run. Do NOT proceed to Phase 4. |
| Phase 4 LLM run hits context limit | Save partial state, present "Resume from sub-step X?" prompt |
| Phase 4.5 dev sanity fails | Use phase-rollback-snapshot.py to rollback, fix the failing E2E, re-run |
| Phase 4.6 finds orphan files (C14 violation) | Auto-delete with confirmation, OR wire into service layer |
| Phase 4.8 developer rejects README | Iterate on README only, don't regenerate code |
| Any phase: tools missing | Mark skipped in iteration-state, present install instructions in iteration summary |

---

## Integration with Other Agents

| Trigger | Behavior |
|---------|----------|
| After Phase 6 completes | Suggest: "Run /validation-agent to generate tests and measure coverage?" |
| After Phase 4.6 | Suggest: "Run /review-agent for full code review?" |
| If `.iteration-state.json` shows validation/compliance complete | Suggest: "Run /review-agent for final PR review?" |
