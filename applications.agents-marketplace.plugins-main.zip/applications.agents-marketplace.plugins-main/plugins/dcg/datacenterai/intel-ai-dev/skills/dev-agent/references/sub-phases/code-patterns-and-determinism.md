## Code Patterns (Embedded Reference)

These are the EXACT patterns to follow. Do not deviate.

### FastAPI Main (from Enterprise-Inference)
```python
from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup: DB → Auth → Services
    await init_db()
    yield
    # Shutdown: cleanup

def create_app() -> FastAPI:
    app = FastAPI(title=settings.app_name, lifespan=lifespan)
    # Middleware stack (LIFO — last added = first executed)
    app.add_middleware(CORSMiddleware, ...)
    app.add_middleware(SecurityHeadersMiddleware)
    app.add_middleware(RequestLoggingMiddleware)
    app.add_middleware(CorrelationIDMiddleware)
    app.add_middleware(MetricsMiddleware)
    # Routers
    app.include_router(health_router)
    app.include_router(api_router, prefix="/api/v1")
    register_exception_handlers(app)
    return app

app = create_app()
```

### Config (from Enterprise-Inference)
```python
from pydantic_settings import BaseSettings
from functools import lru_cache
from enum import Enum

class Environment(str, Enum):
    DEV = "dev"
    STAGING = "staging"
    PRODUCTION = "production"

class DatabaseSettings(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="DB_")
    url: str = "sqlite+aiosqlite:///./data/app.db"  # Dev default; Docker/Helm override to PostgreSQL
    pool_size: int = 5
    max_overflow: int = 10
    echo: bool = False

    @property
    def is_sqlite(self) -> bool:
        return "sqlite" in self.url

class Settings(BaseSettings):
    environment: Environment = Environment.DEV
    debug: bool = False
    db: DatabaseSettings = DatabaseSettings()
    # ... nested settings for security, observability, etc.

@lru_cache
def get_settings() -> Settings:
    return Settings()
```

### Dockerfile (from Enterprise-Inference)
```dockerfile
FROM python:3.11-slim AS builder
WORKDIR /build
RUN python -m venv /opt/venv
ENV PATH="/opt/venv/bin:$PATH"
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

FROM python:3.11-slim
RUN apt-get update && apt-get install -y --no-install-recommends curl ca-certificates \
    && rm -rf /var/lib/apt/lists/* \
    && groupadd -r appuser && useradd -r -g appuser -u 1000 appuser
COPY --from=builder /opt/venv /opt/venv
ENV PATH="/opt/venv/bin:$PATH"
WORKDIR /app
COPY app/ ./app/
USER appuser
EXPOSE 8000
HEALTHCHECK --interval=30s --timeout=5s CMD curl -f http://localhost:8000/healthz || exit 1
CMD ["uvicorn", "app.main:app", "--host", "0.0.0.0", "--port", "8000"]
```

### Helm NetworkPolicy (Zero-Trust)
```yaml
# Only allow traffic from same namespace, egress to specific ports
spec:
  podSelector:
    matchLabels: {{- include "app.selectorLabels" . | nindent 6 }}
  policyTypes: [Ingress, Egress]
  ingress:
    - from:
        - namespaceSelector:
            matchLabels:
              kubernetes.io/metadata.name: {{ .Release.Namespace }}
  egress:
    - to: []  # DNS
      ports: [{protocol: UDP, port: 53}, {protocol: TCP, port: 53}]
    - to: []  # PostgreSQL
      ports: [{protocol: TCP, port: 5432}]
    - to: []  # Redis
      ports: [{protocol: TCP, port: 6379}]
    - to: []  # HTTPS
      ports: [{protocol: TCP, port: 443}]
```

---

## Determinism Guarantees

- **Template files (~70%)**: Exact copy with variable substitution. Same PRD → same output.
- **Pattern-based files (~20%)**: Follow embedded patterns above. Structure is deterministic,
  content varies by PRD resources/entities.
- **PRD-specific code (~10%)**: Service layer stubs, agent graphs. Generated from PRD
  acceptance criteria. May vary slightly between runs.

**Rule**: NEVER improvise. If the PRD doesn't specify something, don't generate it.
Ask the user rather than guessing.

---

## Critical Rules

1. **Read ALL standards** before generating PRD-specific code: coding, security, testing, container, helm, observability, CI/CD, opensource
2. **Scaffold-first**: Always run `scripts/scaffold.py` first (Phase 2) — never manually read or copy templates
3. **PRD-driven only**: Generate ONLY what the Technical PRD specifies
4. **Show plan before executing**: User must confirm the file list
5. **Validate after generating**: Run syntax/lint/build checks
6. **Intel Apache-2.0 headers**: Every source file gets the Intel copyright header
7. **No secrets in generated code**: Use environment variables for all config
8. **Container security**: uid=1000, non-root, read-only fs, drop ALL capabilities
9. **Dev sanity before handoff**: Project MUST start locally before declaring generation complete
10. **Contract enforcement**: Frontend and backend MUST agree on response shapes and auth payloads

---

## Contract Enforcement Rules (MANDATORY)

These rules prevent frontend-backend integration failures. They apply to ALL generated code.

### Rule C1: List Endpoint Response Shape

ALL list endpoints MUST return `PaginatedResponse` with fields: `{items, total, page, size}`.
NEVER use custom field names for the collection (e.g., `jobs`, `uploads`, `documents`).
The field is ALWAYS `items` regardless of the resource type.

```python
# CORRECT — always use PaginatedResponse pattern
@router.get("", response_model=PaginatedResponse[JobRead])
async def list_jobs(db: DbSession, page: int = Query(1, ge=1), size: int = Query(20, ge=1, le=100)):
    ...
    return PaginatedResponse(items=jobs, total=total, page=page, size=size)

# WRONG — custom response with non-standard field names
class JobListResponse(BaseModel):
    jobs: list[JobRead]  # ← NEVER DO THIS — frontend expects 'items'
    total: int
```

### Rule C2: Entity ID Field

ALL entities returned from the API MUST have an `id` field (UUID string).
NEVER use prefixed ID field names (`job_id`, `upload_id`, `document_id`) in response schemas.

```python
# CORRECT
class JobRead(BaseSchema):
    id: UUID
    status: str

# WRONG
class JobRead(BaseSchema):
    job_id: str  # ← frontend always accesses .id
```

### Rule C3: Auth Contract

When PRD requires local authentication (not Keycloak):
- Use template: `app/core/security_local.py.tmpl` + `app/api/v1/endpoints/auth.py.tmpl`
- Backend accepts `{username: str, password: str}` for login AND register
- Backend returns `{access_token, refresh_token, token_type, expires_in, user: {id, username, email}}`
- Frontend auth store uses `accessToken` field (from `auth-store.ts.tmpl`)
- Frontend api-client reads `useAuthStore.getState().accessToken`
- UserInfo model uses `user_id` and `username` (not `sub`)
- Dev-mode fallback user: `user_id="00000000-0000-0000-0000-000000000001"` (valid UUID)

When PRD uses Keycloak (default `security.py.tmpl`):
- Template `security.py.tmpl` handles JWKS validation
- Frontend redirects to Keycloak login page
- UserInfo uses `sub`, `email`, `name`, `roles`

### Rule C4: Frontend Type Alignment

Generated frontend feature types MUST extend `BaseEntity` from `@/types/common`:
```typescript
import type { BaseEntity } from '@/types/common';
export interface Job extends BaseEntity {
  status: string;
  // ... PRD-specific fields
}
```
`BaseEntity` provides `{id: string, created_at: string, updated_at: string | null}`.

### Rule C5: API Path Consistency

ALL API calls from the frontend MUST use paths prefixed with `/api/v1/`.
The frontend api-client base URL is EMPTY (Vite proxy handles routing to backend).

```typescript
// CORRECT
const BASE_PATH = '/api/v1/jobs';

// WRONG — relative path without /api prefix
const BASE_PATH = '/v1/jobs';  // ← Vite proxy won't catch this
```

### Rule C6: SQLAlchemy Column Naming

When generating models from PRD fields, NEVER use these names as column identifiers:
- `metadata` → use `extra_metadata` or `meta_data`
- `type` → use `{resource}_type` (e.g., `generation_type`)
- `input` / `output` → use `input_text` / `output_text`
- `key`, `index`, `hash` → use `{resource}_key`, `{resource}_index`

### Rule C7: Celery/Task Queue in Dev Mode

When PRD requires async tasks (Celery/Redis):
- NEVER call `.delay()` at module import time
- ALWAYS guard with environment check:
```python
if settings.environment == Environment.DEV:
    logger.info("dev_mode_skipping_task", task=task_name)
else:
    task_function.delay(args)
```
- Celery app MUST use lazy initialization (function, not module-level)

### Rule C8: Database Portability

The template defaults to SQLite for instant dev startup. Production uses PostgreSQL
(set via `DB_URL` env var in Docker Compose / Helm).
- `db.py.tmpl` uses `UUIDType(CHAR(36))` — works on both SQLite and PostgreSQL
- `session.py.tmpl` conditionally skips pool args for SQLite
- `config.py.tmpl` has `is_sqlite` property for branching
- NEVER import from `sqlalchemy.dialects.postgresql` in model files

### Rule C9: Frontend Field Names MUST Match Backend Exactly

When generating frontend types and API calls, field names MUST match the backend
schema EXACTLY. Common violations caught in testing:

```typescript
// WRONG — frontend uses different names than backend
interface UploadConfig {
  model_id: string;       // ← backend expects "model_name"
  max_samples: number;    // ← backend expects "pairs_per_chunk"
  output_format: "jsonl" | "csv";  // ← backend expects "chatml" | "alpaca" | "both"
}

// CORRECT — matches backend schema field names and value enums
interface UploadConfig {
  model_name: string;
  pairs_per_chunk: number;
  output_format: "chatml" | "alpaca" | "both";
}
```

**Generation rule:** After generating backend schemas, derive frontend types FROM
the backend schemas — never generate them independently. Cross-reference:
1. Backend `schemas.py` → Frontend `types/index.ts`
2. Backend `Form(...)` params → Frontend `FormData.append(...)` keys
3. Backend response model fields → Frontend interface fields
4. Backend enum values → Frontend union types

### Rule C10: Complete API Surface (No Phantom Endpoints)

Every endpoint the frontend calls MUST exist in the backend router. Every endpoint
the backend exposes MUST have a corresponding frontend API function if the UI uses it.

**Common violations:**
- Frontend calls `GET /jobs/{id}/download` but backend has no download endpoint
- Frontend calls `GET /jobs/{id}/report` but backend has no report endpoint
- Frontend expects `progress` field but backend never updates it
- Frontend has auth login/register page but backend has no auth endpoints

**Generation rule:** When PRD defines a user workflow (e.g., "user downloads the
generated dataset"), the dev-agent MUST generate BOTH:
1. The backend endpoint that serves the data
2. The frontend function and UI that calls it

If a workflow is deferred to v2, NEITHER side should reference it.

### Rule C11: Dev-Mode Must Exercise Production Code Paths

When infrastructure is substituted for dev mode, the SAME application code must run.
Dev-mode substitutes replace infrastructure, not business logic.

```python
# CORRECT — same endpoint, same pipeline, different backend
@router.post("", response_model=JobRead, status_code=202)
async def create_job(...):
    job = create_job_record(...)
    if settings.celery.enabled:
        process_job_task.delay(str(job.id), config)
    else:
        await run_pipeline_sync(str(job.id), config)  # Same pipeline code!
    return JobRead.model_validate(job)

# WRONG — dev mode silently skips processing
@router.post("", response_model=JobRead, status_code=202)
async def create_job(...):
    job = create_job_record(...)
    if settings.celery.enabled:
        process_job_task.delay(str(job.id), config)
    # Dev mode: job stays "pending" forever — broken UX
    return JobRead.model_validate(job)
```

**Pattern for each infrastructure component:**

| Infra | Production | Dev Substitute | Same Code? |
|-------|-----------|----------------|------------|
| Celery | `.delay()` | `await run_inline()` | Yes — same pipeline functions |
| EI | Real LLM endpoint | MockEIClient | Yes — same client interface |
| MinIO | S3 object store | LocalStorageBackend | Yes — same StorageBackend interface |
| PostgreSQL | Async PG pool | SQLite + aiosqlite | Yes — same SQLAlchemy ORM |
| Keycloak | JWKS validation | Dev bypass user | Yes — same middleware, short-circuit |

### Rule C12: Generated Project Must Include Download & Report Endpoints

For ANY project that produces output artifacts (files, datasets, reports), the backend
MUST expose endpoints to retrieve them. Users should never need to SSH into a server
or browse MinIO directly.

```python
# Required endpoints when project produces output files:
@router.get("/{job_id}/download")
async def download_result(job_id: UUID, db: DbSession, user: CurrentUser):
    """Download the generated output file."""
    ...

@router.get("/{job_id}/report")
async def get_report(job_id: UUID, db: DbSession, user: CurrentUser):
    """Get the quality/processing report."""
    ...
```

### Rule C13: Deterministic Output — Same PRD = Same Product

When multiple developers run dev-agent with the same PRD, they MUST get:
- **Identical file structure** — same paths, same module organization
- **Same UI design** — same layout, same components, same visual patterns (Intel design system)
- **Same API surface** — same endpoints, same request/response shapes
- **Same code patterns** — same abstractions, same naming, same architecture

This is enforced by:
1. Templates provide 100% of infrastructure code (no invention)
2. PRD-specific code follows the EXACT patterns from templates (items.py → any resource)
3. Frontend features follow the EXACT `__feature__/` folder structure
4. Design tokens are from templates (Intel blue, sidebar layout, card-based UI)
5. No creative decisions — if the PRD doesn't specify, use template defaults

**What this means in practice:**
- Do NOT add extra helper modules that aren't in the template set
- Do NOT reorganize the file structure based on "best practices"
- Do NOT choose different UI libraries or layout patterns
- Do NOT add features not in the PRD
- Frontend ALWAYS uses: Tailwind + Intel design tokens, sidebar layout, feature folders
- Backend ALWAYS uses: FastAPI + SQLAlchemy + Pydantic, nested config, typed deps

### Rule C14: No Orphan Code — Every File Must Be Reachable

After generation, trace from `main.py` (backend) and `main.tsx` (frontend):
- Every Python module must be importable via the router/service/model chain
- Every TypeScript component must be rendered via the router
- Every endpoint must be callable from the frontend
- Every frontend page must have a corresponding API function

If a file can't be reached through normal execution paths, it should not exist.
This prevents "generated but never integrated" code from shipping.

---

## Standards Applied

Read these before generating any code:
- `.claude/shared/standards/coding-standards.md`
- `.claude/shared/standards/security-practices.md`
- `.claude/shared/standards/testing-standards.md`
- `.claude/shared/standards/container-standards.md`
- `.claude/shared/standards/helm-standards.md`
- `.claude/shared/standards/observability-standards.md`
- `.claude/shared/standards/ci-cd-standards.md`
- `.claude/shared/standards/opensource-compliance.md`
- `.claude/shared/standards/project-structure.md`
- `.claude/shared/standards/tech-stack.md`
- `.claude/shared/standards/ux-design-system.md`

---

## Plugins Used

This agent leverages installed plugins when available:

| Plugin | Phase | Purpose |
|--------|-------|---------|
| `frontend-design` | Phase 4.6 | Distinctive UI within Intel brand |
| `semgrep` | Phase 4.7 | Real-time SAST during code generation |
| `playwright` | Phase 4.5 Step 9 | Visual frontend verification |
| `context7` | Phase 4 | Version-specific library documentation |
| `github` | Program Checkpoints | Enhanced PR/commit operations |

If plugins are not installed, the agent degrades gracefully (curl fallback, manual security review later).

---

## Next Steps (After Dev-Agent Completes)

After all phases complete and checkpoints pass:

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
PROJECT GENERATION COMPLETE
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Next steps:
1. /review-agent  — Multi-dimensional code review (C1-C14, security, standards)
2. /validation-agent — Generate tests, coverage, gap analysis
3. /compliance-agent — Security scans, OSPDT, SBOM, dashboard

Recommended order: review → validation → compliance
Or jump to validation if you want tests first.

Which would you like to run next? [1/2/3]
```
