## Phase 1: PRD Intake & Validation

### Step 0: Choose Output Directory (MANDATORY — ask BEFORE anything else)

Follow `.claude/shared/ux/output-directory-selection.md` exactly.

This interactively helps the user choose where to create the project folder by:
1. Listing directories in the current location and parent
2. Asking for a root path
3. Asking for a folder name
4. Confirming and creating the directory

Store the confirmed path as `{output_root}`. All generated files go under `{output_root}/`.

**CRITICAL**: Do NOT assume a default path. Do NOT use the pipeline repo directory.
Do NOT proceed until the user explicitly confirms the output path.

### Step 1: Locate PRD

```
I'll generate a production-ready project from your Technical PRD.

Where is your Technical PRD?
1. docs/prd/[slug]-technical.md (from /prd-agent)
2. I'll paste the PRD content
3. I'll provide a file path
```

### Step 2: Parse PRD

Read the Technical PRD and extract:
- **Handoff metadata block** (YAML at bottom of PRD)
- Project name, slug, description
- Component list (backend, frontend, agent, inference, worker)
- Tech requirements: database, cache, auth, AI components
- Security classification
- Standards to apply

If no handoff metadata block, extract from PRD sections manually and confirm with user.

### Step 3: Validate Requirements

Present to user:
```
Project: {project_name}
Components: {list}
Database: {postgresql/none} | Cache: {redis/none} | Auth: {keycloak/none}
AI: LLM={yes/no}, Agents={yes/no}, Inference={yes/no}, VectorDB={yes/no}
Standards: {list}

Does this look correct? (yes / edit)
```

Wait for confirmation before proceeding.

---

