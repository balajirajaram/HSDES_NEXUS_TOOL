## Phase 2: Generate handoff.yaml & Run Scaffold

### Step 1: Generate handoff.yaml

From the parsed Technical PRD (Phase 1), create `{output_root}/handoff.yaml`:

```yaml
project_name: "{from PRD}"
project_slug: "{from PRD}"
package_name: "{first backend component, snake_case}"
description: "{PRD executive summary, first sentence}"
port: {from handoff.components[0].port, default 8000}
python_version: "3.11"
year: "{current year}"
author: "Intel AI Team"
app_name: "{from PRD}"
github_org: "{from config or user input}"
features:
  - name: "{Feature 1}"
    slug: "{feature-1}"
    resource_name: "{Resource}"
    resource_plural: "{Resources}"
```

See `scripts/handoff.yaml.example` for the full schema.

### Step 2: Run scaffold.py (ALL template files)

```bash
cd {pipeline_repo}
python scripts/scaffold.py --vars {output_root}/handoff.yaml --output {output_root}/{project_slug}/ --force
```

This generates ~150 files in <3 seconds with ZERO context usage:
- config (18 files): .gitignore, README, Makefile, CNCF docs, scripts
- github (10 files): CI/CD workflows, templates, dependabot
- backend (30 files): FastAPI app structure, config, middleware, auth, inference
- frontend (44 files): React+Vite+Tailwind, routing, auth, stores, UI components
- frontend_features (8 files per feature): API, components, hooks, types
- docker (3 files): compose files, nginx
- helm (16 files): full Kubernetes chart
- ansible (11 files): playbooks, roles, inventory

**Show the scaffold output to user:**
```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
SCAFFOLD COMPLETE — {project_name}
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Generated {N} template files in {time}s
Manifest: reports/generation/scaffold-manifest.json

Phases:
  config:    {n} files ✓
  github:    {n} files ✓
  backend:   {n} files ✓
  frontend:  {n} files ✓
  features:  {n} files ✓
  docker:    {n} files ✓
  helm:      {n} files ✓
  ansible:   {n} files ✓

Next: PRD-specific code generation (endpoints, models, AI logic)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

### Step 3: Initialize Git Repository & Install Hooks

```bash
cd {output_root}/{project_slug}
git init
cp {pipeline_repo}/templates/project-scaffold/github/hooks/commit-msg .git/hooks/commit-msg
chmod +x .git/hooks/commit-msg
git add -A
git commit -m "feat({project_slug}): scaffold project from PRD"
```

The `commit-msg` hook strips any AI co-author lines from commits. This is a safety net
ensuring only the developer appears as commit author — see `.claude/shared/ux/git-versioning.md`.

### Step 4: Verify scaffold output

```bash
# Quick syntax check on generated Python
cd {output_root}/{project_slug}/src/{package_name}
python -m py_compile app/main.py
python -m py_compile app/config.py
echo "Scaffold Python files compile OK"
```

**DO NOT read template files manually.** scaffold.py handles all template processing.
The LLM context is preserved for PRD-specific creative work in Phase 4.

---

