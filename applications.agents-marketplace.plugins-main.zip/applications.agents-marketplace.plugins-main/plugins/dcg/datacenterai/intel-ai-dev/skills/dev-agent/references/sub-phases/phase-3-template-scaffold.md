## Phase 3: Template Scaffold (AUTOMATED via scaffold.py)

**CRITICAL: Do NOT manually read or copy template files. scaffold.py handles ALL 151 templates.**

Phase 2 ran `python scripts/scaffold.py --vars handoff.yaml --output {project_dir}/ --force`
which generated all infrastructure files automatically. Coverage breakdown:

| Phase | Files | Contents |
|-------|-------|----------|
| config | 18 | .gitignore, .pre-commit-config.yaml, .env.example, Makefile, Taskfile.yml, CLAUDE.md, README.md, scripts/dev-sanity.sh, scripts/install.sh, scripts/start.bat, scripts/healthcheck.sh, scripts/migrate.sh, scripts/seed-data.py, scripts/wait-for-deps.sh, LICENSE, CODE_OF_CONDUCT.md, CONTRIBUTING.md, SECURITY.md, THIRD-PARTY-PROGRAMS |
| github | 10 | CI/CD workflows (ci, code-scans, release, dependency-review, codeql), dependabot, CODEOWNERS, issue templates, PR template |
| backend | 31 | Dockerfile, alembic.ini, tox.ini, pyproject.toml, requirements.txt, tests/conftest.py, app/ (main, config, core/middleware, core/security, core/security_local, core/exceptions, core/rate_limit, api/deps, api/v1/router, api/v1/endpoints/items, api/v1/endpoints/auth, models/schemas, models/db, db/session, observability/telemetry+logging+health, inference/__init__+config+mock_client+ei_client+vllm_client, services/__init__+pipeline_runner, storage/__init__+backend) |
| frontend | 44 | package.json, tsconfig.json, tsconfig.node.json, vite.config.ts, vitest.config.ts, tailwind.config.ts, postcss.config.js, index.html, Dockerfile, nginx.conf, .env, .env.example, src/ (main.tsx, index.css, vite-env.d.ts, test-setup.ts, app/providers+router+layout+error-boundary+not-found, lib/api-client+auth+cn+constants, hooks/use-auth+use-toast, stores/auth-store+ui-store, pages/login+dashboard, types/api+common, components/layout/ header+sidebar+content-area+page-header, components/ui/ badge+button+card+empty-state+input+modal+select+skeleton+spinner+table+toast, components/feedback/ error-display+loading-overlay) |
| frontend_features | 8/feature | api/api.ts, api/queries.ts, components/detail.tsx, components/form.tsx, components/list.tsx, hooks/use-{slug}.ts, index.ts, types.ts |
| docker | 3 | docker-compose.yml, docker-compose.prod.yml, nginx/nginx.conf |
| helm | 16 | Chart.yaml, values.yaml, values-production.yaml, templates/ (_helpers.tpl, deployment, service, hpa, pdb, networkpolicy, serviceaccount, configmap, secret, ingress, servicemonitor, NOTES.txt, tests/test-connection.yaml) |
| ansible | 11 | ansible.cfg, inventory/dev.yml, playbooks/ (setup, infrastructure, application, validate, backup, pre_upgrade), roles/ (common, infrastructure, application) tasks/main.yml |
| **TOTAL** | **151+** | All templates from `templates/project-scaffold/` with full variable substitution |

**What scaffold.py ALREADY handles for inference:**
- Enterprise Inference strategy: `ei_client.py` (REST client for remote EI)
- Direct vLLM strategy: `vllm_client.py` (REST client for local vLLM)
- Mock client: `mock_client.py` (for unit tests and CI)
- Both are ALWAYS generated — the `.env` config determines which is used at runtime

**What scaffold.py does NOT generate (Phase 4 handles these via LLM):**
- PRD-specific API endpoints (e.g., `/tasks`, `/ai/prioritize`)
- PRD-specific database models (custom columns, relationships)
- PRD-specific Pydantic schemas (Create/Read/Update per resource)
- PRD-specific service layer (business logic)
- PRD-specific frontend customization (custom list views, forms, routing)
- Agent graphs (if PRD requires LangGraph agents)
- Custom router wiring (replacing template `items` router with PRD resources)

---

