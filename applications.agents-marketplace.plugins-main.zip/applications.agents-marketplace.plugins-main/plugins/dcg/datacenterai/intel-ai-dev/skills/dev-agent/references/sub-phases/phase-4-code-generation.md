## Phase 4: PRD-Specific Code Generation

This is where the dev-agent adds value beyond templates. For each PRD user story
and acceptance criterion, generate implementation code.

**Generation philosophy: Contract-First, Test-Last.**
Define interfaces between components BEFORE implementing either side.
Both backend and frontend are generated from the same contract — consistency by construction.

**EXTENDED REASONING — Pre-Generation Analysis (Phase 4 start)**

Before writing ANY code, reason deeply about the PRD-to-code mapping:

1. **Data model coherence**: List every entity the PRD mentions. Do they form a
   consistent schema? Are there implied relationships not explicitly stated?
   (e.g., "users upload documents" implies a User→Document FK)
2. **Endpoint coverage**: Map every user story to at least one API endpoint.
   If a story has no endpoint, either it's a frontend-only feature or something
   is missing from the implementation plan.
3. **Inference integration points**: Where does AI/ML inference touch the data flow?
   Is it synchronous (blocking the request) or async (via task queue)?
   This determines whether to use a direct service call or a Celery/ARQ worker.
4. **Frontend-backend contract**: For each endpoint, what does the frontend need?
   Define the response shape BEFORE generating code so C9 (types match) is satisfied
   by construction, not by post-hoc fixing.
5. **Dependency graph**: Which services depend on which? Generate in dependency order
   (models → schemas → services → endpoints → frontend hooks) to avoid forward references.
6. **All models required**: List EVERY model the codebase imports (User for auth,
   any status enums, any supporting models). If the scaffold's `auth.py` imports `User`,
   that model MUST be generated. Check the scaffold's imports before generating.
7. **Inference interface contract**: The scaffold provides `EIClient.chat_completion()→dict`.
   Services need a simpler `generate(prompt)→str` wrapper. Define this adapter BEFORE
   writing any service that calls inference.

Surface any ambiguities: "The PRD mentions {X} but doesn't specify {Y}. I'll assume {Z}
unless you want to clarify." Then proceed.

### 4.0 Contract Definition (MANDATORY — before any code)

Before generating backend or frontend code, define the API contract for each endpoint.
This contract is the SINGLE SOURCE OF TRUTH that both sides implement against.

For each endpoint:
```
POST /api/v1/{resource}
  Request: multipart form? JSON body? What fields exactly?
  Response: { id, status, field_1, field_2, ... }
  Status code: 201? 202?

GET /api/v1/{resource}
  Query params: page, size, filters?
  Response: { items: [...], total, page, size }

GET /api/v1/{resource}/{id}
  Response: same shape as list item

DELETE /api/v1/{resource}/{id}
  Response: 204 No Content
```

Also define the **inference interface** the services will use:
```python
# This is what services call:
async def generate(prompt: str, temperature: float = 0.7) -> str:
    """Sends prompt to LLM, returns content string."""
```

And any **supporting models** the scaffold already imports:
- Check `auth.py` → needs `User` model in db.py
- Check `pipeline.py` patterns → needs status enums
- Check what `__init__.py` exports → must match service expectations

### 4.1 Inference Adapter (MANDATORY if PRD uses AI)

The scaffold provides `EIClient` with `chat_completion(messages) → dict`. Services
need a simpler interface. Write the adapter FIRST:

```python
# app/inference/__init__.py — unified interface
class InferenceClient:
    async def generate(self, prompt: str, temperature: float = 0.7) -> str:
        """Wraps EIClient.chat_completion, extracts content string."""
        messages = [{"role": "user", "content": prompt}]
        response = await self._client.chat_completion(messages, ...)
        return response["choices"][0]["message"]["content"]

def get_inference_client() -> InferenceClient:
    """Factory: mock or real based on config."""
```

All services call `get_inference_client().generate(prompt)` — never EIClient directly.
This is a one-time setup that prevents interface mismatches in all downstream services.

### 4.2 Database Models

For each data entity in the PRD:
- Follow `app/models/db.py.tmpl` pattern (SQLAlchemy 2.0 async, UUID primary keys, timestamps)
- Add columns from PRD data model
- Add relationships between entities
- **Add ALL supporting models** the scaffold imports (User for auth, status enums, etc.)
- Generate Alembic migration stub

**Checklist before moving to 4.3:**
- Does `auth.py` import any model from db.py? → It's generated (always generate `User` model).
- Does any service import enums from db.py? → They're generated.
- Run: `python -c "from app.models.db import *"` → must pass.
- **Demo user seeding**: Add `_seed_demo_user()` in `main.py` lifespan (after `create_all`).
  Seeds `demo / Demo1234` on startup so user acceptance sanity can test login immediately.
  This is mandatory for the Phase 4.5b user acceptance flow.

### 4.3 Pydantic Schemas

For each resource:
- Follow `app/models/schemas.py.tmpl` pattern
- Create, Read, Update schemas per resource
- Add validators from PRD constraints
- **Match endpoint contracts defined in 4.0 exactly**
- Use proper enum types (not raw `str`) for constrained fields

### 4.4 API Endpoints

For each resource in the PRD:
- Generate endpoint file following the scaffold `items.py.tmpl` pattern
- Replace Item with the resource name
- **Match the contract from 4.0**: same field names, same form encoding, same response shape
- Add validation from PRD acceptance criteria
- Wire into `api/v1/router.py` (replace scaffold `items` router)
- **ALWAYS wire the auth router** — `api_router.include_router(auth.router)` even when
  `AUTH_ENABLED=false`. The user acceptance sanity tests the full login flow.
- **Delete the scaffold `items.py`** — it's now orphan code

**For file upload endpoints**: Use individual `Form()` parameters, NOT a JSON string
form field. Frontend sends `FormData` with explicit fields.

### 4.5 Service Layer

For each business operation in the PRD:
```python
# src/{component}/app/services/{resource}_service.py
# Pattern: async functions, dependency injection, structured logging
async def create_{resource}(
    db: AsyncSession,
    data: {Resource}Create,
    current_user: UserInfo,
) -> {Resource}Read:
    ...
```

**Services that call LLM**: Use `get_inference_client().generate(prompt)` (from 4.1).
Never import EIClient directly. Parse LLM JSON responses with error handling.

### 4.6 Advanced AI Patterns (if applicable — NO base templates exist)

**IMPORTANT:** There are no scaffold templates for these patterns. The LLM generates
the complete module structure from scratch, following Intel coding standards. Every file
must be production-quality: typed, async, logged, testable.

#### 4.6a Agent Graphs (if `ai_components.agents: true`)

Generate complete agent orchestration module:

```python
# app/agents/{workflow_name}/
#   __init__.py        — public interface
#   state.py           — TypedDict state definition
#   nodes.py           — pure node functions (state in → state out)
#   edges.py           — conditional routing logic
#   tools.py           — tool definitions (Pydantic BaseModel for each tool)
#   graph.py           — compiled graph assembly
#   config.py          — agent-specific settings

# app/agents/{workflow_name}/state.py
from typing import TypedDict, Annotated
from operator import add

class AgentState(TypedDict):
    messages: Annotated[list, add]
    context: dict
    # PRD-specific state fields...

# app/agents/{workflow_name}/graph.py
from langgraph.graph import StateGraph, END
from .state import AgentState
from .nodes import research_node, analyze_node, generate_node
from .edges import should_continue

def build_graph() -> StateGraph:
    graph = StateGraph(AgentState)
    graph.add_node("research", research_node)
    graph.add_node("analyze", analyze_node)
    graph.add_node("generate", generate_node)
    graph.add_conditional_edges("analyze", should_continue, {"continue": "generate", "done": END})
    graph.set_entry_point("research")
    return graph.compile()
```

**Requirements:**
- All node functions MUST be async
- All node functions MUST use `get_inference_client()` (from 4.1) for LLM calls
- State must be serializable (for checkpointing)
- Add structlog logging at each node entry/exit
- Wire into service layer via `app/services/{workflow}_service.py`
- Expose via API endpoint (POST to start, GET to poll status)

#### 4.6b RAG Pipeline (if `ai_components.vector_db: true`)

**Pattern Source: Enterprise-RAG (OPEA Project)**

Follow Intel's Enterprise-RAG architecture as the reference implementation:
- **Microservice component layout**: Each RAG module is a self-contained component
  with its own `app/`, `tests/`, `tox.ini`, `Dockerfile`, and `requirements.txt`
  (see `.claude/shared/standards/project-structure.md` § Microservice Component Layout)
- **OPEA pipeline architecture**: Retrieval → Reranking → Generation as composable
  microservices that can be deployed independently or composed
- **Testing**: tox-based test structure with unit + integration separation
  (Enterprise-RAG pattern from `.claude/shared/standards/testing-standards.md`)
- **CI/CD**: Pre-commit hooks, CNCF required files (LICENSE, CONTRIBUTING, SECURITY.md)
  per Enterprise-RAG conventions in `.claude/shared/standards/ci-cd-standards.md`
- **Observability**: Structured logging with structlog, Prometheus metrics for retrieval
  latency, embedding throughput, and generation time
- **Config**: Environment-variable-driven settings with Pydantic BaseSettings,
  matching Enterprise-RAG's 12-factor app approach

Generate complete RAG module:

```python
# app/rag/
#   __init__.py        — public interface
#   embeddings.py      — embedding model client (EI or local)
#   chunker.py         — document chunking strategies
#   vector_store.py    — vector DB client (Chroma/Milvus/pgvector)
#   retriever.py       — retrieval logic with reranking
#   chain.py           — RAG chain (retrieve → augment → generate)
#   config.py          — RAG-specific settings

# app/rag/retriever.py
from .vector_store import VectorStoreClient
from .embeddings import get_embedding_client

class Retriever:
    def __init__(self, vector_store: VectorStoreClient, top_k: int = 5):
        self._store = vector_store
        self._embedder = get_embedding_client()
        self._top_k = top_k

    async def retrieve(self, query: str) -> list[Document]:
        embedding = await self._embedder.embed(query)
        results = await self._store.similarity_search(embedding, k=self._top_k)
        return results

# app/rag/chain.py
from .retriever import Retriever
from ..inference import get_inference_client

class RAGChain:
    async def invoke(self, query: str) -> RAGResponse:
        docs = await self._retriever.retrieve(query)
        context = "\n".join(d.content for d in docs)
        prompt = self._build_prompt(query, context)
        answer = await get_inference_client().generate(prompt)
        return RAGResponse(answer=answer, sources=docs)
```

**Requirements (Enterprise-RAG aligned):**
- Embedding client must support EI embedding endpoint OR local model
- Vector store client must be async (Enterprise-RAG uses async throughout)
- Chunking must be configurable (size, overlap, strategy) — follow Enterprise-RAG's
  document processing pipeline patterns (sentence-level, paragraph, sliding window)
- Add document ingestion endpoint (POST /documents with file upload)
- Add query endpoint (POST /query with RAG response)
- Include source attribution in responses (Enterprise-RAG mandates provenance tracking)
- Wire vector store config into `app/config.py` using Pydantic BaseSettings
- Follow Enterprise-RAG component isolation: each module testable independently
- Health checks for each RAG sub-component (embedder, vector store, retriever)
- Structured logging at each pipeline stage (ingest, chunk, embed, store, retrieve, generate)
- Graceful degradation: if vector store unavailable, return error with retry guidance

#### 4.6c Multi-Agent Systems (if PRD has multiple collaborating agents)

Generate inter-agent communication:

```python
# app/agents/orchestrator.py — coordinates multiple agent workflows
# app/agents/shared/memory.py — shared memory across agents
# app/agents/shared/tools.py — tools shared between agents
```

**Requirements:**
- Each agent is a separate graph (4.6a pattern)
- Orchestrator manages agent selection and handoff
- Shared state via message passing (not global mutable state)
- Each agent has its own system prompt and tool set

#### 4.6d Completeness Check (MANDATORY after 4.6)

After generating advanced AI modules, verify:
1. All imports resolve: `python -c "from app.agents import *"` or `from app.rag import *`
2. Config wired: new settings in `config.py` with env var overrides
3. API exposed: new endpoints registered in router
4. Frontend aware: types + API hooks for new endpoints
5. Dependencies added: langgraph, chromadb, etc. in requirements.txt
6. Mock/dev fallback: can the module work without external vector DB/agent infra?

### 4.7 Frontend Feature Generation (MANDATORY)

**This step is NOT optional.** The scaffold stamps 8 files per feature with `{{PLACEHOLDER}}`
markers. EVERY placeholder must be replaced with PRD-specific code.

**Generation order for EACH feature:**

1. **`types.ts`** — TypeScript interfaces matching backend schemas EXACTLY.
   Copy field names and types from Pydantic schemas (4.3). Add supporting types
   (status unions, config interfaces, list params, list response).

2. **`api/api.ts`** — Real API calls matching endpoint signatures (4.4).
   If endpoint uses multipart upload → use FormData.
   If endpoint has sub-resources → add methods for those too.

3. **`api/queries.ts`** — React Query hooks with proper invalidation.
   Add refetch intervals for long-running operations (polling).
   Add mutation hooks with toast notifications.

4. **`components/form.tsx`** — Actual creation form (NOT generic "name" field).
   File upload? → drag-and-drop zone using `<label htmlFor="file-upload">` wrapping
   the drop area, with `<input id="file-upload" type="file" className="hidden">` inside.
   The `<label>` natively triggers the file input on click — works in ALL browsers
   (Chrome, Edge, Firefox). Do NOT use `useRef` + `onClick(() => ref.click())` as this
   is blocked by Chrome's sandbox policy on enterprise-managed machines.
   Config fields? → typed inputs with validation.
   Match the exact fields from the POST endpoint contract (4.0).

5. **`components/list.tsx`** — Actual columns matching resource fields.
   Status badges with color coding.
   Proper column headers from the domain (not "ID", "Created").
   Row click → navigate to detail.

6. **`components/detail.tsx`** — Actual detail view with ALL resource fields.
   Action buttons (download, delete, etc.) based on resource state.
   Sub-resource display (e.g., results within a job).
   Loading states, error states.

7. **`hooks/use-{slug}.ts`** — Re-export hooks from queries (update exports list).

8. **`index.ts`** — Update exports to match actual component names.

**After all features are done, also update:**

9. **`app/router.tsx`** — Replace `{{FEATURE_ROUTE_IMPORTS}}` and
   `{{FEATURE_ROUTE_DEFINITIONS}}` with actual imports and routes.

10. **`components/layout/sidebar.tsx`** — Replace `{{NAV_ITEMS}}` and
    `{{NAV_ICON_IMPORTS}}` with actual navigation items and icons.

11. **`lib/constants.ts`** — Replace `{{NAV_ITEMS}}` with actual nav array.

12. **`pages/dashboard.tsx`** — Update quick actions and getting-started to be
    PRD-specific (not generic "Create your first resource").

**Frontend Design (frontend-design plugin):**
When generating frontend feature pages, apply creativity WITHIN Intel brand system
(see `.claude/shared/standards/ux-design-system.md`):
- Intel brand colors (#003580, #00C7FD) as non-negotiable base
- Distinctive layout composition, animation timing, spatial design
- shadcn/ui components with Intel CSS variables

### 4.8 Dependency Sync (MANDATORY)

After all code is generated, sync `requirements.txt` with actual imports:

```bash
# Scan for imports not in requirements.txt
grep -rh "^import \|^from " src/{package_name}/app/services/ | \
  grep -v "^from app\." | grep -v "^from \." | sort -u
```

Common additions that Phase 4 typically introduces:
- `tiktoken` (if chunking by tokens)
- `PyPDF2` / `pymupdf` (if parsing PDFs)
- `openpyxl` (if parsing Excel)
- `python-multipart` (if file upload endpoints exist)
- `langchain` / `langgraph` (if agent graphs)
- `chromadb` / `pgvector` (if vector DB)

**Add any missing packages to `requirements.txt` NOW, not during dev sanity.**

### 4.9 Phase 4 Completion Gate (MANDATORY — must pass before Phase 4.5)

Run ALL of the following checks. Every one must pass. If ANY fails, fix it in Phase 4
(do NOT proceed to Phase 4.5 with known failures):

```bash
# 1. All backend imports resolve (catches missing models, enums, broken references)
cd {project_dir}/src/{package_name}
python -c "from app.main import app; print('Backend imports: OK')"

# 2. Zero template placeholders remain
grep -r "{{" {project_dir}/src/ {project_dir}/frontend/src/ \
  --include="*.py" --include="*.ts" --include="*.tsx" | \
  grep -v "node_modules" | grep -v "__pycache__" | \
  grep -v "f-string"  # Exclude Python f-string escaped braces
# Must return ZERO results (or only f-string false positives)

# 3. TypeScript compiles without errors
cd {project_dir}/frontend
npx tsc --noEmit
# Must exit 0

# 4. Dependencies are installable
cd {project_dir}/src/{package_name}
pip install -r requirements.txt --dry-run
# Must succeed

# 5. No orphan scaffold files
# items.py should be deleted (replaced by PRD-specific endpoints)
test ! -f {project_dir}/src/{package_name}/app/api/v1/endpoints/items.py
```

**If any check fails**: Fix the issue IMMEDIATELY. Do not mark Phase 4 as complete.
Do not proceed to Phase 4.5. The fix belongs here — Phase 4.5 is for VERIFICATION
of working code, not for fixing generation errors.

**Present completion summary:**
```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
PHASE 4 COMPLETE — Generation Gate
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Backend imports:      ✓ (all resolve)
Template placeholders: ✓ (zero remaining)
TypeScript:           ✓ (zero errors)
Dependencies:         ✓ (all installable)
Orphan code:          ✓ (items.py removed)

Ready for Phase 4.5 Dev Sanity.
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

### 4.10 Real-Time Security Check (semgrep plugin)

After generating each code file, the `semgrep` plugin runs real-time SAST if available.
If the plugin detects a security issue during generation, fix immediately before proceeding.

Common catches during code generation:
- SQL injection (raw string interpolation in queries)
- Hardcoded secrets (API keys in config defaults)
- Path traversal (user input in file paths without sanitization)
- SSRF (user-controlled URLs in HTTP requests)

If semgrep plugin not installed, security issues are caught later in Phase 4.6 audit
and compliance-agent scans — but fixing earlier is cheaper.

---

