## Phase 4.5: Dev Sanity Verification (MANDATORY — VERIFICATION ONLY)

**Principle: Dev Sanity = Production Sanity minus Kubernetes.**

**CRITICAL: Phase 4.5 is VERIFICATION, not FIXING.** If code bugs are discovered here
(import errors, missing models, interface mismatches), STOP and acknowledge that Phase 4
was incomplete. Fix the issue, re-run the 4.9 completion gate, then resume 4.5.
The goal is zero fixes during dev sanity — only infrastructure configuration and E2E flow testing.

Dev sanity tests with REAL infrastructure — no mocks. The same code, the same
services, the same data flow as production. Only Kubernetes orchestration is absent.

The goal is NOT "does the app start" — it is "does the PRODUCT work as a customer
would use it in production?" Every functional flow is tested end-to-end with real
services. If a flow doesn't work, it must be fixed before proceeding.

Dev sanity is an interactive developer-driven loop:
1. Ask developer what REAL infrastructure they have available
2. Validate each service is reachable
3. Test EVERY functional flow end-to-end with real services
4. Find issues → fix → re-test
5. Once ALL flows pass, proceed to code integration audit

**NO MOCKS IN DEV SANITY.** The mock client exists in the codebase for unit tests
and CI pipelines — it is NEVER used during dev sanity. If the developer does not
have an EI endpoint, they must deploy one first (EI setup instructions are in README).

### Step 1: Environment Setup

```bash
export NO_PROXY="localhost,127.0.0.1,::1"
export no_proxy="localhost,127.0.0.1,::1"
```

### Step 2: Infrastructure Decision Gate (ASK THE DEVELOPER)

Present each infrastructure dependency. The developer provides REAL service details.

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
DEV SANITY — Infrastructure Setup
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Dev sanity tests the product as production. I need REAL services.

1. LLM Inference (Enterprise Inference):
   → Provide your EI endpoint URL and bearer token
   → If you don't have one, deploy EI first:
     https://github.com/opea-project/Enterprise-Inference
   → Or use Direct vLLM if your PRD specifies it

2. Task Queue:
   A) I have Redis running → provide URL (e.g., redis://localhost:6379/0)
   B) Use synchronous inline processing (same pipeline code, no queue)

3. File Storage:
   A) I have MinIO running → provide endpoint + credentials
   B) Use local filesystem (./data/) — same StorageBackend interface

4. Database:
   A) I have PostgreSQL running → provide connection URL
   B) Use SQLite — same ORM, same queries, portable

5. Authentication:
   A) I have Keycloak running → provide realm URL
   B) Auth disabled for now (dev bypass) — middleware still active

Provide your EI endpoint first (required for AI-powered features):
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

Wait for developer response. Then configure `.env` accordingly.

**Proxy Detection (Intel corporate network):**
```bash
# Check if behind corporate proxy
if [ -n "$HTTP_PROXY" ] || [ -n "$HTTPS_PROXY" ]; then
  echo "⚠️  Corporate proxy detected: ${HTTP_PROXY:-$HTTPS_PROXY}"
  echo "   Adding EI endpoint to NO_PROXY..."
  EI_HOST=$(echo "{EI_ENDPOINT}" | sed 's|https\?://||' | cut -d/ -f1 | cut -d: -f1)
  export NO_PROXY="${NO_PROXY:+$NO_PROXY,}$EI_HOST,localhost,127.0.0.1"
  echo "   NO_PROXY=$NO_PROXY"
fi
```

If proxy is detected and EI connection fails, guide the developer:
```
⚠️  Cannot reach EI endpoint. You appear to be behind a corporate proxy.

Options:
1. Add EI host to NO_PROXY (recommended if EI is internal)
2. Configure proxy credentials for external EI
3. Use --noproxy flag (EI is on local network)
4. Skip EI — proceed with mock inference (dev sanity incomplete)

[1/2/3/4]
```

**EI validation (MANDATORY — do not proceed without confirming):**
```bash
curl --noproxy '*' -s "{EI_ENDPOINT}/v1/models" -H "Authorization: Bearer {token}" | \
  python3 -c "import sys,json; d=json.load(sys.stdin); models=d.get('data',[]); \
  print(f'EI OK: {len(models)} models available'); [print(f'  • {m[\"id\"]}') for m in models[:5]]"
```

**If EI is not reachable:** Do NOT proceed. Help the developer fix connectivity.
Common issues: proxy settings, VPN, incorrect URL, expired token.

**If developer absolutely cannot provide EI (e.g., no access yet):**
```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
⚠️  EI NOT AVAILABLE
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
AI-powered features cannot be fully tested without Enterprise Inference.
Options:
  1. Deploy EI now (I'll wait) — see README § Enterprise Inference Setup
  2. Skip AI flows only — test all non-AI functionality (CRUD, auth, frontend)
     AI flows will be verified when EI becomes available
  3. Proceed with mock (NOT recommended — sanity incomplete, will need re-run)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

If they choose option 2, mark AI flows as "DEFERRED — requires EI" in results.
If they choose option 3, mark the entire dev sanity as "INCOMPLETE — mock only".

**Redis/Celery validation (if chosen):**
```bash
python3 -c "import redis; r=redis.from_url('{url}'); r.ping(); print('Redis OK')"
```

### Step 3: Configure and Start

Based on developer's infrastructure choices, write `.env` with REAL values:

```bash
# Write .env with developer-provided values
cat > .env << EOF
ENVIRONMENT=dev
INFERENCE_API_ENDPOINT={developer_provided_url}
INFERENCE_API_TOKEN={developer_provided_token}
INFERENCE_MODEL_NAME={model_from_available_list}
DB_URL={developer_choice}
CELERY_ENABLED={true_if_redis_provided}
CELERY_BROKER_URL={redis_url_if_provided}
MINIO_ENDPOINT={minio_url_if_provided}
AUTH_ENABLED={true_if_keycloak_provided}
EOF
```

**Code generation for infrastructure modes:**

All substitutes (LocalStorageBackend, synchronous pipeline runner, etc.) are ALWAYS
generated as part of the project codebase — they ship for CI tests and fallback.
But during dev sanity, the REAL services are used. The substitutes only activate
when the corresponding env var is empty/unset.

### Step 4: Install Dependencies (MUST use virtual environment)

**Python dependencies MUST be installed in a virtual environment — never system-wide.**

```bash
cd {output_root}/src/{component}

# Create venv if it doesn't exist
python -m venv .venv

# Activate venv (Windows)
source .venv/Scripts/activate 2>/dev/null || source .venv/bin/activate

# Verify we're in the venv
python -c "import sys; assert 'venv' in sys.prefix or '.venv' in sys.prefix, 'NOT IN VENV'; print(f'venv OK: {sys.prefix}')"

# Install dependencies
pip install -r requirements.txt
```

```bash
cd {output_root}/frontend
npm install
```

**If pip install fails:** diagnose and fix (common: asyncpg needs C compiler on Windows
→ use SQLite for dev; missing aiosqlite → add to requirements.txt).

**IMPORTANT:** All subsequent Python commands in dev sanity (uvicorn, pytest, etc.)
MUST run inside this venv. If you open a new shell, re-activate with:
`source {output_root}/src/{component}/.venv/Scripts/activate` (Windows)
or `source {output_root}/src/{component}/.venv/bin/activate` (Linux)

### Step 4b: Clear Stale Frontend Cache (MANDATORY)

**CRITICAL:** If the frontend was installed (`npm install`) BEFORE Phase 4 code
generation modified the source files, Vite's dependency pre-bundling cache will serve
STALE code — the old scaffold template endpoints, not the new Phase 4 code.

```bash
# Always clear Vite cache before dev sanity
rm -rf {output_root}/frontend/node_modules/.vite

# Kill any existing node/vite processes from previous runs
# (On Windows: taskkill //F //IM node.exe)
# (On Linux/Mac: pkill -f "vite" || true)
```

**Also create frontend `.env`** if it doesn't exist (proxy target for API calls):
```bash
cat > {output_root}/frontend/.env << 'EOF'
VITE_API_BASE_URL=http://127.0.0.1:{port}
EOF
```

**Verification after starting frontend:**
```bash
# Confirm Vite serves the CORRECT current code (not stale):
curl --noproxy '*' -s http://127.0.0.1:5173/src/features/{feature}/api/api.ts | head -5
# Should show the Phase 4 code (correct API paths), NOT scaffold template code
```

If stale code is detected, kill the Vite process completely and restart.

### Step 5: Start Backend and Verify Health

```bash
cd {output_root}/src/{component}
uvicorn app.main:app --port {port} --host 127.0.0.1 &
# Wait up to 30s for startup
curl --noproxy '*' http://127.0.0.1:{port}/healthz
```

**If backend fails to start**, diagnose and apply these known fixes:
- `pool_size not supported` → session.py must check `settings.db.is_sqlite`
- `No module named 'aiosqlite'` → add to requirements.txt
- Column name collision (`metadata`, `type`, `input`) → rename with suffix
- `Cannot import celery` / Redis timeout → wrap in dev-mode guard
- `UUID()` type error → verify db.py uses UUIDType (CHAR(36))
- Import error in any module → fix the import path, add missing `__init__.py`

### Step 6: Verify Frontend-Backend Contract Alignment

Before testing functional flows, verify that frontend types EXACTLY match backend responses.

```bash
# 1. Verify ALL list endpoints return PaginatedResponse shape
curl --noproxy '*' http://127.0.0.1:{port}/api/v1/{resource_plural} | python3 -c "
import sys, json
data = json.load(sys.stdin)
assert 'items' in data, f'Contract violation: expected items, got: {list(data.keys())}'
assert 'total' in data, 'Contract violation: missing total'
assert 'page' in data, 'Contract violation: missing page'
assert 'size' in data, 'Contract violation: missing size'
print('OK: PaginatedResponse contract verified')
"

# 2. Verify frontend type fields match backend schema fields
# Read frontend types/*.ts field names
# Read backend schemas.py fields
# Every field in the frontend type MUST exist in the backend response
# No phantom fields (fields frontend expects but backend never sends)
```

**If mismatch found:** Fix the SOURCE OF TRUTH conflict immediately:
- Backend schemas.py is the authority
- Frontend types MUST conform to backend
- Never add fields to backend just to satisfy frontend — redesign the frontend type

### Step 7: Verify Auth Flow (real auth or dev bypass)

If developer provided Keycloak, test the real OIDC flow.
If auth is disabled for now, verify dev bypass middleware still responds correctly:

```bash
# Without auth header → dev bypass returns dev-user context
curl --noproxy '*' -s http://127.0.0.1:{port}/api/v1/{resource_plural} | \
  python3 -c "import sys, json; data=json.load(sys.stdin); assert 'items' in data; print('OK')"

# If local auth enabled → test register/login/token flow
# Generate ephemeral test credentials at runtime
TEST_USER="test_dev_$(python3 -c "import secrets; print(secrets.token_hex(4))")"
TEST_PASS="$(python3 -c "import secrets, string; print('T' + secrets.token_urlsafe(12) + '1!')")"

curl --noproxy '*' -s -X POST http://127.0.0.1:{port}/api/v1/auth/register \
  -H "Content-Type: application/json" \
  -d "{\"username\":\"$TEST_USER\",\"password\":\"$TEST_PASS\"}" | \
  python3 -c "import sys,json; d=json.load(sys.stdin); print('Register:', d)"

curl --noproxy '*' -s -X POST http://127.0.0.1:{port}/api/v1/auth/login \
  -H "Content-Type: application/json" \
  -d "{\"username\":\"$TEST_USER\",\"password\":\"$TEST_PASS\"}" | \
  python3 -c "import sys,json; d=json.load(sys.stdin); \
  assert 'access_token' in d, f'Missing token: {d}'; \
  assert 'user' in d and 'id' in d['user']; print('Auth OK: token + user.id present')"
```

### Step 8: End-to-End Functional Flow (CRITICAL — NO SKIPPING)

**EXTENDED REASONING — E2E Flow Coverage Analysis (before testing)**

Before executing any E2E tests, reason deeply about WHAT to test:

1. **PRD story mapping**: List every user story from the PRD. For each one, define
   the exact API call sequence that proves it works. If a story can't be tested
   via API calls alone (e.g., "user sees dashboard"), flag it for Step 9 (frontend).
2. **Happy path vs edge cases**: For each flow, what's the minimum happy path?
   What's the most likely failure mode? Test BOTH.
3. **Dependency ordering**: Which flows must succeed before others can run?
   (e.g., "create dataset" must work before "train model on dataset")
   Execute in dependency order — don't test downstream flows if upstream fails.
4. **AI-specific flows**: If inference is involved, is there a mock/stub mode?
   If EI is unavailable, can we verify the request FORMAT is correct even if
   the response is mocked? Never skip AI flows — at minimum verify the contract.
5. **Data setup requirements**: What seed data is needed? Which flows need
   pre-existing records? Create setup fixtures before testing.

Output a numbered test plan BEFORE executing:
"E2E Test Plan ({N} flows from {M} user stories):
1. {flow_1}: {API_sequence} — tests story: {story_ref}
2. {flow_2}: {API_sequence} — tests story: {story_ref}
..."

Then execute each flow in order. Stop on first critical failure and fix before continuing.

This is the core of dev sanity. The developer verifies that EVERY functional workflow
from the PRD completes end-to-end with REAL services. No flow is skipped.

**Derive functional flows from the PRD user stories.** Each PRD user story that says
"As a user, I want to..." becomes a testable flow. The dev-agent maps PRD acceptance
criteria to concrete API calls.

**Generic pattern for functional flow verification:**

For EVERY resource/workflow in the PRD:

```bash
# 1. CREATE — verify the resource can be created (JSON or multipart as per endpoint)
CREATE_RESP=$(curl --noproxy '*' -s -X POST http://127.0.0.1:{port}/api/v1/{resource} \
  {-H "Content-Type: application/json" -d '{...}' | -F "field=value"})
RESOURCE_ID=$(echo "$CREATE_RESP" | python3 -c "import sys,json; print(json.load(sys.stdin)['id'])")

# 2. PROCESS — if the resource triggers async processing, verify it completes
# Poll status until not "pending" (timeout: 60s for real EI, 10s for inline)
for i in $(seq 1 60); do
  STATUS=$(curl --noproxy '*' -s http://127.0.0.1:{port}/api/v1/{resource}/$RESOURCE_ID | \
    python3 -c "import sys,json; print(json.load(sys.stdin).get('status','unknown'))")
  [ "$STATUS" = "completed" ] && break
  sleep 1
done
[ "$STATUS" = "completed" ] || echo "FAIL: stuck in $STATUS"

# 3. READ — verify the result is accessible and has expected shape
curl --noproxy '*' -s http://127.0.0.1:{port}/api/v1/{resource}/$RESOURCE_ID | \
  python3 -c "import sys,json; d=json.load(sys.stdin); assert 'id' in d; print('GET OK')"

# 4. DOWNLOAD/OUTPUT — if the workflow produces output files, verify download works
curl --noproxy '*' -s -o /tmp/output.jsonl \
  http://127.0.0.1:{port}/api/v1/{resource}/$RESOURCE_ID/download
[ -s /tmp/output.jsonl ] && echo "Download OK: $(wc -l < /tmp/output.jsonl) lines"

# 5. LIST — verify pagination works
curl --noproxy '*' -s http://127.0.0.1:{port}/api/v1/{resource} | \
  python3 -c "import sys,json; d=json.load(sys.stdin); \
  assert 'items' in d and d['total'] >= 1; print(f'List OK: {d[\"total\"]} items')"

# 6. DELETE — verify cleanup works
curl --noproxy '*' -s -X DELETE http://127.0.0.1:{port}/api/v1/{resource}/$RESOURCE_ID
```

**AI-Powered Flows (require REAL EI):**

When the PRD includes AI features (generation, inference, classification, etc.),
these flows MUST be tested with the real Enterprise Inference endpoint:
- Verify the EI model produces actual output (not mock responses)
- Verify output quality is reasonable (valid JSON, expected structure)
- Verify error handling when EI returns errors (rate limit, timeout)
- Verify the output format matches what the frontend expects to display

**If ANY flow fails, the dev-agent MUST:**
1. Identify which stage broke (create? processing? output? format?)
2. Diagnose root cause from error output
3. Fix the generated code (not a workaround — a real fix)
4. Re-run the failing flow
5. Maximum 3 fix iterations per flow — then report to developer with root cause

**Developer iteration loop:**
After the dev-agent verifies, the developer may want to:
- Test additional edge cases
- Test via the frontend UI (manual browser testing)
- Test with real production documents
- Report issues for the dev-agent to fix

The dev-agent supports this iterative process. Dev sanity is NOT a one-shot gate —
it's a collaborative verification cycle that ends when the developer says "done."

### Step 9: Frontend Integration Verification

**Method A: Playwright (preferred — if plugin installed)**

Use the Playwright MCP tools to visually verify the frontend renders correctly:

1. Navigate to http://127.0.0.1:5173
2. Wait for React to mount (check for `#root` element with children)
3. If auth is enabled: verify login page renders. If `VITE_AUTH_REQUIRED=false`: verify redirect to main page.
4. Navigate to each feature page via router links
5. Verify key elements exist on each page:
   - Data table/list component (for list views)
   - Form elements (for create/edit views)
   - Navigation items matching PRD features
6. Take a screenshot of each major view for developer review
7. Check browser console for JavaScript errors — any error is a failure

This catches the Gurunath demo issue: HTML served but React component not rendering.

**Method B: curl fallback (if Playwright not available)**

```bash
cd {output_root}/frontend
npx vite --port 3000 &
sleep 5

# 9a. Frontend serves HTML
curl --noproxy '*' -s http://127.0.0.1:5173/ | grep -q '<div id="root"' && echo "HTML OK"

# 9b. Vite proxy routes /api → backend
curl --noproxy '*' -s http://127.0.0.1:5173/healthz | grep -q '"status"' && echo "Proxy OK"

# 9c. API calls through frontend proxy return correct data shape
curl --noproxy '*' -s http://127.0.0.1:5173/api/v1/{resource_plural} | \
  python3 -c "import sys,json; d=json.load(sys.stdin); assert 'items' in d; print('Proxy→API OK')"
```

**NOTE**: Method B only verifies HTML is served — it does NOT verify that React components
actually render. Always prefer Method A (Playwright) for true visual verification.

### Step 10: Docker Image Build Verification

If Docker is available, verify ALL images build successfully:

```bash
cd {output_root}
docker build -t {project_slug}-api:dev -f src/{component}/Dockerfile src/{component}/ && echo "API image OK"
docker build -t {project_slug}-worker:dev -f src/worker/Dockerfile src/worker/ && echo "Worker image OK"
docker build -t {project_slug}-frontend:dev -f frontend/Dockerfile frontend/ && echo "Frontend image OK"
```

If Docker is NOT available, mark as "deferred to Docker Compose full-stack test" — do NOT skip.

### Step 11: Auto-Fix and Re-verify

If ANY check fails, the dev-agent MUST:
1. Identify the root cause from the error output
2. Apply the fix to the generated code (not a workaround — a real fix)
3. Re-run the ENTIRE failing step (not just the broken assertion)
4. Maximum 3 fix iterations per step — then report remaining issues to user

```
Dev Sanity: 1 failure detected

FAILURE: Processing returned empty result — EI returned unexpected format
ROOT CAUSE: EI response parsing expects 'choices[0].message.content' but model returns 'text' field
FIX: Updating response parser to handle both OpenAI and vLLM response formats
APPLYING... ✓ Fixed

Re-running full flow... ✓ ALL CHECKS PASS
```

### Step 12: Present Results

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
DEV SANITY — {project_name} (REAL INFRASTRUCTURE)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Infrastructure:
  • EI: {endpoint} ({N} models) ✓
  • DB: {sqlite/postgresql} ✓
  • Storage: {local/minio} ✓
  • Queue: {inline/celery+redis} ✓
  • Auth: {disabled/local/keycloak} ✓

Functional Flows:
  ✓ Backend starts on :{port}
  ✓ GET /healthz → 200
  ✓ Frontend-backend contracts aligned (types match)
  ✓ EI connectivity verified (real model responses)
  ✓ E2E: {PRD-specific flow description}
  ✓ All {N} PRD functional flows complete
  ✓ CRUD operations work with pagination
  ✓ Frontend serves HTML on :3000
  ✓ Vite proxy routes /api → backend correctly
  ✓ Docker images build (or deferred)

Tested with REAL services. No mocks. No skipped flows.
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

---

