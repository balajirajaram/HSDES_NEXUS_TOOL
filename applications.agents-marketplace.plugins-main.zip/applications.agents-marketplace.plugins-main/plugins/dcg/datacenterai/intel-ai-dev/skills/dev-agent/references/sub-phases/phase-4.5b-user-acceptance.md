## Phase 4.5b: User Acceptance Sanity (MANDATORY — before Integration Audit)

**Principle: The developer IS the first customer.**

After automated dev sanity passes (Phase 4.5), the developer manually tests the running
application in a browser. This catches issues that automated E2E tests cannot:
- UI doesn't render as expected (layout, spacing, visual bugs)
- Workflow feels wrong (UX flow, missing interactions, confusing steps)
- Features the PRD describes but the agent missed generating
- Features generated incorrectly (wrong logic, wrong fields, wrong behavior)
- New requirements discovered during hands-on testing

This phase is INTERACTIVE. The agent starts both servers, presents testing instructions,
and WAITS for developer feedback. It does NOT proceed automatically.

---

### Step 1: Start Both Servers

```bash
# Backend
cd {output_root}/src/{package_name}
python -m uvicorn app.main:app --port {port} --host 127.0.0.1 &

# Frontend
cd {output_root}/frontend
npx vite --port 5173 --host 127.0.0.1 &
```

Verify both are reachable before presenting to user:
```bash
curl --noproxy '*' -s http://127.0.0.1:{port}/healthz
curl --noproxy '*' -s http://127.0.0.1:5173/ | head -3
```

### Step 2: Present Technical Status & Testing Instructions

**MANDATORY: Tell the developer what is technically up and running, what substitutions
are active in dev mode, and what is NOT covered at this stage.** The developer must
understand the full picture before testing.

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
USER ACCEPTANCE SANITY — {project_name}
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

WHAT'S RUNNING (Dev Mode):
  Backend:  http://127.0.0.1:{port}
  API Docs: http://127.0.0.1:{port}/api/docs
  Frontend: http://127.0.0.1:5173

DEV SUBSTITUTIONS ACTIVE:
  • Database: SQLite (production = PostgreSQL)
  • Storage: Local filesystem (production = MinIO/S3)
  • Task queue: Inline execution (production = Celery + Redis)
  • Auth: Local JWT (production = Keycloak SSO)
  • Inference: {mock_or_real_ei} (production = Enterprise Inference)

LOGIN CREDENTIALS:
  Username: demo
  Password: Demo1234
  (Auto-seeded demo user. You can also click "Register" to create your own.)

WHAT THIS SANITY COVERS:
  ✓ Full user workflow end-to-end (login → action → results → download)
  ✓ All CRUD operations via real database
  ✓ File upload/processing with real {inference_mode}
  ✓ Frontend-backend contract (field names, pagination, error handling)
  ✓ UI layout, navigation, interaction flow

WHAT IS NOT COVERED (tested later):
  ✗ Containerized deployment (Phase 5 / compliance-agent)
  ✗ Kubernetes/Helm (production infrastructure)
  ✗ Load testing, rate limiting under stress
  ✗ Keycloak SSO integration
  ✗ Multi-user concurrent access
  → These are verified after README generates & compliance/validation agents run.
  → A FINAL user sanity covering ALL scenarios happens post-compliance.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

SUGGESTED TEST PATH:
  1. Login with demo / Demo1234
  2. Navigate through all pages (sidebar links)
  3. Create a resource (upload, fill form, etc.)
  4. Watch processing status update
  5. View results, download output
  6. Delete and verify cleanup

Report what you find. Options:
  A) "Missing feature" — PRD says X but it's not generated
  B) "Wrong behavior" — feature exists but works incorrectly
  C) "UI issue" — layout, styling, interaction problems
  D) "New requirement" — want something not in the PRD
  E) "All good" — proceed to Integration Audit
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

### Step 3: Wait for Developer Feedback

**DO NOT PROCEED until the developer responds.** This is a blocking gate.

### Step 4: Iteration Loop (if issues reported)

For each issue the developer reports:

1. **Acknowledge** — "I see the issue: {description}"
2. **Classify** — Is this a code bug, missing feature, UI fix, or new scope?
3. **Fix** — Make the change immediately
4. **Verify** — Re-run the backend import check (`python -c "from app.main import app"`)
5. **Report** — "Fixed: {what changed}. Please refresh and re-test."

**Repeat until developer says "All good" or "Proceed".**

**Rules for iteration:**
- If the fix is a code bug (wrong logic, missing endpoint) → fix and re-test
- If the fix is a missing PRD feature → generate it (same patterns as Phase 4)
- If the fix is a new requirement NOT in PRD → confirm scope before implementing
- If the fix requires architectural changes → present options, don't just do it
- Maximum 10 iterations before suggesting a checkpoint commit

### Step 5: Checkpoint After Acceptance

Once the developer approves:

1. Stop the running servers (or leave them for integration audit)
2. Run the Phase 4.9 completion gate again (imports, placeholders, TypeScript)
3. Commit progress: `feat({slug}): user acceptance sanity passed`
4. Update `.iteration-state.json` with acceptance status

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
USER ACCEPTANCE — PASSED
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Developer verified:
  ✓ {list of flows tested}
Iterations: {N} fixes applied
Ready for Phase 4.6 Integration Audit.
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

---

### Why This Phase Exists

Before this phase was added, the pipeline had a gap:
- Phase 4.5 automated tests verify API contracts and data flow
- But they cannot verify: visual rendering, UX flow, missing features the agent
  didn't realize it needed to generate, or incorrect interpretations of the PRD

The developer catching these issues HERE (before integration audit) means:
- Fixes are cheap (code is fresh, context is loaded)
- Integration audit checks FINAL code, not code that's about to change
- README generation (Phase 4.7) documents the ACTUAL product, not a broken one
- No wasted work auditing code that will be rewritten

**This is the last chance to iterate on features before the code is locked down.**

---

### Two-Stage User Sanity Model

This pipeline uses a **two-stage** user sanity approach:

| Stage | When | What's Covered | What's NOT Covered |
|-------|------|----------------|-------------------|
| **Phase 4.5b (THIS)** | After code gen, before integration audit | Functional flow, UI, missing features, wrong behavior | Containers, K8s, load, SSO, multi-user |
| **Final Sanity** | After compliance/validation agents complete | ALL scenarios: containerized, production-equivalent, full security | Nothing — this is the production-readiness gate |

**Tell the developer at Phase 4.5b:**
> "This sanity covers the functional product. After README generates and
> compliance/validation agents finish, you'll do a FINAL sanity that covers
> the full production stack (Docker, Helm, security scans passing, rate limiting,
> etc.). Think of this as 'does the product work?' and the final one as
> 'is the product ready to ship?'"

### Auth Guidance for Dev Sanity

The scaffold seeds a **demo user** on startup when running in dev mode (SQLite):
- **Username:** `demo`
- **Password:** `Demo1234`

This is handled by `_seed_demo_user()` in `main.py` lifespan. The developer can also
use the "Register" link on the login page to create additional test accounts.

**If the project has `AUTH_ENABLED=false`**: The backend still accepts all requests
(security middleware returns a dev-user), but the frontend login page still appears.
The auth endpoint must still be wired in `router.py` and the demo user seeded so
the frontend login flow works end-to-end.

**Template rule:** ALWAYS wire the auth router and seed the demo user, regardless of
`AUTH_ENABLED` setting. The user acceptance sanity tests the FULL user experience
including login.

---
