## Phase 4.6: Code Integration Audit (MANDATORY — before README generation)

**EXTENDED REASONING — Semantic Integration Analysis (Phase 4.6 start)**

Before running mechanical checks, reason deeply about the semantic integrity of the codebase:

1. **Data flow tracing**: Trace a request from frontend → API → service → database → response.
   At each boundary, does the type transform correctly? Are there fields that exist on one
   side but not the other? (This is where C9 violations hide.)
2. **Code path completeness**: For each feature generated in Phase 4, does a complete
   code path exist? endpoint registered → service called → model accessed → schema returned.
   If any link in the chain is missing, it's an orphan that will 404 at runtime.
3. **Configuration coherence**: Do all components agree on ports, database names, service
   URLs? A common failure: backend uses port 8000, but docker-compose maps 8080, and
   frontend calls localhost:8000 — works in dev, fails in Docker.
4. **Template residue**: Did scaffold.py leave any `{{placeholder}}` un-substituted?
   Did Phase 4 generation create files that conflict with scaffold output?
   (e.g., two different `router.py` files, one from scaffold, one from Phase 4)
5. **Import graph**: Starting from `app/main.py`, can every import be resolved?
   Are there circular dependencies between service modules?

Prioritize findings by severity:
- CRITICAL: Will cause runtime crash (broken imports, missing routes)
- HIGH: Will cause incorrect behavior (type mismatches, wrong ports)
- MEDIUM: Will cause confusion (orphan files, unused code)

Fix ALL critical and high issues before proceeding. Medium issues: fix or document.

**Principle: Before generating the final README, verify that ALL code is properly
integrated. No orphan files, no broken imports, no contract mismatches, no dead
endpoints. The README documents what EXISTS and WORKS — so the code must be solid first.**

### Step 1: Full Integration Check

The dev-agent performs a comprehensive sweep of the generated codebase:

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
CODE INTEGRATION AUDIT
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Checking...
```

**Checks to perform:**

| # | Check | What it catches |
|---|-------|----------------|
| 1 | All Python imports resolve | Missing modules, circular deps |
| 2 | All API endpoints are reachable | Unregistered routes in router.py |
| 3 | Frontend types match backend schemas | Field name/type mismatches |
| 4 | Frontend API calls match registered endpoints | 404s from wrong paths |
| 5 | All env vars in config.py exist in .env.example | Missing documentation |
| 6 | All env vars in docker-compose.yml exist in .env.example | Orphan config |
| 7 | Worker pipeline imports resolve | Missing pipeline stages |
| 8 | Database models match schema definitions | ORM ↔ Pydantic drift |
| 9 | Dockerfile COPY paths match actual file structure | Build failures |
| 10 | Helm values reference correct ports/paths | Deployment misconfig |

**How to perform each check:**

```bash
# Check 1: Python imports
cd src/{component}
python3 -c "import app.main"  # Will fail if any import is broken

# Check 2: Registered routes
python3 -c "
from app.main import app
routes = [r.path for r in app.routes]
print('Registered routes:', sorted(routes))
# Verify all expected endpoints are listed
"

# Check 3: Frontend-Backend type alignment
# Read frontend types/index.ts fields
# Read backend schemas.py fields
# Compare: every frontend field must exist in backend response
# Flag: fields frontend expects but backend doesn't send

# Check 4: Frontend API paths
# Grep frontend for /api/v1/* patterns
# Verify each matches a registered backend route

# Check 5-6: Env var consistency
# Parse .env.example → set of var names
# Parse config.py env_prefix + field names → set of expected vars
# Parse docker-compose.yml environment blocks → set of used vars
# Report: any var in code but not in .env.example
```

### Step 2: Fix Integration Issues

If ANY check fails:
1. Fix the code (not just suppress the check)
2. Re-run the full audit
3. Maximum 3 iterations — then report remaining issues

### Step 3: Present Audit Results

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
CODE INTEGRATION AUDIT — RESULTS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
✓ All imports resolve (0 broken)
✓ {N} API endpoints registered and reachable
✓ Frontend types aligned with backend schemas
✓ Frontend API calls match registered routes
✓ {M} env vars documented in .env.example
✓ Worker pipeline fully connected
✓ Database models ↔ Pydantic schemas consistent
✓ Dockerfiles reference correct paths
✓ Helm values consistent with app config

Code is integration-ready. Generating README.
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

---

