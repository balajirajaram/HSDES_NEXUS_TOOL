## Phase 4.7: Production-Ready README & Configuration (MANDATORY)

**Principle: The README is generated AFTER code is verified solid. It documents
what EXISTS and WORKS — not aspirational features. A customer who has never seen
this codebase can deploy to production by following it step-by-step.**

### Step 1: README Structure (Required Sections)

The generated README.md MUST contain ALL of the following sections:

```markdown
# {Project Name}

{One-line description}

## Architecture

{ASCII diagram showing ALL components AND their responsibilities}
{Must include: what workers DO (pipeline stages), data flow direction,
external dependencies, port numbers}

## Prerequisites

- Runtime requirements (Python, Node.js versions)
- Infrastructure requirements (Docker, or individual services)
- External service requirements (Enterprise Inference, Keycloak)
- Links to setup guides for each prerequisite

## Enterprise Inference Setup

{Dedicated section — NOT buried in a generic "Configuration" block}
- What EI is and why this project needs it
- Link to EI deployment guide: https://github.com/opea-project/Enterprise-Inference
- Expected endpoint format (OpenAI-compatible /v1/chat/completions)
- How to verify your EI instance is reachable
- What happens if EI is unavailable (mock mode for development)
- Supported models and how to check available models

## Quick Start — Development (No Docker)

{Step-by-step to run locally with ZERO external dependencies}
- Uses: SQLite, local filesystem, mock EI, inline processing
- Developer can test full flow immediately after clone
- Include EXACT commands (not "run the server" — the actual command)
- Include verification step (curl command to prove it works)

## Quick Start — Docker Compose (Full Stack)

{Step-by-step to run the complete production-like stack}
- Set environment variables (EI endpoint, tokens)
- docker compose up
- Verify all services healthy
- Access the UI

## Docker Image Build & Publish

{How to build images locally and push to a registry}
- Build commands for each service (api, worker, frontend)
- Tag conventions
- Push to registry (generic — works with any OCI registry)
- Image size expectations

## Configuration Reference

{Complete table of ALL environment variables}
- Variable name, description, default value, required/optional
- Grouped by: Database, Cache, Storage, Inference, Auth, Observability
- Clear indication of which are dev-only vs production-required

## API Documentation

- Where to find Swagger UI
- Key endpoints with request/response examples
- Authentication requirements per environment

## Worker Pipeline

{Detailed explanation of what the async workers do}
- Pipeline stages: Parse → Chunk → PII Detect → Generate → Verify → Format
- What each stage does, inputs, outputs
- How to monitor progress
- Error handling and retries

## Development Guide

- How to run tests
- How to add a new pipeline stage
- How to add a new output format
- Code structure explanation
- Dev-mode shortcuts and their production equivalents

## Production Deployment

- Kubernetes/Helm deployment (reference to helm/ directory)
- Required secrets (EI token, DB password, MinIO credentials)
- Health checks and readiness probes
- Scaling considerations
- Monitoring and observability setup

## Troubleshooting

- Common errors and fixes
- How to check if EI is reachable
- How to verify database connectivity
- Log locations and how to read them
```

### Step 2: Architecture Diagram — Industry-Standard SVG (MANDATORY)

The generated project README MUST embed an SVG architecture diagram, NOT ASCII art.
This provides an industry-standard visual that renders in GitHub, Confluence, and browsers.

**How it works:**
1. During Phase 4.7, generate a project-specific SVG using the base script
2. The script reads the actual project structure (components, ports, dependencies)
3. Produces `docs/architecture/solution-overview.svg`
4. README embeds it: `![Architecture](docs/architecture/solution-overview.svg)`

**Generate the SVG:**
```bash
python scripts/gen_solution_svg.py \
  --project-dir {project_dir} \
  --project-name "{project_name}" \
  --output {project_dir}/docs/architecture/solution-overview.svg
```

The SVG generator script (`scripts/gen_solution_svg.py`) is a base template provided
by the pipeline. It reads the project's actual structure and generates a pixel-perfect
architecture diagram with:
- All runtime components discovered from source (backend, frontend, workers)
- Port numbers from config
- External dependencies from requirements/config (EI, Keycloak, DB, cache)
- Data flow arrows
- Intel brand colors
- Trust boundaries (internal vs external services)

**README Architecture section format:**
```markdown
## Architecture

![Solution Architecture](docs/architecture/solution-overview.svg)

### Components

| Component | Technology | Port | Purpose |
|-----------|-----------|------|---------|
| Backend   | FastAPI   | 8000 | REST API, business logic |
| Frontend  | React+Vite| 5173 | User interface |
| Workers   | Celery    | —    | Async processing pipeline |
| ...       | ...       | ...  | ... |
```

**Additionally**, include Mermaid diagrams inline in the README for specific flows
(API sequence, auth flow, worker pipeline) — these complement the SVG overview:
```markdown
### API Flow

\`\`\`mermaid
sequenceDiagram
    participant FE as Frontend
    participant API as Backend
    participant WK as Worker
    participant EI as Enterprise Inference
    FE->>API: POST /api/v1/jobs
    API->>WK: dispatch(job_id)
    WK->>EI: chat_completion(prompt)
    EI-->>WK: response
    WK-->>API: job.status = complete
    FE->>API: GET /api/v1/jobs/{id}
\`\`\`
```

**The old ASCII approach is DEPRECATED.** SVG for architecture overview, Mermaid for
specific flows — this is the industry standard for modern open-source projects.

### Step 3: .env.example Completeness

The `.env.example` file MUST contain EVERY configurable variable with:
- A descriptive comment explaining what it does
- The dev-mode default value
- A comment showing the production value pattern

```env
# ─── Environment ───────────────────────────────────
ENVIRONMENT=dev                # dev | staging | prod

# ─── Database ──────────────────────────────────────
# Dev: SQLite (no setup needed)
# Prod: DB_URL=postgresql+asyncpg://user:pass@host:5432/dbname
DB_URL=sqlite+aiosqlite:///./data/app.db

# ─── Enterprise Inference ──────────────────────────
# Your deployed EI endpoint (OpenAI-compatible API)
# Set to "mock://" to use built-in mock for development
# See: https://github.com/opea-project/Enterprise-Inference
INFERENCE_API_ENDPOINT=mock://
INFERENCE_API_TOKEN=
INFERENCE_MODEL_NAME=meta-llama/Llama-3.3-70B-Instruct

# ─── File Storage ──────────────────────────────────
# Dev: local filesystem (automatic)
# Prod: MinIO/S3-compatible object storage
MINIO_ENDPOINT=
MINIO_ACCESS_KEY=minioadmin
MINIO_SECRET_KEY=minioadmin

# ─── Task Queue ────────────────────────────────────
# Dev: inline processing (no Redis needed)
# Prod: Redis-backed Celery
CELERY_ENABLED=false
CELERY_BROKER_URL=redis://localhost:6379/0

# ─── Authentication ────────────────────────────────
# Dev: disabled (all requests use dev-user)
# Prod: Keycloak OIDC
AUTH_ENABLED=false
AUTH_KEYCLOAK_URL=https://keycloak.example.com
AUTH_REALM=myapp
AUTH_CLIENT_ID=myapp-api
```

### Step 4: Configuration Parity Verification

After generating README and configs, verify:
1. Every env var in `.env.example` is read by config.py
2. Every env var in docker-compose.yml exists in `.env.example`
3. Every env var in helm values.yaml has a matching `.env.example` entry
4. README "Configuration Reference" table matches `.env.example` exactly
5. No orphan variables (referenced but never used, or used but never documented)

### Step 5: Developer Tooling README (MANDATORY)

Generate `docs/DEVELOPER-TOOLING.md` — a platform-agnostic guide explaining all
automation and tooling files. This keeps the main README focused on the application
while providing full developer infrastructure documentation separately.

**Required sections in DEVELOPER-TOOLING.md:**
1. **Makefile** — All targets with descriptions and usage examples
2. **Taskfile.yml** — Alternative task runner, install instructions, task list
3. **scripts/** — Purpose of each script, when to use it
4. **ansible/** — Playbook structure, when to use Ansible vs Helm
5. **`.github/workflows/`** — CI/CD pipeline explanation, what each workflow does
6. **CLAUDE.md** — What it is, why it exists, when to update it
7. **Platform Notes** — Linux/macOS as primary, Windows via WSL2/Git Bash/Task

**Platform stance:** Linux and macOS are the primary development platforms.
Windows instructions use WSL2 (recommended) or Git Bash as alternatives.
Do NOT write Windows-first documentation.

**Add reference in main README.md** (before License section):
```markdown
## Developer Tooling

For detailed documentation on the Makefile, Taskfile, Ansible playbooks, CI/CD workflows,
scripts, and CLAUDE.md — see **[docs/DEVELOPER-TOOLING.md](docs/DEVELOPER-TOOLING.md)**.
```

---

