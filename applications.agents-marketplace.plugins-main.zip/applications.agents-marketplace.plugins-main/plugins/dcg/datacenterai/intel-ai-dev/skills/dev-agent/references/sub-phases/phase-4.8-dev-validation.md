## Phase 4.8: Developer README Verification & Product Validation

**Principle: After README is generated, present the current state to the developer.
Developer verifies the README manually (as a customer would). Then optionally
validates the full product by using it as per README instructions.**

### Step 1: Present Current State Summary

After README generation, present a complete summary of what's been built:

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
PROJECT STATE SUMMARY — {project_name}
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

FILES GENERATED: {total_count}
  Backend:   {api_count} files (FastAPI + SQLAlchemy)
  Worker:    {worker_count} files (Pipeline stages)
  Frontend:  {frontend_count} files (React + TypeScript)
  Infra:     {infra_count} files (Docker, Helm, CI/CD)

FUNCTIONAL FLOWS VERIFIED:
  ✓ Upload → Job Creation
  ✓ Full Pipeline: Parse → Chunk → PII → Generate → Verify → Format
  ✓ Dataset Download (valid JSONL)
  ✓ Quality Report Generation
  ✓ CRUD Operations (list, get, delete)
  ✓ Frontend-Backend Proxy Integration

INFRASTRUCTURE TESTED (real services):
  • Inference: {EI @ URL — N models, response time Xms}
  • Task Queue: {Redis/Celery @ URL | inline processing}
  • Storage: {MinIO @ URL | local filesystem}
  • Database: {PostgreSQL @ URL | SQLite}
  • Auth: {Keycloak @ URL | local JWT | dev bypass}

README: Generated at {project_slug}/README.md
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

NEXT STEPS:
1. Verify README — Follow it as a customer would (recommended)
2. Validate product — Use the app end-to-end as per README
3. Proceed to /validation-agent — Skip manual verification
4. Continue testing — I want to test more functional flows
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

### Step 2: Developer Verifies README (if chose option 1)

The developer reads the README and follows it step-by-step. The dev-agent is
available to fix any issues the developer encounters.

**Developer's checklist (they verify manually):**
- Can I understand the architecture from the README alone?
- Are the prerequisites clear? Do I know what I need before starting?
- Does "Quick Start (Development)" work exactly as written?
- Does "Quick Start (Docker Compose)" work exactly as written?
- Is the EI section clear about what to deploy and where?
- Can I find the Docker build instructions easily?
- Is the Configuration Reference complete?

If the developer reports issues → dev-agent fixes README → developer re-checks.

### Step 3: Full Product Validation (if chose option 2)

The developer uses the product exactly as a real customer would:

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
PRODUCT VALIDATION — Use as a customer
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Follow the README from scratch:

1. Start the application (dev mode or Docker Compose)
2. Open the frontend in a browser
3. Upload a real document (PDF, Excel, or DOCX)
4. Configure the job (model, format, chunk size)
5. Submit and wait for processing
6. Download the generated dataset
7. Inspect the JSONL output — is it usable for training?
8. Check the quality report — does it make sense?

Report any issues and I'll fix them.
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

The dev-agent stays available to fix issues discovered during this validation.
This is an iterative process — developer reports issue → agent fixes → developer retests.

### Step 4: Final Sign-off

Once the developer is satisfied:

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
PRODUCTION READINESS — {project_name}
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
✓ All functional flows verified
✓ Code integration audit passed
✓ README generated and verified
✓ Product validated by developer
✓ Dev mode works with zero external infrastructure

Ready for /validation-agent (automated tests + coverage).
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

---

