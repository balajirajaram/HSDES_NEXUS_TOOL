## Phase 5: Validation

After dev sanity passes, run static validation checks:

```bash
# Syntax checks
cd src/{component}
python -m py_compile app/main.py
python -m py_compile app/config.py

# Lint checks
ruff check . 2>/dev/null || echo "ruff not installed — install with: pip install ruff"

# Docker build check (if Docker available)
docker build -t {component}:test . 2>/dev/null || echo "Docker not available"

# Helm lint (if helm available)
helm lint helm/{project}/ 2>/dev/null || echo "Helm not available"
```

Report results to user.

---

