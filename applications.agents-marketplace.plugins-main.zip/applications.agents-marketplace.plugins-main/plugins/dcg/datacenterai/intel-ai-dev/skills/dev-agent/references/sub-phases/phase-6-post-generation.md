## Phase 6: Post-Generation

### Step 1: Generate Reports

After all project files are created, generate the following reports:

**`reports/generation/generation-summary.md`** — Contains:
- Project name, slug, Technical PRD reference
- Variable values used during generation (all template variables and their resolved values)
- Component list with file counts per component
- PRD-to-file mapping (which PRD section drove which files)
- Total file count and generation timestamp

**`reports/generation/file-manifest.json`** — Contains:
- Filename + SHA256 hash of each generated file
- Source classification: "template" (from templates/) or "prd-generated" (from PRD content)
- Template path reference for template-sourced files
- PRD user story reference for PRD-generated files
- Used for determinism checking across runs

### Step 2: Create Iteration State

Create `.iteration-state.json` at the output root. MUST include the canonical phase keys
that other agents rely on for session recovery:

- `current_iteration`: 1
- `phases.generation.status`: "completed" (CANONICAL — required for validation-agent handoff)
- `phases.dev_sanity.status`: "completed" (CANONICAL — confirms E2E works)
- `tool_availability`: detect which tools are installed (ruff, mypy, docker, helm, etc.)
- `skipped_items`: any validation checks that couldn't run (Docker build, Helm lint)

You MAY also keep internal sub-phase keys (`phase_0`..`phase_4.8`) for your own session
recovery, but the canonical keys above are MANDATORY — other agents read them.

See `.claude/shared/contracts/iteration-state-schema.md` for the full schema.

### Step 3: Show Iteration Summary

Use the format from `.claude/shared/ux/iteration-summary-template.md`:

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
✅ ITERATION 1 COMPLETE — Project Generation
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

COVERED:
• Generated {count} files from Technical PRD
• All templates applied with variable substitution
• Python syntax validation passed (all .py files compile)
• Lint check: {result}

SKIPPED (needs config/infra):
• Docker build validation — {reason} — {install instruction}
• Helm chart lint — {reason} — {install instruction}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📊 REPORTS GENERATED
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
• Generation Summary: reports/generation/generation-summary.md
• File Manifest: reports/generation/file-manifest.json

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
⏭️ FOR ITERATION 2
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
1. Install: {tools needed}
2. Configure: {configs needed}
3. Deploy: {services needed}
4. Then run: /validation-agent to generate and run tests
```

### Step 4: Program Checkpoints (MANDATORY)

**After generation completes, you MUST present the Program Checkpoints gate.**

Follow `.claude/shared/ux/program-checkpoints.md` exactly. Present ALL 3 checkpoints together:

1. **Wiki** — Update PRD wiki page with "Code Generated" status + file count
2. **Jira** — Update all Stories with comment: "Code generated — ready for review"
3. **Git** — Commit entire generated project, push to feature branch

**Commit message:**
```
feat({project_slug}): Generate project scaffold from PRD

- {file_count} files generated from Technical PRD
- Backend: src/{component}/ (FastAPI + SQLAlchemy)
- Frontend: frontend/ (React + TypeScript)
- Helm: helm/{project}/ (K8s deployment)
- CI/CD: .github/workflows/ (5 pipelines)
```

**After checkpoints are processed:** Save project state to Claude memory automatically (see program-checkpoints.md § Memory Save).

Then show phase transition:
```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🔗 HANDOFF: Dev → Validation
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Project generation complete. Ready for validation.
Artifacts: {project_slug}/, reports/generation/

🔀 YOUR OPTIONS
1. Run /validation-agent now
2. Review generated output first
3. Stop here — I'll continue later
```

---

