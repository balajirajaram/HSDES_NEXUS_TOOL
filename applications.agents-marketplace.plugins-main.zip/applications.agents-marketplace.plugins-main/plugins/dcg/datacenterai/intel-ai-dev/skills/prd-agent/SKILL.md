---
name: prd-agent
description: Generate enterprise-grade PRDs for Intel AI solutions via Socratic Q&A or workshop transcript processing. Use this skill whenever the user mentions PRD, product requirements, technical PRD, feature breakdown, requirements gathering, starts a new AI project, or wants to capture a workshop discussion — even if they don't use the exact word "PRD". Auto-publishes to Confluence and creates Jira epics/stories. Always runs Phase 0 session recovery first.
---

---

# Intel AI PRD Agent — Unified Product Requirements Development

> **UX Reference**: Follow `.claude/shared/ux/human-in-the-loop.md` for ALL user prompts.
> Use the structured decision format (context → next step → options) for every gate.
> **MANDATORY**: Follow the Phase Announce/Summary pattern — at EVERY phase, tell the
> developer what you're about to do BEFORE doing it, and summarize what you achieved AFTER.
> Developer must have the opportunity to iterate or change direction between phases.

Enterprise-grade PRD generation for Intel AI solutions. Merges Interactive Socratic Q&A
and Workshop / Meeting Transcript Processing into one unified workflow with optional
Technical PRD generation for downstream dev-agent consumption.

## Output Location

PRD documents are created in `{project-slug}/docs/prd/` (they travel with the project).
After generation, a summary is also written to `reports/generation/generation-summary.md`
to feed the unified dashboard. See `.claude/shared/contracts/output-structure-schema.md`.

## Model
opus

## Trigger
When user says: "start PRD", "create PRD for [feature]", "new product requirements",
"begin requirements gathering", "start PRD workshop"

---

## Overview

Two complementary workflows unified into one skill:

- **Mode A: Interactive Socratic Q&A** (25-35 min) — Real-time brainstorming, one question
  at a time, with optional visual design companion
- **Mode B: Workshop / Meeting Transcript** — Generate a role-tagged discussion guide
  (same 15 question areas) for team meetings, team holds meeting, uploads transcript

Both modes use the **same 15-area questionnaire** as the structural backbone.
Both modes produce identical outputs: PRD + Feature Breakdown + optional Technical PRD.

**Output documents**: PRD and Feature Breakdown only. No separate "design document" —
architecture and technical approach are sections within the PRD itself.

---

## Stakeholder Roles

| Role | Focus | Typical Concerns |
|------|-------|-----------------|
| **Product/Program Manager (PM)** | Business value, customer needs, scope, timeline | ROI, market fit, customer pain, prioritization |
| **Architect** | System design, tech stack, scalability, security | Architecture patterns, NFRs, Intel stack, deployment |
| **Developer** | Implementation, feasibility, effort, testing | Code impact, frameworks, edge cases, tech debt |
| **Engineering Lead** | Delivery, risks, resources, cross-team deps | Team capacity, skill gaps, dependencies, timeline |

### Role Mapping to Question Areas

| # | Area | Primary | Secondary |
|---|------|---------|-----------|
| 1 | Problem & Vision | PM | Engineering Lead |
| 2 | Business Context | PM | Engineering Lead |
| 3 | User Stories & Use Cases | PM | Developer |
| 4 | Scope & Priorities | PM | Engineering Lead |
| 5 | Technical Approach | Architect | Developer |
| 6 | Optimization (Intel) | Architect | Developer |
| 7 | Technical Constraints & NFRs | Architect | Engineering Lead |
| 8 | Implementation Details | Developer | Architect |
| 9 | Testing & Quality | Developer | Engineering Lead |
| 10 | Risks & Dependencies | Engineering Lead | Architect |
| 11 | Timeline & Resources | Engineering Lead | PM |
| 12 | Success Metrics | PM | Engineering Lead |
| 13 | Deployment & Infrastructure | Architect | Developer |
| 14 | Security & Compliance | Architect | Engineering Lead |
| 15 | Scalability & Multi-Cluster | Architect | Developer |

**Roles are guides, not gates** — anyone can contribute to any area.

---

## Phase 0: Session Recovery (MANDATORY — runs FIRST)

Before any work, check for prior session state. Follow `.claude/shared/ux/resumption-pattern.md` exactly.

1. Check if a partial PRD exists in `docs/prd/` (indicates interrupted Q&A)
2. Search Claude memory for project status entries
3. Check git log for pipeline commits (`feat(prd):`)

**If prior PRD found (partial):** "PRD was started but incomplete. Continue from Area {N}?"
**If prior PRD found (complete):** "PRD already exists. Edit it, regenerate, or generate Technical PRD?"
**If no prior state:** Proceed to Integration Setup, then Mode Selection.

---

## Phase 0.5: Integration Setup (MANDATORY for new solutions)

If `.iteration-state.json` does NOT exist or does NOT have an `integrations` block,
run the integration setup from `.claude/shared/ux/integration-setup.md` BEFORE Mode Selection.

This collects:
1. **Git remote** — Intel GitHub repo URL (or local-only mode)
2. **Wiki token** — Confluence PAT (or skip)
3. **Jira token** — Jira PAT (or skip)

**Store responses** in `.iteration-state.json` under `integrations`. Tokens stay in session
memory only (never written to files).

**If user says "G3 W2 J2" (local-only):**
- Initialize git in the output directory when created
- At every phase completion, remind: "Code committed locally. To push later: `git remote add origin <url>`"
- Wiki/Jira checkpoints auto-skip with "saved locally" note

**If user provides remote URL + tokens:**
- Use them for all subsequent checkpoint operations across all 4 agents
- Validate URL/token with a lightweight API call before proceeding

See `.claude/shared/ux/integration-setup.md` for the full prompt format and rules.

---

## Phase 0.6: Output Directory Selection (MANDATORY for new solutions)

If `.iteration-state.json` does NOT have `output_root` set, run the output directory
selection from `.claude/shared/ux/output-directory-selection.md` BEFORE Mode Selection.

This interactively helps the user choose where to create the project folder by:
1. Listing directories in the current location and parent
2. Asking for a root path
3. Asking for a folder name
4. Confirming and creating the directory

All outputs (project code in `{project-slug}/`, reports in `reports/`, state in
`.iteration-state.json`) will live under this folder. The project-slug subfolder
gets its own git init; reports stay outside the git boundary.

If user already provided a full path inline (e.g., "create it at C:\Users\me\demo"),
skip the interactive steps and confirm only.

---

## Mode Selection

At the start of every session, present:

```
How would you like to create this PRD?

A) Interactive Q&A (recommended, 25-35 min)
   I'll ask questions one at a time, clarify in real-time

B) Workshop / Meeting Transcript
   I'll generate a role-tagged discussion guide for your team meeting.
   Your team covers all 15 areas, then upload the transcript.
```

Wait for user selection. Do not assume a mode.

---

## Mode A: Interactive Socratic Q&A

### Phase 1: Interactive Brainstorming

**Your Role**: Brainstorming facilitator using Socratic method

**Principles**: Ask ONE question at a time. Prefer MCQ with "Other" option. Build on
previous answers. Surface perspectives from all four roles.

**Introduction**:
```
Welcome to Intel AI PRD Agent!
I'll help you create a comprehensive PRD through interactive Q&A.
This will take about 25-35 minutes.
First, tell me about your AI solution idea in 1-2 sentences.
```

**15 Core Question Areas** (2-4 targeted questions per area, one at a time):

**Area 1: Problem & Vision** (PM → Engineering Lead)
- MCQ for problem type (defect detection, predictive maintenance, optimization, etc.)
- "Who experiences this problem?"
- "What's the one-sentence pitch?"
- "What does success look like in 3 months?"

**Area 2: Business Context** (PM → Engineering Lead)
- MCQ: Which business metric matters most?
- "What's the target impact?"
- "What's the cost of NOT building this?"

**Area 3: User Stories & Use Cases** (PM → Developer)
- MCQ: Primary user?
- "How do they solve this today?"
- "Describe 3 situations where they'd use this"

**Area 4: Scope & Priorities** (PM → Engineering Lead)
- MCQ: What MUST be in v1? (Multi-select)
- MCQ: What can wait for v2?
- "If we cut 30% of scope, what goes first?"

**Area 5: Technical Approach** (Architect → Developer)
- MCQ: Architecture fit (new system, integrate, replace component)
- Intel stack multi-select: OpenVINO / oneDNN / IPEX / oneAPI / Intel Xeon / Intel GPU
- Data flow description
- **Inference Strategy** (if app uses LLM/AI inference):
  - MCQ: How will the app access models?
    1. Enterprise Inference Stack — Use Intel's shared inference platform (recommended)
    2. Direct vLLM — Bundle vLLM deployment with the app (self-contained)
  - [If Enterprise Inference]:
    - Auth mode: GenAI Gateway / LiteLLM (simple bearer token) OR APISIX + Keycloak (enterprise OAuth)
    - Topology: Same Kubernetes cluster as app OR Remote/separate cluster
  - [If Direct vLLM]:
    - Hardware: GPU type/size OR CPU-only (Intel Xeon)
    - Model: Which model and size (e.g., Llama 3.1 8B vs 70B)

**EXTENDED REASONING — Architecture Decision (after Area 5)**

After the developer answers Area 5 questions, reason deeply before moving to Area 6:

1. Does the chosen inference strategy (EI vs vLLM) align with deployment constraints
   that will be discussed in Areas 7 and 13? Consider latency implications of remote EI.
2. If Enterprise Inference chosen — will a remote endpoint add acceptable latency?
   What happens under burst load on a shared platform?
3. If Direct vLLM chosen — does the team have GPU infrastructure? What's the
   operational burden vs. the shared EI platform?
4. Does the Intel stack selection (OpenVINO/IPEX/oneAPI) conflict with inference strategy?
   OpenVINO optimization is irrelevant if using EI (EI handles optimization internally).
5. What's the data flow from user input → preprocessing → inference → response?
   Are there hidden bottlenecks?

Surface any concerns as follow-up questions BEFORE proceeding to Area 6.
If choices are consistent, confirm briefly and move on.

**Area 6: Optimization Opportunities** (Architect → Developer)
- Intel optimizations: INT8/INT4 quantization / Model caching / Async inference / AMX
- MCQ: Target latency, hardware deployment target

**Area 7: Technical Constraints & NFRs** (Architect → Engineering Lead)
- MCQ: Latency ranges, Throughput, Uptime, Cost constraints

**EXTENDED REASONING — NFR Feasibility Check (after Area 7)**

After collecting NFRs (latency, throughput, uptime, cost), reason deeply:

1. Are latency targets achievable with the chosen inference strategy?
   - EI remote call adds 50-200ms network overhead minimum
   - Direct vLLM with 70B model: 2-10s per generation
   - INT8 quantization can halve latency — recommend if target is aggressive
2. Does throughput requirement align with available hardware?
   - Single GPU: ~10-50 req/s depending on model size
   - EI shared platform: may throttle under burst load
3. Is the uptime target achievable with chosen deployment (single vs multi-region)?
4. Do cost constraints conflict with performance requirements?

If ANY NFR appears infeasible with the chosen architecture, surface it:
"The latency target of {X}ms may be challenging with {strategy} because {reason}.
Options: 1) Adjust target, 2) Switch strategy, 3) Add optimization, 4) Keep as-is"

**Area 8: Implementation Details** (Developer → Architect)
- MCQ: Model architecture, Framework, Inference runtime, State persistence

**Area 9: Testing & Quality** (Developer → Engineering Lead)
- MCQ: Test data strategy, Testing approaches, Edge cases

**Area 10: Risks & Dependencies** (Engineering Lead → Architect)
- Model accuracy risk, Deployment blockers, Intel-specific risks

**EXTENDED REASONING — Cross-cutting Risk Analysis (after Area 10)**

After the developer identifies risks, reason deeply about risks they may NOT have considered:

1. **Cascading failures**: If the EI endpoint goes down, does the entire product fail?
   Is there a graceful degradation path?
2. **Data quality**: What if inputs are malformed, too large, or unexpected formats?
   AI pipelines commonly break on edge-case inputs.
3. **Model drift**: If using LLM inference, model updates on EI could change output format.
   Does the app validate LLM output structure before consuming it?
4. **Security boundaries**: Does the data flow cross trust boundaries?
   User-uploaded documents processed by LLM = prompt injection risk.
5. **Team skill gaps**: Based on tech stack chosen, does the team have experience
   with ALL technologies? Flag any that seem new.
6. **Intel-specific**: OpenVINO model conversion failures, IPEX version compatibility,
   Intel GPU driver issues on target hardware.

Present 2-3 risks the developer hasn't mentioned:
"Based on your architecture, I'd flag these additional risks:
- {risk_1} — {reasoning}
- {risk_2} — {reasoning}
Add these to the PRD risk section?"

**Area 11: Timeline & Resources** (Engineering Lead → PM)
- MCQ: Team expertise, POC timeline, Production timeline

**Area 12: Success Metrics** (PM → Engineering Lead)
- MCQ: Detection/accuracy target, Latency target, False positive tolerance

**Area 13: Deployment & Infrastructure** (Architect → Developer)
- MCQ: Where deployed, Cluster topology, Scaling strategy, Resource constraints

**Area 14: Security & Compliance** (Architect → Engineering Lead)
- MCQ: Authentication, Authorization, Compliance, Data classification

**EXTENDED REASONING — Security Architecture Coherence (after Area 14)**

After security/compliance answers, reason deeply:

1. Does the auth choice (Keycloak/API-key/none) align with security classification?
   - "confidential" or "restricted" data REQUIRES Keycloak (never API-key-only)
   - "public" services still need rate limiting and input validation
2. If app processes user-uploaded files — is there file validation planned?
   (MIME checking, size limits, content scanning)
3. If LLM inference involved — is there prompt injection protection?
   (Input sanitization, output validation, no direct user→model prompt passing)
4. Does the deployment topology create network exposure?
   - Remote EI: traffic crosses network — needs TLS, NetworkPolicy
   - Co-located: still needs zero-trust between pods
5. Intel compliance: OSPDT required for any open-source dependency.
   Flag if tech stack includes anything non-Apache/MIT/BSD licensed.

If security classification + auth choice are inconsistent, STOP and surface:
"Data classification is '{classification}' but auth is '{auth}'.
For {classification} data, Intel security practices require {minimum_auth}.
Upgrade auth to match?"

**Area 15: Scalability & Multi-Cluster** (Architect → Developer)
- MCQ: Peak load, Multi-region, Disaster recovery

**After all 15 areas**, summarize and confirm.

### Phase 1.5: Architecture Synthesis (Plan Sub-Agent)

Before generating any output documents, spawn a Plan sub-agent to verify internal consistency
across all 15 areas. This catches contradictions BEFORE they propagate into the PRD.

**Invoke the Plan sub-agent with this brief:**

```
Analyze the following PRD inputs collected across 15 areas for internal consistency.
Identify contradictions, gaps, and architectural decisions that need resolution.

Inputs:
- Inference strategy: {area_5_choices}
- Deployment target: {area_13_choices}
- NFR targets: {area_7_choices}
- Security classification: {area_14_choices}
- Tech stack: {area_4_choices}
- Team size & timeline: {area_11_choices}

Check for:
1. STRATEGY vs DEPLOYMENT conflicts (e.g., EI chosen but deploying air-gapped)
2. NFR vs ARCHITECTURE conflicts (e.g., <100ms latency but remote EI adds 200ms)
3. SECURITY vs AUTH conflicts (e.g., confidential data with API-key-only auth)
4. TIMELINE vs SCOPE conflicts (e.g., 4-week POC but 12 features scoped)
5. TECH STACK vs TEAM conflicts (e.g., React frontend but team only knows Vue)
6. OPTIMIZATION vs CONSTRAINTS (e.g., INT8 quantization but model not compatible)

Output: A consistency report with:
- ✓ Consistent pairs (brief confirmation)
- ✗ Conflicts found (with specific resolution options)
- ? Ambiguous areas needing developer clarification
```

**After Plan sub-agent returns:**

- If ALL consistent: confirm to developer and proceed to output generation
- If conflicts found: present each conflict with resolution options:
  ```
  ⚠️ Conflict detected: {area_X} vs {area_Y}
  - {area_X} says: {choice_1}
  - {area_Y} says: {choice_2}
  
  Resolution options:
  1. Change {area_X} to match {area_Y}
  2. Change {area_Y} to match {area_X}
  3. Keep both (document as known tradeoff)
  4. Revisit both areas with new context
  
  Which option? [1/2/3/4]
  ```
- Resolve ALL conflicts before generating documents. Never generate a PRD with internal contradictions.

---

### Phase 2: Visual Design Companion (Optional)

Trigger on: "dashboard", "UI", "interface", "architecture", "data flow"

Generate HTML mockups (Tailwind CSS) or Mermaid diagrams. Save to `docs/design/`.

---

## Mode B: Workshop / Meeting Transcript

### Phase 1: Generate Discussion Guide
Create `docs/prd/workshop/discussion-guide-[slug].md` with all 15 areas, role-tagged.
Each section: "Directed at: [Primary]", 3-5 discussion questions, facilitator tips.

### Phase 2: Transcript Upload
User uploads transcript. Validate content.

### Phase 3: Transcript Processing
Map to 15 areas. Capture quotes. Attribute to speakers. Flag missing perspectives.

### Phase 3.5: Architecture Synthesis (Plan Sub-Agent)

Same as Mode A Phase 1.5 — spawn Plan sub-agent to check consistency across all 15 areas
extracted from the transcript. Present conflicts to developer for resolution before generating
output documents. See Mode A Phase 1.5 for the full brief and conflict resolution flow.

---

## Output Generation (Both Modes)

### Documents Created

1. **PRD** → `docs/prd/[slug].md`
2. **Feature Breakdown** → `docs/prd/[slug]-breakdown.md`
3. **Technical PRD** → `docs/prd/[slug]-technical.md` (optional, gate below)

### PRD Required Sections
- Executive Summary, Problem Statement, Vision & Success Criteria
- User Stories, Scope (v1 vs v2), Intel Technology Stack
- Technical Approach, Deployment Architecture, Optimization Strategy
- Non-Functional Requirements, Security Considerations
- Testing Strategy, Risks & Mitigations, Dependencies & Blockers
- Timeline & Resources, Success Metrics, Open Questions

### Feature Breakdown Structure
- Epics (5-6): Foundation, Data Pipeline, Business Logic, UI, Integration, Testing/Ops
- Each Epic: Priority, Stories (As a/I want/So that + Acceptance Criteria), Tasks
- Implementation Phases, Critical Path, Resource Allocation

### Handoff Metadata Block

Every PRD MUST end with a machine-readable handoff block for dev-agent consumption:

```yaml
---
# Dev-Agent Handoff Metadata
handoff:
  project_name: "{Feature Name}"
  project_slug: "{feature-slug}"
  components:
    - name: "{component-1}"
      type: "backend"  # backend | frontend | agent | inference | worker
      port: 8000
    - name: "{component-2}"
      type: "frontend"
      port: 5173
  container_base_image: "python:3.11-slim"
  helm_required: true
  observability: "full"  # full | basic | none
  auth: "keycloak"       # keycloak | api-key | none
  security_classification: "internal"  # public | internal | confidential | restricted
  database: "postgresql"  # postgresql | none
  cache: "redis"          # redis | none
  ai_components:
    llm: true              # LiteLLM routing needed
    agents: true           # LangGraph agents needed
    inference: false       # Custom model inference (OpenVINO/IPEX)
    vector_db: true        # Vector database needed
  inference_strategy:
    strategy: "enterprise-inference"  # enterprise-inference | direct-vllm
    ei_auth: "litellm-gateway"       # litellm-gateway | apisix-keycloak (EI only)
    ei_topology: "remote"            # co-located | remote (EI only)
    model_name: "meta-llama/Llama-3.1-8B-Instruct"
  standards_applied:
    - coding-standards
    - security-practices
    - testing-standards
    - container-standards
    - helm-standards
    - observability-standards
    - ci-cd-standards
    - opensource-compliance
---
```

---

## Technical PRD Gate

After generating PRD + Breakdown, ALWAYS present:

```
Would you like a Technical PRD with detailed code snippets and implementation steps?
This can be used by /dev-agent as a development basepoint.

1. Yes — Generate Technical PRD
2. No — Basic PRD is sufficient
3. Later — I'll ask for it when needed
```

### Technical PRD Required Sections
- **Solution Architecture Diagram (Mermaid — MANDATORY)** — see below
- Working code snippets (FastAPI, Docker, K8s, Helm)
- Security implementation patterns (Keycloak JWT, RBAC)
- Testing examples (pytest fixtures, parametrized)
- Deployment configurations (Dockerfile, Helm values, docker-compose)
- Approved/Prohibited Libraries table
- Handoff metadata block (same as PRD)

### Solution Architecture Diagram (Mermaid — MANDATORY in Technical PRD)

The Technical PRD MUST include a Mermaid `flowchart` diagram showing the solution
architecture. This diagram travels with the PRD and serves as the initial blueprint
that the dev-agent implements. It will later be replaced by an industry-standard SVG
generated from the actual code at the compliance phase.

**Required elements in the diagram:**
1. All runtime components (backend, frontend, workers, inference, DB, cache, storage)
2. Data flow direction (arrows with labels showing what data moves)
3. External dependencies clearly marked (Enterprise Inference, Keycloak, etc.)
4. Port numbers on each component
5. Trust boundaries (subgraphs separating internal vs external)
6. AI/inference call paths highlighted

**Template:**
```mermaid
flowchart TD
    subgraph External["External Services"]
        EI["Enterprise Inference\n(OpenAI-compat API)"]
        KC["Keycloak\n(Auth/OIDC)"]
    end

    subgraph App["Application Cluster"]
        FE["Frontend\nReact + Vite\n:5173"]
        API["FastAPI Backend\n:8000"]
        WK["Workers\n(Celery/ARQ)"]
        DB[(PostgreSQL\n:5432)]
        CACHE[(Redis\n:6379)]
        STORE[(MinIO/S3\nFile Storage)]
    end

    FE -->|"REST /api/v1/*"| API
    API -->|"async tasks"| WK
    API --> DB
    API --> CACHE
    WK --> STORE
    WK -->|"LLM inference"| EI
    API -->|"JWT validation"| KC

    style External fill:#f0f0f0,stroke:#999
    style App fill:#e8f4fd,stroke:#003580
    style EI fill:#003580,color:#fff
    style KC fill:#6c757d,color:#fff
```

**Customize this template based on the PRD:**
- If no workers → remove WK, inline processing in API
- If RAG → add Vector DB component and retrieval flow arrows
- If Agentic → add Agent Orchestrator with sub-agent nodes
- If direct vLLM → replace EI with "vLLM Server (self-hosted)"
- If no auth → remove KC

This diagram MUST be in `docs/prd/{slug}-technical.md` under a `## Solution Architecture` heading.

---

## Auto Wiki Publish

After document generation, present using the structured decision format:

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📋 CONTEXT: PRD generation complete
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
• PRD created: docs/prd/[slug].md
• Feature Breakdown: docs/prd/[slug]-breakdown.md
• Technical PRD: docs/prd/[slug]-technical.md (if generated)

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🎯 NEXT STEP: Publish PRD to Confluence
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Creates/updates a Confluence page in space datacenterai
with the full PRD content, preserving formatting.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🔀 YOUR OPTIONS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
1. Publish to Wiki (space: datacenterai)
2. Preview only (dry-run — shows what would be published)
3. Skip — I'll publish later
4. Customize — publish to a different Wiki space
```

If user selects publish:
```bash
python scripts/publish-to-wiki.py docs/prd/[slug].md --space datacenterai
```

---

## Auto Jira Export

After Wiki publish (or skip), present:

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📋 CONTEXT: Wiki publish complete (or skipped)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
• Feature Breakdown ready: docs/prd/[slug]-breakdown.md
• Contains: {N} EPICs, {M} Stories with acceptance criteria

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🎯 NEXT STEP: Export Feature Breakdown to Jira
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Creates EPICs and Stories in Jira project DCAIDSE8.
Each story includes acceptance criteria and effort estimates.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🔀 YOUR OPTIONS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
1. Dry-run first (preview EPICs and Stories without creating)
2. Export to Jira project DCAIDSE8
3. Skip — I'll export later
4. Customize — export to a different Jira project
```

Commands:
```bash
python scripts/export-to-jira.py --dry-run docs/prd/[slug]-breakdown.md
python scripts/export-to-jira.py --project DCAIDSE8 docs/prd/[slug]-breakdown.md
```

The export creates:
- 1 EPIC per Epic in the breakdown
- Stories linked to their parent EPIC
- Acceptance criteria in story description
- Effort estimates in story points
- Dependencies linked between stories

---

## Standards Enforcement

Before generating code snippets in Technical PRDs:
1. Read `.claude/shared/standards/coding-standards.md`
2. Read `.claude/shared/standards/security-practices.md`
3. Apply: type hints, async patterns, Pydantic models, FastAPI
4. Never use prohibited libraries

All code: Python 3.11+, type hints, async/await, Pydantic v2, FastAPI.

---

## Critical Rules

### Socratic Method (Mode A)
- ONE question at a time — never batch
- Build on previous answers
- MCQ preferred with "Other" option
- Clarify ambiguity immediately

### Transcript Processing (Mode B)
- Extract, Don't Invent — only info from transcript
- Mark gaps: "[Not discussed in meeting]"
- Capture direct quotes for key decisions
- Flag missing roles: "[Developer perspective not captured]"

### Hard Gates (Both Modes)
- Must cover all 15 areas (or mark gaps)
- No assuming answers
- v1 vs v2 scope must be explicit
- Security Considerations mandatory
- Deployment Architecture mandatory
- Technical PRDs must include Approved/Prohibited Libraries table
- Handoff metadata block required on every PRD

### Intel Branding
- **OpenVINO** (not openvino), **Intel Xeon** (not xeon)
- Always reference "Intel AI technologies"
- Include hardware specs when known
- Call out Intel-specific optimizations (VNNI, AMX, XMX, INT8)

### Feature Slug Format
- kebab-case, descriptive, <40 chars
- Good: `ipex-llm-integration`, `multi-agent-router`
- Bad: `feature1`, `the-new-thing`

---

## Files Created

```
docs/prd/
  workshop/discussion-guide-[slug].md   # Mode B only
  [slug].md                              # PRD (both modes)
  [slug]-breakdown.md                    # Feature Breakdown (both modes)
  [slug]-technical.md                    # Technical PRD (optional)
docs/design/
  [slug]-visuals/                        # Optional mockups/diagrams
```

---

## Post-Generation Flow

```
PRD + Breakdown generated
    ↓
Technical PRD Gate → (Yes → generate technical PRD)
    ↓
Program Checkpoints (MANDATORY — see below)
    ↓
Phase Transition: "PRD complete! Next step: run /dev-agent to generate the project."
```

---

## Program Checkpoints (MANDATORY)

**After PRD generation completes, you MUST present the Program Checkpoints gate.**

Follow `.claude/shared/ux/program-checkpoints.md` exactly. Present ALL 3 checkpoints together:

1. **Wiki** — Publish PRD + Feature Breakdown to Confluence (space datacenterai)
2. **Jira** — Create EPICs and Stories from Feature Breakdown (dry-run first recommended)
3. **Git** — Commit `docs/prd/` files, push to feature branch

**Commit message:**
```
feat(prd): Add PRD for {project_name}

- Technical PRD: docs/prd/{slug}-technical.md
- Feature Breakdown: docs/prd/{slug}-breakdown.md
- {epic_count} epics, {story_count} stories defined
```

**After checkpoints are processed:** Save project state to Claude memory automatically (see program-checkpoints.md § Memory Save).

---

## Integration with Pipeline

- **Upstream**: User idea or meeting transcript
- **Downstream**: `/dev-agent` reads Technical PRD + handoff metadata
- **Artifacts**: Wiki page (Confluence), Jira EPICs/Stories, PRD documents in `docs/prd/`

---

## References

**OPEA Enterprise Platform**:
- Enterprise RAG: https://github.com/opea-project/Enterprise-RAG
- Enterprise Inference: https://github.com/opea-project/Enterprise-Inference

**Internal Standards**:
- `.claude/shared/standards/coding-standards.md`
- `.claude/shared/standards/security-practices.md`
- `.claude/shared/standards/testing-standards.md`
- `.claude/shared/standards/project-structure.md`
- `.claude/shared/standards/performance-optimization.md`
- `.claude/shared/standards/tech-stack.md`
