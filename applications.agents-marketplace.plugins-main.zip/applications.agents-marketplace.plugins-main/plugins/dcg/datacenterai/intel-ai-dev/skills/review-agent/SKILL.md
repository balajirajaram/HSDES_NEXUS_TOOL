---
name: review-agent
description: Multi-dimensional code review against Intel enterprise standards (contract rules C1-C14, security practices, architecture, frontend-backend contracts). Use this skill whenever the user mentions review, code review, PR review, quality check, audit code, references a PR URL, asks "is this production-ready", or wants a second opinion on generated code. Delegates broad code-quality review to the official code-review plugin, then layers Intel-specific contract and standards checks on top. Produces structured report with confidence scores and safe auto-fix. Always runs Phase 0 environment check first.
---

# Intel AI Review Agent — Multi-Dimensional Code Review

> **UX Reference**: Follow `.claude/shared/ux/human-in-the-loop.md` for ALL user prompts.

Reviews code against Intel enterprise standards. Delegates general code-quality review
to the official `code-review` plugin (5 parallel Sonnet agents with confidence scoring),
then adds Intel-specific dimensions: contract rules C1-C14, Intel security practices,
Enterprise-Inference patterns, and frontend-backend integration verification.

## Model
opus

## Trigger
When user says: "review", "review agent", "code review", "review this PR",
"review the generated code", "check quality", or references a PR URL.

---

## Phase 0: Plugin & Environment Check

Before starting review, check which skills/plugins are available by looking at the
skills list provided in the system context. Do NOT use `claude plugin list` bash
commands — the skills are already visible to you in the conversation.

**Check for these skills (by name in the available-skills list):**
- `code-review:code-review` — General code-quality review (5 parallel agents)
- `playwright` tools (`mcp__plugin_playwright_*`) — Frontend visual verification
- GitHub tools (`gh` CLI) — PR comment posting

**Degradation if missing:**
- No code-review → run review dimensions sequentially in this skill instead of delegating
- No playwright → Frontend visual verification skipped (use static analysis only)
- No github → PR comments posted manually

**Also check dev tools:**
- `python -m ruff --version` — Python linting
- `python -m mypy --version` — Type checking
- `python -m bandit --version` — Security scanning

Proceed regardless — all reviews can function without plugins, just at lower automation.

---

## Phase 0.5: Scope Detection

First, check for `.iteration-state.json` in the working directory or a known project path.
If found and `phases.compliance.status` is "completed", auto-detect the project directory
and skip the scope question — review the entire generated project (option 3).

If no iteration state found, ask:

```
What would you like me to review?

1. Current branch changes (git diff against main/master)
2. A specific PR (paste URL or PR number)
3. A generated project directory (from /dev-agent output)
4. Specific files (paste paths)

[1/2/3/4]
```

Based on selection, gather the diff or file set to review.

---

## Phase 1: Delegated General Review (code-review plugin)

**If `code-review` plugin is available:**

Delegate the broad review pass to the official plugin. It runs 5 parallel Sonnet sub-agents
that cover general code quality faster and more reliably than reinventing the wheel:
CLAUDE.md compliance, bug detection, historical context, PR history, and code comments.

```
/code-review {scope-from-Phase-0.5}
```

Capture its output. Do NOT duplicate its findings — they're already authoritative for
general code-quality issues. Your job is to layer Intel-specific checks on top.

**If `code-review` plugin is NOT available:**

Run the review dimensions in this skill sequentially (slower, but complete). The
dimensions below cover what the plugin would have caught.

---

## Phase 2: Intel-Specific Review (always runs, plugin or not)

These dimensions are NOT covered by the code-review plugin and MUST run regardless.

### 2.1 Contract Compliance — C1 through C14 (CRITICAL)

Check ALL 14 contract rules from the dev-agent. These are Intel-specific and unique
to the Enterprise-Inference pattern. The dev-agent enforces them at generation time;
this skill verifies they're still intact post-edit.

| Rule | Check | Severity |
|------|-------|----------|
| C1 | List endpoints return `{items, total, page, size}` | CRITICAL |
| C2 | All entity responses have `id: UUID` (not prefixed) | CRITICAL |
| C3 | Auth contract matches template (token shape, user model) | CRITICAL |
| C4 | Frontend types extend `BaseEntity` from `@/types/common` | HIGH |
| C5 | API paths follow `/api/v1/{resource}` convention | HIGH |
| C6 | SQLAlchemy columns use `snake_case` | MEDIUM |
| C7 | Task queue has dev-mode inline fallback | HIGH |
| C8 | Database uses SQLite in dev, PostgreSQL in prod | HIGH |
| C9 | Frontend field names EXACTLY match backend schemas | CRITICAL |
| C10 | Every endpoint in router is implemented (no phantoms) | CRITICAL |
| C11 | Dev-mode exercises production code paths (no mocks) | HIGH |
| C12 | Download & report endpoints included if PRD requires | MEDIUM |
| C13 | Deterministic output (same PRD = same product) | LOW |
| C14 | No orphan code — every file reachable from entrypoint | HIGH |

**How to check each:**
- C1: grep for list endpoints, verify response model is `PaginatedResponse[T]`
- C2: grep for `*Read` schemas, verify `id: UUID` field exists (not `{resource}_id`)
- C3: read auth endpoints and security modules, compare against template contract
- C4: read frontend `types/index.ts`, verify `extends BaseEntity`
- C5: read router registrations, verify path pattern
- C6: read SQLAlchemy models, check column naming
- C7: check if celery/task code has `settings.dev_mode` inline path
- C8: read config, verify `DATABASE_URL` switches between sqlite/postgres
- C9: compare frontend type fields against backend schema fields (exact match)
- C10: compare registered routes vs implemented endpoint functions
- C11: check service layer for mock/stub usage in dev mode
- C12: grep for download/report endpoints if PRD mentions exports
- C13: check for randomness sources, timestamps in generated names
- C14: trace import graph from `app/main.py` — flag unreachable files

### 2.2 Intel Security Practices

Beyond what the code-review plugin catches, verify Intel-specific requirements
from `.claude/shared/standards/security-practices.md`:

- **Intel API keys / Ocp-Apim-Subscription-Key** — never hardcoded, always via env var
- **Enterprise-Inference TLS** — verify EI client uses TLS, never plain HTTP for prod
- **Intel proxy compliance** — outbound calls respect `http_proxy` / `https_proxy` env vars
- **Hardcoded IPs** — flag any non-loopback, non-private IP in code
- **Container security** — uid=1000 non-root, no privileged, HEALTHCHECK present
- **NetworkPolicy** — zero-trust ingress/egress in helm/templates/networkpolicy.yaml
- **CORS** — restricted origins, never `*` in production config
- **Rate limiting** — slowapi middleware present per security-practices.md

### 2.3 Intel Standards Compliance

Check against ALL standards in `.claude/shared/standards/` (13 standards):

- `coding-standards.md`, `tech-stack.md`, `testing-standards.md`
- `observability-standards.md`, `helm-standards.md`, `container-standards.md`
- `ci-cd-standards.md`, `opensource-compliance.md`, `performance-optimization.md`
- `project-structure.md`, `ux-design-system.md`, `validation-checklist.md`, `security-practices.md`

For each standard, run the validation checks documented inside it. Standards are the
source of truth — if a standard says "must use structlog", that's the rule.

### 2.4 Frontend-Backend Integration Boundary

Specifically verify the boundary between frontend and backend (this is where C9, C10
violations live in practice):

- Every frontend API hook calls a registered backend endpoint
- Response types in frontend match response schemas in backend (field-by-field)
- Error handling in frontend covers all backend error response shapes
- Auth flow: token storage → header injection → refresh → retry
- Pagination: frontend passes `page`/`size`, backend returns `items`/`total`
- File upload: multipart handling matches backend expectation

### 2.5 Frontend Visual Verification (if playwright plugin available)

Use the playwright plugin per `.claude/shared/ux/playwright-usage.md` Phase 1.4:
- Screenshot every unique route
- Check for layout breakage
- Accessibility quick-check
- No "undefined" / "null" / "[object Object]" in visible text

---

## Phase 3: Merge & Prioritize

After all sub-agents return (delegated + Intel-specific), merge findings:

**EXTENDED REASONING — Finding Synthesis**

Reason deeply about the combined findings:

1. Are there PATTERNS across findings? (e.g., multiple C9 violations suggest a systematic
   issue with how types were generated, not individual typos)
2. Which findings would cause RUNTIME failures vs. which are style issues?
3. Are any findings FALSE POSITIVES? (e.g., a "missing endpoint" that's intentionally
   excluded per PRD scope)
4. What's the MINIMUM fix set that makes this code production-ready?

### Severity Classification

| Level | Meaning | Action |
|-------|---------|--------|
| CRITICAL | Will crash at runtime or create security vulnerability | MUST fix before merge |
| HIGH | Will cause incorrect behavior or violates Intel mandate | Should fix before merge |
| MEDIUM | Code quality issue, maintenance burden | Fix in follow-up |
| LOW | Style preference, minor improvement | Optional |

### Confidence Scoring Algorithm

Each finding gets a confidence score based on HOW it was detected:

| Detection Method | Score | Example |
|-----------------|-------|---------|
| code-review plugin output | 95-100% | Plugin sub-agent matched |
| Automated tool output (bandit, ruff, mypy) | 95-100% | Tool rule matched |
| Programmatic check (grep pattern + validation) | 90-95% | Field name comparison script |
| Structural analysis (import tracing, route matching) | 85-90% | Orphan file detection |
| Code reading with strong evidence | 80-85% | Missing error handling in visible path |
| Pattern inference (likely issue from similar code) | 60-79% | Probable race condition |
| Heuristic flagging (may be intentional) | <60% | Unusual but valid pattern |

**Scoring rules:**
- If a tool/script/plugin confirms it → 95%+
- If you can show the exact line and explain why it's wrong → 85%+
- If it depends on runtime behavior you can't verify → 70%
- If it could be intentional design → <60%, mark as "needs human judgment"

### Severity Escalation

Aggregate risk assessment:
- 3+ HIGH findings in same module → escalate module to CRITICAL
- 5+ MEDIUM findings of same type → escalate pattern to HIGH
- Any CRITICAL finding → overall verdict becomes REQUEST CHANGES
- All findings MEDIUM or below → verdict is APPROVE with notes

---

## Phase 4: Report Generation

### Output Format

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
INTEL CODE REVIEW — {project_name}
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Overall Score: {score}/100
Verdict: {APPROVE | REQUEST CHANGES | NEEDS DISCUSSION}

Plugin delegation: {used / fallback to sequential}
Dimensions covered: {N/5}

━━━ CRITICAL ({N} findings) ━━━━━━━━━━━━━━━━━━━━━━━━

[C9] Frontend type mismatch — confidence: 98%
  File: frontend/src/features/jobs/types/index.ts:5
  Issue: Field `job_status` doesn't match backend's `status`
  Fix: Rename to `status` to match JobRead schema
  Backend: src/backend/app/models/schemas.py:42 → `status: str`

[C10] Phantom endpoint — confidence: 95%
  File: src/backend/app/api/v1/router.py:12
  Issue: Route `/api/v1/reports` registered but handler not implemented
  Fix: Implement handler or remove route registration

━━━ HIGH ({N} findings) ━━━━━━━━━━━━━━━━━━━━━━━━━━━━

[SEC] Missing rate limiting — confidence: 90%
  File: src/backend/app/main.py
  Issue: No slowapi middleware configured
  Fix: Add SlowAPI with per-IP limits per security-practices.md
  Standard: .claude/shared/standards/security-practices.md:38

[C14] Orphan file — confidence: 92%
  File: src/backend/app/services/legacy_processor.py
  Issue: Not imported by any module, unreachable from app.main
  Fix: Delete or wire into service layer

━━━ MEDIUM ({N} findings) ━━━━━━━━━━━━━━━━━━━━━━━━━━

[STD] Missing structured logging — confidence: 85%
  File: src/backend/app/services/inference_service.py:23
  Issue: Uses print() instead of structlog
  Fix: Replace with `logger.info("inference_complete", model=model, latency_ms=elapsed)`

━━━ LOW ({N} findings) ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

[STD] Missing type annotation — confidence: 80%
  File: src/backend/app/utils/helpers.py:15
  Issue: Function `format_size` missing return type
  Fix: Add `-> str` return annotation

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
SUMMARY
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Contract rules: {passed}/14 ({percentage}%)
Security: {passed}/{total} checks clear
Standards: {compliance_percentage}% compliant
Architecture: {quality_score}/10

Estimated fix effort: {time_estimate}
Blocking issues: {N} (must fix before merge)
```

### Save Report

Save to `reports/review/review-{date}-{short_hash}.md`

---

## Phase 5: Developer Interaction

After presenting the report:

```
Review complete. {N} critical + {M} high findings.

Options:
1. Auto-fix all — I'll fix critical + high issues now
2. Fix critical only — address blockers, leave high for follow-up
3. Discuss findings — walk through specific items
4. Export report — save and handle manually
5. Re-review after fixes — run again on updated code

[1/2/3/4/5]
```

### Auto-Fix Mode (Safe)

If developer chooses option 1 or 2:

**Safety protocol — every fix goes through verification:**

1. Fix findings in severity order (critical first)
2. For each fix:
   a. Show before/after diff to developer
   b. Re-run the SPECIFIC check that caught the issue
   c. If check now passes → proceed to next finding
   d. If check still fails → revert fix, report "unable to auto-fix", move to next
   e. Run `python3 -c "import app.main"` after each fix to verify no new import errors
3. After ALL fixes applied, run a FULL re-check of all original findings
4. If any NEW findings appeared (regression), revert the fix that caused it and report
5. Present summary of changes made vs. findings that need manual attention

**Never auto-fix:**
- Security issues that require architectural changes (e.g., adding auth to an endpoint)
- Business logic issues (e.g., wrong calculation)
- Findings with confidence < 80% (might be false positives)

These are flagged as "Manual Fix Required" with explanation.

### False Positive Handling

Developer can mark any finding as false positive:
```
Mark as false positive? Provide reason:
> [developer types reason]
```

False positives are recorded in `.review-suppressions.json`:
```json
{
  "suppressions": [
    {"rule": "C9", "file": "types/index.ts", "reason": "Intentional rename for UI clarity", "date": "2026-05-13"}
  ]
}
```

On subsequent reviews, suppressed findings are shown as "[SUPPRESSED]" and don't count toward verdict.

---

## Phase 6: Update Iteration State & Program Checkpoints

### Step 1: Update Iteration State

Update `.iteration-state.json` — add/update the CANONICAL `phases.review` key:

```json
{
  "phases": {
    "review": {
      "status": "completed",
      "completed_at": "2026-05-14T15:00:00Z",
      "iteration": 1,
      "report_path": "reports/review/review-2026-05-14.md",
      "notes": "Score: 85/100, verdict: APPROVE, 0 critical, 2 high"
    }
  }
}
```

Do NOT remove existing keys (dev-agent sub-phases, integrations, etc.).

### Step 2: Program Checkpoints

Follow `.claude/shared/ux/program-checkpoints.md`:

1. **Wiki** — Publish review report to Confluence (space datacenterai)
2. **Jira** — Update relevant story/task with review status
3. **Git** — Commit fixes (if any) to feature branch

---

## Integration with Other Agents

| Trigger | Behavior |
|---------|----------|
| After `/dev-agent` Phase 4.6 | Auto-suggest: "Run /review-agent for full review?" |
| After `/validation-agent` | Include test coverage in review context |
| After `/compliance-agent` | Cross-reference security findings |
| PR created via `github` plugin | Can auto-trigger on PR events |

---

## Plugin Usage

This agent leverages installed plugins:

- **code-review plugin** (PRIMARY): General code-quality review delegated to its 5 parallel agents. This skill layers Intel-specific checks on top — never duplicates the plugin's work.
- **playwright plugin**: Phase 2.5 frontend visual verification per `.claude/shared/ux/playwright-usage.md`
- **github plugin**: PR comment posting, status checks, review submission
- **frontend-design plugin**: Referenced for UX design system compliance checks
- **context7 plugin**: Library version verification during standards compliance check
