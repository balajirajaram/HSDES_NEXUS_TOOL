# OSPDT Presentation Sections

## Slide 1: Title
- Project name
- Team / organization
- Date of submission
- Version number

## Slide 2: Project Overview
- Brief description (2-3 sentences)
- Business justification
- Target audience / users
- Deployment model (SaaS, on-prem, hybrid)

## Slide 3: Open Source Inventory
Table columns:
| Package | Version | License | Source | Risk Level |
Color coding:
- GREEN: MIT, BSD-2, BSD-3, Apache-2.0, ISC, Unlicense
- YELLOW: MPL-2.0, LGPL-2.1, LGPL-3.0, EPL-2.0
- RED: GPL-2.0, GPL-3.0, AGPL-3.0, SSPL

## Slide 4: License Compliance
- All permissive licenses: APPROVED
- Weak copyleft (LGPL/MPL): Review required — dynamic linking OK, static linking needs review
- Strong copyleft (GPL/AGPL): BLOCKED for proprietary distribution
- License compatibility matrix summary

## Slide 5: Security Assessment
- SAST results (Bandit findings summary)
- Container scan results (Trivy HIGH/CRITICAL)
- Dependency audit results (pip-audit / npm audit)
- Secret scan results (detect-secrets)
- SBOM generated: Yes/No (CycloneDX format)

## Slide 6: Risk Assessment
- Overall risk level: LOW / MEDIUM / HIGH
- Open HIGH/CRITICAL CVEs: count and list
- License risk: count of non-permissive packages
- Mitigation plan for each risk item
- Recommendation: APPROVE / CONDITIONAL / REJECT
