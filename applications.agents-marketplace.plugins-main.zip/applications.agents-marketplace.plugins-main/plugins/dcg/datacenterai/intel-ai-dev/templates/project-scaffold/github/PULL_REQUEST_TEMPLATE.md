## Summary
<!-- What does this PR do? -->

## Changes
- 

## Checklist
- [ ] Tests added/updated
- [ ] Documentation updated
- [ ] No breaking changes (or documented below)
- [ ] Security: no hardcoded secrets, no new vulnerabilities
- [ ] Lint passes (`ruff check`, `mypy --strict`)

## Breaking Changes
<!-- If any, describe migration steps -->
None
