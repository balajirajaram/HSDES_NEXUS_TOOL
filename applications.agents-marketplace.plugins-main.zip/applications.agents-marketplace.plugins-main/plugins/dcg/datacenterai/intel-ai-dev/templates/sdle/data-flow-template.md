# Data Flow Diagram — {project_name}

## Level 0 — Context

```mermaid
graph LR
    User((User)) -->|HTTPS Request| System["{project_name}"]
    System -->|HTTPS Response| User
    System -->|Query| DB[(Database)]
    System -->|Inference| LLM[LLM Provider]
    System -->|Publish| Wiki[Confluence]
    System -->|Update| Jira[Jira]
```

## Level 1 — Application Components

```mermaid
graph TB
    subgraph Frontend
        UI[React SPA]
    end

    subgraph API Gateway
        Ingress[K8s Ingress]
    end

    subgraph Backend Services
        Auth[Auth Middleware]
        Router[API Router v1]
        Service[Business Logic]
        Agent[AI Agent]
    end

    subgraph Data Stores
        PG[(PostgreSQL)]
        Redis[(Redis Cache)]
        S3[(Object Store)]
    end

    subgraph External
        KC[Keycloak]
        LLM[LLM Endpoint]
        VDB[(Vector DB)]
    end

    UI -->|REST API| Ingress
    Ingress -->|Forward| Auth
    Auth -->|JWT Verify| KC
    Auth -->|Authenticated| Router
    Router --> Service
    Service --> PG
    Service --> Redis
    Service --> S3
    Service --> Agent
    Agent --> LLM
    Agent --> VDB
```

## Data Flows

| # | Source | Destination | Data | Protocol | Auth | Encrypted |
|---|--------|-------------|------|----------|------|-----------|
| 1 | User | Frontend | UI assets | HTTPS | None | Yes (TLS) |
| 2 | Frontend | API | REST requests | HTTPS | Bearer JWT | Yes (TLS) |
| 3 | API | Keycloak | JWKS fetch | HTTPS | None | Yes (TLS) |
| 4 | API | PostgreSQL | SQL queries | TCP:5432 | Password | Yes (TLS) |
| 5 | API | Redis | Cache ops | TCP:6379 | Password | Yes (TLS) |
| 6 | Agent | LLM | Inference | HTTPS | API Key | Yes (TLS) |
| 7 | Agent | Vector DB | Embeddings | TCP | API Key | Yes (TLS) |

## Encryption at Rest
- PostgreSQL: TDE enabled
- Object Storage: AES-256 server-side encryption
- Redis: AOF/RDB on encrypted volume
- Secrets: Kubernetes Secrets (encrypted etcd)

## Encryption in Transit
- All external: TLS 1.3 minimum
- All internal K8s: mTLS via service mesh (optional) or NetworkPolicy enforcement
- Database connections: SSL required (`sslmode=require`)
