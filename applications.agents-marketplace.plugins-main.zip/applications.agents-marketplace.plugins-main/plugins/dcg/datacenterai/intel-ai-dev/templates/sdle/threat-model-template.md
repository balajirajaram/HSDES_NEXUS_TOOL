# Threat Model — {project_name}

## System Overview

```mermaid
graph TB
    subgraph External
        User[End User / Browser]
        Admin[Admin User]
        CI[CI/CD Pipeline]
    end

    subgraph DMZ
        LB[Load Balancer / Ingress]
        WAF[Web Application Firewall]
    end

    subgraph Application Tier
        FE[Frontend - React SPA]
        API[Backend API - FastAPI]
        Auth[Keycloak - Auth Service]
    end

    subgraph Data Tier
        DB[(PostgreSQL)]
        Cache[(Redis)]
        Store[(Object Storage)]
    end

    subgraph AI Tier
        LLM[LLM Service - vLLM/LiteLLM]
        Agent[LangGraph Agents]
        Vector[(Vector DB)]
    end

    User -->|HTTPS| LB
    Admin -->|HTTPS| LB
    LB --> WAF --> FE
    FE -->|REST/WebSocket| API
    API -->|JWT Verify| Auth
    API --> DB
    API --> Cache
    API --> Store
    API --> Agent
    Agent --> LLM
    Agent --> Vector
    CI -->|Deploy| API
```

## Trust Boundaries
1. **External → DMZ**: All traffic over TLS, rate-limited
2. **DMZ → Application**: Authenticated requests only (JWT)
3. **Application → Data**: Service accounts, encrypted connections
4. **Application → AI**: Internal network only, token budget limits

## STRIDE Analysis

| Threat | Category | Component | Mitigation |
|--------|----------|-----------|------------|
| Token theft | Spoofing | Auth | Short-lived JWTs, refresh rotation |
| Parameter tampering | Tampering | API | Pydantic validation, parameterized queries |
| Log injection | Repudiation | Logging | structlog sanitization, correlation IDs |
| PII exposure | Info Disclosure | API/DB | Field-level encryption, RBAC |
| LLM abuse | DoS | AI Tier | Rate limiting, token budgets |
| Prompt injection | Elevation | Agent | Input sanitization, output validation |

## Data Classification
- **PUBLIC**: API docs, health endpoints
- **INTERNAL**: Application logs, metrics
- **CONFIDENTIAL**: User data, API keys, model weights
- **RESTRICTED**: Auth tokens, database credentials
