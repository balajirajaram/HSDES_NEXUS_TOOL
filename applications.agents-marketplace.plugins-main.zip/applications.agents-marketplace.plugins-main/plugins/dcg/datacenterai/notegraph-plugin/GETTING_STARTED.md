# NoteGraph — AI-Powered Knowledge Wiki Builder

**Transform distributed documentation into an AI-maintained, cross-linked knowledge wiki.**

---

## What is NoteGraph?

NoteGraph turns scattered documentation into a structured, cross-linked knowledge wiki automatically. It solves the documentation problems every engineering team faces:

| Current State | With NoteGraph |
|---------------|----------------|
| 3-4 week onboarding cycles | Accelerated onboarding through day-one wiki access |
| Knowledge siloed in individual expertise | Centralized, searchable knowledge base |
| Documentation degradation over time | Automated health monitoring flags outdated content |
| Limited search effectiveness | Categorized index with semantic navigation |
| Redundant content across sources | Unified reference with cross-linking |

---

## Quick Start (5 Minutes)

### Step 1: Install the Plugin

From the marketplace or clone this repo into your AI client's plugins directory.

### Step 2: Initialize Your Wiki

```bash
/notegraph-init
```

This creates `.notegraph/wiki/` in your repo with the proper structure.

### Step 3: Ingest Your Docs

```bash
/notegraph-ingest docs/
```

The AI will:
- Read every document
- Extract key concepts
- Create wiki pages with `[[cross-links]]`
- Build a searchable index

**Time:** ~1-2 minutes for 50 docs

### Step 4: Query Your Wiki

```bash
/notegraph-query "How do I debug PCIe link training failures?"
```

Get AI-synthesized answers with citations back to concept pages.

### Step 5: Maintain It

```bash
/notegraph-lint
```

Health check for orphan pages, dead links, stale content.

---

## Real-World Example

**Current Documentation Structure:**
```
Repository:
├── docs/
│   ├── firmware/
│   │   ├── boot-sequence.md          (50+ documents across multiple locations)
│   │   ├── memory-training.md
│   │   └── debug-guide.md
│   └── design-docs/
│       └── memory-spec.pdf
│
└── Typical retrieval workflow:
    → Engineer searches for a past solution or reference
    → Sifts through dozens of files across multiple locations
    → Finds partial answers, misses related context
    → Spends 30+ minutes reconstructing what was already documented
```

**With NoteGraph Integration:**
```
Repository:
├── docs/                              (Source documents remain unchanged)
│   └── firmware/
│
└── .notegraph/wiki/                   (AI-maintained knowledge layer)
    ├── concepts/
    │   ├── memory-training.md         ← Semantically linked to [[FSP]], [[DIMM Config]]
    │   ├── fsp-initialization.md
    │   └── post-codes.md
    ├── index.md                       ← Categorized concept index
    └── log.md                         ← Change audit trail

Retrieval workflow:
    → Engineer queries: "How does memory training work?"
    → Receives synthesized answer with source citations in seconds
    → Navigates related concepts via semantic cross-links
    → Retrieves complete context without searching through scattered files
```

---

## The Four Skills

### 1. `/notegraph-init`
Bootstrap wiki structure. Run once per repo.

### 2. `/notegraph-ingest <path> [--incremental]`
Core workflow. Reads docs, creates concept pages, cross-links everything.

**Use cases:**
- First-time ingestion: `/notegraph-ingest docs/`
- Weekly updates: `/notegraph-ingest docs/ --incremental`
- Add new doc collection: `/notegraph-ingest design-docs/`

### 3. `/notegraph-query "<question>"`
Natural language queries with AI-synthesized answers and citations.

**Examples:**
- "How do I debug X?"
- "What is Y and how does it work?"
- "How does A relate to B?"

### 4. `/notegraph-lint [--fix]`
Health checks. Finds orphans, dead links, stale content, contradictions.

**Run it:**
- Weekly for maintenance
- Before sharing wiki with team
- On CI/CD for automated quality checks

---

## Wiki Architecture

NoteGraph follows the **LLM Wiki pattern** ([Karpathy's original gist](https://gist.github.com/karpathy/442a6bf555914893e9891c11519de94f)):

### Three Layers

1. **Source Documents** (your existing docs)
   - Never modified (read-only)
   - Live wherever they are now

2. **The Wiki** (AI-maintained)
   - Lives in `.notegraph/wiki/`
   - AI creates, updates, cross-links
   - All Markdown with `[[wikilinks]]`

3. **Query Interface**
   - Natural language queries
   - AI synthesizes from multiple concept pages
   - Returns answers with citations

---

## Concept Pages Explained

Every concept gets its own page with:

**Frontmatter:**
```yaml
---
title: Memory Training Flow
tags: [boot, memory, initialization]
sources: [docs/firmware/boot-sequence.md]
related: [[FSP]], [[POST Codes]], [[DIMM Config]]
created: 2026-06-02
last_updated: 2026-06-02
---
```

**Content:**
- Clear explanation
- Key points with specifics
- Concrete examples (code, data, procedures)
- Cross-links to related concepts
- Citations back to source docs

**See example:** [`examples/example-firmware-wiki/concepts/memory-training.md`](examples/example-firmware-wiki/concepts/memory-training.md)

---

## Typical Workflows

### Retrieving Past Knowledge
```bash
# You documented a debug approach months ago — now you need it again
Engineer: /notegraph-query "How do I debug POST code 0x15?"
→ Synthesized answer with source citations in seconds

Engineer: /notegraph-query "What was the workaround for Gen5 link training?"
→ Surfaces the documented solution with related concepts

# No more digging through old docs or asking teammates
```

### Weekly Documentation Maintenance
```bash
# Monday morning
/notegraph-ingest docs/ --incremental
→ Only processes changed files (fast)

/notegraph-lint
→ Checks for orphans, dead links, stale content

# Wiki stays fresh with 5 minutes/week effort
```

### Cross-Team Knowledge Sharing
```bash
# Firmware team has docs in docs/firmware
# Validation team has docs in docs/validation

/notegraph-ingest docs/firmware
/notegraph-ingest docs/validation

# Unified wiki with cross-links between team knowledge
# Validation's "POST Error Triage" links to Firmware's "Boot Flow"
```

---

## Configuration

After `/notegraph-init`, edit `.notegraph/wiki/config.json`:

```json
{
  "rules": {
    "allowOrphans": false,              // Enforce no orphan pages
    "requireExamples": true,             // Require concrete examples
    "requireSourceCitation": true,       // Every concept needs sources
    "staleThresholdMonths": 18           // Flag pages older than this
  },
  "categories": ["Boot", "Memory", ...]  // Auto-populated
}
```

---

## Best Practices

### For Ingestion
✅ Ingest domain-specific docs (firmware, validation, design)  
✅ Run incremental ingests weekly to stay fresh  
✅ Ingest multiple doc collections into one wiki (cross-links emerge!)  
❌ Don't ingest generic docs (READMEs about git, generic how-tos)

### For Queries
✅ Be specific: "How do I debug PCIe Gen5 link training?"  
✅ Ask procedural questions: "What are the steps to..."  
✅ Follow [[cross-links]] to explore related concepts  
❌ Don't ask yes/no questions — ask "how" and "what"

### For Maintenance
✅ Run `/notegraph-lint` weekly  
✅ Fix orphan pages by adding cross-links  
✅ Update stale content when flagged  
✅ Re-ingest if source docs change significantly

---

## FAQ

**Q: Does it modify my source docs?**  
A: No. Source docs are read-only. The wiki lives in `.notegraph/wiki/`.

**Q: What if I have 1000+ docs?**  
A: Ingestion handles large doc sets. Use `--incremental` for updates (only processes changed files).

**Q: Can I edit the concept pages?**  
A: Yes, but they'll be overwritten on re-ingest. Better: fix the source docs, then re-ingest.

**Q: How does it compare to Confluence/Notion?**  
A: This is **AI-maintained** and **Markdown in your repo**. No manual curation. No external tools.

**Q: Can I export to Obsidian?**  
A: Not yet (v1.0 doesn't include export). Coming in v1.1.

**Q: Does it work offline?**  
A: The wiki is just Markdown files. You can browse offline. Queries require the AI client.

---

## Troubleshooting

**Problem:** "No concepts extracted from my docs"  
**Solution:** Check that docs contain substantive technical content (not just TODOs or meeting notes)

**Problem:** "Ingestion is slow"  
**Solution:** Use `--incremental` flag for updates. Only full ingest is slow (first time only).

**Problem:** "Query answers are generic"  
**Solution:** Wiki might not have detailed info on that topic. Ingest more source docs.

**Problem:** "Lint reports false positives"  
**Solution:** Adjust thresholds in `.notegraph/wiki/config.json` (e.g., `staleThresholdMonths`)

---

## Next Steps

1. ✅ Run `/notegraph-init` in your repo
2. ✅ Ingest your first doc collection
3. ✅ Try a few queries to test it
4. ✅ Share with your team
5. ✅ Set up weekly `lint` runs

**Need help?** Open an issue or check the [full README](README.md).

---

**Transform your documentation into an intelligent knowledge system — automatically maintained, semantically linked, and instantly queryable.**
