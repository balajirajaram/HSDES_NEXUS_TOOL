# NoteGraph — AI-Powered Knowledge Wiki Builder

**Transform distributed documentation into an AI-maintained, cross-linked knowledge wiki.**

| Skill | What it does |
|---|---|
| `/notegraph-init` | Bootstrap a new wiki structure in your repository |
| `/notegraph-ingest` | Ingest source documents, extract concepts, generate cross-linked wiki pages |
| `/notegraph-query` | Query the wiki with AI-synthesized answers and `[[citations]]` |
| `/notegraph-lint` | Health check for orphan pages, dead links, stale content, contradictions |

---

## The Challenge

Valuable technical knowledge accumulates across READMEs, design documents, Confluence pages, and internal references — but retrieving the right information when you need it remains a persistent challenge.

- **Information overload** — The knowledge exists, but finding the right document at the right time means sifting through hundreds of files across multiple sources
- **Lost context** — You solved this problem six months ago, documented it somewhere, but can't locate it now — and neither can your teammates
- **Disconnected insights** — Related concepts live in separate documents with no way to trace how they connect
- **Silent degradation** — References break, procedures become outdated, and conflicting information creeps in without anyone noticing
- **Repeated effort** — Teams re-research and re-document the same concepts because existing knowledge is buried too deep to surface

---

## The Solution

NoteGraph provides an AI-powered approach to knowledge management that transforms distributed documentation into a structured, interconnected wiki.

Point NoteGraph at your documentation repository, and the system automatically reads each document, identifies key technical concepts, generates dedicated wiki pages with semantic cross-linking, and maintains a searchable index — all stored as Markdown within your repository, requiring no external infrastructure.

---

## Why It Matters

| Current State | With NoteGraph |
|---------------|----------------|
| Knowledge buried across scattered documents | Structured wiki with instant concept-level retrieval |
| "I documented this somewhere..." | Searchable index — query in natural language, get cited answers |
| Related information lives in separate silos | Semantic `[[cross-links]]` connect concepts automatically |
| Documentation degrades silently over time | Automated health checks flag stale, conflicting, or orphaned content |
| Teams re-research what was already documented | Single source of truth with bidirectional references |

---

## Install

```text
/plugin marketplace add intel-innersource/applications.agents-marketplace.plugins
/plugin install notegraph-plugin@plugins-marketplace
```

Verify:

```text
/plugin
```

You should see `notegraph-plugin@plugins-marketplace ✓ enabled v1.0.0`.

Smoke test in any directory:

```text
/notegraph-init
```

---

## Usage

### Full pipeline (docs → knowledge wiki)

```text
/notegraph-init                        # Bootstrap wiki structure              (~1 min)
/notegraph-ingest docs/firmware        # Ingest docs → concept pages + links   (~5-15 min)
/notegraph-query "your question"       # Query with citations                  (instant)
/notegraph-lint                        # Health check for issues               (~2 min)
```

Each skill announces what it will do before proceeding and summarizes results after completion.

---

### Step 1: Initialize your wiki
```text
/notegraph-init
```

This creates `.notegraph/wiki/` in your repo with:
- `concepts/` — one page per concept
- `sources/` — summaries of source documents
- `index.md` — master catalog
- `log.md` — operations history
- `config.json` — configuration

### Step 2: Ingest your docs
```text
/notegraph-ingest docs/firmware
```

The AI will:
- Read every document in the source directory
- Extract key concepts
- Create wiki pages with `[[cross-links]]`
- Update the index and log

### Step 3: Query your wiki
```text
/notegraph-query "How do I debug PCIe link training failures?"
```

Get synthesized answers with citations back to concept pages.

### Step 4: Maintain your wiki
```text
/notegraph-lint
```

Health check for orphan pages, dead links, stale content, and contradictions.

---

## Skills Reference

### `/notegraph-init [wiki-directory]`
Bootstrap a new NoteGraph wiki structure in your repository.

**What it creates:**
- `.notegraph/wiki/` with proper structure
- Initial `index.md` and `log.md`
- Configuration file
- Template files

**Example:**
```bash
/notegraph-init
# Creates .notegraph/wiki/ with all scaffolding
```

---

### `/notegraph-ingest <source-path> [--incremental]`
Ingest source documents and generate cross-linked wiki pages.

**What it does:**
1. Scans source directory recursively
2. Extracts key concepts from each document
3. Creates individual concept pages with frontmatter
4. Auto-discovers relationships and creates `[[wikilinks]]`
5. Updates `index.md` and `log.md`

**Arguments:**
- `<source-path>` — Directory to ingest (e.g., `docs/firmware`)
- `--incremental` — Only process new/changed files (fast updates)

**Examples:**
```bash
# Full ingest
/notegraph-ingest docs/firmware

# Incremental update (only changed files)
/notegraph-ingest docs/firmware --incremental
```

**Rules:**
- Never modifies source files (read-only)
- Always creates cross-links between related concepts
- No orphan pages — everything links to something
- Updates index and log on every run

---

### `/notegraph-query "<question>"`
Query the wiki with AI-synthesized answers and citations.

**What it does:**
1. Searches the wiki using semantic + keyword matching
2. Synthesizes answer from relevant concept pages
3. Returns answer with `[[concept]]` citations

**Example:**
```bash
/notegraph-query "How do I debug PCIe link training failures?"
```

**Response format:**
```
PCIe link training failures typically stem from three areas:

1. **Signal integrity issues** — Check [[PCIe Eye Diagram]] and [[SI Validation]]
2. **BIOS configuration** — Verify [[PCIe Bifurcation Settings]] and [[Link Speed Config]]
3. **Hardware faults** — See [[RAS Error Logs]] and [[iConsole Debug]]

For Gen5 specifically, refer to [[Gen5 Known Issues]].
Previously documented workaround: force Gen4 mode during initial triage.

📚 Sources: [[PCIe Debug Guide]], [[Link Training State Machine]], [[Common POST Errors]]

💡 Related: [[PCIe Enumeration]], [[IIO Configuration]]
```

---

### `/notegraph-lint [--fix]`
Health check the wiki for orphans, dead links, and stale content.

**What it checks:**
- ❌ **Orphan pages** — concepts with no incoming links
- ❌ **Dead links** — `[[concepts]]` that don't exist
- ❌ **Stale content** — pages not updated in 18+ months
- ❌ **Missing sources** — concepts with no `source:` in frontmatter
- ❌ **Contradictions** — concepts mentioning the same term with conflicting info
- ❌ **Broken file refs** — source docs that no longer exist

**Arguments:**
- `--fix` — Automatically fix issues where possible

**Example output:**
```
🩺 NoteGraph Health Report

❌ 3 orphan pages found:
  - .notegraph/wiki/concepts/old-debug-flow.md (no incoming links)
  
❌ 2 dead links:
  - .notegraph/wiki/concepts/memory-init.md links to [[DIMM Config]] (doesn't exist)
  
⚠️  5 stale pages (18+ months old):
  - .notegraph/wiki/concepts/legacy-boot.md (last updated 2024-01)
  
✅ 42 pages healthy

Suggested actions: [view detailed report]
```

---

## Architecture

NoteGraph follows the **LLM Wiki pattern** pioneered by Andrej Karpathy ([original gist](https://gist.github.com/karpathy/442a6bf555914893e9891c11519de94f)):

### Three Layers

1. **Source Documents** (immutable)
   - Your existing docs in `docs/`, `design-docs/`, etc.
   - NoteGraph reads from them but **never modifies** them

2. **The Wiki** (AI-maintained)
   - Lives in `.notegraph/wiki/`
   - AI fully owns this layer — creates, updates, cross-links
   - All in Markdown with `[[wikilinks]]`

3. **Query Interface**
   - Natural language queries via `/notegraph-query`
   - Returns synthesized answers with citations

---

## Wiki Structure

After running `/notegraph-init`, you'll have:

```
.notegraph/
└── wiki/
    ├── concepts/           # One page per concept
    │   ├── memory-training.md
    │   ├── pcie-debug.md
    │   └── post-codes.md
    ├── sources/            # One summary per source document
    │   ├── boot-sequence-doc.md
    │   └── debug-guide-doc.md
    ├── index.md            # Master catalog (by category)
    ├── log.md              # Operations history
    └── config.json         # Wiki configuration
```

### Concept Page Format

Every concept page has YAML frontmatter:

```yaml
---
title: Memory Training Flow
tags: [boot, memory, initialization]
sources: 
  - docs/firmware/boot-sequence.md
  - docs/design/memory-init-spec.pdf
related: [[FSP]], [[POST Codes]], [[DIMM Init]]
created: 2026-06-01
last_updated: 2026-06-01
---

# Memory Training Flow

Memory training is the process of calibrating DRAM timing parameters during boot...

## Key Steps
1. SPD detection via [[I2C Bus]]
2. Timing parameter calculation
3. Write leveling and read training

## Related Concepts
- [[FSP Initialization]] — calls memory training
- [[POST Code 0x15]] — indicates training failure
- [[DIMM Configuration]] — affects training parameters

## References
- Source: [boot-sequence.md](../../docs/firmware/boot-sequence.md)
```

---

## Use Cases

### Firmware/BIOS Development
- Consolidate boot flows, register specifications, and debug procedures into a unified, queryable knowledge base
- Instantly retrieve past debug approaches: "How did we resolve the Gen5 link training issue last quarter?"

### Validation & Testing
- Unify test procedures, failure analysis workflows, and troubleshooting guides
- Surface related failure patterns across projects: "What are common POST errors and recommended debug procedures?"

### Platform Engineering Teams
- Preserve institutional knowledge as a living, cross-referenced wiki rather than scattered documents
- Reduce time spent re-researching topics that were already documented elsewhere

---

## Target Audiences

- **Individual engineers** — Stop re-searching for information you've already found — query your own knowledge base in seconds
- **Technical leads** — Institutionalize domain expertise so critical knowledge is retained, organized, and accessible to the entire team
- **Documentation owners** — Leverage automated quality checks to maintain documentation integrity at scale
- **Cross-functional teams** — Establish shared technical vocabulary through unified, cross-linked knowledge repositories

---

## Inspiration

NoteGraph is inspired by Andrej Karpathy's **LLM Wiki pattern**:
- [Original gist by @karpathy](https://gist.github.com/karpathy/442a6bf555914893e9891c11519de94f)

The core pattern: **Source documentation → AI concept extraction → Interconnected knowledge graph**

NoteGraph extends this approach for enterprise team environments:
- Domain-agnostic architecture supporting firmware, validation, ML/AI, and general technical documentation
- Incremental processing for efficient updates as documentation evolves
- Automated quality assurance through health checks for orphaned pages, broken links, and conflicting content
- Natural language query interface with citation-backed responses

---

## Contributing

Found a bug? Want a feature? Open an issue or PR!

---

## License

MIT License — see [LICENSE](LICENSE) for details.

---

---

**Transform your documentation into an intelligent knowledge system — automatically maintained, semantically linked, and instantly queryable.**
