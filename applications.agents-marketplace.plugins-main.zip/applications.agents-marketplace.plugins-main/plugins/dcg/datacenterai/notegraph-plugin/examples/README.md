# NoteGraph Examples

This directory contains example wikis demonstrating NoteGraph in action.

## Example: Firmware Knowledge Base

A sample wiki generated from firmware documentation showing:
- Concept pages with cross-links
- Source summaries
- Index organized by category
- Health report from lint

### Structure

```
example-firmware-wiki/
├── concepts/
│   ├── memory-training.md          # Example concept page
│   ├── fsp-initialization.md
│   └── post-codes.md
├── sources/
│   └── boot-sequence-summary.md    # Source document summary
├── index.md                        # Catalog of all concepts
├── log.md                          # Operations history
└── config.json                     # Wiki configuration
```

### How It Was Generated

```bash
# 1. Initialize wiki
/notegraph-init

# 2. Ingest source docs
/notegraph-ingest docs/firmware

# 3. Query example
/notegraph-query "How does memory training work?"

# 4. Health check
/notegraph-lint
```

### Try It Yourself

1. Copy your team's docs to a `source-docs/` folder
2. Run `/notegraph-init`
3. Run `/notegraph-ingest source-docs/`
4. Query away: `/notegraph-query "your question"`

---

## Example Concept Page

See [`example-firmware-wiki/concepts/memory-training.md`](example-firmware-wiki/concepts/memory-training.md) for a real example of a generated concept page with:
- Frontmatter (title, tags, sources, related concepts)
- Clear explanation
- Cross-links to related concepts
- Citations back to source documents

---

## Example Query Response

**Question:** "How do I debug PCIe link training failures?"

**Answer (with citations):**
```
PCIe link training failures typically stem from three areas:

1. **Signal integrity issues** — Check [[PCIe Eye Diagram]] and [[SI Validation]]
2. **BIOS configuration** — Verify [[PCIe Bifurcation Settings]]
3. **Hardware faults** — See [[RAS Error Logs]]

📚 Sources: [[PCIe Debug Guide]], [[Link Training State Machine]]
💡 Related: [[PCIe Enumeration]], [[IIO Configuration]]
```

---

## Example Lint Report

```
🩺 NoteGraph Health Report

Health Score: 84% ████████████░░░░░░░░

❌ Critical (3):
- 2 dead links
- 1 orphan page

⚠️  Warnings (5):
- 5 stale pages (18+ months old)

✅ 42 pages healthy
```

---

*More examples coming soon — contribute yours via PR!*
