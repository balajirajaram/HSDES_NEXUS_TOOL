---
title: Memory Training Flow
tags: [boot, memory, initialization, ddr5]
sources:
  - docs/firmware/boot-sequence.md
  - docs/design/memory-init-spec.pdf
related: [[FSP Initialization]], [[POST Codes]], [[DIMM Configuration]]
created: 2026-06-02
last_updated: 2026-06-02
---

# Memory Training Flow

Memory training is the process of calibrating DRAM timing parameters during platform boot to ensure reliable memory operation across temperature and voltage variations.

## Overview

During the [[FSP Initialization]] phase (specifically FSP-M), the firmware executes a series of training algorithms to optimize signal timing between the memory controller and DIMMs. This process is critical because DDR5 operates at very high speeds (4800+ MT/s) where even picosecond-level timing differences can cause errors.

## Key Steps

- **SPD Detection** — Read DIMM specifications via [[I2C Bus]] to get base timing parameters (CAS latency, tRCD, tRP)
- **Write Leveling** — Align write data strobe (DQS) with clock signal to ensure data is captured correctly
- **Read Training** — Calibrate read data capture timing to find the optimal sampling window
- **Command Training** — Optimize command/address signal timing for maximum margin

## Training Sequence

```
1. SPD Read (I2C @ 100kHz)
   └─> Parse timing tables
   
2. Write Leveling
   └─> Adjust DQS delay per byte lane
   
3. Read Training (per rank, per byte lane)
   ├─> Find left edge of eye
   ├─> Find right edge of eye
   └─> Program center point
   
4. Command/Address Training
   └─> Optimize setup/hold margins
```

## Example Timing Values

After successful training, typical DDR5-4800 settings:

```
CAS Latency (CL):  40 clocks
tRCD:              40 clocks  
tRP:               40 clocks
tRFC (refresh):    295 ns
```

## Failure Scenarios

If training fails, you'll see [[POST Code 0x15]] and boot will halt. Common causes:

- **Incompatible DIMMs** → Check [[DIMM Configuration]] compatibility matrix
- **Thermal issues** → Training parameters shift with temperature
- **Marginal signal integrity** → See [[Memory Signal Integrity]] debug guide
- **BIOS configuration** → Verify SPD timings vs BIOS overrides

## Related Concepts

- [[FSP Initialization]] — Memory training is executed during FSP-M phase
- [[POST Code 0x15]] — Indicates memory training failure
- [[DIMM Configuration]] — Determines which training algorithms run
- [[DDR5 Architecture]] — Underlying memory technology being trained
- [[RMT (Rank Margin Tool)]] — Advanced tool for training diagnostics

## Performance Impact

Memory training typically adds **2-3 seconds** to boot time on a 2-socket server with 16 DIMMs. This can be reduced with:

- **Fast boot mode** — Skip some training on warm boot (risky if voltage/temp changed)
- **Training result caching** — Save parameters in NVRAM (used by [[Memory Fast Boot]])

## References

- Source: [boot-sequence.md](../../docs/firmware/boot-sequence.md)
- Source: [memory-init-spec.pdf](../../docs/design/memory-init-spec.pdf)
- See also: Intel® Xeon® Memory Training Guide (internal)
