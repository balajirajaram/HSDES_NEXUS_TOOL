---
name: notegraph-ingest
description: "Ingest source documents and generate cross-linked wiki pages"
argument-hint: "<source-path> [--incremental]"
---

# Ingest Source Documents

## When to Use

This is the **core workflow** of NoteGraph. Use this skill to:

- Ingest a new set of documents for the first time
- Update the wiki after source documents have changed
- Add new document collections to an existing wiki

**Full ingest** (default): Process all documents in the source path  
**Incremental ingest** (`--incremental`): Only process new/changed files since last run

## What It Does

This skill transforms scattered source documents into a structured, cross-linked knowledge wiki:

1. **Scans** source directory recursively (supports `.md`, `.txt`, `.pdf`, `.rst`, `.adoc`)
2. **Reads** each document fully
3. **Extracts** key concepts from the content
4. **Generates** individual concept pages with frontmatter
5. **Cross-links** concepts using `[[wikilinks]]` for discovered relationships
6. **Updates** `index.md` with new concepts (organized by category)
7. **Logs** the operation to `log.md` with timestamp and details

## Procedure

When the user invokes this skill, follow these steps carefully:

### Step 1: Validate prerequisites
- Check that `.notegraph/wiki/` exists
  - If not: suggest running `/notegraph-init` first
- Check that source path exists and is readable
- Read `.notegraph/wiki/config.json` for settings

### Step 2: Scan source directory
- Recursively find all supported files (`.md`, `.txt`, `.pdf`, `.rst`, `.adoc`)
- If `--incremental` flag is set:
  - Read `.notegraph/wiki/log.md` to find last ingestion timestamp
  - Filter to only files modified after that timestamp
  - Report: "Found X new/changed files since [last run date]"
- Otherwise (full ingest):
  - Process all files
  - Report: "Found X files to ingest"

### Step 3: Read existing wiki state
- Read `.notegraph/wiki/index.md` to get list of existing concepts
- Read existing concept pages to understand what's already documented
- This prevents duplicate concepts with different names

### Step 4: Process each source document

For each source file:

**4a. Read the document**
- Read the full content
- If PDF: extract text content
- Note the file path for citations

**4b. Create source summary page**
- Create a summary page in `.notegraph/wiki/sources/[filename].md`
- Format:
```markdown
---
title: [Document Title]
source: [relative path to source file]
date_ingested: [current date]
concepts_extracted: [[concept1]], [[concept2]], [[concept3]]
---

# [Document Title]

## Summary
[2-3 sentence summary of the document]

## Key Takeaways
- [Bullet point 1]
- [Bullet point 2]
- [Bullet point 3]

## Concepts Covered
- [[Concept 1]] — brief note
- [[Concept 2]] — brief note

## Source
[Relative path to source](../../path/to/source.md)
```

**4c. Extract concepts**
Identify key concepts in the document. A "concept" is:
- A technical term, process, component, or idea
- Something worth explaining on its own page
- Something that might be referenced from other concepts

Examples of concepts:
- "Memory Training Flow"
- "PCIe Link Training"
- "POST Code 0x15"
- "FSP Initialization"

**Do NOT create concepts for:**
- Generic terms (e.g., "testing", "configuration" without specifics)
- Company names or acronyms without context
- Passing mentions without substantive information

**4d. For each extracted concept:**

Check if concept page already exists:
- If exists: **Update it** with new information from this source
  - Add source to frontmatter `sources:` array
  - Update `last_updated` date
  - Merge new information into content (don't duplicate)
  - Add new cross-links if discovered
  
- If new: **Create concept page** in `.notegraph/wiki/concepts/[concept-slug].md`

**Concept page format:**
```markdown
---
title: [Concept Name]
tags: [category1, category2, specific-topic]
sources:
  - path/to/source1.md
  - path/to/source2.pdf
related: [[Related Concept 1]], [[Related Concept 2]], [[Related Concept 3]]
created: [date]
last_updated: [date]
---

# [Concept Name]

[2-3 sentence introduction explaining what this concept is]

## Overview
[Detailed explanation with concrete details]

## Key Points
- **Point 1** — explanation with specifics
- **Point 2** — explanation with specifics
- **Point 3** — explanation with specifics

[Use concrete examples with actual numbers/values where possible]

## Examples
[If applicable: code blocks, calculations, data flow, etc.]

## Related Concepts
- [[Related Concept 1]] — how it relates
- [[Related Concept 2]] — how it relates

## References
- Source: [filename](../../path/to/source.md)
```

**4e. Discover cross-links**
As you write each concept page:
- Identify relationships to other concepts (existing or new)
- Add `[[wikilinks]]` in the content where concepts are mentioned
- Update the `related:` field in frontmatter
- **Rule:** Every concept should link to at least 1-2 other concepts (no orphans)

**Cross-linking strategies:**
- "X is part of Y" → Y's page should link to X
- "X happens before Y" → both should link to each other
- "X is used by Y and Z" → Y and Z should link to X
- "X and Y are alternatives" → mutual links

### Step 5: Categorize concepts
- Analyze all concepts (new and existing)
- Group them into logical categories (e.g., "Boot Process", "Memory", "Debug", "PCIe")
- Update categories in `.notegraph/wiki/config.json`

### Step 6: Update index.md
Update `.notegraph/wiki/index.md`:
- Organize all concepts by category
- Each entry: `- [[Concept Name]] — one-line summary`
- Keep alphabetical within categories
- Update "Last updated" timestamp

**Example index structure:**
```markdown
# NoteGraph Wiki Index

**Last updated:** 2026-06-01

## Categories

### Boot Process
- [[FSP Initialization]] — Firmware Support Package init sequence
- [[Memory Training]] — DRAM timing calibration during boot
- [[POST Flow]] — Power-On Self-Test execution order

### Debug & Validation
- [[Common POST Errors]] — Frequent boot failure codes and fixes
- [[PCIe Debug]] — Link training and enumeration troubleshooting
- [[RAS Logging]] — Reliability, Availability, Serviceability logs

### Memory
- [[DIMM Configuration]] — Memory module detection and setup
- [[Memory Map]] — Physical address space layout
```

### Step 7: Update log.md
Append an entry to `.notegraph/wiki/log.md`:

```markdown
## [YYYY-MM-DD HH:MM]
**Operation:** `ingest` | **Source:** `path/to/source`
**Status:** ✅ Success

- Processed X files
- Created Y new concept pages
- Updated Z existing concept pages
- Discovered N cross-links
- Categories: [list categories]

**New concepts:**
- [[Concept 1]]
- [[Concept 2]]

**Updated concepts:**
- [[Concept 3]] — added source: filename.md
```

### Step 8: Report to user
Provide a summary:

```
✅ Ingestion complete!

📁 Processed: 23 files from docs/firmware
📄 Created: 15 new concept pages
🔄 Updated: 8 existing concept pages
🔗 Discovered: 67 cross-links

Categories:
- Boot Process (8 concepts)
- Memory (5 concepts)
- Debug (10 concepts)

Next steps:
- Run `/notegraph-query "your question"` to query the wiki
- Run `/notegraph-lint` to check for issues
- Browse .notegraph/wiki/index.md to explore concepts
```

## Arguments

### `<source-path>` (required)
Directory containing source documents to ingest.

**Examples:**
- `docs/firmware`
- `design-docs/`
- `../shared-knowledge`

### `--incremental` (optional)
Only process files that are new or modified since the last ingestion.

**When to use:**
- Weekly/daily wiki updates
- CI/CD pipelines
- After making doc changes

**How it works:**
- Compares file modification times against last log entry timestamp
- Only re-processes changed files
- Much faster than full re-ingest

## Rules

### Must Follow
- ✅ **Never modify source files** — read-only access only
- ✅ **Always create [[wikilinks]]** for related concepts
- ✅ **Update index.md and log.md** on every run
- ✅ **No orphan pages** — every concept must link to at least one other
- ✅ **Include examples** — prefer concrete numbers/code over abstractions
- ✅ **Cite sources** — every concept must reference source file(s)
- ✅ **Use frontmatter** — all concept pages must have valid YAML frontmatter
- ✅ **Preserve existing content** — when updating, merge don't replace

### Best Practices
- Extract 3-10 concepts per document (not too granular, not too coarse)
- Use clear, descriptive concept titles
- Keep concept pages focused (one topic per page)
- Add 2-5 related concepts per page
- Use concrete examples with actual values
- Group concepts into 4-8 categories

## Example Usage

### Full ingest (first time)
```bash
User: /notegraph-ingest docs/firmware

AI: Scanning docs/firmware for documents...
Found 47 files to ingest.

[... processing ...]

✅ Ingestion complete!
📄 Created 23 concept pages
🔗 Discovered 156 cross-links
```

### Incremental update
```bash
User: /notegraph-ingest docs/firmware --incremental

AI: Checking for changes since last ingest (2026-05-28)...
Found 3 new/changed files.

[... processing ...]

✅ Update complete!
📄 Created 2 new concept pages
🔄 Updated 1 existing concept page
🔗 Discovered 8 new cross-links
```

### Multiple source directories
```bash
# Ingest firmware docs
User: /notegraph-ingest docs/firmware

# Then ingest validation docs (will merge with existing wiki)
User: /notegraph-ingest docs/validation

AI: ✅ Ingestion complete!
🔗 Found 12 cross-links between firmware and validation concepts!
```

## Troubleshooting

**Problem:** "Source path not found"  
**Solution:** Check that the path is relative to repo root

**Problem:** "No .notegraph/wiki directory"  
**Solution:** Run `/notegraph-init` first

**Problem:** "No concepts extracted"  
**Solution:** Check that source files contain substantive technical content

**Problem:** "Duplicate concepts with different names"  
**Solution:** The AI should detect these during Step 3 and merge them
