---
name: notegraph-init
description: "Bootstrap a new NoteGraph wiki structure in your repository"
argument-hint: "[wiki-directory]"
---

# Initialize NoteGraph Wiki

## When to Use

Use this skill **once per repository** when you want to set up a new NoteGraph knowledge wiki. This is the first step before ingesting any documents.

Run this skill if:
- You're setting up NoteGraph for the first time
- You want to create a fresh wiki structure
- You need to initialize the configuration

## What It Does

This skill bootstraps a complete wiki structure in your repository:

1. Creates `.notegraph/wiki/` directory hierarchy
2. Generates initial `index.md` (empty catalog, ready to populate)
3. Generates initial `log.md` (operations history)
4. Creates `config.json` with sensible defaults
5. Sets up `concepts/` and `sources/` subdirectories
6. Creates template files for reference

**Output structure:**
```
.notegraph/
└── wiki/
    ├── concepts/           # Concept pages will go here
    ├── sources/            # Source document summaries
    ├── index.md            # Master catalog
    ├── log.md              # Operations history
    └── config.json         # Wiki configuration
```

## Procedure

When the user invokes this skill, follow these steps:

### Step 1: Check if wiki already exists
- Look for `.notegraph/wiki/` directory
- If it exists, warn the user and ask if they want to:
  - Keep existing wiki (abort)
  - Reinitialize (will preserve existing concept pages but regenerate index/log/config)

### Step 2: Create directory structure
Create these directories:
```
.notegraph/wiki/concepts/
.notegraph/wiki/sources/
```

### Step 3: Generate index.md
Create `.notegraph/wiki/index.md` with this content:

```markdown
# NoteGraph Wiki Index

**Last updated:** [current date]

Welcome to your NoteGraph knowledge wiki. This index is automatically maintained by the AI.

## Quick Links
- [Changelog](log.md) — View all ingestion operations
- [Configuration](config.json) — Wiki settings

## Categories

*No concepts yet. Run `/notegraph-ingest <source-path>` to populate the wiki.*

---

## About This Wiki

This wiki is generated and maintained by NoteGraph, an AI-powered knowledge management system.

- **Source documents** are never modified (read-only)
- **Concept pages** are AI-generated with `[[cross-links]]`
- **Index** and **log** are automatically updated

### Usage
- `/notegraph-ingest <path>` — Ingest documents
- `/notegraph-query "question"` — Query the wiki
- `/notegraph-lint` — Health check
```

### Step 4: Generate log.md
Create `.notegraph/wiki/log.md` with this content:

```markdown
# NoteGraph Operations Log

This file tracks all operations performed on the wiki.

---

## [current date and time]
**Operation:** `init`
**Status:** ✅ Success

Wiki structure initialized:
- Created `.notegraph/wiki/` directory
- Generated `index.md` and `log.md`
- Created `config.json` with default settings
- Ready for ingestion

---
```

### Step 5: Generate config.json
Create `.notegraph/wiki/config.json` with this content:

```json
{
  "version": "1.0",
  "wikiDirectory": ".notegraph/wiki",
  "frontmatter": {
    "required": ["title", "tags", "sources", "last_updated"],
    "optional": ["related", "created", "status"]
  },
  "rules": {
    "allowOrphans": false,
    "requireExamples": true,
    "requireSourceCitation": true,
    "staleThresholdMonths": 18
  },
  "categories": []
}
```

**Note:** The `categories` array will be populated automatically during ingestion.

### Step 6: Confirm success
Report to the user:

```
✅ NoteGraph wiki initialized successfully!

Created:
  .notegraph/wiki/
  ├── concepts/
  ├── sources/
  ├── index.md
  ├── log.md
  └── config.json

Next steps:
1. Run `/notegraph-ingest <source-path>` to populate the wiki
2. Run `/notegraph-query "your question"` to query it
3. Run `/notegraph-lint` to check health

Example: /notegraph-ingest docs/firmware
```

## Arguments

- **[wiki-directory]** (optional) — Custom location for the wiki
  - Default: `.notegraph/wiki`
  - Use this if you want a different location (e.g., `knowledge-base/`)

**Example with custom directory:**
```
/notegraph-init wiki
```
This creates `wiki/` instead of `.notegraph/wiki/`

## Rules

- ✅ Create directory structure if it doesn't exist
- ✅ Preserve existing concept pages if reinitializing
- ✅ Use current date/time in log entries
- ✅ Generate valid JSON for config.json
- ❌ Never overwrite existing concept pages without asking
- ❌ Never modify source documents

## Example Usage

### First-time setup
```bash
User: /notegraph-init