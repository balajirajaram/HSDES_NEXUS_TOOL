---
name: notegraph-lint
description: "Health check the wiki for orphans, dead links, and stale content"
argument-hint: "[--fix]"
---

# Lint NoteGraph Wiki

## When to Use

Use this skill to maintain wiki health and quality:

- **Periodic maintenance** — Run weekly/monthly to catch issues
- **Before releases** — Ensure wiki is clean before sharing with team
- **After bulk ingestion** — Check for orphans or broken links
- **On CI/CD** — Automate quality checks
- **When onboarding slows** — Users report confusing or outdated info

**Health checks detect:**
- Orphan pages (no incoming links)
- Dead links (references to non-existent concepts)
- Stale content (not updated in 18+ months)
- Missing source citations
- Contradictions between pages
- Broken source file references

## What It Does

This skill performs a comprehensive health check on your wiki and generates a report with:

1. **Issue counts** by category
2. **File paths** for each issue
3. **Severity levels** (❌ critical, ⚠️ warning, ℹ️ info)
4. **Actionable suggestions** for fixes
5. **Overall health score**

**Optional:** With `--fix` flag, automatically fixes certain issues (dead links, stale dates).

## Procedure

When the user invokes this skill, follow these steps:

### Step 1: Validate wiki exists
- Check that `.notegraph/wiki/` exists
- If not: suggest running `/notegraph-init` first
- Check that concepts exist to lint

### Step 2: Read wiki configuration
- Read `.notegraph/wiki/config.json` for lint rules:
  - `staleThresholdMonths` (default: 18)
  - `allowOrphans` (default: false)
  - `requireSourceCitation` (default: true)

### Step 3: Scan all wiki pages
Build an inventory:
- List all concept pages in `wiki/concepts/`
- List all source pages in `wiki/sources/`
- Parse frontmatter from each page
- Extract all `[[wikilinks]]` from content

### Step 4: Run health checks

#### Check 1: Orphan Pages
**What:** Concept pages with no incoming `[[wikilinks]]` from other pages

**Why it matters:** Orphans are undiscoverable — users can't navigate to them

**How to check:**
1. For each concept page, count how many other pages link to it
2. If count == 0, it's an orphan (unless it's referenced in index.md)

**Report format:**
```
❌ 3 orphan pages found:
  - .notegraph/wiki/concepts/old-debug-flow.md (no incoming links)
  - .notegraph/wiki/concepts/legacy-boot-sequence.md (no incoming links)
  - .notegraph/wiki/concepts/deprecated-tool.md (no incoming links)

Suggestion: Add cross-links from related concepts, or archive if obsolete
```

#### Check 2: Dead Links
**What:** `[[Wikilinks]]` that reference concepts that don't exist

**Why it matters:** Broken navigation, confusing for users

**How to check:**
1. Extract all `[[wikilinks]]` from all pages
2. For each link, check if `wiki/concepts/[link-slug].md` exists
3. Report any that don't exist

**Report format:**
```
❌ 2 dead links found:
  - .notegraph/wiki/concepts/memory-init.md links to [[DIMM Config]] (doesn't exist)
    → Suggestion: Create concept page for "DIMM Config" or fix link to [[DIMM Configuration]]
  - .notegraph/wiki/concepts/boot-flow.md links to [[Old FSP]] (doesn't exist)
    → Suggestion: Update to [[FSP Initialization]] or create missing page
```

#### Check 3: Stale Content
**What:** Pages not updated in N months (configurable, default 18)

**Why it matters:** Outdated info can mislead users

**How to check:**
1. Read `last_updated:` field from frontmatter
2. Calculate months since that date
3. Report pages exceeding threshold

**Report format:**
```
⚠️  5 stale pages (18+ months old):
  - .notegraph/wiki/concepts/legacy-boot.md (last updated 2024-01-15)
  - .notegraph/wiki/concepts/old-pcie-debug.md (last updated 2023-11-03)
  - .notegraph/wiki/concepts/deprecated-memory-training.md (last updated 2023-08-22)
  
Suggestion: Review these pages — update if still relevant, archive if obsolete
```

#### Check 4: Missing Source Citations
**What:** Concept pages without `sources:` in frontmatter

**Why it matters:** Claims can't be traced back to authoritative docs

**How to check:**
1. Read frontmatter from each concept page
2. Check if `sources:` field exists and is non-empty
3. Report any missing citations

**Report format:**
```
⚠️  3 pages missing source citations:
  - .notegraph/wiki/concepts/generic-debug-tips.md (no sources listed)
  - .notegraph/wiki/concepts/troubleshooting-101.md (no sources listed)

Suggestion: Add source documents to frontmatter, or flag as "derived knowledge"
```

#### Check 5: Broken Source References
**What:** Source files listed in frontmatter that no longer exist

**Why it matters:** Can't verify claims if source is gone

**How to check:**
1. For each concept page, read `sources:` array from frontmatter
2. Check if each source file path exists on disk
3. Report any missing files

**Report format:**
```
❌ 2 broken source references:
  - .notegraph/wiki/concepts/memory-training.md references:
    → docs/old/memory-spec.pdf (file not found)
  - .notegraph/wiki/concepts/boot-flow.md references:
    → design-docs/deprecated/boot-design.md (file not found)

Suggestion: Update concept pages to reference current source files
```

#### Check 6: Contradictions (Advanced)
**What:** Multiple pages making conflicting claims about the same topic

**Why it matters:** Confuses users, undermines trust

**How to check:**
1. Identify concepts mentioning the same terms/entities
2. Look for conflicting statements (e.g., different values, opposite claims)
3. This requires semantic analysis — flag potential contradictions

**Report format:**
```
⚠️  1 potential contradiction found:
  - [[Memory Training]] says "training takes 2-3 seconds"
  - [[Boot Performance]] says "memory training takes 8-10 seconds"
  
Suggestion: Review these pages and reconcile the difference (may depend on platform)
```

### Step 5: Calculate health score
```
Health Score = (total pages - issues) / total pages * 100

Example: 50 pages, 8 issues → (50 - 8) / 50 = 84%
```

### Step 6: Generate report

**Report format:**

```markdown
# 🩺 NoteGraph Health Report

**Generated:** [date and time]
**Wiki:** `.notegraph/wiki/`
**Total pages:** X concept pages, Y source summaries

---

## Health Score: [XX%]

[Progress bar visualization]
████████████░░░░░░░░ 84% Healthy

---

## Issues Found

### ❌ Critical Issues (X)
[Orphans, dead links, broken source refs]

### ⚠️  Warnings (Y)
[Stale content, missing citations]

### ℹ️  Info (Z)
[Minor issues, suggestions]

---

## Detailed Findings

### ❌ Orphan Pages (3)
- .notegraph/wiki/concepts/old-debug-flow.md
- .notegraph/wiki/concepts/legacy-boot-sequence.md
- .notegraph/wiki/concepts/deprecated-tool.md

**Fix:** Add cross-links from related concepts, or archive if obsolete

---

### ❌ Dead Links (2)
- .notegraph/wiki/concepts/memory-init.md → [[DIMM Config]] (missing)
- .notegraph/wiki/concepts/boot-flow.md → [[Old FSP]] (missing)

**Fix:** Create missing pages or update links to existing concepts

---

### ⚠️  Stale Content (5 pages)
- .notegraph/wiki/concepts/legacy-boot.md (18 months old)
- .notegraph/wiki/concepts/old-pcie-debug.md (24 months old)

**Fix:** Review and update, or archive if no longer relevant

---

### ⚠️  Missing Citations (3)
- .notegraph/wiki/concepts/generic-debug-tips.md
- .notegraph/wiki/concepts/troubleshooting-101.md

**Fix:** Add source documents to frontmatter

---

### ❌ Broken Source References (2)
- memory-training.md → docs/old/memory-spec.pdf (not found)
- boot-flow.md → design-docs/deprecated/boot-design.md (not found)

**Fix:** Update to point to current source files

---

## Summary

✅ **Healthy pages:** 42  
❌ **Pages with issues:** 8  
📊 **Overall health:** 84%

**Recommended actions:**
1. Fix dead links (high priority)
2. Review stale content
3. Add source citations where missing
4. Consider archiving orphaned pages

Run `/notegraph-lint --fix` to auto-fix some issues.
```

### Step 7: If `--fix` flag is set

Automatically fix certain issues:

**Auto-fixable issues:**
1. **Update stale dates** — Update `last_updated` to today if content was reviewed
2. **Remove dead links** — Comment out `[[dead links]]` with a note
3. **Update index.md** — Remove references to deleted pages

**Report what was fixed:**
```
🔧 Auto-fix applied:

✅ Fixed 2 issues:
- Removed dead link [[Old FSP]] from boot-flow.md
- Removed dead link [[DIMM Config]] from memory-init.md

⚠️  3 issues require manual review:
- 3 orphan pages (decision needed: keep or archive?)
- 2 broken source references (update to correct paths)

Re-run `/notegraph-lint` to verify fixes.
```

### Step 8: Update log.md
Append a lint entry to `.notegraph/wiki/log.md`:

```markdown
## [YYYY-MM-DD HH:MM]
**Operation:** `lint`
**Status:** ✅ Complete

**Health score:** 84%
**Issues found:** 8 (3 critical, 5 warnings)
**Auto-fixed:** 2 issues (--fix flag used)

See full report above.
```

## Arguments

### `[--fix]` (optional)
Automatically fix issues where possible.

**What gets auto-fixed:**
- Dead links (removed or commented out)
- Stale dates (updated to current date)
- Index inconsistencies

**What requires manual review:**
- Orphan pages (user must decide: link or archive)
- Broken source references (user must provide correct path)
- Contradictions (user must reconcile)

**Example:**
```bash
/notegraph-lint --fix
```

## Rules

### Must Follow
- ✅ **Report file paths** — users need to know where issues are
- ✅ **Suggest fixes** — every issue should have an actionable suggestion
- ✅ **Use severity levels** — critical (❌), warning (⚠️), info (ℹ️)
- ✅ **Calculate health score** — gives users a quick sense of wiki quality
- ✅ **Log to log.md** — maintain audit trail
- ❌ **Don't auto-delete pages** without asking — even orphans might be valuable
- ❌ **Don't modify concept content** during auto-fix — only metadata/links

### Lint Rule Configuration
Read from `.notegraph/wiki/config.json`:

```json
{
  "rules": {
    "allowOrphans": false,           // If true, don't flag orphan pages
    "requireExamples": true,          // Warn if concept has no examples
    "requireSourceCitation": true,    // Require sources: field
    "staleThresholdMonths": 18        // How old before flagging as stale
  }
}
```

## Example Usage

### Basic lint (report only)

```bash
User: /notegraph-lint

AI: 🩺 Running health check on wiki...

[... scanning ...]

# 🩺 NoteGraph Health Report

**Health Score: 84%** ████████████░░░░░░░░

## Issues Found

❌ **Critical (3)**
- 2 dead links
- 1 orphan page

⚠️  **Warnings (5)**
- 5 stale pages

✅ **42 pages healthy**

[... detailed findings ...]

**Next steps:**
- Run `/notegraph-lint --fix` to auto-fix some issues
- Review stale content manually
```

### Lint with auto-fix

```bash
User: /notegraph-lint --fix

AI: 🔧 Running health check with auto-fix...

[... scanning ...]

✅ Auto-fixed 2 issues:
- Removed 2 dead links

⚠️  3 issues require manual review:
- 1 orphan page (decide: link or archive?)
- 2 broken source refs (update paths)

**Health score improved: 78% → 84%**

Re-run `/notegraph-lint` to verify.
```

### Perfect health

```bash
User: /notegraph-lint

AI: 🩺 Running health check...

# 🩺 NoteGraph Health Report

**Health Score: 100%** ████████████████████

✅ **All 47 pages healthy!**

No issues found:
- No orphan pages
- No dead links
- All content up-to-date
- All sources cited

Your wiki is in excellent shape! 🎉
```

### First-time lint (many issues)

```bash
User: /notegraph-lint

AI: 🩺 Running health check...

# 🩺 NoteGraph Health Report

**Health Score: 62%** ████████████░░░░░░░░

## Issues Found

❌ **Critical (12)**
- 8 dead links
- 4 orphan pages

⚠️  **Warnings (15)**
- 12 stale pages
- 3 missing citations

**Recommended:**
1. Run `/notegraph-lint --fix` to auto-fix dead links
2. Review orphan pages and add cross-links
3. Update stale content
4. Run `/notegraph-ingest --incremental` to refresh from sources
```

## Troubleshooting

**Problem:** "Lint finds too many false positives"  
**Solution:** Adjust thresholds in `config.json` (e.g., increase `staleThresholdMonths`)

**Problem:** "Auto-fix is too aggressive"  
**Solution:** Run without `--fix` first, review report, then decide

**Problem:** "Contradictions not detected"  
**Solution:** This is a hard problem — requires semantic analysis, may miss some

**Problem:** "Wiki is 100% healthy but users report issues"  
**Solution:** Lint checks structure, not content quality — run `/notegraph-query` tests
