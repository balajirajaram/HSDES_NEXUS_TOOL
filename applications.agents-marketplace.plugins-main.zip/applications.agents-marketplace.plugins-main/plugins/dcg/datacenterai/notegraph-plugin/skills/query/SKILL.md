---
name: notegraph-query
description: "Query the wiki with AI-synthesized answers and citations"
argument-hint: '"<your question>"'
---

# Query NoteGraph Wiki

## When to Use

Use this skill whenever you need to:

- **Answer questions** from the knowledge base
- **Find information** scattered across multiple documents
- **Onboard new team members** — they can query instead of asking teammates
- **Discover related concepts** — the answer includes cross-links
- **Synthesize information** from multiple sources with citations

**Perfect for:**
- "How do I debug X?"
- "What is Y and how does it work?"
- "What are common failures in Z?"
- "How does A relate to B?"

## What It Does

This skill provides intelligent question-answering over your wiki:

1. **Searches** the wiki using semantic + keyword matching
2. **Identifies** the most relevant concept pages
3. **Synthesizes** a clear answer from those pages
4. **Cites sources** using `[[concept]]` wikilinks
5. **Suggests related concepts** for further exploration

**Output format:**
- Clear, concise answer
- `[[Wikilink]]` citations to concept pages
- Related concepts for deeper exploration

## Procedure

When the user invokes this skill, follow these steps:

### Step 1: Validate wiki exists
- Check that `.notegraph/wiki/` exists
- If not: suggest running `/notegraph-init` and `/notegraph-ingest` first
- Check that `index.md` has concepts (not empty)

### Step 2: Parse the question
Analyze the user's question to understand:
- **What** they're asking (concept, process, troubleshooting, relationship)
- **Key terms** to search for
- **Scope** (broad overview vs specific detail)

**Example analysis:**
- Question: "How do I debug PCIe link training failures?"
- Key terms: PCIe, link training, failures, debug
- Type: Troubleshooting / procedural
- Scope: Specific, actionable steps

### Step 3: Search the wiki

**3a. Read the index**
- Read `.notegraph/wiki/index.md` to get all concept titles
- Identify 5-10 potentially relevant concepts based on:
  - Keyword matching
  - Category relevance
  - Concept title similarity

**3b. Read relevant concept pages**
- Read the top 5-10 matching concept pages fully
- Follow cross-links if the answer seems to span multiple concepts
- Read source summaries in `wiki/sources/` if needed

**3c. Identify the most relevant information**
- Extract passages that directly answer the question
- Note which concepts provide which pieces of information
- Track citations (which concept pages you're synthesizing from)

### Step 4: Synthesize the answer

**Answer structure:**

```markdown
[Direct answer to the question — 1-2 sentences]

[Detailed explanation organized by key points]

1. **[Point 1]** — [explanation with specifics from wiki]
2. **[Point 2]** — [explanation with specifics from wiki]
3. **[Point 3]** — [explanation with specifics from wiki]

[Include concrete examples, code, or procedures if available in the wiki]

📚 **Sources:** [[Concept 1]], [[Concept 2]], [[Concept 3]]

💡 **Related concepts you might want to explore:**
- [[Related Concept A]] — [why it's relevant]
- [[Related Concept B]] — [why it's relevant]
```

**Answer quality guidelines:**
- ✅ Direct and actionable (answer the question clearly)
- ✅ Specific not generic (use actual details from the wiki)
- ✅ Cite sources (every claim should trace to a concept page)
- ✅ Include examples (code, commands, procedures if in wiki)
- ✅ Suggest related concepts (help user explore deeper)
- ❌ Don't invent information not in the wiki
- ❌ Don't be vague ("it depends...", "usually...")
- ❌ Don't answer without citations

### Step 5: Handle edge cases

**Question is too broad**
```
Your question covers a broad topic. Here are the key concepts:

- [[Concept 1]] — [summary]
- [[Concept 2]] — [summary]
- [[Concept 3]] — [summary]

Try asking more specifically, e.g.:
- "How does [Concept 1] handle X?"
- "What are common failures in [Concept 2]?"
```

**Answer not in wiki**
```
I couldn't find information about "[topic]" in the wiki.

The wiki currently covers:
- [Category 1]: [[concept]], [[concept]]
- [Category 2]: [[concept]], [[concept]]

Suggestions:
1. Try rephrasing your question
2. Check if related concepts exist: [[similar concept]]
3. Run `/notegraph-ingest <path>` if you have source docs about this topic
```

**Partial answer**
```
I found partial information about "[topic]":

[What I found with citations]

However, the wiki doesn't currently cover:
- [Missing piece 1]
- [Missing piece 2]

These concepts might have related info: [[Concept A]], [[Concept B]]
```

### Step 6: Format and return

Present the answer to the user with:
- Clear formatting (headings, bullets, code blocks)
- All `[[wikilinks]]` properly formatted
- Emoji markers (📚 for sources, 💡 for related concepts)
- Suggestions for follow-up queries if helpful

## Arguments

### `"<your question>"` (required)
Natural language question about the knowledge base.

**Examples:**
- `/notegraph-query "How do I debug PCIe link training failures?"`
- `/notegraph-query "What is memory training?"`
- `/notegraph-query "What are common POST errors?"`
- `/notegraph-query "How does FSP relate to memory initialization?"`

**Tip:** Be specific for better answers!

## Rules

### Must Follow
- ✅ **Only use information from the wiki** — don't invent facts
- ✅ **Always cite sources** using `[[wikilinks]]`
- ✅ **Read multiple concept pages** — answers often span concepts
- ✅ **Follow cross-links** — related concepts often have the full picture
- ✅ **Include examples** — if the wiki has code/commands, show them
- ❌ **Never answer without citations** — every claim needs a source
- ❌ **Never invent information** — admit when answer isn't in wiki

### Best Practices
- Read 5-10 concept pages per query (not just 1-2)
- Synthesize across multiple sources for complete answers
- Include procedural steps if the question asks "how to"
- Suggest 2-4 related concepts for deeper exploration
- Use concrete examples and specifics from the wiki
- Format answers for readability (bullets, numbered lists, code blocks)

## Example Usage

### Example 1: Troubleshooting question

```bash
User: /notegraph-query "How do I debug PCIe link training failures?"

AI: PCIe link training failures typically stem from three areas:

1. **Signal integrity issues** — Check the eye diagram quality and verify signal integrity validation results. Poor signal quality prevents successful training. See [[PCIe Eye Diagram]] and [[SI Validation]].

2. **BIOS configuration** — Incorrect bifurcation settings or link speed configuration can cause training to fail. Verify [[PCIe Bifurcation Settings]] and [[Link Speed Config]].

3. **Hardware faults** — Check RAS error logs and use iConsole for hardware diagnostics. See [[RAS Error Logs]] and [[iConsole Debug]].

**For Gen5 specifically:** Refer to [[Gen5 Known Issues]]. A common workaround is forcing Gen4 mode during debug.

**Debug procedure:**
1. Check POST code — if 0xA3, see [[POST Code 0xA3]]
2. Read error logs via `ipmitool sel list`
3. Test with known-good riser card
4. Try forcing lower link speed in BIOS

📚 **Sources:** [[PCIe Debug Guide]], [[Link Training State Machine]], [[Common POST Errors]]

💡 **Related concepts:**
- [[PCIe Enumeration]] — what happens after successful training
- [[IIO Configuration]] — platform-level PCIe settings
```

### Example 2: Concept explanation

```bash
User: /notegraph-query "What is memory training?"

AI: Memory training is the process of calibrating DRAM timing parameters during platform boot to ensure reliable memory operation.

**Key steps in memory training:**

1. **SPD Detection** — Read DIMM specifications via [[I2C Bus]] to get timing parameters
2. **Write Leveling** — Align write data strobe with clock signal
3. **Read Training** — Calibrate read data capture timing
4. **Command Training** — Optimize command/address signal timing

**When it happens:**
Memory training occurs during [[FSP Initialization]], specifically in the FSP-M (Memory) phase. If training fails, you'll see [[POST Code 0x15]].

**Common issues:**
- Incompatible DIMMs → Check [[DIMM Configuration]]
- Thermal issues → Training timing changes with temperature
- Marginal signal integrity → See [[Memory Signal Integrity]]

**Example timing values:**
```
CAS Latency: 22 clocks
tRCD: 22 clocks
tRP: 22 clocks
```

📚 **Sources:** [[Boot Sequence]], [[FSP Memory Init]], [[DDR5 Training]]

💡 **Related concepts:**
- [[Memory Map]] — address space after training completes
- [[RMT (Rank Margin Tool)]] — advanced training diagnostics
```

### Example 3: Relationship question

```bash
User: /notegraph-query "How does FSP relate to memory initialization?"

AI: FSP (Firmware Support Package) is the Intel-provided firmware that handles memory initialization during boot. Memory init is one of FSP's core responsibilities.

**The relationship:**

1. **FSP-M (Memory)** — This FSP phase executes [[Memory Training]] and configures the memory controller. It runs very early in boot, before main BIOS.

2. **FSP calls memory training** — [[Memory Training Flow]] is invoked by FSP-M to calibrate DRAM timings based on [[DIMM Configuration]] read from SPD.

3. **BIOS configures FSP** — BIOS passes configuration parameters to FSP via UPDs (Updatable Product Data). See [[FSP UPD Configuration]].

**Boot sequence:**
```
SEC → PEI → FSP-M (memory training) → FSP-S (silicon init) → DXE
```

If FSP-M fails, you'll see [[POST Code 0x15]] and boot halts.

📚 **Sources:** [[FSP Architecture]], [[Memory Training]], [[Boot Flow]]

💡 **Related concepts:**
- [[FSP-S]] — silicon initialization phase (after memory)
- [[FSP Debug]] — how to debug FSP failures
- [[UEFI PEI Phase]] — where FSP runs
```

### Example 4: Not found in wiki

```bash
User: /notegraph-query "How do I configure RAID arrays?"

AI: I couldn't find information about "RAID arrays" in the wiki.

The wiki currently covers:
- **Boot Process**: [[FSP]], [[Memory Training]], [[POST Flow]]
- **Debug**: [[PCIe Debug]], [[RAS Logging]], [[iConsole]]
- **Memory**: [[DIMM Configuration]], [[Memory Map]]

**Suggestions:**
1. Try searching for related storage concepts: [[Storage Configuration]] or [[SATA Init]]
2. If you have docs about RAID, run `/notegraph-ingest <path>` to add them to the wiki
3. Check if this is covered under a different name in [[index.md]]
```

## Troubleshooting

**Problem:** "No concepts found"  
**Solution:** Wiki is empty — run `/notegraph-ingest` first

**Problem:** "Answer is too generic"  
**Solution:** Read more concept pages, follow cross-links for details

**Problem:** "Missing citations"  
**Solution:** Every claim must cite a `[[concept]]` — go back and add them

**Problem:** "User asks follow-up question"  
**Solution:** Search again with the new question, can reference previous concepts
