---
title: {{TITLE}}
tags: [{{TAG1}}, {{TAG2}}, {{TAG3}}]
sources:
  - {{SOURCE_FILE_PATH}}
related: [[{{RELATED_CONCEPT_1}}]], [[{{RELATED_CONCEPT_2}}]], [[{{RELATED_CONCEPT_3}}]]
created: {{CREATED_DATE}}
last_updated: {{LAST_UPDATED_DATE}}
---

# {{TITLE}}

{{CONCEPT_SUMMARY}}

## Overview

{{DETAILED_EXPLANATION}}

## Key Points

- **{{KEY_POINT_1}}** — {{EXPLANATION_1}}
- **{{KEY_POINT_2}}** — {{EXPLANATION_2}}
- **{{KEY_POINT_3}}** — {{EXPLANATION_3}}

## Examples

{{CONCRETE_EXAMPLES}}

```
{{CODE_OR_DATA_EXAMPLE}}
```

## Related Concepts

- [[{{RELATED_CONCEPT_1}}]] — {{RELATIONSHIP_DESCRIPTION_1}}
- [[{{RELATED_CONCEPT_2}}]] — {{RELATIONSHIP_DESCRIPTION_2}}
- [[{{RELATED_CONCEPT_3}}]] — {{RELATIONSHIP_DESCRIPTION_3}}

## References

- Source: [{{SOURCE_FILENAME}}]({{RELATIVE_PATH_TO_SOURCE}})
