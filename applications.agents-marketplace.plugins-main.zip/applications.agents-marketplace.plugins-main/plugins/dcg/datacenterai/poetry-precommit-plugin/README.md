# Poetry Pre-commit Plugin

A Copilot skill plugin that runs pre-commit hooks on git-changed files within a Poetry-managed virtual environment.

## Overview

This plugin identifies modified files in a git repository, activates the project's virtual environment, and runs pre-commit checks on each changed file individually. It iteratively fixes failures until all checks pass.

## When to Use

- Run pre-commit hooks on files you changed
- Lint, format, or validate code changes
- Fix pre-commit failures iteratively

## Procedure

### 1. Identify Changed Files

The plugin runs `git status --porcelain` to find modified/added files and parses the output to get changed file paths.

Supported status prefixes:
| Prefix | Meaning |
|--------|---------|
| `M` / ` M` | Modified |
| `A` / `AM` | Added |
| `??` | Untracked (skipped unless explicitly included) |
| `D` | Deleted (skipped) |

If a branch is specified to diff against, `git diff --name-only <branch>` is used instead.

### 2. Activate the Virtual Environment

The project virtual environment is activated using the setup script:

```powershell
Powershell.exe -noexit -File src\kayak\scripts\setup_kayak.ps1 --provisioning
```

The environment must be ready before proceeding to pre-commit checks.

### 3. Run Pre-commit on Each Changed File

Pre-commit is executed one file at a time via Poetry:

```powershell
poetry run pre-commit run --files <path-to-changed-file>
```

### 4. Fix Failures and Re-run

When pre-commit fails on a file, the plugin:

1. Reads the pre-commit error output.
2. Identifies the failing check (e.g., black, isort, flake8, mypy, trailing whitespace).
3. Opens the file and applies the necessary fix.
4. Re-runs the same pre-commit command on that file.
5. Repeats until the check passes.
6. Moves on to the next changed file.

### 5. Final Summary

After all files pass, a summary is provided including:
- List of files checked
- Fixes applied (if any)
- Confirmation that all pre-commit checks pass

## Important Notes

- Operates strictly within the designated workspace folder.
- Pre-commit is always run **one file at a time** to isolate failures.
- Files are not skipped or batched unless explicitly requested.
- If a fix would change the logic or behavior of the code (not just formatting), user confirmation is required before applying.
- The virtual environment must be activated before running any `poetry` commands.

## Requirements

- Git
- Python with Poetry
- Pre-commit hooks configured in the repository (`.pre-commit-config.yaml`)

## Supported Checks

The plugin handles common pre-commit hooks including but not limited to:

- **black** — Code formatting
- **isort** — Import sorting
- **flake8** — Linting
- **mypy** — Type checking
- **trailing-whitespace** — Whitespace cleanup
