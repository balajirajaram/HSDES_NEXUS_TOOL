# Pre-commit Check and Git Commit Plugin

A Copilot skill plugin that runs pre-commit checks on git-changed files, fixes failures, and commits the changes in a single automated workflow.

## Overview

This plugin combines code quality validation with git commit into one seamless cycle: identify changes, run pre-commit hooks, fix issues, and commit — all within a Poetry-managed virtual environment.

## When to Use

- Run pre-commit checks on changed files and then commit them
- Validate code quality and commit in one workflow
- Automate the check-fix-commit cycle

## Procedure

### 1. Run Pre-commit Checks

#### Identify Changed Files

The plugin runs `git status --porcelain` to find modified/added files.

| Prefix | Meaning | Action |
|--------|---------|--------|
| `M` / ` M` | Modified | Include |
| `A` / `AM` | Added | Include |
| `D` | Deleted | Skip |
| `??` | Untracked | Skip |

#### Activate the Virtual Environment

```powershell
Powershell.exe -noexit -File src\kayak\scripts\setup_kayak.ps1 --provisioning
```

#### Run Pre-commit on Each File

Pre-commit is executed one file at a time:

```powershell
poetry run pre-commit run --files <path-to-changed-file>
```

#### Fix Failures and Re-run

When pre-commit fails:

1. Read the error output and identify the failing check.
2. Apply the necessary fix.
3. Re-run pre-commit on the file.
4. Repeat until the check passes.
5. Move to the next file.

If a fix changes logic or behavior (not just formatting), user confirmation is required.

### 2. Stage the Changed Files

After all pre-commit checks pass, stage files explicitly:

```powershell
git add <file1> <file2> ...
```

Only files identified as changed (plus any files modified by pre-commit fixes) are staged. `git add .` or `git add -A` is never used.

### 3. Generate the Commit Message

The plugin analyzes staged changes to produce a commit message:

1. Runs `git diff --cached --stat` for a summary of staged changes.
2. Runs `git diff --cached` to review actual content.
3. Composes a commit message following these rules:
   - **Subject line**: Concise (max 72 chars), imperative mood (e.g., "Fix linting errors in security module")
   - **Body** (if needed): Explains what changed and why, separated from subject by a blank line
   - Mentions pre-commit fixes if applied (e.g., "Apply black/isort formatting fixes")
   - Uses user-provided message if one is given

### 4. Commit the Changes

```powershell
git commit -m "<commit message>"
```

For multi-line messages:

```powershell
git commit -m "<subject>" -m "<body>"
```

### 5. Final Summary

After committing, a summary is provided including:

- List of files checked and committed
- Pre-commit fixes applied (if any)
- The commit message used
- The commit hash (from `git log --oneline -1`)

## Important Notes

- Operates strictly within the designated workspace folder.
- Pre-commit is always run **one file at a time** to isolate failures.
- `--no-verify` is never used on commits — pre-commit hooks must run.
- If there are no changed files, the plugin informs the user and stops.
- If a fix changes code logic/behavior (not just formatting), user confirmation is required.
- If the user provides a specific commit message, it is used as-is.
- The virtual environment must be activated before running any `poetry` commands.

## Requirements

- Git
- Python with Poetry
- Pre-commit hooks configured in the repository (`.pre-commit-config.yaml`)

## Supported Checks

Handles common pre-commit hooks including but not limited to:

- **black** — Code formatting
- **isort** — Import sorting
- **flake8** — Linting
- **mypy** — Type checking
- **trailing-whitespace** — Whitespace cleanup
