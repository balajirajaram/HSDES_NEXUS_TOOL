---
name: pre-commit-and-commit
description: 'Run pre-commit checks on changed files and commit them. Use when: user says "check and commit", "lint and commit", "pre-commit and commit", "validate and commit my changes", "check quality and commit", "commit my changes with checks".'
argument-hint: 'Optionally specify a commit message or branch to diff against'
---

# Pre-commit Check and Git Commit

## When to Use
- User wants to run pre-commit checks on changed files and then commit them
- User asks to validate code quality and commit in one workflow
- User wants an automated check-fix-commit cycle

## Core Behavior

**Autonomous fix loop per file, with final approval per file.** Process files one by one. For each file, automatically apply all fixes and re-run pre-commit in a loop until it passes — do NOT ask the user on every individual fix. Only ask the user for approval once per file at the end, presenting the complete set of changes that made pre-commit pass for that file. Wait for user response before moving to the next file.

**All terminal commands run without user permission.** Never ask the user before running a command in the terminal. Execute every command (`git status`, `Test-Path`, `poetry run pre-commit run`, `setup_kayak.ps1`, `git add`, `git commit`, etc.) directly and autonomously. The only user interaction points are: asking about untracked files, asking for workspace path if `C:\Kayak` doesn't exist, and final approval of code changes per file.

## Procedure

### 0. Verify Workspace Directory

Before doing anything, check if `C:\Kayak` exists on the user's system:

```powershell
Test-Path C:\Kayak
```

- If it exists, use `C:\Kayak` as the workspace directory and `cd` into it.
- If it does NOT exist, ask the user for the correct directory using `vscode_askQuestions`:
  - Question: "The directory `C:\Kayak` was not found on your system. Please provide the path to your Kayak workspace directory."
  - Allow freeform text input (no predefined options).
  - Wait for the user to respond. Use the path they provide as the workspace directory.
  - Validate that the user-provided path exists (`Test-Path`). If it doesn't, inform the user and ask again.

All subsequent commands must run within the confirmed workspace directory.

### 1. Identify Changed and Untracked Files

Run `git status` to find all modified, added, and untracked files:

```powershell
git status --porcelain
```

Extract file paths from the output. Files are listed with a two-character status prefix:
- `M` or ` M` = modified (tracked, automatically included)
- `A` or `AM` = added (tracked, automatically included)
- `??` = untracked (handle separately — see next step)

Only include files that exist on disk (skip deleted files marked with `D`).

If the user specifies a branch to diff against, use `git diff --name-only <branch>` instead for tracked files.

### 1b. Ask About Untracked Files

If there are untracked files (`??` status), present them to the user **one at a time** and ask whether to include each in the pre-commit check. Use the `vscode_askQuestions` tool for each untracked file with Yes/No options.

For each untracked file:
- Ask: "Include untracked file `<filename>` in pre-commit check and commit?"
- If the user says Yes, add it to the list of files to check.
- If the user says No, skip it entirely (no pre-commit, no commit).

Do NOT batch untracked files into a single question. Ask about each file individually so the user has granular control.

### 2. Activate the Kayak Virtual Environment

First, check if the `.venv` directory exists in the workspace:

```powershell
Test-Path .venv
```

- If `.venv` does NOT exist, create it by running the setup script. This is the same command used to launch the precommit environment:

  ```powershell
  Powershell.exe -noexit -File src\kayak\scripts\setup_kayak.ps1 --provisioning
  ```

  Wait for the environment creation to complete fully before proceeding.

- If `.venv` already exists, activate it using the same setup script:

  ```powershell
  Powershell.exe -noexit -File src\kayak\scripts\setup_kayak.ps1 --provisioning
  ```

Wait for the environment to be ready before proceeding.

### 3. Process Each File One by One

For each file in the final list (tracked changed files + user-approved untracked files), perform steps 3a through 3d before moving to the next file.

#### 3a. Run Pre-commit on the File

```powershell
poetry run pre-commit run --files <path-to-file>
```

If pre-commit passes on the first run, skip to the next file (no approval needed since nothing was changed).

#### 3b. Autonomous Fix Loop (No User Interaction)

If pre-commit fails:

1. Read the error output carefully.
2. Identify ALL failing checks for this file (e.g., black, isort, flake8, mypy, trailing whitespace).
3. Apply fixes silently — do NOT ask the user for permission at this stage.
4. Re-run pre-commit on the same file:
   ```powershell
   poetry run pre-commit run --files <path-to-file>
   ```
5. If it still fails, repeat steps 1-4.
6. Continue looping until pre-commit passes with zero errors for this file.

**Rules for the fix loop:**
- Apply formatting fixes (black, isort, trailing whitespace, end-of-file) without asking.
- Apply lint fixes (flake8, pylint) without asking — use minimal correct fix.
- Apply type fixes (mypy) without asking — add type annotations, fix type errors.
- Track every change made (description of each fix) for the approval step.
- If the loop exceeds **5 iterations** without converging, stop and present the remaining errors to the user for guidance before continuing.

#### 3c. Ask User for Approval (Once Per File) — BLOCKING

Once pre-commit passes for this file, present the changes to the user using `vscode_askQuestions`:

- Show the file name and a list of all fixes that were applied.
- Ask: "Pre-commit now passes for `<filename>`. These fixes were applied: [list fixes]. Accept changes?"
- Options: **"Yes, keep changes"** / **"Show diff"** / **"Discard changes to this file"**

**IMPORTANT: WAIT for the user to respond before doing anything else.** Do NOT proceed to the next file, do NOT run any commands, do NOT start any new pre-commit loops. The workflow is completely paused until the user explicitly selects an option.

If user selects:
- **"Yes, keep changes"** — only then move on to the next file.
- **"Show diff"** — run `git diff <path-to-file>` and display the output, then ask again whether to keep or discard. Wait for response again.
- **"Discard changes to this file"** — revert with `git checkout -- <path-to-file>` and only then move to the next file.

#### 3d. Move to Next File

Repeat steps 3a–3c for the next file in the list.

### 4. Stage Only Pre-commit-Checked Files

After all pre-commit checks pass, stage **only** the files that went through the pre-commit process (tracked changed files + user-approved untracked files, including any modifications made by pre-commit fixes):

```powershell
git add <file1> <file2> ...
```

Do NOT use `git add .` or `git add -A` — be explicit about which files are staged. Only stage files that were pre-commit checked.

### 5. Generate the Commit Message

Analyze the staged changes to produce an appropriate commit message:

1. Run `git diff --cached --stat` to see a summary of staged changes.
2. Run `git diff --cached` to review the actual content of the changes.
3. Compose a commit message following these rules:
   - **Subject line**: Concise summary (max 72 chars), imperative mood (e.g., "Fix linting errors in security module")
   - **Body** (if needed): Explain *what* changed and *why*, separated from subject by a blank line
   - If pre-commit fixes were applied, mention them (e.g., "Apply black/isort formatting fixes")
   - If the user provided a commit message, use that instead

### 6. Commit the Changes

```powershell
git commit -m "<commit message>"
```

If the commit message has a body, use:
```powershell
git commit -m "<subject>" -m "<body>"
```

### 7. Final Summary

Provide a summary including:
- List of files checked and committed
- Pre-commit fixes applied (if any)
- The commit message used
- The commit hash (from `git log --oneline -1`)

## Important Notes

- **NEVER ask user permission before running terminal commands.** All commands (git, poetry, pre-commit, Test-Path, setup scripts, git add, git commit, etc.) must execute immediately without prompting the user. Run every command autonomously.
- **This skill operates strictly within the confirmed workspace folder** (defaults to `C:\Kayak`, or the user-provided path if `C:\Kayak` does not exist). Do NOT run commands, read files, or make changes in any directory outside the workspace.
- **Process files ONE BY ONE** — run pre-commit, fix, and get approval for each file individually before moving to the next.
- **Do NOT ask the user for permission on individual fixes within a file.** All fixes are applied autonomously; the user only approves the final result per file.
- **WAIT for user approval before proceeding.** When changes are presented to the user, do NOT run pre-commit on the next file or start any new fix loop until the user has explicitly accepted or discarded the current file's changes. The workflow is fully blocked on user response.
- **Only commit files that went through pre-commit and were approved by the user.** Never commit files that were skipped, not checked, or discarded.
- **Ask about untracked files individually** — do not batch them into a single prompt.
- If there are no changed files and the user declines all untracked files, inform the user and stop — do not commit.
- Do NOT use `--no-verify` on the commit. The pre-commit hooks must run.
- If the user provides a specific commit message, use it as-is.
- The venv must be activated before running any `poetry` commands.
