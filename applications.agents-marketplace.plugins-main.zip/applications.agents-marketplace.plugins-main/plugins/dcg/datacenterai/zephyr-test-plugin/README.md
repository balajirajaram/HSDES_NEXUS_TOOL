# zephyr-test-plugin — Zephyr Scale toolkit for Claude Code

**Manage Zephyr Scale test cases end-to-end** — fetch, update with execution
results, create test cycles with version + RC metadata, execute test cases on
a live UI via Playwright MCP, and review test cases against a strict
six-dimension completeness checklist.

| Component | What it does |
|---|---|
| `/zephyr fetch <folder>` | List test cases in a Zephyr folder with steps, preconditions, and expected results |
| `/zephyr update <keys>`  | Create a new version of a test case and write `ACTUAL_RESULT` into the `testData` field of each step |
| `/zephyr cycle <name>`   | Create a test cycle (test run), pin test case versions, and submit step-level results |
| `/zephyr-execute-tests`  | Drive a live web app via Playwright MCP — login, follow steps, capture screenshots, collect actual results |
| `zephyr-test-reviewer` agent | Senior-QA review of test cases against name / objective / preconditions / steps / test data / expected results |

---

## Install

```text
/plugin marketplace add intel-innersource/applications.agents-marketplace.plugins
/plugin install zephyr-test-plugin@plugins-marketplace
```

Verify:

```text
/plugin
```

You should see `zephyr-test-plugin@plugins-marketplace ✓ enabled v0.1.0`.

Smoke test:

```text
/zephyr
```

(With no arguments, the skill lists the three actions and asks which one.)

---

## Usage

### Typical end-to-end flow

```text
/zephyr fetch "/Exploratory Testing"            # Discover what's in the folder
/zephyr-execute-tests "/Exploratory Testing"    # Run them against a live app
/zephyr update PROJ-T250,PROJ-T255 --results-file /tmp/actual_results.json
/zephyr cycle "Exploratory - v2.1.0" --version 2.1.0 --rc RC1 --folder "/Exploratory Testing" --results-file /tmp/results.json
```

### Reviewing test cases

Invoke the bundled agent:

```text
@zephyr-test-reviewer review the test cases in /Exploratory Testing
```

The agent fetches the folder via `/zephyr fetch`, evaluates each test case
across six dimensions (name, objective, preconditions, steps, test data,
expected results), and reports `PASS` / `NEEDS IMPROVEMENT` / `FAIL` per
dimension with concrete suggested rewrites. Approved fixes can be pushed back
via `/zephyr update`.

---

## Required environment variables

| Variable | Purpose |
|---|---|
| `ZEPHYR_TOKEN` | Bearer token for the Zephyr Scale REST API (`/rest/atm/1.0`, `/rest/tests/1.0`) |
| `JIRA_BASE_URL` | Base URL of the Jira instance hosting Zephyr Scale (e.g. `https://jira.example.com`) |

For `/zephyr-execute-tests`, you also need:

| Variable | Purpose |
|---|---|
| `APP_URL` | Base URL of the application under test (overridable per-run with `--app-url`) |
| `APP_USERNAME` | Username for application login during UI execution |
| `APP_PASSWORD` | Password for application login during UI execution |

If these are unset, the skills prompt the user. **Credentials are never
written to memory, logs, or files** — see
`skills/zephyr/references/zephyr-common.md`.

---

## Plugin structure

```
zephyr-test-plugin/
├── plugin.json
├── README.md
├── skills/
│   ├── zephyr/                           # API skill (read + write)
│   │   ├── SKILL.md                       # Action router
│   │   ├── actions/
│   │   │   ├── fetch.md
│   │   │   ├── update.md
│   │   │   └── cycle.md
│   │   └── references/
│   │       └── zephyr-common.md           # Shared auth / transport / guardrails
│   └── zephyr-execute-tests/              # UI execution via Playwright MCP
│       └── SKILL.md
└── agents/
    └── zephyr-test-reviewer.md            # Senior-QA review agent
```

---

## API surface

The `zephyr` skill targets two parallel REST APIs:

| Path prefix | Use for |
|---|---|
| `/rest/atm/1.0` | Test cases, test runs (cycles), result submission |
| `/rest/tests/1.0` | Numeric test-case IDs, version creation, per-item `lastTestCaseVersion` |
| `/rest/api/2` | Jira project / version metadata (validation only) |

The split is documented in `skills/zephyr/references/zephyr-common.md` along
with the self-signed cert handling (`curl -sk`) and the inter-call sleep
policy required by Jira IT.

---

## Guardrails

- `fetch` is read-only. It never issues `POST` / `PUT` / `DELETE`.
- `update` and `cycle` preserve the original `description` and `expectedResult`
  fields verbatim. Only `testData` (for `update`) and result metadata (for
  `cycle`) are modified.
- `ACTUAL_RESULT` is written into `testData` — never into `expectedResult`.
- Tokens and passwords are read from environment variables only; they are
  never logged, echoed, or persisted.

---

## Dependencies

- **`/zephyr-execute-tests`** requires the Playwright MCP server to be
  configured and running. Without it, the other skills (`fetch`, `update`,
  `cycle`) and the reviewer agent still function.
- The skills use `curl` (assumed available on the host) for REST calls.

### Playwright MCP setup

Add to your Claude Code MCP configuration (`~/.claude.json` or your
project's `.mcp.json`):

```json
{
  "mcpServers": {
    "playwright": {
      "command": "npx",
      "args": ["@playwright/mcp@latest"]
    }
  }
}
```

Then restart Claude Code so the MCP server is picked up. First invocation
will download the package and the Chromium browser binary on demand.

---

## Owner

DCG / DataCenterAI — Krystian Rajski (krajski@intel.com)

---

## License

Copyright (C) 2026 Intel Corporation. Licensed under Apache-2.0.
