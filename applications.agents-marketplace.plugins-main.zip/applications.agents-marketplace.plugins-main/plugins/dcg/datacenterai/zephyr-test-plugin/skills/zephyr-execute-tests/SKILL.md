---
name: zephyr-execute-tests
description: Execute Zephyr Scale test cases on a live web application via Playwright MCP — login, follow steps, capture screenshots, and collect per-step actual results ready for cycle submission. Use when the user asks to run/execute Zephyr tests against a UI, drive a browser through Zephyr steps, or capture evidence for a test cycle.
---

# Execute Zephyr test cases on live UI via Playwright MCP

Execute test cases from a Zephyr Scale folder on a live web application using Playwright MCP browser automation. Capture screenshots, collect actual results, and prepare data for cycle submission.

Arguments: $ARGUMENTS
- Zephyr folder path or comma-separated test case keys
- Optional: --app-url (application URL), --screenshot-dir (default: test-exec/)

## Approach
1. Read `ZEPHYR_TOKEN` from environment variable for fetching test steps.
2. Read application credentials from environment (`APP_USERNAME`, `APP_PASSWORD`) or ask user.
3. Fetch test case details from Zephyr (steps, preconditions, expected results).
4. Assess executability: check which tests can run with available data vs which must be BLOCKED.
5. For each executable test:
   a. Navigate to application, login if needed.
   b. Follow test steps using Playwright MCP (browser_navigate, browser_fill_form, browser_click, browser_snapshot).
   c. Capture screenshot at key verification points: `browser_take_screenshot` → `{screenshot-dir}/{KEY}-{step}.png`
   d. Record actual result per step (what the UI showed vs what was expected).
   e. Wait for async responses (browser_wait_for).
6. Compile results JSON with per-step actual results and pass/blocked/fail status.
7. Output summary table and path to results file.

## Credentials
- **ZEPHYR_TOKEN**: From `$ZEPHYR_TOKEN` env var. For fetching test steps.
- **APP_URL**: From `$APP_URL` env var. If not set, use `--app-url` flag. If neither, ask user.
- **APP_USERNAME / APP_PASSWORD**: From env vars or ask user. For application login.
- **JIRA_BASE_URL**: From `$JIRA_BASE_URL` env var. If not set, ask user.
- NEVER store credentials in files, scripts, or memory.

## Constraints
- Requires Playwright MCP server to be configured and running.
- If browser session is lost (target closed), close and re-navigate.
- Always wait for responses after submitting prompts (use browser_wait_for with 10-15s timeout, then snapshot).
- Use browser_snapshot (accessibility tree) for assertions, not screenshots.
- Use browser_take_screenshot for evidence capture only.
- Mark test BLOCKED (not Failed) when precondition cannot be met (e.g. required document not ingested).
- Mark test BLOCKED when test has no steps defined.
- Do not skip steps — execute or explicitly mark each step.

## Playwright MCP Patterns
- Login: `browser_navigate` → `browser_fill_form` (username, password) → `browser_click` (Sign In)
- Send chat prompt: `browser_fill_form` (textbox) → `browser_click` (Send) → `browser_wait_for` (10s) → `browser_snapshot`
- Verify source docs: Check for button elements with document names in snapshot
- Download verification: `browser_click` on source doc button → check for dialog with Download button

## Examples

### Input
/zephyr-execute-tests "/Exploratory Testing" --app-url https://myapp.example.com --screenshot-dir test-exec/

### Output
```
Executed 15 tests from /Exploratory Testing:
  PASS:    T255, T261, T263, T265, T317
  BLOCKED: T250, T252, T253, T254, T256, T257, T258, T259, T318, T534
  FAIL:    (none)

Screenshots saved to test-exec/
Results saved to /tmp/exploratory_results.json
```
