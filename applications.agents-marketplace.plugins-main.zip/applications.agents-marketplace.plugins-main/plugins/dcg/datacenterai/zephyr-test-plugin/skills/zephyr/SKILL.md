---
name: zephyr
description: Zephyr Scale operations - fetch test cases from a folder, update test cases with ACTUAL_RESULT (new version), or create a test cycle with results and metadata. Use when the user asks to fetch/list/show Zephyr test cases, update a Zephyr test case with execution results or actual results, or create a Zephyr test cycle / test run with version + RC + results.
argument-hint: fetch <folder> | update <keys> | cycle <name>
---

# Zephyr Scale Workflow

Manage Zephyr Scale test cases and cycles via its REST APIs (`/rest/atm/1.0`, `/rest/tests/1.0`) plus Jira (`/rest/api/2`) for version metadata.

Three actions, one shared auth + transport layer:

| Action | Purpose |
|--------|---------|
| `fetch`  | List test cases in a folder with steps and preconditions |
| `update` | Create new test case version and write ACTUAL_RESULT into `testData` |
| `cycle`  | Create a test run (cycle), pin test case versions, submit step results |

## Shared conventions

All actions share auth, base URL, and curl behavior. **Read [references/zephyr-common.md](references/zephyr-common.md) before running any action** — it defines:

- Credentials (`ZEPHYR_TOKEN`, `JIRA_BASE_URL`)
- `curl -sk` self-signed cert handling
- HTML strip helper
- Inter-call sleep policy

## Task

Execute the requested action: $ARGUMENTS

Routing:

- `fetch ...`  → see [actions/fetch.md](actions/fetch.md)
- `update ...` → see [actions/update.md](actions/update.md)
- `cycle ...`  → see [actions/cycle.md](actions/cycle.md)

If no action provided, list the three actions and ask which one.

## Out of scope

UI execution against a live application is a separate skill — see `zephyr-execute-tests` (Playwright MCP).
