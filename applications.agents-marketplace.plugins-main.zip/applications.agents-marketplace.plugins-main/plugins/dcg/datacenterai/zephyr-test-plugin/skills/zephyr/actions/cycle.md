# `zephyr cycle` — create test cycle with metadata and results

Create a test cycle (test run) in Zephyr Scale, set metadata (version, RC, description), link test cases at specific versions, and submit step-level execution results.

## Arguments

- Cycle name (or auto-generate from `<folder> + <date>`)
- Optional flags:
  - `--version` (e.g. `2.1.0`) — must match an existing Jira project version
  - `--rc` (e.g. `RC1`)
  - `--folder` — Zephyr folder to pull tests from
  - `--results-file` — JSON with per-test, per-step results

## Approach

1. Load credentials per [../references/zephyr-common.md](../references/zephyr-common.md).
2. If `--folder` given, fetch all test case keys from that folder (reuse `fetch` action's search query).
3. Create cycle: `POST /rest/atm/1.0/testrun` with:
   - `projectKey`, `name`
   - `version`: must match an existing Jira project version string exactly — validate first via `GET /rest/api/2/project/{KEY}/versions`
   - `customFields`: `{"Release Candidate": "RCn"}`
4. For each item in the cycle, set the test case version: `PUT /rest/tests/1.0/testresult/{itemId}` with `{"lastTestCaseVersion": n}`.
5. Submit results: `POST /rest/atm/1.0/testrun/{cycleKey}/testcase/{tcKey}/testresult` with step-level `scriptResults`.
6. Report summary table: cycle key, URL, pass/fail/blocked counts.

## Constraints

- Version string must match an existing Jira project version. Validate via `GET /rest/api/2/project/{KEY}/versions` before creation.
- Test run items accept `testCaseKey` only at creation. Version is set separately via the `tests/1.0` API.
- `scriptResults` DTO accepts only `index`, `status`, `comment` — **NOT** `actualResult`.
- Do **NOT** include a `folder` field in test run creation (test run folders differ from test case folders).
- Sleep 1s between API calls (per shared conventions).

## API reference

- Create cycle: `POST /rest/atm/1.0/testrun` → `{"key": "PROJ-Cnnn"}`
- Get cycle items: `GET /rest/atm/1.0/testrun/{KEY}` → `items[].id`, `items[].testCaseKey`
- Set item version: `PUT /rest/tests/1.0/testresult/{itemId}` with `{"lastTestCaseVersion": n}`
- Submit result: `POST /rest/atm/1.0/testrun/{KEY}/testcase/{tcKey}/testresult`
- List project versions: `GET /rest/api/2/project/{KEY}/versions`

## Examples

### Input
`/zephyr cycle "Exploratory Testing - MyApp v2.1.0" --version 2.1.0 --rc RC1 --folder "/Exploratory Testing" --results-file /tmp/results.json`

### Output
```
Cycle PROJ-C4565 created
  Version: MyApp 2.1.0 | RC: RC1 | Tests: 15 (v2.0)
  Results: 5 Pass, 10 Blocked
  URL: https://your-jira.example.com/secure/Tests.jspa#/testCycle/PROJ-C4565
```
