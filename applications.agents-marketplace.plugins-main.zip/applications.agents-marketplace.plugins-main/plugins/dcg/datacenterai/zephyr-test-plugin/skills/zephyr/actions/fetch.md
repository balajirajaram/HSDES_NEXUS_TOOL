# `zephyr fetch` — list test cases in a folder

Fetch all test cases from a Zephyr Scale folder and display key, name, steps, and preconditions.

## Arguments

- First arg: folder path (e.g. `"/Exploratory Testing"`, `"/E2E [Functional]/Manual & UI"`)
- Optional: project key (default: from `CLAUDE.md` or env)

## Approach

1. Load credentials per [../references/zephyr-common.md](../references/zephyr-common.md).
2. Query: `GET /rest/atm/1.0/testcase/search?query=folder = "<folder>"&fields=key,name`.
3. For each test case key, fetch full details: `GET /rest/atm/1.0/testcase/{KEY}`.
4. Display a summary table: key, name, step count, precondition snippet.
5. For each test, list steps with `description` and `expectedResult` (HTML-stripped).

## Constraints

- Read-only. Never POST/PUT/DELETE.
- If folder returns 0 results, suggest checking the folder path (no leading project key prefix needed).

## API reference

- Search: `GET /rest/atm/1.0/testcase/search?query=folder = "/path"&fields=key,name`
- Detail: `GET /rest/atm/1.0/testcase/{KEY}`

## Examples

### Input
`/zephyr fetch "/Exploratory Testing"`

### Output
Table of N test cases with keys, names, step counts, then detailed step listing per test.
