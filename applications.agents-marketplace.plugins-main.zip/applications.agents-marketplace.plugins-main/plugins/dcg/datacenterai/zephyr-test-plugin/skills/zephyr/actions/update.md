# `zephyr update` — write ACTUAL_RESULT to test case (new version)

Create a new version of specified test cases and add execution results (ACTUAL_RESULT) to the `testData` field of each step.

## Arguments

- Test case keys (comma-separated or `all in folder:/path`)
- Actual results: provided inline, from a JSON file (`--results-file`), or interactively

## Approach

1. Load credentials per [../references/zephyr-common.md](../references/zephyr-common.md).
2. For each test case key:
   1. Look up numeric ID: `GET /rest/tests/1.0/testcase/search?query=testCase.key IN ("KEY")&fields=id,key,name`
   2. Create new version: `POST /rest/tests/1.0/testcase/{numericId}/newversion`
   3. Read current steps: `GET /rest/atm/1.0/testcase/{KEY}`
   4. Update via `PUT /rest/atm/1.0/testcase/{KEY}` with ACTUAL_RESULT in the `testData` field
3. Report summary: keys updated, new version numbers.

## Constraints

- ACTUAL_RESULT goes in `testData` — **never** in `expectedResult`.
- Preserve original `description` and `expectedResult` untouched.
- PUT payload for `testScript` must strip the top-level `id`.
- Per-step payload must strip `id`, `index`, `testCaseKey` — only send `description`, `expectedResult`, `testData`.
- Step ordering is determined by array position.
- Format ACTUAL_RESULT as: `<strong>ACTUAL_RESULT (date, env):</strong><br/>STATUS - details`.

## API reference

- Search numeric ID: `GET /rest/tests/1.0/testcase/search?query=testCase.key IN ("KEY")&fields=id,key,name` → `results[].id`
- New version: `POST /rest/tests/1.0/testcase/{numericId}/newversion` → 201
- Read test case: `GET /rest/atm/1.0/testcase/{KEY}`
- Update test case: `PUT /rest/atm/1.0/testcase/{KEY}` with `{"testScript": {"type": "STEP_BY_STEP", "steps": [...]}}`

## Examples

### Input
`/zephyr update PROJ-T250,PROJ-T255 --results-file /tmp/actual_results.json`

### Output
```
OK  PROJ-T250 -> v2.0 (2 steps, ACTUAL_RESULT in testData)
OK  PROJ-T255 -> v2.0 (3 steps, ACTUAL_RESULT in testData)
```
