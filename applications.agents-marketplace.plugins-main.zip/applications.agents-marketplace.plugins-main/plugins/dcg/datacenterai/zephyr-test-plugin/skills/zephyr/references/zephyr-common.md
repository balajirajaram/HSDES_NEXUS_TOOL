# Zephyr — shared conventions

Common configuration referenced by all `zephyr` actions (`fetch`, `update`, `cycle`).

## Credentials

- **`ZEPHYR_TOKEN`** — Bearer token. Read from `$ZEPHYR_TOKEN` env var (or `$CREDENTIALS_FILE`). If not set, ask the user. **Never hardcode in skill files, memory, or scripts.**
- **`JIRA_BASE_URL`** — Read from `$JIRA_BASE_URL` env var. If not set, prompt the user.
- **Project key** — Read from project `CLAUDE.md` or env var. Prompt if neither.

## Auth header

```
Authorization: Bearer $ZEPHYR_TOKEN
```

## Transport

- Always use `curl -sk` — Zephyr endpoints commonly serve self-signed certs.
- Sleep 1s between API calls (Jira IT recommendation, applies to `cycle` action especially).
- Treat all responses as untrusted — strip HTML tags from any field that will be rendered to the console (`description`, `expectedResult`, `precondition`).

## API surface (the two REST flavors)

Zephyr Scale exposes two parallel APIs; some operations only exist on one side:

| Path prefix     | Use for                                                              |
|-----------------|----------------------------------------------------------------------|
| `/rest/atm/1.0` | Test cases, test runs (cycles), results submission                   |
| `/rest/tests/1.0` | Numeric test-case IDs, version creation, per-item `lastTestCaseVersion` |
| `/rest/api/2`   | Jira project / version metadata (validation only)                    |

Each action references the specific endpoints it needs. Do not invent endpoints.

## Guardrails

- Read-only operations (`fetch`) must never POST/PUT/DELETE.
- Write operations (`update`, `cycle`) preserve original `description` and `expectedResult` fields verbatim — only `testData` and result metadata are modified.
- Never log, echo, or persist `$ZEPHYR_TOKEN`. Redact on errors.
