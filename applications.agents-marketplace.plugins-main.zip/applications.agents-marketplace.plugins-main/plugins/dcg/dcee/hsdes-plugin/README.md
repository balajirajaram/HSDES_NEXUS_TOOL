# HSDes Plugin

Query Intel HSDes bug tracking system using EQL.

> **Install**
> - **VS Code Copilot Chat (Windows, recommended):** install via the [DCEE MCP Setup VSIX extension](../vsix/README.md) — one-click setup. The extension will prompt to download PowerShell 7 if missing.
> - **Claude Code / GitHub Copilot CLI / Codex CLI:** see [Root README — Installation](../README.md#installation).

## Prerequisites

- **PowerShell 7+** (`pwsh`) on PATH
  - Windows: `winget install Microsoft.PowerShell` (or [Microsoft Store](https://apps.microsoft.com/detail/9mz1snwt0n5d))
  - macOS: `brew install powershell`
  - Linux: [Install guide](https://learn.microsoft.com/en-us/powershell/scripting/install/installing-powershell-on-linux)
  - Verify: `pwsh --version`
- **Intel root certificates (one-time):**
  ```powershell
  cd hsdes-plugin
  pwsh scripts/install_intel_certs.ps1
  ```
  Installs Intel SHA2 + SHA384 root certs into the CurrentUser store (no admin needed). Restart the terminal/IDE afterwards.

## Authentication Modes (Auto-Detected)

- **Default credentials mode** (Windows/Kerberos): `https://hsdes-api.intel.com/rest/...` with `UseDefaultCredentials = $true`. No setup required on domain-joined Windows.
- **Token mode** (Linux/macOS friendly): `https://hsdes-api.intel.com/rest/auth/...` with HTTP Basic. Activated only when both env vars are set:
  ```bash
  export HSDES_USERNAME="your_idsid"
  export HSDES_TOKEN="your_hsdes_token"
  ```
  Or place them in any of: `hsdes-plugin/.env`, repo root `.env`, current working dir `.env`.

## Usage Examples

**Natural language:**
- "Query all open P1 bugs for Google on BHS platform"
- "Find bugs submitted in the last 7 days for DMR"
- "Show bugs owned by henry.y.sun@intel.com's team"
- "Get manager chain for hsun21"
- "Get links for article 14025092168"
- "Run saved query 15013555803"

**EQL direct:**
```
hsdes_query with EQL:
SELECT id, title, owner, status, priority
WHERE tenant = 'server_platf_ae' AND subject = 'bug'
AND server_platf_ae.bug.customer_company EQUALS 'google'
AND release CONTAINS 'birch'
AND status = 'open'
SORTBY submitted_date DESC
```

## MCP Tools

| Tool | Description |
|------|-------------|
| `hsdes_query` | Execute EQL query |
| `hsdes_get_links` | Get article links |
| `hsdes_get_article` | Get article with controllable field set |
| `hsdes_get_article_context` | Source-separated context in one call (basic/description/history/comments) |
| `hsdes_get_comments` | Get article comments |
| `hsdes_get_attachments` | List attachments (HSDes binary + IPS/ESFT links) |
| `hsdes_download_ips_attachment` | Download an IPS/ESFT file by URL |
| `hsdes_upload_ips_attachment` | **WRITE** Upload to ESFT/IPS (dry-run by default) |
| `hsdes_update_article` | **WRITE** Append a comment (dry-run by default) |
| `hsdes_get_saved_query` | Run saved query |
| `hsdes_get_saved_query_definition` | Get saved query definition (title/EQL/owner) |
| `hsdes_email_to_idsid` | Convert email to IDSID |
| `hsdes_get_user_info` | Get user info + manager chain |
| `hsdes_get_current_user` | Get the calling user's IDSID/name/email |
| `hsdes_get_query_template` | Load query template |
| `hsdes_get_images` | Extract embedded images from description/comments |

## MCP Resources

| Resource | Description |
|----------|-------------|
| `hsdes://skill` | Complete EQL query skill guide |
| `hsdes://eql-syntax` | EQL syntax reference |
| `hsdes://field-mappings` | Customer, platform, field mappings |

## Standalone Scripts

The PowerShell scripts in `scripts/` are plain CLI tools — `mcp_server.py` just dispatches to them via subprocess. They can run directly without an MCP client. The upload script ships in two parallel ports (PowerShell + Python) with the same arg surface and JSON output.

### `hsdes_upload_ips_attachment` — upload to ESFT/IPS without opening the SPA

Reverse-engineered chunked-multipart upload (10 MB chunks). Resolves SFDC `caseid` + `visibility` from the article's `server_platf_ae.bug.upload_attach_to_ips`, then POSTs every chunk to `/sftservices/upload/IPS_SFT/`. ESFT auto-mirrors `IPS_SFT` → `HSDES_SFT` so the file appears on the article afterwards (verify with `hsdes_get_attachments`).

**PowerShell:**
```powershell
# Dry-run
pwsh -Command "& { ./hsdes-plugin/scripts/hsdes_upload_ips.ps1 `
    -ArticleId 22015171853 -FilePath C:\tmp\foo.txt `
    -Description 'Test upload' -DryRun:`$true }"

# Live upload, internal visibility
pwsh -Command "& { ./hsdes-plugin/scripts/hsdes_upload_ips.ps1 `
    -ArticleId 22015171853 -FilePath C:\tmp\foo.txt `
    -Description 'Test upload' -Visibility internal }"
```

**Python:**
```bash
pip install requests requests-negotiate-sspi

# Dry-run
python hsdes-plugin/scripts/hsdes_upload_ips.py 22015171853 C:\tmp\foo.txt \
    -d "Test upload" --dry-run

# Live upload, internal visibility
python hsdes-plugin/scripts/hsdes_upload_ips.py 22015171853 C:\tmp\foo.txt \
    -d "Test upload" -v internal
```

> Visibility options: `auto` (first link in the article — usually Public), `public`, `internal`, `partner`. Customer-visible uploads cannot be deleted via this tool — there is no delete API. Always dry-run first.

## Health Checks

```bash
cd hsdes-plugin
python check.py          # all checks
python check.py --env    # environment only
python check.py --skill  # skills validation
python check.py --mcp    # MCP server health
python check.py --e2e    # end-to-end test (requires Intel network)
```

## Troubleshooting

See [TROUBLESHOOTING.md](./TROUBLESHOOTING.md) for detailed solutions.

| Problem | Fix |
|---------|-----|
| `Unexpected "tenant"` | Auto-fixed by MCP server (multi-line → single-line) |
| `Invalid Operator Found` (with `!=`) | Use `NOT_EQUAL` keyword instead of `!=` symbol |
| `Unexpected "FROM"` | No FROM clause — use `WHERE tenant = '...' AND subject = '...'` |
| `SORTBY criteria needs to match` | Add SORTBY field to SELECT clause |
| `pwsh not found` | Install PowerShell 7+: https://aka.ms/powershell |
| `Authentication failed` | Windows mode: refresh Kerberos login. Token mode: verify `HSDES_USERNAME` + `HSDES_TOKEN`. |

**Platform mappings:** DMR/OKS → `'oak'`, BHS/GNR → `'birch'`, EGS/EMR → `'eagle'`
