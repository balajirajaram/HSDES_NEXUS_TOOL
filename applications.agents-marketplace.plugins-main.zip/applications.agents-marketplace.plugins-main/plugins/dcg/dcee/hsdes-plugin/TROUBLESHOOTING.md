# HSDes Plugin Troubleshooting

## Common Errors and Solutions

### 1. "Unexpected 'tenant'" Error

**Cause:** Multi-line EQL query (contains `\n` newlines)

**Solution:** MCP server automatically converts to single-line (no action needed)

**Example:**
```
❌ Bad: "SELECT id\nWHERE tenant = 'server_platf_ae'"
✅ Good: "SELECT id WHERE tenant = 'server_platf_ae'"
```

---

### 2. "Invalid Operator Found" (with `!=`)

**Cause:** Using `!=` symbol instead of `NOT_EQUAL` keyword

**Solution:** Replace `!=` with `NOT_EQUAL`

**Example:**
```
❌ Bad: status != 'complete'
✅ Good: status NOT_EQUAL 'complete'
```

---

### 3. "SORTBY criteria needs to match" Error

**Cause:** SORTBY field not included in SELECT clause

**Solution:** Add the field to SELECT

**Example:**
```
❌ Bad: SELECT id, title WHERE ... SORTBY submitted_date DESC
✅ Good: SELECT id, title, submitted_date WHERE ... SORTBY submitted_date DESC
```

---

### 4. "Syntax Error" with FROM clause

**Cause:** HSDes EQL does NOT support FROM clause

**Solution:** Use WHERE tenant/subject instead

**Example:**
```
❌ Bad: SELECT id FROM server_platf_ae.bug WHERE ...
✅ Good: SELECT id WHERE tenant = 'server_platf_ae' AND subject = 'bug' AND ...
```

---

### 5. No Results or Wrong Platform

**Cause:** Using user abbreviations instead of internal codenames

**Solution:** Use correct platform mappings

**Platform Mappings:**
- DMR/OKS → `'oak'`
- BHS/GNR/SRF → `'birch'`
- EGS/EMR → `'eagle'`

**Example:**
```
❌ Bad: release CONTAINS 'dmr'
✅ Good: release CONTAINS 'oak'
```

---

### 6. MCP Server Not Responding

**Quick Fix:** Restart VSCode completely (File → Exit, then reopen)

**Codex CLI note:** `codex mcp add` writes the server to `~/.codex/config.toml`, but the current Codex session does not hot-load newly added MCP servers. Start a new Codex session after adding `hsdes`, then verify with `codex mcp list`.

**Check Status:**
1. Open VSCode Output panel (Ctrl+Shift+U)
2. Select "MCP" or "GitHub Copilot Chat"
3. Look for: `Starting server hsdes` and `Discovered 3 tools`

---

### 7. Authentication Failed (401)

HSDes scripts support two auth modes:

- **Default credentials mode**: `/rest/...` + `UseDefaultCredentials` (Windows/Kerberos)
- **Token mode**: `/rest/auth/...` + `Authorization: Basic ...` (enabled by `HSDES_USERNAME` + `HSDES_TOKEN`)

#### If you are using default credentials mode

**Cause:** Kerberos ticket expired (common every ~8-10 hours).

**Fix:** Open https://hsdes.intel.com in your browser, complete login, then retry.

#### If you are using token mode

**Cause:** Missing/invalid token env vars or inactive token.

**Fix:**

```bash
export HSDES_USERNAME="your_idsid"
export HSDES_TOKEN="your_hsdes_token"
```

If you prefer `.env`, put the same keys in `hsdes-plugin/.env` or repo root `.env`.

Then retry. If it still fails, regenerate token in HSDes and update `HSDES_TOKEN`.

**Note on Bearer tokens:** HSDes token mode here uses **HTTP Basic auth** with `username:token` against `/rest/auth/...`, not Azure AD bearer tokens.

---

### 8. PowerShell Script Fails

**Check Requirements:**
- PowerShell 7+ installed: `pwsh --version`
- Intel domain authentication (VPN connected)
- Network access to https://hsdes-api.intel.com

**Manual Test:**
```powershell
cd hsdes-plugin
pwsh scripts/hsdes_query.ps1 -Eql "SELECT id WHERE tenant = 'server_platf_ae' AND subject = 'bug' SORTBY id DESC" -MaxResults 3
```

---

## Quick Reference

### Correct Query Template

```eql
SELECT id, title, owner, server_platf_ae.bug.customer_company, submitted_date, release, status, priority
WHERE tenant = 'server_platf_ae' AND subject = 'bug'
AND server_platf_ae.bug.customer_company = 'google'
AND (release CONTAINS 'oak' OR release CONTAINS 'birch' OR release CONTAINS 'eagle')
AND priority = 'p1-showstopper'
SORTBY submitted_date DESC
```

### Common Mappings

| User Input | EQL Value |
|------------|-----------|
| GGL/Google | `'google'` |
| MSFT | `'microsoft'` |
| DMR/OKS | `CONTAINS 'oak'` |
| BHS/GNR | `CONTAINS 'birch'` |
| EGS/EMR | `CONTAINS 'eagle'` |
| P1/critical | `'p1-showstopper'` |
| P2/high | `'p2-high'` |
| closed | `'complete'` |
| open | `'open'` |

---

## Tool Output Format

Successful query:
```
✅ Query successful!
Total results returned: 24
Max results limit: 10

{JSON data}
```

Failed query:
```
❌ EQL Syntax Error:
Error 2: Unexpected "tenant"
```
