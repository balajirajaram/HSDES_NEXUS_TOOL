"""HSDes Plugin Health Checks."""

import asyncio
import argparse
import shutil
import subprocess
import sys
from pathlib import Path

PLUGIN_DIR = Path(__file__).parent
SCRIPTS_DIR = PLUGIN_DIR / "scripts"
SKILLS_DIR = PLUGIN_DIR / "skills"
REFS_DIR = PLUGIN_DIR / "references"

REQUIRED_SCRIPTS = ["hsdes_query.ps1", "hsdes_links.ps1", "hsdes_saved_query.ps1", "hsdes_auth.ps1"]
REQUIRED_REFS = [
    "field-mappings.md", "eql-syntax.md",
    "irf-firmware-query.md", "irf-platform-query.md",
    "irf-dmr-ptp-soc-query.md", "irf-dmr-cfm-bug-query.md",
]


def _find_pwsh() -> str | None:
    """Return pwsh path if found, else None. Checks common locations first."""
    # Try common Windows locations first (bypasses PATH issues)
    common_paths = [
        Path.home() / "AppData/Local/Microsoft/WindowsApps/pwsh.exe",
        Path("C:/Program Files/PowerShell/7/pwsh.exe"),
    ]
    for pwsh_path in common_paths:
        if pwsh_path.exists():
            return str(pwsh_path)

    # Fallback to PATH search
    return shutil.which("pwsh")


def _pass(msg: str) -> None:
    print(f"  PASS  {msg}")


def _fail(msg: str) -> None:
    print(f"  FAIL  {msg}")


def _skip(msg: str) -> None:
    print(f"  SKIP  {msg}")


async def _get_server_capability_counts(server) -> dict[str, int]:
    """Return registered MCP capability counts for the instantiated server."""
    async def _count(*method_names: str) -> int:
        for method_name in method_names:
            method = getattr(server, method_name, None)
            if method is None:
                continue
            items = await method()
            return len(items)
        raise AttributeError(f"Server missing capability methods: {method_names}")

    return {
        "tools": await _count("list_tools", "get_tools"),
        "resources": await _count("list_resources", "get_resources"),
        "resource_templates": await _count("list_resource_templates", "get_resource_templates"),
    }


def check_env() -> int:
    """Check environment dependencies."""
    print("\n[Environment Checks]")
    errors = 0

    # Python version
    v = sys.version_info
    if v >= (3, 10):
        _pass(f"Python {v.major}.{v.minor}.{v.micro}")
    else:
        _fail(f"Python {v.major}.{v.minor} < 3.10 required")
        errors += 1

    # pwsh
    pwsh = _find_pwsh()
    if pwsh:
        try:
            result = subprocess.run(
                [pwsh, "-Command", "$PSVersionTable.PSVersion.ToString()"],
                capture_output=True, text=True, timeout=10
            )
            ver = result.stdout.strip()
            _pass(f"pwsh {ver} at {pwsh}")
        except Exception as e:
            _fail(f"pwsh found but failed: {e}")
            errors += 1
    else:
        _fail("pwsh not found. Install: https://aka.ms/powershell")
        errors += 1

    # fastmcp
    try:
        import fastmcp
        _pass(f"fastmcp {getattr(fastmcp, '__version__', 'installed')}")
    except ImportError:
        _fail("fastmcp not installed. Run: pip install fastmcp")
        errors += 1

    return errors


def check_skill() -> int:
    """Validate skills and references."""
    print("\n[Skills Validation]")
    errors = 0

    # SKILL.md exists
    skill_md = SKILLS_DIR / "hsdes-query" / "SKILL.md"
    if skill_md.exists():
        content = skill_md.read_text(encoding="utf-8")
        # Check frontmatter
        if content.startswith("---"):
            lines = content.split("---", 2)
            if len(lines) >= 3 and "name:" in lines[1] and "description:" in lines[1]:
                _pass("skills/SKILL.md frontmatter valid")
            else:
                _fail("skills/SKILL.md frontmatter missing name or description")
                errors += 1
        else:
            _fail("skills/SKILL.md missing frontmatter (---)")
            errors += 1
    else:
        _fail("skills/SKILL.md not found")
        errors += 1

    # Reference files
    for ref in REQUIRED_REFS:
        path = REFS_DIR / ref
        if path.exists():
            _pass(f"references/{ref}")
        else:
            _fail(f"references/{ref} not found")
            errors += 1

    return errors


def check_mcp() -> int:
    """Check MCP server can start."""
    print("\n[MCP Server Health]")
    errors = 0

    try:
        sys.path.insert(0, str(PLUGIN_DIR))
        from mcp_server import mcp as server
        _pass(f"mcp_server.py imports OK (server: {server.name})")
    except Exception as e:
        _fail(f"mcp_server.py import failed: {e}")
        errors += 1
        return errors

    try:
        counts = asyncio.run(_get_server_capability_counts(server))
        _pass(
            "registered capabilities: "
            f"{counts['tools']} tools, "
            f"{counts['resources']} resources, "
            f"{counts['resource_templates']} resource templates"
        )
    except Exception:
        _skip("capability count unavailable (FastMCP version too old)")

    # Check scripts exist
    for script in REQUIRED_SCRIPTS:
        path = SCRIPTS_DIR / script
        if path.exists():
            _pass(f"scripts/{script}")
        else:
            _fail(f"scripts/{script} not found")
            errors += 1

    return errors


def check_e2e() -> int:
    """Run end-to-end test query."""
    print("\n[End-to-End Test]")

    pwsh = _find_pwsh()
    if not pwsh:
        _skip("pwsh not available, skipping e2e test")
        return 0

    test_script = SCRIPTS_DIR / "test_query.ps1"
    if not test_script.exists():
        _skip("test_query.ps1 not found, skipping e2e test")
        return 0

    try:
        result = subprocess.run(
            [pwsh, "-NoProfile", "-File", str(test_script)],
            capture_output=True, text=True, timeout=30
        )
        if result.returncode == 0:
            _pass("e2e test query succeeded")
            return 0
        else:
            _fail(f"e2e test query failed: {result.stderr.strip()}")
            return 1
    except subprocess.TimeoutExpired:
        _fail("e2e test query timed out")
        return 1
    except Exception as e:
        _fail(f"e2e test query error: {e}")
        return 1


def main():
    parser = argparse.ArgumentParser(description="HSDes Plugin Health Checks")
    parser.add_argument("--env", action="store_true", help="Environment checks only")
    parser.add_argument("--skill", action="store_true", help="Skills validation only")
    parser.add_argument("--mcp", action="store_true", help="MCP server health only")
    parser.add_argument("--e2e", action="store_true", help="End-to-end test only")
    args = parser.parse_args()

    run_all = not any([args.env, args.skill, args.mcp, args.e2e])
    total_errors = 0

    print("HSDes Plugin Health Checks")
    print("=" * 40)

    if run_all or args.env:
        total_errors += check_env()
    if run_all or args.skill:
        total_errors += check_skill()
    if run_all or args.mcp:
        total_errors += check_mcp()
    if run_all or args.e2e:
        total_errors += check_e2e()

    print("\n" + "=" * 40)
    if total_errors == 0:
        print("All checks passed!")
    else:
        print(f"{total_errors} check(s) failed.")
    return 1 if total_errors else 0


if __name__ == "__main__":
    sys.exit(main())
