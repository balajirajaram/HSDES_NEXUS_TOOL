# hsdes-plugin v2.0.0 Plan — deferred

**Status:** deferred until v1.1.8 (HTML→text dual-mode) ships and stabilizes. Not urgent — pure structural cleanup, no functional bug.

## Goal

Merge `hsdes_get_article_context` into `hsdes_get_article`. Remove the duplicate.

## Why

Two tools with overlapping use-cases:

| Tool | Current behavior |
|---|---|
| `hsdes_get_article` | flat HSDes JSON (`{data: [{...all fields...}]}`) + text preamble |
| `hsdes_get_article_context` | source-separated JSON (`{article_basic, description, ext_cust_blog_hist, comments}`); calls `get_article` + optionally `get_comments` internally |

LLMs pick the wrong one based on naming intuition (e.g. `_context` suggests "more info"; `_article` suggests "simple"). Docstring guards alone (Option A from the original brainstorm) help but don't eliminate the ambiguity. Cleanest fix is to have ONE tool.

## Target API (post-merge)

```python
@mcp.tool()
def hsdes_get_article(
    article_id: str,
    include_description: bool = False,
    include_customer_history: bool = False,
    include_comments: bool = False,         # ← absorbed from _context
    fields: list[str] | None = None,
    comment_fields: list[str] | None = None,  # ← absorbed
    max_comments: int = 200,                  # ← absorbed
) -> str:
```

Return shape — **always** source-separated (this is the breaking change vs. v1.x flat output):

```json
{
  "hsd_id": "14027610565",
  "url": "https://hsdes.intel.com/...",
  "article_basic": {
    "title": "...",
    "owner": "...",
    "status": "...",
    "priority": "...",
    "...other metadata..."
  },
  "description": "..." | null,
  "ext_cust_blog_hist": "..." | null,
  "comments": [...] | null,
  "comments_total": N,
  "comments_truncated": N
}
```

## Removal

- Delete `hsdes_get_article_context` entirely. No alias.
- Tool count: 16 → 15.

## Files to update (5)

1. `hsdes-plugin/mcp_server.py` — refactor `hsdes_get_article` signature + return; delete `hsdes_get_article_context` block (~100 lines).
2. `hsdes-plugin/tests/test_article.py` — convert `test_get_article_*` (flat → source-separated); rename `test_get_article_context_*` → `test_get_article_with_comments`.
3. `hsdes-plugin/tests/test_base64_strip.py` — update `test_get_article_context_inherits_strip_from_inner_calls` to use new signature.
4. `hsdes-plugin/README.md` — remove `hsdes_get_article_context` row, update `hsdes_get_article` description.
5. `hsdes-plugin/CLAUDE.md` — same; update tool count "MCP Tools (16 total)" → "(15 total)".
6. `hsdes-plugin/skills/hsdes-query/SKILL.md` — replace any mention of `hsdes_get_article_context` with `hsdes_get_article(include_comments=True)`.

Plus the standard 3-place version sync:
- `hsdes-plugin/.claude-plugin/plugin.json`
- `hsdes-plugin/mcp_server.py` `_VERSION`
- `.claude-plugin/marketplace.json`

## Risks

1. **Cache mismatch** — users with cached old version will see their LLM call `hsdes_get_article_context` and get tool-not-found. The MCP startup log will show v2.0.0 and the AI's tool list will be fresh, so the next call will switch to the new API. Tolerable.
2. **External skills/scripts** — repo grep already cleared (5 internal files, no external refs). Safe.
3. **Should `hsdes_get_comments` also fold in?** — open question. `hsdes_get_article(include_comments=True)` would cover most cases, but `hsdes_get_comments` is also called directly when only comments are needed (no metadata). Keeping it as a separate concern matches the source-separation principle. **Decision pending — leaving `hsdes_get_comments` as-is for now.**

## Why deferred (not bundled with v1.1.8)

- v1.1.8 is a critical bug fix (HTML→text resolves malformed-JSON pain). Ship-blocking concerns shouldn't be coupled with structural cleanup.
- Risk isolation — if HTML→text needs revert, we don't drag down the merge too.
- Smaller PRs review faster.
- v2 has no functional urgency; the LLM-confusion problem is real but not user-facing pain.

## Open design questions for v2 implementation

- Keep text preamble (`Article: 14027610565\n  Tenant: ...\n`)? Currently in `hsdes_get_article` for human readability; redundant once `article_basic` exists. **Lean: drop it.**
- `source_notes` array in current `hsdes_get_article_context` — useful for AI but adds noise. **Lean: keep, AI references it correctly.**
- Should `comments` ever be returned without metadata? No — keep `article_basic` always present.
