"""HSDes MCP Server - Query Intel HSDes bug tracking system."""

import re
import sys
import shutil
import subprocess
import webbrowser
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

# Fix Windows encoding issues - force UTF-8 for stdout/stderr
if sys.platform == "win32":
    import io
    if isinstance(sys.stdout, io.TextIOWrapper):
        sys.stdout.reconfigure(encoding='utf-8')
    if isinstance(sys.stderr, io.TextIOWrapper):
        sys.stderr.reconfigure(encoding='utf-8')

# Fix proxy env vars with trailing newlines (breaks httpx URL parsing)
import os as _os
for _k in ('HTTP_PROXY', 'HTTPS_PROXY', 'NO_PROXY', 'http_proxy', 'https_proxy', 'no_proxy'):
    _v = _os.environ.get(_k)
    if _v and _v != _v.strip():
        _os.environ[_k] = _v.strip()


def _ensure_packages(*packages):
    """Auto-install missing packages using Intel proxy."""
    import importlib.util
    missing = [p for p in packages if importlib.util.find_spec(p) is None]
    if missing:
        import os as _os
        _proxy = _os.environ.get("HTTPS_PROXY") or _os.environ.get("HTTP_PROXY") or "http://proxy-dmz.intel.com:912"
        print(f"[hsdes] Auto-installing: {missing}", file=sys.stderr)
        subprocess.run(
            [sys.executable, "-m", "pip", "install",
             "--isolated",
             f"--proxy={_proxy}",
             "--index-url=https://pypi.org/simple/"] + missing,
            check=True
        )

_ensure_packages("fastmcp")

from fastmcp import FastMCP  # noqa: E402

_VERSION = "1.4.3"

mcp = FastMCP(
    "hsdes",
    version=_VERSION,
    instructions="""Query Intel HSDes bug tracking system using EQL.

CRITICAL SYNTAX RULES:
0. EQL MUST start with SELECT fields WHERE ... (SELECT is REQUIRED — no SELECT = syntax error)
1. Operators MUST be uppercase: CONTAINS, EQUALS, NOT_EQUAL, SORTBY, REPORTS_TO
2. Strings MUST use single quotes: 'google' (NOT "google")
3. Use NOT_EQUAL keyword (NOT != symbol)
4. NO FROM clause - use WHERE tenant='...' AND subject='...'
5. Parentheses ARE supported: (release CONTAINS 'oak' OR release CONTAINS 'birch')
6. Use DESC/ASC for sorting
7. SORTBY fields MUST be in SELECT clause
8. DATE FIELDS: CONTAINS does NOT work on date fields (causes ElasticSearch error). Use >= / < range instead.
   WRONG: submitted_date CONTAINS '2026-04'
   RIGHT: submitted_date >= '2026-04-01' AND submitted_date < '2026-05-01'
9. TENANT-SCOPED FIELDS IN SELECT: Fields like server_platf_ae.bug.customer_company work at the API level
   but cause a client-side TypeError in Copilot Chat MCP when the dotted-key JSON is parsed. Use AS alias.
   The AS shortname MUST be a trailing suffix of the fullname (spec rule):
     valid:   server_platf_ae.bug.customer_company AS 'customer_company'       ✓
     valid:   server_platf_ae.bug.customer_company AS 'bug.customer_company'   ✓
     invalid: server_platf_ae.bug.customer_company AS 'company'                ✗ (not a suffix)
   WRONG: SELECT id, title, server_platf_ae.bug.customer_company WHERE ...
   RIGHT: SELECT id, title, server_platf_ae.bug.customer_company AS 'customer_company' WHERE ...

OWNER QUERIES — self / team / manager:

SELF ("my bugs", "owned by me", "owner is me"):
  Use the literal `owner is me` operator — server-side resolves the caller.
  DO NOT call hsdes_get_current_user just to insert the idsid.
  Example:
    SELECT id, title, owner, submitted_date
    WHERE tenant='server_platf_ae' AND subject='bug'
      AND owner is me
    SORTBY submitted_date DESC

TEAM/MANAGER ("user's team", "manager's reports"):
Step 1: If user provides email → call hsdes_email_to_idsid('email@intel.com') to get IDSID
Step 2: Use IDSID in query with REPORTS_TO operator:
        WHERE owner REPORTS_TO 'idsid'

IMPORTANT:
- Fields like team=, manager=, owner_ldap_group=, subscribers=, involved_people= DO NOT EXIST
- For self → `owner is me`. For others/teams → `owner REPORTS_TO 'idsid'` (or `owner = 'idsid'` for one user)
- Example: "henry.y.sun@intel.com's team" → call hsdes_email_to_idsid('henry.y.sun@intel.com') → use 'hsun21' → WHERE owner REPORTS_TO 'hsun21'

COMMON MAPPINGS:
- Customers: GGL='google', MSFT='microsoft', Dell='dell', HPE='hp_enterprise'
- Priority: P1='p1-showstopper', P2='p2-high', P3='p3-medium'
- Status: closed='complete', open='open'
- subject='feature' = CCB (post-silicon) or POR (plan of record); use server_platf.feature

COMMON MISTAKES — DO NOT DO THESE:
- NEVER SELECT 'url' — it is NOT an HSDes field. URLs are derived from id:
  https://hsdes.intel.com/appstore/article-one/#/article/{id}
- NEVER SELECT 'parent_id' — it is NOT an HSDes field. For article relationships
  (parent/child/duplicate/linked), call hsdes_get_links(article_id='...') instead.
- NEVER SELECT 'team', 'manager', 'owner_ldap_group', 'subscribers', 'involved_people'
  — none exist. For team/manager queries use owner REPORTS_TO 'idsid'.
- Invalid fields are silently stripped by HSDes (returned in invalidFields) — you will
  NOT see an error, just missing columns in the result. Always double-check field names.
- If user specifies a platform (OKS/DMR/BHS/GNR/SPR/EMR/SRF/CWF), the query MUST
  include a release filter for that tenant — see RELEASE FILTERS below. Missing the
  release filter returns bugs from ALL platforms/eras, not what the user asked for.

RELEASE FILTERS — differ by tenant (CRITICAL: wrong tenant = zero results). CONTAINS is case-insensitive:
server_platf_ae.bug / server_platf.bug / server_platf.feature:
  DMR=CONTAINS 'DMR', GNR=CONTAINS 'GNR', SRF=CONTAINS 'SRF', CWF=CONTAINS 'CWF'
  All OKS=CONTAINS 'Oak Stream', All BHS=CONTAINS 'Birch Stream', EMR=CONTAINS 'EMR'
central_firmware.bug / central_firmware.feature:
  OKS+DMR=CONTAINS 'oakstream_diamondrapids', BHS+GNR=CONTAINS 'graniterapids'
  All OKS=CONTAINS 'oakstream', All BHS=CONTAINS 'birchstream'
sighting_central.sighting:
  DMR=CONTAINS 'dmr', GNR=CONTAINS 'gnr', CWF=CONTAINS 'cwf', SRF=CONTAINS 'srf'

IRF QUERIES (CRITICAL WORKFLOW — do NOT write custom EQL for IRF meetings!):
When user asks about IRF, bug review meeting, BIOS IRF, firmware IRF, or platform IRF:
Step 1: Call hsdes_get_query_template with the matching template name:
  - 'firmware-irf'  → OKS+BHS BIOS ASIA IRF (saved query 15018339809)
  - 'platform-irf'  → Platform IRF All Geos (saved query 15013555803)
  - 'hsio-irf'      → HSIO IRF BHS/OKS PCIe/CXL APAC (saved query 15017467796)
  - 'memory-irf'    → Memory IRF BHS/OKS Memory APAC (saved query 15015935984)
  - 'dmr-ptp'       → DMR PTP_SoC sightings
  - 'dmr-cfm'       → DMR central_firmware bugs
Step 2: The tool returns the saved query EQL + output format. Execute with hsdes_get_saved_query.
NEVER query central_firmware.bug or server_platf_ae.bug directly for IRF — use the templates.

QUERY TEMPLATES:
-- server_platf_ae.bug (default) --
SELECT id, title, owner, server_platf_ae.bug.customer_company, submitted_date, release, status, priority
WHERE tenant = 'server_platf_ae' AND subject = 'bug'
AND owner REPORTS_TO 'hsun21'
AND (release CONTAINS 'DMR' OR release CONTAINS 'Birch Stream')
AND priority = 'p1-showstopper'
SORTBY submitted_date DESC

-- sighting_central.sighting --
SELECT id, title, owner, release, status, priority, submitted_date
WHERE tenant = 'sighting_central' AND subject = 'sighting'
AND release CONTAINS 'dmr'
SORTBY submitted_date DESC

-- central_firmware.bug --
SELECT id, title, owner, release, status, priority, submitted_date
WHERE tenant = 'central_firmware' AND subject = 'bug'
AND release CONTAINS 'oakstream_diamondrapids'
SORTBY submitted_date DESC

SAVED QUERY URL ROUTING (CRITICAL):
When user provides any URL containing a saved query ID:
  - https://hsdes.intel.com/appstore/community/#/query?queryId={id}
  - https://hsdes.intel.com/appstore/community_legacy/#/{id}?queryId={id}
  - Any URL with ?queryId={id} or /#/{numeric_id}
Extract the numeric ID and call hsdes_get_saved_query(query_id='{id}') DIRECTLY.
DO NOT call hsdes_get_saved_query_definition first.
DO NOT ask the user for more info — extract the ID from the URL and execute.

ARTICLE READ WORKFLOW (SOURCE-SEPARATED, CRITICAL):
- For base metadata: hsdes_get_article(article_id='...') with default fields
- For description: hsdes_get_article(article_id='...', include_description=True)
- For customer history thread: hsdes_get_article(article_id='...', include_customer_history=True)
- For comments: hsdes_get_comments(article_id='...')
- Never mix up ext_cust_blog_hist and comments; they are different sources and must be reported separately.

Tool returns "✅ Query successful!" or "❌ Query failed:" prefix.
""",
)

SCRIPT_DIR = Path(__file__).parent / "scripts"
SKILLS_DIR = Path(__file__).parent / "skills"
REFS_DIR = Path(__file__).parent / "references"

# Threshold (in chars) above which _run_ps1 spools a string param to a temp
# file instead of passing via argv. Windows CreateProcess command-line cap is
# ~32KB, but the cap covers the entire cmdline including pwsh path + script
# path + other params + quoting. 8 KB per individual arg leaves comfortable
# headroom even when multiple large args are passed in one call.
_PS1_LARGE_ARG_THRESHOLD = 8 * 1024

PWSH_NOT_FOUND = (
    "PowerShell 7+ (pwsh) not found in PATH.\n"
    "Install: https://aka.ms/powershell\n"
    "  Windows: winget install Microsoft.PowerShell\n"
    "  macOS:   brew install powershell\n"
    "  Linux:   https://learn.microsoft.com/en-us/powershell/scripting/install/installing-powershell-on-linux"
)


def _find_pwsh() -> str | None:
    """Return pwsh path if found, else None."""
    # Try common Windows locations first (bypasses PATH issues)
    common_paths = [
        Path.home() / "AppData/Local/Microsoft/WindowsApps/pwsh.exe",
        Path("C:/Program Files/PowerShell/7/pwsh.exe"),
    ]
    for pwsh_path in common_paths:
        if pwsh_path.exists():
            return str(pwsh_path)

    # Fallback to PATH search
    return shutil.which("pwsh")


def _run_ps1(script_name: str, **params: str) -> str:
    """Run a PowerShell script and return its stdout as string.

    Large parameter values (e.g. base64-embedded screenshots in comments)
    overflow the Windows CreateProcess command-line cap (~32KB). When a
    string value exceeds _PS1_LARGE_ARG_THRESHOLD, we spool it to a UTF-8
    temp file and pass `-{Key}File <path>` instead of `-{Key} <value>`.
    The PS1 script must opt in by accepting the matching `-{Key}File`
    parameter and reading the file when set — see hsdes_update_article.ps1
    for the canonical pattern.
    """
    pwsh = _find_pwsh()
    if not pwsh:
        return PWSH_NOT_FOUND

    script = SCRIPT_DIR / script_name
    if not script.exists():
        return f"Script not found: {script}"

    import tempfile
    cmd = [pwsh, "-NoProfile", "-File", str(script)]
    temp_files: list[str] = []
    for key, value in params.items():
        if isinstance(value, bool):
            # [switch]/[bool] params need colon syntax with -File: -Flag:true / -Flag:false
            cmd.append(f"-{key}:{'true' if value else 'false'}")
            continue
        sval = str(value)
        if len(sval) > _PS1_LARGE_ARG_THRESHOLD:
            fd, tpath = tempfile.mkstemp(prefix=f"hsdes_{key}_", suffix=".arg")
            try:
                with _os.fdopen(fd, "wb") as f:
                    f.write(sval.encode("utf-8"))
            except Exception:
                _os.close(fd)
                raise
            temp_files.append(tpath)
            cmd.extend([f"-{key}File", tpath])
        else:
            cmd.extend([f"-{key}", sval])

    try:
        result = subprocess.run(
            cmd, capture_output=True, timeout=120
        )
        # Decode as UTF-8 with replacement to handle mixed encodings from
        # PowerShell (HSDes data may contain non-UTF-8 bytes like 0xFF).
        # Guard against None (observed on Windows under FastMCP stdio transport).
        stdout = (result.stdout or b'').decode('utf-8', errors='replace')
        stderr = (result.stderr or b'').decode('utf-8', errors='replace')

        # Retry once on transient 401 in default-credentials mode (SSPI / KDC
        # cache race after klist purge, brief KDC blip). Token mode skips —
        # a 401 there is a real credential problem, not transient.
        if (result.returncode != 0
                and ("401" in stderr or "Unauthorized" in stderr)
                and not (_os.environ.get("HSDES_USERNAME") and _os.environ.get("HSDES_TOKEN"))):
            result = subprocess.run(cmd, capture_output=True, timeout=120)
            stdout = (result.stdout or b'').decode('utf-8', errors='replace')
            stderr = (result.stderr or b'').decode('utf-8', errors='replace')

        if result.returncode != 0:
            stderr = stderr.strip()
            # Check for clear failure markers
            if "=== QUERY FAILED ===" in stderr:
                return stderr  # Return formatted error message
            if "401" in stderr or "Unauthorized" in stderr:
                has_token_auth = bool(_os.environ.get("HSDES_USERNAME") and _os.environ.get("HSDES_TOKEN"))
                if has_token_auth:
                    return "❌ Authentication failed in token mode. Verify HSDES_USERNAME/HSDES_TOKEN and ensure the HSDES token is active."
                if sys.platform == "win32":
                    webbrowser.open("https://hsdes.intel.com")
                    return "❌ Authentication failed. Kerberos ticket may have expired. Opening https://hsdes.intel.com in your browser — please log in, then retry."
                return "❌ Authentication failed. Kerberos ticket may have expired. Log in to https://hsdes.intel.com and retry, or set HSDES_USERNAME/HSDES_TOKEN for token mode."
            if "Unable to connect" in stderr or "network" in stderr.lower():
                return "❌ Cannot connect to HSDes API. Check network connectivity."
            if "Syntax Error" in stderr or "Error " in stderr:
                return f"❌ EQL Syntax Error:\n{stderr}"
            return f"❌ Query failed:\n{stderr}"

        # Check for success marker and parse output
        stdout = stdout.strip()
        if "=== QUERY SUCCESS ===" in stdout:
            # Extract summary and results
            lines = stdout.split('\n')
            summary = []
            json_start = None
            for i, line in enumerate(lines):
                if line.startswith("Total results") or line.startswith("Max results"):
                    summary.append(line)
                elif line == "=== RESULTS ===":
                    json_start = i + 1
                    break

            if json_start and json_start < len(lines):
                json_data = '\n'.join(lines[json_start:])
                return f"✅ Query successful!\n{chr(10).join(summary)}\n\n{json_data}"

        return stdout
    except subprocess.TimeoutExpired:
        return "❌ Query timed out after 120 seconds."
    except Exception as e:
        import traceback as _tb
        return f"❌ Unexpected error: {e}\n\nTraceback:\n{_tb.format_exc()}"
    finally:
        for tpath in temp_files:
            try:
                _os.unlink(tpath)
            except OSError:
                pass


def _parse_ps1_json(raw: str) -> dict | None:
    """Extract and parse JSON from mixed PS output (Write-Host text + JSON).

    PowerShell scripts output Write-Host info lines before the JSON body.
    This helper finds the first '{' and parses from there.
    PowerShell ConvertTo-Json sometimes leaves unescaped control chars
    in HTML strings (\t, \r, \n etc.), so we sanitize before parsing.
    """
    import json as _json
    m = re.search(r'\{[\s\S]*\}', raw)
    if not m:
        return None
    text = m.group()
    try:
        return _json.loads(text)
    except _json.JSONDecodeError:
        pass
    # Retry: sanitize unescaped control characters inside JSON strings
    # Replace raw control chars (0x00-0x1f except already-escaped ones) with spaces
    sanitized = re.sub(r'[\x00-\x08\x0b\x0c\x0e-\x1f]', ' ', text)
    try:
        return _json.loads(sanitized)
    except _json.JSONDecodeError:
        return None


# --- MCP Tools ---


@mcp.tool()
def hsdes_query(eql: str, max_results: int = 200) -> str:
    """Execute HSDes EQL query. EQL MUST include: tenant='...', subject='...', and SELECT clause. Default tenant='server_platf_ae', subject='bug'. For owned-by-me queries: use `owner is me` directly (server resolves the caller — no hsdes_get_current_user call needed). For team queries: get IDSID via hsdes_email_to_idsid, then use owner REPORTS_TO 'idsid'. Release filters differ by tenant — see server instructions. Priority: P1='p1-showstopper', P2='p2-high'."""
    # HSDes EQL parser does NOT support multi-line queries - convert to single line
    eql = " ".join(eql.split())
    # Strip invalid FROM clause (LLMs hallucinate SQL-style FROM; EQL uses WHERE tenant=...)
    eql = re.sub(r'\bFROM\s+\S+\s+(?=WHERE\b)', '', eql, flags=re.IGNORECASE)
    results = _run_ps1("hsdes_query.ps1", Eql=eql, MaxResults=max_results)
    return _add_article_urls(_enrich_owners(results))


@mcp.tool()
def hsdes_get_links(article_id: str) -> str:
    """Get related links for an HSDes article. Excludes folder/hierarchy noise — only returns meaningful links (related-link, cloned-to, etc.).

    Args:
        article_id: The HSDes article ID (numeric string).
    """
    import json
    import re

    raw = _run_ps1("hsdes_links.ps1", ArticleId=article_id)

    # Extract JSON block from mixed PS output (Write-Host text + JSON)
    m = re.search(r'\{[\s\S]*\}', raw)
    if not m:
        return raw

    try:
        data = json.loads(m.group())
        links = [r for r in data.get("responses", [])
                 if r.get("subject") != "folder" and r.get("relationship") != "child-parent"]
        if not links:
            return f"No related links found for article {article_id}."
        lines = [f"Related links for article {article_id}:\n"]
        for r in links:
            lines.append(f"ID: {r['id']}")
            lines.append(f"  Title: {r.get('title', '')}")
            lines.append(f"  Tenant.Subject: {r.get('tenant', '')}.{r.get('subject', '')}")
            lines.append(f"  Relationship: {r.get('relationship', '')} | Status: {r.get('status', '')}")
            lines.append("")
        return "\n".join(lines)
    except Exception:
        return raw


# Default fields for hsdes_get_article — excludes heavy fields (description, comments, ext_cust_blog_hist).
# server_platf_ae.bug.customer_company is included; other tenants return it in "invalidFields" (stripped below).
_ARTICLE_DEFAULT_FIELDS = (
    "id,tenant,subject,title,owner,submitted_date,release,status,component,"
    "updated_date,priority,tag,"
    "server_platf_ae.bug.customer_company,"
    "server_platf_ae.bug.customer_project_name,"
    "server_platf_ae.bug.ext_source_id,"
    "server_platf_ae.bug.int_sighting_url,"
    "server_platf_ae.bug.odm,"
    "server_platf_ae.bug.ext_attach_url"
)
_EXT_CUST_BLOG_HIST_FIELD = "server_platf_ae.bug.ext_cust_blog_hist"

# Heavy fields that hsdes_get_saved_query strips by default to avoid token overflow.
# Saved queries can include these as output columns; on multi-row results the full
# HTML/text body of each ticket would otherwise blow up the response.
_SAVED_QUERY_BOMB_FIELDS = (
    "description",
    "comments",
    "ext_cust_blog_hist",
    "server_platf_ae.bug.ext_cust_blog_hist",
)


def _strip_saved_query_bomb_fields(
    text: str,
    include_description: bool,
    include_comments: bool,
    include_customer_history: bool,
) -> tuple[str, dict[str, int]]:
    """Strip heavy fields from saved query rows unless explicitly opted in.

    Returns (json_text, {field: rows_with_non_empty_value}).
    On parse failure, returns the input unchanged with empty counts.
    """
    import json as _json_mod

    keep: set[str] = set()
    if include_description:
        keep.add("description")
    if include_comments:
        keep.add("comments")
    if include_customer_history:
        keep.add("ext_cust_blog_hist")
        keep.add("server_platf_ae.bug.ext_cust_blog_hist")

    targets = [f for f in _SAVED_QUERY_BOMB_FIELDS if f not in keep]
    if not targets:
        return text, {}

    try:
        # strict=False tolerates raw control chars HSDes embeds in HTML fields
        obj = _json_mod.loads(text, strict=False)
    except Exception:
        return text, {}

    rows = obj.get("data") if isinstance(obj, dict) else obj
    if not isinstance(rows, list):
        return text, {}

    counts = {f: 0 for f in targets}
    for row in rows:
        if not isinstance(row, dict):
            continue
        for f in targets:
            if f in row:
                if row[f]:
                    counts[f] += 1
                row.pop(f)

    counts = {k: v for k, v in counts.items() if v > 0}
    return _json_mod.dumps(obj, ensure_ascii=False), counts


# Inline base64 images embedded in HSDes HTML fields (description, comments,
# ext_cust_blog_hist) are a token bomb on their own — a single customer-pasted
# screenshot can be 100KB+. Replace with a self-documenting placeholder; the
# inline_id (sha256[:12] of base64 chars) lets the caller correlate the
# placeholder with the corresponding entry returned by hsdes_get_images.
_RE_BASE64_IMAGE = re.compile(r'data:image/([\w+.\-]+);base64,([A-Za-z0-9+/=]+)')


def _inline_image_id(b64_data: str) -> str:
    """Stable 12-char id derived from the base64 payload. Same image → same id across calls."""
    import hashlib
    return hashlib.sha256(b64_data.encode("ascii")).hexdigest()[:12]


def _strip_base64_images(text: str) -> tuple[str, dict[str, int]]:
    """Replace `data:image/<type>;base64,<chars>` URIs with a `[base64-image-stripped:...]`
    placeholder. Returns (cleaned_text, {"count": N, "bytes_saved": M}).

    Safe to apply to JSON-encoded text: base64 alphabet (A-Z a-z 0-9 + / =) and the
    placeholder contain no JSON-meaningful chars (", \\, control chars), so structural
    boundaries are preserved.
    """
    if "data:image/" not in text:
        return text, {"count": 0, "bytes_saved": 0}

    count = 0
    bytes_saved = 0

    def _replace(m: re.Match) -> str:
        nonlocal count, bytes_saved
        url = m.group(0)
        img_type = m.group(1)
        b64_data = m.group(2)
        inline_id = _inline_image_id(b64_data)
        original_len = len(url)
        placeholder = (
            f"[base64-image-stripped:id={inline_id},type={img_type},bytes={original_len} "
            f"— call hsdes_get_images(article_id) to extract]"
        )
        bytes_saved += original_len - len(placeholder)
        count += 1
        return placeholder

    cleaned = _RE_BASE64_IMAGE.sub(_replace, text)
    return cleaned, {"count": count, "bytes_saved": bytes_saved}


def _extract_inline_base64_images(html: str) -> list[dict]:
    """Find all inline base64 images in HTML. Returns list of {inline_id, type, b64_data}.

    The base64 chars themselves are kept in b64_data so the caller can decode + persist.
    """
    if not html or "data:image/" not in html:
        return []
    out = []
    for m in _RE_BASE64_IMAGE.finditer(html):
        img_type = m.group(1)
        b64_data = m.group(2)
        out.append({
            "inline_id": _inline_image_id(b64_data),
            "type": img_type,
            "b64_data": b64_data,
        })
    return out


def _strip_invalid_fields(text: str) -> str:
    """Remove the 'invalidFields' key from HSDes API responses (cross-tenant artifact)."""
    import json as _json_mod
    try:
        obj = _json_mod.loads(text)
        if isinstance(obj, dict) and "invalidFields" in obj:
            del obj["invalidFields"]
            return _json_mod.dumps(obj, ensure_ascii=False)
    except Exception:
        pass
    return text


def _call_tool_fn(tool_obj, *args, **kwargs):
    """Call a FastMCP tool object or plain function uniformly."""
    fn = getattr(tool_obj, "fn", tool_obj)
    return fn(*args, **kwargs)


@mcp.tool()
def hsdes_get_article(
    article_id: str,
    include_description: bool = False,
    include_customer_history: bool = False,
    fields: list[str] | None = None,
    format: str = "text",
) -> str:
    """Get a specific HSDes article by its numeric ID. Use this ONLY when you already have a known numeric article ID (from a URL, link, or another tool result). Do NOT use this to search by keyword or topic — to find articles by title or subject matter, use hsdes_query with subject='article' AND title CONTAINS 'keyword' instead.

    By default returns a safe field set (title, status, owner, priority, release, customer_company, etc.) without heavy fields that cause token overflow. Use include_description=True to include the full article description, and include_customer_history=True to include customer email history (ext_cust_blog_hist). For comments, use hsdes_get_comments.

    Args:
        article_id: The HSDes article ID — MUST be a numeric ID already known (e.g. '22021660584'). NOT a keyword, name, or topic.
        include_description: If True, include the full article description field. Default False.
        include_customer_history: If True, include server_platf_ae.bug.ext_cust_blog_hist. Default False.
        fields: Optional explicit list of fields to request from API. If provided, overrides default field set.
        format: 'text' (default) or 'html'. When 'text', HTML body fields are converted to plain text in PowerShell before serialization (saves tokens, sidesteps HSDes's malformed-HTML serialization that breaks json.loads). Pass 'html' only if you specifically need raw HTML markup.
    """
    if not article_id.strip().lstrip('-').isdigit():
        return (
            f"❌ article_id must be a numeric HSDes ID (e.g. '22021660584'), not a keyword.\n"
            f"To search for articles by title or topic, use hsdes_query:\n"
            f"  SELECT id, title, owner, submitted_date\n"
            f"  WHERE tenant = 'server_platf_ae' AND subject = 'article'\n"
            f"  AND title CONTAINS '{article_id}'\n"
            f"  SORTBY submitted_date DESC"
        )

    if fields:
        requested_fields: list[str] = []
        for field in fields:
            normalized = str(field).strip()
            if normalized and normalized not in requested_fields:
                requested_fields.append(normalized)
    else:
        requested_fields = [f.strip() for f in _ARTICLE_DEFAULT_FIELDS.split(",")]

    if include_description:
        requested_fields.append("description")
    if include_customer_history:
        requested_fields.append(_EXT_CUST_BLOG_HIST_FIELD)

    # Keep request compact and deterministic for easier debugging.
    final_fields = ",".join(dict.fromkeys(requested_fields))
    fmt = format.strip().lower() if format else "text"
    if fmt not in ("text", "html"):
        fmt = "text"
    result = _run_ps1(
        "hsdes_get_article.ps1",
        ArticleId=article_id,
        Fields=final_fields,
        Format=fmt,
    )
    result = _strip_invalid_fields(result)
    result, _ = _strip_base64_images(result)
    return _add_article_urls(_enrich_owners(result))


@mcp.tool()
def hsdes_get_comments(article_id: str, format: str = "text") -> str:
    """Get comments from an HSDes article, with owner, timestamp, and full content.
    Use this instead of hsdes_get_article when you need to read discussion/comments.
    Each comment has its own owner and submitted_date.

    Args:
        article_id: The HSDes article ID (numeric string).
        format: 'text' (default) or 'html'. When 'text', comment bodies are converted to plain text in PowerShell before serialization. Pass 'html' only if you specifically need raw HTML markup.
    """
    if not article_id.strip().lstrip('-').isdigit():
        return "article_id must be a numeric HSDes ID."

    import json as _json

    fmt = format.strip().lower() if format else "text"
    if fmt not in ("text", "html"):
        fmt = "text"
    raw = _run_ps1("hsdes_get_comments.ps1", ArticleId=article_id, Format=fmt)

    # Parse JSON from mixed PS output (Write-Host + JSON)
    data = _parse_ps1_json(raw)
    if not data:
        return raw

    comments = data.get("data", [])
    result = {
        "hsd_id": article_id,
        "comments": comments,
        "count": len(comments),
        "message": f"Found {len(comments)} comment(s) for article {article_id}"
    }
    result_str = _json.dumps(result, indent=2, ensure_ascii=False)
    result_str, _ = _strip_base64_images(result_str)
    return _add_article_urls(_enrich_owners(result_str))


@mcp.tool()
def hsdes_get_article_context(
    article_id: str,
    include_description: bool = False,
    include_customer_history: bool = False,
    include_comments: bool = False,
    article_fields: list[str] | None = None,
    comment_fields: list[str] | None = None,
    max_comments: int = 200,
) -> str:
    """Get source-separated article context in one call.

    This is an orchestration wrapper that keeps sources separate:
    - article_basic (from hsdes_get_article default/selected fields)
    - description (optional, from article field)
    - ext_cust_blog_hist (optional, from article field)
    - comments (optional, from hsdes_get_comments)

    Args:
        article_id: Numeric HSDes article ID.
        include_description: Include `description` from article.
        include_customer_history: Include `server_platf_ae.bug.ext_cust_blog_hist` from article.
        include_comments: Include comments section from hsdes_get_comments.
        article_fields: Optional explicit field list for article API call.
        comment_fields: Optional field projection for comments (e.g. ['id','owner','submitted_date','description']).
        max_comments: Max comments to return when include_comments=True (default 200).
    """
    import json as _json

    if not article_id.strip().lstrip("-").isdigit():
        return "article_id must be a numeric HSDes ID."
    if max_comments < 0:
        return "max_comments must be >= 0."

    article_raw = _call_tool_fn(
        hsdes_get_article,
        article_id,
        include_description=include_description,
        include_customer_history=include_customer_history,
        fields=article_fields,
    )
    try:
        article_payload = _json.loads(article_raw)
    except _json.JSONDecodeError:
        return article_raw

    article_rows = article_payload.get("data", []) if isinstance(article_payload, dict) else []
    article_record = article_rows[0] if article_rows else {}

    description_val = article_record.get("description")
    history_val = article_record.get(_EXT_CUST_BLOG_HIST_FIELD)
    article_basic = {
        k: v
        for k, v in article_record.items()
        if k not in {"description", _EXT_CUST_BLOG_HIST_FIELD}
    }

    comments_out = []
    comments_total = 0
    comments_truncated = 0
    if include_comments:
        comments_raw = _call_tool_fn(hsdes_get_comments, article_id)
        try:
            comments_payload = _json.loads(comments_raw)
        except _json.JSONDecodeError:
            comments_payload = {
                "hsd_id": article_id,
                "comments": [],
                "count": 0,
                "error": comments_raw,
            }

        comments_list = comments_payload.get("comments", []) if isinstance(comments_payload, dict) else []
        comments_total = len(comments_list)

        if max_comments and comments_total > max_comments:
            comments_list = comments_list[:max_comments]
            comments_truncated = comments_total - max_comments

        if comment_fields:
            normalized_fields = []
            for field in comment_fields:
                f = str(field).strip()
                if f and f not in normalized_fields:
                    normalized_fields.append(f)
            comments_out = [{k: c.get(k) for k in normalized_fields} for c in comments_list]
        else:
            comments_out = comments_list

    result = {
        "hsd_id": article_id,
        "article_basic": article_basic,
        "description": description_val if include_description else None,
        "ext_cust_blog_hist": history_val if include_customer_history else None,
        "comments": comments_out if include_comments else [],
        "comments_count": comments_total if include_comments else 0,
        "comments_truncated": comments_truncated if include_comments else 0,
        "source_notes": [
            "description comes from article.description",
            "ext_cust_blog_hist comes from article.server_platf_ae.bug.ext_cust_blog_hist",
            "comments come from article children with child_subject=comment",
        ],
    }
    return _json.dumps(result, indent=2, ensure_ascii=False)


# Allowlist of fields hsdes_update_article is permitted to modify. Anything
# outside this set must go through the HSDes web UI — the goal is to prevent
# AI-driven mass edits of structural fields (owner, priority, etc.).
#
# status / reason ARE allowed (workflow transitions, e.g. flipping a support
# request to `awaiting_user`). Note: `status_reason` is a READ-ONLY merged
# display value of the form `<status>.<reason>` — write the bare `status`
# and/or `reason` fields instead. The PS1 script performs a verify-after-write
# GET because HSDes silently no-ops invalid status/reason transitions.
_UPDATE_ALLOWED_FIELDS = ("comments", "notify", "ext_cust_blog", "ext_cust_blog_rich", "status", "reason")

# Magic-byte → data:URI mime mapping for *_image_paths kwargs. Only image
# types HSDes actually re-uploads as binary attachments (HSDes auto-uploads
# each data: URI in a written HTML field and rewrites src). PDFs/other docs
# belong in hsdes_upload_ips_attachment, not inline.
_IMAGE_EXT_TO_MIME = {
    ".png": "image/png",
    ".jpg": "image/jpeg",
    ".gif": "image/gif",
    ".webp": "image/webp",
    ".bmp": "image/bmp",
}


def _build_image_html_prefix(paths: list[str]) -> tuple[str | None, str]:
    """Read images from disk and return (error, html_prefix).

    Letting the caller pass filesystem paths avoids forcing the LM to emit
    base64 in tool args (Hermes Agent's *_image_paths precedent). HSDes
    auto-uploads each data: URI as a binary attachment and rewrites src.
    Magic-byte detection (vs filename extension) rejects mislabeled / non-
    image files cleanly so the caller routes PDFs etc. through the right tool.
    """
    import base64 as _b64
    parts: list[str] = []
    for raw in paths:
        p = Path(raw)
        if not p.exists() or not p.is_file():
            return (f"❌ Image file not found: {raw}", "")
        ext = _detect_ext_from_magic(p)
        mime = _IMAGE_EXT_TO_MIME.get(ext)
        if mime is None:
            return (
                f"❌ {raw} is not a supported image (detected {ext}); "
                "supported: png, jpg, gif, webp, bmp. Use "
                "hsdes_upload_ips_attachment for non-image files.",
                "",
            )
        try:
            data = p.read_bytes()
        except OSError as e:
            return (f"❌ Cannot read image {raw}: {e}", "")
        b64 = _b64.b64encode(data).decode("ascii")
        parts.append(
            f'<div><img src="data:{mime};base64,{b64}" alt="{p.name}"/></div>'
        )
    return (None, "".join(parts))


@mcp.tool()
def hsdes_update_article(
    article_id: str,
    comments: str | None = None,
    notify: str | None = None,
    comment_id: str | None = None,
    ext_cust_blog: str | None = None,
    ext_cust_blog_rich: str | None = None,
    comments_image_paths: list[str] | None = None,
    ext_cust_blog_rich_image_paths: list[str] | None = None,
    status: str | None = None,
    reason: str | None = None,
    dry_run: bool = True,
) -> str:
    """Add a comment, set the notify list, or transition status/reason on an HSDes article.
    Supports: `comments`, `notify`, `ext_cust_blog`, `ext_cust_blog_rich`,
    `status`, `reason`.

    ⚠️ THIS WRITES TO PRODUCTION HSDES. New comments are visible to the
    article owner, watchers, and downstream automation; both routes are
    recorded in the article's revision history. Use this tool ONLY when the
    user has explicitly asked you to update a specific article — never as a
    side effect of analysis, planning, or "being helpful".

    ⚠️ DRY-RUN BY DEFAULT: dry_run=True (default) appends ?debug=true so the
    server validates the body but does NOT persist. Always run a dry-run
    first, show the result to the user, and only set dry_run=False after the
    user confirms the exact change. NOTE: dry-run validates structure only
    and may not catch all field-writability rules — a successful dry-run
    does not guarantee a successful real write.

    Wire semantics (HSDes specifics — see swagger /article paths):
      - comments alone      → POST /article with subject="comments",
        parent_id=<id>. Adds a NEW child comment article. Repeated calls
        accumulate; they do NOT replace the previous comment.
      - comments+comment_id → PUT /article/<comment_id>: replaces the body
        of an existing comment in place. submitted_date is preserved;
        updated_date is bumped. NOTE: HSDes does NOT support DELETE on
        comments (returns 405) — there is no programmatic way to remove
        one. Use the web UI for that.
      - notify              → PUT /article/{id} with the parent's
        tenant/subject and fieldValues=[{"notify": "..."}].
      - ext_cust_blog{_rich} → PUT /article/{id} writing
        server_platf_ae.bug.ext_cust_blog (plain) and/or
        server_platf_ae.bug.ext_cust_blog_rich (HTML). If only the rich
        variant is supplied, plain is auto-derived from the HTML and both
        fields are written together (mirroring the HSDes UI's paired-field
        pattern). Tenant-gated: only works on server_platf_ae articles.
      - status / reason     → PUT /article/{id} with bare `status` and/or
        `reason` fields in fieldValues. HSDes models these as TWO SEPARATE
        writable fields; the `status_reason` field returned by GET is a
        server-aggregated READ-ONLY display value of the form
        `<status>.<reason>` (e.g. `open.awaiting_user`). Writing
        `status_reason` directly silently no-ops. Likewise, HSDes silently
        no-ops invalid status/reason transitions (200 with empty body, no
        error). On a real write (dry_run=False) the tool follows up with a
        GET and reports `verify_ok=true/false` so the caller knows whether
        the value actually landed.
      - Op order in one call: comment → ext_cust_blog* → notify →
        status/reason. Each op's success is reported independently.

    Tenant/subject of the parent article are auto-discovered via a small
    GET — the caller does NOT need to supply them.

    Other fields (priority, owner, title, description, tag, etc.) are NOT
    supported by this tool. Tell the user to use the HSDes web UI for
    those — do not try to work around this restriction.

    Args:
        article_id: Numeric HSDes article ID of the parent bug
            (e.g. '22021660584'). Required.
        comments: Comment body. **Always HTML, never Markdown.** HSDes
            renders the field as HTML (similar to Outlook): Markdown
            fences/asterisks/backticks appear literally, and — critically
            — **plain-text whitespace and line breaks are collapsed**.
            Indentation, multiple spaces, and bare `\n` will not survive
            rendering, so plain prose is fine for one-paragraph notes but
            destroys any code listing, table, or numbered list.

            Formatting rules:
              - Use `<br>` for line breaks between paragraphs.
              - Wrap code, traces, and any block where indentation matters
                in `<pre>...</pre>` (preserves monospace + whitespace +
                newlines). Inside `<pre>`, escape `<`, `>`, `&` as
                `&lt;`, `&gt;`, `&amp;`.
              - Use `<ul><li>...</li></ul>` for bullet lists,
                `<ol><li>...</li></ol>` for numbered lists.
              - `<b>`, `<i>`, `<code>` work inline as expected.
              - Headings (`<h2>`, `<h3>`), tables (`<table>`), and
                blockquotes (`<blockquote>`) all render.
              - Inline base64 images (`<img src="data:image/...">`) are
                auto-uploaded by HSDes as binary attachments and the src
                is rewritten on save. Markdown and MathML are stored but
                NOT rendered.

            With comment_id set, replaces that comment's body; without it,
            a new child comment is created.
        notify: Comma-separated IDSIDs to notify (e.g. 'hcheng20,jdoe').
        comment_id: Numeric ID of an existing comment article to update in
            place. Requires `comments` to also be set (the new body).
            Without `comment_id`, `comments` adds a NEW comment.
        ext_cust_blog: Plain text for the customer-blog field
            (server_platf_ae.bug.ext_cust_blog). Optional — usually
            auto-derived from `ext_cust_blog_rich` if you don't set this.
            ⚠️ HSDes UI shows this field as READ-ONLY: AE cannot edit it
            via the form. Direct PUT is a back-door API path; customer-
            facing systems do NOT receive what we write here, and the
            next external sync may overwrite it. Only use this when the
            user explicitly asks to write the customer blog field. The
            dry_run=True default IS the last-mile guard — caller is
            responsible for showing the dry-run output and getting
            explicit user confirmation before setting dry_run=False.
        ext_cust_blog_rich: Rich HTML for the customer-blog rich field
            (server_platf_ae.bug.ext_cust_blog_rich). Same warnings as
            `ext_cust_blog`. If supplied, the plain text companion is
            auto-derived (unless `ext_cust_blog` is also supplied, in
            which case the caller's plain text wins). Tenant-gated:
            only works on server_platf_ae articles.
        comments_image_paths: Local filesystem paths to image files
            (png/jpg/gif/webp/bmp) that should be embedded inline at the
            START of the `comments` HTML. The tool reads each file, base64-
            encodes it, and prepends a `<div><img src="data:..."/></div>`
            block — HSDes auto-uploads each data: URI as a binary
            attachment and rewrites src on save. Lets the caller share
            screenshots without round-tripping base64 through tool args.
            When supplied alone (without `comments`), an image-only
            comment is created. Non-image files are rejected; use
            `hsdes_upload_ips_attachment` for PDFs etc.
        ext_cust_blog_rich_image_paths: Same shape as `comments_image_paths`
            but targets `ext_cust_blog_rich`. Useful for posting customer-
            facing screenshots into the rich-HTML field. HSDes UI is
            paired-field: writing rich also propagates to the read-only
            `ext_cust_blog_hist` over time. Tenant-gated to server_platf_ae.
        status: New status for the parent article (e.g. 'open', 'review',
            'complete'). Workflow rules apply; HSDes silently no-ops
            invalid transitions. On real writes the tool verifies via GET
            and reports verify_ok in the response.
        reason: New reason for the parent article (e.g. 'awaiting_user',
            'investigation', 'fixed'). Write the bare `reason` field — do
            NOT pass the merged `status_reason` display value
            ('open.awaiting_user'); that field is read-only and silently
            no-ops on PUT. Pair with `status` when crossing status
            boundaries. Same verify-after-write behaviour as `status`.
        dry_run: True (default) = validate via ?debug=true, do not persist.
            False = actually write. ALWAYS run dry_run=True first, show
            the user the resulting per-op summary, get explicit
            confirmation, only then call again with dry_run=False.
    """
    if not article_id.strip().lstrip("-").isdigit():
        return "❌ article_id must be a numeric HSDes ID (e.g. '22021660584')."

    has_comment_id = comment_id is not None and str(comment_id).strip() != ""
    if has_comment_id and not str(comment_id).strip().isdigit():
        return "❌ comment_id must be a numeric HSDes comment article ID."

    # Resolve image_paths → HTML prefix BEFORE the "no fields" check so an
    # image-only comment (paths supplied, body omitted) is a valid request.
    if comments_image_paths:
        err, prefix = _build_image_html_prefix(comments_image_paths)
        if err:
            return err
        comments = prefix + (comments or "")
    if ext_cust_blog_rich_image_paths:
        err, prefix = _build_image_html_prefix(ext_cust_blog_rich_image_paths)
        if err:
            return err
        ext_cust_blog_rich = prefix + (ext_cust_blog_rich or "")

    has_comments = comments is not None and str(comments).strip() != ""
    has_notify = notify is not None and str(notify).strip() != ""
    has_blog = ext_cust_blog is not None and str(ext_cust_blog).strip() != ""
    has_blog_rich = (
        ext_cust_blog_rich is not None and str(ext_cust_blog_rich).strip() != ""
    )
    has_status = status is not None and str(status).strip() != ""
    has_reason = reason is not None and str(reason).strip() != ""

    if has_comment_id and not has_comments:
        return (
            "❌ comment_id requires comments — pass the new body to write.\n"
            "Note: HSDes does not allow DELETE on comments (405); to remove "
            "a comment, use the web UI."
        )

    if not (has_comments or has_notify or has_blog or has_blog_rich or has_status or has_reason):
        return (
            "❌ No fields to update. Pass at least one of: comments, notify, "
            "ext_cust_blog, ext_cust_blog_rich, status, reason, "
            "comments_image_paths, ext_cust_blog_rich_image_paths.\n"
            "Other fields (priority, owner, title, etc.) are NOT supported "
            "by this tool — use the HSDes web UI instead."
        )

    ps_kwargs: dict[str, str] = {
        "ArticleId": article_id,
        "DryRun": "true" if dry_run else "false",
    }
    if has_comments:
        ps_kwargs["Comments"] = comments
    if has_comment_id:
        ps_kwargs["CommentId"] = str(comment_id).strip()
    if has_notify:
        ps_kwargs["Notify"] = notify
    if has_blog:
        ps_kwargs["ExtCustBlog"] = ext_cust_blog
    if has_blog_rich:
        ps_kwargs["ExtCustBlogRich"] = ext_cust_blog_rich
    if has_status:
        ps_kwargs["Status"] = status
    if has_reason:
        ps_kwargs["Reason"] = reason

    return _run_ps1("hsdes_update_article.ps1", **ps_kwargs)


# Regex for HSDes binary URLs in HTML
_BINARY_URL_RE = re.compile(r'https?://hsdes(?:-api)?\.intel\.com/rest/binary/(\d+)')

# Regex for IPS attachment URLs as embedded in HSDes HTML (customer-facing portal domain).
# These use esft.intel.com/IPS_SFT and require conversion to esft-int.intel.com/HSDES_SFT
# for Intel-internal Windows-auth download.
#
# NOTE: HSDes serves the FileName= query param with raw spaces (no URL-encoding) inside
# <a href="..."> attributes — e.g. `FileName=EGS PCIE WorkShop WW23_MSFT_...pdf`. The
# pattern therefore allows spaces and only stops at HTML attribute / tag boundaries
# (`"`, `<`, `>`). A previous `[^\s"'<>]+` form silently truncated such URLs at the
# first space, dropping older real-customer attachments from `hsdes_get_attachments`.
_IPS_URL_RE = re.compile(
    r'https://esft\.intel\.com/sftservices/download/IPS_SFT\?[^"<>]+'
)

# Regex for IPS attachment URLs in ext_attach_url field (XML format, already esft-int).
# These are already in the correct Intel-internal download format.
_IPS_DIRECT_URL_RE = re.compile(
    r'https://esft-int\.intel\.com/sftservices/download/HSDES_SFT/\?[^"<>]+'
)


def _extract_binary_ids(html: str) -> list[str]:
    """Extract unique binary IDs from HTML content, preserving order."""
    seen = set()
    result = []
    for m in _BINARY_URL_RE.finditer(html):
        bid = m.group(1)
        if bid not in seen:
            seen.add(bid)
            result.append(bid)
    return result


def _extract_ips_attachments(html: str, article_id: str) -> list[dict]:
    """Extract IPS (ESFT) attachment metadata from HSDes HTML.

    HTML embeds esft.intel.com/IPS_SFT links (customer portal, requires Salesforce auth).
    We convert them to esft-int.intel.com/HSDES_SFT links (Intel-internal, Windows auth)
    using the same AppFileID and the HSDes article ID as AppData.
    """
    import html as _html_mod
    from urllib.parse import urlparse, parse_qs, urlencode
    seen: set[str] = set()
    results = []
    for m in _IPS_URL_RE.finditer(html or ""):
        raw_url = _html_mod.unescape(m.group(0))  # &amp; → &
        if raw_url in seen:
            continue
        seen.add(raw_url)
        qs = parse_qs(urlparse(raw_url).query)
        filename = qs.get("FileName", [""])[0]
        app_file_id = qs.get("AppFileID", [""])[0]
        ext = filename.rsplit(".", 1)[-1].lower() if "." in filename else ""
        # Build the Intel-internal download URL
        download_url = (
            "https://esft-int.intel.com/sftservices/download/HSDES_SFT/?"
            + urlencode({"FileName": filename, "AppFileID": app_file_id, "AppData": article_id})
        )
        results.append({
            "type": "ips",
            "id": None,
            "filename": filename,
            "file_type": ext,
            "file_size": None,
            "url": download_url,
            "app_file_id": app_file_id,
        })
    return results


# Regex for [IPS:] / [HSDES:] thread headers in ext_cust_blog_hist.
# Format: [IPS|HSDES: <visibility> :: <role> :: <author> :: <email> :: <YYYY-MM-DD HH:MM:SS[.fff]>]
_IPS_HEADER_RE = re.compile(
    r'\[(IPS|HSDES):\s*'
    r'([^:]*?)\s*::\s*'           # visibility (e.g. "Public to Customers")
    r'([^:]*?)\s*::\s*'           # role (Partner / Agent)
    r'([^:]*?)\s*::\s*'           # author full name
    r'([^\s:]+@[^\s:]+)\s*::\s*'  # email
    r'(\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2}(?:\.\d+)?)'  # timestamp
    r'\s*\]',
    re.IGNORECASE,
)

# Regex for `<a href="...">[YYYY-MM-DD HH:MM:SS] filename</a>` in ext_attach_url.
# Captures href so we can pull the unique AppFileID — keying timestamps by
# AppFileID disambiguates repeated filenames (e.g. `screenshot.png` uploaded
# more than once) where a filename-only map would silently collide.
_EXT_ATTACH_TS_RE = re.compile(
    r'<a\s+href="([^"]+)"[^>]*>\s*'
    r'\[(\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2})\]\s*([^<]+?)\s*</a>',
    re.IGNORECASE,
)


def _parse_ips_thread(blog_hist: str) -> list[dict]:
    """Split ext_cust_blog_hist into a list of messages, oldest-first sorted by timestamp.

    Each message: {kind, visibility, role, author, email, posted_at, body}.
    `body` is the text between this header and the next header (trimmed).
    """
    if not blog_hist:
        return []
    matches = list(_IPS_HEADER_RE.finditer(blog_hist))
    if not matches:
        return []
    messages = []
    for i, m in enumerate(matches):
        body_start = m.end()
        body_end = matches[i + 1].start() if i + 1 < len(matches) else len(blog_hist)
        body = blog_hist[body_start:body_end].strip()
        messages.append({
            "kind": m.group(1).upper(),               # IPS or HSDES
            "visibility": m.group(2).strip(),
            "role": m.group(3).strip(),
            "author": m.group(4).strip(),
            "email": m.group(5).strip(),
            "posted_at": m.group(6).strip(),
            "body": body,
        })
    # Sort oldest-first for human-readable timeline
    messages.sort(key=lambda x: x["posted_at"])
    return messages


def _build_ext_attach_timestamps(ext_attach_xml: str) -> dict[str, str]:
    """Index timestamps from ext_attach_url XML keyed by both AppFileID and filename.

    Each `<a href="...">[YYYY-MM-DD HH:MM:SS] filename</a>` entry is parsed.
    Returned dict has two key shapes:
      - 'id:<AppFileID>' (preferred — unique per upload, disambiguates repeated
        filenames)
      - 'name:<filename>' (fallback for entries with no AppFileID; first
        occurrence wins, callers must understand collisions are possible)
    Use `_ext_ts_lookup` to resolve a timestamp without remembering key shape.
    """
    out: dict[str, str] = {}
    if not ext_attach_xml:
        return out
    import html as _html_mod
    from urllib.parse import urlparse, parse_qs
    for m in _EXT_ATTACH_TS_RE.finditer(ext_attach_xml):
        href = _html_mod.unescape(m.group(1))
        ts = m.group(2).strip()
        label = m.group(3).strip()
        if not ts:
            continue
        try:
            qs = parse_qs(urlparse(href).query)
            app_file_id = qs.get("AppFileID", [""])[0]
        except Exception:
            app_file_id = ""
        if app_file_id:
            out[f"id:{app_file_id}"] = ts
        if label and f"name:{label}" not in out:
            out[f"name:{label}"] = ts
    return out


def _ext_ts_lookup(ts_map: dict[str, str], app_file_id: str, filename: str) -> str:
    """Return the timestamp for an attachment, preferring AppFileID over filename."""
    if app_file_id:
        hit = ts_map.get(f"id:{app_file_id}")
        if hit:
            return hit
    if filename:
        return ts_map.get(f"name:{filename}", "")
    return ""


# Sanitize filenames + AppFileIDs that come from HSDes/ESFT query strings before
# joining them into a filesystem path. Both can be attacker-controlled (HSDes
# stores whatever filename the customer uploaded), so we strip any path
# components, reject "." / "..", and clamp AppFileID to a safe alnum subset.
def _safe_basename(raw: str, fallback: str = "ips_download") -> str:
    if not raw:
        return fallback
    name = Path(raw).name  # strip path components / drive letters
    if not name or name in (".", ".."):
        return fallback
    return name


def _safe_app_file_id(raw: str) -> str:
    if not raw:
        return ""
    return re.sub(r"[^A-Za-z0-9_\-]", "", raw)[:64]


def _ips_cache_path(url: str) -> Path | None:
    """Compute the cwd-relative cache location for an ESFT URL.

    Layout: ./downloads/<article_id>/<AppFileID>/<filename>
    The AppFileID subdir prevents collisions when two IPS attachments on the
    same article share a display filename. Returns None if the URL has no
    parseable FileName at all.
    """
    from urllib.parse import urlparse, parse_qs, unquote
    try:
        qs = parse_qs(urlparse(url).query)
    except Exception:
        return None
    fname = _safe_basename(unquote(qs.get("FileName", [""])[0]))
    safe_id = _safe_app_file_id(unquote(qs.get("AppFileID", [""])[0]))
    article_q = unquote(qs.get("AppData", [""])[0])
    base = Path.cwd() / "downloads"
    if article_q and article_q.isdigit():
        base = base / article_q
    if safe_id:
        return base / safe_id / fname
    return base / fname


def _correlate_attachment_to_thread(
    filename: str,
    posted_at_hint: str,
    thread: list[dict],
) -> dict:
    """Find the IPS message that uploaded this attachment.

    Strategy (ordered for correctness when filenames repeat):
      1. If posted_at_hint is set (resolved from AppFileID-keyed timestamp),
         match by ±60s timestamp proximity. This is unambiguous even when the
         same filename appears in multiple messages — each upload has its own
         AppFileID and timestamp.
      2. Else fall back to literal filename match in message body. NOTE: when
         several messages reference the same filename string, this returns
         the FIRST match and may attach the wrong metadata; the caller should
         prefer the AppFileID-keyed timestamp path when possible.
      3. Else return empty dict.
    """
    if not thread:
        return {}
    if posted_at_hint:
        try:
            from datetime import datetime
            hint = datetime.strptime(posted_at_hint[:19], "%Y-%m-%d %H:%M:%S")
            best = None
            best_delta = None
            for msg in thread:
                try:
                    ts = datetime.strptime(msg["posted_at"][:19], "%Y-%m-%d %H:%M:%S")
                except ValueError:
                    continue
                delta = abs((ts - hint).total_seconds())
                if delta <= 60 and (best_delta is None or delta < best_delta):
                    best, best_delta = msg, delta
            if best:
                return _ips_msg_summary(best)
        except ValueError:
            pass
    if filename:
        for msg in thread:
            if filename in msg["body"]:
                return _ips_msg_summary(msg)
    return {}


def _ips_msg_summary(msg: dict) -> dict:
    """Reduce a parsed IPS message to a compact attachment-context dict."""
    body = msg["body"]
    # Strip the boilerplate "New Case Attachment uploaded: Download link <name> <label>"
    excerpt = re.sub(
        r'^New Case Attachment uploaded:\s*Download link\s+\S+\s*',
        '',
        body,
        flags=re.IGNORECASE,
    ).strip()
    if len(excerpt) > 160:
        excerpt = excerpt[:157].rstrip() + "..."
    return {
        "posted_at": msg["posted_at"],
        "posted_by": msg["author"],
        "posted_by_role": msg["role"],
        "posted_by_email": msg["email"],
        "kind": msg["kind"],
        "message_excerpt": excerpt,
    }


def _html_text_excerpt(html: str, max_len: int = 160) -> str:
    """Convert HTML to a compact text excerpt for client-safe image context."""
    if not html:
        return ""
    text = re.sub(r'<img\b[^>]*>', ' ', html, flags=re.IGNORECASE)
    text = re.sub(r'<[^>]+>', ' ', text)
    text = re.sub(r'&nbsp;?', ' ', text, flags=re.IGNORECASE)
    text = re.sub(r'&amp;', '&', text, flags=re.IGNORECASE)
    text = re.sub(r'\s+', ' ', text).strip()
    if len(text) <= max_len:
        return text
    return text[: max_len - 3].rstrip() + "..."


def _build_image_context(source_label: str, html: str, comment: dict | None = None) -> dict:
    """Build client-safe image context metadata without requiring image-read capability."""
    context = {
        "source_type": "comment" if comment else source_label,
        "source_label": source_label,
        "text_excerpt": _html_text_excerpt(html),
    }
    if comment:
        context["comment_owner"] = comment.get("owner", "")
        context["comment_id"] = comment.get("id", "")
        context["submitted_date"] = comment.get("submitted_date", "")
    return context


def _detect_ext_from_magic(file_path: Path) -> str:
    """Detect file extension from magic bytes when Content-Type is unhelpful."""
    try:
        with open(file_path, 'rb') as f:
            header = f.read(16)
    except (OSError, IOError):
        return ".bin"
    if header[:8] == b'\x89PNG\r\n\x1a\n':
        return ".png"
    if header[:3] == b'\xff\xd8\xff':
        return ".jpg"
    if header[:6] in (b'GIF87a', b'GIF89a'):
        return ".gif"
    if header[:4] == b'RIFF' and header[8:12] == b'WEBP':
        return ".webp"
    if header[:4] == b'%PDF':
        return ".pdf"
    if header[:2] == b'BM':
        return ".bmp"
    if header[:4] == b'PK\x03\x04':
        return ".zip"  # Could be xlsx/docx/pptx too
    return ".bin"


def _content_type_to_ext(content_type: str) -> str:
    """Map Content-Type to file extension."""
    ct = content_type.lower().split(";")[0].strip()
    mapping = {
        "image/png": ".png",
        "image/jpeg": ".jpg",
        "image/gif": ".gif",
        "image/bmp": ".bmp",
        "image/webp": ".webp",
        "image/svg+xml": ".svg",
        "application/pdf": ".pdf",
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet": ".xlsx",
        "application/vnd.openxmlformats-officedocument.wordprocessingml.document": ".docx",
        "application/vnd.openxmlformats-officedocument.presentationml.presentation": ".pptx",
        "text/plain": ".txt",
        "text/html": ".html",
    }
    return mapping.get(ct, ".bin")


@mcp.tool()
def hsdes_get_images(article_id: str, max_images: int = 20, as_image: bool = False):
    """Extract and download ALL embedded images from an HSDes article's description and comments.
    Covers both HSDes binary-ID images (<img src=".../binary/<id>">) and inline base64 images
    (<img src="data:image/...;base64,...">). All images are saved to local temp files and returned
    with client-safe context metadata.
    Do NOT assume the caller can read local image files or use vision. Use returned context first.
    Clients that support local image inspection may optionally use local_path for extra detail.

    For inline base64 images, the returned `inline_id` matches the `id=...` in the
    `[base64-image-stripped:id=<...>]` placeholder produced by hsdes_get_article /
    hsdes_get_comments / hsdes_get_saved_query, so callers can correlate placeholder ↔ file.

    Args:
        article_id: The HSDes article ID (numeric string).
        max_images: Maximum total number of images to download/extract (default 20).
        as_image: If True, return inline MCP Image content blocks for each image that
            is png/jpg/gif/webp/bmp and ≤ 8 MB, alongside the JSON summary. This lets
            multimodal LLMs see all extracted images directly. Default False (JSON only).
    """
    if not article_id.strip().lstrip('-').isdigit():
        return "article_id must be a numeric HSDes ID."

    import base64 as _base64
    import json as _json
    import tempfile

    # Fields that may contain embedded images (HTML with <img> tags)
    _IMAGE_FIELDS = [
        "description",
        "server_platf_ae.bug.ext_cust_blog_hist",
    ]

    # Step 1: Get article (all fields including ext_cust_blog_hist).
    # Format=html so <img> tags survive — PS1 default 'text' strips them via
    # Convert-HsdesHtmlToText, leaving zero matches for the regexes below.
    raw_article = _run_ps1("hsdes_get_article.ps1", ArticleId=article_id, Format="html")
    article_record = {}
    article_data = _parse_ps1_json(raw_article)
    if article_data:
        records = article_data.get("data", [])
        if records:
            article_record = records[0]

    # Step 2: Get comments — same Format=html requirement.
    raw_comments = _run_ps1("hsdes_get_comments.ps1", ArticleId=article_id, Format="html")
    comments = []
    comments_data = _parse_ps1_json(raw_comments)
    if comments_data:
        comments = comments_data.get("data", [])

    # Step 3a: Extract all HSDes binary IDs with source tracking
    binary_sources = {}  # binary_id -> source label
    binary_contexts = {}  # binary_id -> context metadata
    # Step 3b: Extract all inline base64 images
    inline_sources = {}  # inline_id -> source label
    inline_contexts = {}  # inline_id -> context metadata
    inline_payload = {}  # inline_id -> (img_type, b64_data)

    for field_name in _IMAGE_FIELDS:
        field_html = article_record.get(field_name, "")
        if field_html:
            label = field_name.split(".")[-1] if "." in field_name else field_name
            for bid in _extract_binary_ids(field_html):
                if bid not in binary_sources:
                    binary_sources[bid] = label
                    binary_contexts[bid] = _build_image_context(label, field_html)
            for img in _extract_inline_base64_images(field_html):
                iid = img["inline_id"]
                if iid not in inline_sources:
                    inline_sources[iid] = label
                    inline_contexts[iid] = _build_image_context(label, field_html)
                    inline_payload[iid] = (img["type"], img["b64_data"])

    for i, comment in enumerate(comments):
        comment_html = comment.get("description", "")
        for bid in _extract_binary_ids(comment_html):
            if bid not in binary_sources:
                binary_sources[bid] = f"comment#{i+1}"
                binary_contexts[bid] = _build_image_context(f"comment#{i+1}", comment_html, comment)
        for img in _extract_inline_base64_images(comment_html):
            iid = img["inline_id"]
            if iid not in inline_sources:
                inline_sources[iid] = f"comment#{i+1}"
                inline_contexts[iid] = _build_image_context(f"comment#{i+1}", comment_html, comment)
                inline_payload[iid] = (img["type"], img["b64_data"])

    all_binary_ids = list(binary_sources.keys())
    all_inline_ids = list(inline_sources.keys())
    total_found = len(all_binary_ids) + len(all_inline_ids)

    if total_found == 0:
        return _json.dumps({
            "hsd_id": article_id,
            "images": [],
            "count": 0,
            "total_found": 0,
            "message": f"No embedded images found in article {article_id}."
        }, indent=2)

    # Step 4: Apportion max_images budget — binary first, then inline
    budget = max_images
    download_ids = all_binary_ids[:budget]
    budget -= len(download_ids)
    extract_inline_ids = all_inline_ids[:budget]

    img_dir = Path(tempfile.gettempdir()) / "hsdes_images"
    img_dir.mkdir(exist_ok=True)

    def _download_one(bid: str) -> dict:
        base_name = f"{article_id}_{bid}"
        # Check cache: look for any existing file with this base name
        for cached in img_dir.glob(f"{base_name}.*"):
            return {
                "binary_id": bid,
                "source": binary_sources[bid],
                "context": binary_contexts[bid],
                "local_path": str(cached),
                "content_type": "cached",
                "size": cached.stat().st_size,
            }
        # Download to .bin, then rename based on content_type
        out_path = img_dir / f"{base_name}.bin"
        raw = _run_ps1("hsdes_download_binary.ps1", BinaryId=bid, OutputPath=str(out_path))
        try:
            meta = _json.loads(raw)
            ct = meta.get("content_type", "")
            ext = _content_type_to_ext(ct)
            # Fallback: detect from magic bytes when API returns octet-stream
            if ext == ".bin" and out_path.exists():
                ext = _detect_ext_from_magic(out_path)
            final_path = out_path
            if ext and ext != ".bin" and out_path.exists():
                new_path = out_path.with_suffix(ext)
                if not new_path.exists():
                    out_path.rename(new_path)
                final_path = new_path
            meta["local_path"] = str(final_path)
            meta["source"] = binary_sources[bid]
            meta["context"] = binary_contexts[bid]
            return meta
        except _json.JSONDecodeError:
            return {
                "binary_id": bid,
                "source": binary_sources[bid],
                "context": binary_contexts[bid],
                "local_path": str(out_path) if out_path.exists() else "",
                "content_type": "unknown",
                "size": 0,
                "error": raw[:200],
            }

    def _save_inline_one(iid: str) -> dict:
        img_type, b64_data = inline_payload[iid]
        ext = _content_type_to_ext(f"image/{img_type}")
        if ext == ".bin":
            ext = f".{img_type}" if img_type.isalnum() else ".bin"
        final_path = img_dir / f"{article_id}_inline_{iid}{ext}"
        if final_path.exists():
            size = final_path.stat().st_size
        else:
            try:
                decoded = _base64.b64decode(b64_data, validate=False)
                final_path.write_bytes(decoded)
                size = len(decoded)
            except Exception as e:
                return {
                    "inline_id": iid,
                    "source": inline_sources[iid],
                    "context": inline_contexts[iid],
                    "local_path": "",
                    "content_type": f"image/{img_type}",
                    "size": 0,
                    "error": str(e)[:200],
                }
        return {
            "inline_id": iid,
            "source": inline_sources[iid],
            "context": inline_contexts[iid],
            "local_path": str(final_path),
            "content_type": f"image/{img_type}",
            "size": size,
        }

    images = []
    if download_ids:
        with ThreadPoolExecutor(max_workers=min(len(download_ids), 5)) as ex:
            images.extend(ex.map(_download_one, download_ids))
    if extract_inline_ids:
        # Inline base64 is local decode — fast, no need to parallelize aggressively
        images.extend(_save_inline_one(iid) for iid in extract_inline_ids)

    msg = (
        f"Returned {len(images)} image(s) with client-safe context metadata "
        f"({len(download_ids)} HSDes binary, {len(extract_inline_ids)} inline base64). "
        "Use the returned context for analysis first. Clients with local image inspection "
        "support may optionally inspect local_path files for extra detail."
    )
    if total_found > max_images:
        msg += f" (Limit: {max_images}/{total_found} -- {total_found - max_images} skipped)"

    summary_json = _json.dumps({
        "hsd_id": article_id,
        "images": images,
        "count": len(images),
        "total_found": total_found,
        "message": msg,
    }, indent=2, ensure_ascii=False)

    if not as_image:
        return summary_json

    # Build mixed content list: JSON summary + Image blocks for inline-able files.
    image_exts = {".png", ".jpg", ".jpeg", ".gif", ".webp", ".bmp"}
    MAX_INLINE_BYTES = 8 * 1024 * 1024
    try:
        from fastmcp.utilities.types import Image
    except ImportError:
        return summary_json

    blocks: list = [summary_json]
    for img in images:
        path_str = img.get("local_path") or ""
        if not path_str:
            continue
        p = Path(path_str)
        if not p.is_file():
            continue
        ext = p.suffix.lower()
        if ext not in image_exts:
            continue
        if p.stat().st_size > MAX_INLINE_BYTES:
            continue
        fmt = "jpeg" if ext in (".jpg", ".jpeg") else ext.lstrip(".")
        blocks.append(Image(path=str(p), format=fmt))
    return blocks


@mcp.tool()
def hsdes_get_attachments(article_id: str, include_thread_context: bool = False) -> str:
    """List attachments for an HSDes article: native HSDes binary files (type=hsdes) and
    IPS/ESFT shared files (type=ips). IPS attachments are detected from ext_attach_url,
    ext_cust_blog_hist, and description; deduplicated by AppFileID.
    IPS entries include a 'url' field — pass it to hsdes_download_ips_attachment to download.

    Args:
        article_id: The HSDes article ID (numeric string).
        include_thread_context: When True, IPS entries get extra fields by parsing the
            IPS/HSDES message thread in ext_cust_blog_hist and matching each attachment
            to the message that posted it. Adds: posted_at, posted_by, posted_by_role
            (Partner/Agent), posted_by_email, kind (IPS/HSDES), message_excerpt. Default
            False — the regex-based parse is sensitive to HSDes formatting changes and
            adds ~150ms per call. Turn it on for IRF / customer-correlation workflows.
    """
    if not article_id.strip().lstrip('-').isdigit():
        return "article_id must be a numeric HSDes ID."

    import json as _json
    from concurrent.futures import ThreadPoolExecutor

    from urllib.parse import urlparse, parse_qs

    # Fetch HSDes binary children and article HTML in parallel
    with ThreadPoolExecutor(max_workers=2) as ex:
        f_att = ex.submit(_run_ps1, "hsdes_get_attachments.ps1", ArticleId=article_id)
        f_art = ex.submit(
            _run_ps1, "hsdes_get_article.ps1", ArticleId=article_id,
            Fields="description,server_platf_ae.bug.ext_cust_blog_hist,server_platf_ae.bug.ext_attach_url",
        )
    raw_att = f_att.result()
    raw_art = f_art.result()

    attachments: list[dict] = []

    # HSDes binary attachments
    att_data = _parse_ps1_json(raw_att)
    if att_data:
        for a in att_data.get("attachments", []):
            a["type"] = "hsdes"
            attachments.append(a)

    # IPS attachments — dedup by app_file_id across all sources
    seen_file_ids: set[str] = set()

    def _add_ips(entry: dict) -> None:
        fid = entry.get("app_file_id", "")
        if fid and fid not in seen_file_ids:
            seen_file_ids.add(fid)
            attachments.append(entry)

    art_data = _parse_ps1_json(raw_art)
    if art_data:
        records = art_data.get("data", [])
        if records:
            rec = records[0]

            # Optional thread-correlation — only when caller opts in. The regex parse
            # of ext_cust_blog_hist is fragile against HSDes format changes, so we
            # default off and let callers turn it on for IRF/customer triage flows.
            ips_thread: list[dict] = []
            ext_ts_map: dict[str, str] = {}
            if include_thread_context:
                blog_hist = rec.get("server_platf_ae.bug.ext_cust_blog_hist") or ""
                ips_thread = _parse_ips_thread(blog_hist)
                ext_attach_for_ts = rec.get("server_platf_ae.bug.ext_attach_url") or ""
                ext_ts_map = _build_ext_attach_timestamps(ext_attach_for_ts)
            ext_attach = rec.get("server_platf_ae.bug.ext_attach_url") or ""

            # Source 1: ext_attach_url — XML with direct esft-int URLs (already correct format)
            for m in _IPS_DIRECT_URL_RE.finditer(ext_attach):
                url = m.group(0)
                qs = parse_qs(urlparse(url).query)
                filename = qs.get("FileName", [""])[0]
                app_file_id = qs.get("AppFileID", [""])[0]
                ext = filename.rsplit(".", 1)[-1].lower() if "." in filename else ""
                entry = {
                    "type": "ips",
                    "id": None,
                    "filename": filename,
                    "file_type": ext,
                    "file_size": None,
                    "url": url,
                    "app_file_id": app_file_id,
                }
                if include_thread_context:
                    ts_hint = _ext_ts_lookup(ext_ts_map, app_file_id, filename)
                    ctx = _correlate_attachment_to_thread(filename, ts_hint, ips_thread)
                    if ts_hint and "posted_at" not in ctx:
                        entry["posted_at"] = ts_hint  # ts known but no body match
                    if ctx:
                        entry.update(ctx)
                _add_ips(entry)

            # Source 2: ext_cust_blog_hist + description — HTML with esft.intel.com URLs (need conversion)
            for field in ("server_platf_ae.bug.ext_cust_blog_hist", "description"):
                for ips in _extract_ips_attachments(rec.get(field) or "", article_id):
                    if include_thread_context:
                        fname = ips.get("filename", "")
                        fid = ips.get("app_file_id", "")
                        ts_hint = _ext_ts_lookup(ext_ts_map, fid, fname)
                        ctx = _correlate_attachment_to_thread(fname, ts_hint, ips_thread)
                        if ts_hint and "posted_at" not in ctx:
                            ips["posted_at"] = ts_hint
                        if ctx:
                            ips.update(ctx)
                    _add_ips(ips)

    count = len(attachments)
    if count == 0:
        return _json.dumps({
            "hsd_id": article_id,
            "attachments": [],
            "count": 0,
            "message": f"No attachments found for article {article_id}."
        }, indent=2)

    hsdes_n = sum(1 for a in attachments if a.get("type") == "hsdes")
    ips_n = sum(1 for a in attachments if a.get("type") == "ips")
    parts = []
    if hsdes_n:
        parts.append(f"{hsdes_n} HSDes binary")
    if ips_n:
        parts.append(f"{ips_n} IPS/ESFT")

    return _json.dumps({
        "hsd_id": article_id,
        "attachments": attachments,
        "count": count,
        "message": f"Found {count} attachment(s): {', '.join(parts)}.",
    }, indent=2, ensure_ascii=False)


@mcp.tool()
def hsdes_download_ips_attachment(url: str, output_path: str = "", as_image: bool = False):
    """Download an IPS/ESFT attachment from esft-int.intel.com.
    Use the 'url' field from hsdes_get_attachments (type=ips entries) as input.
    ESFT can be slow — enforces a 30-second timeout.

    Args:
        url: The full ESFT download URL (from hsdes_get_attachments type=ips).
        output_path: Local path to save the file. Defaults to
            <cwd>/downloads/<article_id>/<AppFileID>/<filename>, where
            article_id is parsed from the URL's AppData query param and the
            AppFileID subdir prevents collisions when two IPS attachments on
            the same article share a display filename. Falls back to
            <cwd>/downloads/<filename> if AppData/AppFileID are missing.
        as_image: If True and the downloaded file is an image (jpg/png/gif/webp/bmp),
            return its bytes inline as an MCP Image content block (so a multimodal
            LLM can see the picture directly). The file is still saved to disk.
            For non-image content or when False, returns JSON metadata only.
            Files larger than 8 MB always fall back to JSON metadata.
    """
    import json as _json

    if "esft-int.intel.com" not in url:
        return _json.dumps({"success": False, "error": "url must be an esft-int.intel.com link."})

    # Cache lookup. When the caller did NOT pass output_path, compute a cache
    # location keyed by AppFileID so two IPS attachments with the same display
    # filename don't collide. We also pass this same path to PS1 as the
    # write target — otherwise PS1's flat default would land somewhere the
    # next cache check can't find.
    cache_path: Path | None = (
        Path(output_path) if output_path else _ips_cache_path(url)
    )
    data: dict | None = None
    if cache_path and cache_path.is_file() and cache_path.stat().st_size > 0:
        data = {
            "success": True,
            "filename": cache_path.name,
            "output_path": str(cache_path),
            "file_size": cache_path.stat().st_size,
            "url": url,
            "cached": True,
        }

    if data is None:
        effective_output = output_path or (str(cache_path) if cache_path else "")
        if cache_path and not output_path:
            cache_path.parent.mkdir(parents=True, exist_ok=True)
        raw = _run_ps1("hsdes_download_ips.ps1", Url=url, OutputPath=effective_output)
        data = _parse_ps1_json(raw)
        if not data:
            return raw

    # Default behavior — JSON metadata only.
    if not as_image or not data.get("success"):
        return _json.dumps(data, indent=2, ensure_ascii=False)

    file_path_str = data.get("output_path") or ""
    if not file_path_str:
        return _json.dumps(data, indent=2, ensure_ascii=False)
    p = Path(file_path_str)
    if not p.is_file():
        return _json.dumps(data, indent=2, ensure_ascii=False)

    # Detect image format from magic bytes (Content-Type isn't returned by ESFT script).
    ext = _detect_ext_from_magic(p).lstrip(".")
    image_exts = {"png", "jpg", "jpeg", "gif", "webp", "bmp"}
    if ext not in image_exts:
        return _json.dumps(
            {**data, "as_image_skipped": f"file is not an image (detected: {ext})"},
            indent=2, ensure_ascii=False,
        )

    MAX_INLINE_BYTES = 8 * 1024 * 1024  # 8 MB
    size = data.get("file_size") or p.stat().st_size
    if size > MAX_INLINE_BYTES:
        return _json.dumps(
            {**data, "as_image_skipped": f"file too large for inline ({size} > {MAX_INLINE_BYTES})"},
            indent=2, ensure_ascii=False,
        )

    try:
        from fastmcp.utilities.types import Image
    except ImportError:
        return _json.dumps(
            {**data, "as_image_skipped": "fastmcp.utilities.types.Image not available"},
            indent=2, ensure_ascii=False,
        )

    fmt = "jpeg" if ext == "jpg" else ext
    return Image(path=str(p), format=fmt)


@mcp.tool()
def hsdes_download_all_ips_attachments(
    article_id: str,
    dest_dir: str = "",
    max_workers: int = 4,
) -> str:
    """Download every IPS/ESFT attachment of an article in one shot.

    Downloads run in parallel (default 4 workers) and reuse the per-file cache:
    if a file already exists at the target path with size > 0, it is NOT re-fetched.

    Args:
        article_id: The HSDes article ID (numeric string).
        dest_dir: Directory to save files into. Defaults to %TEMP%/hsdes_ips_<article_id>/.
        max_workers: Concurrent ESFT downloads (default 4, capped at 8).

    Returns a JSON manifest:
      { "hsd_id", "dest_dir", "count", "files": [{filename, output_path, file_size,
        cached, app_file_id, error?}, ...] }
    """
    if not article_id.strip().lstrip('-').isdigit():
        return "article_id must be a numeric HSDes ID."

    import json as _json
    import tempfile
    from concurrent.futures import ThreadPoolExecutor

    if not dest_dir:
        dest_dir = str(Path(tempfile.gettempdir()) / f"hsdes_ips_{article_id}")
    dest = Path(dest_dir)
    dest.mkdir(parents=True, exist_ok=True)

    att_raw = hsdes_get_attachments(article_id)
    payload = _json.loads(att_raw)
    ips = [a for a in payload.get("attachments", []) if a.get("type") == "ips" and a.get("url")]

    if not ips:
        return _json.dumps({
            "hsd_id": article_id, "dest_dir": str(dest), "count": 0, "files": [],
            "message": f"No IPS attachments to download for article {article_id}.",
        }, indent=2)

    workers = max(1, min(int(max_workers), 8))

    def _one(att: dict) -> dict:
        # Filename comes from HSDes/ESFT (ultimately customer-supplied) — treat
        # as untrusted: strip path components so a hostile name like
        # `../../boot.ini` or `\\share\foo` can't escape dest_dir. Pair with
        # an AppFileID subdir so two attachments with the same display name
        # land in distinct files instead of overwriting each other.
        fname = _safe_basename(att.get("filename"))
        safe_id = _safe_app_file_id(att.get("app_file_id") or "")
        if safe_id:
            out_path = dest / safe_id / fname
            out_path.parent.mkdir(parents=True, exist_ok=True)
        else:
            out_path = dest / fname
        # Re-using hsdes_download_ips_attachment also gives us cache + esft check.
        result_raw = hsdes_download_ips_attachment(url=att["url"], output_path=str(out_path))
        try:
            r = _json.loads(result_raw) if isinstance(result_raw, str) else {}
        except _json.JSONDecodeError:
            r = {"success": False, "error": str(result_raw)[:200]}
        return {
            "filename": fname,
            "app_file_id": att.get("app_file_id"),
            "output_path": r.get("output_path", str(out_path)),
            "file_size": r.get("file_size"),
            "cached": bool(r.get("cached")),
            "success": bool(r.get("success")),
            "error": r.get("error"),
        }

    with ThreadPoolExecutor(max_workers=workers) as ex:
        files = list(ex.map(_one, ips))

    ok = sum(1 for f in files if f["success"])
    cached = sum(1 for f in files if f["cached"])
    return _json.dumps({
        "hsd_id": article_id,
        "dest_dir": str(dest),
        "count": len(files),
        "files": files,
        "message": f"Downloaded {ok}/{len(files)} IPS attachments ({cached} from cache) to {dest}.",
    }, indent=2, ensure_ascii=False)


@mcp.tool()
def hsdes_upload_ips_attachment(
    article_id: str,
    file_path: str,
    description: str,
    visibility: str = "auto",
    dry_run: bool = True,
) -> str:
    """Upload a file to ESFT/IPS for an HSDes article — no browser tab needed.

    Mirrors the SFT IPS Upload web UI (esft-int.intel.com/sftipsupload) protocol:
      1. Pull caseid + visibility from server_platf_ae.bug.upload_attach_to_ips
         on the article (the same <a href> the web UI uses).
      2. Slice the file into 10 MB chunks under one AppFileID and POST each
         chunk to /sftservices/upload/IPS_SFT/ with Windows integrated auth.
      3. Verify by calling /sftservices/getfileuploaddetail/ — return surfaces
         a `verify` block with status/sft_path/upload_status_date so callers
         do not have to wait on the HSDes mirror cron just to confirm the
         upload landed.
      4. ESFT auto-mirrors IPS_SFT → HSDES_SFT, so the file eventually appears
         on the article (use hsdes_get_attachments to confirm; mirror is
         async and may take minutes).

    Dry-run defaults to True. The first call returns the resolved caseid +
    visibility + chunk plan WITHOUT uploading. Re-run with dry_run=False
    after the user confirms the target article and visibility look right.
    Uploads to customer-visible visibility (e.g. Public_to_Customers) are
    irreversible from this tool — there is no delete API.

    Args:
        article_id: HSDes article ID (numeric). Used to look up the SFDC caseid.
        file_path: Absolute local path to the file to upload.
        description: Description text. Goes into the multipart Comment field —
            the same field the web UI's "Description" textbox writes to.
        visibility: One of 'auto' (default — pick the first link in the article,
            usually Public), 'public', 'internal', 'partner'. Maps to
            Public_to_Customers / Private_to_Intel / Private_to_Partner.
        dry_run: When True (default) skip the actual POST and only return the
            resolved metadata. Set to False to perform the upload.
    """
    import json as _json

    if not article_id.strip().lstrip('-').isdigit():
        return _json.dumps({"success": False, "error": "article_id must be numeric."})
    if visibility not in ("auto", "public", "internal", "partner"):
        return _json.dumps({"success": False, "error": "visibility must be one of: auto, public, internal, partner."})
    if not Path(file_path).is_file():
        return _json.dumps({"success": False, "error": f"file_path not found: {file_path}"})
    if not description or not description.strip():
        return _json.dumps({"success": False, "error": "description is required (goes into ESFT Comment field)."})

    raw = _run_ps1(
        "hsdes_upload_ips.ps1",
        ArticleId=article_id,
        FilePath=file_path,
        Description=description,
        Visibility=visibility,
        DryRun=dry_run,
    )
    data = _parse_ps1_json(raw)
    if data:
        return _json.dumps(data, indent=2, ensure_ascii=False)
    return raw


_RE_ARTICLE_ID = re.compile(r'"id"\s*:\s*"(\d{8,})"')
_HSDES_ARTICLE_URL = "https://hsdes.intel.com/appstore/article-one/#/article/{id}"


def _add_article_urls(text: str) -> str:
    """Inject a 'url' field next to each article id so AI always renders IDs as links."""
    def _replace(m: re.Match) -> str:
        article_id = m.group(1)
        url = _HSDES_ARTICLE_URL.format(id=article_id)
        return f'"id": "{article_id}", "url": "{url}"'
    return _RE_ARTICLE_ID.sub(_replace, text)


def _enrich_owners(text: str) -> str:
    """Replace owner IDs with 'idsid (Full Name)' format in query results."""
    # Match owner values that don't already contain enrichment (no parenthesis)
    owners = sorted(set(re.findall(r'"owner"\s*:\s*"([^"(]+)"', text)))
    if not owners:
        return text

    def _lookup(idsid: str) -> tuple[str, str]:
        info = _run_ps1("hsdes_user_info.ps1", Idsid=idsid)
        m = re.search(r'Name:\s*(.+)', info)
        return idsid, m.group(1).strip() if m else ''

    name_map = {}
    with ThreadPoolExecutor(max_workers=min(len(owners), 10)) as ex:
        for idsid, name in ex.map(_lookup, owners):
            if name:
                name_map[idsid] = name

    for idsid, name in name_map.items():
        text = re.sub(
            rf'"owner"\s*:\s*"{re.escape(idsid)}"',
            lambda m, i=idsid, n=name: f'"owner": "{i} ({n})"',
            text,
        )
    return text


def _get_output_format_section(ref_filename: str) -> str:
    """Extract the ## Output Format section from a reference file."""
    ref_path = REFS_DIR / ref_filename
    if not ref_path.exists():
        return ""
    try:
        content = ref_path.read_text(encoding='utf-8')
        if '## Output Format' not in content:
            return ""
        start = content.index('## Output Format')
        # Find next ## section after Output Format
        rest = content[start + len('## Output Format'):]
        next_section = rest.find('\n## ')
        end = start + len('## Output Format') + next_section if next_section != -1 else len(content)
        return content[start:end].strip()
    except Exception:
        return ""


@mcp.tool()
def hsdes_get_saved_query(
    query_id: str,
    max_results: int = 200,
    include_description: bool = False,
    include_comments: bool = False,
    include_customer_history: bool = False,
    format: str = "text",
) -> str:
    """EXECUTE a saved HSDes query and return matching articles. Use when user provides a saved query URL or query ID.
    To extract query ID from URL: ?queryId={id} or community_legacy/#/{id} → pass that numeric ID as query_id.
    NOTE: This RUNS the query and returns matching articles. To inspect the query definition (title, EQL, owner), use hsdes_get_saved_query_definition instead.

    By default strips heavy fields (description, comments, ext_cust_blog_hist) from each row to avoid
    token overflow when the saved query is configured to include them. To inspect those fields,
    either set the include_* flag here, or call hsdes_get_article(include_description=True,
    include_customer_history=True) / hsdes_get_article_context per article id.

    Args:
        query_id: The saved query ID.
        max_results: Maximum number of results to return (default 200).
        include_description: If True, keep `description` in saved query rows. Default False.
        include_comments: If True, keep `comments` in saved query rows. Default False.
        include_customer_history: If True, keep `ext_cust_blog_hist` in saved query rows. Default False.
        format: 'text' (default) or 'html'. When 'text', HTML body fields kept by include_* are converted to plain text in PowerShell before serialization. Pass 'html' only if you specifically need raw HTML markup.
    """
    keep_fields: list[str] = []
    if include_description:
        keep_fields.append("description")
    if include_comments:
        keep_fields.append("comments")
    if include_customer_history:
        keep_fields.append("ext_cust_blog_hist")
        keep_fields.append("server_platf_ae.bug.ext_cust_blog_hist")

    # PS1 strips bomb fields at the source, before JSON serialization. This is critical
    # because HSDes embeds malformed HTML (unescaped quotes, raw control chars) inside
    # ext_cust_blog_hist for some rows, which breaks Python's json.loads. Doing the
    # strip on the parsed PowerShell object — before ConvertTo-Json — sidesteps that.
    fmt = format.strip().lower() if format else "text"
    if fmt not in ("text", "html"):
        fmt = "text"
    results = _run_ps1(
        "hsdes_saved_query.ps1",
        QueryId=query_id,
        MaxResults=max_results,
        StripBombFields=True,
        KeepFields=",".join(keep_fields),
        Format=fmt,
    )

    # Read PS1's _stripped metadata (per-field counts) and remove from response body.
    # strict=False is required because HSDes embeds raw control chars (e.g. \x1a) inside
    # other text fields like irf_notes, which Python's strict json.loads rejects. The
    # subsequent json.dumps will re-emit them as proper \uXXXX escapes.
    stripped: dict[str, int] = {}
    try:
        import json as _json_mod
        obj = _json_mod.loads(results, strict=False)
        if isinstance(obj, dict) and "_stripped" in obj:
            ps1_meta = obj.pop("_stripped")
            if isinstance(ps1_meta, dict):
                stripped = {k: int(v) for k, v in ps1_meta.items() if int(v) > 0}
        results = _json_mod.dumps(obj, ensure_ascii=False)
    except Exception:
        # If json.loads still fails, fall through — Python-side strip below handles it.
        pass

    # Defense-in-depth: also run Python-side strip in case PS1 didn't honor the flag
    # (e.g., user pinned an older script). Idempotent — no-op if PS1 already stripped.
    results, py_stripped = _strip_saved_query_bomb_fields(
        results,
        include_description=include_description,
        include_comments=include_comments,
        include_customer_history=include_customer_history,
    )
    for k, v in py_stripped.items():
        stripped[k] = stripped.get(k, 0) + v

    results, b64_stats = _strip_base64_images(results)
    results = _add_article_urls(_enrich_owners(results))

    sections: list[str] = []

    if stripped:
        parts = ", ".join(f"{f}={n}" for f, n in stripped.items())
        sections.append(
            f"NOTE: heavy fields were stripped from saved query rows to avoid token overflow ({parts}). "
            f"To read those fields, call hsdes_get_article(article_id, include_description=True, "
            f"include_customer_history=True) or hsdes_get_article_context per id, or re-run this tool "
            f"with the matching include_* flag set to True."
        )

    if b64_stats["count"]:
        sections.append(
            f"NOTE: stripped {b64_stats['count']} inline base64 image(s) "
            f"({b64_stats['bytes_saved']:,} chars saved). "
            f"Use hsdes_get_images(article_id) to retrieve images as files."
        )

    # For known IRF queries, prepend the output format so the AI always formats correctly
    ref_file = IRF_QUERY_REFS.get(query_id)
    if ref_file:
        output_format = _get_output_format_section(ref_file)
        if output_format:
            sections.append(output_format)

    if sections:
        return "\n\n---\n\n".join(sections + [results])

    return results


@mcp.tool()
def hsdes_get_saved_query_definition(query_id: str) -> str:
    """Get the DEFINITION (metadata) of a saved HSDes query: title, EQL expression, owner, description.
    ONLY use when the user explicitly asks to inspect, view, or edit the query definition itself.
    DO NOT use this to run a query or get results — use hsdes_get_saved_query for that.
    DO NOT use this when user provides a saved query URL and wants to list issues — use hsdes_get_saved_query instead.

    Args:
        query_id: The saved query ID (numeric string, e.g. '22020838886').
    """
    return _run_ps1("hsdes_saved_query_def.ps1", QueryId=query_id)


@mcp.tool()
def hsdes_email_to_idsid(email: str) -> str:
    """STEP 1 for team queries: Convert Intel email to IDSID. Then use IDSID in REPORTS_TO operator. Example: 'henry.y.sun@intel.com' → 'hsun21' → use in WHERE owner REPORTS_TO 'hsun21'."""
    return _run_ps1("hsdes_user_by_email.ps1", Email=email)


@mcp.tool()
def hsdes_get_user_info(idsid: str, resolve_chain: bool = True) -> str:
    """Lookup user org + manager chain (MGL1/2/3) by IDSID.

    By default (resolve_chain=True) also fetches each manager's name and email in parallel —
    use this for "who is X's manager" questions so you don't have to make 3 follow-up calls.
    Set resolve_chain=False for faster lookups when only IDSIDs are needed.

    Returns user metadata only, NOT for querying bugs. For bug queries use owner REPORTS_TO 'idsid' in EQL."""
    return _run_ps1("hsdes_user_info.ps1", Idsid=idsid, ResolveChain=resolve_chain)


@mcp.tool()
def hsdes_get_current_user() -> str:
    """Get the current user's IDSID, name, and email from HSDes. Use ONLY when you need the user's identity metadata (e.g. to display "you are hcheng20"). For "owned by me" queries, prefer the EQL operator `owner is me` directly — no need to round-trip through this tool. For team queries, the team owner's idsid still requires hsdes_email_to_idsid + REPORTS_TO."""
    return _run_ps1("hsdes_current_user.ps1")


# Known IRF saved query IDs → reference file (auto-inject output format)
# IMPORTANT: Each reference file listed here MUST have a "## Output Format" section.
# _get_output_format_section() returns "" if the section is missing, silently skipping injection.
# Also add to TEMPLATE_ALIASES below and to the system prompt IRF QUERIES section above.
IRF_QUERY_REFS = {
    '15013555803': 'irf-platform-query.md',    # Platform IRF (BHS/OKS All Geos)
    '15018339809': 'irf-firmware-query.md',    # Firmware IRF (OKS+BHS BIOS ASIA)
    '14026166360': 'irf-dmr-ptp-soc-query.md', # DMR PTP_SoC Sightings
    '15014794041': 'irf-dmr-cfm-bug-query.md', # DMR Central Firmware Bugs
    '15017467796': 'irf-hsio-query.md',        # HSIO IRF (BHS/OKS PCIe/CXL APAC)
    '15015935984': 'irf-memory-query.md',      # Memory IRF (BHS/OKS Memory APAC)
}

# Template short name mappings
TEMPLATE_ALIASES = {
    'firmware-irf': 'irf-firmware-query.md',
    'platform-irf': 'irf-platform-query.md',
    'dmr-ptp': 'irf-dmr-ptp-soc-query.md',
    'dmr-cfm': 'irf-dmr-cfm-bug-query.md',
    'hsio-irf':   'irf-hsio-query.md',
    'memory-irf': 'irf-memory-query.md',
}


@mcp.tool()
def hsdes_get_query_template(template_name: str) -> str:
    """Get a pre-defined HSDes saved query template for IRF or cross-tenant queries. ONLY use for the named templates below — do NOT use this to look up EQL syntax or field mappings.

    Templates:
    - 'firmware-irf' - OKS+BHS BIOS ASIA IRF (ID: 15018339809)
    - 'platform-irf' - Platform IRF All Geos (ID: 15013555803)
    - 'hsio-irf'     - HSIO IRF BHS/OKS PCIe/CXL APAC (ID: 15017467796)
    - 'memory-irf'   - Memory IRF BHS/OKS Memory APAC (ID: 15015935984)
    - 'dmr-ptp'      - DMR PTP_SoC sightings (cross-tenant)
    - 'dmr-cfm'      - DMR central_firmware bugs

    Returns the saved query EQL and output format to use with hsdes_get_saved_query.
    """
    # Resolve short name to filename
    filename = TEMPLATE_ALIASES.get(template_name, template_name)

    # Build file path
    file_path = REFS_DIR / filename

    # Validate path stays within REFS_DIR (prevent path traversal)
    try:
        resolved_path = file_path.resolve()
        refs_abs = REFS_DIR.resolve()
        if not resolved_path.is_relative_to(refs_abs):
            return f"❌ Invalid template path '{template_name}' - access denied."
    except (ValueError, OSError) as e:
        return f"❌ Invalid template path: {e}"

    # Check if file exists
    if not file_path.exists():
        available = "\n".join([f"- {k} ({v})" for k, v in TEMPLATE_ALIASES.items()])
        return f"❌ Template '{template_name}' not found.\n\nAvailable templates:\n{available}\n\nOr use any filename from references/ directory."

    # Read and return file content
    try:
        return file_path.read_text(encoding='utf-8')
    except (OSError, UnicodeDecodeError) as e:
        return f"❌ Error reading template: {e}"


# --- MCP Resources (for VS Code - skills knowledge) ---


def _read_file(path: Path) -> str:
    """Read a file and return its contents."""
    if path.exists():
        return path.read_text(encoding="utf-8")
    return f"File not found: {path}"


@mcp.resource("hsdes://guide")
def get_comprehensive_guide() -> str:
    """Complete HSDes EQL reference - syntax, mappings, examples, and best practices.

    This is the MASTER reference containing all information needed to generate correct queries.
    Always consult this before generating EQL queries for complex or ambiguous user requests.
    """
    # Combine all reference files into a single comprehensive resource
    parts = [
        "# HSDes Complete Reference Guide\n",
        "This guide contains everything needed to generate correct HSDes EQL queries.\n",
        "\n---\n\n## Part 1: Quick Mappings\n",
        _read_file(REFS_DIR / "field-mappings.md"),
        "\n---\n\n## Part 2: EQL Syntax Reference\n",
        _read_file(REFS_DIR / "eql-syntax.md"),
        "\n---\n\n## Part 3: Query Skill & Templates\n",
        _read_file(SKILLS_DIR / "hsdes-query" / "SKILL.md"),
    ]
    return "\n".join(parts)


@mcp.resource("hsdes://eql-syntax")
def get_eql_syntax() -> str:
    """EQL syntax reference - operators, date functions, common patterns."""
    return _read_file(REFS_DIR / "eql-syntax.md")


@mcp.resource("hsdes://field-mappings")
def get_field_mappings() -> str:
    """Field mappings - customer abbreviations, platform names, field paths."""
    return _read_file(REFS_DIR / "field-mappings.md")


if __name__ == "__main__":
    print(f"[hsdes] v{_VERSION}", file=sys.stderr)
    mcp.run()
