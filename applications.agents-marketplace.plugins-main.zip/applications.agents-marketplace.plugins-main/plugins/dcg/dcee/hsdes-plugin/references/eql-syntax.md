# HSDes EQL Syntax Reference

## Critical Rules

1. **Operators**: Uppercase only - `CONTAINS`, `EQUALS`, `NOT_EQUAL`, `SORTBY`
2. **Strings**: Single quotes only - `'value'` (NOT `"value"`)
3. **NOT operator**: Use `NOT_EQUAL` (NOT `!=`)
4. **SORTBY fields**: Must be in SELECT clause
5. **NO FROM clause**: Use `WHERE tenant = '...' AND subject = '...'`
6. **Parentheses**: Supported - `(field1 OR field2)`
7. **Multi-line**: MCP server auto-converts (parser doesn't support `\n`)

## Query Structure

### Basic Query
```eql
SELECT field1, field2, tenant.subject.field3
WHERE tenant = 'tenant_name'
AND subject = 'subject_type'
AND condition1
AND condition2
SORTBY field DESC
```

### Hierarchical Query (Parent/Child/Link)
For querying parent-child relationships or linked articles:

```eql
-- Using Child (legacy, being deprecated)
SELECT id, title
WHERE Parent(tenant.subject.field = 'value'), Child(child_subject.field = 'value')
SORTBY field DESC

-- Using LINK (recommended)
SELECT id, title
WHERE Parent(server.bugeco.status = 'approved'), LINK_parent-child(ar.status = 'not_done')
SORTBY field DESC
```

**Important:**
- `Parent()` required when using `Child()` or `LINK_()`
- Cannot mix Child and Link - use one or the other
- Prefer LINK_<linktype> over Child

**Flags** (optional):
- `DirectChildren` - Only direct children
- `LeftJoin` - All parents even without matching children

Example: `WHERE Parent(...), Child(...), DirectChildren`

### Field Aliases
```eql
SELECT tenant.subject.field AS 'shortname'
-- Shortname must be subset of fullname: 'field', 'subject.field', or 'tenant.subject.field'
```

Operators follow the format: `LHS <operator> RHS`
- **LHS** = field name (left-hand side)
- **RHS** = value or value list (right-hand side)

Example: `Field1 EQUALS 'abc'` — LHS is `Field1`, RHS is `'abc'`

## EQL Operators — Complete Reference

### Equality

| Operator | Alias | Description | Example |
|----------|-------|-------------|---------|
| `EQUALS` | `=` | Exact match | `status = 'open'` |
| `NOT_EQUAL` | — | Not equal (use keyword, NOT `!=`) | `exposure NOT_EQUAL '4-low'` |

### List Membership

| Operator | Description | Example |
|----------|-------------|---------|
| `IN` | LHS value is in RHS list (parentheses required) | `status IN ('open', 'complete')` |
| `NOT_IN` / `NOT IN` | LHS value is not in RHS list | `status NOT IN ('rejected')` |

### String Matching

| Operator | Description | Example |
|----------|-------------|---------|
| `CONTAINS` | RHS is a substring of LHS. Supports SQL LIKE wildcards | `release CONTAINS 'birch'` |
| `DOES_NOT_CONTAIN` | RHS is not a substring of LHS | `title DOES_NOT_CONTAIN 'PRW'` |
| `STARTS_WITH` | LHS begins with RHS | `title STARTS_WITH '[DMR]'` |
| `DOES_NOT_START_WITH` | Opposite of STARTS_WITH | `title DOES_NOT_START_WITH '[DTI]'` |
| `ENDS_WITH` | LHS ends with RHS | `tag ENDS_WITH '_IRF'` |
| `DOES_NOT_END_WITH` | Opposite of ENDS_WITH | `tag DOES_NOT_END_WITH '_NTA'` |

**CONTAINS wildcards** (same as SQL LIKE):
- `%` — matches 0 or more characters
- `_` — matches exactly one character
- `[]` — character list, also escapes wildcard characters
- See: http://msdn.microsoft.com/en-us/library/ms179859.aspx

### Comparison

| Operator | Alias | Description | Example |
|----------|-------|-------------|---------|
| `GREATER_THAN` | `>` | LHS > RHS (numeric or ASCII) | `submitted_date > DaysAgo(5)` |
| `LESS_THAN` | `<` | LHS < RHS | `submitted_date < 'now-6d'` |
| `GREATER_THAN_OR_EQUAL_TO` | `>=` | LHS >= RHS | `priority >= 'p2-high'` |
| `LESS_THAN_OR_EQUAL_TO` | `<=` | LHS <= RHS | `updated_date <= '01/15/2025'` |
| `BETWEEN` | — | LHS >= lower AND LHS <= upper | `submitted_date BETWEEN '01/01/2025' AND '01/31/2025'` |

**BETWEEN format:** `<field> BETWEEN <lower_limit> AND <upper_limit>`

### Empty / Null Checks

| Operator | Description | Example |
|----------|-------------|---------|
| `IS_EMPTY` | Field value is empty | `irf_disposition_date IS_EMPTY` |
| `IS_NOT_EMPTY` | Field value is not empty | `int_sighting_url IS_NOT_EMPTY` |

### Special Operators

| Operator | Description | Example |
|----------|-------------|---------|
| `IS ME` | Field matches current authenticated user | `WHERE owner IS ME` |
| `REPORTS_TO` | All direct/indirect reportees of a manager (max 100 reportees, IDSID only) | `WHERE owner REPORTS_TO 'hsun21'` |

> **Important:**
> - `REPORTS_TO` requires IDSID format (e.g. `'hsun21'`), NOT email or employee number
> - For "manager's team" or "user's team" queries, ALWAYS use `owner REPORTS_TO 'idsid'`
> - **NOT** `team =`, `manager =`, `owner_ldap_group =` (these fields don't exist)

### Logical

| Operator | Description | Example |
|----------|-------------|---------|
| `AND` | Logical AND | `status = 'open' AND priority = 'p2-high'` |
| `OR` | Logical OR | `tag CONTAINS 'pnp' OR tag CONTAINS 'perf'` |

### Sorting

| Operator | Description | Example |
|----------|-------------|---------|
| `SORTBY` | Sort results (ASC/DESC) | `SORTBY submitted_date DESC` |

## Working with Dates

### Relative Date Functions

| Function | Description | Example |
|----------|-------------|---------|
| `DaysAgo(N)` | N days before today | `submitted_date > DaysAgo(5)` |
| `DaysFromNow(N)` | N days after today | `due_date < DaysFromNow(7)` |
| `WeeksAgo(N)` | N weeks before today | `updated_date > WeeksAgo(2)` |
| `WeeksFromNow(N)` | N weeks after today | |
| `MonthsAgo(N)` | N months before today | `submitted_date > MonthsAgo(3)` |
| `MonthsFromNow(N)` | N months after today | |
| `HoursAgo(N)` | N hours ago from now | `updated_date > HoursAgo(24)` |
| `HoursFromNow(N)` | N hours after now | |
| `MinutesAgo(N)` | N minutes ago from now | |
| `MinutesFromNow(N)` | N minutes from now | |
| `Today` | Current date | `submitted_date = Today` |
| `Tomorrow` | Next day | |
| `Yesterday` | Previous day | `submitted_date > Yesterday` |

### Specific Date Formats

```
'MM/dd/yyyy HH:mm:ss'    e.g. '12/31/2024 23:59:59'
'MM/dd/yyyy'              e.g. '01/15/2025'
'yyyy-MM-dd'              e.g. '2026-04-01'
```

> **Note:** All dates are rounded to .000 milliseconds.

> **WARNING: CONTAINS does NOT work on date fields.** Using `submitted_date CONTAINS '2026-04'` causes an ElasticSearch query count service error. For month/year filtering, always use a `>=` / `<` range:
> ```eql
> -- Filter by month (April 2026)
> submitted_date >= '2026-04-01' AND submitted_date < '2026-05-01'
> ```

### Shorthand Date Syntax

The shorthand `'now-Nd'` syntax is also commonly used:
```eql
submitted_date > 'now-30d'    -- Last 30 days (equivalent to DaysAgo(30))
submitted_date < 'now-6d'     -- Older than 6 days
```

### Date Examples

```eql
-- Tickets submitted in last 5 days
WHERE submitted_date GREATER_THAN DaysAgo(5)
WHERE submitted_date > DaysAgo(5)

-- Tickets submitted after a specific date
WHERE submitted_date > '12/31/2018 23:59:59'

-- Tickets submitted in a date range
WHERE submitted_date BETWEEN '01/01/2025' AND '03/31/2025'
```

## Common Patterns

### Multiple Values with EQUALS
```eql
( server_platf_ae.bug.customer_company EQUALS 'google'
  OR server_platf_ae.bug.customer_company EQUALS 'microsoft' )
```

### Multiple Values with CONTAINS
```eql
( release CONTAINS 'birch' OR release CONTAINS 'oak' )
```

### Empty/Non-empty Checks
```eql
server_platf_ae.bug.ext_attach_url IS_NOT_EMPTY   -- Has attachments
server_platf_ae.bug.irf_disposition_date IS_EMPTY -- No disposition
```

### Current User Filter
```eql
WHERE owner IS ME
```

### Manager Reportees Filter
```eql
WHERE owner REPORTS_TO 'manager_idsid' AND status = 'open'
```

## JSON Field Support (Advanced)

HSDes supports querying JSON-type custom fields using JSONPath syntax:

```eql
-- Select from JSON structure (field type must be "json")
SELECT id, [tenant.subject.myjsonfield$.a.d]
WHERE [tenant.subject.myjsonfield$.a.d] = 'value'

-- Check if array contains value
SELECT id WHERE [tenant.subject.myjsonfield$.b] has '"value"'
```

**Important:**
- Field must be created as "json" type in ESBuilder
- JSONPath (text after `$`) cannot contain: `` ` ' ] [ ``
- Use squared brackets `[ ]` to enclose JSON field references
- For array containment, use `has` operator

**Example:**
```json
// Field value: {"a": {"d":"e"}, "b": ["b1","b2"], "c": 3}

// Query:
SELECT id, [tenant.subject.field$.a.d]
WHERE [tenant.subject.field$.b] has '"b1"'
```

---

## API Endpoints

### EQL Query Execution
```
POST https://hsdes-api.intel.com/rest/query/execution/eql?start_at=1&max_results=10000
Content-Type: application/json
Body: {"eql": "YOUR_EQL_QUERY"}
```

### Execute Saved Query by ID
For SQL-based or cross-tenant saved queries that cannot be expressed as EQL:
```
GET https://hsdes-api.intel.com/rest/query/execution/{queryId}?start_at=1&max_results=10000
```

### Get Article Links (Related/Promoted)
```
GET https://hsdes-api.intel.com/rest/article/{articleId}/links
```

### Get Saved Query Metadata
```
GET https://hsdes-api.intel.com/rest/query/MetaData?id={queryId}
```

## Link Response Structure

```json
{
  "responses": [
    {
      "subject": "bug|sighting|quality_event|folder",
      "id": "article_id",
      "tenant": "tenant_name",
      "status": "status",
      "title": "article_title",
      "relationship": "related-link|child-parent",
      "owner": "owner_id"
    }
  ]
}
```

### Finding Promoted Issues
- `subject = "sighting"` with `tenant = "sighting_central"` → promoted to central tracking
- `subject = "quality_event"` → CFB/quality tracking
- `tenant = "central_firmware"` → promoted to firmware tracking

## Common Errors

### ❌ Using FROM clause (NOT SUPPORTED)
```eql
-- WRONG - HSDes EQL does NOT support FROM
SELECT id, title FROM server_platf.sighting WHERE priority = 'critical'
```
**Error:** `Syntax Error -- Error 2: Unexpected "FROM"`

**Fix:** Remove FROM, use tenant/subject in WHERE
```eql
-- CORRECT
SELECT id, title WHERE tenant = 'server_platf' AND subject = 'sighting' AND priority = 'critical'
```

### ❌ Using double quotes for strings
```eql
-- WRONG
WHERE tenant = "server_platf_ae"
```
**Error:** EQL parser error

**Fix:** Use single quotes
```eql
-- CORRECT
WHERE tenant = 'server_platf_ae'
```

### ❌ SORTBY field not in SELECT
```eql
-- WRONG
SELECT id, title WHERE tenant = 'server_platf_ae' SORTBY submitted_date DESC
```
**Error:** `Error 49: SORTBY criteria needs to match at least one short name from select clause`

**Fix:** Include field in SELECT
```eql
-- CORRECT
SELECT id, title, submitted_date WHERE tenant = 'server_platf_ae' SORTBY submitted_date DESC
```

### ❌ Lowercase operators
```eql
-- WRONG
WHERE status equals 'open' and tenant contains 'server'
```
**Error:** Parser error

**Fix:** Use uppercase operators
```eql
-- CORRECT
WHERE status EQUALS 'open' AND tenant CONTAINS 'server'
```
