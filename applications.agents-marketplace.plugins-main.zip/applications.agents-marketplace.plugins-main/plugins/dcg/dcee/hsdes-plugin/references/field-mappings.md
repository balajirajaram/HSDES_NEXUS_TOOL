# HSDes Field Mappings Reference

## Customer Abbreviations

| Abbrev | HSDes Value | Abbrev | HSDes Value |
|--------|-------------|--------|-------------|
| GGL | `google` | MSFT | `microsoft` |
| Dell | `dell` | HPE | `hp_enterprise` |
| Meta/FB | `facebook` | AWS | `amazon` |
| LNV | `lenovo` | QCT/Quanta | `quanta` |
| SMCI | `super_micro` | FXN | `foxconn` |
| IEC | `inventec` | Compal | `compal` |
| Pega | `pegatron` | WW | `wiwynn` |
| Mitac | `mitac` | ASR | `asrock` |
| Giga | `gigabyte` | Asus | `asustek` |
| NV | `nvidia` | ORCL | `oracle` |

## Platform Abbreviations

> **IMPORTANT:** Release field naming differs by tenant. Use the correct filter for the tenant you are querying — wrong tenant filter returns zero results.

### server_platf_ae.bug / server_platf.bug / server_platf.feature
Release values are full human-readable strings containing the CPU abbreviation.

| User Input | EQL Filter | Example Release Value |
|------------|-----------|----------------------|
| DMR, Diamond Rapids | `CONTAINS 'DMR'` | `Oak Stream Platform 1 DMR` |
| OKS family (all) | `CONTAINS 'Oak Stream'` | `Oak Stream Platform 1 DMR` |
| GNR, Granite Rapids | `CONTAINS 'GNR'` | `Birch Stream Platform GNR SP` |
| SRF, Sierra Forest | `CONTAINS 'SRF'` | `Birch Stream Platform SRF SP` |
| CWF, ClearWater Forest | `CONTAINS 'CWF'` | `Birch Stream Platform CWF AP` |
| BHS family (all) | `CONTAINS 'Birch Stream'` | `Birch Stream Platform GNR SP` |
| EMR, Emerald Rapids | `CONTAINS 'EMR'` | `Eagle Stream EMR SP` |
| SKX, Skylake Server | `CONTAINS 'purley'` | Legacy |
| ICX, Icelake Server | `CONTAINS 'whitley'` | Legacy |

### central_firmware.bug / central_firmware.feature
Release values use `bios.` / `ifwi.` / `patch.` prefix with underscore-separated codenames.

| User Input | EQL Filter | Example Release Value |
|------------|-----------|----------------------|
| DMR, OKS+DMR | `CONTAINS 'oakstream_diamondrapids'` | `bios.oakstream_diamondrapids` |
| OKS family (all) | `CONTAINS 'oakstream'` | `bios.oakstream_diamondrapids` |
| GNR, BHS+GNR | `CONTAINS 'graniterapids'` | `bios.birchstream_graniterapids-ap` |
| BHS family (all) | `CONTAINS 'birchstream'` | `bios.birchstream_graniterapids-ap` |

> Note: SRF and CWF are BHS variants — use `CONTAINS 'birchstream'` to include them.

### sighting_central.sighting
Release values use `package.` / `pkg.` prefix with short lowercase CPU codenames.

| User Input | EQL Filter | Example Release Value |
|------------|-----------|----------------------|
| DMR, Diamond Rapids | `CONTAINS 'dmr'` | `pkg.dmr-a0`, `package.dmrap-ucc-x1-a0` |
| GNR, Granite Rapids | `CONTAINS 'gnr'` | `package.gnrap-ucc-x3-b3`, `gnr7-a0` |
| CWF, ClearWater Forest | `CONTAINS 'cwf'` | `package.cwfap-xdcc-b0` |
| SRF, Sierra Forest | `CONTAINS 'srf'` | `package.srfsp-lcc-c0` |

> Note: No single BHS umbrella filter exists in this tenant. To query all BHS sightings combine: `(release CONTAINS 'gnr' OR release CONTAINS 'cwf' OR release CONTAINS 'srf')`

> Note: GRR (`grr-b0`) does NOT contain 'gnr' — `CONTAINS 'gnr'` safely excludes GRR.

## Subject / Article Type Terminology

| HSDes subject | Intel Term | Meaning |
|---------------|------------|---------|
| `bug` | Bug / Debug Request | Defect or silicon sighting |
| `feature` | CCB | Post-silicon Change Control Board item |
| `feature` | POR | Plan of Record item |
| `sighting` | Sighting | Silicon sighting (sighting_central only) |

> When users say "CCB" or "POR", query with `subject = 'feature'`.
> For CCB/POR queries, use `server_platf.feature` (not `server_platf_ae.feature`).

## Status Mappings

| User Input | EQL Value |
|------------|-----------|
| closed | `status = 'complete'` |
| open | `status = 'open'` |

## Priority Mappings

| User Input | EQL Value |
|------------|-----------|
| P1, hotlist | `p1-showstopper` |
| P2 | `p2-high` |
| P3 | `p3-medium` |
| P4 | `p4-low` |

## Exposure Mappings

Use with prefix `server_platf_ae.bug.exposure`:
- `1-critical`, `2-high`, `3-medium`, `4-low`

## Component Mappings

| User Input | EQL Value |
|------------|-----------|
| FACR | `component = 'platform.cpu_dpm'` |

## Field Name Reference

### Base Fields (no prefix needed)
`id`, `title`, `owner`, `submitted_date`, `release`, `status`, `component`, `updated_date`, `priority`, `tag`, `description`, `comments`

### Tenant-Specific Fields

Many fields are scoped to a specific `tenant.subject` and require the corresponding prefix. The same field name may exist in different tenants with different prefixes.

| Tenant.Subject | Prefix | Example Fields |
|----------------|--------|----------------|
| `server_platf_ae.bug` | `server_platf_ae.bug.` | `customer_company`, `customer_project_name`, `ext_source_id`, `int_sighting_url`, `odm`, `ext_attach_url`, `ext_cust_blog_hist`, `owner_geo`, `exposure`, `co_owners`, `irf_notes`, `irf_disposition_date`, `article_type`, `current_owner_org` |
| `sighting_central.sighting` | `sighting_central.sighting.` / `sighting.` | `days_open`, `sub_forum`, `sysdbg_notes1`, `team_found`, `forum` |
| `server_platf.bug` | `server_platf.bug.` / `bug.` | `forum`, `exposure`, `platform` |
| `central_firmware.bug` | `central_firmware.bug.` / `bug.` | `submitter_org`, `days_open`, `regression`, `program_milestone`, `processor`, `fw_subcomponent`, `tools_used`, `review_owner`, `review_status`, `corrective_action_owner`, `corrective_action_status`, `escape_analysis_conclusion`, `customer_affected`, `virtual_fw_release` |

> **Note:** Some fields use a short prefix (e.g. `sighting.forum`, `bug.forum`, `bug.exposure`) while others need the full tenant prefix (e.g. `sighting_central.sighting.days_open`). The short prefix form is `subject.field`; the long form is `tenant.subject.field`. Which form to use depends on the query context and field definition in HSDes.

### Field Abbreviations

| Abbrev | Full Field Path |
|--------|-----------------|
| IPS | `server_platf_ae.bug.ext_source_id` |
| customer blog/history | `server_platf_ae.bug.ext_cust_blog_hist` |

## Default Field Selections

### Standard Query
```
id, title, owner, server_platf_ae.bug.customer_company, server_platf_ae.bug.customer_project_name, submitted_date, server_platf_ae.bug.ext_source_id, release, status, component, updated_date, priority, server_platf_ae.bug.int_sighting_url, server_platf_ae.bug.odm, server_platf_ae.bug.ext_attach_url, tag
```

### Full Article Study
```
id, title, owner, description, tag, submitted_date, comments, server_platf_ae.bug.customer_company, server_platf_ae.bug.customer_project_name, server_platf_ae.bug.ext_source_id, release, status, component, updated_date, priority, server_platf_ae.bug.int_sighting_url, server_platf_ae.bug.odm, server_platf_ae.bug.ext_attach_url, server_platf_ae.bug.ext_cust_blog_hist
```

## Tenant and Subject Defaults

- **Default:** `tenant = 'server_platf_ae'` AND `subject = 'bug'`
- **Common tenants:** `server_platf_ae`, `server_platf`, `client_platf`, `central_firmware`, `sighting_central`
- **Common subjects:** `bug`, `feature`, `testcase`, `requirement`, `sighting`

When user specifies `tenant.subject`:
- "server_platf.feature" → `tenant = 'server_platf'` AND `subject = 'feature'`
- "sighting_central.sighting" → `tenant = 'sighting_central'` AND `subject = 'sighting'`

### Cross-Tenant Queries

Some saved queries span multiple tenants (e.g. `sighting_central.sighting` + `server_platf.bug`). These are stored as **SQL-based queries** (not EQL) and cannot be expressed in EQL. To execute them, use the saved query execution endpoint:
```
GET https://hsdes-api.intel.com/rest/query/execution/{queryId}?start_at=1&max_results=10000
```
