# DMR Central Firmware Bug Query (ID: 15014794041)

**Title:** DMR_Bug_All - Open
**Owner:** junyuton
**Last Updated:** 2024-04-03

**Scope:** Diamond Rapids open BIOS bugs in `central_firmware.bug` tenant

> **Note:** This is a **SQL-based saved query** (`query.flags: SQL`), tenant is `central_firmware` (not `server_platf_ae`). Use the saved query execution endpoint to run it.

## Get Latest Query Metadata from HSDes

```powershell
Invoke-RestMethod -Uri "https://hsdes-api.intel.com/rest/query/MetaData?id=15014794041" `
    -Method Get -UseDefaultCredentials -Headers @{"Accept"="application/json"} -NoProxy
```

## Execute Saved Query

```powershell
Invoke-RestMethod -Uri "https://hsdes-api.intel.com/rest/query/execution/15014794041?start_at=1&max_results=10000" `
    -Method Get -UseDefaultCredentials -Headers @{"Accept"="application/json"} -NoProxy
```

## Query Structure

**Tenant:** `central_firmware`  **Subject:** `bug`

**SELECT fields:**
```
id, title, owner, status, reason, bug.exposure, priority,
central_firmware.bug.submitter_org, component, central_firmware.bug.days_open,
updated_date, bug.report_type, central_firmware.bug.regression, bug.env_found,
central_firmware.bug.program_milestone, release, release_affected,
submitted_date, closed_date, central_firmware.bug.processor, tag,
central_firmware.bug.fw_subcomponent, central_firmware.bug.tools_used,
central_firmware.bug.review_owner, central_firmware.bug.review_status,
central_firmware.bug.corrective_action_owner, central_firmware.bug.corrective_action_status,
central_firmware.bug.escape_analysis_conclusion, bug.root_cause,
central_firmware.bug.family_change_date, central_firmware.bug.release_change_date,
central_firmware.bug.virtual_fw_release, central_firmware.bug.customer_affected,
central_firmware.bug.pre_si_corrective_action, central_firmware.bug.pre_si_corrective_action_owner,
central_firmware.bug.pre_si_corrective_action_status,
central_firmware.bug.pre_si_escape_analysis_conclusion
```

**WHERE logic:** `R1 AND (R2 OR R3) AND R4`

| Rule | Field | Operator | Value |
|------|-------|----------|-------|
| R1 | id | > | 0 |
| R2 | release_affected | IN | 'bios.hudsoncreek', 'bios.hortoncreek' |
| R3 | release_affected | CONTAINS | 'bios.oakstream_diamondrapids' |
| R4 | status | NOT IN | 'rejected', 'complete', 'future' |

## Logic

- **Tenant:** `central_firmware.bug` (Central Firmware bug tracking, not server_platf_ae)
- **Release affected:** Hudson Creek or Horton Creek BIOS, OR Oak Stream Diamond Rapids BIOS
- **Status:** Open (excludes rejected, complete, future)
- **Fields:** Includes extensive firmware-specific fields — corrective action tracking, escape analysis, pre-Si analysis, review status, FW subcomponent, etc.

## central_firmware.bug Specific Fields

| Short Name | Full Field Path |
|------------|-----------------|
| submitter_org | `central_firmware.bug.submitter_org` |
| days_open | `central_firmware.bug.days_open` |
| regression | `central_firmware.bug.regression` |
| program_milestone | `central_firmware.bug.program_milestone` |
| processor | `central_firmware.bug.processor` |
| fw_subcomponent | `central_firmware.bug.fw_subcomponent` |
| tools_used | `central_firmware.bug.tools_used` |
| review_owner | `central_firmware.bug.review_owner` |
| review_status | `central_firmware.bug.review_status` |
| corrective_action_owner | `central_firmware.bug.corrective_action_owner` |
| corrective_action_status | `central_firmware.bug.corrective_action_status` |
| escape_analysis_conclusion | `central_firmware.bug.escape_analysis_conclusion` |
| family_change_date | `central_firmware.bug.family_change_date` |
| release_change_date | `central_firmware.bug.release_change_date` |
| virtual_fw_release | `central_firmware.bug.virtual_fw_release` |
| customer_affected | `central_firmware.bug.customer_affected` |
| pre_si_corrective_action | `central_firmware.bug.pre_si_corrective_action` |
| pre_si_corrective_action_owner | `central_firmware.bug.pre_si_corrective_action_owner` |
| pre_si_corrective_action_status | `central_firmware.bug.pre_si_corrective_action_status` |
| pre_si_escape_analysis_conclusion | `central_firmware.bug.pre_si_escape_analysis_conclusion` |
