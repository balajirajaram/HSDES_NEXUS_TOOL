# DMR PTP_SoC Sightings Query (ID: 14026166360)

**Title:** DMR PTP_SoC Sightings
**Owner:** hvisairo
**Last Updated:** 2025-11-08

**Scope:** Diamond Rapids PTP_SoC sightings across sighting_central and server_platf tenants

> **Note:** This is a **cross-tenant saved query** (SQL-based, not EQL). It spans `sighting_central.sighting` and `server_platf.bug`. Cross-tenant queries cannot be expressed as EQL — use the saved query execution endpoint instead.

## Get Latest Query Metadata from HSDes

```powershell
Invoke-RestMethod -Uri "https://hsdes-api.intel.com/rest/query/MetaData?id=14026166360" `
    -Method Get -UseDefaultCredentials -Headers @{"Accept"="application/json"} -NoProxy
```

## Execute Saved Query

Since this is a cross-tenant SQL query, execute it via the saved query endpoint (not EQL):
```powershell
Invoke-RestMethod -Uri "https://hsdes-api.intel.com/rest/query/execution/14026166360?start_at=1&max_results=10000" `
    -Method Get -UseDefaultCredentials -Headers @{"Accept"="application/json"} -NoProxy
```

## Query Structure

**Tenants:** `sighting_central` (subject: `sighting`) + `server_platf` (subject: `bug`)

**SELECT fields:**
```
id, title, priority, status, reason, owner,
sighting_central.sighting.days_open, sighting.team_found, sighting.forum,
sighting_central.sighting.sub_forum, sighting_central.sighting.sysdbg_notes1, tenant
```

**WHERE logic:** `(R1 OR R4 OR R6 OR R7) AND (R2 OR R8) AND (R3 OR R5 OR R9)`

### sighting_central.sighting criteria

| Rule | Field | Operator | Value |
|------|-------|----------|-------|
| R1 | sighting.forum | IN | 'cpu.analog', 'cpu.logic' |
| R2 | tag | CONTAINS | 'PTP_SoC' |
| R3 | family | IN | 'DIAMOND RAPIDS-AP-LCC', 'DIAMOND RAPIDS-SP-LCC', 'DIAMOND RAPIDS-SP-MCC', 'DIAMOND RAPIDS-SP-HCC', 'DIAMOND RAPIDS-UCC', 'DIAMOND RAPIDS-HCC', 'DIAMOND RAPIDS-LCC', 'DIAMOND RAPIDS-UCC-M', 'DIAMOND RAPIDS-UCC-X1' |
| R4 | sighting.forum | IN | 'testchip.analog', 'testchip.logic' |
| R5 | family | IN | 'Leucadia die' |
| R6 | sighting.forum | IN | 'mfg.srss' |

### server_platf.bug criteria

| Rule | Field | Operator | Value |
|------|-------|----------|-------|
| R7 | bug.forum | IN | 'SysDebug.board' |
| R8 | tag | CONTAINS | 'PTP_SoC' |
| R9 | family | IN | 'Oak Stream DMR Platforms' |

## Logic

- **Forum filter (R1 OR R4 OR R6 OR R7):** CPU analog/logic sightings, testchip analog/logic sightings, mfg SRSS sightings, OR server_platf SysDebug board bugs
- **Tag filter (R2 OR R8):** Must have 'PTP_SoC' tag (applies per tenant)
- **Family filter (R3 OR R5 OR R9):** Diamond Rapids variants (sighting_central) OR Leucadia die (sighting_central) OR Oak Stream DMR (server_platf)
