# Firmware IRF Query (ID: 15018339809)

**Title:** OKS+BHS BIOS ASIA IRF
**Owner:** weitsung
**Last Updated:** 2026-03-05

**Scope:** BHS/OKS platforms, firmware components, APAC region, P1/P2 priority

## Get Latest EQL from HSDes

To retrieve the latest query metadata (including EQL) directly from HSDes:
```powershell
Invoke-RestMethod -Uri "https://hsdes-api.intel.com/rest/query/MetaData?id=15018339809" `
    -Method Get -UseDefaultCredentials -Headers @{"Accept"="application/json"} -NoProxy
```

## EQL

```eql
SELECT id, title, bug.exposure, priority, owner, server_platf_ae.bug.co_owners, component, status, reason,
       submitted_date, updated_date, release, server_platf_ae.bug.customer_company,
       server_platf_ae.bug.current_owner_org, server_platf_ae.bug.irf_notes,
       server_platf_ae.bug.irf_hotlist_approved, server_platf_ae.bug.irf_disposition_date, tag
WHERE tenant = 'server_platf_ae'
AND subject = 'bug'
AND ( ( ( ( family IN ('Birch Stream Platform', 'Oak Stream DMR Platforms')
            AND component IN ('platform.bios', 'platform.fsp', 'platform.txt/sec_fw', 'platform.bmc',
                             'platform.ras', 'platform.sps_fw', 'platform.sgx', 'platform.tdx',
                             'platform.manageability', 'platform.pmt')
            AND release IN ('granite_rapids', 'Birch Stream Platform GNR AP', 'Birch Stream Platform GNR SP',
                           'Birch Stream Platform SRF AP', 'Birch Stream Platform SRF SP',
                           'Birch Stream Platform CWF AP', 'Birch Stream Platform CWF SP',
                           'Oak Stream Platform 1 DMR', 'Oak Stream Platform 2 DMR',
                           'Oak Stream Platform 3 DMR', 'Oak Stream Platform DMR HD')
            AND server_platf_ae.bug.article_type = 'debug_request'
            AND status = 'open'
            AND server_platf_ae.bug.customer_project_name DOES_NOT_CONTAIN 'DTI'
            AND tag DOES_NOT_CONTAIN 'NTA'
            AND server_platf_ae.bug.customer_company != 'inspur'
            AND server_platf_ae.bug.owner_geo CONTAINS 'APAC'
            AND server_platf_ae.bug.odm NOT IN ('inspur')
            AND ( priority IN ('p1-showstopper', 'p2-high') OR bug.exposure IN ('1-critical', '2-high') ) )
          OR ( server_platf_ae.bug.customer_project_name CONTAINS 'DTI' AND tag CONTAINS 'FW_IRF' ) )
        AND server_platf_ae.bug.irf_disposition_date IS_EMPTY
        AND ( title DOES_NOT_CONTAIN '[DTI]' AND title DOES_NOT_CONTAIN '[CoVal]' ) )
      OR ( component IN ('platform.bios', 'platform.fsp', 'platform.txt/sec_fw', 'platform.bmc',
                        'platform.ras', 'platform.sps_fw', 'platform.sgx', 'platform.tdx',
                        'platform.manageability', 'platform.pmt')
           AND server_platf_ae.bug.article_type = 'debug_request'
           AND status = 'open'
           AND server_platf_ae.bug.irf_disposition_date IS_EMPTY
           AND priority NOT IN ('p4-low')
           AND bug.exposure NOT IN ('4-low')
           AND ( title CONTAINS '[DMR Co-Val]' OR title CONTAINS '[DMR Co-PO]' ) ) )
SORTBY release ASC, submitted_date ASC
```

## Output Format

Format results as a markdown table grouped by **priority** (p1-showstopper first, then p2-high, etc.):

| priority | id | title | status_reason | release | owner | component | customer_company | irf_notes |
|----------|----|-------|---------------|---------|-------|-----------|------------------|-----------|

- `irf_notes` → `server_platf_ae.bug.irf_notes` (paste raw content as-is, preserve bullet points)
- `status_reason` → `{status}.{reason}` combined (e.g., `open.awaiting_customer`)
- `id` → hyperlink: `[{id}](https://hsdes.intel.com/appstore/article-one/#/article/{id})`
- `owner` → show the full enriched value as-is (format: `idsid (Full Name)`) — do NOT truncate to IDSID only
- Group rows under bold priority headers; omit empty priority groups

## Logic

- **Platforms:** Oak Stream (DMR) and Birch Stream (GNR/SRF/CWF)
- **Components:** BIOS, FSP, Security FW, BMC, RAS, SPS FW, SGX, TDX, Manageability, PMT
- **Focus:** Open debug requests for APAC region
- **Priority:** P1/P2 or Critical/High exposure
- **Excludes:** Inspur (customer_company and ODM), DTI/NTA tags, [DTI]/[CoVal] in title
- **Special:** Includes DTI with FW_IRF tag OR DMR Co-Val/Co-PO (priority != P4, exposure != 4-low)
