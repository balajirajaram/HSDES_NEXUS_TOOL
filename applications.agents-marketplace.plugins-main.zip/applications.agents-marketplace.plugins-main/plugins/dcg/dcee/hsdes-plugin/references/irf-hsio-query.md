# HSIO IRF Query (ID: 15017467796)

**Title:** CSE_HSIO Customer Issues_Agenda
**Owner:** cho7
**Last Updated:** 2026-03-11

**Scope:** BHS/OKS platforms, HSIO components (PCIe/CXL), APAC region

## Get Latest EQL from HSDes

To retrieve the latest query metadata (including EQL) directly from HSDes:
```powershell
Invoke-RestMethod -Uri "https://hsdes-api.intel.com/rest/query/MetaData?id=15017467796" `
    -Method Get -UseDefaultCredentials -Headers @{"Accept"="application/json"} -NoProxy
```

## EQL

```eql
SELECT id, title, bug.exposure, priority, owner, server_platf_ae.bug.co_owners,
       server_platf_ae.bug.ext_source_id, server_platf_ae.bug.customer_company,
       server_platf_ae.bug.odm, server_platf_ae.bug.article_type,
       server_platf_ae.bug.owner_geo, server_platf_ae.bug.current_owner_org,
       status, server_platf_ae.bug.ext_priority, component,
       submitted_date, updated_date, closed_date, bug.closed_reason,
       server_platf_ae.bug.conclusion_type, reason, status_reason, tag,
       server_platf_ae.bug.irf_tag, server_platf_ae.bug.irf_hotlist_approved,
       server_platf_ae.bug.irf_notes, server_platf_ae.bug.prw_ihv_name,
       server_platf_ae.bug.prw_ihv_product, server_platf_ae.bug.irf_disposition_date,
       release
WHERE tenant = 'server_platf_ae'
AND subject = 'bug'
AND family IN ('Birch Stream Platform', 'Oak Stream DMR Platforms')
AND release IN ('Birch Stream Platform GNR SP', 'Birch Stream Platform GNR AP',
               'Birch Stream Platform SRF SP', 'Birch Stream Platform SRF AP',
               'Oak Stream Platform 2 DMR', 'Oak Stream Platform 3 DMR',
               'Oak Stream Platform 1 DMR')
AND server_platf_ae.bug.article_type = 'debug_request'
AND status NOT IN ('implemented', 'complete', 'verified', 'future', 'rejected')
AND component IN ('platform.cpu_pcie', 'platform.ev.pcie', 'platform.cxl', 'platform.cxl_poc')
AND server_platf_ae.bug.irf_tag DOES_NOT_CONTAIN '/hsio_skip'
AND server_platf_ae.bug.owner_geo CONTAINS 'P'
AND server_platf_ae.bug.irf_disposition_date IS_EMPTY
AND ( priority IN ('p1-showstopper', 'p2-high', '1-showstopper', '2-high')
      OR bug.exposure IN ('1-critical', '2-high')
      OR ( title CONTAINS '[DMR Co-Val' AND priority NOT IN ('4-low', 'p4-low') )
      OR title CONTAINS '[DMR Co-PO' )
SORTBY release DESC, server_platf_ae.bug.owner_geo ASC, bug.exposure ASC, owner ASC, server_platf_ae.bug.conclusion_type ASC
```

## Output Format

Format results as a markdown table grouped by **priority** (p1-showstopper first, then p2-high, etc.):

| priority | id | title | status_reason | release | owner | component | customer_company | irf_notes |
|----------|----|-------|---------------|---------|-------|-----------|------------------|-----------|

- `irf_notes` → `server_platf_ae.bug.irf_notes` (paste raw content as-is, preserve bullet points)
- `status_reason` → `{status}.{reason}` combined (e.g., `open.awaiting_customer`)
- `id` → hyperlink: `[{id}](https://hsdes.intel.com/appstore/article-one/#/article/{id})`
- `owner` → show the full enriched value as-is (format: `idsid (Full Name)`) — do NOT truncate to IDSID only
- Group rows under bold priority headers; omit empty priority groups

## Logic

- **Platforms:** Oak Stream (DMR) and Birch Stream (GNR/SRF)
- **Components:** CPU PCIe, EV PCIe, CXL, CXL PoC
- **Focus:** Open debug requests for APAC region (owner_geo contains 'P')
- **Status:** Excludes implemented, complete, verified, future, rejected
- **Priority:** P1/P2 or Critical/High exposure, or DMR Co-Val (non-low priority), or DMR Co-PO
- **Excludes:** Items tagged with `/hsio_skip`, disposed items (irf_disposition_date set)
