# Memory IRF Query (ID: 15015935984)

**Title:** [IRF] Xeon SP Memory Issues - APAC Customer
**Owner:** ilinx
**Last Updated:** 2026-03-10

**Scope:** BHS/OKS platforms, memory components, APAC region (excludes EMEA/US/LAT)

## Get Latest EQL from HSDes

To retrieve the latest query metadata (including EQL) directly from HSDes:
```powershell
Invoke-RestMethod -Uri "https://hsdes-api.intel.com/rest/query/MetaData?id=15015935984" `
    -Method Get -UseDefaultCredentials -Headers @{"Accept"="application/json"} -NoProxy
```

## EQL

```eql
SELECT id, title, owner, server_platf_ae.bug.co_owners, tag, bug.exposure,
       priority, server_platf_ae.bug.ext_priority,
       server_platf_ae.bug.customer_company, bug.platform, release,
       server_platf_ae.bug.article_type, server_platf_ae.bug.irf_notes,
       server_platf_ae.bug.irf_hotlist_approved,
       server_platf_ae.bug.current_owner_org, server_platf_ae.bug.irf,
       server_platf_ae.bug.irf_tag, server_platf_ae.bug.int_sighting_url,
       server_platf_ae.bug.irf_disposition_date, component, status,
       server_platf_ae.bug.owner_geo, reason, submitted_date
WHERE tenant = 'server_platf_ae'
AND subject = 'bug'
AND status NOT IN ('rejected', 'verified', 'complete')
AND ( bug.platform IN ('Birch Stream Platform', 'Birch Stream Platform CWF AP',
                       'Birch Stream Platform CWF SP',
                       'Oak Stream Diamond Rapids HD (DMR-HD)',
                       'Oak Stream DMR Platforms', 'Oak Stream Platform 1 DMR',
                       'Oak Stream Platform 2 DMR', 'Oak Stream DMR 16Ch R/M')
      OR release IN ('Birch Stream Platform GNR SP', 'Birch Stream Platform GNR AP',
                     'Birch Stream Platform SRF SP', 'Birch Stream Platform CWF SP',
                     'Birch Stream Platform SRF AP', 'Birch Stream Platform CWF AP',
                     'Oak Stream Platform 1 DMR', 'Oak Stream COR SP',
                     'Oak Stream COR AP', 'Oak Stream Platform 2 DMR',
                     'Oak Stream Platform 3 DMR', 'Oak Stream Platform DMR HD',
                     'Oak Stream Platform RRF SP') )
AND server_platf_ae.bug.owner_geo DOES_NOT_CONTAIN 'EMEA'
AND tag DOES_NOT_CONTAIN 'misc.si'
AND server_platf_ae.bug.irf NOT IN ('networking', 'storage', 'sps_fw', 'comms', 'me_fw',
                                    'fpga', 'pch', 'tools', 'power_thermal_mechanical',
                                    'nvdimm_us', 'unassigned')
AND server_platf_ae.bug.owner_geo DOES_NOT_CONTAIN 'US'
AND component IN ('platform.cpu_memory', 'platform.ev', 'platform.si/ev',
                  'tool.ddr_rank_margining', 'platform.ev.ddr', 'platform.ras',
                  'tool.margining/RMT', 'platform.ev_margin', 'platform.bios',
                  'platform.memory', 'platform.soc_memory', 'platform.test_event',
                  'platform.mem_buffer', 'tool.intel_mem_assistant')
AND server_platf_ae.bug.owner_geo DOES_NOT_CONTAIN 'LAT'
AND ( tag CONTAINS 'MEV' OR tag CONTAINS 'imf' )
AND tag DOES_NOT_CONTAIN 'TWS'
AND server_platf_ae.bug.article_type NOT IN ('feature_request', 'test_event', 'question', 'design_services')
AND server_platf_ae.bug.irf_disposition_date IS_EMPTY
SORTBY release ASC, server_platf_ae.bug.article_type ASC, bug.exposure ASC, server_platf_ae.bug.customer_company ASC
```

## Output Format

Format results as a markdown table grouped by **priority** (p1-showstopper first, then p2-high, etc.):

| priority | id | title | status_reason | release | owner | component | customer_company | irf_notes |
|----------|----|-------|---------------|---------|-------|-----------|------------------|-----------|

- `irf_notes` → `server_platf_ae.bug.irf_notes` (paste raw content as-is, preserve bullet points)
- `status_reason` → `{status}.{reason}` combined (e.g., `open.awaiting_customer`)
- `id` → hyperlink: `[{id}](https://hsdes.intel.com/appstore/article-one/#/article/{id})`
- `owner` → show the full enriched value as-is (format: `idsid (Full Name)`) — do NOT truncate to IDSID only
- Group rows under bold priority headers; omit empty priority groups

## Logic

- **Platforms:** Birch Stream (GNR/SRF/CWF) and Oak Stream (DMR/COR/RRF) via platform or release
- **Components:** CPU Memory, EV, SI/EV, DDR Rank Margining, EV DDR, RAS, Margining/RMT, EV Margin, BIOS, Memory, SoC Memory, Test Event, Mem Buffer, Intel Mem Assistant
- **Focus:** APAC region only (excludes EMEA, US, LAT geo)
- **Status:** Excludes rejected, verified, complete
- **Tags:** Must contain 'MEV' or 'imf'; excludes 'misc.si' and 'TWS'
- **IRF Category:** Excludes networking, storage, SPS FW, comms, ME FW, FPGA, PCH, tools, power/thermal/mechanical, NVDIMM US, unassigned
- **Article Type:** Excludes feature_request, test_event, question, design_services
- **Excludes:** Disposed items (irf_disposition_date set)
