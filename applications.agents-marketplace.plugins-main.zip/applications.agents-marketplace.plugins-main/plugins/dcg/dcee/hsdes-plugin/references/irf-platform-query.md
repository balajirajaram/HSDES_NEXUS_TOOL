# Platform IRF Query (ID: 15013555803)

**Title:** Copy of IRF OKS/ BHS All Geos
**Owner:** llin10
**Last Updated:** 2026-03-05

**Scope:** BHS/OKS platforms, CPU/platform components, P1/P2 priority (OKS includes P1-P3)

## Get Latest EQL from HSDes

To retrieve the latest query metadata (including EQL) directly from HSDes:
```powershell
Invoke-RestMethod -Uri "https://hsdes-api.intel.com/rest/query/MetaData?id=15013555803" `
    -Method Get -UseDefaultCredentials -Headers @{"Accept"="application/json"} -NoProxy
```

## EQL

```eql
SELECT id, title, owner, bug.exposure, priority, server_platf_ae.bug.customer_company, release,
       component, status, reason, server_platf_ae.bug.irf_notes, server_platf_ae.bug.irf,
       server_platf_ae.bug.owner_geo, submitted_date
WHERE tenant = 'server_platf_ae'
AND subject = 'bug'
AND id > 0
AND server_platf_ae.bug.owner_geo IS_NOT_EMPTY
AND owner != 'sys_pool'
AND server_platf_ae.bug.customer_company NOT IN ('intel', 'inspur')
AND status NOT IN ('rejected', 'verified', 'complete')
AND server_platf_ae.bug.article_type = 'debug_request'
AND family IN ('Birch Stream Platform', 'Oak Stream DMR Platforms')
AND release IN ('Birch Stream Platform GNR AP', 'Birch Stream Platform GNR SP',
               'Birch Stream Platform SRF SP', 'Birch Stream Platform SRF AP',
               'Oak Stream Platform 1 DMR', 'Oak Stream Platform 2 DMR', 'Oak Stream Platform 3 DMR',
               'Birch Stream Platform CWF SP', 'Birch Stream Platform CWF AP')
AND server_platf_ae.bug.irf_disposition_date IS_EMPTY
AND ( priority IN ('p1-showstopper', 'p2-high')
      OR ( family IN ('Oak Stream DMR Platforms')
           AND priority IN ('p1-showstopper', 'p2-high', 'p3-medium') ) )
AND submitted_date < 'now-6d'
AND ( component IN ('platform.cpu_core', 'platform.cpu_memory', 'platform.cpu_other',
                   'platform.cpu_qpi', 'platform.cpu_uncore', 'platform.cpu_upi',
                   'platform.ras', 'platform.ev', 'platform.cpu_dpm', 'platform.cpu_fuse',
                   'platform.cpu_mca_triage', 'platform.cpu_peci', 'platform.cpu_perf',
                   'platform.cpu_pwrmgmt', 'platform.cpu_sde', 'platform.ev.ddr',
                   'platform.ev.upi', 'platform.cpu_s3m', 'platform.cpu_pcie',
                   'platform.ev.pcie', 'platform.cxl', 'platform.clocking',
                   'platform.reset', 'platform.manageability')
      OR ( component IN ('platform.bios', 'platform.txt/sec_fw', 'platform.bmc',
                        'platform.manageability')
           AND server_platf_ae.bug.owner_geo CONTAINS 'P' ) )
SORTBY priority ASC, release ASC, server_platf_ae.bug.customer_company ASC
```

## Output Format

Format results as a markdown table grouped by **priority** (p1-showstopper first, then p2-high, etc.):

| priority | id | title | status_reason | release | owner | irf_notes |
|----------|----|-------|---------------|---------|-------|-----------|

- `irf_notes` → `server_platf_ae.bug.irf_notes` (paste raw content as-is, preserve bullet points)
- `status_reason` → `{status}.{reason}` combined (e.g., `open.awaiting_customer`)
- `id` → hyperlink: `[{id}](https://hsdes.intel.com/appstore/article-one/#/article/{id})`
- `owner` → show the full enriched value as-is (format: `idsid (Full Name)`) — do NOT truncate to IDSID only
- Group rows under bold priority headers; omit empty priority groups

## Logic

- **Platforms:** Birch Stream (GNR/SRF/CWF), Oak Stream (DMR)
- **Components:** CPU cores, memory, uncore, UPI, RAS, EV, DPM, CXL, clocking, reset, manageability, etc.
- **Special:** BIOS/BMC only if owner_geo contains 'P' (APAC)
- **Priority:** BHS: P1/P2 only; OKS (DMR): P1-P3 (excludes P4)
- **Status:** Active (not rejected/verified/complete)
- **Excludes:** Intel/Inspur, sys_pool owner
- **Time filter:** submitted_date older than 6 days
