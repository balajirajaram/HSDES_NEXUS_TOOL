<# HSDes Environment Check Script
.SYNOPSIS
    Verify environment prerequisites for HSDes plugin
.NOTES
    Requires PowerShell 7+ (pwsh)
#>
#Requires -Version 7

. "$PSScriptRoot/hsdes_auth.ps1"

Write-Host "HSDes Environment Check" -ForegroundColor Cyan
Write-Host "========================"

# PowerShell version
$ver = $PSVersionTable.PSVersion
if ($ver.Major -ge 7) {
    Write-Host "  PASS  PowerShell $ver" -ForegroundColor Green
} else {
    Write-Host "  FAIL  PowerShell $ver < 7.0" -ForegroundColor Red
}

# Python
$python = Get-Command python -ErrorAction SilentlyContinue
if ($python) {
    $pyVer = python --version 2>&1
    Write-Host "  PASS  $pyVer" -ForegroundColor Green
} else {
    Write-Host "  FAIL  Python not found" -ForegroundColor Red
}

# fastmcp
try {
    $fastmcpVer = python -c "import fastmcp; print(getattr(fastmcp, '__version__', 'installed'))" 2>$null
    if ($LASTEXITCODE -eq 0 -and $fastmcpVer) {
        Write-Host "  PASS  fastmcp $fastmcpVer" -ForegroundColor Green
    } else {
        Write-Host "  FAIL  fastmcp not installed" -ForegroundColor Red
    }
} catch {
    Write-Host "  FAIL  fastmcp not installed" -ForegroundColor Red
}

# Auth mode
try {
    $authMode = Get-HsdesAuthMode
    if ($authMode -eq "token") {
        Write-Host "  PASS  auth mode: token (/rest/auth + basic auth)" -ForegroundColor Green
    } else {
        Write-Host "  PASS  auth mode: default credentials (/rest + UseDefaultCredentials)" -ForegroundColor Green
    }
} catch {
    Write-Host "  FAIL  auth mode configuration: $($_.Exception.Message)" -ForegroundColor Red
    $authMode = "invalid"
}

# Network connectivity
try {
    if ($authMode -eq "token") {
        $idsid = Get-HsdesEffectiveIdsid
        $params = New-HsdesRequestParams -Path "user/$idsid" -Method Get -TimeoutSec 20
        $response = Invoke-RestMethod @params -ErrorAction Stop
        Write-Host "  PASS  HSDes API reachable (token mode)" -ForegroundColor Green
    } elseif ($authMode -eq "default-credentials") {
        $params = New-HsdesRequestParams -Path "health" -Method Get -TimeoutSec 10
        $response = Invoke-RestMethod @params -ErrorAction Stop
        Write-Host "  PASS  HSDes API reachable" -ForegroundColor Green
    }
} catch {
    if ($authMode -eq "default-credentials" -and $_.Exception.Message -match "401|403") {
        Write-Host "  PASS  HSDes API reachable (auth required)" -ForegroundColor Green
    } elseif ($authMode -eq "token" -and $_.Exception.Message -match "401|403") {
        Write-Host "  FAIL  Token authentication failed. Verify HSDES_USERNAME/HSDES_TOKEN." -ForegroundColor Red
    } else {
        Write-Host "  FAIL  HSDes API unreachable: $($_.Exception.Message)" -ForegroundColor Red
    }
}
