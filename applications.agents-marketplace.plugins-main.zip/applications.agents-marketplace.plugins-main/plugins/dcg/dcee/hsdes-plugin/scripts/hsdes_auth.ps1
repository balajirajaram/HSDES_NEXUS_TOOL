<# HSDes Shared Authentication Helpers
.SYNOPSIS
    Builds Invoke-RestMethod/Invoke-WebRequest parameters for dual-mode auth.
.DESCRIPTION
    - Default mode (Windows-compatible): /rest/... + UseDefaultCredentials
    - Token mode (cross-platform): /rest/auth/... + Authorization: Basic base64(username:token)

    Token mode is enabled only when BOTH env vars are set:
      HSDES_USERNAME
      HSDES_TOKEN
#>
#Requires -Version 7

$script:HsdDotEnvLoaded = $false
$script:HsdDotEnv = @{}

function Initialize-HsdesDotEnv {
    if ($script:HsdDotEnvLoaded) {
        return
    }
    $script:HsdDotEnvLoaded = $true

    $candidates = @(
        (Join-Path (Join-Path $PSScriptRoot "..") ".env"),
        (Join-Path (Join-Path (Join-Path $PSScriptRoot "..") "..") ".env"),
        (Join-Path (Get-Location).Path ".env")
    )

    $seen = @{}
    foreach ($candidate in $candidates) {
        try {
            $resolved = [System.IO.Path]::GetFullPath($candidate)
        } catch {
            continue
        }
        if ($seen.ContainsKey($resolved)) {
            continue
        }
        $seen[$resolved] = $true
        if (-not (Test-Path -LiteralPath $resolved -PathType Leaf)) {
            continue
        }

        foreach ($rawLine in (Get-Content -LiteralPath $resolved -ErrorAction SilentlyContinue)) {
            if ([string]::IsNullOrWhiteSpace($rawLine)) {
                continue
            }
            $line = $rawLine.Trim()
            if ($line.StartsWith("#")) {
                continue
            }

            if ($line -match '^(?:export\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*)$') {
                $key = $matches[1]
                $value = $matches[2].Trim()

                if (($value.StartsWith('"') -and $value.EndsWith('"')) -or ($value.StartsWith("'") -and $value.EndsWith("'"))) {
                    $value = $value.Substring(1, $value.Length - 2)
                } elseif ($value -match '^(.*?)\s+#') {
                    $value = $matches[1].TrimEnd()
                }

                if (-not $script:HsdDotEnv.ContainsKey($key)) {
                    $script:HsdDotEnv[$key] = $value
                }
            }
        }
    }
}

function Get-HsdesSettingValue {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Name
    )

    $envValue = [Environment]::GetEnvironmentVariable($Name)
    if (-not [string]::IsNullOrWhiteSpace($envValue)) {
        return $envValue
    }

    Initialize-HsdesDotEnv
    if ($script:HsdDotEnv.ContainsKey($Name)) {
        return $script:HsdDotEnv[$Name]
    }
    return $null
}

function Get-HsdesTokenAuthInfo {
    $username = Get-HsdesSettingValue -Name "HSDES_USERNAME"
    $token = Get-HsdesSettingValue -Name "HSDES_TOKEN"

    $hasUsername = -not [string]::IsNullOrWhiteSpace($username)
    $hasToken = -not [string]::IsNullOrWhiteSpace($token)

    if ($hasUsername -xor $hasToken) {
        throw "HSDES token auth requires both HSDES_USERNAME and HSDES_TOKEN to be set."
    }

    if (-not $hasUsername) {
        return $null
    }

    return @{
        username = $username.Trim()
        token = $token.Trim()
    }
}

function Get-HsdesAuthMode {
    if (Get-HsdesTokenAuthInfo) {
        return "token"
    }
    return "default-credentials"
}

function Get-HsdesEffectiveIdsid {
    $tokenAuth = Get-HsdesTokenAuthInfo
    if ($tokenAuth) {
        return $tokenAuth.username
    }
    return $env:USERNAME
}

function New-HsdesRequestParams {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Path,
        [ValidateSet('Get', 'Post', 'Put', 'Delete', 'Patch', 'Head', 'Options')]
        [string]$Method = 'Get',
        [hashtable]$Headers = @{},
        [string]$ContentType,
        [string]$Body,
        [int]$TimeoutSec
    )

    $tokenAuth = Get-HsdesTokenAuthInfo
    $baseUri = if ($tokenAuth) {
        "https://hsdes-api.intel.com/rest/auth"
    } else {
        "https://hsdes-api.intel.com/rest"
    }

    $relativePath = $Path.TrimStart('/')
    $params = @{
        Uri = "$baseUri/$relativePath"
        Method = $Method
    }

    $mergedHeaders = @{}
    if ($Headers) {
        foreach ($name in $Headers.Keys) {
            $mergedHeaders[$name] = $Headers[$name]
        }
    }

    if ($tokenAuth) {
        $pair = "{0}:{1}" -f $tokenAuth.username, $tokenAuth.token
        $encoded = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes($pair))
        $mergedHeaders["Authorization"] = "Basic $encoded"
    } else {
        $params["UseDefaultCredentials"] = $true
    }

    if ($mergedHeaders.Count -gt 0) {
        $params["Headers"] = $mergedHeaders
    }

    if ($PSBoundParameters.ContainsKey("ContentType") -and -not [string]::IsNullOrWhiteSpace($ContentType)) {
        $params["ContentType"] = $ContentType
    }

    if ($PSBoundParameters.ContainsKey("Body")) {
        $params["Body"] = $Body
    }

    if ($PSBoundParameters.ContainsKey("TimeoutSec") -and $TimeoutSec -gt 0) {
        $params["TimeoutSec"] = $TimeoutSec
    } else {
        $params["TimeoutSec"] = 30
    }

    if ($PSVersionTable.PSVersion.Major -ge 7) {
        $params["NoProxy"] = $true
    }

    return $params
}
