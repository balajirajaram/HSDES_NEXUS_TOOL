<# HSDes Current User
.SYNOPSIS
    Get current user's HSDes profile (IDSID, name, email, org)
.NOTES
    Requires PowerShell 7+.
#>
#Requires -Version 7

. "$PSScriptRoot/hsdes_auth.ps1"

$Idsid = Get-HsdesEffectiveIdsid
$requestPath = "user/$Idsid"
$params = New-HsdesRequestParams -Path $requestPath -Method 'Get' -ContentType 'application/json'

try {
    $response = Invoke-RestMethod @params

    if ($response.data -and $response.data.Count -gt 0) {
        $user = $response.data[0]
        $result = @{
            idsid  = $Idsid
            name   = $user.'sys_user.name'
            email  = $user.'sys_user.email'
            org    = $user.'sys_user.orgunit_description'
            group  = $user.'sys_user.group'
            site   = $user.'sys_user.site'
        }
        return $result | ConvertTo-Json -Compress
    }
    else {
        Write-Error "User not found: $Idsid"
        throw
    }
}
catch {
    Write-Error "Failed to get current user: $_"
    throw
}
