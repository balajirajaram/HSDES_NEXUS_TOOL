<# HSDes Download Binary Script
.SYNOPSIS
    Download a binary attachment from HSDes by its binary ID
.PARAMETER BinaryId
    The HSDes binary attachment ID (numeric)
.PARAMETER OutputPath
    Full file path to save the downloaded binary
.EXAMPLE
    .\hsdes_download_binary.ps1 -BinaryId 12345678 -OutputPath "C:\temp\attachment.pdf"
#>
#Requires -Version 7
param(
    [Parameter(Mandatory=$true)]
    [string]$BinaryId,

    [Parameter(Mandatory=$true)]
    [string]$OutputPath
)

if ($BinaryId -notmatch '^\d+$') { throw "Invalid BinaryId: Must be numeric." }
. "$PSScriptRoot/hsdes_auth.ps1"

$requestPath = "binary/$BinaryId"
$params = New-HsdesRequestParams -Path $requestPath -Method 'Get'
$params['OutFile'] = $OutputPath
$params['PassThru'] = $true

try {
    $response = Invoke-WebRequest @params

    # Extract content type (may be array)
    $contentType = $response.Headers['Content-Type']
    if ($contentType -is [array]) { $contentType = $contentType[0] }

    # Get file size
    $fileSize = (Get-Item $OutputPath).Length

    # Output JSON metadata
    $meta = @{
        binary_id    = $BinaryId
        local_path   = $OutputPath
        content_type = $contentType
        size         = $fileSize
    }
    return $meta | ConvertTo-Json -Compress
}
catch {
    Write-Error "Failed to download binary: $_"
    throw
}
