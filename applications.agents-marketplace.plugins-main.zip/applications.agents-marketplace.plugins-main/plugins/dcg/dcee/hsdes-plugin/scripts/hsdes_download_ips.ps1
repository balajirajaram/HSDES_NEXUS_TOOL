<# HSDes Download IPS Attachment
.SYNOPSIS
    Download a file from esft-int.intel.com (Intel ESFT / IPS) using Windows integrated auth.
.PARAMETER Url
    Full ESFT download URL (from hsdes_get_attachments type=ips).
.PARAMETER OutputPath
    Local file path to save to. Defaults to <cwd>/downloads/<article_id>/<filename> (article_id
    parsed from the URL's AppData query param). Falls back to <cwd>/downloads/<filename> if AppData
    is missing or non-numeric.
.EXAMPLE
    .\hsdes_download_ips.ps1 -Url "https://esft-int.intel.com/sftservices/download/HSDES_SFT/?FileName=foo.pdf&AppFileID=...&AppData=..."
#>
#Requires -Version 7
param(
    [Parameter(Mandatory=$true)]
    [string]$Url,
    [string]$OutputPath = ""
)

if ($Url -notmatch '^https://esft-int\.intel\.com/') {
    throw "URL must be an esft-int.intel.com ESFT link."
}

# Parse filename from URL query string
$filename = "ips_download"
if ($Url -match '[?&]FileName=([^&]+)') {
    $filename = [Uri]::UnescapeDataString($matches[1])
    # Strip path components — URL FileName= ultimately comes from HSDes data,
    # treat it as untrusted to prevent ..\..\ traversal out of the downloads dir.
    $filename = [System.IO.Path]::GetFileName($filename)
    if (-not $filename -or $filename -eq '.' -or $filename -eq '..') {
        $filename = "ips_download"
    }
}

if (-not $OutputPath) {
    $articleId = $null
    if ($Url -match '[?&]AppData=([^&]+)') {
        $articleId = [Uri]::UnescapeDataString($matches[1])
    }
    try {
        $baseDir = Join-Path (Get-Location).Path "downloads"
        if ($articleId -and $articleId -match '^\d+$') {
            $baseDir = Join-Path $baseDir $articleId
        }
        if (-not (Test-Path -LiteralPath $baseDir)) {
            New-Item -ItemType Directory -Path $baseDir -Force -ErrorAction Stop | Out-Null
        }
    }
    catch {
        # cwd not writable (read-only mount, service path, etc) — fall back to temp.
        $baseDir = [System.IO.Path]::GetTempPath()
    }
    $OutputPath = Join-Path $baseDir $filename
}

Write-Host "Downloading IPS attachment: $filename" -ForegroundColor Cyan
Write-Host "  URL: $Url" -ForegroundColor Gray
Write-Host "  Output: $OutputPath" -ForegroundColor Gray

try {
    Invoke-WebRequest `
        -Uri $Url `
        -OutFile $OutputPath `
        -UseDefaultCredentials `
        -NoProxy `
        -TimeoutSec 30 `
        -ErrorAction Stop

    $size = (Get-Item $OutputPath).Length
    Write-Host "  Downloaded: $size bytes" -ForegroundColor Green

    $result = @{
        success     = $true
        filename    = $filename
        output_path = $OutputPath
        file_size   = $size
        url         = $Url
    }
    return $result | ConvertTo-Json -Depth 3
}
catch {
    $errMsg = $_.ToString()
    Write-Host "  Error: $errMsg" -ForegroundColor Red
    $result = @{
        success  = $false
        filename = $filename
        url      = $Url
        error    = $errMsg
    }
    return $result | ConvertTo-Json -Depth 3
}
