<# HSDes Get Article Script
.SYNOPSIS
    Get an HSDes article by its ID (no tenant/subject needed)
.PARAMETER ArticleId
    The HSDes article ID
.PARAMETER Fields
    Optional comma-separated field selection passed as ?fields=... to the API
.PARAMETER Format
    'text' (default) or 'html'. When 'text', HTML body fields (description,
    ext_cust_blog_hist) are converted to plain text before serialization.
    Sidesteps HSDes's malformed-HTML serialization that breaks Python
    json.loads downstream.
.EXAMPLE
    .\hsdes_get_article.ps1 -ArticleId 22021660584
.EXAMPLE
    .\hsdes_get_article.ps1 -ArticleId 22021660584 -Format html
#>
#Requires -Version 7
param(
    [Parameter(Mandatory=$true)]
    [string]$ArticleId,

    [Parameter(Mandatory=$false)]
    [string]$Fields = "",

    [Parameter(Mandatory=$false)]
    [ValidateSet('text', 'html')]
    [string]$Format = 'text'
)

if ($ArticleId -notmatch '^\d+$') { throw "Invalid ArticleId: Must be numeric." }

# Force UTF-8 stdout — see hsdes_saved_query.ps1 for full rationale.
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

. "$PSScriptRoot/hsdes_auth.ps1"
. "$PSScriptRoot/hsdes_text_helpers.ps1"

$requestPath = "article/$ArticleId"
if ($Fields) { $requestPath += "?fields=$Fields" }
$params = New-HsdesRequestParams -Path $requestPath -Method 'Get' -Headers @{ "Accept" = "application/json" }

try {
    $response = Invoke-RestMethod @params

    # Display key info
    Write-Host "`nArticle: $ArticleId" -ForegroundColor Cyan
    if ($response.data) {
        $data = $response.data[0]
        Write-Host "  Tenant: $($data.tenant)" -ForegroundColor Yellow
        Write-Host "  Subject: $($data.subject)" -ForegroundColor Yellow
        Write-Host "  Title: $($data.title)"
        Write-Host "  Status: $($data.status)"
        Write-Host "  Owner: $($data.owner)"
        Write-Host "  Priority: $($data.priority)"
        Write-Host ""

        # HTML → text on body fields when Format=text. Critical: ext_cust_blog_hist
        # contains malformed HTML (unescaped quotes, raw control chars) that breaks
        # downstream Python json.loads if kept as-is.
        if ($Format -eq 'text') {
            $bodyFields = @('description', 'server_platf_ae.bug.ext_cust_blog_hist')
            foreach ($field in $bodyFields) {
                $prop = $data.PSObject.Properties[$field]
                if ($prop -and $prop.Value) {
                    $data.$field = Convert-HsdesHtmlToText -Html ([string]$prop.Value)
                }
            }
        }
    }

    $jsonOutput = $response | ConvertTo-Json -Depth 10
    if ($Format -eq 'text') {
        # Belt-and-suspenders: strip any raw control chars that survived (see
        # hsdes_saved_query.ps1 for full rationale).
        $jsonOutput = [regex]::Replace($jsonOutput, '[\x00-\x08\x0B\x0C\x0E-\x1F]', '')
    }
    return $jsonOutput
}
catch {
    Write-Error "Failed to get article: $_"
    throw
}
