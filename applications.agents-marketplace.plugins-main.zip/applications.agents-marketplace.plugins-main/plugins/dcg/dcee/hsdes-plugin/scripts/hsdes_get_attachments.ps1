<# HSDes Get Attachments Script
.SYNOPSIS
    List binary attachments for an HSDes article with metadata
.DESCRIPTION
    Step 1: GET /rest/article/{id}/children?child_subject=attachment&fields=id,title
    Step 2: For each child, GET /rest/binary/{id}/info to get filename, fileType, fileSize
.PARAMETER ArticleId
    The HSDes article ID (numeric)
.EXAMPLE
    .\hsdes_get_attachments.ps1 -ArticleId 22021660584
#>
#Requires -Version 7
param(
    [Parameter(Mandatory=$true)]
    [string]$ArticleId
)

if ($ArticleId -notmatch '^\d+$') { throw "Invalid ArticleId: Must be numeric." }
. "$PSScriptRoot/hsdes_auth.ps1"

# Step 1: Get attachment children
$childrenPath = "article/$ArticleId/children?child_subject=attachment&fields=id,title"
Write-Host "Fetching attachments for article $ArticleId..." -ForegroundColor Cyan

try {
    $childrenParams = New-HsdesRequestParams -Path $childrenPath -Method 'Get' -Headers @{ "Accept" = "application/json" }
    $childrenResponse = Invoke-RestMethod @childrenParams
}
catch {
    Write-Error "Failed to get attachment children: $_"
    throw
}

$children = $childrenResponse.data
if (-not $children -or $children.Count -eq 0) {
    # Return empty result as JSON
    $result = @{
        article_id = $ArticleId
        attachments = @()
        count = 0
    }
    return $result | ConvertTo-Json -Depth 5
}

Write-Host "Found $($children.Count) attachment(s)" -ForegroundColor Yellow

# Step 2: For each child, get binary info
$attachments = @()
foreach ($child in $children) {
    $childId = $child.id
    $childTitle = $child.title

    $infoPath = "binary/$childId/info"
    try {
        $infoParams = New-HsdesRequestParams -Path $infoPath -Method 'Get' -Headers @{ "Accept" = "application/json" }
        $infoResponse = Invoke-RestMethod @infoParams
        $attachments += @{
            id        = [string]$childId
            title     = [string]$childTitle
            filename  = [string]$infoResponse.filename
            file_type = [string]$infoResponse.fileType
            file_size = $infoResponse.fileSize
        }
        Write-Host "  $childId - $($infoResponse.filename) ($($infoResponse.fileType), $($infoResponse.fileSize) bytes)" -ForegroundColor Green
    }
    catch {
        # If binary info fails, still include the child with partial data
        Write-Host "  $childId - binary info unavailable: $_" -ForegroundColor Red
        $attachments += @{
            id        = [string]$childId
            title     = [string]$childTitle
            filename  = ""
            file_type = ""
            file_size = 0
            error     = "Failed to get binary info: $_"
        }
    }
}

$result = @{
    article_id  = $ArticleId
    attachments = $attachments
    count       = $attachments.Count
}

return $result | ConvertTo-Json -Depth 5
