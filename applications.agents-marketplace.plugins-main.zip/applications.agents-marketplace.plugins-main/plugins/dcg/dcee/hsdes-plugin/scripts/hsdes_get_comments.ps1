<# HSDes Get Comments Script
.SYNOPSIS
    Get comments for an HSDes article by its ID
.PARAMETER ArticleId
    The HSDes article ID
.PARAMETER Format
    'text' (default) or 'html'. When 'text', comment description bodies are
    converted to plain text before serialization. Sidesteps HSDes's malformed-
    HTML serialization that breaks Python json.loads downstream.
.EXAMPLE
    .\hsdes_get_comments.ps1 -ArticleId 22021660584
.EXAMPLE
    .\hsdes_get_comments.ps1 -ArticleId 22021660584 -Format html
#>
#Requires -Version 7
param(
    [Parameter(Mandatory=$true)]
    [string]$ArticleId,

    [Parameter(Mandatory=$false)]
    [ValidateSet('text', 'html')]
    [string]$Format = 'text'
)

if ($ArticleId -notmatch '^\d+$') { throw "Invalid ArticleId: Must be numeric." }

# Force UTF-8 stdout — see hsdes_saved_query.ps1 for full rationale.
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

. "$PSScriptRoot/hsdes_auth.ps1"
. "$PSScriptRoot/hsdes_text_helpers.ps1"

$requestPath = "article/$ArticleId/children?child_subject=comment&fields=id,owner,description,submitted_date"
$params = New-HsdesRequestParams -Path $requestPath -Method 'Get' -Headers @{ "Accept" = "application/json" }

try {
    $response = Invoke-RestMethod @params

    # Display key info
    Write-Host "`nComments for article: $ArticleId" -ForegroundColor Cyan
    if ($response.data) {
        Write-Host "  Count: $($response.data.Count)" -ForegroundColor Yellow
        foreach ($comment in $response.data) {
            Write-Host "  [$($comment.id)] $($comment.owner) - $($comment.submitted_date)" -ForegroundColor Gray
        }
        Write-Host ""

        if ($Format -eq 'text') {
            foreach ($comment in $response.data) {
                if ($comment.description) {
                    $comment.description = Convert-HsdesHtmlToText -Html ([string]$comment.description)
                }
            }
        }
    }

    $jsonOutput = $response | ConvertTo-Json -Depth 10
    if ($Format -eq 'text') {
        # Belt-and-suspenders: strip any raw control chars that survived (see
        # hsdes_saved_query.ps1 for full rationale).
        $jsonOutput = [regex]::Replace($jsonOutput, '[\x00-\x08\x0B\x0C\x0E-\x1F]', '')
    }
    return $jsonOutput
}
catch {
    Write-Error "Failed to get comments: $_"
    throw
}
