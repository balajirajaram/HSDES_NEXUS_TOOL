<# HSDes IPS upload detail — dev/debug helper, NOT exposed via MCP.

.SYNOPSIS
    Fetch ESFT getfileuploaddetail for an AppFileID. Dev-only, not an MCP tool.

.DESCRIPTION
    Hits the SPA's per-file detail endpoint at
    https://esft-int.intel.com/sftservices/getfileuploaddetail/IPS_SFT/?AppFileID=<uuid>
    and prints the parsed FileDetails as JSON. Useful for:

      * Verifying an old AppFileID's status without the upload tool.
      * Investigating why a file is stuck in `pending` (status / sft_path /
        ipType / securityCompliance / idsid).
      * Manual support when a user reports "I uploaded but HSDes shows nothing".

    NOT exposed as an MCP tool intentionally:

      * No `@mcp.tool()` decorator in mcp_server.py.
      * MCP clients (Claude Code / Copilot Chat / CLI) can only see decorated
        tools — they will not be aware this script exists or be tempted to
        call it.
      * AppFileIDs are opaque to end users; the canonical "did it land?"
        check is the `verify` block already returned by
        hsdes_upload_ips_attachment and hsdes_get_attachments. This script
        is for humans debugging the ESFT side.

.PARAMETER AppFileID
    UUID returned as `app_file_id` by hsdes_upload_ips.ps1 / py.

.PARAMETER Host
    ESFT host (default: esft-int.intel.com).

.PARAMETER Raw
    Print full ESFT response (default: summary only).

.EXAMPLE
    .\hsdes_ips_detail.ps1 -AppFileID 412a8b8d-b5f0-4a6a-9bbb-75cdd991ced9

.EXAMPLE
    .\hsdes_ips_detail.ps1 -AppFileID <uuid> -Raw

.NOTES
    Auth: Windows integrated (UseDefaultCredentials). ESFT does not accept
    HSDes tokens — same constraint as the upload script's chunk POST.
#>
#Requires -Version 7
[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)]
    [string]$AppFileID,

    [string]$EsftHost = 'esft-int.intel.com',

    [switch]$Raw,

    [int]$TimeoutSec = 30
)

if ($AppFileID -notmatch '^[0-9a-fA-F\-]{32,40}$') {
    throw "AppFileID does not look like a UUID: $AppFileID"
}

# Primer GET — same NTLM-on-multipart fix as the upload script
$primerUri = "https://$EsftHost/sftipsupload/index.html"
$session = $null
try {
    Invoke-WebRequest `
        -Uri $primerUri `
        -Method Get `
        -UseDefaultCredentials `
        -NoProxy `
        -SessionVariable session `
        -TimeoutSec $TimeoutSec `
        -ErrorAction Stop | Out-Null
} catch {
    Write-Host "  [warn] primer GET failed (continuing): $($_.Exception.Message)" -ForegroundColor Yellow
    $session = New-Object Microsoft.PowerShell.Commands.WebRequestSession
    $session.UseDefaultCredentials = $true
}

$detailUri = "https://$EsftHost/sftservices/getfileuploaddetail/IPS_SFT/?AppFileID=$AppFileID"
try {
    $resp = Invoke-WebRequest `
        -Uri $detailUri `
        -Method Get `
        -UseDefaultCredentials `
        -WebSession $session `
        -NoProxy `
        -TimeoutSec $TimeoutSec `
        -ErrorAction Stop
} catch {
    @{ success = $false; error = $_.Exception.Message } | ConvertTo-Json -Depth 4
    exit 1
}

$outer = ($resp.Content | ConvertFrom-Json).GetFileUploadDetailResult
$inner = $outer.FileDetails | ConvertFrom-Json

if ($Raw) {
    @{ outer = $outer; file_details = $inner } | ConvertTo-Json -Depth 6
} else {
    @{
        status              = $inner.status
        file_name           = $inner.fileName
        case_id             = $inner.caseId
        sft_path            = $inner.sftPath
        size_in_bytes       = $inner.sizeInBytes
        category            = $inner.category
        ip_type             = $inner.ipType
        security_compliance = $inner.securityCompliance
        idsid               = $inner.idsid
        upload_status_date  = $inner.uploadStatusDate
        extended            = $inner.extended
    } | ConvertTo-Json -Depth 5
}
