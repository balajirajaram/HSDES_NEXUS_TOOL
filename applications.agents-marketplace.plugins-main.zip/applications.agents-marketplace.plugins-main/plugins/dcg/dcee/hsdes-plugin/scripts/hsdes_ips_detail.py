"""HSDes IPS upload detail — dev/debug helper, NOT exposed via MCP.

Hits the SPA's per-file detail endpoint at
``https://esft-int.intel.com/sftservices/getfileuploaddetail/IPS_SFT/?AppFileID=<uuid>``
and prints the parsed FileDetails as JSON. Useful for:

* Verifying an old AppFileID's status without the upload tool.
* Investigating why a file is stuck in ``pending`` (status / sft_path /
  ipType / securityCompliance / idsid).
* Manual support when a user reports "I uploaded but HSDes shows nothing".

NOT exposed as an MCP tool intentionally:

* No ``@mcp.tool()`` decorator in ``mcp_server.py``.
* MCP clients (Claude Code / Copilot Chat / CLI) can only see decorated
  tools — they will not be aware this script exists or be tempted to call
  it.
* AppFileIDs are opaque to end users; the canonical "did it land?" check
  is the ``verify`` block already returned by ``hsdes_upload_ips_attachment``
  and ``hsdes_get_attachments``. This script is for humans debugging the
  ESFT side.

Usage::

    python hsdes_ips_detail.py <AppFileID>
    python hsdes_ips_detail.py <AppFileID> --host esft.intel.com
    python hsdes_ips_detail.py <AppFileID> --raw     # full ESFT response

Auth: Windows NTLM via requests_negotiate_sspi (same as the upload script's
ESFT POST). HSDES_USERNAME / HSDES_TOKEN are not used — this endpoint is
ESFT-only and only accepts the Windows session.
"""
from __future__ import annotations

import argparse
import json
import sys

import requests
import urllib3
from requests_negotiate_sspi import HttpNegotiateAuth

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


def get_upload_detail(app_file_id: str, host: str = "esft-int.intel.com",
                      timeout: int = 30) -> dict:
    """Fetch ESFT FileDetails for an AppFileID. Same call upload_chunks() does
    after the chunk POST; exposed here for standalone dev access."""
    s = requests.Session()
    s.auth = HttpNegotiateAuth()
    s.verify = False
    s.proxies = {"http": None, "https": None}
    # Primer GET — same NTLM-on-multipart fix as the upload path
    try:
        s.get(f"https://{host}/sftipsupload/index.html", timeout=timeout)
    except Exception:
        pass
    url = f"https://{host}/sftservices/getfileuploaddetail/IPS_SFT/?AppFileID={app_file_id}"
    r = s.get(url, timeout=timeout)
    r.raise_for_status()
    outer = r.json().get("GetFileUploadDetailResult", {}) or {}
    inner = json.loads(outer.get("FileDetails", "{}") or "{}")
    return {
        "outer": outer,
        "file_details": inner,
        "summary": {
            "status": inner.get("status", ""),
            "file_name": inner.get("fileName", ""),
            "case_id": inner.get("caseId", ""),
            "sft_path": inner.get("sftPath", ""),
            "size_in_bytes": inner.get("sizeInBytes", 0),
            "category": inner.get("category", ""),
            "ip_type": inner.get("ipType", ""),
            "security_compliance": inner.get("securityCompliance", ""),
            "idsid": inner.get("idsid", ""),
            "upload_status_date": inner.get("uploadStatusDate", ""),
            "extended": inner.get("extended", {}),
        },
    }


def main() -> int:
    p = argparse.ArgumentParser(
        prog="hsdes_ips_detail.py",
        description="DEV-ONLY: fetch ESFT getfileuploaddetail for an AppFileID. "
                    "Not exposed as an MCP tool.",
    )
    p.add_argument("app_file_id", help="UUID of the upload (returned as `app_file_id` "
                                       "by hsdes_upload_ips_attachment).")
    p.add_argument("--host", default="esft-int.intel.com",
                   help="ESFT host (default: esft-int.intel.com).")
    p.add_argument("--raw", action="store_true",
                   help="Print the full ESFT response (default: summary only).")
    p.add_argument("--timeout", type=int, default=30, help="HTTP timeout in seconds.")
    args = p.parse_args()

    try:
        d = get_upload_detail(args.app_file_id, host=args.host, timeout=args.timeout)
    except Exception as e:
        print(json.dumps({"success": False, "error": str(e)}, indent=2))
        return 1

    print(json.dumps(d if args.raw else d["summary"], indent=2, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    sys.exit(main())
