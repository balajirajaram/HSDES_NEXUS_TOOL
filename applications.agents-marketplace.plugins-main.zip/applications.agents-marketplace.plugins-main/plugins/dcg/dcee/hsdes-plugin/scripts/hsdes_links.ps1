<# HSDes Article Links Query Script
.SYNOPSIS
    Get related/promoted links for an HSDes article
.PARAMETER ArticleId
    The HSDes article ID
.EXAMPLE
    .\hsdes_links.ps1 -ArticleId 14025092168
#>
#Requires -Version 7
param(
    [Parameter(Mandatory=$true)]
    [string]$ArticleId
)

if ($ArticleId -notmatch '^\d+$') { throw "Invalid ArticleId: Must be numeric." }
. "$PSScriptRoot/hsdes_auth.ps1"

$requestPath = "article/$ArticleId/links"
$params = New-HsdesRequestParams -Path $requestPath -Method 'Get' -Headers @{ "Accept" = "application/json" }

try {
    $response = Invoke-RestMethod @params
    
    Write-Host "`nLinks for Article: $ArticleId`n" -ForegroundColor Cyan
    
    foreach ($link in $response.responses) {
        Write-Host "ID: $($link.id)" -ForegroundColor Yellow
        Write-Host "  Subject: $($link.subject) | Tenant: $($link.tenant)"
        Write-Host "  Relationship: $($link.relationship) | Status: $($link.status)"
        Write-Host "  Title: $($link.title)"
        Write-Host ""
    }
    
    # Find promoted sightings
    $sightings = $response.responses | Where-Object { $_.subject -eq "sighting" }
    if ($sightings) {
        Write-Host "Promoted Sightings Found:" -ForegroundColor Green
        $sightings | ForEach-Object { Write-Host "  $($_.id) - $($_.title)" }
    }
    
    return $response | ConvertTo-Json -Depth 10
}
catch {
    Write-Error "Failed to get article links: $_"
    throw
}
