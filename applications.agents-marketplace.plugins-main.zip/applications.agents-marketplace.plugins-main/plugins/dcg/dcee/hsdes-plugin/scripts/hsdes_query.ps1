<# HSDes EQL Query Script
.SYNOPSIS
    Execute HSDes EQL queries via REST API
.PARAMETER Eql
    The EQL query string
.PARAMETER OutputFile
    Optional JSON output file path
.PARAMETER MaxResults
    Maximum number of results to return (default: 10000)
.EXAMPLE
    .\hsdes_query.ps1 -Eql "SELECT id, title WHERE tenant = 'server_platf_ae' AND subject = 'bug'"
.NOTES
    Requires PowerShell 7+ (pwsh)
#>
#Requires -Version 7
param(
    [Parameter(Mandatory=$true)]
    [string]$Eql,

    [Parameter(Mandatory=$false)]
    [string]$OutputFile,

    [Parameter(Mandatory=$false)]
    [int]$MaxResults = 10000
)

. "$PSScriptRoot/hsdes_auth.ps1"

$requestPath = "query/execution/eql?start_at=1&max_results=$MaxResults"
$body = @{ eql = $Eql } | ConvertTo-Json

$params = New-HsdesRequestParams -Path $requestPath -Method 'Post' -ContentType 'application/json' -Body $body

try {
    $response = Invoke-RestMethod @params

    if ($OutputFile) {
        $response | ConvertTo-Json -Depth 10 | Out-File -FilePath $OutputFile -Encoding UTF8
        Write-Host "Results saved to: $OutputFile"
    }

    # Format output with clear success indicator
    $totalResults = if ($response.data) { $response.data.Count } else { 0 }
    $maxResults = if ($response.max_results) { $response.max_results } else { 'unknown' }

    # Add summary header for LLM parsing
    Write-Output "=== QUERY SUCCESS ==="
    Write-Output "Total results returned: $totalResults"
    Write-Output "Max results limit: $maxResults"
    Write-Output "=== RESULTS ==="

    return $response | ConvertTo-Json -Depth 10 -Compress
}
catch {
    $errorMsg = $_.Exception.Message
    Write-Output "=== QUERY FAILED ==="
    Write-Output "Error: $errorMsg"

    # Check for common error patterns
    if ($errorMsg -match "401|Unauthorized") {
        Write-Output "Cause: Authentication failed. Please verify Intel domain login."
    }
    elseif ($errorMsg -match "Syntax Error|Error \d+") {
        Write-Output "Cause: EQL syntax error. Check operators (uppercase), quotes (single), and field names."
    }
    elseif ($errorMsg -match "Unable to connect|network") {
        Write-Output "Cause: Cannot connect to HSDes API. Check network connectivity."
    }

    throw
}
