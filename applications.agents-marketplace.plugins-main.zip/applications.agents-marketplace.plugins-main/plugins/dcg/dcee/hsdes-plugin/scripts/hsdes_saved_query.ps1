<# HSDes Saved Query Execution Script
.SYNOPSIS
    Execute a saved HSDes query by its query ID
.PARAMETER QueryId
    The saved query ID
.PARAMETER MaxResults
    Maximum number of results to return (default: 10000)
.PARAMETER StripBombFields
    Remove heavy fields (description, comments, ext_cust_blog_hist) from each row
    before serialization. Default $true. Critical because HSDes embeds malformed
    HTML inside ext_cust_blog_hist (unescaped quotes, raw control chars) which
    breaks Python's json.loads downstream — stripping at the PowerShell object
    level avoids ever serializing the malformed content.
.PARAMETER KeepFields
    Comma-separated list of bomb-field names to retain even when StripBombFields
    is $true. Use to opt back in to specific fields per call.
.PARAMETER Format
    'text' (default) or 'html'. When 'text', HTML body fields kept by KeepFields
    (description / ext_cust_blog_hist) are converted to plain text before
    serialization. This sidesteps HSDes's malformed-HTML serialization (unescaped
    quotes, raw control chars) that breaks Python's json.loads downstream.
.EXAMPLE
    .\hsdes_saved_query.ps1 -QueryId 15013555803
.EXAMPLE
    .\hsdes_saved_query.ps1 -QueryId 15013555803 -KeepFields "ext_cust_blog_hist"
.EXAMPLE
    .\hsdes_saved_query.ps1 -QueryId 15013555803 -KeepFields "ext_cust_blog_hist" -Format html
.NOTES
    Requires PowerShell 7+ (pwsh)
#>
#Requires -Version 7
param(
    [Parameter(Mandatory=$true)]
    [string]$QueryId,

    [Parameter(Mandatory=$false)]
    [int]$MaxResults = 10000,

    [Parameter(Mandatory=$false)]
    [bool]$StripBombFields = $true,

    [Parameter(Mandatory=$false)]
    [string]$KeepFields = "",

    [Parameter(Mandatory=$false)]
    [ValidateSet('text', 'html')]
    [string]$Format = 'text'
)

if ($QueryId -notmatch '^\d+$') { throw "Invalid QueryId: Must be numeric." }

# Force UTF-8 stdout. Without this, pwsh -File mode under subprocess uses the
# system default (cp1252 / OEM), which substitutes non-representable Unicode
# chars (e.g. →, → arrows in HSDes BIOS-knob descriptions) with `\x1A` SUB —
# producing invalid JSON downstream that Python's json.loads rejects with
# "Invalid control character". The `$jsonOutput` string in PowerShell is fine;
# the corruption is in the stdout encoding step.
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

. "$PSScriptRoot/hsdes_auth.ps1"
. "$PSScriptRoot/hsdes_text_helpers.ps1"

$requestPath = "query/execution/${QueryId}?start_at=1&max_results=$MaxResults"
$params = New-HsdesRequestParams -Path $requestPath -Method 'Get' -Headers @{ "Accept" = "application/json" }

try {
    $response = Invoke-RestMethod @params

    if ($StripBombFields -and $response.data) {
        $bombFields = @(
            'description',
            'comments',
            'ext_cust_blog_hist',
            'server_platf_ae.bug.ext_cust_blog_hist'
        )
        $keepSet = @{}
        foreach ($f in ($KeepFields -split ',')) {
            $trimmed = $f.Trim()
            if ($trimmed) { $keepSet[$trimmed] = $true }
        }
        $stripCounts = [ordered]@{}
        foreach ($row in $response.data) {
            foreach ($field in $bombFields) {
                if ($keepSet.ContainsKey($field)) { continue }
                $prop = $row.PSObject.Properties[$field]
                if ($prop) {
                    $val = [string]$prop.Value
                    if (-not [string]::IsNullOrEmpty($val)) {
                        if ($stripCounts.Contains($field)) {
                            $stripCounts[$field] = [int]$stripCounts[$field] + 1
                        } else {
                            $stripCounts[$field] = 1
                        }
                    }
                    $row.PSObject.Properties.Remove($field)
                }
            }
        }
        if ($stripCounts.Count -gt 0) {
            $response | Add-Member -NotePropertyName '_stripped' -NotePropertyValue $stripCounts -Force
        }
    }

    # HTML → text on any body fields that survived (i.e., were KeepFields'd).
    # This is the critical fix: ext_cust_blog_hist contains malformed HTML
    # (unescaped quotes, raw \x1a) that breaks downstream JSON parsing if kept as-is.
    if ($Format -eq 'text' -and $response.data) {
        $bodyFields = @('description', 'comments', 'ext_cust_blog_hist', 'server_platf_ae.bug.ext_cust_blog_hist', 'irf_notes')
        foreach ($row in $response.data) {
            foreach ($field in $bodyFields) {
                $prop = $row.PSObject.Properties[$field]
                if ($prop -and $prop.Value) {
                    $row.$field = Convert-HsdesHtmlToText -Html ([string]$prop.Value)
                }
            }
        }
    }

    $jsonOutput = $response | ConvertTo-Json -Depth 10

    # Belt-and-suspenders: strip any raw control chars that survived field-level
    # cleanup (e.g. mojibake bytes from HSDes that PowerShell flagged unicode-wise
    # as ASCII control chars). JSON syntax doesn't allow raw control chars in
    # strings — anything legitimately needed would be \uXXXX-escaped — so this is
    # a safe final-stage cleanup that prevents downstream Python json.loads
    # failures entirely.
    if ($Format -eq 'text') {
        $jsonOutput = [regex]::Replace($jsonOutput, '[\x00-\x08\x0B\x0C\x0E-\x1F]', '')
    }
    return $jsonOutput
}
catch {
    Write-Error "HSDes saved query failed: $_"
    throw
}
