<# HSDes Saved Query Definition Script
.SYNOPSIS
    Get the definition (metadata) of a saved HSDes query by its query ID.
    Returns the query title, EQL expression, owner, and other metadata.
    Use this when you want to INSPECT a saved query, not execute it.
.PARAMETER QueryId
    The saved query ID (numeric)
.EXAMPLE
    .\hsdes_saved_query_def.ps1 -QueryId 22020838886
.NOTES
    Requires PowerShell 7+ (pwsh)
    Endpoint: GET /rest/query/{QueryId}
#>
#Requires -Version 7
param(
    [Parameter(Mandatory=$true)]
    [string]$QueryId
)

if ($QueryId -notmatch '^\d+$') { throw "Invalid QueryId: Must be numeric." }
. "$PSScriptRoot/hsdes_auth.ps1"

$requestPath = "query/$QueryId"
$params = New-HsdesRequestParams -Path $requestPath -Method 'Get' -Headers @{ "Accept" = "application/json" }

try {
    $response = Invoke-RestMethod @params
    return $response | ConvertTo-Json -Depth 10
}
catch {
    Write-Error "HSDes get saved query definition failed: $_"
    throw
}
