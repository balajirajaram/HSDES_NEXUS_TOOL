<# HSDes Text Helpers — HTML → plain text conversion for body fields.

Shared by hsdes_saved_query.ps1, hsdes_get_article.ps1, hsdes_get_comments.ps1.

Why: HSDes embeds malformed HTML in fields like ext_cust_blog_hist (unescaped
double quotes inside string values, raw control chars). When ConvertTo-Json
serializes that, downstream Python json.loads chokes. Doing HTML → text BEFORE
serialization sidesteps the problem entirely — once tags are stripped and
entities decoded, the resulting plain text round-trips cleanly through JSON.

Also dramatically reduces token footprint (typical 5-10x compression vs HTML
with mso-* style attributes) and is easier for LLMs to reason about.
#>
#Requires -Version 7

function Convert-HsdesHtmlToText {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [AllowEmptyString()]
        [AllowNull()]
        [string]$Html
    )

    if ([string]::IsNullOrWhiteSpace($Html)) { return '' }

    $text = $Html

    # Inline base64 images → placeholder (defense-in-depth; mcp_server.py also strips)
    $text = [regex]::Replace($text, 'data:image/[\w+.\-]+;base64,[A-Za-z0-9+/=]+', '[base64-image]')

    # Block-level tags → newline (preserve paragraph / list structure)
    $text = [regex]::Replace($text, '(?i)<br\s*/?>', "`n")
    $text = [regex]::Replace($text, '(?i)</p\s*>', "`n")
    $text = [regex]::Replace($text, '(?i)</li\s*>', "`n")
    $text = [regex]::Replace($text, '(?i)</div\s*>', "`n")
    $text = [regex]::Replace($text, '(?i)</tr\s*>', "`n")

    # All remaining HTML tags → space
    $text = [regex]::Replace($text, '<[^>]+>', ' ')

    # Decode HTML entities (&amp;, &nbsp;, &quot;, ...)
    $text = [System.Net.WebUtility]::HtmlDecode($text)

    # Strip raw control chars that HSDes embeds (\x07 BEL, \x1a SUB, etc.) but
    # keep \t (\x09), \n (\x0A), \r (\x0D)
    $text = [regex]::Replace($text, '[\x00-\x08\x0B\x0C\x0E-\x1F]', '')

    # Collapse runs of spaces/tabs (but not newlines)
    $text = [regex]::Replace($text, '[ \t]+', ' ')

    # Normalize CRLF / CR → LF
    $text = $text -replace "`r`n", "`n" -replace "`r", "`n"

    # Collapse 3+ consecutive newlines to 2
    $text = [regex]::Replace($text, "`n{3,}", "`n`n")

    return $text.Trim()
}
