<# HSDes Update Article Script
.SYNOPSIS
    Add a comment, update an existing comment, set notify, and/or set the
    customer-blog rich-HTML field on an HSDes article.
.DESCRIPTION
    HSDes models comments as CHILD ARTICLES (subject="comments", parent_id=bug),
    NOT as a writable field on the parent. The `comments` field on the parent
    is a server-aggregated read-only string ("++++<id> <user>\n..."). Trying
    to PUT it returns 400 "[comments] is a read only field. You cannot set it."

    This script uses four routes:
      -Comments  alone           → POST /article  (new child comment)
      -Comments + -CommentId     → PUT  /article/<comment_id>  (update existing)
      -Notify                    → PUT  /article/<article_id>  (parent's notify field)
      -ExtCustBlogRich           → PUT  /article/<article_id>  (server_platf_ae only)
                                    Writes BOTH server_platf_ae.bug.ext_cust_blog_rich
                                    (raw HTML) and server_platf_ae.bug.ext_cust_blog
                                    (auto-derived plain text) — HSDes UI uses both
                                    fields as a pair.

    All routes require `tenant` and `subject` at the TOP LEVEL of the body
    (ArticleRequest schema position 1/2). Without them HSDes returns 400
    "The view name specified doesn't exist".

    Tenant-scoped fields (e.g. server_platf_ae.bug.*) MUST be referenced by
    full prefix in fieldValues — short names (ext_cust_blog_rich without
    tenant.subject prefix) return 400 "is NOT a valid field for X.Y".

    Tenant/subject are auto-discovered (parent for add+notify+blog, comment
    for update) so the caller doesn't need to supply them.

    DELETE on a comment article returns 405 Method Not Allowed — HSDes does
    not support comment deletion via the REST API. Use the web UI or escalate.

    Dry-run support is via ?debug=true on each request — the server validates
    the body but does NOT persist. Note: dry-run does NOT catch field
    writability errors (e.g. trying to write a read-only field passes
    dry-run but fails on real write).
.PARAMETER ArticleId
    Numeric HSDes article ID (the parent bug). Required for all routes —
    used as the addressing target for new comments and notify, and as
    context when updating an existing comment.
.PARAMETER Comments
    Comment body (HTML or plain text). With -CommentId: replaces the body
    of that comment. Without -CommentId: posted as a NEW child comment.
.PARAMETER CommentId
    Optional numeric ID of an existing comment article. When set together
    with -Comments, the existing comment's body is updated in place.
.PARAMETER Notify
    Comma-separated IDSIDs to notify, written to the parent's notify field.
.PARAMETER ExtCustBlog
    Plain text for server_platf_ae.bug.ext_cust_blog. Optional. If only
    -ExtCustBlogRich is provided, the plain version is auto-derived from
    HTML; pass -ExtCustBlog to override that derivation with caller-
    supplied plain text.
.PARAMETER ExtCustBlogRich
    Rich HTML body for the customer-blog rich field
    (server_platf_ae.bug.ext_cust_blog_rich). Tenant-restricted to
    server_platf_ae — the script returns an error if the parent article is
    in a different tenant. When supplied without -ExtCustBlog, plain-text
    companion field (server_platf_ae.bug.ext_cust_blog) is auto-derived
    from the HTML and written in the same PUT, mirroring the HSDes UI's
    paired-field pattern.
.PARAMETER Status
    New status value for the parent article (e.g. 'open', 'review',
    'complete'). Written as a bare `status` field in fieldValues.
.PARAMETER Reason
    New reason value for the parent article (e.g. 'awaiting_user',
    'investigation', 'fixed'). HSDes models status+reason as TWO SEPARATE
    fields whose display value is `status_reason = <status>.<reason>` —
    `status_reason` itself is read-only and silently no-ops on PUT.
    Always write the bare `reason` (and optionally `status`) instead.
    HSDes also silently no-ops invalid transitions for these fields
    (returns 200 with empty body), so when -DryRun is 'false' the script
    performs a verify GET after the write and reports whether the value
    actually took (verify_ok=true/false in the operation record).
.PARAMETER DryRun
    'true' (default) → ?debug=true on each call (validate, don't persist).
    'false' → real write.
#>
#Requires -Version 7
param(
    [Parameter(Mandatory=$true)]
    [string]$ArticleId,

    [Parameter(Mandatory=$false)]
    [string]$Comments,

    # When the caller has a body larger than the Windows command-line limit
    # (~32KB — inline base64 images blow past it easily), Python spools it to
    # a temp file and passes its path via -CommentsFile. Same idea for
    # -ExtCustBlogFile / -ExtCustBlogRichFile below.
    [Parameter(Mandatory=$false)]
    [string]$CommentsFile,

    [Parameter(Mandatory=$false)]
    [string]$CommentId,

    [Parameter(Mandatory=$false)]
    [string]$Notify,

    [Parameter(Mandatory=$false)]
    [string]$ExtCustBlog,

    [Parameter(Mandatory=$false)]
    [string]$ExtCustBlogFile,

    [Parameter(Mandatory=$false)]
    [string]$ExtCustBlogRich,

    [Parameter(Mandatory=$false)]
    [string]$ExtCustBlogRichFile,

    [Parameter(Mandatory=$false)]
    [string]$Status,

    [Parameter(Mandatory=$false)]
    [string]$Reason,

    [Parameter(Mandatory=$false)]
    [ValidateSet('true','false')]
    [string]$DryRun = 'true'
)

[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
. "$PSScriptRoot/hsdes_auth.ps1"
. "$PSScriptRoot/hsdes_text_helpers.ps1"

# Resolve -*File params (used when the argv form would exceed ~32KB).
if ($CommentsFile -and (Test-Path -LiteralPath $CommentsFile)) {
    $Comments = [System.IO.File]::ReadAllText($CommentsFile, [System.Text.Encoding]::UTF8)
}
if ($ExtCustBlogFile -and (Test-Path -LiteralPath $ExtCustBlogFile)) {
    $ExtCustBlog = [System.IO.File]::ReadAllText($ExtCustBlogFile, [System.Text.Encoding]::UTF8)
}
if ($ExtCustBlogRichFile -and (Test-Path -LiteralPath $ExtCustBlogRichFile)) {
    $ExtCustBlogRich = [System.IO.File]::ReadAllText($ExtCustBlogRichFile, [System.Text.Encoding]::UTF8)
}

if ($ArticleId -notmatch '^\d+$') {
    Write-Output "=== UPDATE FAILED ==="
    Write-Output "Error: ArticleId must be numeric, got: $ArticleId"
    exit 0
}
if ($PSBoundParameters.ContainsKey('CommentId') -and $CommentId.Length -gt 0 -and $CommentId -notmatch '^\d+$') {
    Write-Output "=== UPDATE FAILED ==="
    Write-Output "Error: CommentId must be numeric, got: $CommentId"
    exit 0
}

# NOTE: don't gate on $PSBoundParameters.ContainsKey here — when Python
# spools a large value via the -{Key}File companion param, -Key itself is
# NOT in $PSBoundParameters (only -KeyFile is), even after the file-read
# block above assigns to $Key. Check the variable value directly.
$wantComments    = $Comments.Length        -gt 0
$wantCommentId   = $CommentId.Length       -gt 0
$wantNotify      = $Notify.Length          -gt 0
$wantBlogPlain   = $ExtCustBlog.Length     -gt 0
$wantBlogRich    = $ExtCustBlogRich.Length -gt 0
$wantBlogAny     = $wantBlogPlain -or $wantBlogRich
$wantStatus      = $Status.Length          -gt 0
$wantReason      = $Reason.Length          -gt 0
$wantStatusReason = $wantStatus -or $wantReason

if ($wantCommentId -and -not $wantComments) {
    Write-Output "=== UPDATE FAILED ==="
    Write-Output "Error: -CommentId requires -Comments (the new body to write)."
    exit 0
}

if (-not $wantComments -and -not $wantNotify -and -not $wantBlogAny -and -not $wantStatusReason) {
    Write-Output "=== UPDATE FAILED ==="
    Write-Output "Error: No fields to update. Pass at least one of -Comments, -Notify, -ExtCustBlog, -ExtCustBlogRich, -Status, -Reason."
    exit 0
}

# ---------------------------------------------------------------------------
# Helper: GET the tenant/subject of an article (parent or comment).
# ---------------------------------------------------------------------------
function Get-HsdesTenantSubject {
    param([string]$Id)
    try {
        $params = New-HsdesRequestParams -Path "article/$Id`?fields=tenant,subject" -Method 'Get'
        $resp = Invoke-RestMethod @params
        $rec = if ($resp.data) { $resp.data[0] } else { $null }
    } catch {
        return @{ ok = $false; error = $_.Exception.Message }
    }
    if (-not $rec -or [string]::IsNullOrWhiteSpace($rec.tenant) -or [string]::IsNullOrWhiteSpace($rec.subject)) {
        return @{ ok = $false; error = "no tenant/subject (article does not exist or no read access)" }
    }
    return @{ ok = $true; tenant = [string]$rec.tenant; subject = [string]$rec.subject }
}

# Discover parent tenant/subject — needed for both new-comment POST and notify PUT.
$parentMeta = Get-HsdesTenantSubject -Id $ArticleId
if (-not $parentMeta.ok) {
    Write-Output "=== UPDATE FAILED ==="
    Write-Output "ArticleId: $ArticleId"
    Write-Output "Error: Could not read parent article — $($parentMeta.error)"
    exit 0
}
$parentTenant  = $parentMeta.tenant
$parentSubject = $parentMeta.subject

$query = if ($DryRun -eq 'true') { '?debug=true' } else { '' }

# ---------------------------------------------------------------------------
# Helper — execute one HTTP call, capture raw error body.
# ---------------------------------------------------------------------------
function Invoke-HsdesWrite {
    param([string]$Path, [string]$Method, [string]$Body)
    $params = New-HsdesRequestParams -Path $Path -Method $Method -ContentType 'application/json' -Body $Body
    try {
        $resp = Invoke-WebRequest @params -SkipHttpErrorCheck
        return @{
            success    = ($resp.StatusCode -ge 200 -and $resp.StatusCode -lt 300)
            statusCode = [int]$resp.StatusCode
            body       = $resp.Content
        }
    } catch {
        return @{ success = $false; statusCode = 0; body = $_.Exception.Message }
    }
}

$results = [ordered]@{
    article_id = $ArticleId
    comment_id = if ($wantCommentId) { $CommentId } else { $null }
    dry_run    = $DryRun
    tenant     = $parentTenant
    subject    = $parentSubject
    operations = @()
    overall_ok = $true
}

# ---------------------------------------------------------------------------
# Op 1: comments
#   - With CommentId → PUT /article/<comment_id> (update existing)
#   - Without        → POST /article (add new child)
# ---------------------------------------------------------------------------
if ($wantComments) {
    if ($wantCommentId) {
        # Update existing comment — discover its own tenant/subject.
        $cMeta = Get-HsdesTenantSubject -Id $CommentId
        if (-not $cMeta.ok) {
            $results.operations += [ordered]@{
                op = 'update_comment'; method = 'PUT'; path = "article/$CommentId$query"
                status_code = 0; success = $false
                body = "Could not read comment — $($cMeta.error)"
            }
            $results.overall_ok = $false
        } else {
            $bodyObj = [ordered]@{
                tenant      = $cMeta.tenant
                subject     = $cMeta.subject
                fieldValues = @( @{ description = $Comments } )
            }
            $body = $bodyObj | ConvertTo-Json -Depth 5 -Compress
            $r = Invoke-HsdesWrite -Path "article/$CommentId$query" -Method 'Put' -Body $body
            $results.operations += [ordered]@{
                op = 'update_comment'; method = 'PUT'; path = "article/$CommentId$query"
                status_code = $r.statusCode; success = $r.success; body = $r.body
            }
            if (-not $r.success) { $results.overall_ok = $false }
        }
    } else {
        # Add a new child comment under the parent.
        $bodyObj = [ordered]@{
            tenant      = $parentTenant
            subject     = 'comments'
            fieldValues = @(
                @{ parent_id   = $ArticleId },
                @{ description = $Comments }
            )
        }
        $body = $bodyObj | ConvertTo-Json -Depth 5 -Compress
        $r = Invoke-HsdesWrite -Path "article$query" -Method 'Post' -Body $body
        $results.operations += [ordered]@{
            op = 'add_comment'; method = 'POST'; path = "article$query"
            status_code = $r.statusCode; success = $r.success; body = $r.body
        }
        if (-not $r.success) { $results.overall_ok = $false }
    }
}

# ---------------------------------------------------------------------------
# Op 2: PUT ext_cust_blog_rich (+ auto-derived plain ext_cust_blog).
#   - server_platf_ae tenant only (other tenants don't have these fields).
#   - Tenant-scoped fields use the FULL prefix in fieldValues; short names
#     like "ext_cust_blog_rich" return "is NOT a valid field" (HSDes routes
#     short-names to base schema first).
#   - HSDes UI pairs these two fields; we mirror that by deriving plain
#     text from the supplied HTML and writing both atomically in one PUT.
#   - NOTE: HSDes UI shows this field as read-only — users see our value
#     but can't edit it via the form. Direct PUT is a back-door API path
#     intended for sync agents. The `_UPDATE_ALLOWED_FIELDS` allowlist in
#     mcp_server.py intentionally does NOT expose this to AI callers; this
#     param is here for manual / scripted use only.
# ---------------------------------------------------------------------------
if ($wantBlogAny) {
    if ($parentTenant -ne 'server_platf_ae') {
        $results.operations += [ordered]@{
            op = 'set_ext_cust_blog'; method = 'PUT'; path = "article/$ArticleId$query"
            status_code = 0; success = $false
            body = "ext_cust_blog* is server_platf_ae-only; parent tenant is '$parentTenant'."
        }
        $results.overall_ok = $false
    } else {
        $prefix = "$parentTenant.$parentSubject"
        $fields = @()
        $plainSource = 'omitted'
        if ($wantBlogPlain) {
            $plainValue = $ExtCustBlog
            $plainSource = 'caller'
        } elseif ($wantBlogRich) {
            $plainValue = Convert-HsdesHtmlToText -Html $ExtCustBlogRich
            $plainSource = 'auto-derived'
        }
        if ($plainSource -ne 'omitted') {
            $fields += @{ "$prefix.ext_cust_blog" = $plainValue }
        }
        if ($wantBlogRich) {
            $fields += @{ "$prefix.ext_cust_blog_rich" = $ExtCustBlogRich }
        }
        $bodyObj = [ordered]@{
            tenant      = $parentTenant
            subject     = $parentSubject
            fieldValues = $fields
        }
        $body = $bodyObj | ConvertTo-Json -Depth 5 -Compress
        $r = Invoke-HsdesWrite -Path "article/$ArticleId$query" -Method 'Put' -Body $body
        $opEntry = [ordered]@{
            op = 'set_ext_cust_blog'; method = 'PUT'; path = "article/$ArticleId$query"
            status_code = $r.statusCode; success = $r.success; body = $r.body
            plain_source = $plainSource
            wrote_rich = $wantBlogRich
        }
        $results.operations += $opEntry
        if (-not $r.success) { $results.overall_ok = $false }
    }
}

# ---------------------------------------------------------------------------
# Op 3: PUT notify on the parent if -Notify provided.
# ---------------------------------------------------------------------------
if ($wantNotify) {
    $bodyObj = [ordered]@{
        tenant      = $parentTenant
        subject     = $parentSubject
        fieldValues = @( @{ notify = $Notify } )
    }
    $body = $bodyObj | ConvertTo-Json -Depth 5 -Compress
    $r = Invoke-HsdesWrite -Path "article/$ArticleId$query" -Method 'Put' -Body $body
    $results.operations += [ordered]@{
        op = 'set_notify'; method = 'PUT'; path = "article/$ArticleId$query"
        status_code = $r.statusCode; success = $r.success; body = $r.body
    }
    if (-not $r.success) { $results.overall_ok = $false }
}

# ---------------------------------------------------------------------------
# Op 4: PUT status and/or reason on the parent.
#   - HSDes models these as TWO SEPARATE writable fields. The `status_reason`
#     field returned by GET is a server-aggregated read-only display value
#     of the form `<status>.<reason>` (e.g. `open.awaiting_user`). Writing
#     `status_reason` directly returns 200 with empty body but the value is
#     NOT persisted. Always write the bare `status` / `reason` instead.
#   - HSDes also silently no-ops invalid transitions on these fields (200
#     empty body, no error). On a real write (DryRun='false') we follow up
#     with a GET and compare the live values to what we asked for,
#     reporting verify_ok=true/false so the caller knows whether the write
#     actually landed.
# ---------------------------------------------------------------------------
if ($wantStatusReason) {
    $sr = [ordered]@{}
    if ($wantStatus) { $sr['status'] = $Status }
    if ($wantReason) { $sr['reason'] = $Reason }
    $bodyObj = [ordered]@{
        tenant      = $parentTenant
        subject     = $parentSubject
        fieldValues = @( $sr )
    }
    $body = $bodyObj | ConvertTo-Json -Depth 5 -Compress
    $r = Invoke-HsdesWrite -Path "article/$ArticleId$query" -Method 'Put' -Body $body
    $opEntry = [ordered]@{
        op = 'set_status_reason'; method = 'PUT'; path = "article/$ArticleId$query"
        status_code = $r.statusCode; success = $r.success; body = $r.body
        wrote_status = $wantStatus
        wrote_reason = $wantReason
    }
    # Verify-after-write — only on real writes; dry-run never persists.
    if ($r.success -and $DryRun -eq 'false') {
        try {
            $vParams = New-HsdesRequestParams -Path "article/$ArticleId`?fields=status,reason,status_reason" -Method 'Get'
            $vResp = Invoke-RestMethod @vParams
            $vRec = if ($vResp.data) { $vResp.data[0] } else { $null }
            if ($vRec) {
                $verifyOk = $true
                $verifyDetail = [ordered]@{ status = $vRec.status; reason = $vRec.reason; status_reason = $vRec.status_reason }
                if ($wantStatus -and [string]$vRec.status -ne $Status) { $verifyOk = $false }
                if ($wantReason -and [string]$vRec.reason -ne $Reason) { $verifyOk = $false }
                $opEntry['verify_ok'] = $verifyOk
                $opEntry['verify_detail'] = $verifyDetail
                if (-not $verifyOk) {
                    $opEntry['success'] = $false
                    $results.overall_ok = $false
                }
            } else {
                $opEntry['verify_ok'] = $false
                $opEntry['verify_detail'] = 'GET returned no data row'
                $opEntry['success'] = $false
                $results.overall_ok = $false
            }
        } catch {
            $opEntry['verify_ok'] = $false
            $opEntry['verify_detail'] = "verify GET failed: $($_.Exception.Message)"
            # Don't flip success on a verify-GET failure (the write may have landed) — just warn.
        }
    }
    $results.operations += $opEntry
    if (-not $r.success) { $results.overall_ok = $false }
}

# ---------------------------------------------------------------------------
# Render summary lines + JSON detail for callers parsing stdout.
# ---------------------------------------------------------------------------
if ($results.overall_ok) {
    Write-Output "=== UPDATE SUCCESS ==="
} else {
    Write-Output "=== UPDATE FAILED ==="
}
Write-Output "DryRun: $DryRun"
Write-Output "ArticleId: $ArticleId"
if ($wantCommentId) { Write-Output "CommentId: $CommentId" }
Write-Output "Tenant: $parentTenant"
Write-Output "Subject: $parentSubject"
foreach ($op in $results.operations) {
    Write-Output ("Op {0}: {1} {2} → {3} (success={4})" -f $op.op, $op.method, $op.path, $op.status_code, $op.success)
}
Write-Output "=== RESPONSE ==="
return ($results | ConvertTo-Json -Depth 6 -Compress)
