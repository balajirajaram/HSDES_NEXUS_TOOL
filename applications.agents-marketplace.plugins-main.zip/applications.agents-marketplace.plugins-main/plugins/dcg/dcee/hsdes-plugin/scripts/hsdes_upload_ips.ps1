<# HSDes Upload IPS Attachment
.SYNOPSIS
    Upload a file to ESFT/IPS for an HSDes article without opening the browser tab.
.DESCRIPTION
    Reverse-engineered from the SFT IPS Upload SPA (esft-int.intel.com/sftipsupload).
    Workflow:
      1. GET /rest/article/{id} -> extract caseid + visibility from
         server_platf_ae.bug.upload_attach_to_ips field.
      2. Generate AppFileID (UUID v4) once for the whole upload.
      3. Slice the file into 10 MB chunks.
      4. POST each chunk as multipart/form-data to
         /sftservices/upload/IPS_SFT/ with full metadata.
      5. ESFT auto-mirrors IPS_SFT -> HSDES_SFT so the file shows up on the article.
.PARAMETER ArticleId
    HSDes article ID (numeric). Used to look up the SFDC caseid.
.PARAMETER FilePath
    Local file to upload.
.PARAMETER Description
    Description for the attachment. Goes into the multipart Comment field
    (the same field the web UI's "Description" text box writes to).
.PARAMETER Visibility
    auto (default): pick the first <a> link from upload_attach_to_ips
                    (typically "Upload to IPS (Public)").
    public:         match a link whose visibility=Public_to_Customers
    internal:       match a link whose visibility=Private_to_Intel
    partner:        match a link whose visibility=Private_to_Partner
.PARAMETER DryRun
    Skip the actual POST. Only resolves caseid+visibility and prints what would
    happen. Useful for end-to-end checks.
.EXAMPLE
    .\hsdes_upload_ips.ps1 -ArticleId 22015171853 -FilePath C:\tmp\foo.txt -Description "Test upload"
.EXAMPLE
    .\hsdes_upload_ips.ps1 -ArticleId 22015171853 -FilePath C:\tmp\foo.txt -Description "test" -DryRun true
#>
#Requires -Version 7
param(
    [Parameter(Mandatory=$true)]
    [string]$ArticleId,
    [Parameter(Mandatory=$true)]
    [string]$FilePath,
    [Parameter(Mandatory=$true)]
    [string]$Description,
    [ValidateSet('auto','public','internal','partner')]
    [string]$Visibility = 'auto',
    [int]$ChunkSizeMB = 10,
    [int]$TimeoutSec = 300,
    [bool]$DryRun = $false
)

if ($ArticleId -notmatch '^\d+$') { throw "Invalid ArticleId: must be numeric." }
if (-not (Test-Path -LiteralPath $FilePath -PathType Leaf)) { throw "File not found: $FilePath" }
if ([string]::IsNullOrWhiteSpace($Description)) { throw "Description is required (goes into ESFT Comment field)." }

. "$PSScriptRoot/hsdes_auth.ps1"

$VisibilityToken = @{
    'public'   = 'Public_to_Customers'
    'internal' = 'Private_to_Intel'
    'partner'  = 'Private_to_Partner'
}
$VisibilityJson = @{
    'Public_to_Customers' = '{"visibility":"Public to Customers"}'
    'Private_to_Intel'    = '{"visibility":"Private to Intel"}'
    'Private_to_Partner'  = '{"visibility":"Private to Partner"}'
}

# --- Step 1: pull caseid + visibility from the article ---

Write-Host "[1/3] Resolving caseid from HSDes article $ArticleId" -ForegroundColor Cyan

$reqParams = New-HsdesRequestParams `
    -Path "article/$ArticleId`?fields=server_platf_ae.bug.upload_attach_to_ips" `
    -Method 'Get' `
    -Headers @{ 'Accept' = 'application/json' }

try {
    $articleResp = Invoke-RestMethod @reqParams
}
catch {
    throw "Failed to fetch article ${ArticleId}: $_"
}

$record = $articleResp.data | Select-Object -First 1
if (-not $record) { throw "Article $ArticleId returned no data." }

# Field path: server_platf_ae.bug.upload_attach_to_ips
$xmlBlob = $null
$bugNode = $record.PSObject.Properties['server_platf_ae.bug.upload_attach_to_ips']
if ($bugNode) {
    $xmlBlob = $bugNode.Value
} else {
    # Some records nest as server_platf_ae.bug.upload_attach_to_ips dotted-path
    $xmlBlob = ($record | Select-Object -ExpandProperty 'server_platf_ae.bug.upload_attach_to_ips' -ErrorAction SilentlyContinue)
}

if ([string]::IsNullOrWhiteSpace($xmlBlob)) {
    throw "Article $ArticleId has no upload_attach_to_ips link (no IPS case associated)."
}

# Extract every <a href="...sftipsupload/...?application=IPS_SFT&caseid=...&visibility=..."> entry
# Host is captured so we can route the upload to the matching ESFT environment
# (production esft.intel.com vs integration esft-int.intel.com).
$linkPattern = 'href="https://(esft(?:-int)?\.intel\.com)/sftipsupload/index\.html\?[^"]*?application=IPS_SFT[^"]*?caseid=([0-9a-zA-Z]{15,18})[^"]*?visibility=([A-Za-z_]+)[^"]*?"'
$linkMatches = [regex]::Matches($xmlBlob, $linkPattern)
if ($linkMatches.Count -eq 0) {
    throw "No IPS_SFT upload links found in upload_attach_to_ips field. Raw value: $xmlBlob"
}

$candidates = @()
foreach ($m in $linkMatches) {
    $candidates += [pscustomobject]@{
        Host       = $m.Groups[1].Value
        CaseId     = $m.Groups[2].Value
        Visibility = $m.Groups[3].Value
    }
}

$chosen = $null
if ($Visibility -eq 'auto') {
    $chosen = $candidates[0]
} else {
    $wantToken = $VisibilityToken[$Visibility]
    $chosen = $candidates | Where-Object { $_.Visibility -eq $wantToken } | Select-Object -First 1
    if (-not $chosen) {
        $available = ($candidates | ForEach-Object { $_.Visibility }) -join ', '
        throw "No matching visibility=$wantToken link in article $ArticleId. Available: $available"
    }
}

$caseId = $chosen.CaseId
$visToken = $chosen.Visibility
$esftHost = $chosen.Host
$extendedJson = $VisibilityJson[$visToken]
if (-not $extendedJson) {
    throw "Unknown visibility token from article: $visToken"
}

Write-Host "  Host: $esftHost" -ForegroundColor Gray
Write-Host "  CaseID: $caseId" -ForegroundColor Gray
Write-Host "  Visibility: $visToken" -ForegroundColor Gray
Write-Host "  ExtendedAttributes: $extendedJson" -ForegroundColor Gray

# --- Step 2: prepare AppFileID + chunk plan ---

$file = Get-Item -LiteralPath $FilePath
$fileName = $file.Name
$fileSize = [int64]$file.Length
$chunkSize = [int64]($ChunkSizeMB * 1024 * 1024)
$appFileId = [guid]::NewGuid().ToString()

$chunkCount = if ($fileSize -eq 0) { 1 } else { [math]::Ceiling([double]$fileSize / [double]$chunkSize) }

Write-Host "[2/3] Upload plan" -ForegroundColor Cyan
Write-Host "  File: $fileName ($fileSize bytes)" -ForegroundColor Gray
Write-Host "  AppFileID: $appFileId" -ForegroundColor Gray
Write-Host "  Chunks: $chunkCount x ${ChunkSizeMB} MB" -ForegroundColor Gray

if ($DryRun) {
    Write-Host "[dry-run] Skipping POST. Returning resolved metadata." -ForegroundColor Yellow
    $result = @{
        success     = $true
        dry_run     = $true
        article_id  = $ArticleId
        host        = $esftHost
        case_id     = $caseId
        visibility  = $visToken
        extended    = $extendedJson
        file_name   = $fileName
        file_size   = $fileSize
        app_file_id = $appFileId
        chunk_count = $chunkCount
        chunk_size  = $chunkSize
    }
    return $result | ConvertTo-Json -Depth 4
}

# --- Step 3: chunked multipart POST ---

$uploadUri = "https://$esftHost/sftservices/upload/IPS_SFT/"

function New-MultipartBytes {
    param(
        [Parameter(Mandatory=$true)] $Fields,
        [Parameter(Mandatory=$true)] [string]$FileFieldName,
        [Parameter(Mandatory=$true)] [string]$FileName,
        [Parameter(Mandatory=$true)] [byte[]]$FileBytes,
        [Parameter(Mandatory=$true)] [string]$Boundary
    )
    $crlf = "`r`n"
    $ms = New-Object System.IO.MemoryStream
    $writer = New-Object System.IO.BinaryWriter($ms)
    $enc = [System.Text.Encoding]::UTF8

    foreach ($key in $Fields.Keys) {
        $value = [string]$Fields[$key]
        $header = "--$Boundary$crlf"
        $header += "Content-Disposition: form-data; name=`"$key`"$crlf$crlf"
        $writer.Write($enc.GetBytes($header))
        $writer.Write($enc.GetBytes($value))
        $writer.Write($enc.GetBytes($crlf))
    }

    # Binary file part
    $fileHeader = "--$Boundary$crlf"
    $fileHeader += "Content-Disposition: form-data; name=`"$FileFieldName`"; filename=`"$FileName`"$crlf"
    $fileHeader += "Content-Type: application/octet-stream$crlf$crlf"
    $writer.Write($enc.GetBytes($fileHeader))
    $writer.Write($FileBytes)
    $writer.Write($enc.GetBytes($crlf))

    # Closing boundary
    $writer.Write($enc.GetBytes("--$Boundary--$crlf"))
    $writer.Flush()
    return ,$ms.ToArray()
}

Write-Host "[3/3] Uploading $chunkCount chunk(s)..." -ForegroundColor Cyan

# Prime an authenticated keep-alive connection with a body-less GET so the
# NTLM 401-challenge handshake does not happen on the multipart POST. When
# the challenge fires on the POST, the body stream is already half-consumed
# and the retry sends a truncated body — ESFT then sees the file binary at
# the wrong byte offset and returns HTTP 500 ErrorCode 6006 "file position
# is not same as filepartoffset". Reusing the WebSession on the chunk POST
# below keeps the connection authenticated.
$primerUri = "https://$esftHost/sftipsupload/index.html"
try {
    Invoke-WebRequest `
        -Uri $primerUri `
        -Method Get `
        -UseDefaultCredentials `
        -NoProxy `
        -SessionVariable esftSession `
        -TimeoutSec $TimeoutSec `
        -ErrorAction Stop | Out-Null
} catch {
    Write-Host "  [warn] primer GET failed (continuing): $($_.Exception.Message)" -ForegroundColor Yellow
    $esftSession = New-Object Microsoft.PowerShell.Commands.WebRequestSession
    $esftSession.UseDefaultCredentials = $true
}

$fs = [System.IO.File]::OpenRead($FilePath)
$buffer = New-Object byte[] $chunkSize
$offset = [int64]0
$chunkIndex = 0
$lastResponse = $null

try {
    while ($offset -lt $fileSize -or ($fileSize -eq 0 -and $chunkIndex -eq 0)) {
        $chunkIndex++
        $remaining = $fileSize - $offset
        $thisChunk = if ($remaining -lt $chunkSize) { [int]$remaining } else { [int]$chunkSize }
        if ($thisChunk -lt 0) { $thisChunk = 0 }

        $chunkBytes = New-Object byte[] $thisChunk
        if ($thisChunk -gt 0) {
            $read = $fs.Read($chunkBytes, 0, $thisChunk)
            if ($read -ne $thisChunk) {
                throw "Short read at offset ${offset}: expected $thisChunk, got $read"
            }
        }

        $boundary = '----HsdesPSUpload' + [guid]::NewGuid().ToString('N')
        # Ordered hashtable: SPA appends fields in this exact order, mirror it.
        # EffectiveDate / ExpirationDate are mandatory; SPA sends both with the
        # SAME value (today, local TZ offset, no fractional seconds) via
        # moment().format() — verified by patched XHR capture.
        $nowLocal = (Get-Date).ToString('yyyy-MM-ddTHH:mm:sszzz')
        $fields = [ordered]@{
            'AppFileID'          = $appFileId
            'FileSize'           = $fileSize.ToString()
            'FilePartOffset'     = $offset.ToString()
            'CaseID'             = $caseId
            'Comment'            = $Description
            'ExtendedAttributes' = $extendedJson
            'EffectiveDate'      = $nowLocal
            'ExpirationDate'     = $nowLocal
        }
        $body = New-MultipartBytes `
            -Fields $fields `
            -FileFieldName 'file' `
            -FileName $fileName `
            -FileBytes $chunkBytes `
            -Boundary $boundary

        $contentType = "multipart/form-data; boundary=$boundary"
        $pct = if ($fileSize -gt 0) { [math]::Round((($offset + $thisChunk) * 100.0 / $fileSize), 1) } else { 100.0 }
        Write-Host "  chunk $chunkIndex/$chunkCount  offset=$offset  bytes=$thisChunk  ($pct%)" -ForegroundColor Gray

        try {
            $lastResponse = Invoke-WebRequest `
                -Uri $uploadUri `
                -Method Post `
                -Body $body `
                -ContentType $contentType `
                -UseDefaultCredentials `
                -WebSession $esftSession `
                -NoProxy `
                -TimeoutSec $TimeoutSec `
                -ErrorAction Stop
        }
        catch {
            $errBody = ''
            if ($_.Exception.Response) {
                try {
                    $stream = $_.Exception.Response.GetResponseStream()
                    $reader = New-Object System.IO.StreamReader($stream)
                    $errBody = $reader.ReadToEnd()
                } catch {}
            }
            throw "Chunk $chunkIndex POST failed: $($_.Exception.Message)`nResponse: $errBody"
        }

        $offset += $thisChunk
        if ($fileSize -eq 0) { break }
    }
}
finally {
    $fs.Dispose()
}

$statusCode = if ($lastResponse) { [int]$lastResponse.StatusCode } else { 0 }
$respBody = if ($lastResponse) { $lastResponse.Content } else { '' }

Write-Host "  Final status: $statusCode" -ForegroundColor Green

# Verify ESFT registered the upload via the SPA's per-file detail endpoint.
# ESFT moves files through pending -> ready before HSDes mirror picks them
# up; this confirms upload completed and surfaces sftPath + status without
# making the caller wait on the mirror.
$verify = @{}
try {
    $detailUri = "https://$esftHost/sftservices/getfileuploaddetail/IPS_SFT/?AppFileID=$appFileId"
    $detailResp = Invoke-WebRequest `
        -Uri $detailUri `
        -Method Get `
        -UseDefaultCredentials `
        -WebSession $esftSession `
        -NoProxy `
        -TimeoutSec $TimeoutSec `
        -ErrorAction Stop
    $outer = ($detailResp.Content | ConvertFrom-Json).GetFileUploadDetailResult
    $inner = $outer.FileDetails | ConvertFrom-Json
    $verify = @{
        status              = $inner.status
        sft_path            = $inner.sftPath
        upload_status_date  = $inner.uploadStatusDate
        size_in_bytes       = $inner.sizeInBytes
        category            = $inner.category
        extended            = $inner.extended
    }
} catch {
    $verify = @{ error = $_.Exception.Message }
}

$result = @{
    success        = ($statusCode -ge 200 -and $statusCode -lt 300)
    article_id     = $ArticleId
    host           = $esftHost
    case_id        = $caseId
    visibility     = $visToken
    file_name      = $fileName
    file_size      = $fileSize
    app_file_id    = $appFileId
    chunks_uploaded = $chunkIndex
    final_status   = $statusCode
    response_body  = $respBody
    verify         = $verify
}
return $result | ConvertTo-Json -Depth 5
