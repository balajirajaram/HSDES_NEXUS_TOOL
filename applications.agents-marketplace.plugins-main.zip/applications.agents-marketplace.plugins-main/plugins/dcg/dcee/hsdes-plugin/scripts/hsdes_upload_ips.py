"""HSDes Upload IPS Attachment — Python port of hsdes_upload_ips.ps1.

Uploads a local file to ESFT / IPS for an HSDes article without opening the
SPA browser tab. Reverse-engineered from the SFT IPS Upload SPA at
``esft-int.intel.com/sftipsupload`` and verified byte-for-byte against a live
SPA upload (patched ``XMLHttpRequest.send`` capture, 2026-04-29).

Workflow
--------
1. ``GET /rest/article/{id}?fields=server_platf_ae.bug.upload_attach_to_ips``
   to extract ``caseid`` + ``visibility`` + ``host`` from the embedded
   ``<a href>`` links.
2. Generate one ``AppFileID`` (UUID v4) shared by every chunk of the upload.
3. Slice the file into 10 MB chunks (default; configurable).
4. POST each chunk as ``multipart/form-data`` to
   ``https://<host>/sftservices/upload/IPS_SFT/`` with the SPA's exact field
   order. Auth is Windows session (NTLM / Kerberos).
5. ESFT auto-mirrors ``IPS_SFT`` -> ``HSDES_SFT`` so the file appears on the
   article within a few seconds.

Auth modes (mirrors ``hsdes_auth.ps1``)
---------------------------------------
* **Default** — NTLM / Kerberos via ``requests_negotiate_sspi`` for both the
  HSDes article fetch and the ESFT POST. Requires running on a domain-joined
  Windows machine.
* **Token** — when both ``HSDES_USERNAME`` and ``HSDES_TOKEN`` are set
  (process env or any of the ``.env`` lookup paths below), the HSDes article
  fetch uses HTTP Basic against ``/rest/auth``. The ESFT POST itself
  **always** uses the Windows session — ESFT does not accept HSDes tokens.

``.env`` lookup order (first hit per key wins, real env still wins):
  1. ``hsdes-plugin/.env``
  2. repo root ``.env``
  3. current working directory ``.env``

Field order (do not reorder — SPA-verified)
-------------------------------------------
``AppFileID``, ``FileSize``, ``FilePartOffset``, ``CaseID``, ``Comment``,
``ExtendedAttributes``, ``EffectiveDate``, ``ExpirationDate``, ``file``.

``EffectiveDate`` and ``ExpirationDate`` are mandatory and the SPA sends both
with the same value (today, local TZ offset, ``yyyy-MM-ddTHH:mm:sszzz``,
no fractional seconds, no UTC ``Z``).

Examples
--------
Dry-run (resolve caseid only, no POST)::

    python hsdes_upload_ips.py 22015171853 C:\\tmp\\foo.txt -d "Test upload" --dry-run

Live upload, internal visibility::

    python hsdes_upload_ips.py 22015171853 C:\\tmp\\foo.txt -d "Test" -v internal

Output is a single JSON object on stdout; progress goes to stderr.
"""

from __future__ import annotations

import argparse
import json
import os
import re
import sys
import uuid
from datetime import datetime
from pathlib import Path
from typing import Optional

import requests
import urllib3

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


HSDES_API_DEFAULT = "https://hsdes-api.intel.com/rest"
HSDES_API_TOKEN = "https://hsdes-api.intel.com/rest/auth"

VISIBILITY_TOKEN = {
    "public": "Public_to_Customers",
    "internal": "Private_to_Intel",
    "partner": "Private_to_Partner",
}
VISIBILITY_JSON = {
    "Public_to_Customers": '{"visibility":"Public to Customers"}',
    "Private_to_Intel": '{"visibility":"Private to Intel"}',
    "Private_to_Partner": '{"visibility":"Private to Partner"}',
}

LINK_RE = re.compile(
    r'href="https://(esft(?:-int)?\.intel\.com)/sftipsupload/index\.html\?'
    r'[^"]*?application=IPS_SFT'
    r'[^"]*?caseid=([0-9a-zA-Z]{15,18})'
    r'[^"]*?visibility=([A-Za-z_]+)'
    r'[^"]*?"'
)


def _eprint(*args, **kwargs) -> None:
    print(*args, file=sys.stderr, **kwargs)


def _now_local_iso() -> str:
    """SPA-format timestamp: ``2026-04-29T13:50:05+08:00`` (no millis, with colon in offset)."""
    s = datetime.now().astimezone().strftime("%Y-%m-%dT%H:%M:%S%z")
    return s[:-2] + ":" + s[-2:]


_DOTENV_LOADED = False


def _load_dotenv() -> None:
    """Mirror hsdes_auth.ps1: load HSDES_USERNAME / HSDES_TOKEN from .env files.

    Lookup order (first hit wins per key, existing process env still wins):
      1. ``hsdes-plugin/.env`` (sibling of scripts/)
      2. repo root ``.env``
      3. current working directory ``.env``
    """
    global _DOTENV_LOADED
    if _DOTENV_LOADED:
        return
    _DOTENV_LOADED = True

    here = Path(__file__).resolve().parent
    candidates = [here.parent / ".env", here.parent.parent / ".env", Path.cwd() / ".env"]
    seen: set[str] = set()
    pat = re.compile(r"^(?:export\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*)$")

    for candidate in candidates:
        try:
            resolved = str(candidate.resolve())
        except OSError:
            continue
        if resolved in seen or not candidate.is_file():
            continue
        seen.add(resolved)
        for raw in candidate.read_text(encoding="utf-8", errors="replace").splitlines():
            line = raw.strip()
            if not line or line.startswith("#"):
                continue
            m = pat.match(line)
            if not m:
                continue
            key, value = m.group(1), m.group(2).strip()
            if (value.startswith('"') and value.endswith('"')) or (
                value.startswith("'") and value.endswith("'")
            ):
                value = value[1:-1]
            else:
                hash_split = re.match(r"^(.*?)\s+#", value)
                if hash_split:
                    value = hash_split.group(1).rstrip()
            os.environ.setdefault(key, value)


def _build_auth():
    """Return the auth object for HSDes calls.

    Uses HTTP Basic with HSDES_USERNAME / HSDES_TOKEN if both are set,
    otherwise falls back to Windows NTLM / Kerberos via requests_negotiate_sspi.
    Reads .env files first (same lookup order as hsdes_auth.ps1).
    """
    _load_dotenv()
    username = os.environ.get("HSDES_USERNAME", "").strip()
    token = os.environ.get("HSDES_TOKEN", "").strip()
    if username and token:
        return requests.auth.HTTPBasicAuth(username, token), HSDES_API_TOKEN, "token"
    try:
        from requests_negotiate_sspi import HttpNegotiateAuth
    except ImportError as e:
        raise RuntimeError(
            "requests_negotiate_sspi not installed. "
            "Run: pip install requests-negotiate-sspi"
        ) from e
    return HttpNegotiateAuth(), HSDES_API_DEFAULT, "default-credentials"


def _esft_auth():
    """ESFT POST always uses Windows session, regardless of HSDES_TOKEN."""
    try:
        from requests_negotiate_sspi import HttpNegotiateAuth
    except ImportError as e:
        raise RuntimeError(
            "requests_negotiate_sspi not installed. "
            "Run: pip install requests-negotiate-sspi"
        ) from e
    return HttpNegotiateAuth()


def fetch_upload_link_xml(article_id: str, timeout: int = 30) -> str:
    """Fetch ``server_platf_ae.bug.upload_attach_to_ips`` XML blob for an article.

    :param article_id: numeric HSDes article ID
    :param timeout: HTTP timeout in seconds
    :returns: raw XML / HTML fragment containing the ``<a>`` upload links
    :raises RuntimeError: when the field is empty (article has no IPS case)
    """
    auth, base, mode = _build_auth()
    _eprint(f"  [auth: {mode}]")
    url = f"{base}/article/{article_id}?fields=server_platf_ae.bug.upload_attach_to_ips"
    r = requests.get(
        url,
        auth=auth,
        headers={"Accept": "application/json"},
        timeout=timeout,
        verify=False,
        proxies={"http": None, "https": None},
    )
    r.raise_for_status()
    payload = r.json()
    data = payload.get("data") or []
    if not data:
        raise RuntimeError(f"Article {article_id} returned no data.")
    xml_blob = data[0].get("server_platf_ae.bug.upload_attach_to_ips") or ""
    if not xml_blob.strip():
        raise RuntimeError(
            f"Article {article_id} has no upload_attach_to_ips link "
            "(no IPS case associated)."
        )
    return xml_blob


def pick_link(xml_blob: str, visibility: str) -> dict:
    """Pick one ``<a href>`` link from the upload_attach_to_ips XML blob.

    :param xml_blob: raw value of the ``upload_attach_to_ips`` field
    :param visibility: ``auto`` / ``public`` / ``internal`` / ``partner``
    :returns: dict with ``host``, ``case_id``, ``visibility_token``
    :raises RuntimeError: when no matching link is found
    """
    matches = LINK_RE.findall(xml_blob)
    if not matches:
        raise RuntimeError(
            f"No IPS_SFT upload links in upload_attach_to_ips. Raw: {xml_blob[:300]}"
        )
    candidates = [{"host": h, "case_id": c, "visibility_token": v} for h, c, v in matches]
    if visibility == "auto":
        return candidates[0]
    want = VISIBILITY_TOKEN[visibility]
    for c in candidates:
        if c["visibility_token"] == want:
            return c
    available = ", ".join(c["visibility_token"] for c in candidates)
    raise RuntimeError(f"No visibility={want} link found. Available: {available}")


def upload_chunks(
    *,
    host: str,
    case_id: str,
    visibility_token: str,
    file_path: Path,
    description: str,
    chunk_size: int,
    timeout: int,
) -> dict:
    """POST every chunk to ESFT in SPA-verified field order.

    :param host: ``esft-int.intel.com`` (production) or ``esft.intel.com``
    :param case_id: 15-18 char SFDC case ID extracted from upload link
    :param visibility_token: ``Public_to_Customers`` / ``Private_to_Intel`` / ``Private_to_Partner``
    :param file_path: local file to upload
    :param description: maps to ESFT ``Comment`` field
    :param chunk_size: bytes per chunk (SPA uses 10 MB = 10485760)
    :param timeout: per-chunk HTTP timeout in seconds
    :returns: summary dict with chunk count and final HTTP status
    """
    extended = VISIBILITY_JSON[visibility_token]
    file_size = file_path.stat().st_size
    file_name = file_path.name
    app_file_id = str(uuid.uuid4())
    upload_uri = f"https://{host}/sftservices/upload/IPS_SFT/"

    chunk_count = max(1, -(-file_size // chunk_size))  # ceildiv, 0-byte file = 1 chunk
    _eprint(f"[3/3] Uploading {chunk_count} chunk(s) -> {upload_uri}")

    # Use a Session with a primer GET so the NTLM 401-challenge handshake
    # completes on a body-less request. Without this, the multipart POST's
    # body stream is consumed on the unauthenticated first try, requests
    # cannot rewind it for the authenticated retry, and ESFT receives a
    # truncated body whose file binary lands at the wrong byte offset —
    # surfacing as HTTP 500 ErrorCode 6006 "file position is not same as
    # filepartoffset". The GET to the SPA URL primes Negotiate auth on the
    # connection so the chunk POST goes through on its first attempt.
    s = requests.Session()
    s.auth = _esft_auth()
    s.verify = False
    s.proxies = {"http": None, "https": None}
    primer_url = f"https://{host}/sftipsupload/index.html"
    try:
        s.get(primer_url, timeout=timeout)
    except Exception as e:
        _eprint(f"  [warn] primer GET failed (continuing): {e}")

    last_status = 0
    last_body = ""

    with file_path.open("rb") as fh:
        offset = 0
        for idx in range(1, chunk_count + 1):
            chunk = fh.read(chunk_size)
            this_size = len(chunk)
            now = _now_local_iso()
            # Field order is SPA-verified (patched XHR capture). Do NOT reorder.
            data = [
                ("AppFileID", app_file_id),
                ("FileSize", str(file_size)),
                ("FilePartOffset", str(offset)),
                ("CaseID", case_id),
                ("Comment", description),
                ("ExtendedAttributes", extended),
                ("EffectiveDate", now),
                ("ExpirationDate", now),
            ]
            files = [("file", (file_name, chunk, "application/octet-stream"))]
            pct = (offset + this_size) * 100.0 / file_size if file_size else 100.0
            _eprint(f"  chunk {idx}/{chunk_count}  offset={offset}  bytes={this_size}  ({pct:.1f}%)")

            r = s.post(upload_uri, data=data, files=files, timeout=timeout)
            last_status = r.status_code
            last_body = r.text
            if not r.ok:
                raise RuntimeError(
                    f"Chunk {idx} POST failed: HTTP {last_status}\nResponse: {last_body[:1000]}"
                )
            offset += this_size

    # Verify ESFT registered the upload by calling the SPA's per-file detail
    # endpoint. ESFT moves files through pending -> ready before HSDes mirror
    # picks them up; this confirms upload completed and surfaces sftPath +
    # status without making the caller wait on the mirror.
    verify: dict = {}
    detail_url = f"https://{host}/sftservices/getfileuploaddetail/IPS_SFT/?AppFileID={app_file_id}"
    try:
        rd = s.get(detail_url, timeout=timeout)
        if rd.ok:
            outer = rd.json().get("GetFileUploadDetailResult", {}) or {}
            inner = json.loads(outer.get("FileDetails", "{}") or "{}")
            verify = {
                "status": inner.get("status", ""),
                "sft_path": inner.get("sftPath", ""),
                "upload_status_date": inner.get("uploadStatusDate", ""),
                "size_in_bytes": inner.get("sizeInBytes", 0),
                "category": inner.get("category", ""),
                "extended": inner.get("extended", {}),
            }
        else:
            verify = {"error": f"HTTP {rd.status_code}", "body": rd.text[:300]}
    except Exception as e:
        verify = {"error": str(e)}

    return {
        "host": host,
        "case_id": case_id,
        "visibility": visibility_token,
        "file_name": file_name,
        "file_size": file_size,
        "app_file_id": app_file_id,
        "chunks_uploaded": chunk_count,
        "final_status": last_status,
        "response_body": last_body,
        "verify": verify,
    }


def parse_args() -> argparse.Namespace:
    """Parse command-line arguments.

    Positional:
        article_id   numeric HSDes article ID (e.g. ``22015171853``)
        file_path    local file to upload

    Required flags:
        -d / --description   text shown as ``Description`` in the ESFT UI;
                             written to the multipart ``Comment`` field

    Optional flags:
        -v / --visibility    auto (default) | public | internal | partner
                             ``auto`` picks the first ``<a>`` link in the
                             article (typically ``Public_to_Customers``)
        --chunk-mb           chunk size in MB (default 10, mirrors SPA)
        --timeout            per-chunk HTTP timeout in seconds (default 300)
        --dry-run            resolve caseid + print plan, skip the POST
    """
    p = argparse.ArgumentParser(
        prog="hsdes_upload_ips.py",
        description="Upload a file to ESFT / IPS for an HSDes article (no browser tab).",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=(
            "Auth: NTLM/Kerberos via requests_negotiate_sspi by default. "
            "Set HSDES_USERNAME + HSDES_TOKEN to use HSDes Basic auth for the "
            "article fetch (the ESFT POST always uses the Windows session)."
        ),
    )
    p.add_argument("article_id", help="numeric HSDes article ID")
    p.add_argument("file_path", type=Path, help="local file to upload")
    p.add_argument(
        "-d", "--description",
        required=True,
        help='text for the ESFT "Description" field (multipart Comment)',
    )
    p.add_argument(
        "-v", "--visibility",
        choices=("auto", "public", "internal", "partner"),
        default="auto",
        help="which <a> link to pick from upload_attach_to_ips (default: auto)",
    )
    p.add_argument(
        "--chunk-mb", type=int, default=10,
        help="chunk size in megabytes (default: 10, matches SPA)",
    )
    p.add_argument(
        "--timeout", type=int, default=300,
        help="per-chunk HTTP timeout in seconds (default: 300)",
    )
    p.add_argument(
        "--dry-run", action="store_true",
        help="resolve caseid + print plan, skip the POST",
    )
    return p.parse_args()


def main() -> int:
    args = parse_args()

    if not re.fullmatch(r"\d+", args.article_id):
        _eprint(f"error: article_id must be numeric, got: {args.article_id}")
        return 2
    if not args.file_path.is_file():
        _eprint(f"error: file not found: {args.file_path}")
        return 2
    if not args.description.strip():
        _eprint("error: --description is required (goes into ESFT Comment field)")
        return 2

    chunk_size = args.chunk_mb * 1024 * 1024

    try:
        _eprint(f"[1/3] Resolving caseid from HSDes article {args.article_id}")
        xml_blob = fetch_upload_link_xml(args.article_id, timeout=args.timeout)
        chosen = pick_link(xml_blob, args.visibility)
        _eprint(f"  Host: {chosen['host']}")
        _eprint(f"  CaseID: {chosen['case_id']}")
        _eprint(f"  Visibility: {chosen['visibility_token']}")

        file_size = args.file_path.stat().st_size
        chunk_count = max(1, -(-file_size // chunk_size))
        _eprint(f"[2/3] File: {args.file_path.name} ({file_size} bytes), "
                f"{chunk_count} x {args.chunk_mb} MB")

        if args.dry_run:
            _eprint("[dry-run] Skipping POST.")
            result = {
                "success": True,
                "dry_run": True,
                "article_id": args.article_id,
                "host": chosen["host"],
                "case_id": chosen["case_id"],
                "visibility": chosen["visibility_token"],
                "extended": VISIBILITY_JSON[chosen["visibility_token"]],
                "file_name": args.file_path.name,
                "file_size": file_size,
                "chunk_count": chunk_count,
                "chunk_size": chunk_size,
            }
            print(json.dumps(result, indent=2))
            return 0

        summary = upload_chunks(
            host=chosen["host"],
            case_id=chosen["case_id"],
            visibility_token=chosen["visibility_token"],
            file_path=args.file_path,
            description=args.description,
            chunk_size=chunk_size,
            timeout=args.timeout,
        )
        result = {
            "success": 200 <= summary["final_status"] < 300,
            "article_id": args.article_id,
            **summary,
        }
        print(json.dumps(result, indent=2))
        return 0 if result["success"] else 1

    except Exception as e:
        _eprint(f"error: {e}")
        return 1


if __name__ == "__main__":
    sys.exit(main())
