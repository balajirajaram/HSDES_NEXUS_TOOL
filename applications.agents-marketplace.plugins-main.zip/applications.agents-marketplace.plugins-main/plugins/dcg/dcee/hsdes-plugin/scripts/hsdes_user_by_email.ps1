<# HSDes User Lookup by Email
.SYNOPSIS
    Get user information by email address
.PARAMETER Email
    The Intel email address (e.g., henry.y.sun@intel.com)
.EXAMPLE
    .\hsdes_user_by_email.ps1 -Email "henry.y.sun@intel.com"
.NOTES
    Requires PowerShell 7+ (pwsh)
#>
#Requires -Version 7
param(
    [Parameter(Mandatory=$true)]
    [string]$Email
)

. "$PSScriptRoot/hsdes_auth.ps1"

$requestPath = "user/byemailId?emailId=$Email"
$params = New-HsdesRequestParams -Path $requestPath -Method 'Get' -ContentType 'application/json'

try {
    $response = Invoke-RestMethod @params

    # Check if user found
    if ($response.data -and $response.data.Count -gt 0) {
        $user = $response.data[0]

        Write-Output "=== USER INFO ==="
        Write-Output "IDSID: $($user.'sys_user.idsid')"
        Write-Output "Name: $($user.'sys_user.name')"
        Write-Output "Email: $($user.'sys_user.email')"
        Write-Output "WWID: $($user.'sys_user.wwid')"
        Write-Output "Org: $($user.'sys_user.orgunit_description')"
        Write-Output "Group: $($user.'sys_user.group')"
        Write-Output "Site: $($user.'sys_user.site')"
        Write-Output "=== RESULT ==="

        return $user | ConvertTo-Json -Compress
    }
    else {
        Write-Error "User not found for email: $Email"
        throw
    }
}
catch {
    Write-Error "Failed to lookup user by email: $_"
    throw
}
