<# HSDes User Information with Manager Chain
.SYNOPSIS
    Get user info + manager chain, optionally resolve manager names/emails
.PARAMETER Idsid
    The Intel IDSID (e.g., hsun21)
.PARAMETER ResolveChain
    If set, also fetch MGL1/2/3's name and email in parallel
.EXAMPLE
    .\hsdes_user_info.ps1 -Idsid "hsun21"
    .\hsdes_user_info.ps1 -Idsid "hsun21" -ResolveChain
.NOTES
    Requires PowerShell 7+ (pwsh)
#>
#Requires -Version 7
param(
    [Parameter(Mandatory=$true)]
    [string]$Idsid,
    [switch]$ResolveChain
)

. "$PSScriptRoot/hsdes_auth.ps1"

function Invoke-HsdesParallelRequests {
    param([array]$Requests)

    # Each request: @{ Key=<string>; Params=<hashtable for Invoke-RestMethod splat> }
    # Returns array of pscustomobjects: { Key; Data; Error }
    return $Requests | ForEach-Object -Parallel {
        $item = $_
        $p = $item.Params
        $lastErr = $null
        for ($attempt = 0; $attempt -lt 2; $attempt++) {
            try {
                $resp = Invoke-RestMethod @p
                return [pscustomobject]@{ Key = $item.Key; Data = $resp; Error = $null }
            } catch {
                $lastErr = $_.Exception.Message
                Start-Sleep -Milliseconds 500
            }
        }
        return [pscustomobject]@{ Key = $item.Key; Data = $null; Error = $lastErr }
    } -ThrottleLimit 8
}

function Build-UserLookupRequests {
    param([string]$LookupId, [string]$KeyPrefix)
    $userParams = New-HsdesRequestParams -Path "user/$LookupId" -Method 'Get' -ContentType 'application/json'
    $managerParams = New-HsdesRequestParams -Path "user/${LookupId}?expand=manager" -Method 'Get' -ContentType 'application/json'
    return @(
        [pscustomobject]@{ Key = "${KeyPrefix}:user";    Params = $userParams },
        [pscustomobject]@{ Key = "${KeyPrefix}:manager"; Params = $managerParams }
    )
}

function Parse-UserRecord {
    param([string]$LookupId, $UserResp, $ManagerResp)
    if (-not $UserResp -or -not $UserResp.data -or $UserResp.data.Count -eq 0) { return $null }
    $u = $UserResp.data[0]
    $m = if ($ManagerResp -and $ManagerResp.manager) { $ManagerResp.manager[0] } else { $null }
    $rec = [ordered]@{
        idsid = $LookupId
        name  = $u.'sys_user.name'
        email = $u.'sys_user.email'
        wwid  = $u.'sys_user.wwid'
        org   = $u.'sys_user.orgunit_description'
        group = $u.'sys_user.group'
        site  = $u.'sys_user.site'
    }
    if ($m) {
        $rec.manager_mgl1 = $m.mgl1
        $rec.manager_mgl2 = $m.mgl2
        $rec.manager_mgl3 = $m.mgl3
    }
    return [pscustomobject]$rec
}

try {
    # Phase 1: primary user (2 parallel REST calls)
    $phase1Reqs = Build-UserLookupRequests -LookupId $Idsid -KeyPrefix 'primary'
    $phase1Resp = Invoke-HsdesParallelRequests -Requests $phase1Reqs
    $byKey = @{}
    foreach ($r in $phase1Resp) { $byKey[$r.Key] = $r }

    if ($byKey['primary:user'].Error) {
        Write-Error "User lookup failed: $($byKey['primary:user'].Error)"
        throw
    }

    $primary = Parse-UserRecord -LookupId $Idsid -UserResp $byKey['primary:user'].Data -ManagerResp $byKey['primary:manager'].Data
    if (-not $primary) {
        Write-Error "User not found: $Idsid"
        throw
    }

    # Phase 2: resolve manager chain (optional, 6 parallel REST calls)
    $chainRecords = @()
    if ($ResolveChain) {
        $levels = @()
        if ($primary.manager_mgl1) { $levels += [pscustomobject]@{ Level='mgl1'; Id=$primary.manager_mgl1 } }
        if ($primary.manager_mgl2) { $levels += [pscustomobject]@{ Level='mgl2'; Id=$primary.manager_mgl2 } }
        if ($primary.manager_mgl3) { $levels += [pscustomobject]@{ Level='mgl3'; Id=$primary.manager_mgl3 } }

        if ($levels.Count -gt 0) {
            $phase2Reqs = @()
            foreach ($lvl in $levels) {
                $phase2Reqs += Build-UserLookupRequests -LookupId $lvl.Id -KeyPrefix $lvl.Level
            }
            $phase2Resp = Invoke-HsdesParallelRequests -Requests $phase2Reqs
            $byKey2 = @{}
            foreach ($r in $phase2Resp) { $byKey2[$r.Key] = $r }

            foreach ($lvl in $levels) {
                $uResp = $byKey2["$($lvl.Level):user"].Data
                $mResp = $byKey2["$($lvl.Level):manager"].Data
                $rec = Parse-UserRecord -LookupId $lvl.Id -UserResp $uResp -ManagerResp $mResp
                if (-not $rec) {
                    # Fallback: still include the IDSID even if lookup failed
                    $rec = [pscustomobject]@{ idsid = $lvl.Id }
                }
                $withLevel = [ordered]@{ level = $lvl.Level }
                foreach ($prop in $rec.PSObject.Properties) { $withLevel[$prop.Name] = $prop.Value }
                $chainRecords += [pscustomobject]$withLevel
            }
        }
    }

    # Formatted output
    Write-Output "=== USER INFO ==="
    Write-Output "IDSID: $($primary.idsid)"
    Write-Output "Name: $($primary.name)"
    Write-Output "Email: $($primary.email)"
    Write-Output "WWID: $($primary.wwid)"
    Write-Output "Org: $($primary.org)"
    Write-Output "Group: $($primary.group)"
    Write-Output "Site: $($primary.site)"

    if ($primary.manager_mgl1 -or $primary.manager_mgl2 -or $primary.manager_mgl3) {
        Write-Output ""
        Write-Output "=== MANAGER CHAIN ==="
        if ($chainRecords.Count -gt 0) {
            foreach ($c in $chainRecords) {
                $label = switch ($c.level) {
                    'mgl1' { 'Direct Manager (MGL1)' }
                    'mgl2' { 'MGL2' }
                    'mgl3' { 'MGL3' }
                    default { $c.level }
                }
                $name  = if ($c.PSObject.Properties.Name -contains 'name')  { $c.name }  else { '' }
                $email = if ($c.PSObject.Properties.Name -contains 'email') { $c.email } else { '' }
                Write-Output "${label}: $($c.idsid) - $name <$email>"
            }
        } else {
            Write-Output "Direct Manager (MGL1): $($primary.manager_mgl1)"
            Write-Output "MGL2: $($primary.manager_mgl2)"
            Write-Output "MGL3: $($primary.manager_mgl3)"
        }
    }

    Write-Output "=== RESULT ==="
    $result = [ordered]@{}
    foreach ($prop in $primary.PSObject.Properties) { $result[$prop.Name] = $prop.Value }
    if ($chainRecords.Count -gt 0) {
        $result['chain'] = $chainRecords
    }
    $result | ConvertTo-Json -Compress -Depth 5
}
catch {
    Write-Error "Failed to get user info: $_"
    throw
}
