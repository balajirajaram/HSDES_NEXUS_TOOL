<# Install Intel Root Certificates
.SYNOPSIS
    Download and install Intel root certificates to trusted store
.DESCRIPTION
    Downloads Intel SHA2 and SHA384 root certificates and installs them
    to the current user's trusted root certificate store.
    This eliminates the need for -SkipCertificateCheck.
.EXAMPLE
    .\install_intel_certs.ps1
.NOTES
    Requires PowerShell 7+ (pwsh)
    Does NOT require admin privileges (installs to CurrentUser store)
#>
#Requires -Version 7

$CERT_URLS = @(
    @{
        Name = 'IntelSHA2RootChain'
        Url  = 'http://certificates.intel.com/repository/certificates/IntelSHA2RootChain-Base64.zip'
    },
    @{
        Name = 'IntelSHA384TrustChain'
        Url  = 'https://certificates.intel.com/repository/certificates/TrustBundles/IntelSHA384TrustChain-Base64.zip'
    }
)

$TEMP_DIR = Join-Path $env:TEMP "intel_certs"
$installed = 0
$failed = 0

Write-Host "`n=== Intel Certificate Installer ===" -ForegroundColor Cyan
Write-Host "This will install Intel root certificates to your trusted store.`n"

# Create temp directory
if (Test-Path $TEMP_DIR) {
    Remove-Item $TEMP_DIR -Recurse -Force
}
New-Item -ItemType Directory -Path $TEMP_DIR | Out-Null

# Open certificate store
$store = New-Object System.Security.Cryptography.X509Certificates.X509Store("Root", "CurrentUser")
$store.Open("ReadWrite")

try {
    foreach ($cert in $CERT_URLS) {
        Write-Host "Processing: $($cert.Name)..." -ForegroundColor Yellow

        try {
            # Download certificate bundle
            $zipPath = Join-Path $TEMP_DIR "$($cert.Name).zip"
            Write-Host "  Downloading from: $($cert.Url)"

            $downloadParams = @{
                Uri     = $cert.Url
                OutFile = $zipPath
            }

            # Skip cert check for the download itself (chicken-and-egg problem)
            if ($cert.Url -like "https://*") {
                $downloadParams['SkipCertificateCheck'] = $true
            }

            Invoke-WebRequest @downloadParams

            # Extract zip
            $extractPath = Join-Path $TEMP_DIR $cert.Name
            Expand-Archive -Path $zipPath -DestinationPath $extractPath -Force

            # Install all .cer and .crt files
            $certFiles = Get-ChildItem -Path $extractPath -Include @('*.cer', '*.crt', '*.pem') -Recurse

            foreach ($certFile in $certFiles) {
                Write-Host "  Installing: $($certFile.Name)"

                try {
                    # Use constructor instead of Import() for cross-platform compatibility
                    $certificate = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2($certFile.FullName)

                    # Check if already installed
                    $existing = $store.Certificates | Where-Object { $_.Thumbprint -eq $certificate.Thumbprint }
                    if ($existing) {
                        Write-Host "    Already installed (thumbprint: $($certificate.Thumbprint))" -ForegroundColor DarkGray
                    } else {
                        $store.Add($certificate)
                        Write-Host "    Installed successfully (thumbprint: $($certificate.Thumbprint))" -ForegroundColor Green
                        $installed++
                    }
                } catch {
                    Write-Warning "    Failed to install $($certFile.Name): $_"
                    $failed++
                }
            }

            Write-Host "  Complete: $($cert.Name)`n" -ForegroundColor Green

        } catch {
            Write-Warning "Failed to process $($cert.Name): $_"
            $failed++
        }
    }
} finally {
    $store.Close()

    # Cleanup
    if (Test-Path $TEMP_DIR) {
        Remove-Item $TEMP_DIR -Recurse -Force
    }
}

Write-Host "`n=== Installation Summary ===" -ForegroundColor Cyan
Write-Host "Certificates installed: $installed" -ForegroundColor Green
if ($failed -gt 0) {
    Write-Host "Failed: $failed" -ForegroundColor Red
}

Write-Host "`nYou can now remove '-SkipCertificateCheck' from HSDes scripts." -ForegroundColor Yellow
Write-Host "Restart your terminal/IDE for changes to take effect.`n"
