# Test SSL without SkipCertificateCheck
. "$PSScriptRoot/hsdes_auth.ps1"

$requestPath = 'query/execution/eql?start_at=1&max_results=1'
$body = @{ eql = 'SELECT id WHERE tenant = ''server_platf_ae'' AND subject = ''bug'' SORTBY id DESC' } | ConvertTo-Json
$params = New-HsdesRequestParams -Path $requestPath -Method 'Post' -ContentType 'application/json' -Body $body

try {
    $response = Invoke-RestMethod @params
    Write-Host 'SUCCESS: SSL verification works with installed certificates!' -ForegroundColor Green
    Write-Host "Result count: $($response.data.Count)"
    exit 0
} catch {
    Write-Host 'FAILED: SSL verification failed' -ForegroundColor Red
    Write-Host "Error: $_"
    exit 1
}
