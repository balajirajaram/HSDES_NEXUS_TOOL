---
name: hsdes
description: Query Intel HSDes bug tracking system using EQL. Use when user asks about HSDes queries, bug searches, customer issues, platform sightings, IRF tracking, or needs to find/analyze bugs by customer, platform, priority, or component. Supports EQL query generation, API execution, and result analysis.
---

# HSDes Query Skill

Generate and execute HSDes EQL queries to search articles.

## Quick Reference

**API Endpoint:** `https://hsdes-api.intel.com/rest/query/execution/eql?start_at=1&max_results=10000`

**Article URL format (for links in emails, reports, etc.):**
```
https://hsdes.intel.com/appstore/article-one/#/article/{id}
```
> ⚠️ Do NOT use `community/#/{id}` — that format is incorrect. Always use `article-one/#/article/{id}`.

**Saved Query URL format:**
```
https://hsdes.intel.com/appstore/community/#/query?queryId={queryId}
```
> Example: `https://hsdes.intel.com/appstore/community/#/query?queryId=15013555803`

**Critical EQL Rules:**
- **EQL must be a single line** — NO newlines (`\n`) in the `eql` parameter. Write the entire query on one line.
- Operators MUST be uppercase: `CONTAINS`, `EQUALS`, `IS_NOT_EMPTY`, `SORTBY`
- Strings MUST use single quotes: `'google'`
- SORTBY fields MUST be in SELECT clause

## Basic Query Template

```eql
SELECT id, title, owner, server_platf_ae.bug.customer_company, submitted_date, release, status, priority WHERE tenant = 'server_platf_ae' AND subject = 'bug' AND <conditions> SORTBY submitted_date DESC
```

## Execution

Queries are executed via MCP tools:
- **hsdes_query** — Execute EQL queries
- **hsdes_get_article** — Get article by ID with API-level field selection. Default is safe/basic fields; optional flags allow `description` and `ext_cust_blog_hist`.
- **hsdes_get_article_context** — One-call source-separated wrapper. Recommended when user wants "read again" with explicit separation of basic fields, description, customer history, and comments.
- **hsdes_get_comments** — Get comment children (owner, submitted_date, description). Use for discussion thread/comments only.
- **hsdes_get_links** — Get related/promoted links for an article
- **hsdes_get_saved_query** — Execute saved queries by ID

## Article Read Workflow (Source-Separated)

When user asks to "read again", "summarize timeline", or asks about mismatches between description/history/comments:

Preferred:

1. **One-call source-separated read**  
   `hsdes_get_article_context(article_id='<id>', include_description=True, include_customer_history=True, include_comments=True)`

Fallback (manual split), follow this order:

2. **Basic article metadata**  
   `hsdes_get_article(article_id='<id>')`
3. **Description only**  
   `hsdes_get_article(article_id='<id>', include_description=True, fields=['id','title','description'])`
4. **Customer history only** (`ext_cust_blog_hist`)  
   `hsdes_get_article(article_id='<id>', include_customer_history=True, fields=['id','server_platf_ae.bug.ext_cust_blog_hist'])`
5. **Comments only**  
   `hsdes_get_comments(article_id='<id>')`

Rules:
- Never treat `ext_cust_blog_hist` as `comments`.
- Never assume `comments` contains customer mail thread.
- Always label extracted facts by source: `description`, `ext_cust_blog_hist`, or `comment#N`.

## Writing Comments (`hsdes_update_article`)

HSDes renders the `comments` field as **HTML**, similar to Outlook —
Markdown is NOT supported, and **plain-text whitespace and line breaks
are collapsed on render**. Sending plain text with indented code, tables,
or numbered lists produces unformatted prose.

Rules:
- One-paragraph conversational replies: plain prose is fine.
- Anything with code, indentation, lists, or multiple paragraphs: write
  HTML.
  - `<br>` between paragraphs.
  - `<pre>...</pre>` for code/traces (preserves monospace + whitespace +
    newlines). Escape `<`, `>`, `&` as `&lt;`, `&gt;`, `&amp;` inside.
  - `<ul><li>...</li></ul>` for bullets; `<ol>` for numbered lists.
  - `<b>`, `<i>`, `<code>`, `<h2>`, `<table>`, `<blockquote>` all render.
- Never paste Markdown fences (` ``` `), asterisks, or backticks for
  emphasis — they show as literal characters.
- For screenshots, use the `comments_image_paths=[...]` arg instead of
  base64-encoding by hand.

Template for a code-heavy comment:
```html
Hi @Name —<br><br>

Some prose context.<br><br>

<pre>
    code_line_1;
    if (x &lt; y) { ... }
</pre>

More prose.<br><br>

Thanks,<br>
&lt;your signoff&gt;
```

Always dry-run first (`dry_run=True`, the default), show the result to
the user, get explicit confirmation, then re-call with `dry_run=False`.

## Common Mappings (Quick)

**Customers / Priority / Status** (all tenants):

| User Says | EQL Value |
|-----------|-----------|
| GGL | `'google'` |
| P1/hotlist | `'p1-showstopper'` |
| closed | `status = 'complete'` |
| IPS | `server_platf_ae.bug.ext_source_id` |
| IPS attachment file URL | `server_platf_ae.bug.ext_attach_url` | Contains URL of file attached by customer via IPS portal (e.g. crashdump, log file). Use `CONTAINS 'crashdump'` or `CONTAINS '.bin'` to filter. |
| CCB, POR | `subject = 'feature'` → use `server_platf.feature` |

**Platform → release filter by tenant** (CONTAINS is case-insensitive):

| Tenant | Platform | EQL Filter |
|--------|----------|-----------|
| `server_platf_ae.bug` / `server_platf.bug` / `server_platf.feature` | DMR | `CONTAINS 'DMR'` |
| | GNR | `CONTAINS 'GNR'` |
| | SRF | `CONTAINS 'SRF'` |
| | CWF | `CONTAINS 'CWF'` |
| | All OKS | `CONTAINS 'Oak Stream'` |
| | All BHS | `CONTAINS 'Birch Stream'` |
| | EMR | `CONTAINS 'EMR'` |
| `central_firmware.bug` / `central_firmware.feature` | OKS+DMR | `CONTAINS 'oakstream_diamondrapids'` |
| | BHS+GNR | `CONTAINS 'graniterapids'` |
| | All OKS | `CONTAINS 'oakstream'` |
| | All BHS | `CONTAINS 'birchstream'` |
| `sighting_central.sighting` | DMR | `CONTAINS 'dmr'` |
| | GNR | `CONTAINS 'gnr'` |
| | CWF | `CONTAINS 'cwf'` |
| | SRF | `CONTAINS 'srf'` |

## Query Templates

For complex IRF queries, use the `hsdes_get_query_template` tool:
- `hsdes_get_query_template('firmware-irf')` - OKS+BHS BIOS ASIA IRF
- `hsdes_get_query_template('platform-irf')` - Platform IRF All Geos
- `hsdes_get_query_template('hsio-irf')`     - HSIO BHS/OKS PCIe/CXL APAC
- `hsdes_get_query_template('memory-irf')`   - Memory BHS/OKS APAC
- `hsdes_get_query_template('dmr-ptp')` - DMR PTP_SoC sightings
- `hsdes_get_query_template('dmr-cfm')` - DMR central_firmware bugs

**Known IRF saved query IDs — call `hsdes_get_query_template` BEFORE displaying results:**
- `15013555803` → `platform-irf` (includes `irf_notes` field)
- `15018339809` → `firmware-irf` (includes `irf_notes` field)
- `15017467796` → `hsio-irf`
- `15015935984` → `memory-irf`

## Example: IPS Crashdump Attachment Search

Find Google bugs with crashdump files uploaded via IPS portal:

```eql
SELECT id, title, owner, status, priority, submitted_date, release, server_platf_ae.bug.ext_attach_url WHERE tenant = 'server_platf_ae' AND subject = 'bug' AND server_platf_ae.bug.customer_company = 'google' AND server_platf_ae.bug.ext_attach_url CONTAINS 'crashdump' SORTBY submitted_date DESC
```

For field mappings and EQL syntax, see MCP Resources (hsdes://field-mappings, hsdes://eql-syntax).
