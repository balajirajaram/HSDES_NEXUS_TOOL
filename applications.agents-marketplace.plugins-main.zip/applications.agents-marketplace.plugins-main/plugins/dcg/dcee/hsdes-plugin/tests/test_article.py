"""Tests for hsdes_get_article field selection behavior."""
import json
import os
import sys
from unittest.mock import patch

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))


def _call(tool_obj, *args, **kwargs):
    """Call the underlying function of a FastMCP FunctionTool."""
    fn = getattr(tool_obj, "fn", tool_obj)
    return fn(*args, **kwargs)


@patch("mcp_server._run_ps1")
def test_get_article_default_fields(mock_ps1):
    from mcp_server import _ARTICLE_DEFAULT_FIELDS, hsdes_get_article

    mock_ps1.return_value = '{"data":[]}'
    _call(hsdes_get_article, "14027610116")

    mock_ps1.assert_called_once_with(
        "hsdes_get_article.ps1",
        ArticleId="14027610116",
        Fields=_ARTICLE_DEFAULT_FIELDS,
        Format="text",
    )


@patch("mcp_server._run_ps1")
def test_get_article_includes_description_and_customer_history(mock_ps1):
    from mcp_server import _EXT_CUST_BLOG_HIST_FIELD, hsdes_get_article

    mock_ps1.return_value = '{"data":[]}'
    _call(
        hsdes_get_article,
        "14027610116",
        include_description=True,
        include_customer_history=True,
    )

    _, kwargs = mock_ps1.call_args
    assert kwargs["ArticleId"] == "14027610116"
    assert "description" in kwargs["Fields"]
    assert _EXT_CUST_BLOG_HIST_FIELD in kwargs["Fields"]


@patch("mcp_server._run_ps1")
def test_get_article_custom_fields_override_defaults(mock_ps1):
    from mcp_server import hsdes_get_article

    mock_ps1.return_value = '{"data":[]}'
    _call(
        hsdes_get_article,
        "14027610116",
        include_customer_history=True,
        fields=["id", "title", "description", "description"],
    )

    _, kwargs = mock_ps1.call_args
    assert kwargs["Fields"] == "id,title,description,server_platf_ae.bug.ext_cust_blog_hist"


@patch("mcp_server._run_ps1")
def test_get_article_invalid_id(mock_ps1):
    from mcp_server import hsdes_get_article

    result = _call(hsdes_get_article, "not-a-number")
    assert "numeric" in result.lower()
    mock_ps1.assert_not_called()


@patch("mcp_server._enrich_owners", side_effect=lambda x: x)
@patch("mcp_server._run_ps1")
def test_get_article_context_source_separated(mock_ps1, _mock_enrich):
    from mcp_server import hsdes_get_article_context

    def _side_effect(script_name, **kwargs):
        if script_name == "hsdes_get_article.ps1":
            return json.dumps(
                {
                    "data": [
                        {
                            "id": "14027610116",
                            "title": "Case title",
                            "status": "open",
                            "description": "<p>desc</p>",
                            "server_platf_ae.bug.ext_cust_blog_hist": "<p>hist</p>",
                        }
                    ]
                }
            )
        if script_name == "hsdes_get_comments.ps1":
            return json.dumps(
                {
                    "data": [
                        {
                            "id": "9001",
                            "owner": "jdoe (John Doe)",
                            "submitted_date": "2026-04-10",
                            "description": "<p>c1</p>",
                        },
                        {
                            "id": "9002",
                            "owner": "asmith (Alice Smith)",
                            "submitted_date": "2026-04-11",
                            "description": "<p>c2</p>",
                        },
                    ]
                }
            )
        raise AssertionError(f"Unexpected script: {script_name}")

    mock_ps1.side_effect = _side_effect

    result = _call(
        hsdes_get_article_context,
        "14027610116",
        include_description=True,
        include_customer_history=True,
        include_comments=True,
        comment_fields=["id", "owner"],
        max_comments=1,
    )
    parsed = json.loads(result)
    assert parsed["hsd_id"] == "14027610116"
    assert parsed["description"] == "<p>desc</p>"
    assert parsed["ext_cust_blog_hist"] == "<p>hist</p>"
    assert parsed["comments_count"] == 2
    assert parsed["comments_truncated"] == 1
    assert parsed["comments"] == [{"id": "9001", "owner": "jdoe (John Doe)"}]
    assert "description" not in parsed["article_basic"]
    assert "server_platf_ae.bug.ext_cust_blog_hist" not in parsed["article_basic"]


@patch("mcp_server._enrich_owners", side_effect=lambda x: x)
@patch("mcp_server._run_ps1")
def test_get_article_context_basic_only(mock_ps1, _mock_enrich):
    from mcp_server import hsdes_get_article_context

    mock_ps1.return_value = json.dumps(
        {
            "data": [
                {
                    "id": "14027610116",
                    "title": "Case title",
                    "status": "open",
                }
            ]
        }
    )

    result = _call(hsdes_get_article_context, "14027610116")
    parsed = json.loads(result)
    assert parsed["description"] is None
    assert parsed["ext_cust_blog_hist"] is None
    assert parsed["comments"] == []
    assert parsed["comments_count"] == 0

    # Only article endpoint should be called when comments are not requested.
    called_scripts = [c.args[0] for c in mock_ps1.call_args_list]
    assert called_scripts == ["hsdes_get_article.ps1"]


@patch("mcp_server._run_ps1")
def test_update_article_invalid_id(mock_ps1):
    from mcp_server import hsdes_update_article

    result = _call(hsdes_update_article, "not-a-number", comments="hi")
    assert "numeric" in result.lower()
    mock_ps1.assert_not_called()


@patch("mcp_server._run_ps1")
def test_update_article_no_fields(mock_ps1):
    from mcp_server import hsdes_update_article

    result = _call(hsdes_update_article, "22021660584")
    assert "No fields to update" in result
    mock_ps1.assert_not_called()


@patch("mcp_server._run_ps1")
def test_update_article_empty_strings_treated_as_missing(mock_ps1):
    from mcp_server import hsdes_update_article

    result = _call(hsdes_update_article, "22021660584", comments="   ", notify="")
    assert "No fields to update" in result
    mock_ps1.assert_not_called()


@patch("mcp_server._run_ps1")
def test_update_article_dry_run_default_true(mock_ps1):
    from mcp_server import hsdes_update_article

    mock_ps1.return_value = "=== UPDATE SUCCESS ==="
    _call(hsdes_update_article, "22021660584", comments="hello")

    _, kwargs = mock_ps1.call_args
    assert kwargs["ArticleId"] == "22021660584"
    assert kwargs["Comments"] == "hello"
    assert kwargs["DryRun"] == "true"
    assert "Notify" not in kwargs


@patch("mcp_server._run_ps1")
def test_update_article_dry_run_false_when_disabled(mock_ps1):
    from mcp_server import hsdes_update_article

    mock_ps1.return_value = "=== UPDATE SUCCESS ==="
    _call(
        hsdes_update_article,
        "22021660584",
        comments="hello",
        notify="hcheng20,jdoe",
        dry_run=False,
    )

    _, kwargs = mock_ps1.call_args
    assert kwargs["DryRun"] == "false"
    assert kwargs["Comments"] == "hello"
    assert kwargs["Notify"] == "hcheng20,jdoe"


def test_update_article_allowlist_signature():
    """Tool signature must NOT expose writable fields outside the allowlist.

    `article_id` and `comment_id` are addressing parameters, NOT writable
    fields — they identify which record to act on, not what to write to it.
    `dry_run` is a control flag. `comments_image_paths` /
    `ext_cust_blog_rich_image_paths` are transformation inputs (filesystem
    paths → inline base64 prepended to the matching HTML field); the bytes
    get folded into an allowlisted field, not into a separate one. The
    remaining params MUST equal the field-allowlist exactly.

    If you add a kwarg here, you are widening the write surface — re-read
    the AI-misuse warning in CLAUDE.md and update _UPDATE_ALLOWED_FIELDS
    if (and only if) the new kwarg is itself a writable field.
    """
    import inspect
    from mcp_server import _UPDATE_ALLOWED_FIELDS, hsdes_update_article

    fn = getattr(hsdes_update_article, "fn", hsdes_update_article)
    params = set(inspect.signature(fn).parameters.keys())
    field_params = params - {
        "article_id",
        "comment_id",
        "dry_run",
        "comments_image_paths",
        "ext_cust_blog_rich_image_paths",
    }
    assert field_params == set(_UPDATE_ALLOWED_FIELDS), (
        f"hsdes_update_article field params {field_params} must equal "
        f"allowlist {set(_UPDATE_ALLOWED_FIELDS)}"
    )


@patch("mcp_server._run_ps1")
def test_update_article_comment_id_requires_comments(mock_ps1):
    from mcp_server import hsdes_update_article

    result = _call(hsdes_update_article, "22021660584", comment_id="1566988190")
    assert "comment_id requires comments" in result
    mock_ps1.assert_not_called()


@patch("mcp_server._run_ps1")
def test_update_article_invalid_comment_id(mock_ps1):
    from mcp_server import hsdes_update_article

    result = _call(
        hsdes_update_article,
        "22021660584",
        comments="hi",
        comment_id="not-a-number",
    )
    assert "numeric" in result.lower()
    mock_ps1.assert_not_called()


@patch("mcp_server._run_ps1")
def test_update_article_comment_id_routes_to_ps1(mock_ps1):
    from mcp_server import hsdes_update_article

    mock_ps1.return_value = "=== UPDATE SUCCESS ==="
    _call(
        hsdes_update_article,
        "22021660584",
        comments="updated body",
        comment_id="1566988190",
        dry_run=False,
    )

    _, kwargs = mock_ps1.call_args
    assert kwargs["ArticleId"] == "22021660584"
    assert kwargs["CommentId"] == "1566988190"
    assert kwargs["Comments"] == "updated body"
    assert kwargs["DryRun"] == "false"
    assert "Notify" not in kwargs


@patch("mcp_server._run_ps1")
def test_update_article_ext_cust_blog_rich_routes_to_ps1(mock_ps1):
    from mcp_server import hsdes_update_article

    mock_ps1.return_value = "=== UPDATE SUCCESS ==="
    _call(
        hsdes_update_article,
        "15019275874",
        ext_cust_blog_rich="<p>customer update</p>",
    )

    _, kwargs = mock_ps1.call_args
    assert kwargs["ArticleId"] == "15019275874"
    assert kwargs["ExtCustBlogRich"] == "<p>customer update</p>"
    assert kwargs["DryRun"] == "true"  # default last-mile guard
    assert "ExtCustBlog" not in kwargs  # plain auto-derived in PS1


@patch("mcp_server._run_ps1")
def test_update_article_ext_cust_blog_both_routes_to_ps1(mock_ps1):
    from mcp_server import hsdes_update_article

    mock_ps1.return_value = "=== UPDATE SUCCESS ==="
    _call(
        hsdes_update_article,
        "15019275874",
        ext_cust_blog="manual plain",
        ext_cust_blog_rich="<p>rich body</p>",
    )

    _, kwargs = mock_ps1.call_args
    assert kwargs["ExtCustBlog"] == "manual plain"
    assert kwargs["ExtCustBlogRich"] == "<p>rich body</p>"


# --- status / reason kwargs ---
# `status_reason` is a server-aggregated READ-ONLY display value
# (`<status>.<reason>` — e.g. `open.awaiting_user`). The tool exposes the
# bare `status` and `reason` fields only; the PS1 script writes them as
# separate entries in fieldValues and verifies the live values after a
# real write (HSDes silently no-ops invalid transitions).


@patch("mcp_server._run_ps1")
def test_update_article_reason_routes_to_ps1(mock_ps1):
    from mcp_server import hsdes_update_article

    mock_ps1.return_value = "=== UPDATE SUCCESS ==="
    _call(
        hsdes_update_article,
        "21044484009",
        reason="awaiting_user",
        dry_run=False,
    )

    _, kwargs = mock_ps1.call_args
    assert kwargs["ArticleId"] == "21044484009"
    assert kwargs["Reason"] == "awaiting_user"
    assert kwargs["DryRun"] == "false"
    assert "Status" not in kwargs
    assert "Comments" not in kwargs


@patch("mcp_server._run_ps1")
def test_update_article_status_routes_to_ps1(mock_ps1):
    from mcp_server import hsdes_update_article

    mock_ps1.return_value = "=== UPDATE SUCCESS ==="
    _call(
        hsdes_update_article,
        "21044484009",
        status="open",
    )

    _, kwargs = mock_ps1.call_args
    assert kwargs["ArticleId"] == "21044484009"
    assert kwargs["Status"] == "open"
    assert kwargs["DryRun"] == "true"  # default last-mile guard
    assert "Reason" not in kwargs


@patch("mcp_server._run_ps1")
def test_update_article_status_and_reason_together(mock_ps1):
    from mcp_server import hsdes_update_article

    mock_ps1.return_value = "=== UPDATE SUCCESS ==="
    _call(
        hsdes_update_article,
        "21044484009",
        status="open",
        reason="awaiting_user",
        dry_run=False,
    )

    _, kwargs = mock_ps1.call_args
    assert kwargs["Status"] == "open"
    assert kwargs["Reason"] == "awaiting_user"
    assert kwargs["DryRun"] == "false"


@patch("mcp_server._run_ps1")
def test_update_article_reason_alone_is_a_valid_op(mock_ps1):
    """Passing only -Reason must NOT trigger the 'No fields to update' guard."""
    from mcp_server import hsdes_update_article

    mock_ps1.return_value = "=== UPDATE SUCCESS ==="
    result = _call(hsdes_update_article, "21044484009", reason="awaiting_user")

    assert "No fields to update" not in result
    mock_ps1.assert_called_once()


@patch("mcp_server._run_ps1")
def test_update_article_status_reason_empty_strings_treated_as_missing(mock_ps1):
    from mcp_server import hsdes_update_article

    result = _call(hsdes_update_article, "21044484009", status="   ", reason="")
    assert "No fields to update" in result
    mock_ps1.assert_not_called()


def test_update_article_allowlist_contains_status_and_reason():
    """`status` and `reason` are writable workflow fields exposed by the tool.

    `status_reason` (the merged display value) is intentionally NOT in the
    allowlist — it's read-only on the HSDes side and writes silently no-op.
    """
    from mcp_server import _UPDATE_ALLOWED_FIELDS

    assert "status" in _UPDATE_ALLOWED_FIELDS
    assert "reason" in _UPDATE_ALLOWED_FIELDS
    assert "status_reason" not in _UPDATE_ALLOWED_FIELDS


# --- *_image_paths kwargs ---
# Inline base64 lets the tool avoid having the LM emit image bytes itself; the
# tool reads files from disk and folds them into the matching HTML field on the
# server side. HSDes then auto-uploads each data: URI as a binary attachment
# and rewrites the src. Magic-byte detection (vs. filename extension) rejects
# mislabeled / non-image files cleanly.


def _png_bytes(size: int = 64) -> bytes:
    """Magic-byte-valid PNG payload for _detect_ext_from_magic."""
    return b"\x89PNG\r\n\x1a\n" + b"\x00" * size


@patch("mcp_server._run_ps1")
def test_update_article_comments_image_paths_missing_file(mock_ps1, tmp_path):
    from mcp_server import hsdes_update_article

    missing = tmp_path / "nope.png"  # never created
    result = _call(
        hsdes_update_article,
        "22021660584",
        comments="body",
        comments_image_paths=[str(missing)],
    )
    assert "not found" in result.lower() or "does not exist" in result.lower()
    mock_ps1.assert_not_called()


@patch("mcp_server._run_ps1")
def test_update_article_comments_image_paths_rejects_non_image(mock_ps1, tmp_path):
    from mcp_server import hsdes_update_article

    pdf_path = tmp_path / "doc.pdf"
    pdf_path.write_bytes(b"%PDF-1.4\n%fake")
    result = _call(
        hsdes_update_article,
        "22021660584",
        comments="body",
        comments_image_paths=[str(pdf_path)],
    )
    assert "not a supported image" in result.lower() or "supported: png" in result.lower()
    mock_ps1.assert_not_called()


@patch("mcp_server._run_ps1")
def test_update_article_comments_image_paths_prepends_base64(mock_ps1, tmp_path):
    from mcp_server import hsdes_update_article

    img = tmp_path / "shot.png"
    img.write_bytes(_png_bytes(120))

    mock_ps1.return_value = "=== UPDATE SUCCESS ==="
    _call(
        hsdes_update_article,
        "22021660584",
        comments="<p>hello</p>",
        comments_image_paths=[str(img)],
    )

    _, kwargs = mock_ps1.call_args
    body = kwargs["Comments"]
    assert body.startswith("<div>")
    assert '<img src="data:image/png;base64,' in body
    assert body.endswith("<p>hello</p>")  # original body preserved at tail


@patch("mcp_server._run_ps1")
def test_update_article_comments_image_paths_without_comments_synthesizes(
    mock_ps1, tmp_path
):
    """Image-only comment is a valid use case (chat screenshot with no prose)."""
    from mcp_server import hsdes_update_article

    img = tmp_path / "shot.png"
    img.write_bytes(_png_bytes())

    mock_ps1.return_value = "=== UPDATE SUCCESS ==="
    result = _call(
        hsdes_update_article,
        "22021660584",
        comments_image_paths=[str(img)],
    )
    assert "No fields to update" not in result
    _, kwargs = mock_ps1.call_args
    assert '<img src="data:image/png;base64,' in kwargs["Comments"]


@patch("mcp_server._run_ps1")
def test_update_article_comments_image_paths_multiple(mock_ps1, tmp_path):
    from mcp_server import hsdes_update_article

    img1 = tmp_path / "a.png"
    img2 = tmp_path / "b.jpg"
    img1.write_bytes(_png_bytes())
    img2.write_bytes(b"\xff\xd8\xff" + b"\x00" * 80)  # JPEG magic

    mock_ps1.return_value = "=== UPDATE SUCCESS ==="
    _call(
        hsdes_update_article,
        "22021660584",
        comments="end",
        comments_image_paths=[str(img1), str(img2)],
    )
    _, kwargs = mock_ps1.call_args
    body = kwargs["Comments"]
    assert body.count("<img ") == 2
    assert "data:image/png;base64," in body
    assert "data:image/jpeg;base64," in body


@patch("mcp_server._run_ps1")
def test_update_article_ext_cust_blog_rich_image_paths_prepends(mock_ps1, tmp_path):
    from mcp_server import hsdes_update_article

    img = tmp_path / "screenshot.png"
    img.write_bytes(_png_bytes())

    mock_ps1.return_value = "=== UPDATE SUCCESS ==="
    _call(
        hsdes_update_article,
        "15019275874",
        ext_cust_blog_rich="<p>customer update</p>",
        ext_cust_blog_rich_image_paths=[str(img)],
    )

    _, kwargs = mock_ps1.call_args
    body = kwargs["ExtCustBlogRich"]
    assert body.startswith("<div>")
    assert '<img src="data:image/png;base64,' in body
    assert body.endswith("<p>customer update</p>")
    # Comments must NOT have been touched
    assert "Comments" not in kwargs


@patch("mcp_server._run_ps1")
def test_update_article_ext_cust_blog_rich_image_paths_alone(mock_ps1, tmp_path):
    """rich field image-only write: image_paths supplied, no rich text."""
    from mcp_server import hsdes_update_article

    img = tmp_path / "shot.png"
    img.write_bytes(_png_bytes())

    mock_ps1.return_value = "=== UPDATE SUCCESS ==="
    result = _call(
        hsdes_update_article,
        "15019275874",
        ext_cust_blog_rich_image_paths=[str(img)],
    )
    assert "No fields to update" not in result
    _, kwargs = mock_ps1.call_args
    assert '<img src="data:image/png;base64,' in kwargs["ExtCustBlogRich"]


@patch("mcp_server._run_ps1")
def test_update_article_both_image_paths_independent(mock_ps1, tmp_path):
    """comments_image_paths and ext_cust_blog_rich_image_paths target different fields."""
    from mcp_server import hsdes_update_article

    a = tmp_path / "a.png"
    b = tmp_path / "b.jpg"
    a.write_bytes(_png_bytes())
    b.write_bytes(b"\xff\xd8\xff" + b"\x00" * 80)

    mock_ps1.return_value = "=== UPDATE SUCCESS ==="
    _call(
        hsdes_update_article,
        "15019275874",
        comments="c-body",
        ext_cust_blog_rich="r-body",
        comments_image_paths=[str(a)],
        ext_cust_blog_rich_image_paths=[str(b)],
    )

    _, kwargs = mock_ps1.call_args
    # PNG goes to Comments, JPEG goes to ExtCustBlogRich — not cross-contaminated.
    assert "data:image/png;base64," in kwargs["Comments"]
    assert "data:image/jpeg;base64," not in kwargs["Comments"]
    assert "data:image/jpeg;base64," in kwargs["ExtCustBlogRich"]
    assert "data:image/png;base64," not in kwargs["ExtCustBlogRich"]
