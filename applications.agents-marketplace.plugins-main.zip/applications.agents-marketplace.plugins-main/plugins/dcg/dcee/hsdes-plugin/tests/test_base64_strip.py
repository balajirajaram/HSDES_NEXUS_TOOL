"""Tests for inline base64 image stripping across all HSDes tools that return HTML body content."""
import json
import os
import sys
from unittest.mock import patch

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))


def _call(tool_obj, *args, **kwargs):
    fn = getattr(tool_obj, "fn", tool_obj)
    return fn(*args, **kwargs)


# ---------------------------------------------------------------- helper level


def test_strip_helper_replaces_inline_image():
    from mcp_server import _strip_base64_images

    # Use a 1KB+ payload so the placeholder genuinely saves bytes
    big_payload = "iVBORw0KGgoAAAANSUhEUgAAA==" * 50
    text = f'before <img src="data:image/png;base64,{big_payload}"> after'
    out, stats = _strip_base64_images(text)

    assert "data:image/png;base64," not in out
    assert "[base64-image-stripped:id=" in out
    assert "type=png" in out
    assert "before" in out and "after" in out
    assert stats["count"] == 1
    assert stats["bytes_saved"] > 0


def test_strip_helper_inline_id_is_stable():
    """Same base64 payload must produce same inline_id across calls."""
    from mcp_server import _strip_base64_images, _inline_image_id

    payload = "iVBORw0KGgoAAAANSUhEUgAAA=="
    text1 = f'<img src="data:image/png;base64,{payload}">'
    text2 = f'<a><img src="data:image/png;base64,{payload}"></a>'

    out1, _ = _strip_base64_images(text1)
    out2, _ = _strip_base64_images(text2)
    expected_id = _inline_image_id(payload)

    assert f"id={expected_id}" in out1
    assert f"id={expected_id}" in out2


def test_strip_helper_placeholder_mentions_recovery_path():
    """Placeholder text should hint at hsdes_get_images for image retrieval."""
    from mcp_server import _strip_base64_images

    out, _ = _strip_base64_images('<img src="data:image/png;base64,iVBORw==">')
    assert "hsdes_get_images" in out


def test_strip_helper_handles_multiple_images_and_types():
    from mcp_server import _strip_base64_images

    text = (
        'a <img src="data:image/jpeg;base64,/9j/4AAQSkZJRg=="> '
        'b <img src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciLz4="> '
        'c <img src="data:image/gif;base64,R0lGODlhAQABAAAAACw=">'
    )
    out, stats = _strip_base64_images(text)

    assert stats["count"] == 3
    assert "type=jpeg" in out
    assert "type=svg+xml" in out
    assert "type=gif" in out
    assert "data:image/" not in out


def test_strip_helper_no_images_is_noop():
    from mcp_server import _strip_base64_images

    text = '{"id":"1","title":"no images here","body":"<p>hello world</p>"}'
    out, stats = _strip_base64_images(text)

    assert out == text
    assert stats == {"count": 0, "bytes_saved": 0}


def test_strip_helper_preserves_json_structure():
    """Base64 alphabet contains no JSON-meaningful chars; replacement must leave JSON parseable."""
    from mcp_server import _strip_base64_images

    payload = {
        "data": [
            {
                "id": "1",
                "ext_cust_blog_hist": '<p><img src="data:image/png;base64,iVBORw0KGgo+abc/123="></p>',
            }
        ]
    }
    text = json.dumps(payload)
    out, stats = _strip_base64_images(text)
    parsed = json.loads(out)

    assert stats["count"] == 1
    assert "data:image/" not in parsed["data"][0]["ext_cust_blog_hist"]
    assert "[base64-image-stripped:" in parsed["data"][0]["ext_cust_blog_hist"]


def test_strip_helper_large_image_byte_savings():
    from mcp_server import _strip_base64_images

    fake_payload = "A" * 50000
    text = f'<img src="data:image/png;base64,{fake_payload}">'
    out, stats = _strip_base64_images(text)

    assert stats["count"] == 1
    assert stats["bytes_saved"] > 49000  # placeholder is ~50 chars; nearly all is saved
    assert len(out) < 200


# ------------------------------------------------------------- tool integration


def _saved_query_response(rows):
    return json.dumps({"data": rows, "total": len(rows)})


@patch("mcp_server._enrich_owners", side_effect=lambda t: t)
@patch("mcp_server._run_ps1")
def test_saved_query_strips_inline_base64_when_history_included(mock_ps1, _enrich):
    """When user opts in to include_customer_history, base64 in that field must still be stripped."""
    from mcp_server import hsdes_get_saved_query

    mock_ps1.return_value = _saved_query_response([
        {
            "id": "14027610565",
            "title": "PCIe issue",
            "ext_cust_blog_hist": '<p>real text</p><img src="data:image/png;base64,iVBORw0KGgoAAAA==">',
        }
    ])

    out = _call(hsdes_get_saved_query, "100", include_customer_history=True)
    assert "data:image/" not in out
    assert "[base64-image-stripped:id=" in out
    assert "real text" in out  # surrounding text preserved
    assert "1 inline base64 image" in out  # NOTE banner present


@patch("mcp_server._enrich_owners", side_effect=lambda t: t)
@patch("mcp_server._run_ps1")
def test_saved_query_strips_base64_in_unhandled_fields(mock_ps1, _enrich):
    """Even if base64 lives in a non-bomb field (e.g. irf_notes), it gets stripped."""
    from mcp_server import hsdes_get_saved_query

    mock_ps1.return_value = _saved_query_response([
        {
            "id": "1",
            "title": "t",
            "irf_notes": '<img src="data:image/jpeg;base64,/9j/4AAQAAA==">',
        }
    ])

    out = _call(hsdes_get_saved_query, "100")
    assert "data:image/" not in out
    assert "[base64-image-stripped:id=" in out
    assert "type=jpeg" in out


@patch("mcp_server._enrich_owners", side_effect=lambda t: t)
@patch("mcp_server._run_ps1")
def test_get_article_strips_inline_base64_in_description(mock_ps1, _enrich):
    from mcp_server import hsdes_get_article

    mock_ps1.return_value = json.dumps({
        "data": [{
            "id": "14027610565",
            "title": "t",
            "description": '<p>desc text</p><img src="data:image/png;base64,iVBORw0KGgo=">',
        }]
    })

    out = _call(hsdes_get_article, "14027610565", include_description=True)
    parsed = json.loads(out)
    body = parsed["data"][0]["description"]

    assert "data:image/" not in body
    assert "[base64-image-stripped:id=" in body
    assert "desc text" in body


@patch("mcp_server._enrich_owners", side_effect=lambda t: t)
@patch("mcp_server._run_ps1")
def test_get_article_strips_inline_base64_in_ext_cust_blog_hist(mock_ps1, _enrich):
    from mcp_server import hsdes_get_article

    mock_ps1.return_value = json.dumps({
        "data": [{
            "id": "14027610565",
            "title": "t",
            "server_platf_ae.bug.ext_cust_blog_hist": '<img src="data:image/png;base64,iVBORw0KGgoAAA=">',
        }]
    })

    out = _call(hsdes_get_article, "14027610565", include_customer_history=True)
    assert "data:image/" not in out
    assert "[base64-image-stripped:" in out


@patch("mcp_server._enrich_owners", side_effect=lambda t: t)
@patch("mcp_server._run_ps1")
def test_get_comments_strips_inline_base64(mock_ps1, _enrich):
    from mcp_server import hsdes_get_comments

    mock_ps1.return_value = json.dumps({
        "data": [{
            "id": "c1",
            "owner": "user1",
            "submitted_date": "2026-05-01",
            "description": '<p>comment text</p><img src="data:image/png;base64,iVBORw0KGgo=">',
        }]
    })

    out = _call(hsdes_get_comments, "14027610565")
    parsed = json.loads(out)
    body = parsed["comments"][0]["description"]

    assert "data:image/" not in body
    assert "[base64-image-stripped:id=" in body
    assert "comment text" in body


@patch("mcp_server._enrich_owners", side_effect=lambda t: t)
@patch("mcp_server._run_ps1")
def test_get_article_context_inherits_strip_from_inner_calls(mock_ps1, _enrich):
    """Context tool composes get_article + get_comments — both already strip, so context output is clean."""
    from mcp_server import hsdes_get_article_context

    article_resp = json.dumps({
        "data": [{
            "id": "14027610565",
            "title": "t",
            "description": '<img src="data:image/png;base64,iVBORw0KGgo=">',
            "server_platf_ae.bug.ext_cust_blog_hist": '<img src="data:image/jpeg;base64,/9j/4AA=">',
        }]
    })
    comments_resp = json.dumps({
        "data": [{
            "id": "c1",
            "owner": "u",
            "submitted_date": "2026-05-01",
            "description": '<img src="data:image/gif;base64,R0lGODlh">',
        }]
    })
    mock_ps1.side_effect = [article_resp, comments_resp]

    out = _call(
        hsdes_get_article_context,
        "14027610565",
        include_description=True,
        include_customer_history=True,
        include_comments=True,
    )

    assert "data:image/" not in out
    # All three image types should have been stripped via inner-tool sanitization
    assert out.count("[base64-image-stripped:") >= 3
