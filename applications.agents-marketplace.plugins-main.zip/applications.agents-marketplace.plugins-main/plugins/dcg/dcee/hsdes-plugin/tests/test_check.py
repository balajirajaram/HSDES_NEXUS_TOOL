"""Tests for hsdes health checks."""
import asyncio
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))


def test_get_server_capability_counts_reports_registered_items():
    import check
    import mcp_server

    counts = asyncio.run(check._get_server_capability_counts(mcp_server.mcp))

    assert counts["tools"] >= 1
    assert counts["resources"] >= 1
