"""Tests for hsdes_get_comments tool."""
import json
import sys
import os
from unittest.mock import patch

# Add parent dir to path so we can import mcp_server
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

MOCK_COMMENTS_RESPONSE = json.dumps({
    "data": [
        {"id": "100001", "owner": "jdoe", "description": "&lt;p&gt;First comment&lt;/p&gt;", "submitted_date": "2026-03-20T10:00:00Z"},
        {"id": "100002", "owner": "asmith", "description": "&lt;p&gt;Second comment&lt;/p&gt;", "submitted_date": "2026-03-21T14:30:00Z"},
    ]
})


def _call(tool_obj, *args, **kwargs):
    """Call the underlying function of a FastMCP FunctionTool."""
    fn = getattr(tool_obj, 'fn', tool_obj)
    return fn(*args, **kwargs)


@patch("mcp_server._run_ps1")
@patch("mcp_server._enrich_owners", side_effect=lambda x: x)
def test_get_comments_returns_structured_json(mock_enrich, mock_ps1):
    mock_ps1.return_value = MOCK_COMMENTS_RESPONSE
    from mcp_server import hsdes_get_comments
    result = _call(hsdes_get_comments, "14025517573")
    parsed = json.loads(result)
    assert parsed["hsd_id"] == "14025517573"
    assert parsed["count"] == 2
    assert len(parsed["comments"]) == 2
    assert parsed["comments"][0]["owner"] == "jdoe"
    mock_ps1.assert_called_once_with("hsdes_get_comments.ps1", ArticleId="14025517573", Format="text")


@patch("mcp_server._run_ps1")
@patch("mcp_server._enrich_owners", side_effect=lambda x: x)
def test_get_comments_empty(mock_enrich, mock_ps1):
    mock_ps1.return_value = json.dumps({"data": []})
    from mcp_server import hsdes_get_comments
    result = _call(hsdes_get_comments, "99999999999")
    parsed = json.loads(result)
    assert parsed["count"] == 0
    assert parsed["comments"] == []


@patch("mcp_server._run_ps1")
def test_get_comments_invalid_id(mock_ps1):
    from mcp_server import hsdes_get_comments
    result = _call(hsdes_get_comments, "not-a-number")
    assert "numeric" in result.lower()
    mock_ps1.assert_not_called()
