"""Tests for hsdes_get_images covering inline base64 image extraction (v1.1.6)."""
import base64
import json
import os
import sys
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))


def _call(tool_obj, *args, **kwargs):
    fn = getattr(tool_obj, "fn", tool_obj)
    return fn(*args, **kwargs)


# Smallest valid PNG (1x1 transparent) — actually decodable, so size > 0
_TINY_PNG = base64.b64encode(
    bytes.fromhex(
        "89504e470d0a1a0a0000000d49484452000000010000000108060000001f15c489"
        "0000000d49444154789c63600100000005000174e9c5300000000049454e44ae426082"
    )
).decode("ascii")


def _make_article_html_with_inline(b64_data: str, img_type: str = "png") -> str:
    return (
        f'<p>customer email body</p>'
        f'<img src="data:image/{img_type};base64,{b64_data}" alt="screenshot">'
        f'<p>more text</p>'
    )


@patch("mcp_server._run_ps1")
def test_get_images_extracts_inline_base64_from_description(mock_ps1, tmp_path, monkeypatch):
    """A single inline image in description should be extracted, decoded, and saved to disk."""
    import mcp_server
    monkeypatch.setattr(mcp_server, "_enrich_owners", lambda t: t)

    article_resp = json.dumps({
        "data": [{
            "id": "14027610565",
            "title": "t",
            "description": _make_article_html_with_inline(_TINY_PNG, "png"),
        }]
    })
    comments_resp = json.dumps({"data": []})
    mock_ps1.side_effect = [article_resp, comments_resp]

    out = _call(mcp_server.hsdes_get_images, "14027610565")
    parsed = json.loads(out)

    assert parsed["total_found"] == 1
    assert parsed["count"] == 1
    img = parsed["images"][0]
    assert "inline_id" in img
    assert img["content_type"] == "image/png"
    assert img["source"] == "description"
    assert img["size"] > 0
    # File actually written to disk
    assert Path(img["local_path"]).exists()
    assert Path(img["local_path"]).stat().st_size == img["size"]


@patch("mcp_server._run_ps1")
def test_get_images_inline_id_matches_strip_placeholder(mock_ps1):
    """Placeholder id from _strip_base64_images must match inline_id from hsdes_get_images."""
    import mcp_server

    html = _make_article_html_with_inline(_TINY_PNG, "png")

    # 1) Strip the same html — capture the placeholder id
    stripped, _ = mcp_server._strip_base64_images(html)
    import re
    m = re.search(r"\[base64-image-stripped:id=([0-9a-f]+),", stripped)
    assert m, f"placeholder not found in {stripped!r}"
    placeholder_id = m.group(1)

    # 2) Run hsdes_get_images with the same html as the article description
    article_resp = json.dumps({"data": [{"id": "1", "description": html}]})
    comments_resp = json.dumps({"data": []})
    mock_ps1.side_effect = [article_resp, comments_resp]

    out = _call(mcp_server.hsdes_get_images, "1")
    parsed = json.loads(out)
    image_id = parsed["images"][0]["inline_id"]

    assert image_id == placeholder_id


@patch("mcp_server._run_ps1")
def test_get_images_extracts_inline_from_ext_cust_blog_hist_and_comments(mock_ps1):
    """Cover all three field locations: description, ext_cust_blog_hist, comments."""
    import mcp_server

    article_resp = json.dumps({
        "data": [{
            "id": "1",
            "description": _make_article_html_with_inline(_TINY_PNG, "png"),
            "server_platf_ae.bug.ext_cust_blog_hist": (
                _make_article_html_with_inline(_TINY_PNG[:-4] + "AAAA", "jpeg")
            ),
        }]
    })
    comments_resp = json.dumps({
        "data": [{
            "id": "c1",
            "owner": "u1",
            "submitted_date": "2026-05-01",
            "description": _make_article_html_with_inline(_TINY_PNG[:-4] + "BBBB", "gif"),
        }]
    })
    mock_ps1.side_effect = [article_resp, comments_resp]

    out = _call(mcp_server.hsdes_get_images, "1")
    parsed = json.loads(out)

    sources = sorted(img["source"] for img in parsed["images"])
    assert sources == ["comment#1", "description", "ext_cust_blog_hist"]
    assert parsed["count"] == 3


@patch("mcp_server._run_ps1")
def test_get_images_dedupes_same_inline_image_across_fields(mock_ps1):
    """Same image appearing in two fields gets one entry, first-source-wins."""
    import mcp_server

    same_img = _make_article_html_with_inline(_TINY_PNG, "png")
    article_resp = json.dumps({
        "data": [{
            "id": "1",
            "description": same_img,
            "server_platf_ae.bug.ext_cust_blog_hist": same_img,
        }]
    })
    comments_resp = json.dumps({"data": []})
    mock_ps1.side_effect = [article_resp, comments_resp]

    out = _call(mcp_server.hsdes_get_images, "1")
    parsed = json.loads(out)

    assert parsed["count"] == 1
    # First-seen field wins (description comes first in _IMAGE_FIELDS list)
    assert parsed["images"][0]["source"] == "description"


@patch("mcp_server._run_ps1")
def test_get_images_max_images_caps_total_across_binary_and_inline(mock_ps1):
    """max_images budget should be applied across both binary and inline images."""
    import mcp_server

    # Construct article HTML with no binary IDs but 3 distinct inline images
    inline_html = (
        f'<img src="data:image/png;base64,{_TINY_PNG}">'
        f'<img src="data:image/jpeg;base64,{_TINY_PNG[:-4] + "AAAA"}">'
        f'<img src="data:image/gif;base64,{_TINY_PNG[:-4] + "BBBB"}">'
    )
    article_resp = json.dumps({"data": [{"id": "1", "description": inline_html}]})
    comments_resp = json.dumps({"data": []})
    mock_ps1.side_effect = [article_resp, comments_resp]

    out = _call(mcp_server.hsdes_get_images, "1", max_images=2)
    parsed = json.loads(out)

    assert parsed["total_found"] == 3
    assert parsed["count"] == 2
    assert "Limit: 2/3" in parsed["message"]


@patch("mcp_server._run_ps1")
def test_get_images_message_reports_split_counts(mock_ps1):
    import mcp_server

    article_resp = json.dumps({
        "data": [{"id": "1", "description": _make_article_html_with_inline(_TINY_PNG, "png")}]
    })
    comments_resp = json.dumps({"data": []})
    mock_ps1.side_effect = [article_resp, comments_resp]

    out = _call(mcp_server.hsdes_get_images, "1")
    parsed = json.loads(out)

    assert "0 HSDes binary, 1 inline base64" in parsed["message"]


@patch("mcp_server._run_ps1")
def test_get_images_no_images_at_all(mock_ps1):
    """Article with no binary IDs and no inline base64 should report empty list."""
    import mcp_server

    article_resp = json.dumps({
        "data": [{"id": "1", "description": "<p>just some text, no images</p>"}]
    })
    comments_resp = json.dumps({"data": []})
    mock_ps1.side_effect = [article_resp, comments_resp]

    out = _call(mcp_server.hsdes_get_images, "1")
    parsed = json.loads(out)

    assert parsed["count"] == 0
    assert parsed["total_found"] == 0


def test_extract_inline_base64_helper_returns_full_payload():
    """Helper must return type, b64_data, and stable inline_id."""
    from mcp_server import _extract_inline_base64_images, _inline_image_id

    html = (
        f'<img src="data:image/png;base64,AAAB=="> and '
        f'<img src="data:image/jpeg;base64,/9j/4AA==">'
    )
    out = _extract_inline_base64_images(html)

    assert len(out) == 2
    assert out[0]["type"] == "png"
    assert out[0]["inline_id"] == _inline_image_id("AAAB==")
    assert out[1]["type"] == "jpeg"
    assert out[1]["b64_data"] == "/9j/4AA=="
