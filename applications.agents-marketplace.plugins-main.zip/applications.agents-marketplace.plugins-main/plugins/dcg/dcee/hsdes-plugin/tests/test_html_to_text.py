"""Tests for the HTML→text dual-mode path (v1.1.8).

Verifies the format parameter is wired through correctly to PS1, with default
'text' and 'html' opt-in. The actual HTML stripping is done in PowerShell
(scripts/hsdes_text_helpers.ps1) and exercised end-to-end against the live
HSDes API in the smoke test, not unit-tested here.
"""
import json
import os
import sys
from unittest.mock import patch

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))


def _call(tool_obj, *args, **kwargs):
    fn = getattr(tool_obj, "fn", tool_obj)
    return fn(*args, **kwargs)


# ------------------------------------------------- hsdes_get_article: format wiring


@patch("mcp_server._enrich_owners", side_effect=lambda t: t)
@patch("mcp_server._run_ps1")
def test_get_article_default_format_is_text(mock_ps1, _enrich):
    from mcp_server import hsdes_get_article

    mock_ps1.return_value = '{"data":[{"id":"1"}]}'
    _call(hsdes_get_article, "1")

    _, kwargs = mock_ps1.call_args
    assert kwargs["Format"] == "text"


@patch("mcp_server._enrich_owners", side_effect=lambda t: t)
@patch("mcp_server._run_ps1")
def test_get_article_format_html_passes_through(mock_ps1, _enrich):
    from mcp_server import hsdes_get_article

    mock_ps1.return_value = '{"data":[{"id":"1"}]}'
    _call(hsdes_get_article, "1", format="html")

    _, kwargs = mock_ps1.call_args
    assert kwargs["Format"] == "html"


@patch("mcp_server._enrich_owners", side_effect=lambda t: t)
@patch("mcp_server._run_ps1")
def test_get_article_invalid_format_falls_back_to_text(mock_ps1, _enrich):
    from mcp_server import hsdes_get_article

    mock_ps1.return_value = '{"data":[{"id":"1"}]}'
    _call(hsdes_get_article, "1", format="markdown")  # not valid

    _, kwargs = mock_ps1.call_args
    assert kwargs["Format"] == "text"


@patch("mcp_server._enrich_owners", side_effect=lambda t: t)
@patch("mcp_server._run_ps1")
def test_get_article_format_case_insensitive(mock_ps1, _enrich):
    from mcp_server import hsdes_get_article

    mock_ps1.return_value = '{"data":[{"id":"1"}]}'
    _call(hsdes_get_article, "1", format="HTML")

    _, kwargs = mock_ps1.call_args
    assert kwargs["Format"] == "html"


# ------------------------------------------------ hsdes_get_comments: format wiring


@patch("mcp_server._enrich_owners", side_effect=lambda t: t)
@patch("mcp_server._run_ps1")
def test_get_comments_default_format_is_text(mock_ps1, _enrich):
    from mcp_server import hsdes_get_comments

    mock_ps1.return_value = '{"data":[]}'
    _call(hsdes_get_comments, "1")

    _, kwargs = mock_ps1.call_args
    assert kwargs["Format"] == "text"


@patch("mcp_server._enrich_owners", side_effect=lambda t: t)
@patch("mcp_server._run_ps1")
def test_get_comments_format_html_passes_through(mock_ps1, _enrich):
    from mcp_server import hsdes_get_comments

    mock_ps1.return_value = '{"data":[]}'
    _call(hsdes_get_comments, "1", format="html")

    _, kwargs = mock_ps1.call_args
    assert kwargs["Format"] == "html"


# ----------------------------------------- hsdes_get_saved_query: format wiring


@patch("mcp_server._enrich_owners", side_effect=lambda t: t)
@patch("mcp_server._run_ps1")
def test_saved_query_default_format_is_text(mock_ps1, _enrich):
    from mcp_server import hsdes_get_saved_query

    mock_ps1.return_value = json.dumps({"data": [{"id": "1"}], "total": 1})
    _call(hsdes_get_saved_query, "100")

    _, kwargs = mock_ps1.call_args
    assert kwargs["Format"] == "text"


@patch("mcp_server._enrich_owners", side_effect=lambda t: t)
@patch("mcp_server._run_ps1")
def test_saved_query_format_html_passes_through(mock_ps1, _enrich):
    from mcp_server import hsdes_get_saved_query

    mock_ps1.return_value = json.dumps({"data": [{"id": "1"}], "total": 1})
    _call(hsdes_get_saved_query, "100", format="html")

    _, kwargs = mock_ps1.call_args
    assert kwargs["Format"] == "html"
