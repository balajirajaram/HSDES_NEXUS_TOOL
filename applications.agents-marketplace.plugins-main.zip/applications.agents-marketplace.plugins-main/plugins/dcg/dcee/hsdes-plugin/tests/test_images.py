"""Tests for hsdes_get_images tool."""
import json
import sys
import os
from unittest.mock import patch

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

MOCK_ARTICLE_RESPONSE = json.dumps({
    "data": [{
        "id": "14025517573",
        "title": "Test article",
        "description": '<p>See this: <img src="https://hsdes.intel.com/rest/binary/111111"> and <img src="https://hsdes-api.intel.com/rest/binary/222222"></p>',
        "server_platf_ae.bug.ext_cust_blog_hist": '<p>Customer log: <img src="https://hsdes.intel.com/rest/binary/444444"></p>'
    }]
})

MOCK_COMMENTS_RESPONSE = json.dumps({
    "data": [
        {"id": "100001", "owner": "jdoe", "description": '<p><img src="https://hsdes.intel.com/rest/binary/333333"></p>', "submitted_date": "2026-03-20"},
    ]
})


def test_extract_binary_ids():
    from mcp_server import _extract_binary_ids
    html = '<img src="https://hsdes.intel.com/rest/binary/111111"> <img src="https://hsdes-api.intel.com/rest/binary/222222"> <a href="https://hsdes.intel.com/rest/binary/333333">link</a>'
    ids = _extract_binary_ids(html)
    assert ids == ["111111", "222222", "333333"]


def test_extract_binary_ids_dedup():
    from mcp_server import _extract_binary_ids
    html = '<img src="https://hsdes.intel.com/rest/binary/111111"><img src="https://hsdes.intel.com/rest/binary/111111">'
    ids = _extract_binary_ids(html)
    assert ids == ["111111"]


def test_extract_binary_ids_empty():
    from mcp_server import _extract_binary_ids
    assert _extract_binary_ids("<p>no images</p>") == []
    assert _extract_binary_ids("") == []


def test_content_type_to_ext():
    from mcp_server import _content_type_to_ext
    assert _content_type_to_ext("image/png") == ".png"
    assert _content_type_to_ext("image/jpeg") == ".jpg"
    assert _content_type_to_ext("image/png; charset=utf-8") == ".png"
    assert _content_type_to_ext("application/pdf") == ".pdf"
    assert _content_type_to_ext("application/octet-stream") == ".bin"
    assert _content_type_to_ext("") == ".bin"


def _call(tool_fn, *args, **kwargs):
    """Call an MCP tool function, unwrapping FastMCP decorator if needed."""
    fn = getattr(tool_fn, 'fn', tool_fn)
    return fn(*args, **kwargs)


@patch("mcp_server._run_ps1")
def test_get_images_full_flow(mock_ps1):
    def ps1_side_effect(script_name, **kwargs):
        if script_name == "hsdes_get_article.ps1":
            return MOCK_ARTICLE_RESPONSE
        elif script_name == "hsdes_get_comments.ps1":
            return MOCK_COMMENTS_RESPONSE
        elif script_name == "hsdes_download_binary.ps1":
            bid = kwargs["BinaryId"]
            out = kwargs["OutputPath"]
            return json.dumps({
                "binary_id": bid,
                "local_path": out,
                "content_type": "image/png",
                "size": 12345,
            })
        return ""

    mock_ps1.side_effect = ps1_side_effect

    from mcp_server import hsdes_get_images
    result = _call(hsdes_get_images, "14025517573")
    parsed = json.loads(result)

    assert parsed["hsd_id"] == "14025517573"
    assert parsed["count"] == 4
    assert len(parsed["images"]) == 4

    binary_ids = [img["binary_id"] for img in parsed["images"]]
    assert "111111" in binary_ids
    assert "222222" in binary_ids
    assert "333333" in binary_ids
    assert "444444" in binary_ids

    sources = {img["binary_id"]: img["source"] for img in parsed["images"]}
    assert sources["444444"] == "ext_cust_blog_hist"
    assert "Read tool" not in parsed["message"]

    contexts = {img["binary_id"]: img["context"] for img in parsed["images"]}
    assert contexts["111111"]["source_type"] == "description"
    assert contexts["111111"]["source_label"] == "description"
    assert contexts["111111"]["text_excerpt"] == "See this: and"
    assert contexts["333333"]["source_type"] == "comment"
    assert contexts["333333"]["source_label"] == "comment#1"
    assert contexts["333333"]["comment_owner"] == "jdoe"


@patch("mcp_server._run_ps1")
def test_get_images_no_images(mock_ps1):
    mock_ps1.side_effect = lambda script, **kw: json.dumps({
        "data": [{"id": "999", "description": "<p>text only</p>"}]
    }) if "article" in script else json.dumps({"data": []})

    from mcp_server import hsdes_get_images
    result = _call(hsdes_get_images, "999")
    parsed = json.loads(result)
    assert parsed["count"] == 0
    assert parsed["images"] == []


@patch("mcp_server._run_ps1")
def test_get_images_max_limit(mock_ps1):
    imgs = " ".join(f'<img src="https://hsdes.intel.com/rest/binary/{1000+i}">' for i in range(25))
    mock_ps1.side_effect = lambda script, **kw: json.dumps({
        "data": [{"id": "888", "description": f"<p>{imgs}</p>"}]
    }) if "article" in script else json.dumps({"data": []})

    from mcp_server import hsdes_get_images
    result = _call(hsdes_get_images, "888", max_images=5)
    parsed = json.loads(result)
    assert parsed["count"] == 5
    assert len(parsed["images"]) == 5
    assert parsed["total_found"] == 25
