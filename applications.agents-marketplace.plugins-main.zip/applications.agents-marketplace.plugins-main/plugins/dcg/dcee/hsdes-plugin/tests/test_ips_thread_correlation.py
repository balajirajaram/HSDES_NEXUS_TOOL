"""Tests for IPS thread parsing and attachment-to-message correlation.

These cover the v1.3.4 enhancements:
  1. `_parse_ips_thread` — split ext_cust_blog_hist by [IPS:|HSDES:] headers.
  2. `_correlate_attachment_to_thread` — match an attachment to its IPS message
     by filename or upload timestamp.
  3. `hsdes_download_ips_attachment(as_image=True)` — return inline Image.

Real fixture taken from HSDes article 14027754728 (Foxconn / Scorpio / OKS).
"""
import os
import sys
from unittest.mock import patch

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))


# Trimmed real ext_cust_blog_hist from article 14027754728.
EXT_CUST_BLOG_HIST = (
    "[IPS: Public to Customers :: Partner :: Allen KL Lee :: "
    "allen.kl.lee@fii-foxconn.com :: 2026-05-12 03:22:49] \n"
    " New Case Attachment uploaded: \n"
    " Download link     messageImage_1778556082480.jpg     All PECI agents untrusted\n\n"
    "[HSDES: Public to Customers :: Agent :: Huang, Dylan :: "
    "dylan.huang@intel.com :: 2026-05-11 23:05:10.537] \n"
    " Hi Allen, understood. If the attached PECI VDM commands pass...\n\n"
    "[IPS: Public to Customers :: Partner :: Allen KL Lee :: "
    "allen.kl.lee@fii-foxconn.com :: 2026-05-07 03:09:54] \n"
    " New Case Attachment uploaded: \n"
    " Download link     messageImage_1778123308699.jpg     PECI VDM CMD\n"
)

EXT_ATTACH_URL = (
    '<?xml version="1.0" ?><dict>'
    '<a href="https://esft-int.intel.com/sftservices/download/HSDES_SFT/'
    '?FileName=messageImage_1778556082480.jpg'
    '&AppFileID=e1573f35-7962-40ba-92ec-f9d7e881aa62'
    '&AppData=14027754728" target="_blank">'
    '[2026-05-12 03:22:49] messageImage_1778556082480.jpg</a>'
    '<a href="https://esft-int.intel.com/sftservices/download/HSDES_SFT/'
    '?FileName=messageImage_1778123308699.jpg'
    '&AppFileID=6e1556a8-8d37-4fe8-a43c-24d59df2f2a2'
    '&AppData=14027754728" target="_blank">'
    '[2026-05-07 03:09:54] messageImage_1778123308699.jpg</a></dict>'
)


# ---------- thread parsing ----------

def test_parse_ips_thread_splits_messages():
    from mcp_server import _parse_ips_thread

    msgs = _parse_ips_thread(EXT_CUST_BLOG_HIST)
    assert len(msgs) == 3
    # Sorted oldest-first
    assert msgs[0]["posted_at"].startswith("2026-05-07")
    assert msgs[-1]["posted_at"].startswith("2026-05-12 03:22")
    # Roles & kinds parsed correctly
    kinds = [m["kind"] for m in msgs]
    assert "IPS" in kinds and "HSDES" in kinds
    agent_msg = next(m for m in msgs if m["kind"] == "HSDES")
    assert agent_msg["role"] == "Agent"
    assert agent_msg["author"] == "Huang, Dylan"
    assert agent_msg["email"] == "dylan.huang@intel.com"


def test_parse_ips_thread_empty_returns_empty_list():
    from mcp_server import _parse_ips_thread

    assert _parse_ips_thread("") == []
    assert _parse_ips_thread("no headers here") == []


# ---------- timestamp map from ext_attach_url ----------

def test_build_ext_attach_timestamps():
    from mcp_server import _build_ext_attach_timestamps, _ext_ts_lookup

    ts_map = _build_ext_attach_timestamps(EXT_ATTACH_URL)
    # AppFileID-keyed lookup is the primary path
    assert ts_map["id:e1573f35-7962-40ba-92ec-f9d7e881aa62"] == "2026-05-12 03:22:49"
    assert ts_map["id:6e1556a8-8d37-4fe8-a43c-24d59df2f2a2"] == "2026-05-07 03:09:54"
    # Filename-keyed fallback also recorded
    assert ts_map["name:messageImage_1778556082480.jpg"] == "2026-05-12 03:22:49"
    assert ts_map["name:messageImage_1778123308699.jpg"] == "2026-05-07 03:09:54"
    # Resolver prefers AppFileID over filename
    assert (
        _ext_ts_lookup(
            ts_map,
            "e1573f35-7962-40ba-92ec-f9d7e881aa62",
            "messageImage_1778556082480.jpg",
        )
        == "2026-05-12 03:22:49"
    )


def test_correlate_duplicate_filename_disambiguated_by_app_file_id_ts(monkeypatch):
    """Same filename appearing in two messages: AppFileID-keyed ts must pick
    the right one. This is the codex Medium finding scenario."""
    from mcp_server import (
        _parse_ips_thread,
        _build_ext_attach_timestamps,
        _ext_ts_lookup,
        _correlate_attachment_to_thread,
    )

    blog = (
        "[IPS: Public to Customers :: Partner :: Alice :: "
        "alice@example.com :: 2026-04-01 10:00:00] \n"
        " New Case Attachment uploaded: Download link screenshot.png foo\n\n"
        "[IPS: Public to Customers :: Partner :: Bob :: "
        "bob@example.com :: 2026-04-02 11:00:00] \n"
        " New Case Attachment uploaded: Download link screenshot.png bar\n"
    )
    xml = (
        '<a href="https://esft-int.intel.com/sftservices/download/HSDES_SFT/'
        '?FileName=screenshot.png&AppFileID=AAA-1111&AppData=42" target="_blank">'
        '[2026-04-01 10:00:00] screenshot.png</a>'
        '<a href="https://esft-int.intel.com/sftservices/download/HSDES_SFT/'
        '?FileName=screenshot.png&AppFileID=BBB-2222&AppData=42" target="_blank">'
        '[2026-04-02 11:00:00] screenshot.png</a>'
    )
    thread = _parse_ips_thread(blog)
    ts_map = _build_ext_attach_timestamps(xml)

    # Each upload, when looked up by AppFileID, gets its own message's metadata.
    ts_a = _ext_ts_lookup(ts_map, "AAA-1111", "screenshot.png")
    ts_b = _ext_ts_lookup(ts_map, "BBB-2222", "screenshot.png")
    ctx_a = _correlate_attachment_to_thread("screenshot.png", ts_a, thread)
    ctx_b = _correlate_attachment_to_thread("screenshot.png", ts_b, thread)
    assert ctx_a["posted_by"] == "Alice"
    assert ctx_b["posted_by"] == "Bob"


def test_build_ext_attach_timestamps_duplicate_filename_keeps_both_by_id():
    """Same display filename uploaded twice → AppFileID-keyed entries don't collide."""
    from mcp_server import _build_ext_attach_timestamps, _ext_ts_lookup

    xml = (
        '<a href="https://esft-int.intel.com/sftservices/download/HSDES_SFT/'
        '?FileName=screenshot.png&AppFileID=AAA-1111&AppData=1" target="_blank">'
        '[2026-05-01 10:00:00] screenshot.png</a>'
        '<a href="https://esft-int.intel.com/sftservices/download/HSDES_SFT/'
        '?FileName=screenshot.png&AppFileID=BBB-2222&AppData=1" target="_blank">'
        '[2026-05-02 11:00:00] screenshot.png</a>'
    )
    ts_map = _build_ext_attach_timestamps(xml)
    assert ts_map["id:AAA-1111"] == "2026-05-01 10:00:00"
    assert ts_map["id:BBB-2222"] == "2026-05-02 11:00:00"
    # Both uploads resolve to their own timestamp via AppFileID
    assert _ext_ts_lookup(ts_map, "AAA-1111", "screenshot.png") == "2026-05-01 10:00:00"
    assert _ext_ts_lookup(ts_map, "BBB-2222", "screenshot.png") == "2026-05-02 11:00:00"


# ---------- correlation ----------

def test_correlate_by_filename_match():
    from mcp_server import _parse_ips_thread, _correlate_attachment_to_thread

    thread = _parse_ips_thread(EXT_CUST_BLOG_HIST)
    ctx = _correlate_attachment_to_thread(
        "messageImage_1778556082480.jpg", "", thread
    )
    assert ctx["posted_by"] == "Allen KL Lee"
    assert ctx["posted_by_role"] == "Partner"
    assert ctx["posted_at"] == "2026-05-12 03:22:49"
    assert ctx["kind"] == "IPS"
    # Message excerpt should strip the boilerplate "Download link <name>"
    assert "All PECI agents untrusted" in ctx["message_excerpt"]
    assert "Download link" not in ctx["message_excerpt"]


def test_correlate_by_timestamp_when_filename_missing():
    from mcp_server import _parse_ips_thread, _correlate_attachment_to_thread

    thread = _parse_ips_thread(EXT_CUST_BLOG_HIST)
    # Filename absent from any body, but timestamp matches a message exactly.
    ctx = _correlate_attachment_to_thread(
        "unrelated.bin", "2026-05-11 23:05:10", thread
    )
    assert ctx.get("posted_by") == "Huang, Dylan"
    assert ctx.get("kind") == "HSDES"


def test_correlate_returns_empty_when_no_match():
    from mcp_server import _parse_ips_thread, _correlate_attachment_to_thread

    thread = _parse_ips_thread(EXT_CUST_BLOG_HIST)
    ctx = _correlate_attachment_to_thread("foo.bin", "1999-01-01 00:00:00", thread)
    assert ctx == {}


# ---------- end-to-end: hsdes_get_attachments enrichment ----------

def test_hsdes_get_attachments_default_skips_enrichment():
    """Default (include_thread_context=False) must NOT add posted_at/posted_by."""
    import json
    import mcp_server

    fake_article = {
        "data": [
            {
                "server_platf_ae.bug.ext_cust_blog_hist": EXT_CUST_BLOG_HIST,
                "server_platf_ae.bug.ext_attach_url": EXT_ATTACH_URL,
                "description": "",
            }
        ]
    }

    def fake_run_ps1(script, **_kw):
        if script == "hsdes_get_attachments.ps1":
            return json.dumps({"attachments": []})
        if script == "hsdes_get_article.ps1":
            return json.dumps(fake_article)
        raise AssertionError(f"unexpected script: {script}")

    with patch.object(mcp_server, "_run_ps1", side_effect=fake_run_ps1):
        out = mcp_server.hsdes_get_attachments("14027754728")

    payload = json.loads(out)
    ips_entries = [a for a in payload["attachments"] if a["type"] == "ips"]
    assert len(ips_entries) >= 2
    # Enrichment fields must be absent in default mode
    for e in ips_entries:
        assert "posted_by" not in e
        assert "posted_by_role" not in e
        assert "message_excerpt" not in e


def test_hsdes_get_attachments_enriches_when_thread_context_enabled():
    """include_thread_context=True attaches posted_by/posted_at/role/email/kind."""
    import json
    import mcp_server

    fake_attachments = {"attachments": []}  # no native HSDes binary attachments
    fake_article = {
        "data": [
            {
                "server_platf_ae.bug.ext_cust_blog_hist": EXT_CUST_BLOG_HIST,
                "server_platf_ae.bug.ext_attach_url": EXT_ATTACH_URL,
                "description": "",
            }
        ]
    }

    def fake_run_ps1(script, **_kw):
        if script == "hsdes_get_attachments.ps1":
            return json.dumps(fake_attachments)
        if script == "hsdes_get_article.ps1":
            return json.dumps(fake_article)
        raise AssertionError(f"unexpected script: {script}")

    with patch.object(mcp_server, "_run_ps1", side_effect=fake_run_ps1):
        out = mcp_server.hsdes_get_attachments(
            "14027754728", include_thread_context=True
        )

    payload = json.loads(out)
    ips_entries = [a for a in payload["attachments"] if a["type"] == "ips"]
    assert len(ips_entries) >= 2

    by_name = {a["filename"]: a for a in ips_entries}
    e = by_name["messageImage_1778556082480.jpg"]
    assert e["posted_at"] == "2026-05-12 03:22:49"
    assert e["posted_by"] == "Allen KL Lee"
    assert e["posted_by_role"] == "Partner"
    assert e["posted_by_email"] == "allen.kl.lee@fii-foxconn.com"
    assert e["kind"] == "IPS"


# ---------- inline-image return ----------

def test_download_ips_attachment_as_image_returns_image_object(tmp_path):
    """as_image=True with a real PNG file should return a fastmcp Image object."""
    import json
    import mcp_server

    # Tiny valid PNG (1x1 transparent)
    png_bytes = bytes.fromhex(
        "89504e470d0a1a0a0000000d49484452000000010000000108060000001f15c4"
        "890000000d49444154789c63000100000005000100"
        "0d0a2db40000000049454e44ae426082"
    )
    img_path = tmp_path / "tiny.png"
    img_path.write_bytes(png_bytes)

    fake_resp = {
        "success": True,
        "filename": "tiny.png",
        "output_path": str(img_path),
        "file_size": len(png_bytes),
        "url": "https://esft-int.intel.com/sftservices/download/HSDES_SFT/?x=1",
    }

    with patch.object(mcp_server, "_run_ps1", return_value=json.dumps(fake_resp)):
        result = mcp_server.hsdes_download_ips_attachment(
            url="https://esft-int.intel.com/sftservices/download/HSDES_SFT/?x=1",
            as_image=True,
        )

    from fastmcp.utilities.types import Image
    assert isinstance(result, Image), f"expected Image, got {type(result)}"


def test_download_ips_attachment_as_image_falls_back_for_non_image(tmp_path):
    """as_image=True with a non-image file must fall back to JSON metadata."""
    import json
    import mcp_server

    txt_path = tmp_path / "notes.txt"
    txt_path.write_bytes(b"hello world")

    fake_resp = {
        "success": True,
        "filename": "notes.txt",
        "output_path": str(txt_path),
        "file_size": 11,
        "url": "https://esft-int.intel.com/sftservices/download/HSDES_SFT/?x=2",
    }

    with patch.object(mcp_server, "_run_ps1", return_value=json.dumps(fake_resp)):
        result = mcp_server.hsdes_download_ips_attachment(
            url="https://esft-int.intel.com/sftservices/download/HSDES_SFT/?x=2",
            as_image=True,
        )

    assert isinstance(result, str)
    payload = json.loads(result)
    assert payload["success"] is True
    assert "as_image_skipped" in payload


def test_download_ips_attachment_default_returns_json(tmp_path):
    """Without as_image flag, behavior is unchanged (JSON string)."""
    import json
    import mcp_server

    img_path = tmp_path / "x.png"
    img_path.write_bytes(b"\x89PNG\r\n\x1a\nrest")

    fake_resp = {
        "success": True,
        "filename": "x.png",
        "output_path": str(img_path),
        "file_size": img_path.stat().st_size,
        "url": "https://esft-int.intel.com/sftservices/download/HSDES_SFT/?x=3",
    }

    with patch.object(mcp_server, "_run_ps1", return_value=json.dumps(fake_resp)):
        result = mcp_server.hsdes_download_ips_attachment(
            url="https://esft-int.intel.com/sftservices/download/HSDES_SFT/?x=3",
        )

    assert isinstance(result, str)
    payload = json.loads(result)
    assert payload["success"] is True
    assert "as_image_skipped" not in payload
