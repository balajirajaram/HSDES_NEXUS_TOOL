"""Tests for v1.4.0 enhancements:
  1. hsdes_download_all_ips_attachments — bulk download with cache
  2. hsdes_get_images(as_image=True) — mixed list with Image blocks
  3. hsdes_download_ips_attachment cache (skip Invoke-WebRequest if file exists)
"""
import json
import os
import sys
from unittest.mock import patch

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

# Reuse the IPS thread fixture from the correlation tests.
from tests.test_ips_thread_correlation import EXT_CUST_BLOG_HIST, EXT_ATTACH_URL  # noqa: E402


# ---------- hsdes_get_images(as_image=True) ----------

def test_get_images_as_image_returns_mixed_blocks(tmp_path):
    import mcp_server
    from fastmcp.utilities.types import Image

    # Tiny PNG
    png = bytes.fromhex(
        "89504e470d0a1a0a0000000d49484452000000010000000108060000001f15c4"
        "890000000d49444154789c63000100000005000100"
        "0d0a2db40000000049454e44ae426082"
    )
    img_dir = tmp_path / "hsdes_images"
    img_dir.mkdir()
    img_path = img_dir / "9999_inline_abc.png"
    img_path.write_bytes(png)

    # Force the tool to "find" our image by mocking the heavy lifting:
    # the PS1 calls return one inline base64 image that decodes to our PNG.
    import base64
    b64 = base64.b64encode(png).decode("ascii")
    html = f'<p>see image</p><img src="data:image/png;base64,{b64}" alt="x">'

    def fake_ps1(script, **_):
        if script == "hsdes_get_article.ps1":
            return json.dumps({"data": [{"description": html}]})
        if script == "hsdes_get_comments.ps1":
            return json.dumps({"data": []})
        raise AssertionError(script)

    with patch.object(mcp_server, "_run_ps1", side_effect=fake_ps1), \
         patch("tempfile.gettempdir", return_value=str(tmp_path)):
        result = mcp_server.hsdes_get_images("9999", as_image=True)

    assert isinstance(result, list), f"expected list, got {type(result)}"
    # First block is the JSON summary string
    assert isinstance(result[0], str)
    summary = json.loads(result[0])
    assert summary["count"] >= 1
    # Subsequent blocks are Image objects
    image_blocks = [b for b in result[1:] if isinstance(b, Image)]
    assert len(image_blocks) >= 1


def test_get_images_default_returns_json_string():
    """as_image=False (default) must keep returning a plain JSON string."""
    import mcp_server

    def fake_ps1(script, **_):
        if script == "hsdes_get_article.ps1":
            return json.dumps({"data": [{"description": ""}]})
        if script == "hsdes_get_comments.ps1":
            return json.dumps({"data": []})
        raise AssertionError(script)

    with patch.object(mcp_server, "_run_ps1", side_effect=fake_ps1):
        result = mcp_server.hsdes_get_images("9999")
    assert isinstance(result, str)
    assert json.loads(result)["count"] == 0


# ---------- hsdes_download_ips_attachment cache ----------

def test_download_ips_attachment_uses_cache(tmp_path):
    """Pre-existing non-empty file at output_path must skip the PS1 download call."""
    import mcp_server

    cache_file = tmp_path / "messageImage_xyz.jpg"
    cache_file.write_bytes(b"\xff\xd8\xff cached jpeg bytes")

    sentinel = {"called": False}

    def fake_ps1(*_a, **_kw):
        sentinel["called"] = True
        raise AssertionError("PS1 should NOT be called when cache exists")

    with patch.object(mcp_server, "_run_ps1", side_effect=fake_ps1):
        out = mcp_server.hsdes_download_ips_attachment(
            url="https://esft-int.intel.com/sftservices/download/HSDES_SFT/?FileName=messageImage_xyz.jpg&AppFileID=x&AppData=1",
            output_path=str(cache_file),
        )

    assert sentinel["called"] is False
    payload = json.loads(out)
    assert payload["success"] is True
    assert payload["cached"] is True
    assert payload["output_path"] == str(cache_file)


def test_download_ips_attachment_no_cache_calls_ps1(tmp_path):
    """If destination does not exist, PS1 must be called as usual."""
    import mcp_server

    target = tmp_path / "newfile.jpg"
    fake_resp = {
        "success": True,
        "filename": "newfile.jpg",
        "output_path": str(target),
        "file_size": 0,
        "url": "https://esft-int.intel.com/sftservices/download/HSDES_SFT/?FileName=newfile.jpg",
    }

    with patch.object(mcp_server, "_run_ps1", return_value=json.dumps(fake_resp)) as m:
        out = mcp_server.hsdes_download_ips_attachment(
            url="https://esft-int.intel.com/sftservices/download/HSDES_SFT/?FileName=newfile.jpg&AppFileID=x&AppData=1",
            output_path=str(target),
        )
    assert m.called
    payload = json.loads(out)
    assert payload["success"] is True
    assert payload.get("cached") is not True


# ---------- hsdes_download_all_ips_attachments ----------

def test_download_all_ips_attachments_manifest(tmp_path):
    import mcp_server

    # Pre-create cache for one of the two files so we can verify cached=True flag.
    # New layout: dest_dir/<AppFileID>/<filename> — fixture AppFileID below
    # matches the EXT_ATTACH_URL entry for messageImage_1778556082480.jpg.
    cached_subdir = tmp_path / "e1573f35-7962-40ba-92ec-f9d7e881aa62"
    cached_subdir.mkdir(parents=True, exist_ok=True)
    cached_file = cached_subdir / "messageImage_1778556082480.jpg"
    cached_file.write_bytes(b"\xff\xd8\xff cached")

    def fake_ps1(script, **kw):
        # Article + native attachments (used by hsdes_get_attachments inside the bulk tool)
        if script == "hsdes_get_attachments.ps1":
            return json.dumps({"attachments": []})
        if script == "hsdes_get_article.ps1":
            return json.dumps({"data": [{
                "server_platf_ae.bug.ext_cust_blog_hist": EXT_CUST_BLOG_HIST,
                "server_platf_ae.bug.ext_attach_url": EXT_ATTACH_URL,
                "description": "",
            }]})
        if script == "hsdes_download_ips.ps1":
            # Simulate a successful download for any non-cached file
            url = kw.get("Url", "")
            out = kw.get("OutputPath", "")
            from urllib.parse import urlparse, parse_qs, unquote
            fname = unquote(parse_qs(urlparse(url).query).get("FileName", [""])[0]) or "x"
            target = out or str(tmp_path / fname)
            from pathlib import Path as _P
            _P(target).write_bytes(b"\xff\xd8\xff downloaded")
            return json.dumps({
                "success": True, "filename": fname, "output_path": target,
                "file_size": 12, "url": url,
            })
        raise AssertionError(f"unexpected script: {script}")

    with patch.object(mcp_server, "_run_ps1", side_effect=fake_ps1):
        out = mcp_server.hsdes_download_all_ips_attachments(
            "14027754728", dest_dir=str(tmp_path), max_workers=2
        )

    payload = json.loads(out)
    assert payload["count"] == 2
    by_name = {f["filename"]: f for f in payload["files"]}
    # The pre-existing cached file must be flagged
    assert by_name["messageImage_1778556082480.jpg"]["cached"] is True
    # The non-cached one was downloaded
    assert by_name["messageImage_1778123308699.jpg"]["cached"] is False
    assert by_name["messageImage_1778123308699.jpg"]["success"] is True


# ---------- security: path traversal in bulk downloader ----------

def test_download_all_ips_attachments_strips_path_traversal(tmp_path):
    """A hostile filename like '..\\..\\boot.ini' must NOT escape dest_dir."""
    import mcp_server

    # Mock get_attachments to return one entry with a path-traversal filename.
    bad_url = (
        "https://esft-int.intel.com/sftservices/download/HSDES_SFT/?"
        "FileName=..%2F..%2Fpwned.txt&AppFileID=hostile-id&AppData=1"
    )
    attachments_payload = {
        "hsd_id": "1",
        "attachments": [
            {
                "type": "ips",
                "filename": "../../pwned.txt",
                "app_file_id": "hostile-id",
                "url": bad_url,
            }
        ],
        "count": 1,
    }

    captured = {}

    def fake_get_attachments(article_id):
        return json.dumps(attachments_payload)

    def fake_download(url, output_path="", as_image=False):
        captured["output_path"] = output_path
        from pathlib import Path as _P
        _P(output_path).parent.mkdir(parents=True, exist_ok=True)
        _P(output_path).write_bytes(b"\x00")
        return json.dumps({
            "success": True,
            "filename": _P(output_path).name,
            "output_path": output_path,
            "file_size": 1,
        })

    with patch.object(mcp_server, "hsdes_get_attachments", side_effect=fake_get_attachments), \
         patch.object(mcp_server, "hsdes_download_ips_attachment", side_effect=fake_download):
        mcp_server.hsdes_download_all_ips_attachments("1", dest_dir=str(tmp_path))

    written = captured["output_path"]
    # Final path must still be inside dest_dir — no `..` segment survives the
    # _safe_basename sanitization.
    written_path = os.path.normpath(written)
    dest_path = os.path.normpath(str(tmp_path))
    assert written_path.startswith(dest_path), (
        f"Path traversal escaped dest_dir: {written_path!r} not under {dest_path!r}"
    )


# ---------- security: cache collision by filename when AppFileID differs ----------

def test_download_ips_attachment_cache_keyed_by_app_file_id(tmp_path, monkeypatch):
    """Two URLs sharing FileName but with different AppFileID must land in
    distinct cache locations — second call must NOT silently return first
    upload's bytes."""
    import mcp_server

    monkeypatch.chdir(tmp_path)

    url_a = (
        "https://esft-int.intel.com/sftservices/download/HSDES_SFT/?"
        "FileName=screenshot.png&AppFileID=AAA-1111&AppData=42"
    )
    url_b = (
        "https://esft-int.intel.com/sftservices/download/HSDES_SFT/?"
        "FileName=screenshot.png&AppFileID=BBB-2222&AppData=42"
    )

    def fake_ps1(script, **kw):
        from pathlib import Path as _P
        target = _P(kw["OutputPath"])
        target.parent.mkdir(parents=True, exist_ok=True)
        # Write distinct content per AppFileID so we can detect collision
        body = b"AAA-content" if "AAA-1111" in target.as_posix() else b"BBB-content"
        target.write_bytes(body)
        return json.dumps({
            "success": True,
            "filename": target.name,
            "output_path": str(target),
            "file_size": len(body),
        })

    with patch.object(mcp_server, "_run_ps1", side_effect=fake_ps1):
        out_a = json.loads(mcp_server.hsdes_download_ips_attachment(url=url_a))
        out_b = json.loads(mcp_server.hsdes_download_ips_attachment(url=url_b))

    # Two distinct on-disk paths (AppFileID subdir)
    assert out_a["output_path"] != out_b["output_path"]
    from pathlib import Path as _P
    assert _P(out_a["output_path"]).read_bytes() == b"AAA-content"
    assert _P(out_b["output_path"]).read_bytes() == b"BBB-content"

    # Second call to url_a must now hit cache, not overwrite with BBB content
    with patch.object(mcp_server, "_run_ps1", side_effect=AssertionError("no PS1 expected on cache hit")):
        out_a2 = json.loads(mcp_server.hsdes_download_ips_attachment(url=url_a))
    assert out_a2["cached"] is True
    assert _P(out_a2["output_path"]).read_bytes() == b"AAA-content"
