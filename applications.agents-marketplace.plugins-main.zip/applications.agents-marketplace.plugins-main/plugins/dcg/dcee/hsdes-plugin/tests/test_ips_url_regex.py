"""Tests for IPS URL regex parsing in ext_attach_url and HTML body fields.

Background: HSDes serves the `FileName=` query parameter with raw (unencoded)
spaces inside `<a href="...">` attributes — e.g. `FileName=EGS PCIE WorkShop ...`.
The previous `[^\\s"'<>]+` form silently truncated such URLs at the first space,
which dropped older real-customer IPS attachments (case 22015171853 from 2022)
from `hsdes_get_attachments` results. v1.3.1 widens the URL char class to
`[^"<>]+` so spaces survive.
"""
import os
import sys
from urllib.parse import parse_qs, urlparse

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))


# Real fixture from HSDes article 22015171853 (Microsoft, Eagle Stream / SPR SP,
# uploaded 2022-06-10). Note the unencoded spaces in FileName.
EXT_ATTACH_URL_22015171853 = (
    '<?xml version="1.0" ?><dict>'
    '<a href="https://esft-int.intel.com/sftservices/download/HSDES_SFT/'
    '?FileName=EGS PCIE WorkShop WW23_MSFT_C2288_E3_CX7.pdf'
    '&AppFileID=14fb0af9-08ef-4012-81fa-dbd69b18daa8'
    '&AppData=22015171853" target="_blank">'
    '[2022-06-10T03:58:25.000Z GMT] EGS PCIE WorkShop WW23_MSFT_C2288_E3_CX7.pdf'
    '</a><br/></dict>'
)


def test_ips_direct_url_re_captures_filename_with_spaces():
    """Regex must capture URLs whose FileName has unencoded spaces."""
    from mcp_server import _IPS_DIRECT_URL_RE

    matches = _IPS_DIRECT_URL_RE.findall(EXT_ATTACH_URL_22015171853)
    assert len(matches) == 1, f"expected exactly one match, got {matches}"

    url = matches[0]
    qs = parse_qs(urlparse(url).query)
    assert qs["FileName"][0] == "EGS PCIE WorkShop WW23_MSFT_C2288_E3_CX7.pdf"
    assert qs["AppFileID"][0] == "14fb0af9-08ef-4012-81fa-dbd69b18daa8"
    assert qs["AppData"][0] == "22015171853"


def test_ips_direct_url_re_stops_at_attribute_boundary():
    """Match must not bleed past the closing `"` of the href attribute."""
    from mcp_server import _IPS_DIRECT_URL_RE

    url = _IPS_DIRECT_URL_RE.findall(EXT_ATTACH_URL_22015171853)[0]
    assert '"' not in url
    assert '<' not in url
    assert '>' not in url
    assert not url.endswith(' ')


def test_ips_url_re_handles_filename_with_spaces_in_href():
    """Same widening applied to the public esft.intel.com pattern."""
    from mcp_server import _IPS_URL_RE

    html = (
        '<a href="https://esft.intel.com/sftservices/download/IPS_SFT'
        '?FileName=My Customer Report Q4 2025.pdf'
        '&AppFileID=00000000-aaaa-bbbb-cccc-000000000001'
        '&AppData=caseId-500cv00000abcdEAAY" target="_blank">My Customer Report</a>'
    )
    matches = _IPS_URL_RE.findall(html)
    assert len(matches) == 1
    qs = parse_qs(urlparse(matches[0]).query)
    assert qs["FileName"][0] == "My Customer Report Q4 2025.pdf"
