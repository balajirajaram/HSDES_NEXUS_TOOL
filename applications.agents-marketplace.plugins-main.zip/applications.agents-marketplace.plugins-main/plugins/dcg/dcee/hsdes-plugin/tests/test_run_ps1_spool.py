"""Tests for _run_ps1's large-arg spool behavior.

Reproduces the v1.4.1 bug where a base64-embedded screenshot in `comments`
overflowed the Windows CreateProcess argv cap (~32KB) and crashed with
`[WinError 206] The filename or extension is too long`. The fix spools any
arg longer than _PS1_LARGE_ARG_THRESHOLD to a UTF-8 temp file and passes
`-{Key}File <path>` instead of `-{Key} <value>`.
"""
import os
import subprocess
import sys
from pathlib import Path
from unittest.mock import patch, MagicMock

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))


def _make_completed_process():
    cp = MagicMock(spec=subprocess.CompletedProcess)
    cp.returncode = 0
    cp.stdout = b'{"ok": true}'
    cp.stderr = b''
    return cp


def test_run_ps1_short_arg_passed_inline():
    """Small values stay on argv — no temp file."""
    import mcp_server

    captured = {}

    def fake_run(cmd, **_kw):
        captured["cmd"] = cmd
        return _make_completed_process()

    with patch.object(mcp_server, "_find_pwsh", return_value="pwsh"), \
         patch("subprocess.run", side_effect=fake_run):
        mcp_server._run_ps1("hsdes_update_article.ps1", ArticleId="123", Comments="short body")

    cmd = captured["cmd"]
    # Small arg appears inline, no -CommentsFile spilled
    assert "-Comments" in cmd
    assert "short body" in cmd
    assert "-CommentsFile" not in cmd


def test_run_ps1_large_arg_spools_to_tempfile():
    """Values larger than _PS1_LARGE_ARG_THRESHOLD become -KeyFile <temppath>."""
    import mcp_server

    big_body = "x" * (mcp_server._PS1_LARGE_ARG_THRESHOLD + 1024)
    captured = {}

    def fake_run(cmd, **_kw):
        captured["cmd"] = cmd
        # Read back the temp file the spool created so we can assert content
        for i, arg in enumerate(cmd):
            if arg == "-CommentsFile":
                with open(cmd[i + 1], "rb") as f:
                    captured["file_bytes"] = f.read()
        return _make_completed_process()

    with patch.object(mcp_server, "_find_pwsh", return_value="pwsh"), \
         patch("subprocess.run", side_effect=fake_run):
        mcp_server._run_ps1("hsdes_update_article.ps1", ArticleId="123", Comments=big_body)

    cmd = captured["cmd"]
    # The big body must NOT be passed as an inline argv value
    assert big_body not in cmd
    # -CommentsFile takes its place
    assert "-CommentsFile" in cmd
    idx = cmd.index("-CommentsFile")
    spool_path = cmd[idx + 1]
    # File content must round-trip UTF-8 bytes
    assert captured["file_bytes"].decode("utf-8") == big_body
    # Cleanup ran in finally — file should be gone by the time _run_ps1 returns
    assert not Path(spool_path).exists()


def test_run_ps1_large_arg_reproduces_winerror_206_without_fix():
    """Sanity bound: a 60KB string is what triggers WinError 206 on Windows;
    confirm the spool kicks in well before that size."""
    import mcp_server

    # 60KB simulates a base64-encoded screenshot
    big_body = "y" * (60 * 1024)
    assert len(big_body) > mcp_server._PS1_LARGE_ARG_THRESHOLD, (
        "Threshold must be smaller than the typical inline-image base64 size."
    )

    captured = {"file_paths": []}

    def fake_run(cmd, **_kw):
        for i, arg in enumerate(cmd):
            # Match `-{Key}File` spool args; `-File` (pwsh's script flag) is
            # excluded so it doesn't count as a spool.
            if (
                arg.startswith("-")
                and arg.endswith("File")
                and arg != "-File"
                and i + 1 < len(cmd)
            ):
                captured["file_paths"].append(cmd[i + 1])
        return _make_completed_process()

    with patch.object(mcp_server, "_find_pwsh", return_value="pwsh"), \
         patch("subprocess.run", side_effect=fake_run):
        mcp_server._run_ps1(
            "hsdes_update_article.ps1",
            ArticleId="123",
            Comments=big_body,
            ExtCustBlogRich=big_body,
        )

    # Two large args → two temp files spooled
    assert len(captured["file_paths"]) == 2


def test_run_ps1_temp_files_cleaned_up_on_exception():
    """Even when the subprocess raises, spool temp files must not leak."""
    import mcp_server

    big_body = "z" * (mcp_server._PS1_LARGE_ARG_THRESHOLD + 1024)
    captured = {"path": None}

    def fake_run(cmd, **_kw):
        for i, arg in enumerate(cmd):
            if arg == "-CommentsFile" and i + 1 < len(cmd):
                captured["path"] = cmd[i + 1]
        raise FileNotFoundError("[WinError 206]")

    with patch.object(mcp_server, "_find_pwsh", return_value="pwsh"), \
         patch("subprocess.run", side_effect=fake_run):
        out = mcp_server._run_ps1(
            "hsdes_update_article.ps1", ArticleId="123", Comments=big_body
        )

    # Error surfaced to caller
    assert "Unexpected error" in out or "WinError 206" in out
    # Temp file got cleaned up in `finally`
    assert captured["path"] is not None
    assert not Path(captured["path"]).exists()
