"""Tests for hsdes_get_saved_query bomb-field stripping behavior."""
import json
import os
import sys
from unittest.mock import patch

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))


def _call(tool_obj, *args, **kwargs):
    fn = getattr(tool_obj, "fn", tool_obj)
    return fn(*args, **kwargs)


def _saved_query_response(rows):
    return json.dumps({"data": rows, "total": len(rows)})


def _extract_payload(text):
    """Saved query result may have prepended NOTE/output-format sections separated by '\\n\\n---\\n\\n'."""
    if "\n\n---\n\n" in text:
        text = text.rsplit("\n\n---\n\n", 1)[1]
    return json.loads(text)


@patch("mcp_server._enrich_owners", side_effect=lambda t: t)
@patch("mcp_server._run_ps1")
def test_saved_query_strips_bomb_fields_by_default(mock_ps1, _enrich):
    from mcp_server import hsdes_get_saved_query

    mock_ps1.return_value = _saved_query_response([
        {
            "id": "15019185922",
            "title": "t1",
            "description": "huge desc",
            "comments": "huge comments",
            "ext_cust_blog_hist": "<html>huge customer history</html>",
        }
    ])

    out = _call(hsdes_get_saved_query, "15018454006")
    payload = _extract_payload(out)
    row = payload["data"][0]

    assert "description" not in row
    assert "comments" not in row
    assert "ext_cust_blog_hist" not in row
    assert row["id"] == "15019185922"
    # NOTE banner should be present and mention all three stripped fields
    assert "stripped" in out
    assert "ext_cust_blog_hist=1" in out
    assert "description=1" in out
    assert "comments=1" in out


@patch("mcp_server._enrich_owners", side_effect=lambda t: t)
@patch("mcp_server._run_ps1")
def test_saved_query_include_customer_history_keeps_field(mock_ps1, _enrich):
    from mcp_server import hsdes_get_saved_query

    mock_ps1.return_value = _saved_query_response([
        {"id": "1", "title": "t", "ext_cust_blog_hist": "keep me"}
    ])

    out = _call(hsdes_get_saved_query, "100", include_customer_history=True)
    payload = _extract_payload(out)
    assert payload["data"][0]["ext_cust_blog_hist"] == "keep me"
    assert "ext_cust_blog_hist=" not in out  # no strip note for this field


@patch("mcp_server._enrich_owners", side_effect=lambda t: t)
@patch("mcp_server._run_ps1")
def test_saved_query_empty_bomb_fields_no_note(mock_ps1, _enrich):
    """Empty-string bomb fields should still be stripped but not counted in the note banner."""
    from mcp_server import hsdes_get_saved_query

    mock_ps1.return_value = _saved_query_response([
        {"id": "1", "title": "t", "ext_cust_blog_hist": "", "description": "", "comments": ""}
    ])

    out = _call(hsdes_get_saved_query, "100")
    payload = _extract_payload(out)
    row = payload["data"][0]

    assert "ext_cust_blog_hist" not in row
    assert "description" not in row
    assert "comments" not in row
    # No NOTE banner because no row had non-empty values
    assert "stripped from saved query" not in out


@patch("mcp_server._enrich_owners", side_effect=lambda t: t)
@patch("mcp_server._run_ps1")
def test_saved_query_dotted_ext_cust_blog_hist_stripped(mock_ps1, _enrich):
    """If a saved query happens to return dotted-key form, also strip it."""
    from mcp_server import hsdes_get_saved_query

    mock_ps1.return_value = _saved_query_response([
        {"id": "1", "title": "t", "server_platf_ae.bug.ext_cust_blog_hist": "huge"}
    ])

    out = _call(hsdes_get_saved_query, "100")
    payload = _extract_payload(out)
    assert "server_platf_ae.bug.ext_cust_blog_hist" not in payload["data"][0]


@patch("mcp_server._enrich_owners", side_effect=lambda t: t)
@patch("mcp_server._run_ps1")
def test_saved_query_invalid_json_passthrough(mock_ps1, _enrich):
    from mcp_server import hsdes_get_saved_query

    mock_ps1.return_value = "not json at all"
    out = _call(hsdes_get_saved_query, "100")
    assert "not json at all" in out


@patch("mcp_server._enrich_owners", side_effect=lambda t: t)
@patch("mcp_server._run_ps1")
def test_saved_query_passes_strip_flags_to_ps1(mock_ps1, _enrich):
    """Verify Python wrapper passes StripBombFields=True and correct KeepFields to PS1."""
    from mcp_server import hsdes_get_saved_query

    mock_ps1.return_value = _saved_query_response([{"id": "1", "title": "t"}])

    _call(hsdes_get_saved_query, "100")
    _, kwargs = mock_ps1.call_args
    assert kwargs["StripBombFields"] is True
    assert kwargs["KeepFields"] == ""

    mock_ps1.reset_mock()
    mock_ps1.return_value = _saved_query_response([{"id": "1", "title": "t"}])
    _call(hsdes_get_saved_query, "100", include_customer_history=True)
    _, kwargs = mock_ps1.call_args
    assert kwargs["StripBombFields"] is True
    assert "ext_cust_blog_hist" in kwargs["KeepFields"]
    assert "server_platf_ae.bug.ext_cust_blog_hist" in kwargs["KeepFields"]


@patch("mcp_server._enrich_owners", side_effect=lambda t: t)
@patch("mcp_server._run_ps1")
def test_saved_query_tolerates_control_chars_in_response(mock_ps1, _enrich):
    """HSDes embeds raw \\x07/\\x1a in some text fields; strict=False keeps json.loads
    from rejecting the response, otherwise _stripped metadata never gets consumed."""
    from mcp_server import hsdes_get_saved_query

    # \x1a is BEL/SUB — Python strict json rejects, json.loads(strict=False) accepts
    raw = (
        '{"data": [{"id": "1", "title": "t", "irf_notes": "see step \x1a here"}], '
        '"total": 1, '
        '"_stripped": {"ext_cust_blog_hist": 5}}'
    )
    mock_ps1.return_value = raw

    out = _call(hsdes_get_saved_query, "100")

    assert "NOTE: heavy fields were stripped" in out
    assert "ext_cust_blog_hist=5" in out
    payload = _extract_payload(out)
    assert "_stripped" not in payload
    # The control char gets re-encoded as proper  after roundtrip
    assert payload["data"][0]["irf_notes"] == "see step \x1a here"


@patch("mcp_server._enrich_owners", side_effect=lambda t: t)
@patch("mcp_server._run_ps1")
def test_saved_query_consumes_ps1_stripped_metadata(mock_ps1, _enrich):
    """When PS1 strips at the source, _stripped metadata must drive the NOTE banner
    and be removed from the response body."""
    from mcp_server import hsdes_get_saved_query

    mock_ps1.return_value = json.dumps({
        "data": [{"id": "1", "title": "t"}],  # PS1 already removed ext_cust_blog_hist
        "total": 1,
        "_stripped": {"ext_cust_blog_hist": 42},
    })

    out = _call(hsdes_get_saved_query, "100")

    assert "NOTE: heavy fields were stripped" in out
    assert "ext_cust_blog_hist=42" in out
    payload = _extract_payload(out)
    assert "_stripped" not in payload  # consumed and removed from body


def test_strip_helper_reports_only_non_empty():
    from mcp_server import _strip_saved_query_bomb_fields

    text = json.dumps({
        "data": [
            {"id": "1", "ext_cust_blog_hist": "x"},
            {"id": "2", "ext_cust_blog_hist": ""},
            {"id": "3", "ext_cust_blog_hist": "y"},
        ]
    })
    out, counts = _strip_saved_query_bomb_fields(
        text, include_description=False, include_comments=False, include_customer_history=False,
    )
    obj = json.loads(out)
    for row in obj["data"]:
        assert "ext_cust_blog_hist" not in row
    assert counts == {"ext_cust_blog_hist": 2}
