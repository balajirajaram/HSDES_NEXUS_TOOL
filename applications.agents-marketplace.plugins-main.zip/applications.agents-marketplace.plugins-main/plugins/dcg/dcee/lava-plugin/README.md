# LAVA Plugin

Query Intel LAVA (Line item AVailability for All) API for CPU specifications by QDF/SSPEC or product name.

> **Install**
> - **VS Code Copilot Chat (Windows, recommended):** install via the [DCEE MCP Setup VSIX extension](../vsix/README.md) — one-click setup.
> - **Claude Code / GitHub Copilot CLI / Codex CLI:** see [Root README — Installation](../README.md#installation).

## Prerequisites

- **AGS access:** request "Lava Users" or "Lava Reader" at [goto.intel.com/ags](https://goto.intel.com/ags)
- **Intel VPN:** connected to Intel network

## First-Time Auth

Device Code Flow — first use prints a code and URL:

```
============================================================
  LAVA API AUTHENTICATION (One-time only)
============================================================
To sign in, use a web browser to open the page
https://microsoft.com/devicelogin and enter the code
ABC12DEFG to authenticate.
  (Future calls will use cached token)
============================================================
```

1. Open the URL in your browser
2. Enter the displayed code
3. Sign in with Intel credentials
4. Token is cached at `~/.mcp_lava_token_cache.json` — no repeated auth needed

## Quick Start

**By product name (recommended):**
```
What SKUs does Granite Rapids have?
Query DMR specifications
Show GNR specs with >32 cores
```

**Supported abbreviations:** DMR, GNR, SRF, CWF, EMR, SPR

**By QDF code:**
```
Query Q9JT specifications
What are the specs for L1CY?
```

## Tools

| Tool | Description | Example |
|------|-------------|---------|
| `search_product_by_name` | Search products by name/abbreviation | "Granite Rapids", "DMR" |
| `get_line_items_by_qdf` | Get CPU specs by QDF code | "Q9JT", "L1CY" |
| `get_line_items_by_pdmid` | Get all specs for a product | pdmid="10047337" |
| `get_line_items_by_qdfs_and_pdmid` | Batch query specific QDFs | pdmid + qdfs="Q99D,Q7UE" |
| `get_product_names` | List all available products | — |
| `search_line_items` | Filter SKUs by spec criteria, including VIS and explicit UNFUSED exclusion | "DMR with >32 cores and SST-BF" |
| `get_qdfs_by_pdmid` | List all QDF codes for a product | — |

## Returned CPU Data

- **Basic:** core count, TDP, max turbo, base frequency, cache size
- **Memory:** DDR5 frequency, MRDIMM (MCR) frequency, memory channels
- **Connectivity:** UPI ports/speed, PCIe lanes/generation
- **Accelerators:** QAT, DSA, IAA device counts
- **SST:** Speed Select Technology support (SST-PP, SST-TF, SST-BF, SST-CP)

## CSV Fallback (Offline Mode)

When the API is unavailable, the plugin auto-falls back to local CSV files. Only `get_line_items_by_qdf` is supported in fallback mode.

**Setup paths (priority order):**
1. `LAVA_CSV_DIR` environment variable
2. `c:\pythonsv\graniterapids\users\mkcummin\sku_analysis`
3. `c:\pythonsv\diamondrapids\users\mkcummin\sku_analysis`
4. `{plugin_dir}/csv`

**CSV files:** `dmr_lava.csv` (Diamond Rapids, ~193 SKUs), `gnr_lava.csv` (Granite Rapids).

**Indicator in response:**
```json
{ "qdf": "Q0PE", "dataSource": "csv_fallback", "items": [...] }
```

## Troubleshooting

| Problem | Solution |
|---------|----------|
| Authentication fails | Verify AGS access, check VPN connection |
| API returns 404 | QDF/PDM ID may not exist or only in Liport |
| Token expired | Auto-refreshes; if fails, delete `~/.mcp_lava_token_cache.json` |
| MCP server not starting | Check `python` path, verify dependencies |
| CSV fallback not working | Set `LAVA_CSV_DIR` or place CSV in `{plugin_dir}/csv` |

## Support

- **Plugin issues:** GitHub issues in this repository
- **LAVA API:** MIT-LAVA-Helpdesk@intel.com
- **AGS access:** goto.intel.com/ags
