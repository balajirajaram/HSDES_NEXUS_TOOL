"""Shared auth/proxy configuration for LAVA Azure AD requests."""

from __future__ import annotations

import os
from typing import Optional

TENANT_ID = "46c98d88-e344-4ed4-8496-4ed7712e255d"

NO_PROXY_DEFAULT = "127.0.0.1,localhost,.intel.com"


def _normalize_no_proxy_env() -> None:
    """Normalize NO_PROXY/no_proxy by trimming and syncing uppercase/lowercase vars."""
    value = os.environ.get("NO_PROXY") or os.environ.get("no_proxy") or ""
    normalized = value.strip()
    if not normalized:
        return
    os.environ["NO_PROXY"] = normalized
    os.environ["no_proxy"] = normalized


def get_proxy_settings() -> Optional[dict[str, str]]:
    """Return normalized proxy settings for requests/MSAL, if configured."""
    _normalize_no_proxy_env()

    proxies: dict[str, str] = {}
    for scheme in ("http", "https"):
        value = os.environ.get(f"{scheme.upper()}_PROXY") or os.environ.get(f"{scheme}_proxy")
        if value and value.strip():
            normalized = value.strip()
            proxies[scheme] = normalized
            os.environ[f"{scheme.upper()}_PROXY"] = normalized
            os.environ[f"{scheme}_proxy"] = normalized

    if "NO_PROXY" not in os.environ and "no_proxy" not in os.environ:
        os.environ["NO_PROXY"] = NO_PROXY_DEFAULT
        os.environ["no_proxy"] = NO_PROXY_DEFAULT

    return proxies or None


def build_msal_app_kwargs(token_cache) -> dict:
    """Build MSAL app kwargs for Intel corporate proxy / TLS inspection."""
    kwargs = {
        "authority": f"https://login.microsoftonline.com/{TENANT_ID}",
        "token_cache": token_cache,
        "verify": False,
    }
    proxies = get_proxy_settings()
    if proxies:
        kwargs["proxies"] = proxies
    return kwargs
