#!/usr/bin/env python3
"""
Lava API MCP Server

Provides tools to query Intel LAVA (Line item AVailability for All) API
for CPU specifications using Azure AD authentication.
"""

import os as _os
import sys


def _ensure_packages(*packages):
    """Auto-install missing packages using Intel proxy."""
    import importlib.util
    missing = [p for p in packages if importlib.util.find_spec(p) is None]
    if missing:
        import subprocess
        _proxy = _os.environ.get("HTTPS_PROXY") or _os.environ.get("HTTP_PROXY") or "http://proxy-dmz.intel.com:912"
        print(f"[lava] Auto-installing: {missing}", file=sys.stderr)
        subprocess.run(
            [sys.executable, "-m", "pip", "install",
             "--isolated",
             f"--proxy={_proxy}",
             "--index-url=https://pypi.org/simple/"] + missing,
            check=True
        )

_ensure_packages("requests", "msal", "urllib3", "fastmcp")

import os  # noqa: E402
import re  # noqa: E402
import json  # noqa: E402
import logging  # noqa: E402
import threading  # noqa: E402
import webbrowser  # noqa: E402
import requests  # noqa: E402
import csv  # noqa: E402
from typing import Any, Optional, Dict, List  # noqa: E402
import msal  # noqa: E402
import urllib3  # noqa: E402
from auth_config import build_msal_app_kwargs  # noqa: E402

# Fix Windows encoding issues - force UTF-8 for stdout/stderr
if sys.platform == "win32":
    import io
    if isinstance(sys.stdout, io.TextIOWrapper):
        sys.stdout.reconfigure(encoding='utf-8')
    if isinstance(sys.stderr, io.TextIOWrapper):
        sys.stderr.reconfigure(encoding='utf-8')

# Fix proxy env vars with trailing newlines (breaks httpx URL parsing)
for _k in ('HTTP_PROXY', 'HTTPS_PROXY', 'NO_PROXY', 'http_proxy', 'https_proxy', 'no_proxy'):
    _v = _os.environ.get(_k)
    if _v and _v != _v.strip():
        _os.environ[_k] = _v.strip()

from fastmcp import FastMCP  # noqa: E402

# Disable SSL warnings for Intel corporate network
# (Intel uses self-signed certificates for HTTPS inspection)
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# Configure logging
logging.basicConfig(level=logging.INFO, stream=sys.stderr)
logger = logging.getLogger(__name__)

# Azure AD configuration
TENANT_ID = "46c98d88-e344-4ed4-8496-4ed7712e255d"
CLIENT_ID = "1441a063-45e1-4e47-9479-f2461278c25e"
SCOPE = ["api://1441a063-45e1-4e47-9479-f2461278c25e/access_as_user"]
LAVA_API_BASE = "https://lava-api.app.intel.com"
_VERSION = "1.0.13"
mcp = FastMCP("lava-api", version=_VERSION)

# Token cache configuration
TOKEN_CACHE_FILE = os.path.join(os.path.expanduser("~"), ".mcp_lava_token_cache.json")


class _AuthRequiredError(Exception):
    """Raised when device code authentication is required. Background poll started."""
    def __init__(self, verification_uri: str, user_code: str):
        self.verification_uri = verification_uri
        self.user_code = user_code
        super().__init__(
            f"Sign-in required (one-time only).\n\n"
            f"1. Open: {verification_uri}\n"
            f"2. Enter code: {user_code}\n\n"
            f"A browser window has been opened if available. "
            f"After signing in, retry this command."
        )


class _AuthPendingError(Exception):
    """Raised when a background auth poll is already in progress."""
    def __init__(self):
        super().__init__(
            "Authentication in progress. Please complete sign-in in your browser, then retry this command."
        )


# Background auth state: {"thread": Thread, "done": bool}
_auth_state: dict = {}

# Product name abbreviation mapping
PRODUCT_ABBREVIATIONS = {
    "dmr": "Diamond Rapids",
    "gnr": "Granite Rapids",
    "srf": "Sierra Forest",
    "cwf": "ClearWater Forest",
    "emr": "Emerald Rapids",
    "spr": "Sapphire Rapids",
}


# CSV Fallback configuration
def get_csv_fallback_dir() -> Optional[str]:
    """
    Find CSV fallback directory in this order:
    1. Environment variable LAVA_CSV_DIR
    2. Detect diamondrapids workspace
    3. Plugin's own csv directory
    """
    # Try environment variable first
    env_dir = os.environ.get('LAVA_CSV_DIR')
    if env_dir and os.path.isdir(env_dir):
        logger.info(f"Using CSV directory from LAVA_CSV_DIR: {env_dir}")
        return env_dir

    # Check known workspace CSV directories (GNR in graniterapids, DMR in diamondrapids)
    for workspace_csv in [
        r"c:\pythonsv\graniterapids\users\mkcummin\sku_analysis",
        r"c:\pythonsv\diamondrapids\users\mkcummin\sku_analysis",
    ]:
        if os.path.isdir(workspace_csv):
            logger.info(f"Found workspace CSV directory: {workspace_csv}")
            return workspace_csv

    # Check plugin's own csv directory (relative to this script)
    plugin_csv = os.path.join(os.path.dirname(__file__), "..", "csv")
    plugin_csv = os.path.abspath(plugin_csv)
    if os.path.isdir(plugin_csv):
        logger.info(f"Using plugin's CSV directory: {plugin_csv}")
        return plugin_csv

    logger.info("No CSV fallback directory found")
    return None


class CSVFallbackReader:
    """Fallback reader for LAVA CSV files when API is unavailable."""

    def __init__(self, csv_dir: str):
        self.csv_dir = csv_dir
        self.data: Dict[str, Dict[str, str]] = {}  # {qdf: {column: value}}
        self.headers: List[str] = []
        self._load_csvs()

    def _load_csvs(self):
        """Load GNR and DMR CSV files from primary dir and sibling platform dirs."""
        # Build search dirs: primary + sibling platform workspace paths
        search_dirs = [self.csv_dir]
        for platform in ['graniterapids', 'diamondrapids']:
            candidate = re.sub(r'(graniterapids|diamondrapids)', platform,
                               self.csv_dir, flags=re.IGNORECASE)
            if candidate != self.csv_dir and os.path.isdir(candidate):
                search_dirs.append(candidate)

        csv_files = ['gnr_lava.csv', 'dmr_lava.csv']

        for csv_file in csv_files:
            csv_path = None
            for search_dir in search_dirs:
                candidate = os.path.join(search_dir, csv_file)
                if os.path.exists(candidate):
                    csv_path = candidate
                    break
            if not csv_path:
                logger.warning(f"CSV file not found in any search dir: {csv_file}")
                continue

            try:
                with open(csv_path, 'r', encoding='utf-8-sig') as f:
                    reader = csv.reader(f)

                    # Skip first row (category headers)
                    next(reader)

                    # Second row is column names
                    self.headers = next(reader)

                    # Load data rows
                    for row in reader:
                        if len(row) > 1 and row[1]:  # Check QDF field exists
                            qdf = row[1].strip()
                            if qdf:
                                # Map column names to values
                                row_data = {}
                                for i, header in enumerate(self.headers):
                                    if i < len(row):
                                        row_data[header] = row[i]
                                self.data[qdf] = row_data

                logger.info(f"Loaded {len(self.data)} SKUs from {csv_file}")

            except Exception as e:
                logger.error(f"Error loading CSV {csv_path}: {e}")

    def _get_field(self, row_data: dict, *field_names) -> str:
        """Try multiple field name variants (case-insensitive). Returns first non-empty match."""
        lower_data = {k.lower(): v for k, v in row_data.items()}
        for name in field_names:
            val = lower_data.get(name.lower(), '')
            if val and val.strip():
                return val.strip()
        return None

    def get_line_items_by_qdf(self, qdf: str) -> dict:
        """
        Get CPU specifications by QDF from CSV.
        Returns data in API-compatible format.
        """
        if qdf not in self.data:
            return {
                "error": f"QDF not found in CSV fallback: {qdf}",
                "source": "csv_fallback"
            }

        row_data = self.data[qdf]

        # Map CSV columns to API-like format
        # Each field tries multiple name variants: GNR-style (UPPER_SNAKE_CASE) + DMR-style (Title Case)
        specs = {}

        # Core specifications
        val = self._get_field(row_data, 'FUNCTIONAL_CORE', 'Functional Core', 'Core_Count')
        if val:
            specs['Core_Count'] = val

        val = self._get_field(row_data, 'THERMAL_DESIGN_POWER', 'Thermal Design Power', 'TDP')
        if val:
            specs['TDP'] = val

        val = self._get_field(row_data, 'MAX_TURBO_FREQ_RTE', 'Max Turbo Frequency Rate', 'MAXIMUM IA FREQUENCY RATE')
        if val:
            specs['Max_Turbo'] = val

        val = self._get_field(row_data, 'MINIMUM IA FREQUENCY RATE', 'BASE_FREQ',
                              'CPU_SPEED_IN_LOW_FREQ_MODE', 'CPU SPEED IN LOW FREQ MODE')
        if val:
            specs['Base_Freq'] = val

        val = self._get_field(row_data, 'PS_EXTERNAL_STEP', 'PS_STEP',
                              'INTERNAL REV STEP', 'EXTERNAL_REV', 'EXTERNAL_REVISION', 'Stepping')
        if val and re.match(r'^[A-Za-z]\d*$', val.strip()):
            specs['Stepping'] = val

        val = self._get_field(row_data, 'MM_CACHE', 'Cache')
        if val:
            specs['Cache'] = val

        val = self._get_field(row_data, 'IO_CACHE_AGENT', 'IO Cache Agent')
        if val:
            specs['IO_Cache_Agent'] = val

        # Memory specifications
        val = self._get_field(row_data, 'MEMORY_CHANNELS', 'FUNCTIONAL MEMORY CHANNELS', 'No Memory Channels Supported')
        if val:
            specs['Memory_Channels'] = val

        val = self._get_field(row_data, 'MCR_FREQ', 'MCR Freq')
        if val:
            specs['MCR_Freq'] = val

        val = self._get_field(row_data, 'MEMORY_TYPE_SUPPORTED', 'Memory Type Supported')
        if val:
            specs['Memory_Type'] = val

        val = self._get_field(row_data, 'LOW POWER DDR5 FREQ RATE', 'DDR_FREQ', 'MEMORY FREQUENCY RATE',
                              'Memory1 Data Rate', 'SSTPP0 DDR FREQ', 'SSTPP0_DDR_FREQ')
        if val:
            specs['DDR_Freq'] = val

        # Connectivity
        val = self._get_field(row_data, 'MAX_UPI_PORT_CNT', 'Max UPI Port Cnt')
        if val:
            specs['UPI_Ports'] = val

        val = self._get_field(row_data, 'UPI_SPEED', 'UPI Speed')
        if val:
            specs['UPI_Speed'] = val

        val = self._get_field(row_data, 'PEG_LANE_CONFIG', 'PEG Lane Config', 'MAX_PEG_LANE_CNT', 'MAXIMUM PEG LANE COUNT')
        if val:
            specs['PCIe_Lanes'] = val

        val = self._get_field(row_data, 'MAX_PEG_LANE_SPEED', 'Max PEG Lane Speed')
        if val:
            specs['PCIe_Speed'] = val

        # Accelerators
        val = self._get_field(row_data, 'QAT_DEVICES_ENABLED', 'QAT Devices Enabled')
        if val:
            specs['QAT'] = val

        val = self._get_field(row_data, 'DSA_DEVICES_ENABLED', 'DSA Devices Enabled')
        if val:
            specs['DSA'] = val

        val = self._get_field(row_data, 'IAA_DEVICES_ENABLED', 'IAA Devices Enabled')
        if val:
            specs['IAA'] = val

        # SST (Speed Select Technology)
        val = self._get_field(row_data, 'SSTPP_IND', 'SSTPP IND')
        if val:
            specs['SST_PP'] = val

        val = self._get_field(row_data, 'SSTBF_IND', 'SSTBF_SOFT_SKU_IND', 'SSTBF IND')
        if val:
            specs['SST_BF'] = val

        val = self._get_field(row_data, 'SSTTF_ENABLE', 'SSTTF ENABLE')
        if val:
            specs['SST_TF'] = val

        val = self._get_field(row_data, 'SSTCP_ENABLE', 'SSTCP ENABLE')
        if val:
            specs['SST_CP'] = val

        return {
            "qdf": qdf,
            "items": [{
                "lineItemId": "N/A",
                "qdf": qdf,
                "source": "CSV Fallback",
                "lineItemGroups": [],
                "specifications": specs
            }],
            "count": 1,
            "dataSource": "csv_fallback"
        }


class LavaAPIClient:
    """Client for Lava API with Azure AD authentication."""

    def __init__(self):
        self.access_token: Optional[str] = None

        # Initialize token cache
        self.cache = msal.SerializableTokenCache()

        # Load existing cache if available
        if os.path.exists(TOKEN_CACHE_FILE):
            try:
                with open(TOKEN_CACHE_FILE, 'r') as f:
                    self.cache.deserialize(f.read())
                logger.info("Loaded token cache from disk")
            except Exception as e:
                logger.warning(f"Failed to load token cache: {e}")

        # Initialize MSAL app with cache
        self.app = msal.PublicClientApplication(
            CLIENT_ID,
            **build_msal_app_kwargs(self.cache)
        )

    def _save_cache(self):
        """Save token cache to disk."""
        if self.cache.has_state_changed:
            try:
                with open(TOKEN_CACHE_FILE, 'w') as f:
                    f.write(self.cache.serialize())
                logger.info("Saved token cache to disk")
            except Exception as e:
                logger.error(f"Failed to save token cache: {e}")

    def get_access_token(self) -> str:
        """Get Azure AD access token (cached or via device code flow)."""
        # Try to acquire token silently from cache
        accounts = self.app.get_accounts()
        if accounts:
            logger.info(f"Found {len(accounts)} cached account(s), attempting silent token acquisition...")
            result = self.app.acquire_token_silent(SCOPE, account=accounts[0])
            if result and "access_token" in result:
                logger.info("✓ Using cached access token (no authentication needed)")
                self._save_cache()  # Save any updated cache state
                return result["access_token"]
            else:
                logger.warning("Silent token acquisition failed, will request new token")

        # Check if a background auth poll is already in progress
        thread = _auth_state.get("thread")
        if thread and thread.is_alive():
            raise _AuthPendingError()

        # Use device code flow — non-blocking: starts background poll, returns immediately
        logger.info("No cached token available, initiating device code flow...")

        try:
            flow = self.app.initiate_device_flow(scopes=SCOPE)

            if "user_code" not in flow:
                raise Exception(f"Failed to create device flow: {flow.get('error_description', 'Unknown error')}")

            # Print device code instructions to stderr (visible to user)
            print("\n" + "="*60, file=sys.stderr)
            print("  LAVA API AUTHENTICATION (One-time only)", file=sys.stderr)
            print("="*60, file=sys.stderr)
            print(flow["message"], file=sys.stderr)
            print("  (Future calls will use cached token)", file=sys.stderr)
            print("="*60 + "\n", file=sys.stderr)
            webbrowser.open(flow["verification_uri"])

            logger.info(f"Device code: {flow['user_code']}")

            # Start background thread to wait for token (non-blocking)
            def _bg_acquire(client_ref, f):
                global _auth_state
                try:
                    result = client_ref.app.acquire_token_by_device_flow(f)
                    if "access_token" in result:
                        client_ref._save_cache()
                        logger.info("Background auth: token acquired and cached.")
                        print("\n✓ Authentication successful! Token cached.\n", file=sys.stderr)
                    else:
                        logger.error(f"Background auth failed: {result.get('error_description', result.get('error'))}")
                except Exception as bg_e:
                    logger.error(f"Background auth error: {bg_e}")
                finally:
                    _auth_state["done"] = True

            t = threading.Thread(target=_bg_acquire, args=(self, flow), daemon=True)
            _auth_state["thread"] = t
            _auth_state["done"] = False
            t.start()

            raise _AuthRequiredError(flow["verification_uri"], flow["user_code"])

        except (_AuthRequiredError, _AuthPendingError):
            raise
        except Exception as e:
            logger.error(f"Error during authentication: {e}", exc_info=True)
            raise

    def api_request(self, endpoint: str, params: Optional[dict] = None) -> Any:
        """Make authenticated request to Lava API."""
        token = self.get_access_token()
        headers = {
            "Authorization": f"Bearer {token}",
            "Accept": "application/json"
        }

        url = f"{LAVA_API_BASE}{endpoint}"
        logger.info(f"API request: {url}")

        # Disable SSL verification for Intel corporate network
        # (Intel uses self-signed certificates for traffic inspection)
        # Set timeout to prevent hanging (30 seconds)
        try:
            response = requests.get(
                url,
                headers=headers,
                params=params,
                timeout=30,
                verify=False  # Required for Intel corporate proxy with self-signed certs
            )
            response.raise_for_status()
            return response.json()
        except requests.exceptions.SSLError as e:
            logger.error(f"SSL Error - this may indicate missing Intel CA certificates: {e}")
            raise


# Global client instance
client = LavaAPIClient()

# Initialize CSV fallback reader if directory exists
csv_fallback: Optional[CSVFallbackReader] = None
csv_dir = get_csv_fallback_dir()
if csv_dir:
    try:
        csv_fallback = CSVFallbackReader(csv_dir)
        logger.info(f"CSV fallback initialized with {len(csv_fallback.data)} SKUs")
    except Exception as e:
        logger.warning(f"Failed to initialize CSV fallback: {e}")
else:
    logger.info("CSV fallback not available (no CSV directory found)")


def is_valid_stepping(v: str) -> bool:
    """Return True only for stepping values like 'A0', 'B1', 'C0', or single-letter 'B'.

    Rejects purely numeric values like '1', '2' which are internal revision numbers,
    not human-readable stepping identifiers.
    """
    return bool(v and re.match(r'^[A-Za-z]\d*$', v.strip()))


def format_line_item_attributes(collections: list) -> dict:
    """Extract key attributes from line item collections."""
    result = {}

    for collection in collections:
        collection_name = collection.get("collectionName", "")
        attributes = collection.get("attributes", [])

        if collection_name == "Line_Item_Data":
            for attr in attributes:
                attr_name = attr.get("attributeName", "")
                attr_value = attr.get("attributeValue", "")
                if attr_name == "QDF_SSPEC":
                    result["QDF"] = attr_value
                elif attr_name in ("EXTERNAL_REV", "EXTERNAL_REVISION"):
                    if is_valid_stepping(attr_value):
                        result["Stepping"] = attr_value
                elif attr_name in ("EXTERNAL_STEP", "External Step"):
                    if "Stepping" not in result and is_valid_stepping(attr_value):
                        result["Stepping"] = attr_value

        elif collection_name == "Marketing":
            # Extract common CPU specs
            for attr in attributes:
                name = attr.get("attributeName", "")
                value = attr.get("attributeValue", "")

                # SST (Speed Select Technology) - check BEFORE _IND skip
                # because SSTPP_IND and SSTBF_IND end with _IND
                if name == "SSTPP_IND":
                    result["SST_PP"] = value   # Performance Profile
                    continue
                elif name == "SSTTF_ENABLE":
                    result["SST_TF"] = value   # Turbo Frequency
                    continue
                elif name in ("SSTBF_IND", "SSTBF_SOFT_SKU_IND"):
                    result["SST_BF"] = value   # Base Frequency
                    continue
                elif name == "SSTCP_ENABLE":
                    result["SST_CP"] = value   # Core Power
                    continue

                # Stepping - in Marketing collection
                elif name == "INTERNAL_REV_STEP":
                    if is_valid_stepping(value):
                        result["Stepping"] = value
                    continue
                elif name in ("PS_EXTERNAL_STEP", "PS-STEP"):
                    if "Stepping" not in result and is_valid_stepping(value):
                        result["Stepping"] = value
                    continue

                # Skip unit-of-measure and indicator fields (not numeric spec values)
                if "UOM" in name or name.endswith("_IND") or name.endswith("_UNIT"):
                    continue

                def is_numeric(v):
                    try:
                        float(v)
                        return True
                    except (ValueError, TypeError):
                        return False

                # Basic specs — require numeric values to avoid matching UOM/flag attributes
                if "FUNCTIONAL_CORE" in name:
                    if is_numeric(value) and int(float(value)) > 0:
                        result["Core_Count"] = value
                elif "THERMAL_DESIGN_POWER" in name or name == "TDP":
                    if is_numeric(value) and float(value) > 0:
                        result["TDP"] = value
                elif "TURBO" in name and "FREQ" in name:
                    # Only keep non-zero turbo frequencies (SSTPP_TURBO_MAX_3_FREQ etc. may be 0)
                    if is_numeric(value) and float(value) > 0:
                        result["Max_Turbo"] = value
                elif "CPU_SPEED_IN_LOW_FREQ_MODE" in name:
                    if is_numeric(value) and float(value) > 0:
                        result["Base_Freq"] = value
                elif "MM_CACHE" in name or "MM-CACHE" in name or ("CACHE" in name and "SIZE" in name):
                    if is_numeric(value) and float(value) > 0:
                        result["Cache"] = value
                elif name == "IO_CACHE_AGENT":
                    if is_numeric(value) and float(value) > 0:
                        result["IO_Cache_Agent"] = value

                # Memory
                elif "MEMORY_CHANNELS" in name:
                    if is_numeric(value) and int(float(value)) > 0:
                        result["Memory_Channels"] = value
                elif "DDR" in name and "FREQ" in name:
                    if is_numeric(value) and int(float(value)) > 0:
                        result["DDR_Freq"] = value
                elif "MCR_FREQ" in name:
                    if is_numeric(value) and int(float(value)) > 0:
                        result["MCR_Freq"] = value

                # Connectivity
                elif "UPI" in name and "PORT" in name:
                    if is_numeric(value):
                        result["UPI_Ports"] = value
                elif "UPI_SPEED" in name:
                    if is_numeric(value):
                        result["UPI_Speed"] = value
                elif ("PCIE" in name or "PEG" in name) and "SPEED" in name:
                    result["PCIe_Speed"] = value
                elif ("PCIE" in name or "PEG" in name) and "LANE" in name:
                    result["PCIe_Lanes"] = value  # may have suffix like "88A"

                # Accelerators
                elif "QAT" in name and "DEVICE" in name:
                    if is_numeric(value):
                        result["QAT"] = value
                elif "DSA" in name and "DEVICE" in name:
                    if is_numeric(value):
                        result["DSA"] = value
                elif "IAA" in name and "DEVICE" in name:
                    if is_numeric(value):
                        result["IAA"] = value

        elif collection_name == "Roadmap":
            for attr in attributes:
                attr_name = attr.get("attributeName", "")
                attr_value = attr.get("attributeValue", "")
                if "STEPPING" in attr_name.upper() or "REVISION" in attr_name.upper():
                    if "Stepping" not in result and is_valid_stepping(attr_value):
                        result["Stepping"] = attr_value

    # --- SST Per-Profile Frequencies (second pass over Marketing) ---
    pp_raw = {}   # pp_raw[0] = {"AVX2_MAX_TURBO": "3.2", ...}
    bf_raw = {}
    for collection in collections:
        if collection.get("collectionName") != "Marketing":
            continue
        for attr in collection.get("attributes", []):
            name = attr.get("attributeName", "")
            value = attr.get("attributeValue", "")
            if not value or value == "N/A":
                continue

            # SST-PP profiles: SSTPP0_AVX2_MAX_TURBO, SSTPP1_TDP, etc.
            m = re.match(r'^SSTPP(\d+)_(.+)$', name)
            if m:
                idx = int(m.group(1))
                field = m.group(2)
                if idx not in pp_raw:
                    pp_raw[idx] = {}
                pp_raw[idx][field] = value
                continue

            # SST-BF configs: SSTBF_CFG_0_P1_HI..., SSTBF_CFG0_P1_LOW...
            m = re.match(r'^SSTBF_?CFG_?(\d+)_(.+)$', name)
            if m:
                idx = int(m.group(1))
                field = m.group(2)
                if idx not in bf_raw:
                    bf_raw[idx] = {}
                bf_raw[idx][field] = value

    # Build SST_Profiles from active PP profiles
    _PP_FIELDS = {
        "AVX2_MAX_TURBO": "avx2_max_turbo",
        "AVX512_MAX_TURBO": "avx512_max_turbo",
        "AMX_MAX_TURBO": "amx_max_turbo",
        "AVX512H_MAX_TURBO": "avx512h_max_turbo",
        "ALL_CORE_TURBO": "all_core_turbo",
        "AVX2_P1": "avx2_base",
        "AVX512_P1": "avx512_base",
        "AMX_P1": "amx_base",
        "TDP": "tdp",
        "DDR_FREQ": "ddr_freq",
    }
    profiles = []
    for idx in sorted(pp_raw.keys()):
        raw = pp_raw[idx]
        act = raw.get("ALL_CORE_TURBO", "0")
        try:
            if float(act) <= 0:
                continue
        except (ValueError, TypeError):
            continue
        profile = {"id": idx}
        for src_key, dst_key in _PP_FIELDS.items():
            if src_key in raw:
                profile[dst_key] = raw[src_key]
        profiles.append(profile)

    if profiles:
        result["SST_Profiles"] = profiles

    # Build SST_BF_Freq from config 0
    if 0 in bf_raw:
        bf = bf_raw[0]
        bf_freq = {}
        for k, v in bf.items():
            if "HI_PRIORITY" in k:
                bf_freq["hi_freq"] = v
            elif "LOW_PRIORITY" in k:
                bf_freq["lo_freq"] = v
            elif "High_Core_Count" in k:
                bf_freq["hi_core_count"] = v
        if bf_freq:
            result["SST_BF_Freq"] = bf_freq

    return result


def tool_get_line_items_by_qdf(qdf: str) -> dict:
    """
    Get CPU line items by QDF code.

    Args:
        qdf: QDF/SSPEC code (e.g., Q9JT, L1CY)

    Returns:
        Line item data with CPU specifications
    """
    try:
        endpoint = f"/api/v2/line_items/qdf/{qdf}"
        data = client.api_request(endpoint)

        if not data:
            return {"error": f"No data found for QDF: {qdf}"}

        # Format the response
        results = []
        for item in data:
            formatted = {
                "lineItemId": item.get("lineItemId", ""),
                "qdf": item.get("qdfSspec", ""),
                "source": item.get("source", ""),
                "lineItemGroups": item.get("lineItemGroups", []),
                "specifications": format_line_item_attributes(item.get("collections", []))
            }
            results.append(formatted)

        return {"qdf": qdf, "items": results, "count": len(results)}

    except requests.exceptions.Timeout:
        logger.error(f"API timeout for QDF: {qdf}")
        if csv_fallback:
            logger.info(f"Falling back to CSV for QDF: {qdf}")
            return csv_fallback.get_line_items_by_qdf(qdf)
        return {"error": "API request timeout (>30s). Check VPN connection to Intel network."}
    except requests.exceptions.ConnectionError:
        logger.error(f"Connection error for QDF: {qdf}")
        if csv_fallback:
            logger.info(f"Falling back to CSV for QDF: {qdf}")
            return csv_fallback.get_line_items_by_qdf(qdf)
        return {"error": "Connection failed. Ensure you're connected to Intel VPN."}
    except requests.exceptions.HTTPError as e:
        if e.response.status_code == 404:
            # Try CSV fallback for 404 as well
            if csv_fallback:
                logger.info(f"QDF not found in API, trying CSV fallback: {qdf}")
                return csv_fallback.get_line_items_by_qdf(qdf)
            return {"error": f"QDF not found: {qdf}"}
        if csv_fallback:
            logger.info(f"API error, falling back to CSV for QDF: {qdf}")
            return csv_fallback.get_line_items_by_qdf(qdf)
        return {"error": f"API error: {str(e)}"}
    except Exception as e:
        if isinstance(e, (_AuthRequiredError, _AuthPendingError)):
            raise
        logger.error(f"Error in tool_get_line_items_by_qdf: {e}", exc_info=True)
        if csv_fallback:
            logger.info(f"Unexpected error, falling back to CSV for QDF: {qdf}")
            return csv_fallback.get_line_items_by_qdf(qdf)
        return {"error": str(e)}


def tool_get_qdfs_by_pdmid(pdmid: str) -> dict:
    """
    Get all QDFs for a Product Data Management ID.

    Args:
        pdmid: Product Data Management variant item ID (e.g., 10047749)

    Returns:
        List of QDFs from Lava and Liport
    """
    try:
        endpoint = f"/api/v2/line_items/pdmId/qdfs_by_product/{pdmid}"
        data = client.api_request(endpoint)

        return {
            "pdmId": pdmid,
            "lavaQdfs": data.get("lavaQdfs", []),
            "liportQdfs": data.get("liportQdfs", [])
        }

    except requests.exceptions.HTTPError as e:
        if e.response.status_code == 404:
            return {"error": f"PdmId not found: {pdmid}"}
        return {"error": f"API error: {str(e)}"}
    except Exception as e:
        if isinstance(e, (_AuthRequiredError, _AuthPendingError)):
            raise
        logger.error(f"Error in tool_get_qdfs_by_pdmid: {e}", exc_info=True)
        return {"error": str(e)}


def tool_get_line_items_by_pdmid(pdmid: str) -> dict:
    """
    Get all line items for a Product Data Management ID.

    Args:
        pdmid: Product Data Management variant item ID

    Returns:
        All line items for the product
    """
    try:
        endpoint = f"/api/v2/line_items/pdmId/{pdmid}"
        data = client.api_request(endpoint)

        if not data:
            return {"error": f"No data found for PdmId: {pdmid}"}

        # Format the response
        results = []
        for item in data:
            formatted = {
                "lineItemId": item.get("lineItemId", ""),
                "qdf": item.get("qdfSspec", ""),
                "source": item.get("source", ""),
                "lineItemGroups": item.get("lineItemGroups", []),
                "specifications": format_line_item_attributes(item.get("collections", []))
            }
            results.append(formatted)

        return {
            "pdmId": pdmid,
            "items": results,
            "count": len(results),
            "_spec_note": (
                "WARNING: Bulk query specs may be incomplete — UPI_Ports, PCIe_Lanes, "
                "DSA/IAA/QAT fields are often missing. "
                "Use get_line_items_by_qdf per QDF for complete specs when presenting details to the user."
            )
        }

    except requests.exceptions.HTTPError as e:
        if e.response.status_code == 404:
            return {"error": f"PdmId not found: {pdmid}"}
        return {"error": f"API error: {str(e)}"}
    except Exception as e:
        if isinstance(e, (_AuthRequiredError, _AuthPendingError)):
            raise
        logger.error(f"Error in tool_get_line_items_by_pdmid: {e}", exc_info=True)
        return {"error": str(e)}


def tool_get_line_items_by_qdfs_and_pdmid(pdmid: str, qdfs: str) -> dict:
    """
    Get line items from Lava for specific QDFs within a product.
    More efficient than calling get_line_items_by_qdf per QDF.

    Args:
        pdmid: Product Data Management variant item ID (e.g., 10047337)
        qdfs: Comma-separated QDF codes (e.g., "Q99D,Q7UE,Q7UC")

    Returns:
        Line items with specifications for the requested QDFs
    """
    try:
        endpoint = f"/api/v2/line_items/pdmId/lava/{pdmid}"
        params = {"qdfs": qdfs}
        data = client.api_request(endpoint, params=params)

        if not data:
            return {"error": f"No data found for PdmId={pdmid} with QDFs={qdfs}"}

        results = []
        for item in data:
            formatted = {
                "lineItemId": item.get("lineItemId", ""),
                "qdf": item.get("qdfSspec", ""),
                "source": item.get("source", ""),
                "lineItemGroups": item.get("lineItemGroups", []),
                "specifications": format_line_item_attributes(item.get("collections", []))
            }
            results.append(formatted)

        return {"pdmId": pdmid, "requestedQdfs": qdfs, "items": results, "count": len(results)}

    except requests.exceptions.HTTPError as e:
        if e.response.status_code == 404:
            return {"error": f"PdmId not found: {pdmid}"}
        return {"error": f"API error: {str(e)}"}
    except Exception as e:
        if isinstance(e, (_AuthRequiredError, _AuthPendingError)):
            raise
        logger.error(f"Error in tool_get_line_items_by_qdfs_and_pdmid: {e}", exc_info=True)
        return {"error": str(e)}


def tool_get_product_names() -> dict:
    """
    Get all product data management names.

    Returns:
        List of products with PDM IDs and variant names
    """
    try:
        endpoint = "/api/v2/product/product_data_management_name"
        data = client.api_request(endpoint)

        return {"products": data, "count": len(data)}

    except requests.exceptions.Timeout:
        logger.error("API timeout getting product names (this endpoint returns large data)")
        return {"error": "API request timeout. This endpoint returns all products and may be slow. Check VPN connection."}
    except requests.exceptions.ConnectionError:
        logger.error("Connection error getting product names")
        return {"error": "Connection failed. Ensure you're connected to Intel VPN."}
    except Exception as e:
        if isinstance(e, (_AuthRequiredError, _AuthPendingError)):
            raise
        logger.error(f"Error in tool_get_product_names: {e}", exc_info=True)
        return {"error": str(e)}


def tool_search_product_by_name(product_name: str) -> dict:
    """
    Search for products by name and return matching PDM IDs.

    Args:
        product_name: Product name to search for (e.g., "Granite Rapids", "GNR", "DMR")
                      Case-insensitive, supports partial matching and abbreviations.
                      Supported abbreviations: DMR, GNR, SRF, CWF, EMR, SPR

    Returns:
        List of matching products with PDM IDs
    """
    try:
        endpoint = "/api/v2/product/product_data_management_name"
        data = client.api_request(endpoint)

        # Expand abbreviations if provided
        search_term = product_name.lower()
        expanded_term = PRODUCT_ABBREVIATIONS.get(search_term, search_term)

        # If abbreviation was expanded, log it
        if expanded_term != search_term:
            logger.info(f"Expanded abbreviation '{product_name}' → '{expanded_term}'")

        # Search for matching products (case-insensitive)
        matches = []

        for product in data:
            variant_name = product.get("variantName", "")
            if expanded_term.lower() in variant_name.lower():
                matches.append({
                    "pdmId": product.get("productDataManagementId", ""),
                    "variantName": variant_name
                })

        if not matches:
            return {
                "error": f"No products found matching '{product_name}'",
                "suggestion": "Try: 'Granite Rapids' / 'GNR', 'Diamond Rapids' / 'DMR', 'Sierra Forest' / 'SRF', etc."
            }

        return {
            "searchTerm": product_name,
            "expandedTerm": expanded_term if expanded_term != search_term else None,
            "matches": matches,
            "count": len(matches)
        }

    except requests.exceptions.Timeout:
        logger.error(f"API timeout searching for product: {product_name}")
        return {"error": "API request timeout. Check VPN connection."}
    except requests.exceptions.ConnectionError:
        logger.error(f"Connection error searching for product: {product_name}")
        return {"error": "Connection failed. Ensure you're connected to Intel VPN."}
    except Exception as e:
        if isinstance(e, (_AuthRequiredError, _AuthPendingError)):
            raise
        logger.error(f"Error in tool_search_product_by_name: {e}", exc_info=True)
        return {"error": str(e)}


def tool_search_line_items(
    product_name: str,
    min_cores: Optional[int] = None,
    max_cores: Optional[int] = None,
    min_tdp: Optional[int] = None,
    max_tdp: Optional[int] = None,
    min_turbo: Optional[float] = None,
    max_turbo: Optional[float] = None,
    min_upi_ports: Optional[int] = None,
    max_upi_ports: Optional[int] = None,
    min_upi_speed: Optional[int] = None,
    max_upi_speed: Optional[int] = None,
    min_pcie_lanes: Optional[int] = None,
    max_pcie_lanes: Optional[int] = None,
    min_pcie_speed: Optional[int] = None,
    max_pcie_speed: Optional[int] = None,
    min_ddr_freq: Optional[int] = None,
    max_ddr_freq: Optional[int] = None,
    min_mcr_freq: Optional[int] = None,
    max_mcr_freq: Optional[int] = None,
    sst_bf_enabled: Optional[bool] = None,
    sst_cp_enabled: Optional[bool] = None,
    sst_pp_enabled: Optional[bool] = None,
    sst_tf_enabled: Optional[bool] = None,
    exclude_vis: Optional[bool] = None,
    exclude_unfused: Optional[bool] = None,
) -> dict:
    """
    Search for CPU SKUs matching specification criteria.

    Efficient batch query - much faster than querying individual QDFs.
    Use this for queries like "DMR SKUs with core count > 32" or "GNR with TDP < 300W".

    Args:
        product_name: Product name or abbreviation (e.g., "DMR", "Granite Rapids")
        min_cores: Minimum core count (inclusive)
        max_cores: Maximum core count (inclusive)
        min_tdp: Minimum TDP in Watts (inclusive)
        max_tdp: Maximum TDP in Watts (inclusive)
        min_turbo: Minimum turbo frequency in GHz (inclusive)
        max_turbo: Maximum turbo frequency in GHz (inclusive)
        min_upi_ports: Minimum UPI port count (inclusive)
        max_upi_ports: Maximum UPI port count (inclusive)
        min_upi_speed: Minimum UPI speed in GT/s (inclusive)
        max_upi_speed: Maximum UPI speed in GT/s (inclusive)
        min_pcie_lanes: Minimum PCIe lane count (inclusive)
        max_pcie_lanes: Maximum PCIe lane count (inclusive)
        min_pcie_speed: Minimum PCIe speed (Gen5=5, Gen6=6) (inclusive)
        max_pcie_speed: Maximum PCIe speed (Gen5=5, Gen6=6) (inclusive)
        min_ddr_freq: Minimum DDR5 frequency in MHz (inclusive)
        max_ddr_freq: Maximum DDR5 frequency in MHz (inclusive)
        min_mcr_freq: Minimum MRDIMM (MCR) frequency in MHz (inclusive)
        max_mcr_freq: Maximum MRDIMM (MCR) frequency in MHz (inclusive)
        sst_bf_enabled: Filter by SST-BF (Base Frequency) status (True=ENABLED, False=DISABLED)
        sst_cp_enabled: Filter by SST-CP (Core Power) status (True=ENABLED, False=DISABLED)
        sst_pp_enabled: Filter by SST-PP (Perf-per-Watt) status (True=ENABLED, False=DISABLED)
        sst_tf_enabled: Filter by SST-TF (Turbo Frequency) status (True=ENABLED, False=DISABLED)
        exclude_vis: Exclude VIS parts based on product and line item metadata
        exclude_unfused: Exclude explicitly unfused parts based on line item metadata

    Returns:
        Filtered list of line items matching criteria with full specifications

    Examples:
        search_line_items("DMR", min_cores=33) → DMR SKUs with > 32 cores
        search_line_items("GNR", min_upi_speed=24) → GNR with UPI speed >= 24 GT/s
        search_line_items("DMR", min_mcr_freq=12800) → DMR with MRDIMM 12800+
        search_line_items("GNR", sst_bf_enabled=True) → GNR with SST-BF enabled
    """
    try:
        # Step 1: Search for products
        logger.info(f"Searching for product: {product_name}")
        product_result = tool_search_product_by_name(product_name)

        if "error" in product_result:
            return product_result

        # Step 2: Fetch all line items for matching products
        all_items = []
        pdm_ids = [m["pdmId"] for m in product_result.get("matches", [])]

        logger.info(f"Found {len(pdm_ids)} product variant(s), fetching line items...")

        for pdm_id in pdm_ids:
            line_items_result = tool_get_line_items_by_pdmid(pdm_id)
            if "error" not in line_items_result:
                items = line_items_result.get("items", [])
                # Add product info to each item
                for item in items:
                    item["pdmId"] = pdm_id
                    item["productName"] = next(
                        (m["variantName"] for m in product_result["matches"] if m["pdmId"] == pdm_id),
                        ""
                    )
                all_items.extend(items)

        logger.info(f"Fetched {len(all_items)} total line items, applying filters...")

        # Step 3: Filter by criteria
        filtered = []

        def item_metadata_text(item: dict) -> str:
            metadata_parts = [
                item.get("qdf", ""),
                item.get("source", ""),
                item.get("productName", ""),
                item.get("lineItemId", ""),
            ]
            metadata_parts.extend(item.get("lineItemGroups", []))
            return " ".join(str(part) for part in metadata_parts if part).upper()

        for item in all_items:
            specs = item.get("specifications", {})
            metadata_text = item_metadata_text(item)

            # Parse numeric values (handle empty strings)
            def parse_num(val, is_float=False):
                if not val or val == "":
                    return None
                try:
                    return float(val) if is_float else int(float(val))
                except (ValueError, TypeError):
                    return None

            # Parse PCIe lanes (may have suffix like "88A")
            def parse_pcie_lanes(val):
                if not val or val == "":
                    return None
                try:
                    # Remove non-digit suffix (e.g., "88A" -> 88)
                    import re
                    match = re.match(r'(\d+)', str(val))
                    return int(match.group(1)) if match else None
                except (ValueError, TypeError):
                    return None

            core_count = parse_num(specs.get("Core_Count"))
            tdp = parse_num(specs.get("TDP"))
            max_turbo_val = parse_num(specs.get("Max_Turbo"), is_float=True)
            upi_ports = parse_num(specs.get("UPI_Ports"))
            upi_speed = parse_num(specs.get("UPI_Speed"))
            pcie_lanes = parse_pcie_lanes(specs.get("PCIe_Lanes"))
            pcie_speed = parse_num(specs.get("PCIe_Speed"))
            ddr_freq = parse_num(specs.get("DDR_Freq"))
            mcr_freq = parse_num(specs.get("MCR_Freq"))

            # Apply filters
            if min_cores is not None and (core_count is None or core_count < min_cores):
                continue
            if max_cores is not None and (core_count is None or core_count > max_cores):
                continue
            if min_tdp is not None and (tdp is None or tdp < min_tdp):
                continue
            if max_tdp is not None and (tdp is None or tdp > max_tdp):
                continue
            if min_turbo is not None and (max_turbo_val is None or max_turbo_val < min_turbo):
                continue
            if max_turbo is not None and (max_turbo_val is None or max_turbo_val > max_turbo):
                continue
            if min_upi_ports is not None and (upi_ports is None or upi_ports < min_upi_ports):
                continue
            if max_upi_ports is not None and (upi_ports is None or upi_ports > max_upi_ports):
                continue
            if min_upi_speed is not None and (upi_speed is None or upi_speed < min_upi_speed):
                continue
            if max_upi_speed is not None and (upi_speed is None or upi_speed > max_upi_speed):
                continue
            if min_pcie_lanes is not None and (pcie_lanes is None or pcie_lanes < min_pcie_lanes):
                continue
            if max_pcie_lanes is not None and (pcie_lanes is None or pcie_lanes > max_pcie_lanes):
                continue
            if min_pcie_speed is not None and (pcie_speed is None or pcie_speed < min_pcie_speed):
                continue
            if max_pcie_speed is not None and (pcie_speed is None or pcie_speed > max_pcie_speed):
                continue
            if min_ddr_freq is not None and (ddr_freq is None or ddr_freq < min_ddr_freq):
                continue
            if max_ddr_freq is not None and (ddr_freq is None or ddr_freq > max_ddr_freq):
                continue
            if min_mcr_freq is not None and (mcr_freq is None or mcr_freq < min_mcr_freq):
                continue
            if max_mcr_freq is not None and (mcr_freq is None or mcr_freq > max_mcr_freq):
                continue

            # SST (Speed Select Technology) filters
            # Values are "ENABLED" or "DISABLED" strings
            if sst_bf_enabled is not None:
                sst_bf = specs.get("SST_BF", "").upper()
                expected = "ENABLED" if sst_bf_enabled else "DISABLED"
                if sst_bf != expected:
                    continue

            if sst_cp_enabled is not None:
                sst_cp = specs.get("SST_CP", "").upper()
                expected = "ENABLED" if sst_cp_enabled else "DISABLED"
                if sst_cp != expected:
                    continue

            if sst_pp_enabled is not None:
                sst_pp = specs.get("SST_PP", "").upper()
                expected = "ENABLED" if sst_pp_enabled else "DISABLED"
                if sst_pp != expected:
                    continue

            if sst_tf_enabled is not None:
                sst_tf = specs.get("SST_TF", "").upper()
                expected = "ENABLED" if sst_tf_enabled else "DISABLED"
                if sst_tf != expected:
                    continue

            if exclude_vis and "VIS" in metadata_text:
                continue

            if exclude_unfused and "UNFUSED" in metadata_text:
                continue

            filtered.append(item)

        # Build filter summary
        filters_applied = []
        if min_cores is not None:
            filters_applied.append(f"cores >= {min_cores}")
        if max_cores is not None:
            filters_applied.append(f"cores <= {max_cores}")
        if min_tdp is not None:
            filters_applied.append(f"TDP >= {min_tdp}W")
        if max_tdp is not None:
            filters_applied.append(f"TDP <= {max_tdp}W")
        if min_turbo is not None:
            filters_applied.append(f"turbo >= {min_turbo} GHz")
        if max_turbo is not None:
            filters_applied.append(f"turbo <= {max_turbo} GHz")
        if min_upi_ports is not None:
            filters_applied.append(f"UPI ports >= {min_upi_ports}")
        if max_upi_ports is not None:
            filters_applied.append(f"UPI ports <= {max_upi_ports}")
        if min_upi_speed is not None:
            filters_applied.append(f"UPI speed >= {min_upi_speed} GT/s")
        if max_upi_speed is not None:
            filters_applied.append(f"UPI speed <= {max_upi_speed} GT/s")
        if min_pcie_lanes is not None:
            filters_applied.append(f"PCIe lanes >= {min_pcie_lanes}")
        if max_pcie_lanes is not None:
            filters_applied.append(f"PCIe lanes <= {max_pcie_lanes}")
        if min_pcie_speed is not None:
            filters_applied.append(f"PCIe speed >= Gen{min_pcie_speed}")
        if max_pcie_speed is not None:
            filters_applied.append(f"PCIe speed <= Gen{max_pcie_speed}")
        if min_ddr_freq is not None:
            filters_applied.append(f"DDR freq >= {min_ddr_freq} MHz")
        if max_ddr_freq is not None:
            filters_applied.append(f"DDR freq <= {max_ddr_freq} MHz")
        if min_mcr_freq is not None:
            filters_applied.append(f"MCR freq >= {min_mcr_freq} MHz")
        if max_mcr_freq is not None:
            filters_applied.append(f"MCR freq <= {max_mcr_freq} MHz")
        if sst_bf_enabled is not None:
            filters_applied.append(f"SST-BF = {'ENABLED' if sst_bf_enabled else 'DISABLED'}")
        if sst_cp_enabled is not None:
            filters_applied.append(f"SST-CP = {'ENABLED' if sst_cp_enabled else 'DISABLED'}")
        if sst_pp_enabled is not None:
            filters_applied.append(f"SST-PP = {'ENABLED' if sst_pp_enabled else 'DISABLED'}")
        if sst_tf_enabled is not None:
            filters_applied.append(f"SST-TF = {'ENABLED' if sst_tf_enabled else 'DISABLED'}")
        if exclude_vis:
            filters_applied.append("exclude VIS parts")
        if exclude_unfused:
            filters_applied.append("exclude unfused parts")

        logger.info(f"Filtered to {len(filtered)} items matching criteria")

        return {
            "productName": product_name,
            "filtersApplied": filters_applied,
            "totalItems": len(all_items),
            "matchingItems": len(filtered),
            "items": filtered
        }

    except Exception as e:
        if isinstance(e, (_AuthRequiredError, _AuthPendingError)):
            raise
        logger.error(f"Error in tool_search_line_items: {e}", exc_info=True)
        return {"error": str(e)}


# ---------------------------------------------------------------------------
# FastMCP tool registrations
# ---------------------------------------------------------------------------

@mcp.tool()
def get_line_items_by_qdf(qdf: str) -> str:
    """Get CPU line item specifications by QDF/SSPEC code (e.g. Q9JT, L1CY).
    Returns detailed CPU specs: core count, TDP, frequency, cache, memory,
    UPI, PCIe, accelerator info, and SST support (SST-PP, SST-TF, SST-BF, SST-CP)."""
    return json.dumps(tool_get_line_items_by_qdf(qdf), indent=2)


@mcp.tool()
def get_qdfs_by_pdmid(pdmid: str) -> str:
    """Get all QDF codes for a Product Data Management ID (e.g. 10047749).
    Useful for finding all SKUs for a product."""
    return json.dumps(tool_get_qdfs_by_pdmid(pdmid), indent=2)


@mcp.tool()
def get_line_items_by_pdmid(pdmid: str) -> str:
    """Get all line items and specifications for a Product Data Management ID.
    WARNING: Bulk query specs may be incomplete. Use get_line_items_by_qdf
    per QDF for complete specs when presenting details to the user."""
    return json.dumps(tool_get_line_items_by_pdmid(pdmid), indent=2)


@mcp.tool()
def get_line_items_by_qdfs_and_pdmid(pdmid: str, qdfs: str) -> str:
    """Get line items for specific QDFs within a product (batch query).
    Much more efficient than calling get_line_items_by_qdf per QDF.
    pdmid: Product Data Management variant item ID (e.g. 10047337)
    qdfs: Comma-separated QDF codes (e.g. 'Q99D,Q7UE,Q7UC')"""
    return json.dumps(tool_get_line_items_by_qdfs_and_pdmid(pdmid, qdfs), indent=2)


@mcp.tool()
def get_product_names() -> str:
    """Get list of all products with their PDM IDs and variant names.
    Useful for discovering available products."""
    return json.dumps(tool_get_product_names(), indent=2)


@mcp.tool()
def search_product_by_name(product_name: str) -> str:
    """Search for products by name or abbreviation and get PDM IDs.
    ONLY use supported product abbreviations: DMR, GNR, SRF, CWF, EMR, SPR.
    Use this when user knows product name but not PDM ID.
    Call this BEFORE get_line_items_by_qdf when no PDM ID is known."""
    return json.dumps(tool_search_product_by_name(product_name), indent=2)


@mcp.tool()
def search_line_items(
    product_name: str,
    min_cores: Optional[int] = None,
    max_cores: Optional[int] = None,
    min_tdp: Optional[int] = None,
    max_tdp: Optional[int] = None,
    min_turbo: Optional[float] = None,
    max_turbo: Optional[float] = None,
    min_upi_ports: Optional[int] = None,
    max_upi_ports: Optional[int] = None,
    min_upi_speed: Optional[int] = None,
    max_upi_speed: Optional[int] = None,
    min_pcie_lanes: Optional[int] = None,
    max_pcie_lanes: Optional[int] = None,
    min_pcie_speed: Optional[int] = None,
    max_pcie_speed: Optional[int] = None,
    min_ddr_freq: Optional[int] = None,
    max_ddr_freq: Optional[int] = None,
    min_mcr_freq: Optional[int] = None,
    max_mcr_freq: Optional[int] = None,
    sst_bf_enabled: Optional[bool] = None,
    sst_cp_enabled: Optional[bool] = None,
    sst_pp_enabled: Optional[bool] = None,
    sst_tf_enabled: Optional[bool] = None,
    exclude_vis: Optional[bool] = None,
    exclude_unfused: Optional[bool] = None,
) -> str:
    """Search for CPU SKUs matching specification criteria. HIGHLY EFFICIENT —
    use this instead of multiple get_line_items_by_qdf calls.
    Perfect for queries like 'DMR SKUs with core count > 32' or 'GNR with TDP < 300W'.
    Performs batch query and client-side filtering.
    product_name: Product name or abbreviation (e.g. 'DMR', 'Granite Rapids', 'GNR')
    min/max_cores: Core count bounds (inclusive)
    min/max_tdp: TDP in Watts (inclusive)
    min/max_turbo: Max turbo frequency in GHz (inclusive)
    min/max_upi_ports: UPI port count (inclusive)
    min/max_upi_speed: UPI speed in GT/s (inclusive, e.g. 24 for 24 GT/s)
    min/max_pcie_lanes: PCIe lane count (inclusive)
    min/max_pcie_speed: PCIe generation (5=Gen5, 6=Gen6) (inclusive)
    min/max_ddr_freq: DDR5 frequency in MHz (inclusive, e.g. 6400)
    min/max_mcr_freq: MRDIMM frequency in MHz (inclusive, e.g. 12800)
    sst_*_enabled: Filter by SST feature status (True=ENABLED, False=DISABLED)
    exclude_vis: Exclude VIS-tagged parts
    exclude_unfused: Exclude explicitly UNFUSED-tagged parts"""
    return json.dumps(tool_search_line_items(
        product_name=product_name,
        min_cores=min_cores, max_cores=max_cores,
        min_tdp=min_tdp, max_tdp=max_tdp,
        min_turbo=min_turbo, max_turbo=max_turbo,
        min_upi_ports=min_upi_ports, max_upi_ports=max_upi_ports,
        min_upi_speed=min_upi_speed, max_upi_speed=max_upi_speed,
        min_pcie_lanes=min_pcie_lanes, max_pcie_lanes=max_pcie_lanes,
        min_pcie_speed=min_pcie_speed, max_pcie_speed=max_pcie_speed,
        min_ddr_freq=min_ddr_freq, max_ddr_freq=max_ddr_freq,
        min_mcr_freq=min_mcr_freq, max_mcr_freq=max_mcr_freq,
        sst_bf_enabled=sst_bf_enabled, sst_cp_enabled=sst_cp_enabled,
        sst_pp_enabled=sst_pp_enabled, sst_tf_enabled=sst_tf_enabled,
        exclude_vis=exclude_vis,
        exclude_unfused=exclude_unfused,
    ), indent=2)


if __name__ == "__main__":
    print(f"[lava] v{_VERSION}", file=sys.stderr, flush=True)
    mcp.run()

