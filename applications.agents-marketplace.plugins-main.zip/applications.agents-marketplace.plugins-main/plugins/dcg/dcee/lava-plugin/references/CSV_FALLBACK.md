# CSV Fallback Implementation

## Overview

Added automatic CSV fallback to lava-plugin for improved reliability when LAVA API is unavailable.

## What Changed

### New Features

1. **Automatic CSV Fallback**
   - Transparently switches to CSV when API fails
   - Supports GNR and DMR CSV files
   - Returns data in API-compatible format

2. **Flexible Configuration**
   - Environment variable: `LAVA_CSV_DIR`
   - Auto-detection of standard paths
   - Zero-configuration for standard setup

3. **Comprehensive Error Handling**
   - Timeout → CSV fallback
   - Connection error → CSV fallback
   - 404 Not Found → CSV fallback
   - Authentication failure → CSV fallback

## Files Modified

### `mcp_server.py`

**New Code:**
- `get_csv_fallback_dir()` - Directory detection logic
- `CSVFallbackReader` class - CSV parsing and data access
- Modified `tool_get_line_items_by_qdf()` - Added fallback logic

**Changes:**
- Added `csv` and `Dict, List` imports
- Initialize global `csv_fallback` instance
- All API exceptions now try CSV fallback before returning error

### `README.md`

**Added:**
- CSV Fallback feature in Features list
- New "CSV Fallback (Offline Mode)" section with setup instructions
- Fallback behavior documentation

### `CLAUDE.md`

**Added:**
- CSV Fallback in features list
- Detailed "CSV Fallback" section with technical details

## Test Results

### `test_csv_fallback.py`

**With diamondrapids workspace:**
```
✅ Auto-detected: c:\pythonsv\diamondrapids\users\mkcummin\sku_analysis
✅ Loaded 193 SKUs (DMR only)
✅ Q9JT found with TDP data
✅ Q0PE not found (GNR, not in DMR CSV)
✅ Invalid QDF handled gracefully
```

**With environment variable:**
```
✅ LAVA_CSV_DIR overrides auto-detection
✅ Can load from custom directory
✅ Supports both GNR and DMR CSVs
```

### `test_structure.py`

```
✅ All 8/8 tests passed
✅ Python syntax valid
✅ No breaking changes
```

## Usage Examples

### Default (Auto-detection - Both Workspaces)

```bash
# No configuration needed — plugin auto-detects both workspace paths
# Priority: graniterapids first, then diamondrapids
python mcp_server.py

# Log output (graniterapids found first, sibling diamondrapids also scanned):
# INFO:server:Loaded NNN SKUs from gnr_lava.csv
# INFO:server:Loaded 193 SKUs from dmr_lava.csv
# INFO:server:CSV fallback initialized with NNN SKUs
```

### Custom Path

```bash
# Set custom CSV directory
export LAVA_CSV_DIR="/path/to/csv"
python mcp_server.py
```

### Fallback in Action

```
1. User queries QDF while offline
2. API request times out
3. Plugin logs: "Falling back to CSV for QDF: Q9JT"
4. Returns data from gnr_lava.csv
5. Response includes "dataSource": "csv_fallback"
```

## Supported CSV Files

GNR and DMR use **separate CSV files in separate workspaces**:

| File | Platform | Workspace Path |
|------|----------|----------------|
| `gnr_lava.csv` | Granite Rapids | `c:\pythonsv\graniterapids\users\mkcummin\sku_analysis` |
| `dmr_lava.csv` | Diamond Rapids | `c:\pythonsv\diamondrapids\users\mkcummin\sku_analysis` |

`get_csv_fallback_dir()` checks both workspace paths (graniterapids first, then
diamondrapids). `CSVFallbackReader._load_csvs()` then also scans sibling platform
directories via regex substitution, so both CSVs are loaded automatically even when
only one workspace is present.

**CSV Format:**
- Row 1: Category headers
- Row 2: Column names
- Row 3+: Data rows

## Mapped Specifications

CSV columns mapped to API format:

| CSV Column | API Field |
|------------|-----------|
| `QDF` | `qdf` |
| `FUNCTIONAL_CORE` | `Core_Count` |
| `THERMAL_DESIGN_POWER` / `TDP` | `TDP` |
| `MAX_TURBO_FREQ_RTE` | `Max_Turbo` |
| `MM_CACHE` | `Cache` |
| `MEMORY_CHANNELS` | `Memory_Channels` |
| `MCR_FREQ` | `MCR_Freq` |
| `MEMORY_TYPE_SUPPORTED` | `Memory_Type` |
| `MAX_UPI_PORT_CNT` | `UPI_Ports` |
| `UPI_SPEED` | `UPI_Speed` |
| `MAX_PEG_LANE_CNT` | `PCIe_Lanes` |
| `QAT_DEVICES_ENABLED` | `QAT` |
| `DSA_DEVICES_ENABLED` | `DSA` |
| `IAA_DEVICES_ENABLED` | `IAA` |

## Limitations

1. **Tool Support**: Only `get_line_items_by_qdf` supports CSV fallback
2. **Data Freshness**: CSV files must be manually updated
3. **Product Coverage**: Only GNR and DMR (not PTL, future products)
4. **No PDM ID**: Cannot fallback for PDM-based queries

## Future Enhancements (Not Implemented)

- Add more CSV files (PTL, etc.)
- Support `search_product_by_name` with CSV
- Auto-refresh CSV from shared location
- Merge API + CSV data for best coverage

## Testing

Run tests:
```bash
# Test CSV fallback
python test_csv_fallback.py

# Test structure
python test_structure.py
```

## Notes

- CSV fallback is **automatic** - no user action needed
- API is always tried first - CSV is **fallback only**
- Fallback events logged to stderr for debugging
- No performance impact when API works normally
