# Testing Guide for LAVA Plugin

## Test Suites

### 1. Structure Tests (✅ Automated)

**File:** `test_structure.py`

Validates plugin structure without requiring authentication or API access.

**Tests:**
- ✅ File Structure - All required files present
- ✅ JSON Files - Valid JSON syntax
- ✅ Plugin Manifest - Correct plugin.json structure
- ✅ MCP Configuration - Valid .mcp.json
- ✅ Skill Frontmatter - Valid YAML frontmatter
- ✅ Python Syntax - server.py syntax valid
- ✅ Dependencies - Required packages in requirements.txt
- ✅ Marketplace Entry - Plugin listed in marketplace.json

**Run:**
```bash
cd lava-plugin
python test_structure.py
```

**Expected Output:**
```
============================================================
LAVA Plugin Structure Validation
============================================================
...
Result: 8/8 passed

[SUCCESS] All structure tests passed!
```

### 2. End-to-End Tests (🔐 Requires Auth)

**File:** `test_e2e.py`

Full integration tests with real API calls.

**Requirements:**
- Azure AD authentication
- AGS access to "Lava Users" group
- Intel VPN connection

**Tests:**
- Server Startup and Initialize
- List Available Tools
- Validate Tool Schemas
- Mock API Call (validates structure)
- Real API Call (interactive, requires confirmation)

**Run:**
```bash
cd lava-plugin
python test_e2e.py
```

**Notes:**
- First 4 tests run without API access
- Last test requires user confirmation and auth
- May require browser login on first run

### 3. Mock Tests (🐧 Unix Only)

**File:** `test_mock.py`

Tests MCP server communication without API calls.

**Requirements:**
- Unix-like environment (Linux, macOS, WSL)
- Python `select` module

**Tests:**
- Server initialization
- Tools listing
- Tool schema validation

**Run:**
```bash
cd lava-plugin
python test_mock.py
```

**Note:** Not compatible with native Windows (cmd/PowerShell).

## CI/CD Integration

### GitHub Actions Workflow

**File:** `.github/workflows/lava-check.yml`

**Jobs:**
1. **Python Lint** - Runs ruff on mcp_server.py
2. **Plugin Validation** - Runs test_structure.py

**Triggers:**
- Push to `lava-plugin/**`
- Pull requests affecting `lava-plugin/**`
- Manual workflow dispatch

**View Results:**
```bash
gh pr checks <pr-number>
```

## Manual Testing

### Prerequisites

1. **Install Dependencies**
   ```bash
   source ~/.venv/bin/activate
   pip install -r lava-plugin/requirements.txt
   ```

2. **AGS Access**
   - Go to: goto.intel.com/ags
   - Request: "Lava Users" or "Lava Reader" group
   - Wait for approval

3. **Intel VPN**
   - Connect to Intel corporate VPN

### Test 1: Structure Validation

```bash
cd lava-plugin
python test_structure.py
```

Expected: All 8 tests pass

### Test 2: Query QDF via Claude Code

1. Start Claude Code CLI
2. Type: "Query Q9JT specifications"
3. Expected: Plugin triggers and queries API
4. First time: Browser opens for Azure AD login
5. Expected result: CPU specifications displayed

### Test 3: Direct MCP Server Test

```bash
cd lava-plugin
echo '{"jsonrpc":"2.0","id":1,"method":"initialize"}' | python mcp_server.py
```

Expected output (JSON):
```json
{
  "jsonrpc": "2.0",
  "id": 1,
  "result": {
    "protocolVersion": "2024-11-05",
    "capabilities": {"tools": {}},
    "serverInfo": {"name": "lava-api", "version": "1.0.0"}
  }
}
```

### Test 4: List Available Tools

```bash
echo '{"jsonrpc":"2.0","id":1,"method":"initialize"}' | python mcp_server.py
echo '{"jsonrpc":"2.0","id":2,"method":"tools/list"}' | python mcp_server.py
```

Expected: JSON with 4 tools listed

### Test 5: API Call (Requires Auth)

This will trigger Azure AD login:

```python
import json
import subprocess

proc = subprocess.Popen(
    ["python", "mcp_server.py"],
    stdin=subprocess.PIPE,
    stdout=subprocess.PIPE,
    stderr=subprocess.PIPE
)

# Initialize
init_req = {"jsonrpc": "2.0", "id": 1, "method": "initialize"}
proc.stdin.write((json.dumps(init_req) + "\n").encode())
proc.stdin.flush()
response = proc.stdout.readline()
print("Init:", response.decode())

# Call tool
call_req = {
    "jsonrpc": "2.0",
    "id": 2,
    "method": "tools/call",
    "params": {
        "name": "get_line_items_by_qdf",
        "arguments": {"qdf": "Q9JT"}
    }
}
proc.stdin.write((json.dumps(call_req) + "\n").encode())
proc.stdin.flush()
response = proc.stdout.readline()
print("Result:", response.decode())

proc.terminate()
```

## Troubleshooting

### Authentication Fails

**Symptom:** "Failed to acquire access token"

**Solutions:**
1. Verify AGS access: goto.intel.com/ags
2. Check VPN connection
3. Clear token cache and retry:
   ```bash
   rm -f ~/.mcp_lava_token_cache.json
   python test_auth.py
   ```
4. Check device code hasn't expired (15 minutes)
5. Verify correct Intel credentials

### Token Cache Issues

**Symptom:** Repeated authentication prompts

**Check cache file:**
```bash
ls -lh ~/.mcp_lava_token_cache.json
cat ~/.mcp_lava_token_cache.json | python -m json.tool
```

**Clear cache:**
```bash
rm -f ~/.mcp_lava_token_cache.json
```

**Cache location:**
- Lava API: `~/.mcp_lava_token_cache.json`
- Microsoft Graph (email): `~/.mcp_graph_token.json`
- Each API has its own cache file

### API Returns 404

**Symptom:** `{"error": "QDF not found: XXXX"}`

**Causes:**
- Invalid QDF code
- Product not in Lava (may be in Liport only)

**Solutions:**
- Verify QDF code spelling
- Try `get_product_names` to browse available products

### MCP Server Won't Start

**Symptom:** No response or error on startup

**Solutions:**
1. Check Python version: `python --version` (need 3.10+)
2. Verify dependencies: `pip list | grep -E "(mcp|msal|requests)"`
3. Check syntax: `python -m py_compile mcp_server.py`
4. View stderr logs

### Structure Tests Fail

**Symptom:** test_structure.py reports failures

**Common Issues:**
- Missing files: Ensure all plugin files present
- Invalid JSON: Run `python -m json.tool <file.json>`
- Python syntax: Run `python -m py_compile mcp_server.py`

## Test Coverage

| Component | Structure Tests | E2E Tests | Manual Tests |
|-----------|----------------|-----------|--------------|
| File Structure | ✅ | - | - |
| JSON Files | ✅ | - | - |
| Plugin Manifest | ✅ | - | - |
| MCP Config | ✅ | - | - |
| Skill Frontmatter | ✅ | - | - |
| Python Syntax | ✅ | - | - |
| Dependencies | ✅ | - | - |
| Marketplace Entry | ✅ | - | - |
| MCP Protocol | - | ✅ | ✅ |
| Tool Registration | - | ✅ | ✅ |
| Tool Schemas | - | ✅ | ✅ |
| API Authentication | - | ✅ | ✅ |
| API Queries | - | ✅ | ✅ |
| Data Parsing | - | ✅ | ✅ |

## Continuous Testing

### Pre-commit

Add to `.git/hooks/pre-commit`:

```bash
#!/bin/bash
cd lava-plugin
python test_structure.py
exit $?
```

### Pre-push

Add to `.git/hooks/pre-push`:

```bash
#!/bin/bash
cd lava-plugin
python test_structure.py || exit 1
ruff check mcp_server.py || exit 1
echo "All pre-push checks passed"
```

## Test Data

### Valid QDF Codes for Testing

- `Q9JT` - DMR/OKS platform
- `L1CY` - Common test QDF
- `Q0PE` - GNR platform
- `Q597` - Another valid code

### Valid PDM IDs for Testing

- `10047749` - Ponte Vecchio product
- `10051116` - Test product with multiple QDFs

### Expected API Response Structure

```json
{
  "qdf": "Q9JT",
  "items": [
    {
      "lineItemId": "...",
      "qdf": "Q9JT",
      "source": "Lava",
      "lineItemGroups": [...],
      "specifications": {
        "Core_Count": "64",
        "TDP": "350",
        "Max_Turbo": "3.1",
        "Cache": "80",
        ...
      }
    }
  ],
  "count": 1
}
```

## Resources

- **Lava API Docs:** https://lava-api.app.intel.com/index.html
- **Swagger UI:** https://lava-api.app.intel.com/index.html (with Bearer token)
- **AGS Access:** goto.intel.com/ags
- **Support:** MIT-LAVA-Helpdesk@intel.com
