---
name: lava
description: Query Intel CPU LAVA (Line item AVailability for All) specification data via API. Use when user needs CPU QDF lookup, core count, TDP, max turbo frequency, cache size, UPI ports, memory channels, DDR5 speed, MRDIMM specs, PCIe lanes, accelerator (QAT/DSA/IAA) status, or SST (Speed Select Technology) support. Supports all Intel server platforms including Granite Rapids (GNR), Diamond Rapids (DMR), and future products.
---

# LAVA CPU Specification Query

Query Intel CPU specifications from LAVA API for server platforms using QDF or Product ID.

## Recommended Query Workflows

**IMPORTANT: Choose the right workflow based on user input.**

### Workflow A: Product Query (2 calls) — **PREFERRED for discovery/filtering**
Use when user mentions product name or abbreviation (DMR, GNR, SRF, etc.).
```
search_product_by_name → get_line_items_by_pdmid
```
Returns ALL QDFs with summarized specs. Good for filtering (e.g., core count, TDP).
**Note:** Some connectivity/accelerator fields (UPI_Ports, PCIe_Lanes, DSA/IAA/QAT) may be missing from bulk results — do NOT present these as complete specs.

**Examples:**
- "Show me DMR SKUs"
- "Granite Rapids specs with >32 cores"
- "What QDFs does SRF have?"

### Workflow B: Single QDF Query (1 call)
Use when user provides a specific QDF code.
```
get_line_items_by_qdf
```

**Examples:**
- "Query Q9JT specifications"
- "What are the specs for L1CY?"

### Workflow C: Filtered Search (1 call) — **BEST FOR COMPLEX FILTERS**
Use when user wants to filter SKUs by multiple spec criteria (cores, TDP, SST, etc.).
```
search_line_items
```
Accepts product name + up to 20 filter parameters. Handles product lookup and filtering in one call.
Also use this when the user explicitly asks to exclude metadata-tagged parts such as VIS or explicitly unfused parts.

**Examples:**
- "DMR SKUs with more than 32 cores"
- "GNR with UPI speed >= 24 GT/s"
- "DMR with SST-BF enabled"
- "GNR with TDP under 300W and MRDIMM 12800+"
- "DMR 650W CPUs, don't list VIS or unfused parts"

### Workflow D: Named QDFs with Full Details (N calls)
Use when user **explicitly names a small set of QDFs** (≤10) and needs **complete detailed specs** (e.g., to email, report, or compare).
```
get_line_items_by_qdf × N  (one call per QDF)
```
This is the only way to guarantee all fields are present (UPI_Ports, PCIe_Lanes, DSA/IAA/QAT, SST profiles, etc.).

**Examples:**
- "Email full details for Q7UG, Q9DY, Q7GD"
- "Compare specs of Q9UC and Q9UD"
- "Show complete specs for these 5 QDFs: ..."

### ❌ Anti-Pattern
Never loop `get_line_items_by_qdf` to query **all QDFs for a product** (can be 100+). Use `get_line_items_by_pdmid` or `search_line_items` for product-wide discovery.

### ✅ Exception: Use `get_line_items_by_qdf` when
- User names specific QDFs and asks for "details", "full specs", "email", or "report"
- You previously retrieved QDFs via pdmid and need to present complete specs for a subset

## Available Tools

### 1. search_product_by_name
Search for products by name to find PDM IDs. **Use this when you only know the product name.**

**Parameters:**
- `product_name` (required): Product name or abbreviation (e.g., "Granite Rapids", "GNR", "DMR")
  - Case-insensitive, supports partial matching
  - Abbreviations: DMR, GNR, SRF, CWF, EMR, SPR

**Returns:** List of matching products with PDM IDs and variant names

### 2. get_line_items_by_pdmid
Get ALL line items for a product in one call. **Best for product-wide queries and filtering.**

**Parameters:**
- `pdmid` (required): Product Data Management variant item ID

**Returns:** All line items with summarized specs. **Warning:** Some fields may be missing (UPI_Ports, PCIe_Lanes, DSA/IAA/QAT). Use `get_line_items_by_qdf` for complete specs on specific QDFs.

### 3. get_line_items_by_qdf
Get specs for a single QDF. Only use for single QDF lookups.

**Parameters:**
- `qdf` (required): QDF or SSPEC code (e.g., Q9JT, L1CY)

**Returns:** Line item with specifications (core count, TDP, turbo freq, cache, memory, UPI, PCIe, accelerators, SST)

### 4. get_product_names
Browse all available products.

**Returns:** Product variant names with PDM IDs

### 5. search_line_items
Filter SKUs by specification criteria. **Best for complex queries with multiple filters.**

**Parameters:**
- `product_name` (required): Product name or abbreviation
- Numeric filters (all optional, min/max pairs):
  - `min_cores`/`max_cores`: Core count
  - `min_tdp`/`max_tdp`: TDP in Watts
  - `min_turbo`/`max_turbo`: Turbo frequency in GHz
  - `min_upi_ports`/`max_upi_ports`: UPI port count
  - `min_upi_speed`/`max_upi_speed`: UPI speed in GT/s
  - `min_pcie_lanes`/`max_pcie_lanes`: PCIe lane count
  - `min_pcie_speed`/`max_pcie_speed`: PCIe generation (5=Gen5, 6=Gen6)
  - `min_ddr_freq`/`max_ddr_freq`: DDR5 frequency in MHz
  - `min_mcr_freq`/`max_mcr_freq`: MRDIMM frequency in MHz
- SST filters (all optional, boolean):
  - `sst_bf_enabled`: SST Base Frequency
  - `sst_cp_enabled`: SST Core Power
  - `sst_pp_enabled`: SST Performance Profile
  - `sst_tf_enabled`: SST Turbo Frequency
- Metadata exclusion filters:
  - `exclude_vis`: Exclude VIS-tagged parts using product/line-item metadata
  - `exclude_unfused`: Exclude explicitly UNFUSED-tagged parts using line-item metadata

**Returns:** Filtered list of matching SKUs with full specifications and filter summary

## Usage Examples

### Example 1: Product Query
```
User: "Show me DMR SKUs"
Claude: 1. search_product_by_name("DMR") → gets PDM ID
        2. get_line_items_by_pdmid(pdmid) → gets ALL specs
Total: 2 calls
```

### Example 2: Product Query with Filter
```
User: "Granite Rapids with >32 cores"
Claude: 1. search_product_by_name("Granite Rapids") → gets PDM ID
        2. get_line_items_by_pdmid(pdmid) → gets ALL specs
        3. Filters results where Core_Count > 32 in response
Total: 2 calls (not 20+!)
```

### Example 3: Single QDF Query
```
User: "Query Q9JT specifications"
Claude: get_line_items_by_qdf(qdf="Q9JT")
Total: 1 call
```

### Example 4: Browse Products
```
User: "What CPU products are available?"
Claude: get_product_names() → lists all products with abbreviations
Total: 1 call
```

## Authentication

The plugin automatically handles Azure AD authentication using Windows credentials. On first use, you may be prompted to sign in with your Intel account.

**Required Access:**
- AGS group: "Lava Users" or "Lava Reader"
- Request access at: goto.intel.com/ags

## Key CPU Specifications

The API provides comprehensive CPU data including:

**Basic:**
- Core counts (functional and physical)
- TDP (Watts)
- Max turbo frequency (GHz)
- Cache size (MB)

**Memory:**
- Memory channels
- DDR5 max frequency (MHz)
- MRDIMM (MCR) frequency (e.g., 8800, 12800)
- Supported memory types

**Connectivity:**
- UPI port count
- UPI speed (GT/s)
- PCIe lane count
- PCIe generation (Gen5, Gen6)

**Accelerators:**
- QAT (QuickAssist Technology) device count
- DSA (Data Streaming Accelerator) device count
- IAA (In-Memory Analytics Accelerator) device count

**SST (Speed Select Technology):**
- SST-PP: Performance Profile (Perf-per-Watt)
- SST-TF: Turbo Frequency
- SST-BF: Base Frequency
- SST-CP: Core Power
- SST_Profiles: Per-profile key frequencies (active profiles only)
  - Max turbo per ISA: avx2_max_turbo, avx512_max_turbo, amx_max_turbo, avx512h_max_turbo
  - Base freq per ISA: avx2_base, avx512_base, amx_base
  - all_core_turbo, tdp, ddr_freq
- SST_BF_Freq: Base Frequency hi/lo priority freq and core count

## Notes

- QDF codes are alphanumeric identifiers (e.g., Q9JT, L1CY, Q0PE)
- Accelerator counts indicate number of enabled devices (0 = disabled)
- Data comes from both Lava and Liport systems
- API data is always up-to-date (no CSV downloads needed)

## Advanced Tools

The following tools are available for specific use cases:

- `get_qdfs_by_pdmid(pdmid)` - Get all QDF codes for a PDM ID
- `get_line_items_by_qdfs_and_pdmid(pdmid, qdfs)` - Batch query specific QDFs within a product (faster than individual queries)

These are useful when you need to query a specific subset of QDFs rather than all SKUs for a product.

## Troubleshooting

**Authentication Issues:**
- Ensure you have access to "Lava Users" AGS group
- Check VPN connection to Intel network
- Try re-authenticating when prompted

**API Errors:**
- 404: QDF or PDM ID not found
- 401: Authentication token expired (will auto-refresh)
- 403: Insufficient permissions (request AGS access)

## Comparison with Legacy Skill

This plugin replaces the old CSV-based lava-old-skills with:
- ✅ Real-time API access (no manual CSV downloads)
- ✅ Always up-to-date data
- ✅ Support for all current and future products
- ✅ Automatic authentication
- ✅ Broader platform coverage beyond GNR/DMR
