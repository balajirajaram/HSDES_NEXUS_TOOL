"""Shared fixtures for LAVA plugin tests."""
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import pytest
import msal
import requests
import urllib3
from auth_config import build_msal_app_kwargs

TENANT_ID = "46c98d88-e344-4ed4-8496-4ed7712e255d"
CLIENT_ID = "1441a063-45e1-4e47-9479-f2461278c25e"
SCOPE = ["api://1441a063-45e1-4e47-9479-f2461278c25e/access_as_user"]
TOKEN_CACHE_FILE = os.path.expanduser("~/.mcp_lava_token_cache.json")
LAVA_API_BASE = "https://lava-api.app.intel.com"

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


@pytest.fixture(scope="session")
def lava_api_headers():
    """Get LAVA API auth headers using cached token. Skips if unavailable."""
    if not os.path.exists(TOKEN_CACHE_FILE):
        pytest.skip(
            f"LAVA token cache not found: {TOKEN_CACHE_FILE}. "
            "Run the MCP server once to authenticate."
        )

    cache = msal.SerializableTokenCache()
    with open(TOKEN_CACHE_FILE, "r") as f:
        cache.deserialize(f.read())

    app = msal.PublicClientApplication(
        CLIENT_ID,
        **build_msal_app_kwargs(cache),
    )
    accounts = app.get_accounts()
    if not accounts:
        pytest.skip("No cached accounts. Run the MCP server once to authenticate.")

    token_result = app.acquire_token_silent(SCOPE, account=accounts[0])
    if not token_result or "access_token" not in token_result:
        pytest.skip("Failed to acquire token silently. Token may be expired.")

    return {"Authorization": f"Bearer {token_result['access_token']}"}


@pytest.fixture(scope="session")
def lava_api_fetcher(lava_api_headers):
    """Returns a cached function to fetch raw API item by QDF."""
    _cache = {}

    def fetch(qdf: str) -> dict:
        if qdf not in _cache:
            url = f"{LAVA_API_BASE}/api/v2/line_items/qdf/{qdf}"
            resp = requests.get(url, headers=lava_api_headers, verify=False, timeout=30)
            resp.raise_for_status()
            data = resp.json()
            items = data if isinstance(data, list) else [data]
            _cache[qdf] = items[0]
        return _cache[qdf]

    return fetch
