import os

from auth_config import build_msal_app_kwargs, get_proxy_settings


def test_get_proxy_settings_normalizes_and_trims_env(monkeypatch):
    monkeypatch.setenv("HTTP_PROXY", " http://proxy-dmz.intel.com:911 \n")
    monkeypatch.setenv("HTTPS_PROXY", "http://proxy-dmz.intel.com:912 ")
    monkeypatch.setenv("no_proxy", " 127.0.0.1,localhost,.intel.com \n")

    assert get_proxy_settings() == {
        "http": "http://proxy-dmz.intel.com:911",
        "https": "http://proxy-dmz.intel.com:912",
    }
    assert os.environ["NO_PROXY"] == "127.0.0.1,localhost,.intel.com"
    assert os.environ["no_proxy"] == "127.0.0.1,localhost,.intel.com"


def test_get_proxy_settings_returns_none_when_unset(monkeypatch):
    monkeypatch.delenv("HTTP_PROXY", raising=False)
    monkeypatch.delenv("HTTPS_PROXY", raising=False)
    monkeypatch.delenv("http_proxy", raising=False)
    monkeypatch.delenv("https_proxy", raising=False)
    monkeypatch.delenv("NO_PROXY", raising=False)
    monkeypatch.delenv("no_proxy", raising=False)

    assert get_proxy_settings() is None
    assert os.environ["NO_PROXY"] == "127.0.0.1,localhost,.intel.com"
    assert os.environ["no_proxy"] == "127.0.0.1,localhost,.intel.com"


def test_build_msal_app_kwargs_disables_verify_and_includes_proxies(monkeypatch):
    monkeypatch.delenv("HTTP_PROXY", raising=False)
    monkeypatch.delenv("http_proxy", raising=False)
    monkeypatch.delenv("https_proxy", raising=False)
    monkeypatch.delenv("NO_PROXY", raising=False)
    monkeypatch.delenv("no_proxy", raising=False)
    monkeypatch.setenv("HTTPS_PROXY", "http://proxy-dmz.intel.com:912")

    kwargs = build_msal_app_kwargs(token_cache=object())

    assert kwargs["verify"] is False
    assert kwargs["authority"].startswith("https://login.microsoftonline.com/")
    assert kwargs["proxies"] == {"https": "http://proxy-dmz.intel.com:912"}


def test_get_proxy_settings_sets_default_no_proxy(monkeypatch):
    monkeypatch.delenv("HTTP_PROXY", raising=False)
    monkeypatch.delenv("HTTPS_PROXY", raising=False)
    monkeypatch.delenv("http_proxy", raising=False)
    monkeypatch.delenv("https_proxy", raising=False)
    monkeypatch.delenv("NO_PROXY", raising=False)
    monkeypatch.delenv("no_proxy", raising=False)

    assert get_proxy_settings() is None
    assert os.environ["NO_PROXY"] == "127.0.0.1,localhost,.intel.com"
    assert os.environ["no_proxy"] == "127.0.0.1,localhost,.intel.com"
