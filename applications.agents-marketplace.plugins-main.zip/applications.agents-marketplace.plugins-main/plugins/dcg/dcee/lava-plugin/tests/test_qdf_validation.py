"""
Real QDF validation tests for LAVA API.

Fetches live data for known QDFs and asserts field presence + exact values.
Designed to catch silent regressions where a field is dropped (e.g. Cache,
PCIe_Speed) due to attribute name mismatches in format_line_item_attributes().

Requirements: Intel VPN + token cache (~/.mcp_lava_token_cache.json)

Run all:          pytest lava-plugin/tests/test_qdf_validation.py -v
Skip API tests:   pytest -m "not e2e"
"""
import os
import sys

import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from mcp_server import format_line_item_attributes  # noqa: E402


# ---------------------------------------------------------------------------
# Fields that MUST be present and non-empty for every QDF we test.
# If a field goes missing silently, TestRequiredFields catches it.
# GNR exception: IO_Cache_Agent (GNR architecture doesn't have this tile).
# ---------------------------------------------------------------------------
REQUIRED_FIELDS = [
    "Stepping",
    "Core_Count",
    "TDP",
    "Cache",
    "Base_Freq",
    "Max_Turbo",
    "Memory_Channels",
    "DDR_Freq",
    "MCR_Freq",
    "UPI_Ports",
    "UPI_Speed",
    "PCIe_Lanes",
    "PCIe_Speed",
    "QAT",
    "DSA",
    "IAA",
    "SST_PP",
    "SST_BF",
    "SST_TF",
    "SST_CP",
]

# ---------------------------------------------------------------------------
# Known-good values verified against live LAVA API responses and spec docs.
# Update here when a new stepping ships with different values.
# ---------------------------------------------------------------------------
QDF_KNOWN_VALUES: dict[str, dict[str, str]] = {
    # --- Granite Rapids (GNR) ---
    "Q5MU": {
        "Stepping": "B",
        "Core_Count": "72",
        "TDP": "350",
        "Cache": "336",
        # IO_Cache_Agent intentionally absent — GNR has no IO cache tile
        "Base_Freq": "0.8",
        "Max_Turbo": "4",
        "Memory_Channels": "8",
        "DDR_Freq": "6400",
        "MCR_Freq": "8000",
        "UPI_Ports": "4",
        "UPI_Speed": "24",
        "PCIe_Lanes": "88A",
        "PCIe_Speed": "GEN5",
        "QAT": "4",
        "DSA": "4",
        "IAA": "4",
        "SST_PP": "DISABLED",
        "SST_BF": "DISABLED",
        "SST_TF": "ENABLED",
        "SST_CP": "ENABLED",
    },
    # --- Diamond Rapids A0 ---
    "Q9UC": {
        "Stepping": "A0",
        "Core_Count": "160",
        "TDP": "500",
        "Cache": "1120",
        "IO_Cache_Agent": "32",
        "Base_Freq": "0.6",
        "Max_Turbo": "3.2",
        "Memory_Channels": "16",
        "DDR_Freq": "8000",
        "MCR_Freq": "12800",
        "UPI_Ports": "2",
        "UPI_Speed": "56",
        "PCIe_Lanes": "96A",
        "PCIe_Speed": "Gen6",
        "QAT": "2",
        "DSA": "2",
        "IAA": "2",
        "SST_PP": "ENABLED",
        "SST_BF": "DISABLED",
        "SST_TF": "ENABLED",
        "SST_CP": "ENABLED",
    },
    # --- Diamond Rapids A1 ---
    "Q9WG": {
        "Stepping": "A1",
        "Core_Count": "72",
        "TDP": "500",
        "Cache": "960",
        "IO_Cache_Agent": "32",
        "Base_Freq": "0.6",
        "Max_Turbo": "3.2",
        "Memory_Channels": "16",
        "DDR_Freq": "8000",
        "MCR_Freq": "12800",
        "UPI_Ports": "2",
        "UPI_Speed": "56",
        "PCIe_Lanes": "96A",
        "PCIe_Speed": "Gen6",
        "QAT": "2",
        "DSA": "2",
        "IAA": "2",
        "SST_PP": "DISABLED",
        "SST_BF": "ENABLED",
        "SST_TF": "ENABLED",
        "SST_CP": "ENABLED",
    },
    "Q9WJ": {
        "Stepping": "A1",
        "Core_Count": "32",
        "TDP": "325",
        "Cache": "240",
        "IO_Cache_Agent": "32",
        "Base_Freq": "0.6",
        "Max_Turbo": "3.2",
        "Memory_Channels": "16",
        "DDR_Freq": "8000",
        "MCR_Freq": "12800",
        "UPI_Ports": "2",
        "UPI_Speed": "56",
        "PCIe_Lanes": "96A",
        "PCIe_Speed": "Gen6",
        "QAT": "2",
        "DSA": "2",
        "IAA": "2",
        "SST_PP": "DISABLED",
        "SST_BF": "DISABLED",
        "SST_TF": "ENABLED",
        "SST_CP": "ENABLED",
    },
    "Q9WK": {
        "Stepping": "A1",
        "Core_Count": "6",
        "TDP": "350",
        "Cache": "80",
        "IO_Cache_Agent": "32",
        "Base_Freq": "0.6",
        "Max_Turbo": "3.1",
        "Memory_Channels": "16",
        "DDR_Freq": "8000",
        "MCR_Freq": "12800",
        "UPI_Ports": "2",
        "UPI_Speed": "56",
        "PCIe_Lanes": "96A",
        "PCIe_Speed": "Gen6",
        "QAT": "2",
        "DSA": "2",
        "IAA": "2",
        "SST_PP": "DISABLED",
        "SST_BF": "DISABLED",
        "SST_TF": "DISABLED",
        "SST_CP": "ENABLED",
    },
    "Q9WL": {
        "Stepping": "A1",
        "Core_Count": "160",
        "TDP": "650",
        "Cache": "1120",
        "IO_Cache_Agent": "32",
        "Base_Freq": "0.6",
        "Max_Turbo": "3.2",
        "Memory_Channels": "16",
        "DDR_Freq": "8000",
        "MCR_Freq": "12800",
        "UPI_Ports": "2",
        "UPI_Speed": "56",
        "PCIe_Lanes": "96A",
        "PCIe_Speed": "Gen6",
        "QAT": "2",
        "DSA": "2",
        "IAA": "2",
        "SST_PP": "DISABLED",
        "SST_BF": "DISABLED",
        "SST_TF": "ENABLED",
        "SST_CP": "ENABLED",
    },
    "Q9WM": {
        "Stepping": "A1",
        "Core_Count": "24",
        "TDP": "325",
        "Cache": "240",
        "IO_Cache_Agent": "32",
        "Base_Freq": "0.6",
        "Max_Turbo": "3.1",
        "Memory_Channels": "16",
        "DDR_Freq": "8000",
        "MCR_Freq": "12800",
        "UPI_Ports": "2",
        "UPI_Speed": "56",
        "PCIe_Lanes": "96A",
        "PCIe_Speed": "Gen6",
        "QAT": "2",
        "DSA": "2",
        "IAA": "2",
        "SST_PP": "DISABLED",
        "SST_BF": "DISABLED",
        "SST_TF": "ENABLED",
        "SST_CP": "ENABLED",
    },
    # --- Diamond Rapids A0 (additional) ---
    "Q9JR": {
        "Stepping": "A0",
        "Core_Count": "32",
        "TDP": "350",
        "Cache": "240",
        "IO_Cache_Agent": "32",
        "Base_Freq": "0.6",
        "Max_Turbo": "3.1",
        "Memory_Channels": "16",
        "DDR_Freq": "8000",
        "MCR_Freq": "12800",
        "UPI_Ports": "2",
        "UPI_Speed": "56",
        "PCIe_Lanes": "96A",
        "PCIe_Speed": "Gen6",
        "QAT": "2",
        "DSA": "2",
        "IAA": "2",
        "SST_PP": "DISABLED",
        "SST_BF": "DISABLED",
        "SST_TF": "ENABLED",
        "SST_CP": "ENABLED",
    },
    "Q9JT": {
        "Stepping": "A0",
        "Core_Count": "6",
        "TDP": "350",
        "Cache": "80",
        "IO_Cache_Agent": "32",
        "Base_Freq": "0.6",
        "Max_Turbo": "3.1",
        "Memory_Channels": "16",
        "DDR_Freq": "8000",
        "MCR_Freq": "12800",
        "UPI_Ports": "2",
        "UPI_Speed": "56",
        "PCIe_Lanes": "96A",
        "PCIe_Speed": "Gen6",
        "QAT": "2",
        "DSA": "2",
        "IAA": "2",
        "SST_PP": "DISABLED",
        "SST_BF": "DISABLED",
        "SST_TF": "ENABLED",
        "SST_CP": "ENABLED",
    },
    # Q9CZ and Q7YL: SSTBF_IND absent from API (not DISABLED, just not present)
    "Q9CZ": {
        "Stepping": "A0",
        "Core_Count": "6",
        "TDP": "350",
        "Cache": "80",
        "IO_Cache_Agent": "32",
        "Base_Freq": "0.8",
        "Max_Turbo": "3.1",
        "Memory_Channels": "12",
        "DDR_Freq": "8000",
        "MCR_Freq": "12800",
        "UPI_Ports": "2",
        "UPI_Speed": "56",
        "PCIe_Lanes": "96A",
        "PCIe_Speed": "Gen6",
        "QAT": "2",
        "DSA": "2",
        "IAA": "2",
        "SST_PP": "DISABLED",
        # SST_BF omitted — SSTBF_IND not present in API for this QDF
        "SST_TF": "ENABLED",
        "SST_CP": "ENABLED",
    },
    "Q7YL": {
        "Stepping": "A0",
        "Core_Count": "32",
        "TDP": "325",
        "Cache": "240",
        "IO_Cache_Agent": "32",
        "Base_Freq": "0.8",
        "Max_Turbo": "3.1",
        "Memory_Channels": "16",
        "DDR_Freq": "8000",
        "MCR_Freq": "12800",
        "UPI_Ports": "2",
        "UPI_Speed": "56",
        "PCIe_Lanes": "96A",
        "PCIe_Speed": "Gen6",
        "QAT": "2",
        "DSA": "2",
        "IAA": "2",
        "SST_PP": "DISABLED",
        # SST_BF omitted — SSTBF_IND not present in API for this QDF
        "SST_TF": "ENABLED",
        "SST_CP": "ENABLED",
    },
}

# QDFs that legitimately do not have IO_Cache_Agent (GNR architecture)
NO_IO_CACHE_QDFS = {"Q5MU"}

# QDFs where SSTBF_IND is absent from the API response (not DISABLED, just not present)
NO_SST_BF_QDFS = {"Q9CZ", "Q7YL"}


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture(scope="module")
def all_specs(lava_api_fetcher):
    """Fetch and parse specs for all test QDFs once per test module."""
    return {
        qdf: format_line_item_attributes(
            lava_api_fetcher(qdf).get("collections", [])
        )
        for qdf in QDF_KNOWN_VALUES
    }


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


@pytest.mark.e2e
@pytest.mark.parametrize("qdf", list(QDF_KNOWN_VALUES.keys()))
def test_required_fields_present(qdf, all_specs):
    """Every QDF must return all required fields — catches silent field drops."""
    specs = all_specs[qdf]
    required = set(REQUIRED_FIELDS)
    if qdf in NO_IO_CACHE_QDFS:
        required.discard("IO_Cache_Agent")
    else:
        required.add("IO_Cache_Agent")

    if qdf in NO_SST_BF_QDFS:
        required.discard("SST_BF")

    missing = [f for f in sorted(required) if not specs.get(f)]
    assert not missing, f"{qdf}: missing required fields: {missing}"


@pytest.mark.e2e
@pytest.mark.parametrize(
    "qdf,field,expected",
    [
        (qdf, field, value)
        for qdf, known in QDF_KNOWN_VALUES.items()
        for field, value in known.items()
    ],
    ids=lambda x: x if isinstance(x, str) else "",
)
def test_known_field_value(qdf, field, expected, all_specs):
    """Each known field must match its expected value (case-insensitive)."""
    specs = all_specs[qdf]
    actual = specs.get(field)
    assert actual is not None, (
        f"{qdf}.{field}: field missing from API response. "
        f"Available fields: {sorted(specs.keys())}"
    )
    assert actual.upper() == expected.upper(), (
        f"{qdf}.{field}: expected={expected!r}, got={actual!r}"
    )
