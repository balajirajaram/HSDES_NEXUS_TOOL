import os
import sys

import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from mcp_server import tool_search_line_items  # noqa: E402


@pytest.fixture
def stub_search_data(monkeypatch):
    def fake_search_product_by_name(product_name: str) -> dict:
        assert product_name == "DMR"
        return {
            "searchTerm": product_name,
            "matches": [
                {"pdmId": "1001", "variantName": "DIAMOND RAPIDS-UCC"},
                {"pdmId": "1002", "variantName": "DMR_VIS_SLID"},
            ],
            "count": 2,
        }

    def fake_get_line_items_by_pdmid(pdmid: str) -> dict:
        items_by_pdmid = {
            "1001": [
                {
                    "lineItemId": "li-prod",
                    "qdf": "Q7GG",
                    "source": "LAVA",
                    "lineItemGroups": ["production", "fused"],
                    "specifications": {"Core_Count": "256", "TDP": "650", "Max_Turbo": "3.4"},
                },
                {
                    "lineItemId": "li-unfused",
                    "qdf": "Q7UF",
                    "source": "LAVA_UNFUSED",
                    "lineItemGroups": ["bringup", "UNFUSED"],
                    "specifications": {"Core_Count": "256", "TDP": "650", "Max_Turbo": "3.3"},
                },
            ],
            "1002": [
                {
                    "lineItemId": "li-vis",
                    "qdf": "Q9WX",
                    "source": "LAVA",
                    "lineItemGroups": ["DMR_VIS_VARIANT"],
                    "specifications": {"Core_Count": "256", "TDP": "650", "Max_Turbo": "3.4"},
                }
            ],
        }
        return {"pdmId": pdmid, "items": items_by_pdmid[pdmid], "count": len(items_by_pdmid[pdmid])}

    monkeypatch.setattr("mcp_server.tool_search_product_by_name", fake_search_product_by_name)
    monkeypatch.setattr("mcp_server.tool_get_line_items_by_pdmid", fake_get_line_items_by_pdmid)


def test_search_line_items_exclude_vis_filters_variant_matches(stub_search_data):
    result = tool_search_line_items(
        product_name="DMR",
        min_tdp=650,
        max_tdp=650,
        exclude_vis=True,
    )

    assert [item["qdf"] for item in result["items"]] == ["Q7GG", "Q7UF"]
    assert "exclude VIS parts" in result["filtersApplied"]


def test_search_line_items_exclude_unfused_filters_metadata_matches(stub_search_data):
    result = tool_search_line_items(
        product_name="DMR",
        min_tdp=650,
        max_tdp=650,
        exclude_unfused=True,
    )

    assert [item["qdf"] for item in result["items"]] == ["Q7GG", "Q9WX"]
    assert "exclude unfused parts" in result["filtersApplied"]


def test_search_line_items_can_exclude_vis_and_unfused_together(stub_search_data):
    result = tool_search_line_items(
        product_name="DMR",
        min_tdp=650,
        max_tdp=650,
        exclude_vis=True,
        exclude_unfused=True,
    )

    assert [item["qdf"] for item in result["items"]] == ["Q7GG"]
    assert result["matchingItems"] == 1
