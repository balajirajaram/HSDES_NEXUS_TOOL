# video-transcribe-summarize

Transcribe a local video / audio file with **faster-whisper** and produce a
structured Markdown summary (sections, tables, Q&A blockquotes, links back to
the transcript). Designed for Intel meeting recordings on Windows behind the
corporate proxy.

## What it does
1. Probe duration with `ffprobe`
2. Extract 16 kHz mono WAV with `ffmpeg`
3. Run `faster-whisper` (CPU int8, `small` model by default) streaming
   `.transcript.txt` + `.srt` as segments arrive
4. Read the full transcript and emit `<basename>_summary.md` with a fixed
   template (overview, sections, Q&A, conclusion)

## Skill
- [`skills/video-transcribe-summarize/SKILL.md`](skills/video-transcribe-summarize/SKILL.md)

## Triggers
- "transcribe `<file>.mp4`"
- "summarize this recording / video / meeting"
- "watch this video and give me the key points"
- "listen to this audio and recap"
- "take meeting notes from `<file>.m4a`"
- "extract key points from this town hall recording"
- "convert this audio to text"
- "get a transcript of `<file>.mkv`"
- "write meeting minutes for this recording"
- "caption / subtitle / create SRT for `<file>.mp4`"
- "turn this talk into markdown"

## Tool prerequisites (one-time, auto-checked by the skill)
- `ffmpeg` (install via `winget install Gyan.FFmpeg`)
- Python 3.12 (faster-whisper has no wheels for 3.14 yet)
- `faster-whisper` via `pip --proxy http://proxy-dmz.intel.com:912`

## Known pitfalls baked into the skill
- `HF_HUB_DISABLE_XET=1` is mandatory — HuggingFace xet protocol stalls
  behind the Intel proxy and the download hangs at tokenizer files
- Always invoke `py -3.12` explicitly
- Refresh `$env:Path` after a fresh `winget install` of ffmpeg in the same
  session
- Poll progress with `Get-Content -Tail` from a separate terminal; do **not**
  `Start-Sleep` inside the same shell

## Owners
- dong-han.wu@intel.com (DCEE APJ ODMS, Thermal)
- abby.liu@intel.com

## License
MIT — Intel internal use.

## Changelog
### 1.0.1
- English-only trigger phrases; expanded list to 13 phrases
- Document additional supported extensions (`.webm`, `.mp3`)

### 1.0.0
- Initial release
- `video-transcribe-summarize` skill
