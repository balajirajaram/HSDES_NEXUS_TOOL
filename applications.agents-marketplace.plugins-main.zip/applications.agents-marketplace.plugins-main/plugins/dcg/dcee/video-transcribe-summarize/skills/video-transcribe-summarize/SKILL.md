---
name: video-transcribe-summarize
description: Transcribe a local video/audio file with faster-whisper and produce a structured Markdown summary. Use when the user asks to "transcribe", "summarize", "watch", "listen to", "recap", "take notes from", "extract key points from", "convert to text", "get a transcript of", "write meeting minutes for", "caption", "subtitle", "create SRT for", or "turn into markdown" a local .mp4/.mkv/.mov/.webm/.wav/.m4a/.mp3 file (meeting recording, town hall, talk, lecture, podcast, voice memo). Handles Intel proxy + Windows quirks. Do NOT use for YouTube URLs or files that already have a transcript.
---

# Video → Transcript → Markdown Summary

End-to-end workflow to extract spoken content from a local media file and turn it into an organized Chinese/English summary.

## When to use
- User points at a local video/audio file (`.mp4`, `.mkv`, `.mov`, `.webm`, `.wav`, `.m4a`, `.mp3`) and asks to summarize, transcribe, recap, take notes, or extract key points from it.
- File is on the user's machine (NOT a streaming URL). For SharePoint/Stream URLs, first download via the m365 MCP tools, then run this skill.

## Tool prerequisites (install once)
Check first; only install what's missing.

```powershell
# ffmpeg — needed to extract audio
Get-Command ffmpeg -ErrorAction SilentlyContinue
# If missing:
winget install --id Gyan.FFmpeg -e --accept-source-agreements --accept-package-agreements --silent
# Refresh PATH in current session:
$env:Path = [Environment]::GetEnvironmentVariable("Path","User") + ";" + [Environment]::GetEnvironmentVariable("Path","Machine")

# Python 3.12 (faster-whisper has no wheels for 3.14 yet)
py -0    # confirm -V:3.12 is listed

# faster-whisper (use Intel proxy)
py -3.12 -m pip install --proxy http://proxy-dmz.intel.com:912 faster-whisper
```

## Workflow

### Step 1 — Locate file + probe duration
```powershell
ffprobe -v error -show_entries format=duration,size -of default=nw=1 "<path/to/video>"
```
Use duration to set user expectations. On CPU with `small` int8, transcription runs ~0.4× realtime (a 60-min video takes ~22 min).

### Step 2 — Extract mono 16 kHz WAV
Whisper prefers this format. Keep WAV next to the video.

```powershell
ffmpeg -y -i "<input>" -vn -ac 1 -ar 16000 -c:a pcm_s16le "<output>.wav"
```

### Step 3 — Transcribe with faster-whisper
Create `transcribe.py` next to the audio. Key knobs:

- **Model size**: `small` (≈480 MB, fine for clear meeting audio) → `medium` (≈1.5 GB, better accuracy, slower). Start with `small`; only upgrade if quality is poor.
- **Critical env vars on Intel corp network**:
  - `HTTPS_PROXY` / `HTTP_PROXY` = `http://proxy-dmz.intel.com:912`
  - `HF_HUB_DISABLE_XET=1` — **must set this**; the xet protocol hangs behind Intel proxy and the download will stall at tokenizer files only.
- Stream output to `.txt` and `.srt` as segments arrive so progress is observable from another terminal (`Get-Content -Tail`).
- `condition_on_previous_text=False` avoids runaway hallucination loops.
- `vad_filter=True` skips long silences.

Reference template:

```python
import os, time
os.environ["HTTPS_PROXY"] = "http://proxy-dmz.intel.com:912"
os.environ["HTTP_PROXY"]  = "http://proxy-dmz.intel.com:912"
os.environ["HF_HUB_DISABLE_XET"] = "1"
os.environ["HF_HUB_DISABLE_SYMLINKS_WARNING"] = "1"
from faster_whisper import WhisperModel

AUDIO   = r"<path>.wav"
OUT_TXT = r"<path>.transcript.txt"
OUT_SRT = r"<path>.srt"
MODEL   = os.environ.get("WHISPER_MODEL", "small")

model = WhisperModel(MODEL, device="cpu", compute_type="int8", num_workers=1)
segments, info = model.transcribe(
    AUDIO, beam_size=1, vad_filter=True,
    vad_parameters=dict(min_silence_duration_ms=500),
    condition_on_previous_text=False,
)
print(f"lang={info.language} p={info.language_probability:.2f} dur={info.duration:.0f}s", flush=True)

def fmt(t):
    h=int(t//3600); m=int((t%3600)//60); s=t%60
    return f"{h:02d}:{m:02d}:{s:06.3f}".replace(".", ",")

with open(OUT_TXT,"w",encoding="utf-8") as ft, open(OUT_SRT,"w",encoding="utf-8") as fs:
    for i, seg in enumerate(segments, 1):
        line = seg.text.strip()
        ft.write(f"[{seg.start:7.2f} -> {seg.end:7.2f}] {line}\n"); ft.flush()
        fs.write(f"{i}\n{fmt(seg.start)} --> {fmt(seg.end)}\n{line}\n\n"); fs.flush()
        if i % 20 == 0:
            print(f"  seg {i} t={seg.end:.1f}s", flush=True)
```

Run it asynchronously and poll progress with `Get-Content "<txt>" -Tail 3`. Do NOT use `Start-Sleep` to wait — let the async terminal complete-notification trigger your next turn.

### Step 4 — Read transcript + write summary
1. `read_file` the entire `.transcript.txt` (use large ranges, not many small reads).
2. Identify structure:
   - Speakers (intro sequence often reveals names + roles)
   - Major sections (financials, roadmap, Q&A, etc.)
   - Q&A questions — capture each questioner's name + role + their actual question
3. Produce a Markdown file `<basename>_summary.md` next to the transcript.

## Summary MD template

Use this structure (adapt section names to topic):

```markdown
# <Talk title> — 重點整理

- 日期:YYYY-MM-DD
- 來源影片:`<relative path>`(<duration>,<language>)
- 逐字稿:[<file>.transcript.txt](<file>.transcript.txt)
- 字幕檔:[<file>.srt](<file>.srt)
- 主講人:
  - **<Name>**(<role>)
  - ...

---

## 1. <First major section, e.g. Q1 財報>

<Use a table for numeric metrics>

| 指標 | 數字 | 變化 |
|---|---|---|
| ... | ... | ... |

- Key bullet
- Key bullet

---

## 2. <Next section>
...

---

## N. Q&A 重點

### <Questioner Name>(<team/role>)
> <quoted question>

**<Speaker> 回答**:
- bullet
- bullet

---

## 結尾
- <closing remarks / awards / next steps>
```

## Style rules for the summary
- **Language**: match the user's language preference. Default to 繁體中文 with English tech terms preserved (e.g. "rack level", "chiplet", product code names).
- **Bold the actionable numbers and decisions** (targets, dates, percentages, cancellations).
- **Tables for financials / metrics**; bullets for narrative.
- **Quote Q&A questions verbatim** (translated) inside `> blockquote` so context is preserved.
- Preserve product code names (DMR, Crescent Island, Coral, etc.) exactly as spoken.
- Keep section headings parallel — every `## N. Title` should be a real topic, not filler.
- Link the transcript and SRT at the top so the reader can verify any claim.
- Do not invent numbers. If whisper mis-transcribed a digit, mark with `~` or `(?)`.

## Common pitfalls
- **HF download stalls at ~2 MB** → `HF_HUB_DISABLE_XET=1` is not set. Kill, set env, retry.
- **Python 3.14 errors importing faster-whisper** → use `py -3.12` explicitly.
- **`ffmpeg not found` right after winget install** → refresh PATH in current PowerShell session (see prerequisites).
- **Wrong language detected on Chinese/English mixed talks** → pass `language="zh"` or `language="en"` explicitly to `model.transcribe()`.
- **OneDrive paths with spaces** → always quote paths; prefer `r"..."` raw strings in Python.
- **Don't poll with `Start-Sleep`** during transcription; rely on async terminal completion notification.

## Quick command crib
```powershell
# 1) probe
ffprobe -v error -show_entries format=duration -of default=nw=1 "$v"
# 2) extract
ffmpeg -y -i "$v" -vn -ac 1 -ar 16000 -c:a pcm_s16le "$($v -replace '\.[^.]+$','.wav')"
# 3) transcribe
$env:HF_HUB_DISABLE_XET="1"; $env:HTTPS_PROXY="http://proxy-dmz.intel.com:912"; $env:WHISPER_MODEL="small"
py -3.12 transcribe.py
# 4) tail progress from another terminal
Get-Content "<file>.transcript.txt" -Tail 5 -Wait
```
