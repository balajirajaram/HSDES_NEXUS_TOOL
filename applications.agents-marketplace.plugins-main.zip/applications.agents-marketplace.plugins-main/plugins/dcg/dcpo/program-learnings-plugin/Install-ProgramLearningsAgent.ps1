#Requires -Version 5.1
<#
.SYNOPSIS
    Installs or updates the Program Learnings Agent for VS Code Copilot.

.DESCRIPTION
    Copies the generic program-learnings.agent.md to the current user's VS Code
    User Prompts folder, and syncs all project config JSON files to
    %USERPROFILE%\.copilot\program-learnings\configs\.

    Can be run:
      - Locally, pointing at a cloned repo folder
      - From a shared UNC path (e.g. \\share\tools\program-learnings\)
      - By IT/setup automation to provision new developers

.PARAMETER SourcePath
    Root folder of this repository / distribution package.
    Defaults to the folder this script lives in.

.PARAMETER ProjectSlug
    Optional. If supplied, only copies the matching <slug>.json config,
    not all configs in the configs\ subfolder.

.EXAMPLE
    # Install everything from the current folder
    .\Install-ProgramLearningsAgent.ps1

.EXAMPLE
    # Install only the jaguar-shores config from a network share
    .\Install-ProgramLearningsAgent.ps1 -SourcePath \\corp\tools\program-learnings -ProjectSlug jaguar-shores

.EXAMPLE
    # Upgrade agent file only (no config changes)
    .\Install-ProgramLearningsAgent.ps1 -AgentOnly
#>
[CmdletBinding(SupportsShouldProcess)]
param(
    [string]$SourcePath   = $PSScriptRoot,
    [string]$ProjectSlug  = "",
    [switch]$AgentOnly,
    [switch]$ConfigOnly
)

$ErrorActionPreference = "Stop"

# ── Paths ────────────────────────────────────────────────────────────────────

$AgentSource  = Join-Path $SourcePath "agents\program-learnings.agent.md"
$ConfigSource = Join-Path $SourcePath "configs"

$VSCodePromptsDir = Join-Path $env:APPDATA "Code\User\prompts"
$LocalConfigDir   = Join-Path $env:USERPROFILE ".copilot\program-learnings\configs"

# ── Helpers ──────────────────────────────────────────────────────────────────

function Write-Step([string]$msg) {
    Write-Host "`n  $msg" -ForegroundColor Cyan
}

function Write-OK([string]$msg) {
    Write-Host "    [OK] $msg" -ForegroundColor Green
}

function Write-Skip([string]$msg) {
    Write-Host "    [--] $msg" -ForegroundColor DarkGray
}

function Write-Warn([string]$msg) {
    Write-Host "    [!!] $msg" -ForegroundColor Yellow
}

# ── Pre-flight ────────────────────────────────────────────────────────────────

Write-Host "`nProgram Learnings Agent — Installer" -ForegroundColor White
Write-Host "=====================================" -ForegroundColor DarkCyan
Write-Host "  Source  : $SourcePath"
Write-Host "  User    : $env:USERNAME"
Write-Host "  Machine : $env:COMPUTERNAME"

if (-not $ConfigOnly) {
    if (-not (Test-Path $AgentSource)) {
        Write-Error "Agent file not found: $AgentSource`nRun this script from the repo root or pass -SourcePath."
    }
}

if (-not $AgentOnly) {
    if (-not (Test-Path $ConfigSource)) {
        Write-Error "Configs folder not found: $ConfigSource"
    }
}

# ── Environment setup ────────────────────────────────────────────────────────
# Ensures the agent runs without "Allow execution?" prompts on this machine.

Write-Step "Configuring execution environment..."

# Fix #2 — PowerShell execution policy
# 'Unrestricted' still shows a confirmation dialog for scripts downloaded from the
# internet. 'RemoteSigned' silently runs local scripts; remote scripts must be signed.
$currentPolicy = Get-ExecutionPolicy -Scope CurrentUser
if ($currentPolicy -in @('Undefined', 'Restricted', 'Unrestricted')) {
    if ($PSCmdlet.ShouldProcess("CurrentUser execution policy", "Set to RemoteSigned")) {
        Set-ExecutionPolicy -Scope CurrentUser RemoteSigned -Force
        Write-OK "Execution policy set to RemoteSigned (CurrentUser scope)"
    }
} else {
    Write-Skip "Execution policy already '$currentPolicy' — no change needed"
}

# Fix #1 — Unblock the M365 Graph MCP server exe
# Windows marks downloaded executables with a Zone.Identifier stream that triggers
# SmartScreen on every launch. Removing it allows the MCP server to start silently.
$mcpExe = Join-Path $env:USERPROFILE ".copilot\bin\m365-graph-mcp\m365-graph-mcp.exe"
if (Test-Path $mcpExe) {
    if ($PSCmdlet.ShouldProcess($mcpExe, "Unblock-File")) {
        Unblock-File -Path $mcpExe -ErrorAction SilentlyContinue
        Write-OK "Unblocked: m365-graph-mcp.exe"
    }
} else {
    Write-Warn "m365-graph-mcp.exe not found — skipping unblock."
    Write-Warn "Expected: $mcpExe"
    Write-Warn "Install the M365 Graph MCP server first, then re-run this script."
}

# ── Install agent file ────────────────────────────────────────────────────────

if (-not $ConfigOnly) {
    Write-Step "Installing agent file..."

    if (-not (Test-Path $VSCodePromptsDir)) {
        New-Item -ItemType Directory -Path $VSCodePromptsDir -Force | Out-Null
        Write-OK "Created VS Code prompts folder: $VSCodePromptsDir"
    }

    $dest = Join-Path $VSCodePromptsDir "program-learnings.agent.md"
    if ($PSCmdlet.ShouldProcess($dest, "Copy agent file")) {
        Copy-Item -Path $AgentSource -Destination $dest -Force
        Unblock-File -Path $dest -ErrorAction SilentlyContinue
        Write-OK "Installed: $dest"
    }
}

# ── Install config(s) ─────────────────────────────────────────────────────────

if (-not $AgentOnly) {
    Write-Step "Installing project configs..."

    if (-not (Test-Path $LocalConfigDir)) {
        New-Item -ItemType Directory -Path $LocalConfigDir -Force | Out-Null
        Write-OK "Created config folder: $LocalConfigDir"
    }

    $configFiles = if ($ProjectSlug) {
        $f = Join-Path $ConfigSource "$ProjectSlug.json"
        if (-not (Test-Path $f)) {
            Write-Error "Config not found for slug '$ProjectSlug': $f"
        }
        @(Get-Item $f)
    }
    else {
        Get-ChildItem -Path $ConfigSource -Filter "*.json"
    }

    foreach ($file in $configFiles) {
        $dest = Join-Path $LocalConfigDir $file.Name
        if ($PSCmdlet.ShouldProcess($dest, "Copy config")) {
            Copy-Item -Path $file.FullName -Destination $dest -Force
            Unblock-File -Path $dest -ErrorAction SilentlyContinue
            Write-OK "Config installed: $($file.Name)"
        }
    }
}

# ── Summary ───────────────────────────────────────────────────────────────────

Write-Host ""
Write-Host "  Installation complete." -ForegroundColor Green
Write-Host ""
Write-Host "  First-run note:" -ForegroundColor White
Write-Host "    A browser window will open once for Microsoft 365 authentication." -ForegroundColor DarkGray
Write-Host "    Tokens are cached automatically after that — no repeated prompts." -ForegroundColor DarkGray
Write-Host ""
Write-Host "  To use the agent:" -ForegroundColor White
Write-Host "    1. Open GitHub Copilot Chat in VS Code" -ForegroundColor DarkGray
Write-Host "    2. Click the agent picker (@) and select 'Program Learnings'" -ForegroundColor DarkGray
Write-Host "    3. Type your project slug, e.g.:  jaguar-shores" -ForegroundColor DarkGray
Write-Host "       or include a date range:       jaguar-shores May 12-19 2026" -ForegroundColor DarkGray
Write-Host ""
Write-Host "  Available project configs:" -ForegroundColor White
Get-ChildItem -Path $LocalConfigDir -Filter "*.json" | Where-Object { $_.Name -ne "template.json" } |
    ForEach-Object { Write-Host "    - $($_.BaseName)" -ForegroundColor DarkGray }
Write-Host ""
Write-Host "  To add a new project:" -ForegroundColor White
Write-Host "    Copy $LocalConfigDir\template.json" -ForegroundColor DarkGray
Write-Host "    Rename to <project-slug>.json and fill in the fields." -ForegroundColor DarkGray
Write-Host ""
