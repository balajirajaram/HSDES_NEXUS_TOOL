# Program Learnings Agent

A config-driven GitHub Copilot agent that automatically generates weekly program learnings summaries for any Intel PSXT, PVST, or PXT forum. It scans your Outlook inbox and OneNote meeting minutes, extracts decisions, gaps, risks, and action items, deduplicates against prior summaries, and uploads a structured `.xlsx` report to SharePoint.

---

## Table of Contents

- [How It Works](#how-it-works)
- [Prerequisites](#prerequisites)
- [Installation](#installation)
  - [One-time setup after installing](#one-time-setup-after-installing)
- [Using the Agent](#using-the-agent)
- [Adding Your Project](#adding-your-project)
- [Finding OneNote IDs](#finding-onenote-ids)
- [Config File Reference](#config-file-reference)
- [What the Agent Extracts](#what-the-agent-extracts)
- [Output Format](#output-format)
- [Troubleshooting](#troubleshooting)
- [Updating to a Newer Version](#updating-to-a-newer-version)

---

## How It Works

```
You type:  @Program Learnings jaguar-shores
               │
               ▼
       Reads configs/jaguar-shores.json          ← your project's settings
               │
       ┌───────┴────────┐
       │                │
  Outlook emails    OneNote pages
  (M365 Graph API)  (M365 Graph API)
       │                │
       └───────┬────────┘
               │ extract decisions, gaps, risks, AIs
               ▼
       Dedup vs. previous SharePoint summaries
               │
               ▼
       Synthesize into themed groups
               │
               ▼
       Generate .xlsx  (one sheet per theme)
               │
               ▼
       Upload to SharePoint WeeklySummaries
```

The agent is **read-only on all sources** (emails, OneNote) and only **writes** the output `.xlsx` to the SharePoint folder you configure.

---

## Prerequisites

Before installing, confirm all four of the following are in place.

### 1. VS Code with GitHub Copilot Chat

- [VS Code](https://code.visualstudio.com/) version 1.90 or later
- [GitHub Copilot](https://marketplace.visualstudio.com/items?itemName=GitHub.copilot) extension
- [GitHub Copilot Chat](https://marketplace.visualstudio.com/items?itemName=GitHub.copilot-chat) extension
- A GitHub Copilot license (individual, Teams, or Enterprise)

Verify: open VS Code, press `Ctrl+Shift+I` to open Copilot Chat. You should see the chat panel.

### 2. M365 Graph MCP Server

The agent uses Microsoft Graph API calls (email, OneNote, SharePoint) through an MCP server. This must be configured in VS Code before the agent can access any Microsoft 365 data.

Check whether it is already installed by opening VS Code settings and searching for `mcp`. If you see an `m365-graph` server listed, you are good. If not, contact your team's Copilot admin or follow the [M365 Graph MCP setup guide](https://github.com/microsoft/m365-mcp) for your organisation.

You must be **signed in to your Intel Microsoft 365 account** in VS Code (the same account that has access to the Outlook mailbox, OneNote notebooks, and SharePoint sites you want the agent to read).

### 3. Python 3.x with openpyxl

The agent generates the `.xlsx` output by running a small Python script. Python must be on your `PATH`.

```powershell
python --version          # should print Python 3.x.x
pip install openpyxl      # install if missing
```

### 4. VS Code agent tool execution enabled

The agent automatically runs the generated Python script using VS Code's task runner. By default, VS Code disables these execution tools for security. Enable them once in your user `settings.json` (`%APPDATA%\Code\User\settings.json`):

```json
"github.copilot.chat.agent.toolRestrictions": {
    "run_notebook_cell": true,
    "create_and_run_task": true,
    "run_vscode_command": true
}
```

Without this setting, the agent will still generate the script but will ask you to run it manually (see [Troubleshooting](#troubleshooting)). The setting persists across all workspaces and VS Code restarts.

### 5. Git

```powershell
git --version             # should print git version 2.x
```

---

## Installation

### Quick install (recommended)

```powershell
# 1. Clone this repo
Download and install the DCG plugin marketplace as pointed out in https://wiki.ith.intel.com/spaces/VAnDA/pages/4738911779/DCG+Marketplace+installation#DCGMarketplaceinstallation-Downloadfrom
cd <InstallationFolder>/plugins/dcg/dcpo/program-learnings-plugin

# 2. Run the installer
.\Install-ProgramLearningsAgent.ps1
```

The installer:
- Copies `agents\program-learnings.agent.md` → `%APPDATA%\Code\User\prompts\`  _(makes the agent available in VS Code's agent picker for your user account)_
- Copies `configs\*.json` → `%USERPROFILE%\.copilot\program-learnings\configs\`  _(project configs the agent reads at runtime)_

**Restart VS Code** after running the installer for the agent to appear in the picker.

### Installer options

| Flag | Description |
|---|---|
| `-ProjectSlug <slug>` | Install only one project's config, not all |
| `-AgentOnly` | Reinstall/update the agent file only, leave configs untouched |
| `-ConfigOnly` | Update configs only, leave the agent file untouched |
| `-WhatIf` | Dry run — shows what would be copied without changing anything |
| `-SourcePath <path>` | Use a different source folder (e.g. a network share) |

```powershell
# Examples
.\Install-ProgramLearningsAgent.ps1 -ProjectSlug tiger-shores
.\Install-ProgramLearningsAgent.ps1 -AgentOnly -WhatIf
.\Install-ProgramLearningsAgent.ps1 -SourcePath \\corp\tools\program-learnings
```

### Verify the install

1. Open VS Code → Copilot Chat (`Ctrl+Shift+I`)
2. Click the **@** agent picker
3. You should see **Program Learnings** in the list

---

### One-time setup after installing

These two steps are required once per user account. You only need to repeat them if you add a new project or if your Microsoft 365 session expires (typically every 90 days).

#### 1 — Authenticate to Microsoft 365

On the very first agent run, the MCP server opens a browser window asking you to sign in with your Intel Microsoft 365 account. Sign in and grant the requested permissions. The token is then cached on disk — subsequent runs are fully silent.

> The installer has already unblocked the MCP server binary and set your PowerShell execution policy so no additional Windows prompts appear.

#### 2 — Open SharePoint-hosted OneNote notebooks in your OneNote client

The Microsoft Graph API's notebook discovery endpoint (`/me/onenote/notebooks`) only returns notebooks you have explicitly opened in the OneNote desktop or web client. If the notebook your config points to lives on a SharePoint team site, you must open it once so it registers under your account.

For each `onenote` entry in your config whose `site` is a SharePoint team site (not your personal OneDrive):

1. Navigate to the SharePoint site in a browser (e.g. `https://intel.sharepoint.com/sites/<site-name>`)
2. Open the notebook listed in your config's `notebook` field
3. Click **Open in OneNote** (top toolbar or via the "..." menu)
4. Wait ~1 minute for the Graph API registration to propagate
5. Re-run the agent — it will now discover the notebook and return live section IDs

**After the first successful run**, update `notebook_id` and `section_ids` in your config with the discovered values. This switches the agent to the fast path, which avoids discovery entirely on future runs and is immune to section-count limit errors.

See [Finding OneNote IDs](#finding-onenote-ids) for the exact Graph Explorer queries to retrieve the IDs.

---

## Using the Agent

### Basic usage

In Copilot Chat, type:

```
@Program Learnings <project-slug>
```

The agent defaults to the **last 7 days** when no date range is given.

### With a specific date range

```
@Program Learnings jaguar-shores May 12-19 2026
@Program Learnings jaguar-shores WW20
```

### Examples

| What you type | What happens |
|---|---|
| `@Program Learnings jaguar-shores` | JGS PSXT/PXT learnings for the past 7 days |
| `@Program Learnings jaguar-shores May 12-19 2026` | JGS learnings for that specific week |
| `@Program Learnings tiger-shores` | Tiger Shores learnings (requires `tiger-shores.json` config) |

### What the agent does step by step

| Step | Action |
|---|---|
| 0 | Reads your project's JSON config |
| 1 | Determines the date range |
| 2 | Checks SharePoint for prior summaries (deduplication) |
| 3 | Searches Outlook emails using keywords from config |
| 4 | Reads OneNote sections listed in config |
| 5 | Groups items into themes; writes one row per learning |
| 6 | Generates a formatted `.xlsx` file locally |
| 7 | Uploads the file to the SharePoint folder in your config |

The agent tracks each step in the VS Code todo panel so you can see progress in real time.

---

## Adding Your Project

### Step 1 — Copy the template

```powershell
cd %USERPROFILE%\.copilot\program-learnings\configs
Copy-Item template.json tiger-shores.json
```

### Step 2 — Fill in the config

Open `tiger-shores.json` in any text editor and fill in every field. See the [Config File Reference](#config-file-reference) section for a description of each field.

At minimum, set:
- `project_name`, `project_code`
- `keywords` (the terms that appear in relevant emails)
- `sharepoint.output_site` and `sharepoint.output_folder`
- At least one entry in `onenote`

### Step 3 — Test it

```
@Program Learnings tiger-shores
```

The agent will tell you if the config file is not found or if a field is missing.

### Step 4 — Share it with the team

Add your new config to this repo and open a pull request so others can install it:

```powershell
# In your local clone of this repo
Copy-Item "%USERPROFILE%\.copilot\program-learnings\configs\tiger-shores.json" configs\
git add configs\tiger-shores.json
git commit -m "feat: add Tiger Shores config"
git push
```

---

## Finding OneNote IDs

To enable the fast path (agent reads pages directly without traversing the full notebook tree — required for SharePoint-hosted notebooks with many sections), you need to populate `notebook_id` and `section_ids` in your config.

Use [Microsoft Graph Explorer](https://developer.microsoft.com/en-us/graph/graph-explorer). Sign in with your Intel M365 account.

### Step 1 — Find the SharePoint site ID

You only need this once per site. Substitute your site's short name:

```
GET https://graph.microsoft.com/v1.0/sites/intel.sharepoint.com:/sites/<site-name>
```

The response contains an `id` field that looks like this:

```
"id": "intel.sharepoint.com,223ede23-792e-4164-9ec4-e357ad4a4f67,a11fa96d-2470-4465-9a9a-5293c457d4a4"
```

This is a composite value — `{hostname},{site-collection-id},{web-id}`. **Copy the entire string, all three parts**, and use it verbatim as `<site-id>` in the next steps. Omitting any part will cause the request to fail.

### Step 2 — List notebooks in the site

Substitute the full site ID from Step 1:

```
GET https://graph.microsoft.com/v1.0/sites/<site-id>/onenote/notebooks
```

Find the notebook whose `displayName` matches your config's `notebook` field. Copy its `id` → this is your `notebook_id`.

### Step 3 — List sections in the notebook

Substitute the site ID and the `notebook_id` from Step 2:

```
GET https://graph.microsoft.com/v1.0/sites/<site-id>/onenote/notebooks/<notebook-id>/sections
```

Find each section whose `displayName` matches the names in your config's `sections` array. Copy the `id` of each → these are your `section_ids`.

### Example (Jaguar Shores PSXT)

| Field | Value |
|---|---|
| Site | `intel.sharepoint.com,223ede23-...` |
| Notebook query | `GET .../sites/<site-id>/onenote/notebooks` |
| `notebook_id` | `1-8268cd53-af3e-4678-95fb-aaad97580f04` |
| Sections query | `GET .../notebooks/1-8268cd53-.../sections` |
| `section_ids[0]` | `1-966d00f4-3839-4e4e-9d0e-e334a8bb3961` (section: "Jaguar Shores") |

### Why this matters

Without `section_ids`, the agent must enumerate all sections in the notebook to find the right one. Microsoft Graph returns an error (`The number of maximum sections is exceeded`) when a notebook has a large number of sections — a known API limitation for SharePoint-hosted notebooks. With `section_ids` populated, the agent skips discovery entirely and calls `onenote/sections/{id}/pages` directly.

---

## Config File Reference

All configs live in `%USERPROFILE%\.copilot\program-learnings\configs\<slug>.json`.

```jsonc
{
  // ── Identity ──────────────────────────────────────────────────────────────

  "project_name": "Tiger Shores",
  // Full human-readable project name. Used in the output document title.

  "project_code": "TGS",
  // Short code used in email subjects and ticket IDs (e.g. TGS, JGS).

  "output_filename_prefix": "PSXT_TigerShores_Learnings_",
  // Prefix for the generated .xlsx file. The date (YYYY-MM-DD) is appended.
  // Example result: PSXT_TigerShores_Learnings_2026-05-23.xlsx

  // ── Forum types ───────────────────────────────────────────────────────────

  "forum_types": ["PSXT", "PXT"],
  // List of forum types this config covers.
  // Supported values: "PSXT", "PVST", "PXT"
  // Used in the scope_constraint and output header.

  // ── Email search ──────────────────────────────────────────────────────────

  "keywords": [
    "TGS", "project-codename", "key-sw-component"
  ],
  // Terms the agent searches for in email subjects and bodies.
  // Use short, distinctive identifiers. Avoid generic words like "status".
  // Each keyword becomes a separate search call — be specific to reduce noise.

  "email_subject_patterns": [
    "PSXT", "TGS Workload Enabling", "TGS Core Validation Weekly Report"
  ],
  // Subject-line search patterns that reliably indicate high-value emails.
  // These are searched against the subject field only, for precision.
  // Tip: look at your recurring meeting invitation titles.

  // ── SharePoint output ─────────────────────────────────────────────────────

  "sharepoint": {
    "output_site": "scgsoftwareprogrammanagementoffice",
    // The SharePoint site name (last segment of the site URL).
    // e.g. for https://intel.sharepoint.com/sites/mysite  →  "mysite"

    "output_folder": "/Shared Documents/Tiger Shores/PSXT/Retrospectives/WeeklySummaries",
    // Folder path within the site where .xlsx files are uploaded.
    // Must already exist in SharePoint — the agent does not create folders.

    "reference_paths": [
      // Optional. Additional SharePoint paths the agent may reference.
      // These are informational and shown in the output header.
      { "label": "PSXT Presentations", "site": "mysite", "path": "/Shared Documents/..." }
    ]
  },

  // ── OneNote sources ───────────────────────────────────────────────────────

  "onenote": [
    {
      "label": "PSXT Minutes",
      // Friendly name shown in the output header and agent progress messages.

      "site": "scgsoftwareprogrammanagementoffice",
      // SharePoint site where this OneNote notebook lives.

      "notebook": "Tiger Shores PSXT",
      // Exact displayName of the OneNote notebook (case-sensitive).
      // Check in Graph Explorer: GET .../sites/<site-id>/onenote/notebooks

      "notebook_id": "1-xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx",
      // The Graph API id of the notebook. See "Finding OneNote IDs" section.
      // Required for the fast path (bypasses section-count limit errors).

      "sections": ["PSXT Minutes"],
      // Exact displayName(s) of sections to read (case-sensitive).

      "section_ids": ["1-yyyyyyyy-yyyy-yyyy-yyyy-yyyyyyyyyyyy"]
      // The Graph API id(s) of each section listed in "sections" above,
      // in the same order. See "Finding OneNote IDs" section.
      // When populated, the agent uses the fast path and skips discovery.
    }
  ],

  // ── Scope filter ──────────────────────────────────────────────────────────

  "scope_constraint": "ONLY include items relevant to Tiger Shores, PSXT, or PXT scope."
  // A plain-English rule the agent applies when deciding whether an extracted
  // item is in scope. Be specific. If your project has a hard boundary
  // (e.g. no media/codec items), state it here.
}
```

---

## What the Agent Extracts

The agent identifies **learnings** — items with program signal value. An item qualifies if it is one of:

| Type | Examples |
|---|---|
| **Decision** | Architecture choice made, feature scoped in/out, process change agreed |
| **Action item** | Task assigned to a person with an expected completion date |
| **Gap** | Missing capability, process hole, coverage miss, spec ambiguity |
| **Risk** | Schedule slip, technical blocker, dependency risk |
| **Key insight** | Observation with cross-team implications, lesson from a prior program |
| **Follow-up** | Item flagged for future discussion or investigation |

The agent **does not** extract: general status updates with no action, scheduling/social messages, items outside the `scope_constraint`, or items already captured in a prior weekly summary.

---

## Output Format

The `.xlsx` file contains:

- **Summary sheet** — period, sources scanned, any inaccessible sources, theme index
- **One sheet per theme** — each learning is one row

Each data row has these columns:

| Column | Content |
|---|---|
| `#` | Counter (resets to 1 per theme) |
| `Title` | 5–10 word label for the learning |
| `Owner` | Alias of the person who raised it or owns the action |
| `Severity` | `Critical` / `High` / `Medium` / `Low` — colour-coded cell fill |
| `Summary` | 2–3 sentences describing the situation or decision |
| `Key Learnings` | Bullet points — the actual insights |
| `Action Items` | `[owner alias] action description` per bullet |
| `Recommendations` | What the team should do going forward |
| `Recommended ETA` | Work week, date, or milestone |

**Severity colour coding:**

| Level | Cell colour | When assigned |
|---|---|---|
| Critical | Red `#C00000` | Active blocker; schedule slip materialised; escalation language present |
| High | Orange `#E36C09` | Multi-week delay risk; no owner on a live action; cross-team dependency at risk |
| Medium | Yellow `#F0C000` | Issue with owner/mitigation in place; process gap not threatening near-term schedule |
| Low | Grey `#D9D9D9` | Informational; future consideration; no near-term urgency |

Files are named `{output_filename_prefix}{YYYY-MM-DD}.xlsx` and uploaded to the SharePoint folder in your config. The agent never overwrites an existing file.

---

## Troubleshooting

### Agent does not appear in the @ picker

- Restart VS Code after running the installer.
- Confirm the file exists: `%APPDATA%\Code\User\prompts\program-learnings.agent.md`
- Check that the GitHub Copilot Chat extension is installed and you are signed in.

### "Config file not found"

- The slug you typed doesn't match any `.json` file in `%USERPROFILE%\.copilot\program-learnings\configs\`.
- Run `Get-ChildItem %USERPROFILE%\.copilot\program-learnings\configs\` to list available slugs.
- File names are case-sensitive on some systems — use lowercase hyphenated slugs.

### Emails are missing or too many irrelevant results

- Narrow the `keywords` list: remove generic terms, add project-specific abbreviations.
- Add precise subject lines to `email_subject_patterns`.
- The agent runs one search call per keyword — a long keyword list causes many API calls but gives better precision than broad terms.

### OneNote pages not found

- Confirm the `notebook` and `sections` names match exactly (including capitalisation) what appears in OneNote.
- The agent navigates by name: list notebooks → find by name → list sections → find by name → list pages. Any mismatch at any level will result in no pages being read.
- **If the notebook is on a SharePoint team site**, the discovery endpoint only returns notebooks you have previously opened in your OneNote client. See [One-time setup — step 2](#2--open-sharepoint-hosted-onenote-notebooks-in-your-onenote-client) for the fix.
- **Recommended fix for all cases**: populate `notebook_id` and `section_ids` in your config — the agent then skips name-based discovery entirely. See [Finding OneNote IDs](#finding-onenote-ids) for step-by-step instructions.

### OneNote section-count limit error

- Symptom: agent reports `The number of maximum sections is exceeded`.
- Cause: the notebook is hosted on a SharePoint site and has more sections than the Graph API allows for a single discovery call.
- Fix: populate `section_ids` in your config. See [Finding OneNote IDs](#finding-onenote-ids).

### SharePoint upload fails

- Confirm `sharepoint.output_folder` already exists in SharePoint. The agent does not create folders.
- Confirm your M365 account has **Edit** permissions on the destination folder.
- Check that `sharepoint.output_site` is the site's short name, not the full URL.

### Agent cannot run the Python script automatically

- Symptom: the agent says it cannot execute the script and asks you to run it manually.
- Cause: VS Code's agent execution tools (`create_and_run_task`, `run_vscode_command`) are disabled in your settings.
- Fix: add the following to `%APPDATA%\Code\User\settings.json` and reload VS Code (`Ctrl+Shift+P` → **Developer: Reload Window**):

```json
"github.copilot.chat.agent.toolRestrictions": {
    "run_notebook_cell": true,
    "create_and_run_task": true,
    "run_vscode_command": true
}
```

- Manual workaround (while you fix the setting): run the generated script yourself in the PowerShell terminal. Use two separate commands — the `&&` separator is not supported in Windows PowerShell:

```powershell
cd C:\Intel\Development\MCPDev
python .\gen_learnings_xlsx.py
```

  Then paste the `Saved:` output line back into the chat so the agent can proceed to the SharePoint upload step.

### openpyxl not found

```powershell
pip install openpyxl
```

---

## Updating to a Newer Version

```powershell
cd program-learnings-agent
git pull
.\Install-ProgramLearningsAgent.ps1 -AgentOnly   # update agent only, keep your configs
```

To also pick up new shared configs (e.g. a new project added by a colleague):

```powershell
.\Install-ProgramLearningsAgent.ps1              # updates everything
```

Your existing config files are **overwritten** by the installer if a file with the same name exists in the repo. Keep any local-only customisations in a file with a unique slug that is not tracked in the repo.
