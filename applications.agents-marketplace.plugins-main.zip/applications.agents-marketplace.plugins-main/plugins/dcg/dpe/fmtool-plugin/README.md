# FMTool Plugin

FMTool stands for Fleet Management Tool.

FMTool Plugin is an Agent Marketplace plugin for system debugging workflows. It packages MCP servers, agents, and skills used for log analysis, document search, HSDES ticket handling, and related Fleet Management Tool-assisted debugging tasks.

## Team

Author team: DCG China / DPE / SysDebug

## Plugin Metadata
- Homepage: <https://github.com/intel-innersource/applications.agents-marketplace.plugins/tree/main/plugins/dcg/dpe/fmtool-plugin>
- Repository: <https://github.com/intel-innersource/applications.agents-marketplace.plugins>

## What This Plugin Provides

This plugin provides:

- MCP server configuration for FMTool integration
- A local stdio MCP server for token management
- A remote HTTP MCP server with tools for system debugging
- Skills for FMTool-backed workflows such as file management, debugging, HSDES handling, and platform analysis
- Agent definitions for FMTool-driven assistance
- Hook configuration for plugin integration

## Authentication Model

This plugin uses a Kerberos-based authentication model.

- The FMTool token is retrieved through a Kerberos-authenticated `curl` request using `--negotiate`.
- Token endpoint: `https://sysdebug-agent.intel.com/api/agent/mcp-user-token`
- On Windows, the token is fetched with `curl.exe`.
- On Linux, the token is fetched with `curl` and the bundled FMTool certificate chain.
- The token response is a JWT and is propagated into local plugin configuration for MCP use.

The local token manager refreshes the JWT when the token is close to expiry and keeps the FMTool MCP configuration synchronized.

## MCP Servers

The plugin currently defines two MCP server entries in `.mcp.json`:

### FMTool Token Manager

- Type: `stdio`
- Command: `python ${userHome}/.vscode/agent-plugins/github.com/intel-innersource/applications.agents-marketplace.plugins/plugins/dcg/dpe/fmtool-plugin/servers/fmtool-token-manager.py`
- Responsibility: maintain the FMTool JWT token for local MCP usage

### FMTool

- Type: `http`
- URL: `http://sysdebug-agent.intel.com:3010/mcp`
- Authentication header: `mcp-user-token`

## Token Storage

The FMTool JWT is synchronized into these local plugin files:

- `.mcp.json`
  - `mcpServers.FMTool.headers["mcp-user-token"]`
- `.env.mcp`
  - `mcp-user-token`
  - `MCP_USER_TOKEN`

This allows both MCP configuration and local scripts to consume the same token.

## Layout

Key plugin paths:

- `agents/` - FMTool agent definitions
- `skills/` - skill definitions and helper scripts
- `servers/` - local MCP server implementations
- `resources/` - bundled resources such as the FMTool certificate chain
- `hooks/` - plugin hook configuration
- `plugin.json` - plugin metadata
- `.mcp.json` - MCP server registration
- `.env.mcp` - local token environment values

## Development Notes

The local token manager is implemented as a dependency-free Python stdio MCP server. It is responsible for:

- checking token state on startup
- rechecking token validity every 5 minutes
- refreshing the token when the JWT `exp` is within 30 minutes
- exposing a local `fmtool_token_status` MCP tool for status reporting

## Summary

FMTool Plugin is the Fleet Management Tool integration package for Agent Marketplace, maintained by DCG China / DPE / SysDebug, with Kerberos-based authentication and local token management for secure access to the FMTool MCP backend.
