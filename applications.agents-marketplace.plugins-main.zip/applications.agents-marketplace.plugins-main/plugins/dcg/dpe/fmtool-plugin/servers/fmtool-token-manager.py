import base64
import json
import os
import subprocess
import sys
import tempfile
import threading
import time

from datetime import datetime, timezone
from pathlib import Path


REFRESH_INTERVAL_SECONDS = 5 * 60
REFRESH_WINDOW_SECONDS = 30 * 60
TOKEN_ENDPOINT = "https://sysdebug-agent.intel.com/api/agent/mcp-user-token"
TOOL_NAME = "fmtool_token_status"
SERVER_NAME = "FMTool Token Manager"
SERVER_VERSION = "1.0.0"
SUPPORTED_PROTOCOL_VERSION = "2024-11-05"


def utc_now_timestamp():
    return time.time()


def format_timestamp(timestamp):
    if timestamp is None:
        return None
    return datetime.fromtimestamp(timestamp, tz=timezone.utc).isoformat()


def decode_jwt_exp(token):
    if not token:
        return None

    parts = token.split(".")
    if len(parts) != 3:
        return None

    payload = parts[1]
    padding = "=" * (-len(payload) % 4)

    try:
        decoded_payload = base64.urlsafe_b64decode(
            (payload + padding).encode("ascii"))
        payload_json = json.loads(decoded_payload.decode("utf-8"))
    except (ValueError, json.JSONDecodeError, UnicodeDecodeError):
        return None

    exp = payload_json.get("exp")
    if not isinstance(exp, (int, float)):
        return None
    return float(exp)


def read_env_token(env_file_path):
    if not env_file_path.is_file():
        return None

    try:
        for line in env_file_path.read_text(encoding="utf-8").splitlines():
            if line.startswith("MCP_USER_TOKEN=") or line.startswith("mcp-user-token="):
                _, value = line.split("=", 1)
                if value:
                    return value
    except OSError:
        return None

    return None


def read_mcp_json_token(mcp_file_path):
    if not mcp_file_path.is_file():
        return None

    try:
        payload = json.loads(mcp_file_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None

    return (
        payload.get("mcpServers", {})
        .get("FMTool", {})
        .get("headers", {})
        .get("mcp-user-token")
    )


class TokenManager:
    def __init__(self):
        script_path = Path(__file__).resolve()
        default_plugin_root = script_path.parent.parent
        self.plugin_root = Path(default_plugin_root).resolve()
        self.env_file = Path(os.environ.get(
            "FMTOOL_ENV_FILE", self.plugin_root / ".env.mcp"))
        self.mcp_file = self.plugin_root / ".mcp.json"
        self.ca_cert = Path(
            os.environ.get(
                "FMTOOL_CA_CERT",
                self.plugin_root / "resources" / "fmtool.intel.com-chain.pem",
            )
        )
        self.lock = threading.Lock()
        self.stop_event = threading.Event()
        self.refresh_thread = None
        self.current_token = None
        self.current_exp = None
        self.last_refresh_time = None
        self.last_refresh_error = None
        self.message = "No token loaded."
        self.state = "fail"

    def start(self):
        self._load_existing_token()
        self.check_and_refresh("startup")
        self.refresh_thread = threading.Thread(
            target=self._refresh_loop, name="fmtool-token-refresh", daemon=True)
        self.refresh_thread.start()

    def stop(self):
        self.stop_event.set()

    def _load_existing_token(self):
        token = (
            os.environ.get("FMTOOL_MCP_USER_TOKEN")
            or os.environ.get("fmtool-mcp-user-token")
        )
        source = "environment"

        if not token:
            token = read_env_token(self.env_file)
            source = str(self.env_file)

        if not token:
            token = read_mcp_json_token(self.mcp_file)
            source = str(self.mcp_file)

        with self.lock:
            self.current_token = token
            self.current_exp = decode_jwt_exp(token)

            if token and self.current_exp:
                self.state = "ok" if self.current_exp > utc_now_timestamp() else "fail"
                self.message = "Loaded token from {source}.".format(
                    source=source)
            elif token:
                self.state = "fail"
                self.message = "Loaded token from {source}, but it is not a valid JWT with exp.".format(
                    source=source
                )
            else:
                self.state = "fail"
                self.message = "No token found in environment or local config files."

    def _refresh_loop(self):
        while not self.stop_event.wait(REFRESH_INTERVAL_SECONDS):
            self.check_and_refresh("scheduled")

    def _needs_refresh(self, exp_timestamp):
        if exp_timestamp is None:
            return True
        return (exp_timestamp - utc_now_timestamp()) <= REFRESH_WINDOW_SECONDS

    def _has_usable_token(self, exp_timestamp):
        return exp_timestamp is not None and exp_timestamp > utc_now_timestamp()

    def check_and_refresh(self, reason):
        with self.lock:
            token = self.current_token
            exp_timestamp = self.current_exp

        if token and self._has_usable_token(exp_timestamp) and not self._needs_refresh(exp_timestamp):
            self._persist_token(token)
            with self.lock:
                self.state = "ok"
                self.message = "Token is valid; no refresh needed during {reason} check.".format(
                    reason=reason
                )
            return

        try:
            refreshed_token = self._fetch_token()
            refreshed_exp = decode_jwt_exp(refreshed_token)
            if refreshed_exp is None:
                raise RuntimeError(
                    "Endpoint returned a token without a valid JWT exp claim.")

            self._persist_token(refreshed_token)

            with self.lock:
                self.current_token = refreshed_token
                self.current_exp = refreshed_exp
                self.last_refresh_time = utc_now_timestamp()
                self.last_refresh_error = None
                self.state = "ok"
                self.message = "Token refreshed successfully during {reason} check.".format(
                    reason=reason
                )
        except Exception as exc:
            error_message = str(exc)
            with self.lock:
                self.last_refresh_error = error_message
                if self._has_usable_token(self.current_exp):
                    self.state = "ok"
                    self.message = (
                        "Token refresh failed during {reason} check, but the current token remains valid: {error}"
                    ).format(reason=reason, error=error_message)
                else:
                    self.state = "fail"
                    self.message = "Token refresh failed during {reason} check: {error}".format(
                        reason=reason,
                        error=error_message,
                    )

    def _fetch_token(self):
        if sys.platform.startswith("win"):
            command = [
                "curl.exe",
                "--negotiate",
                "-u",
                ":",
                "-X",
                "POST",
                TOKEN_ENDPOINT,
                "--noproxy",
                "*",
            ]
        else:
            command = [
                "curl",
                "--negotiate",
                "-u",
                ":",
                "-X",
                "POST",
                TOKEN_ENDPOINT,
                "--noproxy",
                "*",
                "--cacert",
                str(self.ca_cert),
            ]

        completed = subprocess.run(
            command,
            capture_output=True,
            text=True,
            check=False,
        )
        if completed.returncode != 0:
            detail = completed.stderr.strip() or completed.stdout.strip() or "curl returned no output"
            raise RuntimeError(
                "Token request failed: {detail}".format(detail=detail))

        try:
            response = json.loads(completed.stdout)
        except json.JSONDecodeError as exc:
            raise RuntimeError(
                "Token endpoint returned non-JSON output.") from exc

        if response.get("message") != "success":
            raise RuntimeError("Token endpoint did not report success.")

        token = response.get("token")
        if not token:
            raise RuntimeError(
                "Token endpoint response did not include a token.")

        return token

    def _persist_token(self, token):
        self._persist_env_file(token)
        self._persist_mcp_file(token)

    def _persist_env_file(self, token):
        lines = []
        if self.env_file.is_file():
            lines = self.env_file.read_text(encoding="utf-8").splitlines()

        next_lines = []
        saw_lower = False
        saw_upper = False

        for line in lines:
            if line.startswith("mcp-user-token="):
                next_lines.append("mcp-user-token={token}".format(token=token))
                saw_lower = True
            elif line.startswith("MCP_USER_TOKEN="):
                next_lines.append("MCP_USER_TOKEN={token}".format(token=token))
                saw_upper = True
            else:
                next_lines.append(line)

        if not saw_lower:
            next_lines.append("mcp-user-token={token}".format(token=token))
        if not saw_upper:
            next_lines.append("MCP_USER_TOKEN={token}".format(token=token))

        content = "\n".join(next_lines) + "\n"
        self._atomic_write_text(self.env_file, content)

    def _persist_mcp_file(self, token):
        try:
            payload = json.loads(self.mcp_file.read_text(encoding="utf-8"))
        except FileNotFoundError as exc:
            raise RuntimeError("Missing MCP config file: {path}".format(
                path=self.mcp_file)) from exc
        except json.JSONDecodeError as exc:
            raise RuntimeError("Invalid JSON in MCP config file: {path}".format(
                path=self.mcp_file)) from exc

        payload.setdefault("mcpServers", {})
        payload["mcpServers"].setdefault("FMTool", {})
        payload["mcpServers"]["FMTool"].setdefault("headers", {})
        payload["mcpServers"]["FMTool"]["headers"]["mcp-user-token"] = token

        content = json.dumps(payload, indent=2) + "\n"
        self._atomic_write_text(self.mcp_file, content)

    def _atomic_write_text(self, path, content):
        path.parent.mkdir(parents=True, exist_ok=True)
        with tempfile.NamedTemporaryFile(
                mode="w",
                encoding="utf-8",
                dir=path.parent,
                delete=False,
        ) as temp_file:
            temp_file.write(content)
            temp_path = Path(temp_file.name)

        os.replace(temp_path, path)

    def status_payload(self):
        with self.lock:
            exp_timestamp = self.current_exp
            payload = {
                "state": self.state,
                "message": self.message,
                "expires_at": format_timestamp(exp_timestamp),
                "refresh_needed": self._needs_refresh(exp_timestamp),
                "last_refresh_time": format_timestamp(self.last_refresh_time),
            }
            if self.last_refresh_error:
                payload["last_refresh_error"] = self.last_refresh_error
            return payload


class StdioMcpServer:
    def __init__(self, token_manager):
        self.token_manager = token_manager
        self.should_exit = False

    def serve(self):
        self.token_manager.start()
        try:
            while not self.should_exit:
                message = self._read_message(sys.stdin.buffer)
                if message is None:
                    break

                response = self._handle_message(message)
                if response is not None:
                    self._write_message(sys.stdout.buffer, response)
        finally:
            self.token_manager.stop()

    def _handle_message(self, message):
        method = message.get("method")
        request_id = message.get("id")

        if method == "initialize":
            requested_version = message.get(
                "params", {}).get("protocolVersion")
            return {
                "jsonrpc": "2.0",
                "id": request_id,
                "result": {
                    "protocolVersion": requested_version or SUPPORTED_PROTOCOL_VERSION,
                    "capabilities": {"tools": {"listChanged": False}},
                    "serverInfo": {
                        "name": SERVER_NAME,
                        "version": SERVER_VERSION,
                    },
                },
            }

        if method == "notifications/initialized":
            return None

        if method == "ping":
            return {"jsonrpc": "2.0", "id": request_id, "result": {}}

        if method == "tools/list":
            return {
                "jsonrpc": "2.0",
                "id": request_id,
                "result": {
                    "tools": [
                        {
                            "name": TOOL_NAME,
                            "description": "Report FMTool token refresh status.",
                            "inputSchema": {
                                "type": "object",
                                "properties": {},
                                "additionalProperties": False,
                            },
                        }
                    ]
                },
            }

        if method == "tools/call":
            params = message.get("params", {})
            if params.get("name") != TOOL_NAME:
                return self._error_response(request_id, -32602, "Unknown tool requested.")

            status = self.token_manager.status_payload()
            return {
                "jsonrpc": "2.0",
                "id": request_id,
                "result": {
                    "content": [
                        {
                            "type": "text",
                            "text": json.dumps(status),
                        }
                    ],
                    "isError": status["state"] != "ok",
                },
            }

        if method == "shutdown":
            return {"jsonrpc": "2.0", "id": request_id, "result": None}

        if method == "exit":
            self.should_exit = True
            return None

        if request_id is None:
            return None

        return self._error_response(request_id, -32601, "Method not found.")

    def _error_response(self, request_id, code, message):
        return {
            "jsonrpc": "2.0",
            "id": request_id,
            "error": {
                "code": code,
                "message": message,
            },
        }

    def _read_message(self, stream):
        first_line = stream.readline()
        if not first_line:
            return None

        while first_line in (b"\r\n", b"\n"):
            first_line = stream.readline()
            if not first_line:
                return None

        if first_line.lstrip().startswith(b"{"):
            return json.loads(first_line.decode("utf-8"))

        headers = {}
        line = first_line
        while line not in (b"\r\n", b"\n", b""):
            header_name, header_value = line.decode("ascii").split(":", 1)
            headers[header_name.strip().lower()] = header_value.strip()
            line = stream.readline()

        content_length = int(headers.get("content-length", "0"))
        if content_length <= 0:
            return None

        body = stream.read(content_length)
        if not body:
            return None

        return json.loads(body.decode("utf-8"))

    def _write_message(self, stream, message):
        payload = json.dumps(message, separators=(",", ":")).encode("utf-8")
        stream.write(payload)
        stream.write(b"\n")
        stream.flush()


def main():
    server = StdioMcpServer(TokenManager())
    server.serve()


if __name__ == "__main__":
    main()
