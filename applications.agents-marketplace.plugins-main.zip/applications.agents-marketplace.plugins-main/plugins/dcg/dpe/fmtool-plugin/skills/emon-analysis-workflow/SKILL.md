---
name: emon-analysis-workflow
display_name: EMON Analysis Workflow (POC)
display_order: 3
description: 'Analyze Intel Xeon EMON Excel data for performance triage, bottleneck isolation, socket/core/uncore review, PCIe or memory issue investigation, and comparison against known metric expectations and similar issue documentation.'
argument-hint: 'Describe the symptom, CPU generation if known, and attach one or more EMON Excel files.'
---

# EMON Analysis Workflow

## When to Use

- Investigating Intel Xeon performance issues with EMON Excel exports
- Triaging core, memory, PCIe, socket, or uncore bottlenecks
- Comparing EMON data against known expectations for SPR, EMR, GNR, SRF, and CWF platforms
- Correlating EMON observations with issue descriptions and similar documentation or known issues
- Deciding whether the current capture is sufficient or whether the user must recollect data

## What This Skill Produces

- A concise problem statement tied to the captured workload and failing symptom
- A component-oriented status summary for system, socket, core, and relevant uncore blocks
- A list of abnormal or missing critical metrics/events
- A comparison against known expectations and, when available, similar issue documentation
- Recommended next debugging actions, including missing metrics to recollect

## Required Inputs

- One or more EMON Excel files when available
- A problem statement with failing symptom, workload type, and expected behavior
- Collection context when known: CPU generation, socket/core affinity, workload duration, BIOS or tuning deltas, and suspected device or subsystem

## Intake Rules

1. Identify whether the request includes EMON files, a symptom description, or both.
2. Identify the likely CPU generation and the captured components or sheet names.
3. Route the analysis to the closest dominant path: core, PCIe, memory, or generic system/socket triage.
4. Use critical metrics first, then expand only if the data contradicts the first hypothesis.
5. If required events are missing, stop guessing and explicitly ask for recollection or the missing event list.

## Procedure

1. Validate inputs.
   Confirm file type, visible EMON views, workload description, and CPU generation if it can be inferred.
2. Build the first hypothesis.
   Choose the nearest controlling component based on the symptom: core throughput, memory bandwidth or latency, PCIe path, or broad socket/system behavior.
3. Load the relevant references.
   Use the [workflow definition](./workflow-definition.md) for the stepwise analysis path, the [critical metrics catalog](./emon_critical_metrics.json) for generation and component coverage, and the [threshold hints](./emon_thresholds.json) where explicit thresholds already exist.
4. Read the smallest useful JSON section.
    Do not scan the full metric catalog by default. Use the JSON structure below to jump directly to the matching CPU generation and component path.
5. Evaluate critical metrics and events.
   Start with system and socket signals, then drill into core or uncore blocks needed by the selected hypothesis.
6. Correlate with external knowledge.
   If issue description or document search is available, compare the observed metrics and events with similar issues and known workarounds.
7. Produce a decision.
   State what is abnormal, what is still uncertain, and whether the data supports a likely bottleneck or recollection request.

## JSON Structure

Use this mental model when reading `./emon_critical_metrics.json`:

```json
{
   "known_expectation_profiles": {
      "SPR_EMR": {
         "system": {},
         "socket": {}
      },
      "GNR_SRF_CWF": {
         "system": {},
         "socket": {}
      }
   },
   "known_expectation_map": {
      "SPR": "SPR_EMR",
      "EMR": "SPR_EMR",
      "GNR": "GNR_SRF_CWF",
      "SRF": "GNR_SRF_CWF",
      "CWF": "GNR_SRF_CWF"
   },
   "SPR": {
      "system": {},
      "socket": {},
      "core": {},
      "uncore": {
         "cha": {},
         "chacms": {},
         "cms": {},
         "iio": {},
         "i": {},
         "m": {}
      }
   }
}
```

Read it in this order:

1. `known_expectation_map` to map CPU generation to the shared expectation profile.
2. `known_expectation_profiles.<profile>.system` and `socket` for shared first-pass expectations.
3. `<CPU>.system` and `<CPU>.socket` for baseline critical metrics.
4. `<CPU>.core` for compute issues.
5. `<CPU>.uncore.iio` and `<CPU>.uncore.i` for PCIe issues.
6. `<CPU>.uncore.m` plus `cha` or `chacms` or `cms` for memory or fabric issues.

Preferred targeted reads:

- Core issue: expectation profile, `<CPU>.system`, `<CPU>.socket`, `<CPU>.core`, `<CPU>.uncore.cha`
- PCIe issue: expectation profile, `<CPU>.system`, `<CPU>.socket`, `<CPU>.uncore.iio`, `<CPU>.uncore.i`, `<CPU>.uncore.cha`, then `chacms` or `cms` if needed
- Memory issue: expectation profile, `<CPU>.system`, `<CPU>.socket`, `<CPU>.uncore.m`, `<CPU>.uncore.cha`, then `chacms` or `cms` if needed

## Branching Logic

- If EMON file and issue description are both present, perform metric analysis first and use document search to strengthen or reject the hypothesis.
- If only EMON is present, derive the likely bottleneck from the captured metrics and report what additional symptom details would reduce ambiguity.
- If only issue description is present, search for related issues and list the minimum EMON views or events needed to confirm the hypothesis.
- If multiple EMON files are present, compare good versus bad runs first. Use generation-matched critical metrics before comparing broader counters.

## Completion Criteria

- The CPU generation and captured components are identified or explicitly marked unknown.
- The metric catalog is read by CPU generation and component path, not as a full file dump.
- The most relevant critical metrics and events are reviewed for the chosen path.
- Every abnormal result is tied to a metric or event, not just prose.
- Missing data is called out explicitly.
- The conclusion includes next debug steps or recollection guidance.

## References

- [workflow definition](./workflow-definition.md)
- [critical metrics catalog](./emon_critical_metrics.json)
- [threshold hints](./emon_thresholds.json)

