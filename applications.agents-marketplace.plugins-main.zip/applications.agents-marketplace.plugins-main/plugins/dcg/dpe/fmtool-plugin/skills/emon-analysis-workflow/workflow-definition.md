# EMON Analysis Workflow Definition

## Goal

Turn EMON captures and issue context into a defensible first-pass performance diagnosis.
The workflow should isolate the most likely bottleneck, compare the observed behavior against known expectations, and recommend the next debug action without overstating confidence.

## Inputs

### Minimum useful input

- One EMON Excel file or one detailed issue description

### Preferred input

- EMON Excel file
- Workload name and failing symptom
- CPU generation or platform family
- Collection conditions such as socket count, bound cores, BIOS settings, and good versus bad comparison runs
- Suspected device or subsystem if already known

## Entry Decision

1. If EMON and issue description are both present, trust EMON for the first bottleneck hypothesis and use issue or document search to confirm or reject it.
2. If only EMON is present, classify the workload and isolate the dominant bottleneck from the captured metrics.
3. If only issue description is present, search for similar issues and list the EMON views or events needed to confirm the likely causes.
4. If multiple EMON files are present, compare good versus bad captures before deep per-component analysis.

## Stepwise Procedure

### 1. Normalize the request

- Identify the CPU generation when possible: SPR, EMR, GNR, SRF, or CWF.
- Enumerate the captured views, such as system, socket, core, CHA, CHACMS, CMS, IIO, I, or memory views.
- Confirm the workload type and the observed symptom: throughput drop, higher latency, low PCIe bandwidth, core frequency drop, or memory saturation.

### 2. Choose the primary path

- Use the core path when the symptom is compute throughput, CPI growth, or per-core slowdown.
- Use the PCIe path when the symptom is device bandwidth, DMA latency, or host-to-device or device-to-host imbalance.
- Use the memory path when the symptom is DRAM bandwidth, read latency, page behavior, or fabric distress associated with memory traffic.
- Use the generic system/socket path when the issue is broad, unclear, or spans multiple components.

### 3. Review system and socket baselines first

- Check frequency, CPI, utilization, package power, uncore frequency, and DDR data rate.
- Compare values against the generation-specific expectations from the critical metrics catalog and threshold hints.
- If system and socket baselines already contradict the symptom, report that conflict before drilling deeper.

### 4. Run the component-specific analysis

#### Core path

- Focus on core, socket, and CHA views.
- Review frequency, CPI, TMA, branch behavior, memory-bound versus core-bound balance, and license-level residency.
- Compare the active core frequency to idle or less-loaded cores when available.
- If frequency falls while package power approaches TDP, treat power or thermal constraint as a candidate cause.
- If higher license-level residency coincides with lower frequency, treat instruction mix as a candidate cause.
- If CHA dynamic prefetch throttle exceeds about 10 percent or distress stays elevated, treat CHA or fabric backpressure as a candidate cause.

#### PCIe path

- Focus on IIO, I, CHA, CHACMS, and CMS views.
- Calculate inbound write latency with:

$$
\frac{UNC\_I\_CACHE\_TOTAL\_OCCUPANCY.MEM - UNC\_I\_FAF\_OCCUPANCY}{UNC\_I\_TRANSACTIONS.WR\_PREF \times UNC\_I\_CLOCKTICKS}
$$

- Calculate inbound read latency with:

$$
\frac{UNC\_IIO\_COMP\_BUF\_OCCUPANCY.CMPD.ALL\_PARTS}{UNC\_IIO\_COMP\_BUF\_INSERTS.CMPD.ALL\_PARTS \times UNC\_IIO\_CLOCKTICKS}
$$

- Review IIO fast-path acceptance and rejection, lost forward behavior, and the derived FMTool latency metrics when available.
- If CHA distress is high, suspect traffic is backing up before or inside CHA.
- If CHACMS or CMS bounce traffic is large or sustained, treat mesh or memory-side fabric movement as a likely pressure point.

#### Memory path

- Focus on memory, CHA, CHACMS, and CMS views.
- Review total read and write bandwidth, page hit and miss behavior, DRAM access balance, and RPQ read latency when available.
- If memory bandwidth is high together with poor page behavior and rising latency, treat DRAM pressure as the likely cause.
- If CHA, CHACMS, or CMS distress grows with moderate DRAM bandwidth, suspect fabric congestion or throttling rather than raw DRAM saturation.

### 5. Correlate with known issues or documentation

- Search similar issues only after forming the first EMON-based hypothesis.
- Compare the suspect metrics and events from the current capture with values reported by known issues.
- Prefer the issue whose metric pattern, component involvement, and failure mode best match the current case.
- If the known issue requires events not present in the current capture, list the missing events instead of forcing a match.

### 6. Produce the conclusion

The output should include:

- A one-paragraph summary of the likely bottleneck
- CPU generation and captured components
- Critical metrics and events reviewed
- Abnormal metrics and how they compare with expectations
- Similar issue matches or a clear statement that none were convincing
- Next steps, including recollection guidance if the data is incomplete

## Common Decision Rules

- If the required view is missing, state the missing component and stop the branch there.
- If the metrics contradict each other, prefer the simplest explanation supported by system and socket baselines.
- If no similar issue matches, return to the EMON evidence and ask for one or two concrete missing facts, not a broad questionnaire.
- If data is insufficient, recommend collecting both good and bad scenarios with the same event set.

## Completion Checklist

- CPU generation identified or explicitly unknown
- Captured components listed
- First hypothesis chosen before broad search
- Critical metrics and events compared against known expectations
- Missing events or views called out
- Next debug action provided
