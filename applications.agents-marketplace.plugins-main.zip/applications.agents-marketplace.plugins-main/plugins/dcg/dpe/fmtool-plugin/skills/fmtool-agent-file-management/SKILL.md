---
name: fmtool-agent-file-management
description: 'Upload local files to FMTool-managed services and download FMTool-hosted files without a local Node MCP server. Use when a tool needs a file URL, file id, uploaded artifact, or local copy on Windows or Linux.'
argument-hint: 'Describe whether you need to upload or download, and include the source or destination path.'
---

# FMTool Agent File Management

Use this skill when a workflow needs to move files between the local machine and the FMTool backend.

This skill replaces the old local `fmtool-agent-file-management` MCP server. Prefer the bundled upload and download scripts in this skill instead of spawning a local Node process or depending on other FMTool tools.

## When to Use

- A tool requires a backend file URL or uploaded artifact before it can run.
- You need to hand a local file to an FMTool-managed capability.
- You have a remote file id from FMTool and need a local copy.
- The user is on Windows or Linux and the workflow must avoid local Node dependencies.

## Procedure

1. Determine whether the task is an upload or a download.
2. Normalize the path before calling any script.
3. For uploads, confirm the source path points to an existing file, then run the bundled upload script for the current platform.
4. For downloads, confirm the FMTool file id, then run the bundled download script for the current platform with either a destination file path or a destination directory.
5. Return the resulting file id, URL, or saved local path to the user or to the next tool in the workflow.

## Path Rules

- Prefer absolute paths.
- Windows absolute path examples: `C:\\work\\trace\\capture.zip`, `D:\\reports\\summary.xlsx`.
- Linux absolute path examples: `/home/user/trace/capture.zip`, `/tmp/summary.xlsx`.
- If the user provides a relative path, resolve it against the current working directory before using it.
- For downloads, if the destination path is an existing directory, save the file there using the backend-provided filename when available.

## Script Selection

- Linux upload: [scripts/upload-file.sh](./scripts/upload-file.sh)
- Linux download: [scripts/download-file.sh](./scripts/download-file.sh)
- Windows upload: [scripts/upload-file.ps1](./scripts/upload-file.ps1)
- Windows download: [scripts/download-file.ps1](./scripts/download-file.ps1)

The scripts read the token from `MCP_USER_TOKEN` when it is already in the environment. Otherwise they fall back to `../../../.env.mcp`, which is populated by the extension sign-in flow.

## Script Usage

- Linux upload: `./scripts/upload-file.sh /absolute/path/to/file [file-name] [content-type]`
- Linux download: `./scripts/download-file.sh <file-id> [/absolute/output/path-or-directory]`
- Windows upload: `powershell -ExecutionPolicy Bypass -File .\scripts\upload-file.ps1 -FilePath C:\path\to\file [-FileName name.ext] [-ContentType application/octet-stream]`
- Windows download: `powershell -ExecutionPolicy Bypass -File .\scripts\download-file.ps1 -FileId <file-id> [-DestinationPath C:\path\to\output-or-dir]`

The Linux scripts use `curl`. The Windows scripts use `curl.exe`. Both use the bundled FMTool CA chain at `../../../resources/fmtool.intel.com-chain.pem` by default.

## Completion Checks

- Uploads: confirm the returned payload includes the uploaded file identity or backend response needed by the next step.
- Downloads: confirm the reported local path matches the requested destination behavior.
- If a transfer fails, surface the backend status or validation error and verify the path or file id before retrying.