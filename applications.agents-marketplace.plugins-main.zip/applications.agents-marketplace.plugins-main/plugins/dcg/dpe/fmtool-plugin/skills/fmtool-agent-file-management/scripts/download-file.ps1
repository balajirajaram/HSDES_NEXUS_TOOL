[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [string]$FileId,

    [string]$DestinationPath
)

$ErrorActionPreference = 'Stop'

$pluginRoot = (Resolve-Path (Join-Path $PSScriptRoot '..\..\..')).Path
$downloadUrl = if ($env:FMTOOL_DOWNLOAD_URL) { $env:FMTOOL_DOWNLOAD_URL } else { 'https://sysdebug-agent.intel.com/api/file/download' }
$envFile = if ($env:FMTOOL_ENV_FILE) { $env:FMTOOL_ENV_FILE } else { Join-Path $pluginRoot '.env.mcp' }
$caCert = if ($env:FMTOOL_CA_CERT) { $env:FMTOOL_CA_CERT } else { Join-Path $pluginRoot 'resources\fmtool.intel.com-chain.pem' }

function Get-McpUserToken {
    if ($env:MCP_USER_TOKEN) {
        return $env:MCP_USER_TOKEN
    }

    if (-not (Test-Path -LiteralPath $envFile)) {
        throw "Missing MCP user token. Set MCP_USER_TOKEN or populate $envFile."
    }

    foreach ($line in Get-Content -LiteralPath $envFile) {
        if ($line -match '^(MCP_USER_TOKEN|mcp-user-token)=(.*)$') {
            return $Matches[2]
        }
    }

    throw "Missing MCP user token. Set MCP_USER_TOKEN or populate $envFile."
}

function Get-DownloadFileName {
    param(
        [Parameter(Mandatory = $true)]
        [string]$HeadersPath,

        [Parameter(Mandatory = $true)]
        [string]$FallbackName
    )

    foreach ($line in Get-Content -LiteralPath $HeadersPath) {
        if ($line -match 'filename\*?=(?:UTF-8''''|"?)([^";]+)') {
            return [System.Uri]::UnescapeDataString($Matches[1])
        }
    }

    return $FallbackName
}

$token = Get-McpUserToken
$headersPath = [System.IO.Path]::GetTempFileName()
$bodyPath = [System.IO.Path]::GetTempFileName()

try {
    $curlArgs = @(
        '--fail',
        '--silent',
        '--show-error',
        '--cacert', $caCert,
        '-H', "Authorization: Bearer $token",
        '-G',
        '--data-urlencode', "file_id=$FileId",
        '-D', $headersPath,
        '-o', $bodyPath,
        $downloadUrl
    )

    & curl.exe @curlArgs
    if ($LASTEXITCODE -ne 0) {
        exit $LASTEXITCODE
    }

    $fileName = Get-DownloadFileName -HeadersPath $headersPath -FallbackName $FileId

    if (-not $DestinationPath) {
        $outputPath = Join-Path (Get-Location) $fileName
    } elseif ((Test-Path -LiteralPath $DestinationPath) -and (Get-Item -LiteralPath $DestinationPath).PSIsContainer) {
        $outputPath = Join-Path (Resolve-Path -LiteralPath $DestinationPath).Path $fileName
    } else {
        $outputPath = $DestinationPath
    }

    $outputDirectory = Split-Path -Path $outputPath -Parent
    if ($outputDirectory) {
        New-Item -ItemType Directory -Path $outputDirectory -Force | Out-Null
    }

    Move-Item -LiteralPath $bodyPath -Destination $outputPath -Force
    $bodyPath = $null
    Write-Output $outputPath
}
finally {
    if ($headersPath -and (Test-Path -LiteralPath $headersPath)) {
        Remove-Item -LiteralPath $headersPath -Force
    }

    if ($bodyPath -and (Test-Path -LiteralPath $bodyPath)) {
        Remove-Item -LiteralPath $bodyPath -Force
    }
}