#!/usr/bin/env bash

set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
PLUGIN_ROOT="$(cd -- "${SCRIPT_DIR}/../../.." && pwd)"
DOWNLOAD_URL="${FMTOOL_DOWNLOAD_URL:-https://sysdebug-agent.intel.com/api/file/download}"
ENV_FILE="${FMTOOL_ENV_FILE:-${PLUGIN_ROOT}/.env.mcp}"
CA_CERT="${FMTOOL_CA_CERT:-${PLUGIN_ROOT}/resources/fmtool.intel.com-chain.pem}"

usage() {
  echo "Usage: $(basename "$0") <file-id> [destination-path-or-directory]" >&2
  exit 1
}

read_token() {
  if [[ -n "${MCP_USER_TOKEN:-}" ]]; then
    printf '%s' "${MCP_USER_TOKEN}"
    return 0
  fi

  if [[ -f "${ENV_FILE}" ]]; then
    local token
    token="$(grep -E '^(MCP_USER_TOKEN|mcp-user-token)=' "${ENV_FILE}" | head -n 1 | cut -d '=' -f 2-)"
    if [[ -n "${token}" ]]; then
      printf '%s' "${token}"
      return 0
    fi
  fi

  echo "Missing MCP user token. Set MCP_USER_TOKEN or populate ${ENV_FILE}." >&2
  exit 1
}

extract_filename() {
  local headers_file="$1"
  local file_name

  file_name="$(tr -d '\r' < "${headers_file}" | sed -n "s/^content-disposition:.*filename=\"\{0,1\}\([^\";]*\).*/\1/ip" | head -n 1)"
  printf '%s' "${file_name}"
}

[[ $# -ge 1 ]] || usage

FILE_ID="$1"
DESTINATION_INPUT="${2:-}"
TOKEN="$(read_token)"
HEADERS_FILE="$(mktemp)"
BODY_FILE="$(mktemp)"

cleanup() {
  rm -f "${HEADERS_FILE}" "${BODY_FILE}"
}

trap cleanup EXIT

curl --fail --silent --show-error \
  --cacert "${CA_CERT}" \
  -H "Authorization: Bearer ${TOKEN}" \
  -G \
  --data-urlencode "file_id=${FILE_ID}" \
  -D "${HEADERS_FILE}" \
  -o "${BODY_FILE}" \
  "${DOWNLOAD_URL}"

FILE_NAME="$(extract_filename "${HEADERS_FILE}")"
if [[ -z "${FILE_NAME}" ]]; then
  FILE_NAME="${FILE_ID}"
fi

if [[ -z "${DESTINATION_INPUT}" ]]; then
  OUTPUT_PATH="$(pwd)/${FILE_NAME}"
elif [[ -d "${DESTINATION_INPUT}" ]]; then
  OUTPUT_PATH="${DESTINATION_INPUT%/}/${FILE_NAME}"
else
  OUTPUT_PATH="${DESTINATION_INPUT}"
fi

mkdir -p "$(dirname -- "${OUTPUT_PATH}")"
mv "${BODY_FILE}" "${OUTPUT_PATH}"

printf '%s\n' "${OUTPUT_PATH}"