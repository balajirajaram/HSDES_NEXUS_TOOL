[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [string]$FilePath,

    [string]$FileName,

    [string]$ContentType = 'application/octet-stream'
)

$ErrorActionPreference = 'Stop'

$pluginRoot = (Resolve-Path (Join-Path $PSScriptRoot '..\..\..')).Path
$uploadUrl = if ($env:FMTOOL_UPLOAD_URL) { $env:FMTOOL_UPLOAD_URL } else { 'https://sysdebug-agent.intel.com/api/file/upload' }
$envFile = if ($env:FMTOOL_ENV_FILE) { $env:FMTOOL_ENV_FILE } else { Join-Path $pluginRoot '.env.mcp' }
$caCert = if ($env:FMTOOL_CA_CERT) { $env:FMTOOL_CA_CERT } else { Join-Path $pluginRoot 'resources\fmtool.intel.com-chain.pem' }

function Get-McpUserToken {
    if ($env:MCP_USER_TOKEN) {
        return $env:MCP_USER_TOKEN
    }

    if (-not (Test-Path -LiteralPath $envFile)) {
        throw "Missing MCP user token. Set MCP_USER_TOKEN or populate $envFile."
    }

    foreach ($line in Get-Content -LiteralPath $envFile) {
        if ($line -match '^(MCP_USER_TOKEN|mcp-user-token)=(.*)$') {
            return $Matches[2]
        }
    }

    throw "Missing MCP user token. Set MCP_USER_TOKEN or populate $envFile."
}

$resolvedFilePath = (Resolve-Path -LiteralPath $FilePath).Path
if (-not $FileName) {
    $FileName = [System.IO.Path]::GetFileName($resolvedFilePath)
}

$token = Get-McpUserToken

$curlArgs = @(
    '--fail',
    '--silent',
    '--show-error',
    '--cacert', $caCert,
    '-H', "Authorization: Bearer $token",
    '-F', "file=@$resolvedFilePath;filename=$FileName;type=$ContentType",
    $uploadUrl
)

& curl.exe @curlArgs
if ($LASTEXITCODE -ne 0) {
    exit $LASTEXITCODE
}