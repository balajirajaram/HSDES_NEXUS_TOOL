#!/usr/bin/env bash

set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
PLUGIN_ROOT="$(cd -- "${SCRIPT_DIR}/../../.." && pwd)"
UPLOAD_URL="${FMTOOL_UPLOAD_URL:-https://sysdebug-agent.intel.com/api/file/upload}"
ENV_FILE="${FMTOOL_ENV_FILE:-${PLUGIN_ROOT}/.env.mcp}"
CA_CERT="${FMTOOL_CA_CERT:-${PLUGIN_ROOT}/resources/fmtool.intel.com-chain.pem}"

usage() {
  echo "Usage: $(basename "$0") <file-path> [file-name] [content-type]" >&2
  exit 1
}

read_token() {
  if [[ -n "${MCP_USER_TOKEN:-}" ]]; then
    printf '%s' "${MCP_USER_TOKEN}"
    return 0
  fi

  if [[ -f "${ENV_FILE}" ]]; then
    local token
    token="$(grep -E '^(MCP_USER_TOKEN|mcp-user-token)=' "${ENV_FILE}" | head -n 1 | cut -d '=' -f 2-)"
    if [[ -n "${token}" ]]; then
      printf '%s' "${token}"
      return 0
    fi
  fi

  echo "Missing MCP user token. Set MCP_USER_TOKEN or populate ${ENV_FILE}." >&2
  exit 1
}

[[ $# -ge 1 ]] || usage

FILE_PATH="$1"
FILE_NAME="${2:-$(basename -- "${FILE_PATH}")}"
CONTENT_TYPE="${3:-application/octet-stream}"

if [[ ! -f "${FILE_PATH}" ]]; then
  echo "File not found: ${FILE_PATH}" >&2
  exit 1
fi

TOKEN="$(read_token)"

curl --fail --silent --show-error \
  --cacert "${CA_CERT}" \
  -H "Authorization: Bearer ${TOKEN}" \
  -F "file=@${FILE_PATH};filename=${FILE_NAME};type=${CONTENT_TYPE}" \
  "${UPLOAD_URL}"