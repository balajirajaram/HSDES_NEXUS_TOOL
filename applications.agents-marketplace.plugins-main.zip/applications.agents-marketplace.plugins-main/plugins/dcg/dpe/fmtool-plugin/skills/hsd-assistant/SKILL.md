---
name: hsd-assistant
display_name: HSD Assistant for issue analysis and resolution
display_order: 4
description: 'Analyze an HSD ticket end-to-end using FMTool and Co-Design specs. Use when user asks for failure analysis, root cause, similar cases, PPIN/SN recurrence, and a downloadable HTML report.'
argument-hint: 'HSD#<ticket_id> [analysis request]'
tag: 'HSD, hsd, failure analysis'
---

# HSD Failure Analysis and Resolution Workflow

## What This Skill Produces
- A structured HSD analysis with evidence-backed conclusions.
- A top-3 similar completed ticket comparison with solutions.
- A historical recurrence section for the same server serial number or CPU PPIN.
- A downloadable HTML report with readable formatting.

## When to Use
- User provides an HSD ticket ID and asks for analysis or customer-facing conclusion.
- User asks for root cause, known-signal decode, or recommended next action.
- User asks to correlate current failure with historical records by S/N or PPIN.

## Required Inputs
- HSD ticket ID (for example: HSD#14025797599).
- Any explicit formatting constraints from the user (for example: in specified HTML format,include or exclude footer notes).

## Procedure
1. Parse the request and extract the HSD ticket ID.
2. Fetch core ticket context:
    - Call FMTool 'get_hsdes_issue_info'.
    - Call FMTool 'get_hsdes_issue_summary'.
3. Fetch log evidence:
    - Call FMTool 'get_log_analysis_result_list_by_page' with metadata.hsdid.
    - Record total logs, failure signatures, MCA status, and failure category.
    - Figure out the primary failure signature and its associated MCA status (for example MSCOD/MCACOD). 
4. Decode failure signatures when MSCOD or MCACOD is present:
    - Call MCP 'codesign-ask-specs-and-wikis' to search for mcastatus bit interpretation, especially decode for MSCOD and MCACOD.
5. Fetch similar HSD tickets:
    - For primary failure signature, call FMTool 'get_similar_hsdes_issues' with MSCOD/MCACOD or the interpretation in string as keyword.
    - Select top 3 records and extract their summaries or solutions if there is any.
6. Perform historical correlation when identifiers are available:
    - If server S/N or CPU PPIN exists, call FMTool 'get_log_analysis_result_main_db_schema' first.
    - Query historical records for same S/N and PPIN.
    - Summarize recurring signatures, timelines, and hypothesis.
7. FACR Check:
    - Based on PPIN, call FMTool 'get_fa_result_by_ppin_or_vid' to check if there is FA result for the same CPU. 
    - Call FMTool 'search_fa_statistics_by_filters' with `failure_conditions` as the primary FACR lookup field, because failure signatures are often recorded in FACR under the failure-condition text instead of `fault_reason`.
    - Build the `failure_conditions` query from the primary failure signature using this priority: decoded string interpretation first, then `MSCOD/MCACOD`, then the raw issue tag or signature token if needed.
    - Best first query is usually the decoded failure text, for example `DSB parity error`, `Core IFU parity error`, or similar human-readable wording from the MCA decode.
    - If the first `failure_conditions` query returns no match, retry once with a shorter normalized form of the same signature, such as only the decoded error name or only the `MSCOD/MCACOD` pair.
    - If decoded text is too specific, retry with a shorter phrase or the `MSCOD/MCACOD` pair.
    - Only use `fault_reason` as a secondary fallback when `failure_conditions` returns no result. Based on level 0, provide the percentage of CPU defect, and any recommended action from FACR.
8. Known signal check:
    - Based on the CPU type, search for the primary failure signature with FMTool MCP 'search_documents' to see if it is a known signal or known issue. If yes, record the document name and RDC ID, and summarize the resolution or mitigation.
9. Build conclusion:
    - If ticket/logs already provide a clear conclusion, report it with evidence and recommended operation.
    - If no clear conclusion exists, provide best-effort hypothesis and explicit next-step experiments/data to collect.
10. Generate final deliverables:
    - Return concise analysis in chat.
    - Create a downloadable HTML report for readability.
    - Remove Co-design comment text from the bottom of the page.

## Decision Logic
- No logs found:
  - Fall back to HSD summary + similar records + documented hypotheses.
- Conflicting categories (for example DIMM-related vs CPU-related):
  - Prefer first-error evidence and repeated signatures over secondary shutdown effects.
  - Explicitly label secondary effects (for example UBOX/PCU fatal cascades).
- Tool failure or transient endpoint error:
  - Retry once and continue with available validated evidence.
- Incomplete historical correlation due truncated payloads:
  - Re-query with smaller page size and multiple pages, then merge results.
- No FACR match by failure signature:
    - Retry FACR search against `failure_conditions` with a normalized decoded signature string before concluding that no FACR analog exists.

## Quality and Completion Checks
- Ticket metadata included: title, customer, priority, family (when available).
- Log evidence quantified: total logs and key signature counts.
- Signature decode includes both meaning and practical mitigation path.
- Similar records section includes exactly top 3 completed tickets with solution summary.
- Historical section includes same S/N or PPIN recurrence when identifiers exist.
- Next step section includes explicit experiments or data to gather when root cause is not confirmed.
- Final conclusion contains root cause, supporting evidence, and operation suggestion.
- Customer reply is exactly 3 sentences.
- Downloadable HTML is created and path is provided.
- HTML footer does not include Co-design comment text.

## Output Template

Use this structure and replace angle-bracket placeholders with actual values. Refer to ./referenche/example.html for the format and generate downloadable HTML report.

```text
[Note] This is AI Summary for your reference.

<HSD ID>: <HSD Title>
Customer: <Customer Name>  Priority: <HSD Priority>  Family: <HSD Family>
HSD Summary: <HSD Summary>

Log Analysis:
From <log_count> logs, <affected_count> contain <failure_signature> with <MCA_status>. Failure category: <failure_category>.
Log detail table with below columns: Log Name, Timestamp, Signature, MCA Status, Exaplanation for signature, Hypothesis (if any).

Similar HSD Records:
Table with below columns: HSD ID, HSD Title, Solution Summary.

Historical Records with same S/N or PPIN:
Table with below columns: PPIN, S/N, Failure Time, Signature, Hypothesis on relationship to current failure. Notic that if Failure Time for multiple records are the same and the signature are the same, these records are likely from the same failure event but not recurrence.

FACR Check:
For CPU with PPIN <PPIN>, <defect_percentage>% of CPUs show defect in FACR database. FACR recods are list in below table with columns: FACR CI#, PPIN/VID, Failure Signature, FA level 0 and level 1 results.

Known Signals:
Based on FMTool MCP 'search_documents', get similar known signal or known issue from <doc/wiki references>. If hit a known signal or known issue, highlight it in blod font and provide RDC ID if there is any. The potential resolution is <resolution>.

Next Steps:
From <doc/wiki references>, to confirm hypothesis, we recommend <experiments or data to gather with explicity execuable steps or commands>.

Final Conclusion:
<If known: root cause + evidence + operation suggestion. If unknown: best hypothesis + next-step experiments/data to gather.>

Reply to customer:
<three-sentence customer-facing summary>
```
