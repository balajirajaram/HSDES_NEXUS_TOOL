# PathLength x CPI TMA Attribution Analysis

A methodology for decomposing CPU performance differences between
configurations using **PathLength (PL)**, **CPI**, and **TMA**.

## Core Formula
```
Cycles/Task = PL x CPI = (Instructions/Task) x (Cycles/Instruction)
Per-category: PL x CPI x bound% = cycles per task in that category
```

## Quick Start
```bash
python scripts/path_length_analysis.py examples/pixart_4.6g.yaml
```

Generate a self-contained HTML report:
```bash
python scripts/path_length_analysis.py examples/pixart_4.6g.yaml -o reports/pixart_4.6g.html --format html
```

The output format is inferred from `-o`: `.html` / `.htm` produces HTML;
otherwise the script emits Markdown by default. Use `--format markdown` or
`--format html` to override inference.

## Data Collection
### Intel (EMON)
```bash
emon -i events.txt -f emon.dat -- taskset -c 0-15 <workload>
edp -p -f emon.dat > metric.csv
```
### AMD (perf stat)
```bash
perf stat -p <pids> -M PipelineL1 sleep 120
```

## Repo Structure
```
SKILL.md                         # Skill definition
README.md                        # This file
references/input_format.md       # Input format spec
scripts/path_length_analysis.py  # Analysis script
examples/pixart_4.6g.yaml        # 4.6 GHz configs
examples/pixart_3g.yaml          # 3 GHz configs
```

## License
MIT
