---
name: path-length-analysis
description: >
  Decompose CPU performance deltas into PathLength and CPI components,
  attributed through TMA L1 categories.
version: 1.0.0
metadata:
  openclaw:
    requires:
      bins: [python3]
---

# Path-Length x CPI x TMA Attribution Analysis

## When to Activate

- User asks to compare CPU performance across configs (SNC on/off, platforms, freq)
- User provides EMON CSV / perf stat output for 2+ configurations
- User wants to pinpoint whether delta is from instruction count or micro-arch efficiency

## Required Input Contract

The user must provide at least two comparable configurations: one baseline and
one or more targets. For every configuration, collect counters from the same
workload phase, same process scope, and the same measurement duration.

### 1. Workload Throughput
- `seconds_per_task`: wall-clock time per work unit, for example seconds/image.
- The throughput measurement should represent the same steady-state phase as the
  counter collection window.

### 2. Process-Specific CPU Counters
- Required fields:
  - `total_cycles`
  - `total_instructions`
  - `measurement_seconds`
- `total_cycles` and `total_instructions` must be collected over the exact same
  time window for that configuration.
- Baseline and target configurations must use the same `measurement_seconds`
  value, for example all configs use `sleep 120`. This is required so raw totals
  can be converted into comparable instructions/task and cycles/task.
- Counters may come from different tools, but the scope and duration must match:
  - Intel EMON / EDP CSV
  - Linux `perf stat -p <pids> sleep <T>`
  - Vendor tools that report equivalent total cycles and total instructions
- Do not mix process-specific counters with system-wide counters unless all
  compared configurations use the same scope and the workload is isolated.

### 3. TMA L1 Breakdown
- Required L1 categories:
  - `frontend_bound`
  - `backend_bound`
  - `bad_speculation`
  - `retiring`
- Intel source example: `metric_TMA_Frontend_Bound(%)`, Backend,
  Bad_Speculation, Retiring from EMON / EDP.
- AMD source example: `perf stat -p <pids> -M PipelineL1 sleep <T>`.
- TMA values must use the same workload phase and same duration as the cycle and
  instruction counters. If collected in a separate command, use the same `<T>`
  and same process set.
- Optional backend L2 categories:
  - `mem_bound`
  - `core_bound`

### Input Validation Before Analysis
- Reject or ask for clarification if any config is missing `total_cycles`,
  `total_instructions`, `measurement_seconds`, or L1 TMA categories.
- Reject or ask the user to rerun if `measurement_seconds` differs between the
  baseline and target configurations.
- After calculating `PL_inst`, compare every target against the baseline. The
  instructions/task should be close; this confirms each configuration executed
  approximately the same software work per task.
  - `abs(PL_inst_target / PL_inst_baseline - 1) <= 5%`: PASS
  - `5% < abs(...) <= 10%`: WARN; results may include software path length
    differences, not only micro-architecture efficiency.
  - `> 10%`: FAIL for apples-to-apples CPI/TMA attribution; ask the user to
    verify workload phase, PID set, task count, batch size, code path, and input
    data before interpreting the comparison.
- Normalize percentages to fractions before calculation, for example `44.7%` ->
  `0.447`.
- Check that L1 TMA categories sum to approximately `1.0`; warn if the sum is
  materially different.
- Treat `mem_bound` and `core_bound` as backend sub-breakdowns, not additional
  L1 categories to be added on top of the L1 total.

## Computation Methodology

### Step 1 - Base Metrics
```
CPI = total_cycles / total_instructions
IPC = 1 / CPI
tasks_completed = measurement_seconds / seconds_per_task
```

### Step 2 - PathLength
```
PL_inst = total_instructions / tasks_completed
PL_cycles = PL_inst x CPI = total_cycles / tasks_completed
```

`PL_cycles` is the absolute cycles/task value for each configuration. The main
comparison first finds the signed and absolute difference between two configs:

```
delta_total = PL_cycles(baseline) - PL_cycles(target)
abs_delta_total = abs(delta_total)
```

### Step 3 - PathLength Comparability Validation
```
pl_inst_delta_pct = PL_inst(target) / PL_inst(baseline) - 1
```

`PL_inst` should be close across configurations. If it is not close, the test may
be comparing different software work per task, so CPI/TMA attribution alone is
not sufficient to explain the performance delta.

### Step 4 - TMA Validation
Sum of L1 categories should be ~1.0.

### Step 5 - CPI Decomposition
```
CPI_c = CPI x bound%_c   for each category c
```

### Step 6 - PL x CPI Attribution (KEY)
```
PL_cycles_c = PL_cycles x bound%_c
            = PL_inst x CPI x bound%_c
            = cycles/task for category c
```

The attribution must compute total `PL_cycles/task` first, then multiply it by
each TMA bound percentage to get the cycles/task under that bound.

### Step 7 - Delta Analysis
```
delta_c = PL_cycles_c(baseline) - PL_cycles_c(target)
delta_total = PL_cycles(baseline) - PL_cycles(target)
```

### Step 8 - Attribution Fractions
```
fraction_c = delta_c / delta_total
```

Use the signed `delta_total` as the denominator. This preserves negative
fractions for categories that regress and offset the overall improvement. Report
`abs(delta_total)` separately as the absolute PL_cycles gap between the two
configurations.

### Step 9 - Performance Ratio
```
ratio = PL_cycles(target) / PL_cycles(baseline)
```

### Step 10 - Result Cross-Checks
```
sum_l1_bound = frontend_bound + backend_bound + bad_speculation + retiring
sum_l1_pl_cycles = sum(PL_cycles_c for L1 categories)
sum_l1_delta = sum(delta_c for L1 categories)
```

Required checks:
- `sum_l1_bound` should be approximately `1.0`.
- `sum_l1_pl_cycles` should reconstruct `PL_cycles` for each configuration.
- `sum_l1_delta` should reconstruct `delta_total` for each comparison.
- `mem_bound` and `core_bound` are backend sub-breakdowns; they should explain
  `backend_bound` but must not be added again to the L1 total.

## Output: Required Tables

The final report must show the calculation process first, then the per-config
absolute bound values, and finally the pairwise delta attribution. Use this table
order:

Format requirements:
- Markdown is the default text format.
- HTML output is recommended for sharing or review. It must preserve the same
  table order and values as Markdown, include readable styling, and be
  self-contained with no external assets.
- The HTML report must make wide tables horizontally scrollable and visually
  distinguish validation status values such as `PASS`, `WARN`, and `FAIL`.

0. **Data Validation**
   - PL_inst comparability vs baseline
   - L1 TMA sum check
   - PL_cycles reconstruction check
   - L1 delta reconstruction check for each comparison

1. **Calculation Process / Base Metrics**
   - Include a `Formula / Source` column so users can audit every derived value.
   - Required rows:
     - `measurement_seconds`
     - `seconds/task`
     - `tasks/sec`
     - `tasks_completed = measurement_seconds / seconds/task`
     - `total_cycles`
     - `total_instructions`
     - `CPI = total_cycles / total_instructions`
     - `IPC = 1 / CPI`
     - `PL_inst/task = total_instructions / tasks_completed`
     - `PL_cycles/task = total_cycles / tasks_completed`

2. **TMA Bound Percentages**
   - Show each config's bound percentage for:
     `frontend_bound`, `backend_bound`, `bad_speculation`, and `retiring`.
   - Show `mem_bound` and `core_bound` indented as backend sub-breakdowns when
     available.

3. **CPI Decomposition**
   - Show `CPI_c = CPI x bound%_c` for each L1 TMA category.
   - Include total CPI as a cross-check.

4. **Per-Config Bound PL_cycles (Absolute)**
   - This table is required before pairwise deltas.
   - For every bound and every config, output both:
     - `bound%`
     - `PL_cycles_c = PL_cycles x bound%_c`
   - Include an `L1 Total` row. Do not add `mem_bound` and `core_bound` into the
     L1 total again because they are backend sub-breakdowns.

5. **Pairwise PL_cycles Delta Attribution (KEY)**
   - For each baseline-vs-target comparison, output:
     - baseline `PL_cycles_c`
     - target `PL_cycles_c`
     - signed `delta_c = baseline - target`
     - `fraction_c = delta_c / delta_total`
   - Also output:
     - `delta_total = PL_cycles_baseline - PL_cycles_target`
     - `abs(delta_total)` as the absolute PL_cycles gap
     - performance ratio and speedup/slowdown
     - L1 delta reconstruction check
   - This is the most important result table. The fraction column explains how
     much each bound contributes to the total PL_cycles difference.

6. **Key Insights**
   - Summarize the dominant contributors, significant secondary contributors,
     and any negative contributors that offset the total improvement.

## Interpretation

| Fraction | Meaning |
|----------|---------|
| > 0.5 | Dominant contributor |
| 0.2-0.5 | Significant |
| < 0.2 | Minor |
| Negative | Category regressed |

## Example: Pixart 128x128 @ 4.6 GHz (6776P SNC-dis vs SNC2)

| Metric | SNC-disable | SNC2 |
|--------|-------------|------|
| sec/img | 0.376 | 0.364 |
| CPI | 0.656 | 0.617 |
| PL inst/img | 10,601,018,906 | 10,916,325,709 |
| PL cycles/img | 6,953,677,706 | 6,731,480,222 |

### Bound PL_cycles and Attribution (delta = 222,197,484 cycles/img)

| Category | SNC-disable PL_cycles/img | SNC2 PL_cycles/img | Delta | Fraction |
|----------|---------------------------|--------------------|-------|----------|
| frontend_bound | 3,107,836,656 | 3,068,590,059 | 39,246,598 | 17.7% |
| backend_bound | 1,643,575,652 | 1,453,265,733 | 190,309,919 | 85.6% |
| -- mem_bound | 817,349,129 | 664,566,288 | 152,782,841 | 68.8% |
| -- core_bound | 826,226,523 | 788,699,445 | 37,527,078 | 16.9% |
| bad_speculation | 461,373,030 | 456,717,917 | 4,655,113 | 2.1% |
| retiring | 1,740,892,367 | 1,752,906,514 | -12,014,147 | -5.4% |

**Key Insight**: 85.6% of improvement is backend_bound (mem_bound 68.8%),
from SNC2 improving NUMA locality and reducing L3 miss latency.
