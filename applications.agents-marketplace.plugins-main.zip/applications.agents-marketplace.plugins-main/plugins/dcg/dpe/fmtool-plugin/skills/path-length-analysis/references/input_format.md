# Input Format Specification

## Required Fields Per Configuration

Every compared configuration must provide:

- `seconds_per_task` or workload-specific alias such as `seconds_per_img`
- `total_cycles`
- `total_instructions`
- `measurement_seconds`
- TMA L1: `frontend_bound`, `backend_bound`, `bad_speculation`, `retiring`

`total_cycles` and `total_instructions` must come from the same collection
window. Baseline and target configurations must use the same
`measurement_seconds` value, for example all configs are collected with
`sleep 120`.

After converting totals to per-task values, `PL_inst = total_instructions /
(measurement_seconds / seconds_per_task)` should be close across configurations.
Use baseline-relative thresholds: PASS within 5%, WARN from 5% to 10%, FAIL above
10% for apples-to-apples CPI/TMA attribution.

Result cross-checks should verify that L1 TMA reconstructs the total:

- `PL_cycles = total_cycles / (measurement_seconds / seconds_per_task)`
- `PL_cycles_c = PL_cycles * bound_c`
- `delta_total = PL_cycles_baseline - PL_cycles_target`
- `delta_c = PL_cycles_c_baseline - PL_cycles_c_target`
- `fraction_c = delta_c / delta_total`
- `sum(delta_c for L1 categories)` should match `delta_total`

Use `abs(delta_total)` as the absolute PL_cycles gap, but keep signed deltas and
fractions so regressed categories show up as negative contributors.

## Expected Output Tables

Reports may be emitted as Markdown or self-contained HTML. HTML output must keep
the same table order and values as Markdown; it is only a presentation format.

The report should include these tables in order:

1. Data validation: PL_inst comparability, TMA sum, PL_cycles reconstruction.
2. Calculation process / base metrics: raw inputs, formulas, and derived values.
3. TMA bound percentages per config.
4. CPI decomposition per config.
5. Per-config bound PL_cycles: each config's `bound%` and absolute
  `PL_cycles_c = PL_cycles * bound_c` for every bound.
6. Pairwise delta attribution: baseline value, target value, signed delta, and
  `fraction_c = delta_c / delta_total` for every bound.
7. Key insights.

## 1. Intel EMON CSV
Key metrics: total cycles, total instructions, `metric_CPI`, `metric_core IPC`,
and `metric_TMA_..._bound%`.

## 2. AMD perf stat
```bash
perf stat -p <pids> sleep 120
perf stat -p <pids> -M PipelineL1 sleep 120
```
Output: total cycles, total instructions, plus `frontend_bound`,
`backend_bound`, `bad_speculation`, `retiring` as %slots.

If cycles/instructions and TMA are collected with separate commands, both
commands must use the same PID set and same duration.

## 3. Workload Log
```
patch_hw_128_... epoch time: 7.28 sec, loop: 20, time for eche loop: 0.36
```

## 4. YAML Config
```yaml
configs:
  - name: "Config A"
    seconds_per_img: 0.376
    total_cycles: 2219258842242
    total_instructions: 3383303906106
    measurement_seconds: 120
    tma:
      frontend_bound: 0.447
      backend_bound: 0.236
      bad_speculation: 0.066
      retiring: 0.250
```
