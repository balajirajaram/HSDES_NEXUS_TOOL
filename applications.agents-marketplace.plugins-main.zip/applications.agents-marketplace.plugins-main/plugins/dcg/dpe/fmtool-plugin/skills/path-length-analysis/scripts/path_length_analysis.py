#!/usr/bin/env python3
"""
Path-Length x CPI x TMA Attribution Analysis

Usage:
    python path_length_analysis.py <config.yaml>
    python path_length_analysis.py <config.yaml> -o report.html --format html
"""

import argparse, sys, os, json, re
from datetime import datetime
from html import escape
try:
    import yaml
    HAS_YAML = True
except ImportError:
    HAS_YAML = False

TMA_L1 = ['frontend_bound', 'backend_bound', 'bad_speculation', 'retiring']
TMA_L2_BE = ['mem_bound', 'core_bound']
TMA_PL_DISPLAY = ['frontend_bound', 'backend_bound', 'mem_bound', 'core_bound', 'bad_speculation', 'retiring']
PL_INST_WARN_THRESHOLD = 0.05
PL_INST_FAIL_THRESHOLD = 0.10
RECON_WARN_THRESHOLD = 0.01
RECON_FAIL_THRESHOLD = 0.05


class InputValidationError(ValueError):
    """Raised when the input config cannot support PL x CPI conversion."""


def _cfg_name(cfg):
    return str(cfg.get('name', '<unnamed>')) if isinstance(cfg, dict) else '<invalid>'


def required_value(cfg, key, aliases=()):
    """Read a required field, accepting legacy aliases where needed."""
    for candidate in (key, *aliases):
        if isinstance(cfg, dict) and candidate in cfg and cfg[candidate] is not None:
            return cfg[candidate]
    accepted = ', '.join([key, *aliases])
    raise InputValidationError(f"Config '{_cfg_name(cfg)}' is missing required field: {accepted}")


def required_number(cfg, key, aliases=()):
    value = required_value(cfg, key, aliases)
    try:
        number = float(value)
    except (TypeError, ValueError):
        raise InputValidationError(
            f"Config '{_cfg_name(cfg)}' field '{key}' must be numeric; got {value!r}"
        )
    if number <= 0:
        raise InputValidationError(
            f"Config '{_cfg_name(cfg)}' field '{key}' must be positive; got {value!r}"
        )
    return number


def normalize_tma(cfg):
    """Validate and normalize TMA values to fractions in [0, 1]."""
    name = _cfg_name(cfg)
    tma = required_value(cfg, 'tma')
    if not isinstance(tma, dict):
        raise InputValidationError(f"Config '{name}' field 'tma' must be a mapping")

    missing = [cat for cat in TMA_L1 if cat not in tma]
    if missing:
        raise InputValidationError(
            f"Config '{name}' is missing required TMA L1 categories: {', '.join(missing)}"
        )

    normalized = {}
    for cat, value in tma.items():
        try:
            normalized[cat] = float(value)
        except (TypeError, ValueError):
            raise InputValidationError(
                f"Config '{name}' TMA category '{cat}' must be numeric; got {value!r}"
            )

    if any(normalized[cat] > 1.0 for cat in TMA_L1):
        normalized = {cat: value / 100.0 for cat, value in normalized.items()}

    l1_sum = sum(normalized[cat] for cat in TMA_L1)
    if not 0.95 <= l1_sum <= 1.05:
        print(
            f"Warning: Config '{name}' TMA L1 sum is {l1_sum:.3f}; expected approximately 1.0",
            file=sys.stderr,
        )
    return normalized


def validate_configs(configs):
    if not isinstance(configs, list) or len(configs) < 2:
        raise InputValidationError('Input must contain at least two comparable configs')

    durations = []
    for cfg in configs:
        required_value(cfg, 'name')
        required_number(cfg, 'seconds_per_task', aliases=('seconds_per_img',))
        required_number(cfg, 'total_cycles')
        required_number(cfg, 'total_instructions')
        durations.append((_cfg_name(cfg), required_number(cfg, 'measurement_seconds')))
        cfg['_normalized_tma'] = normalize_tma(cfg)

    base_duration = durations[0][1]
    mismatched = [(name, dur) for name, dur in durations if abs(dur - base_duration) > 1e-9]
    if mismatched:
        duration_text = ', '.join(f'{name}={dur:g}s' for name, dur in durations)
        raise InputValidationError(
            'All configs must use the same measurement_seconds so raw cycles and '
            f'instructions can be converted consistently; got {duration_text}'
        )


class ConfigMetrics:
    """Compute all derived metrics for one configuration."""

    def __init__(self, cfg):
        self.name = str(required_value(cfg, 'name'))
        self.sec_per_task = required_number(cfg, 'seconds_per_task', aliases=('seconds_per_img',))
        self.total_cyc = required_number(cfg, 'total_cycles')
        self.total_ins = required_number(cfg, 'total_instructions')
        self.meas_sec = required_number(cfg, 'measurement_seconds')
        self.tma = cfg.get('_normalized_tma') or normalize_tma(cfg)

        self.cpi = self.total_cyc / self.total_ins
        self.ipc = 1.0 / self.cpi
        self.tasks = self.meas_sec / self.sec_per_task

        self.pl_inst = self.total_ins / self.tasks
        self.pl_cyc = self.total_cyc / self.tasks

        self.cpi_decomp = {c: self.cpi * self.tma.get(c, 0) for c in TMA_L1}
        all_cats = TMA_L1 + TMA_L2_BE
        self.plcpi = {c: self.pl_inst * self.cpi * self.tma.get(c, 0) for c in all_cats}


def fmt(v, decimals=3):
    if abs(v) >= 1e6:
        return f'{v:,.0f}'
    return f'{v:.{decimals}f}'


def pct(v):
    return f'{v * 100:.1f}%'


def pl_inst_status(delta_ratio):
    abs_delta = abs(delta_ratio)
    if abs_delta > PL_INST_FAIL_THRESHOLD:
        return 'FAIL'
    if abs_delta > PL_INST_WARN_THRESHOLD:
        return 'WARN'
    return 'PASS'


def reconstruction_status(error_ratio):
    abs_error = abs(error_ratio)
    if abs_error > RECON_FAIL_THRESHOLD:
        return 'FAIL'
    if abs_error > RECON_WARN_THRESHOLD:
        return 'WARN'
    return 'PASS'


def render_inline_html(text):
    """Render the small Markdown subset used in generated reports."""
    rendered = escape(str(text))
    rendered = re.sub(r'`([^`]+)`', r'<code>\1</code>', rendered)
    rendered = re.sub(r'\*\*([^*]+)\*\*', r'<strong>\1</strong>', rendered)
    return rendered


def split_markdown_table_row(line):
    row = line.strip()
    if row.startswith('|'):
        row = row[1:]
    if row.endswith('|'):
        row = row[:-1]
    return [cell.strip() for cell in row.split('|')]


def is_markdown_table_separator(cells):
    return bool(cells) and all(re.fullmatch(r':?-{3,}:?', cell.strip()) for cell in cells)


def html_cell_class(text):
    plain = re.sub(r'[`*]', '', str(text)).strip()
    classes = []
    status = plain.lower()
    if status in ('baseline', 'pass', 'warn', 'fail'):
        classes.append(f'status-{status}')
    if plain.startswith('-') and any(ch.isdigit() for ch in plain):
        classes.append('negative')
    if not classes:
        return ''
    return ' class="' + ' '.join(classes) + '"'


def render_html_table(table_lines):
    rows = [split_markdown_table_row(line) for line in table_lines]
    if len(rows) >= 2 and is_markdown_table_separator(rows[1]):
        headers = rows[0]
        body_rows = rows[2:]
    else:
        headers = rows[0]
        body_rows = rows[1:]

    html = ['<div class="table-wrap">', '<table>']
    html.append('<thead><tr>')
    for cell in headers:
        html.append(f'<th>{render_inline_html(cell)}</th>')
    html.append('</tr></thead>')
    html.append('<tbody>')
    for row in body_rows:
        html.append('<tr>')
        for cell in row:
            html.append(f'<td{html_cell_class(cell)}>{render_inline_html(cell)}</td>')
        html.append('</tr>')
    html.append('</tbody></table></div>')
    return '\n'.join(html)


def markdown_report_to_html(markdown, title='PathLength Analysis Report'):
    """Convert the generated Markdown report into a self-contained HTML page."""
    lines = markdown.splitlines()
    body = []
    in_ul = False
    in_code = False
    code_lines = []
    i = 0

    def close_list():
        nonlocal in_ul
        if in_ul:
            body.append('</ul>')
            in_ul = False

    while i < len(lines):
        line = lines[i]
        stripped = line.strip()

        if in_code:
            if stripped.startswith('```'):
                body.append('<pre><code>' + escape('\n'.join(code_lines)) + '</code></pre>')
                code_lines = []
                in_code = False
            else:
                code_lines.append(line)
            i += 1
            continue

        if stripped.startswith('```'):
            close_list()
            in_code = True
            code_lines = []
            i += 1
            continue

        if not stripped:
            close_list()
            i += 1
            continue

        if stripped.startswith('|'):
            close_list()
            table_lines = []
            while i < len(lines) and lines[i].strip().startswith('|'):
                table_lines.append(lines[i])
                i += 1
            body.append(render_html_table(table_lines))
            continue

        heading = re.match(r'^(#{1,6})\s+(.*)$', stripped)
        if heading:
            close_list()
            level = len(heading.group(1))
            text = render_inline_html(heading.group(2))
            body.append(f'<h{level}>{text}</h{level}>')
            i += 1
            continue

        if stripped.startswith('- '):
            if not in_ul:
                body.append('<ul>')
                in_ul = True
            body.append(f'<li>{render_inline_html(stripped[2:])}</li>')
            i += 1
            continue

        close_list()
        body.append(f'<p>{render_inline_html(stripped)}</p>')
        i += 1

    close_list()
    if in_code:
        body.append('<pre><code>' + escape('\n'.join(code_lines)) + '</code></pre>')

    generated_at = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    body_html = '\n'.join(body)
    return f'''<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>{escape(title)}</title>
  <style>
    :root {{
      --bg: #f6f8fb;
      --card: #ffffff;
      --text: #172033;
      --muted: #667085;
      --border: #d9e2ef;
      --header: #0f172a;
      --accent: #2563eb;
      --pass: #087443;
      --warn: #b45309;
      --fail: #b42318;
      --baseline: #475467;
      --negative: #b42318;
    }}
    * {{ box-sizing: border-box; }}
    body {{
      margin: 0;
      background: var(--bg);
      color: var(--text);
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
      line-height: 1.5;
    }}
    main {{ max-width: 1320px; margin: 0 auto; padding: 32px 20px 56px; }}
    .report-header {{
      margin-bottom: 28px;
      padding: 28px 32px;
      border-radius: 18px;
      color: #fff;
      background: linear-gradient(135deg, #111827, #1d4ed8);
      box-shadow: 0 18px 40px rgba(15, 23, 42, 0.18);
    }}
    .report-header h1 {{ margin: 0 0 8px; font-size: 30px; }}
    .report-header p {{ margin: 0; color: #dbeafe; }}
    h1, h2, h3 {{ color: var(--header); }}
    h1 {{ margin-top: 32px; }}
    h2 {{ margin-top: 32px; padding-top: 20px; border-top: 1px solid var(--border); }}
    h3 {{ margin-top: 24px; }}
    p, li {{ color: var(--text); }}
    code {{
      padding: 2px 5px;
      border-radius: 5px;
      background: #eef2ff;
      color: #1e3a8a;
      font-family: "SFMono-Regular", Consolas, monospace;
      font-size: 0.92em;
    }}
    pre {{ overflow-x: auto; padding: 16px; border-radius: 12px; background: #0f172a; }}
    pre code {{ padding: 0; background: transparent; color: #e5e7eb; }}
    .table-wrap {{
      overflow-x: auto;
      margin: 14px 0 24px;
      border: 1px solid var(--border);
      border-radius: 14px;
      background: var(--card);
      box-shadow: 0 8px 24px rgba(15, 23, 42, 0.06);
    }}
    table {{ width: 100%; border-collapse: collapse; min-width: 720px; }}
    th, td {{ padding: 10px 12px; border-bottom: 1px solid var(--border); text-align: right; white-space: nowrap; }}
    th:first-child, td:first-child {{ text-align: left; position: sticky; left: 0; background: inherit; }}
    th {{ background: #eff6ff; color: #1e3a8a; font-weight: 700; }}
    tbody tr:nth-child(even) {{ background: #fbfdff; }}
    tbody tr:hover {{ background: #f1f7ff; }}
    td.status-pass, td.status-warn, td.status-fail, td.status-baseline {{ font-weight: 700; }}
    td.status-pass {{ color: var(--pass); }}
    td.status-warn {{ color: var(--warn); }}
    td.status-fail {{ color: var(--fail); }}
    td.status-baseline {{ color: var(--baseline); }}
    td.negative {{ color: var(--negative); }}
    strong {{ font-weight: 700; }}
    ul {{ margin-top: 8px; }}
    footer {{ margin-top: 40px; color: var(--muted); font-size: 13px; }}
  </style>
</head>
<body>
  <main>
    <section class="report-header">
      <h1>{escape(title)}</h1>
      <p>Generated at {escape(generated_at)} · PathLength × CPI × TMA attribution</p>
    </section>
    {body_html}
    <footer>Generated by scripts/path_length_analysis.py</footer>
  </main>
</body>
</html>
'''


def generate_comparison(configs):
    validate_configs(configs)
    metrics = [ConfigMetrics(c) for c in configs]
    base = metrics[0]
    out = []

    # Table 0: Data Validation
    out.append('## Table 0: Data Validation\n')
    out.append('### PL_inst Comparability')
    out.append('')
    out.append('| Config | PL inst/task | Delta vs Baseline | Status |')
    out.append('|--------|--------------|-------------------|--------|')
    for m in metrics:
        delta_ratio = m.pl_inst / base.pl_inst - 1.0
        status = 'BASELINE' if m is base else pl_inst_status(delta_ratio)
        out.append(f'| {m.name} | {fmt(m.pl_inst)} | {pct(delta_ratio)} | {status} |')
    out.append('')
    out.append(
        f'Rule: PASS <= {PL_INST_WARN_THRESHOLD:.0%}, WARN <= {PL_INST_FAIL_THRESHOLD:.0%}, '
        f'FAIL > {PL_INST_FAIL_THRESHOLD:.0%}. Large PL_inst drift means configs may not be '
        'running the same software work per task.'
    )
    out.append('')

    out.append('### L1 TMA / PL_cycles Reconstruction')
    out.append('')
    out.append('| Config | L1 Bound Sum | PL cycles/task | Sum L1 PL cycles | Error | Error % | Status |')
    out.append('|--------|--------------|----------------|------------------|-------|---------|--------|')
    for m in metrics:
        l1_bound_sum = sum(m.tma[c] for c in TMA_L1)
        l1_pl_sum = sum(m.plcpi[c] for c in TMA_L1)
        recon_error = l1_pl_sum - m.pl_cyc
        error_ratio = recon_error / m.pl_cyc
        out.append(
            f'| {m.name} | {pct(l1_bound_sum)} | {fmt(m.pl_cyc)} | {fmt(l1_pl_sum)} | '
            f'{fmt(recon_error)} | {pct(error_ratio)} | {reconstruction_status(error_ratio)} |'
        )
    out.append('')
    out.append(
        'Rule: L1 category PL cycles should reconstruct total PL cycles because '
        '`PL_cycles_c = PL_cycles * bound_c`. L2 rows such as mem_bound/core_bound '
        'are backend sub-breakdowns and are not added to the L1 total.'
    )
    out.append('')

    # Table 1: Calculation Process / Base Metrics
    out.append('## Table 1: Calculation Process / Base Metrics\n')
    hdr = '| Metric | Formula / Source | ' + ' | '.join(m.name for m in metrics) + ' |'
    calc_sep = '|--------|------------------|' + '|'.join(['----------'] * len(metrics)) + '|'
    config_sep = '|----------|' + '|'.join(['----------'] * len(metrics)) + '|'
    out.append(hdr)
    out.append(calc_sep)
    calc_rows = [
        ('measurement_seconds', 'input counter duration', lambda m: fmt(m.meas_sec)),
        ('seconds/task', 'input workload time', lambda m: fmt(m.sec_per_task, 4)),
        ('tasks/sec', '1 / seconds/task', lambda m: fmt(1.0 / m.sec_per_task, 3)),
        ('tasks_completed', 'measurement_seconds / seconds/task', lambda m: fmt(m.tasks, 3)),
        ('total_cycles', 'input counter total', lambda m: fmt(m.total_cyc)),
        ('total_instructions', 'input counter total', lambda m: fmt(m.total_ins)),
        ('CPI', 'total_cycles / total_instructions', lambda m: fmt(m.cpi, 3)),
        ('IPC', '1 / CPI', lambda m: fmt(m.ipc, 3)),
        ('PL_inst/task', 'total_instructions / tasks_completed', lambda m: fmt(m.pl_inst)),
        ('PL_cycles/task', 'total_cycles / tasks_completed', lambda m: fmt(m.pl_cyc)),
    ]
    for label, formula, value_fn in calc_rows:
        vals = ' | '.join(value_fn(m) for m in metrics)
        out.append(f'| {label} | {formula} | {vals} |')
    out.append('')

    # Table 2: TMA Breakdown
    out.append('## Table 2: TMA Breakdown (bound%)\n')
    hdr2 = '| Category | ' + ' | '.join(m.name for m in metrics) + ' |'
    out.append(hdr2)
    out.append(config_sep)
    for c in TMA_PL_DISPLAY:
        vals = ' | '.join(pct(m.tma.get(c, 0)) for m in metrics)
        prefix = '  -> ' if c in TMA_L2_BE else ''
        out.append(f'| {prefix}{c} | {vals} |')
    out.append('')

    # Table 3: CPI Decomposition
    out.append('## Table 3: CPI Decomposition (CPI x bound%)\n')
    out.append(hdr2)
    out.append(config_sep)
    for c in TMA_L1:
        vals = ' | '.join(f'{m.cpi_decomp[c]:.4f}' for m in metrics)
        out.append(f'| {c} | {vals} |')
    vals = ' | '.join(f'{m.cpi:.4f}' for m in metrics)
    out.append(f'| **Total (CPI)** | {vals} |')
    out.append('')

    # Table 4: Per-Config Bound PL_cycles
    out.append('## Table 4: Per-Config Bound PL_cycles (Absolute)\n')
    per_config_cols = []
    for m in metrics:
        per_config_cols.extend([f'{m.name} bound%', f'{m.name} PL_cycles/task'])
    out.append('| Category | ' + ' | '.join(per_config_cols) + ' |')
    out.append('|----------|' + '|'.join(['----------'] * len(per_config_cols)) + '|')
    for c in TMA_PL_DISPLAY:
        vals = []
        for m in metrics:
            vals.extend([pct(m.tma.get(c, 0)), fmt(m.plcpi.get(c, 0))])
        prefix = '  -> ' if c in TMA_L2_BE else ''
        out.append(f'| {prefix}{c} | ' + ' | '.join(vals) + ' |')
    l1_vals = []
    for m in metrics:
        l1_bound_sum = sum(m.tma[c] for c in TMA_L1)
        l1_pl_sum = sum(m.plcpi[c] for c in TMA_L1)
        l1_vals.extend([pct(l1_bound_sum), fmt(l1_pl_sum)])
    out.append('| **L1 Total** | ' + ' | '.join(l1_vals) + ' |')
    out.append('')
    out.append('Note: mem_bound and core_bound are backend sub-breakdowns; do not add them to the L1 total again.')
    out.append('')

    # Table 5: PL x CPI Delta Attribution
    for i, comp in enumerate(metrics[1:], 1):
        out.append(f'## Table 5: PL x CPI Delta Attribution -- {base.name} vs {comp.name}\n')
        out.append(f'| Category | {base.name} PL_cycles/task | {comp.name} PL_cycles/task | Delta | Fraction of Delta |')
        out.append('|----------|---------------------------|---------------------------|-------|-------------------|')
        delta_total = base.pl_cyc - comp.pl_cyc
        for c in TMA_PL_DISPLAY:
            d = base.plcpi.get(c, 0) - comp.plcpi.get(c, 0)
            frac = d / delta_total if abs(delta_total) > 0 else 0
            prefix = '  -> ' if c in TMA_L2_BE else ''
            out.append(f'| {prefix}{c} | {fmt(base.plcpi.get(c,0))} | {fmt(comp.plcpi.get(c,0))} | {fmt(d)} | {pct(frac)} |')
        out.append(f'| **Total** | {fmt(base.pl_cyc)} | {fmt(comp.pl_cyc)} | {fmt(delta_total)} | 100.0% |')
        l1_delta_sum = sum(base.plcpi[c] - comp.plcpi[c] for c in TMA_L1)
        recon_error = l1_delta_sum - delta_total
        error_ratio = recon_error / delta_total if abs(delta_total) > 0 else 0
        out.append(f'\nAbsolute PL_cycles delta: **{fmt(abs(delta_total))} cycles/task**')
        out.append(
            f'L1 delta check: Σ(L1 category deltas) = **{fmt(l1_delta_sum)}**, '
            f'total PL_cycles delta = **{fmt(delta_total)}**, '
            f'error = **{fmt(recon_error)}** ({pct(error_ratio)}, {reconstruction_status(error_ratio)}).'
        )
        ratio = comp.pl_cyc / base.pl_cyc
        out.append(f'\nPerformance ratio (B/A): **{ratio:.4f}**')
        if delta_total > 0:
            out.append(f'Speedup: **{1/ratio:.2f}x**')
        out.append('')

    # Table 6: Key Insights
    out.append('## Table 6: Key Insights\n')
    for i, comp in enumerate(metrics[1:], 1):
        delta_total = base.pl_cyc - comp.pl_cyc
        if abs(delta_total) < 1:
            continue
        deltas = {c: base.plcpi.get(c,0) - comp.plcpi.get(c,0) for c in TMA_PL_DISPLAY}
        sorted_d = sorted(deltas.items(), key=lambda x: abs(x[1]), reverse=True)
        direction = 'faster' if delta_total > 0 else 'slower'
        out.append(f'### {base.name} vs {comp.name}')
        out.append(f'- {comp.name} is **{direction}** by {fmt(abs(delta_total))} cycles/task ({abs(delta_total)/base.pl_cyc*100:.1f}%)')
        out.append(f'- Top contributor: **{sorted_d[0][0]}** ({pct(sorted_d[0][1]/delta_total)})')
        for cat, d in sorted_d[1:3]:
            out.append(f'- {cat}: {pct(d/delta_total)}')
        out.append('')

    return '\n'.join(out)


def main():
    parser = argparse.ArgumentParser(description='Path-Length x CPI x TMA Attribution Analysis')
    parser.add_argument('config', help='YAML or JSON config file')
    parser.add_argument('-o', '--output', help='Output file (default: stdout)')
    parser.add_argument(
        '--format',
        choices=('markdown', 'md', 'html'),
        help='Output format. Defaults to html for .html/.htm output files, otherwise markdown.',
    )
    args = parser.parse_args()

    ext = os.path.splitext(args.config)[1].lower()
    with open(args.config, encoding='utf-8') as f:
        if ext in ('.yaml', '.yml'):
            if not HAS_YAML:
                print('Error: PyYAML not installed. Run: pip install pyyaml', file=sys.stderr)
                sys.exit(1)
            data = yaml.safe_load(f)
        else:
            data = json.load(f)

    try:
        report_md = generate_comparison(data.get('configs') if isinstance(data, dict) else None)
    except InputValidationError as e:
        print(f'Input error: {e}', file=sys.stderr)
        sys.exit(2)

    output_format = args.format
    if output_format == 'md':
        output_format = 'markdown'
    if output_format is None:
        output_ext = os.path.splitext(args.output or '')[1].lower()
        output_format = 'html' if output_ext in ('.html', '.htm') else 'markdown'

    if output_format == 'html':
        title = f'PathLength Analysis Report - {os.path.basename(args.config)}'
        report = markdown_report_to_html(report_md, title)
    else:
        report = report_md

    if args.output:
        output_dir = os.path.dirname(os.path.abspath(args.output))
        if output_dir:
            os.makedirs(output_dir, exist_ok=True)
        with open(args.output, 'w', encoding='utf-8') as f:
            f.write(report)
        print(f'{output_format.upper()} report written to {args.output}')
    else:
        print(report)


if __name__ == '__main__':
    main()
