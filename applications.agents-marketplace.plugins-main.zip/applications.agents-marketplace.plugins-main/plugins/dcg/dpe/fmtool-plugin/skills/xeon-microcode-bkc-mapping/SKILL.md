---
name: xeon-microcode-bkc-mapping
display_name: Xeon Microcode and IPU/BKC Version Mapping
display_order: 1
description: Look up microcode or IPU/BKC version based on user inputs for Xeon processors.
---


# Microcode and IPU/BKC Version Lookup Script

## Purpose

The script provides two main functionalities:

1.  **Look up IPU/BKC version:** Given a microcode and CPU type (or CPU ID), it retrieves the corresponding IPU/BKC version.
2.  **Look up microcode:** Given an IPU/BKC version and CPU type (or CPU ID), it retrieves the corresponding microcode.


## Usage

* **Lookup IPU/BKC version:**

    ```bash
    python3 ./skills/xeon-microcode-bkc-mapping/microcode_and_version_lookup.py -m <microcode> [-c <cpu_type> | -i <cpu_id>]
    ```

    * Replace `<microcode>` with the microcode value.
    * Replace `<cpu_type>` with the actual CPU type (e.g., `ICX`, `CLX`, `SPR`, `EMR`, `GNR`, `SRF`).
    * Replace `<cpu_id>` with the actual CPU ID (e.g., `0x806f8`).

* **Lookup microcode:**

    ```bash
    python3 ./skills/xeon-microcode-bkc-mapping/microcode_and_version_lookup.py -v <ipu_bkc_version> [-c <cpu_type> | -i <cpu_id>]
    ```

    * Replace `<ipu_bkc_version>` with the IPU/BKC version.
    * Replace `<cpu_type>` with the actual "exact" CPU type (e.g., `ICX`, `CLX`, `SPR`, `SPR-HBM`, `EMR`, `GNR-AP`, `GNR-SP`, `SRF`). 
    * Replace `<cpu_id>` with the actual CPU ID (e.g., `0x806f8`).

**Example:**

* To get the IPU/BKC version for microcode "0x2b000001" and CPU type "SPR":

    ```bash
    python3 ./skills/xeon-microcode-bkc-mapping/microcode_and_version_lookup.py -m 0x2b000001 -c SPR
    ```

* To get the IPU/BKC version for microcode "0x2b000001" and CPU ID "0x806f8":

    ```bash
    python3 ./skills/xeon-microcode-bkc-mapping/microcode_and_version_lookup.py -m 0x2b000001 -i 0x806f8
    ```

* To get the microcode for IPU/BKC version "PC" and CPU type "SPR":

    ```bash
    python3 ./skills/xeon-microcode-bkc-mapping/microcode_and_version_lookup.py -v PC -c SPR
    ```

* To get the microcode for IPU/BKC version "PC" and CPU ID "0x806f8":

    ```bash
    python3 ./skills/xeon-microcode-bkc-mapping/microcode_and_version_lookup.py -v PC -i 0x806f8
    ```

* A microcode may hive multiple IPU/BKC versions, and an IPU/BKC version may also hive multiple microcodes. The script will return all matched results in these cases.

    ```bash
    python3 ./skills/xeon-microcode-bkc-mapping/microcode_and_version_lookup.py -m 0x01000381 -c GNR
    ```

    Output:
    ```text
    IPU/BKC version: [GNR-AP] between [PV] and [MR1] or [GNR-SP] between [PV] and [MR1]
    ```
