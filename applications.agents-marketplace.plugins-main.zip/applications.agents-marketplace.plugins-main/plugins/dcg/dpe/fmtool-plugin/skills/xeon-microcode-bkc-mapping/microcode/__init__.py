# INTEL CONFIDENTIAL
# Copyright (c) 2025 Intel Corporation
#
# The source code  contained or  described herein and  all documents related to
# the source code  ("Material") are owned by Intel Corporation or its suppliers
# or licensors.  Title to the  Material  remains with  Intel Corporation or its
# suppliers  and licensors. The Material contains trade secrets and proprietary
# and  confidential  information  of  Intel  or  its  suppliers  and  licensors.
# The Material  is protected  by worldwide  copyright and trade secret laws and
# treaty provisions.  No part of the Material  may  be used, copied, reproduced,
# modified, published, uploaded, posted, transmitted, distributed, or disclosed
# in any way without Intel's prior express written permission. No license under
# any  patent, copyright, trade secret or other intellectual property right is
# granted  to  or conferred upon you by disclosure or delivery of the Materials,
# either expressly, by implication, inducement, estoppel or otherwise.
# Any license under such intellectual property rights must be express and
# approved by Intel in writing.

import os
import sys
import re
import json

from collections import namedtuple
from collections.abc import Sequence
from typing import List, Optional, Dict, Any, Union

from .cpu_type import get_cputype_by_cpuid


Microcode = namedtuple("Microcode", ["microcode", "platform", "version"])

production_type = ["0", "1", "2", "3", "4", "5", "6", "7"]
debug_type = ["8", "9", "a", "b", "c", "d", "e", "f"]


class MicrocodeMappings(Sequence):

    def __init__(self, data: List[Microcode] = None) -> None:
        self.data = data or self.get_mapping()

    def get_mapping(self) -> List[Microcode]:
        curr_dir = os.path.abspath(os.path.dirname(__file__))
        mapping_path = os.path.join(curr_dir, "mapping.json")
        with open(mapping_path, "r") as fp:
            data = json.load(fp)
        return [Microcode(**mapping) for mapping in data] or []

    def _get_range(
            self,
            microcode: str,
            _pre: Optional[Microcode],
            _next: Optional[Microcode]
    ) -> Optional[Microcode]:

        if _pre is None and _next is None:
            return

        if _pre is None:
            return Microcode(microcode, _next.platform, f"pre-[{_next.version}]")

        if _next is None:
            return Microcode(microcode, _pre.platform, f"next-[{_pre.version}]")

        return Microcode(
            microcode=microcode,
            platform=_next.platform,
            version=f"between [{_pre.version}] and [{_next.version}]"
        )

    def compare_microcode(self, microcode: str, platform: str) -> Optional[Microcode]:
        _pre = None
        _next = None
        filtered_microcode_mapping_list = []
        for item in self.data:
            if platform in item.platform and item.microcode[3] == microcode[3] and (item.microcode[2] in production_type and microcode[2] in production_type):
                filtered_microcode_mapping_list.append(item)
        if not filtered_microcode_mapping_list:
            return
        try:
            int_microcode = int(microcode, 16)
        except (ValueError, TypeError):
            return
        if not int_microcode:
            return
        target_patch_version = int(microcode[-3:], 16)
        for curr in filtered_microcode_mapping_list:
            try:
                curr_patch_version = int(curr.microcode[-3:], 16)
                delta = target_patch_version - curr_patch_version
                if delta > 0:
                    if _pre is None or int(_pre.microcode[-3:], 16) < curr_patch_version:
                        _pre = curr
                elif delta < 0:
                    if _next is None or int(_next.microcode[-3:], 16) > curr_patch_version:
                        _next = curr
            except:
                continue
        return self._get_range(microcode, _pre, _next)

    def get_microcode_mapping(self, microcode: str, platform: str) -> Optional[Union[Microcode, List[Microcode]]]:
        _microcode = microcode.lower()

        if not re.match(r"0x[0-9a-f]{8}", _microcode):
            if re.match(r"0x[0-9a-f]{7}", _microcode):
                _microcode = "0x0" + _microcode[2:]
            else:
                return
        if _microcode[2] in debug_type:
            return Microcode(microcode=microcode, platform=platform, version="debug")

        exact_matches = [
            item for item in self.data if platform in item.platform and item.microcode == _microcode]
        if exact_matches:
            if len(exact_matches) == 1:
                return exact_matches[0]
            return exact_matches

        platform_match = []
        for item in self.data:
            if platform in item.platform and item.platform not in platform_match:
                platform_match.append(item.platform)

        if not platform_match:
            return self.compare_microcode(_microcode, platform)
        compare_result = []
        for _platform in platform_match:
            if self.compare_microcode(_microcode, _platform):
                compare_result.append(
                    self.compare_microcode(_microcode, _platform))
        return compare_result

    def get_microcode_by_version_and_platform(self, version: str, platform: str = None, cpu_id: str = None) -> str:
        _platform = None
        if cpu_id and (len(cpu_id) == 5 or len(cpu_id) == 7):
            _platform = get_cputype_by_cpuid(cpu_id)
        else:
            _platform = platform
        if not _platform:
            return None
        for item in self.data:
            if item.platform == _platform and item.version == version:
                return item.microcode
        return None

    def get_version(self, microcode: str, platform: str) -> str:
        mapping = self.get_microcode_mapping(microcode, platform)
        if not mapping:
            return
        if isinstance(mapping, list):
            parts = [f"[{m.platform}] {m.version}" for m in mapping]
            return " or ".join(parts)
        return f"[{mapping.platform}] {mapping.version}"

    def get_multiple_versions(self, microcode_objects: List[Dict[str, Any]]) -> List[str]:
        result = {}
        for microcode_object in microcode_objects:
            cpu_type = None
            if microcode_object.get("cpu_id") and len(microcode_object["cpu_id"]) == 7:
                cpu_type = get_cputype_by_cpuid(microcode_object["cpu_id"])
            else:
                cpu_type = microcode_object.get("cpu_type")
            version = self.get_version(microcode_object.get(
                "microcode"), cpu_type) if cpu_type else None
            result[microcode_object.get("microcode")] = version
        return result

    def get_version_by_microcode_and_platform(self, microcode: str, platform: str = None, cpu_id: str = None) -> str:
        _microcode = microcode.lower()

        if not re.match(r"0x[0-9a-f]{8}", _microcode):
            if re.match(r"0x[0-9a-f]{7}", _microcode):
                _microcode = "0x0" + _microcode[2:]
            else:
                return

        if _microcode[2] in debug_type:
            return "debug"

        _platform = None
        if cpu_id and (len(cpu_id) == 5 or len(cpu_id) == 7):
            _platform = get_cputype_by_cpuid(cpu_id)
        else:
            _platform = platform

        if not _platform:
            return
        exact_matches = [
            item for item in self.data if _platform in item.platform and item.microcode == _microcode]
        if exact_matches:
            if len(exact_matches) == 1:
                return f"[{exact_matches[0].platform}] {exact_matches[0].version}"
            # multiple platform variants found (e.g. GNR-AP and GNR-SP), return combined string
            parts = [f"[{m.platform}] {m.version}" for m in exact_matches]
            return " or ".join(parts)

        platform_match = []
        for item in self.data:
            if _platform in item.platform and item.platform not in platform_match:
                platform_match.append(item.platform)
        if not platform_match:
            _res = self.compare_microcode(_microcode, _platform)
            if _res:
                return f"[{_platform}] {_res.version}"
        version_compare_result = []
        for platform_in_data in platform_match:
            _res = self.compare_microcode(_microcode, platform_in_data)
            if _res and _res.version:
                version_compare_result.append(
                    f"[{platform_in_data}] {_res.version}")
        if version_compare_result:
            return " or ".join(version_compare_result)

        return

    def __getitem__(self, index):
        return self.data[index]

    def __len__(self):
        return len(self.data)

    def to_list(self):
        return list(map(lambda x: x._asdict(), self.data))
