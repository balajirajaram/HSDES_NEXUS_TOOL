# -*- coding: utf-8 -*-

# INTEL CONFIDENTIAL
# Copyright (c) 2023 Intel Corporation
#
# The source code  contained or  described herein and  all documents related to
# the source code  ("Material") are owned by Intel Corporation or its suppliers
# or licensors.  Title to the  Material  remains with  Intel Corporation or its
# suppliers  and licensors. The Material contains trade secrets and proprietary
# and  confidential  information  of  Intel  or  its  suppliers  and  licensors.
# The Material  is protected  by worldwide  copyright and trade secret laws and
# treaty provisions.  No part of the Material  may  be used, copied, reproduced,
# modified, published, uploaded, posted, transmitted, distributed, or disclosed
# in any way without Intel's prior express written permission. No license under
# any  patent,  copyright, trade secret or other intellectual property right is
# granted  to  or conferred upon you by disclosure or delivery of the Materials,
# either expressly, by implication, inducement, estoppel or otherwise.
# Any license under such intellectual property rights must be express and
# approved by Intel in writing.

import re


class CPUType():
    BDX = 'BDX'
    SKX = 'SKX'
    CLX = 'CLX'
    ICX = 'ICX'
    CPX = 'CPX'
    SPR = 'SPR'
    EMR = 'EMR'
    GNR = 'GNR'
    SRF = 'SRF'
    CWF = 'CWF'
    # TODO jiayu should Unknown be "" or "UNKNOWN"?
    UNKNOWN = 'UNKNOWN'

    def all_cpu_types():
        return [CPUType.BDX, CPUType.SKX, CPUType.CLX, CPUType.ICX, CPUType.CPX, CPUType.SPR, CPUType.EMR, CPUType.GNR]


def get_cputype_by_fms(family: int, model: int, stepping: int):
    '''
    Get CPU type by family, model, stepping
    https://wiki.ith.intel.com/display/BugNinja/Family-Model-Stepping+Decode
    '''
    cpu_type = CPUType.UNKNOWN
    if family == 6 and (model == 85 or model == 94):
        cpu_type = CPUType.SKX
        if stepping in [5, 6, 7]:
            cpu_type = CPUType.CLX
        if stepping in [10, 11]:
            cpu_type = CPUType.CPX
    elif family == 6 and (model == 106 or model == 108):
        cpu_type = CPUType.ICX
    elif family == 6 and (model == 79 or model == 86):
        cpu_type = CPUType.BDX
    elif family == 6 and model == 143:
        cpu_type = CPUType.SPR
    elif family == 6 and model == 207:
        cpu_type = CPUType.EMR
    elif family == 6 and (model == 173 or model == 174):
        cpu_type = CPUType.GNR
    elif family == 6 and model == 175:
        cpu_type = CPUType.SRF
    elif family == 6 and model == 221:
        cpu_type = CPUType.CWF
    else:
        pass
    return cpu_type


def get_cputype_by_cpuid(cpuid: str):
    '''
    Get CPU type by CPUID, example: 0x50654
    '''
    cpu_type = CPUType.UNKNOWN

    if cpuid.upper() in CPUType.all_cpu_types():
        return cpuid.upper()

    if cpuid.lower() in ["skylake", "skx"]:
        return CPUType.SKX
    if cpuid.lower() in ["cascadelake", "clx"]:
        return CPUType.CLX

    cpu_stepping = int(cpuid[-1], 16)
    cpu_model = int(cpuid[-5], 16) * 16 + int(cpuid[-2], 16)
    cpu_family = int(cpuid[-4:-2], 16)

    cpu_type = get_cputype_by_fms(cpu_family, cpu_model, cpu_stepping)

    return cpu_type


def get_cpu_type_for_non_purley(crashdump_version: str):
    '''
    Get CPU type for non-purley crashdump
    '''
    cpu_type = CPUType.UNKNOWN
    # [check _version]
    mask = 0x000ff000
    version_value = (int(
        crashdump_version, 16) & mask) >> 12 if "0x" in crashdump_version else crashdump_version
    if version_value in [0x1A, 0x1B]:
        cpu_type = CPUType.ICX
    elif version_value == 0x34:
        cpu_type = CPUType.CPX
    elif version_value in [0x1C, 0x1D, 0x6f, 0x33]:
        cpu_type = CPUType.SPR
    elif version_value == 0x45:
        cpu_type = CPUType.BDX
    elif version_value in [0x79]:
        cpu_type = CPUType.EMR
    elif version_value in [0x2f, 0x80, 0x84]:
        cpu_type = CPUType.GNR
    elif version_value in [0x82, 0x83]:
        cpu_type = CPUType.SRF
    elif version_value in [0x8f]:
        cpu_type = CPUType.CWF
    return cpu_type


def get_cpu_type_for_purley(microcode: str, crashdump_version: str, cpu_id_set: set = set(), mcode_set: set = set()):
    '''
    Get CPU type for purley crashdump
    '''
    if microcode:
        if microcode.startswith('0x2'):
            return CPUType.SKX
        if microcode.startswith('0x3') or microcode.startswith('0x5'):
            return CPUType.CLX
        # return cpu type

    # multiple sockets with same microcode
    if len(mcode_set) == 1:
        microcode = mcode_set.pop()
        if microcode.startswith('0x2'):
            return CPUType.SKX
        if microcode.startswith('0x3') or microcode.startswith('0x5'):
            return CPUType.CLX

    if len(cpu_id_set) > 0:
        if (len(cpu_id_set) > 1):
            cpu_type_set = set()
            for each in cpu_id_set:
                if each.upper() in CPUType.all_cpu_types():
                    cpu_type_set.add(each.upper())
            if len(cpu_type_set) == 1:
                return cpu_type_set.pop()

        for cpu_id in cpu_id_set:
            if cpu_id == "50654":
                return CPUType.SKX
            if cpu_id in ["50657", "50656", "50655", "0"]:
                return CPUType.CLX
            if cpu_id.lower() in ["skylake", "skx"]:
                return CPUType.SKX
            if cpu_id.lower() in ["cascadelake", "clx"]:
                return CPUType.CLX

    # crashdump_version
    version_value = (int(crashdump_version, 16) &
                     0x000ff000) >> 12 if "0x" in crashdump_version else crashdump_version
    if version_value in [0x2A, 0x2B]:
        return CPUType.SKX
    elif version_value in [0x2C, 0x2D, 0x2E]:
        return CPUType.CLX
    # set skx as default for purley crashdump_version = 0.x
    if crashdump_version.startswith("0."):
        return CPUType.SKX

    return CPUType.UNKNOWN


def get_cpu_type_from_cpu_modle_name(cpu_modle_name: str) -> CPUType:
    '''
    Get CPU type from cpu model name, such as:
    Intel(R) Xeon(R) Gold 5118 CPU @ 2.30GHz
    Intel(R) Xeon(R) Platinum 8336C CPU @ 2.30GHz
    Intel(R) Xeon(R) 6980P
    '''
    if cpu_modle_name:
        match = re.search(
            r'Xeon(?:\(R\))?.*?\s+(\d{4}[A-Z]?)', cpu_modle_name, re.IGNORECASE)
        if match:
            cpu_modle_code = match.group(1)
            if "P" in cpu_modle_code:
                return CPUType.GNR
            if "E" in cpu_modle_code:
                return CPUType.SRF
            second_digit = cpu_modle_code[1]
            if second_digit == "1":
                return CPUType.SKX
            if second_digit == "2":
                return CPUType.CLX
            if second_digit == "3":
                if "H" in cpu_modle_code:
                    return CPUType.CPX
                else:
                    return CPUType.ICX
            if second_digit == "4":
                return CPUType.SPR
            if second_digit == "5":
                return CPUType.EMR
    return CPUType.UNKNOWN
