# INTEL CONFIDENTIAL
# Copyright (c) 2025 Intel Corporation
#
# The source code  contained or  described herein and  all documents related to
# the source code  ("Material") are owned by Intel Corporation or its suppliers
# or licensors.  Title to the  Material  remains with  Intel Corporation or its
# suppliers  and licensors. The Material contains trade secrets and proprietary
# and  confidential  information  of  Intel  or  its  suppliers  and  licensors.
# The Material  is protected  by worldwide  copyright and trade secret laws and
# treaty provisions.  No part of the Material  may  be used, copied, reproduced,
# modified, published, uploaded, posted, transmitted, distributed, or disclosed
# in any way without Intel's prior express written permission. No license under
# any  patent,  copyright, trade secret or other intellectual property right is
# granted  to  or conferred upon you by disclosure or delivery of the Materials,
# either expressly, by implication, inducement, estoppel or otherwise.
# Any license under such intellectual property rights must be express and
# approved by Intel in writing.

import argparse

from microcode import MicrocodeMappings

microcode_mappings = MicrocodeMappings()

if __name__ == '__main__':
    parser = argparse.ArgumentParser(
        description="Microcode & IPU/BKC Version lookup.")
    group = parser.add_mutually_exclusive_group()
    group.add_argument("-m", "--microcode",
                       help="Microcode to look up version.")
    group.add_argument("-v", "--version", help="Version to look up microcode.")
    parser.add_argument("-c", "--cpu_type",
                        help="CPU type (e.g., ICX, SPR, GNR).")
    parser.add_argument("-i", "--cpu_id", help="CPU ID (e.g., 0x806f8).")

    args = parser.parse_args()

    if args.microcode and args.cpu_id:
        version = microcode_mappings.get_version_by_microcode_and_platform(
            microcode=args.microcode, cpu_id=args.cpu_id)
        print(f"IPU/BKC version: {version}")
    elif args.microcode and args.cpu_type:
        version = microcode_mappings.get_version_by_microcode_and_platform(
            microcode=args.microcode, platform=args.cpu_type)
        print(f"IPU/BKC version: {version}")
    elif args.version and args.cpu_id:
        microcode = microcode_mappings.get_microcode_by_version_and_platform(
            version=args.version, cpu_id=args.cpu_id)
        print(f"Microcode: {microcode}")
    elif args.version and args.cpu_type:
        microcode = microcode_mappings.get_microcode_by_version_and_platform(
            version=args.version, platform=args.cpu_type)
        print(f"Microcode: {microcode}")
    elif args.microcode or args.version or args.cpu_type or args.cpu_id:
        print("Error: For command-line mode, please provide either '-m <microcode> -c <cpu_type>', '-m <microcode> -i <cpu_id>', '-v <version> -c <cpu_type>', or '-v <version> -i <cpu_id>'.")
    else:
        while True:
            print(
                "Do you want to look up microcode or IPU/BKC version? (microcode/version/exit):")
            choice = input().lower()

            if choice == "version":
                microcode = input("Enter microcode: ")
                cpu_type = input("Enter CPU type: ")
                version = microcode_mappings.get_version_by_microcode_and_platform(
                    microcode=microcode, platform=cpu_type)
                print(f"IPU/BKC version: {version}")
            elif choice == "microcode":
                ipu_bkc_version = input("Enter IPU/BKC version: ")
                cpu_type = input("Enter CPU type: ")
                microcode = microcode_mappings.get_microcode_by_version_and_platform(
                    version=ipu_bkc_version, platform=cpu_type)
                print(f"Microcode: {microcode}")
            elif choice == "exit":
                break
            else:
                print("Invalid choice. Please enter 'microcode', 'version', or 'exit'.")
