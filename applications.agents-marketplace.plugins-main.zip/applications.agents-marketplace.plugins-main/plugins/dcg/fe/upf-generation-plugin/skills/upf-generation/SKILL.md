---
name: upf-generation
description: End-to-end UPF generation agent for COR dies. Generates pd_spec.py from inputs (HAS, spreadsheets, templates, pickles, floorplan), runs PD automation, produces RUM YAMLs, invokes RUM analyse + upfint, generates UPF files, runs DRC, and diffs against baseline. Use this skill when a user wants to generate UPF files for any COR die (MH, IMH, IOH) from scratch or from an existing pd_spec template.
---

# UPF Generation Agent

## Table of Contents

- [Overview](#overview)
- [Shared Procedures](#shared-procedures)
- [Phase 1 — Collect Environment & Die Info](#phase-1--collect-environment--die-info)
- [Phase 2 — Gather Input Files](#phase-2--gather-input-files)
- [Phase 3 — Generate or Validate pd_spec.py](#phase-3--generate-or-validate-pd_specpy)
- [Phase 4 — Run PD Automation & Generate RUM YAMLs](#phase-4--run-pd-automation--generate-rum-yamls)
- [Phase 5 — Run RUM Analyse](#phase-5--run-rum-analyse)
- [Phase 6 — Run RUM UPF Integration](#phase-6--run-rum-upf-integration)
- [Phase 7 — DRC Validation & Error Analysis](#phase-7--drc-validation--error-analysis)
- [Phase 8 — Diff Against Baseline](#phase-8--diff-against-baseline)
- [Phase 9 — Summary & Next Steps](#phase-9--summary--next-steps)

---

## OVERVIEW

This skill performs end-to-end UPF generation for COR dies (MH, IMH, IOH) through a sequential pipeline:

```
Inputs → pd_spec.py → PD Automation → RUM YAMLs → RUM Analyse → RUM UPF Integration → UPF files → DRC → Diff
```

The pipeline has three stages that map to grdlbuild targets:
1. **`upf_rum_yamlgen_<die>`** — Runs gen_rum_inputs.py (PD automation + YAML generation)
2. **`upf_rum_analyse_<die>`** — Runs RUM analyse (RTL elaboration + connectivity maps)
3. **`upf_rum_<die>`** — Runs RUM upfint (actual UPF file generation)

At the start of execution, initialize the todo list:

| id | title | status |
|----|-------|--------|
| 1 | Phase 1 — Collect Environment & Die Info | in-progress |
| 2 | Phase 2 — Gather Input Files | not-started |
| 3 | Phase 3 — Generate/Validate pd_spec.py | not-started |
| 4 | Phase 4 — PD Automation & RUM YAMLs | not-started |
| 5 | Phase 5 — RUM Analyse | not-started |
| 6 | Phase 6 — RUM UPF Integration | not-started |
| 7 | Phase 7 — DRC & Error Analysis | not-started |
| 8 | Phase 8 — Diff Against Baseline | not-started |
| 9 | Phase 9 — Summary & Next Steps | not-started |

After completing each phase, mark it `completed` and the next `in-progress`.

---

## SHARED PROCEDURES

### Key Paths & Variables

These are the standard paths used by the UPF flow. All are relative to `$WORKAREA`:

| Variable | Path Template | Description |
|----------|--------------|-------------|
| `PDSPEC_ROOT` | `die/<BASE>/domains` | PD spec root (contains `pd_upf/pd_spec.py`, `pd_upf/gen_rum_inputs.py`, `pd_upf/pd_utils.py`) |
| `SOCB_GEN` | `output/<DUT>/socb/generators` | SOCB generator outputs (RUM YAMLs go here) |
| `TARGET_ROOT` | `output/<DUT>/rum` | RUM output directory (UPF files land here) |
| `CODEGEN_ROOT` | `src/codegen/<DUT>/rum` | Codegen output (RUM RTL stubs) |
| `PICKLE_PATH` | `output/<VARIANTS>/socb/dm/*.pickle` | SOC assembly pickle file(s) |
| `CTH_FILELIST` | `output/<DUT>/genfilelist/ip/<DUT>/<DUT>.sv.rtl.f` | RTL filelist for RUM |
| `STUB_FILELIST` | `output/<DUT>/socb/generators/socb_rtl/filelist/floorplan_stub_ip.f` | Stub filelist |
| `RUM` | `/p/cth/cad/rum/26.18.01` | RUM tool installation |
| `PSTGEN_ROOT` | `src/codegen/<DUT>/upf_utils/PstGen` | PstGen crossing table |
| `SKILL_DIR` | `.github/skills/upf-generation/references` | Helper scripts for this agent |

### Die-Specific Parameters

| Die | DUT | BASE | top | VARIANTS | Orientation | FIVR Naming |
|-----|-----|------|-----|----------|-------------|-------------|
| **MH** | `mh` | `imh` | `corimh` | `mh` | N/S | VCCFIXDIG_N/S, VCCCFC_N/S |
| **IMH** | `imh` | `imh` | `corimh` | `imh` | E/W | VCCFIXDIG_E/W, VCCCFC_E/W |
| **IOH** | `ioh` | `ioh` | `corioh` | `ioh` | Single | VCCCFC (single) |

### SOCB Version

The SOCB version is resolved via CTH:
```bash
cth_query -tool cheetah-rtl envs SOCB_VERSION -resolve
```

Alternatively, set directly: e.g., `SOCB_VERSION=/nfs/site/disks/crt_tools_0117/socbuilder_client/0.48.11`

### Error Log Parsing

After any RUM stage, check the log for errors:
```bash
grep -c 'ERROR' <logfile>
grep -i 'ERROR_[0-9]\+' <logfile> | sort | uniq -c | sort -rn | head -20
```

Categorize errors by type (ERROR_1103 = supply mismatch, ERROR_1101 = missing supply port, etc.).

---

## Phase 1 — Collect Environment & Die Info

### Goal
Determine the workspace, die type, and verify the CTH environment is ready.

### Steps

1. **Check if WORKAREA is set:**
   ```bash
   echo $WORKAREA
   ```
   If not set, ask the user for the workspace path.

2. **Ask which die to generate UPF for:**
   Use `ask_questions` with header "Die Type":
   - Options: `MH (Memory Hub)`, `IMH (Integrated Memory Hub)`, `IOH (IO Hub)`
   - Store as `DIE_TYPE`

3. **Verify CTH environment is active:**
   ```bash
   echo $CTH_SESSION_ID
   ```
   If not set, instruct the user to source CTH:
   ```bash
   source $WORKAREA/cfg/common_tool.cth
   ```

4. **Resolve SOCB version:**
   ```bash
   cth_query -tool cheetah-rtl envs SOCB_VERSION -resolve
   ```
   Store as `SOCB_VERSION`.

5. **Verify prerequisite outputs exist:**
   - SOC pickle: `$WORKAREA/output/<DUT>/socb/dm/*.pickle`
   - RTL filelist: `$WORKAREA/output/<DUT>/genfilelist/ip/<DUT>/<DUT>.sv.rtl.f` (only needed for analyse/upfint)
   - Stub filelist: `$WORKAREA/output/<DUT>/socb/generators/socb_rtl/filelist/floorplan_stub_ip.f`

   If pickle is missing, inform user they need to run construction first:
   ```bash
   grdlbuild construct_<die> hardening_<die>
   ```

6. **Set all derived path variables** based on die type using the Die-Specific Parameters table above.

---

## Phase 2 — Collect All Inputs from User

### Goal
Gather every piece of information needed to generate pd_spec.py, gen_rum_inputs.py, and run the RUM pipeline.
The agent uses a single decision point: **HAS PDF or Excel template?**

### Helper Scripts (in skill references folder)

All helper scripts live under `$WORKAREA/.github/skills/upf-generation/references/`:

| Script | Filename | Purpose |
|--------|----------|----------|
| `create_pd_spec_template.py` | `references/create_pd_spec_template.py` | Creates structured Excel template with ALL input questions |
| `gen_pd_spec_from_xls.py` | `references/gen_pd_spec_from_xls.py` | Reads filled Excel, validates, generates pd_spec.py |
| `how_to_fill_template.txt` | `references/how_to_fill_template.txt` | Step-by-step guide for filling the template |

### Steps

#### Step 1: Ask HAS or Excel

Use `ask_questions` with header "Data Source":
- Question: "Do you have a HAS PDF document I can extract power supply information from?"
- Options:
  - `Yes — I have a HAS PDF` (recommended if available)
  - `No — I will fill an Excel template with all the info you need`

#### Step 2A: If User Says YES (HAS PDF)

1. Ask for the HAS PDF path (free text input).
2. Extract supply tables using `pdftotext`.
3. Present extracted rails to user for confirmation.
4. Auto-generate pd_spec.py directly (proceed to Phase 3, Path HAS).

#### Step 2B: If User Says NO (Excel Template)

1. **Generate the Excel input template** with ALL required columns:
   ```bash
   python3 $WORKAREA/.github/skills/upf-generation/references/create_pd_spec_template.py \
     --output $WORKAREA/pd_spec_ALL_INPUTS.xlsx
   ```

2. **Tell the user:**
   > I've created an Excel template at `$WORKAREA/pd_spec_ALL_INPUTS.xlsx`.
   > 
   > It has **6 sheets** — each sheet asks you specific questions I need to generate all UPF input files.
   > Please fill it and let me know when it's ready.
   >
   > See `how_to_fill_template.txt` for step-by-step instructions.

3. **Wait for user to confirm the Excel is filled**, then proceed to Phase 3, Path XLS.

### Excel Template Sheets & Columns

The Excel template contains **6 sheets**. Each column header is a question the agent needs answered:

---

#### Sheet 1: `00_INSTRUCTIONS`
Read-only. Color coding guide, rules, and validation info.

---

#### Sheet 2: `01_GLOBAL_CONFIG`
One-time settings for the entire design.

| Row Label (Column A) | What to Fill (Column B) | Description | Example |
|---|---|---|---|
| **DESIGN_NAME** | Your design name | Top-level module name | `corimh` |
| **GROUND_NET** | Ground net name | Almost always `vss` | `vss` |
| **PST_POWER_STATE** | Enable power state table? | `yes` for multi-voltage designs | `yes` |
| **SPEC_VERSION** | Version tag | For tracking changes | `0.1` |
| **TOP_MODULE** | Top module name for RUM | Used in `rum_analyse -top` | `corimh` |
| **DIE_TYPE** | Which die variant | `mh`, `imh`, or `ioh` | `mh` |
| **PICKLE_PATH** | Path to SOC assembly pickle | Relative to WORKAREA or absolute | `output/mh/socb/dm/cormh.pickle` |

---

#### Sheet 3: `02_SUPPLY_RAILS`
**One row per power supply rail.** This is the core input — every power domain in the design.

| Column Header | Required? | What It Asks | Example |
|---|---|---|---|
| **RAIL_NAME** | YES | What is the supply rail name? (UPPERCASE, underscores only) | `VCCINF` |
| **SUPPLY_TYPE** | YES | Is this digital or analog? | `digital` |
| **SOURCE** | YES | Where does this supply come from? | `MBVR` or `FIVR` |
| **IS_PRIMARY_SOURCE** | YES | Does this come directly from the board? | `yes` or `no` |
| **PARENT_SUPPLY** | If above=no | Which rail is the parent? (must exist in this sheet) | `VCCIN_EHV` |
| **DESCRIPTION** | Optional | What does this supply power? | `SOC Infrastructure` |
| **DIE** | Optional | Which die does it belong to? | `IMH` or `All` |
| **VNOM** | Optional | Nominal voltage (volts) | `0.65` |
| **VOLTAGE_RANGE** | Optional | Operating voltage range | `0.585 to 0.935` |
| **QUALITY** | Optional | Noise/ripple spec | `+/-10% of Vnom` |
| **CONSUMER_IPS** | Optional | Which IPs use this? (comma-separated, documentation only) | `uio, pcie, cxl` |
| **PM_MODES** | Optional | Power management modes | `VID, ITD` or `Fixed` |
| **BUMPS** | Optional | Number of package bumps for this supply | `20` |
| **FIVR_BOOT_ORDER** | FIVR only | FIVR power-up sequence number (unique integer) | `1` |
| **RA_CONFIG** | FIVR only | Resource Adapter config | `Root` or `Solo` |

---

#### Sheet 4: `03_CONSUMERS`
**One row per block-to-rail assignment.** Links RTL blocks to power supplies.

| Column Header | Required? | What It Asks | Example |
|---|---|---|---|
| **RAIL_NAME** | YES | Which supply rail? (must match a name in 02_SUPPLY_RAILS) | `VCCINF` |
| **LOCATION** | YES | RTL path to the consuming block (see syntax below) | `//subfcmemleft` |
| **IS_PRIMARY** | YES | Is this the primary power domain for this block? Exactly ONE per rail must be `yes` | `yes` or `no` |
| **POWER_PORTS** | Only if different | IP power port names if different from rail name (comma-separated) | `vccdig, vccst` |
| **GROUND_PORTS** | Only if not vss | IP ground port names if not `vss` | `vssx` |
| **NOTES** | Optional | Why this mapping exists | `PHY uses non-standard ports` |

**Location path syntax reference** (also in sheet 04_REFERENCE):
```
/mio/miopcu           → Exact path from root
/<mio(pcu|rpu)>       → Regex on direct child of root
//<parmio_(pcu|rpu)>  → Regex at any depth
//&avephy_8lane       → Match by MODULE name at any depth
&rstw_top             → Instance name at any depth
//*[='VCCINF' in t_pd_domains]  → Attribute query
```

---

#### Sheet 5: `04_EXPLICIT_UPF`
**One row per IP UPF file** that RUM should source during integration. These are pre-existing UPF files from sub-IPs.

| Column Header | Required? | What It Asks | Example |
|---|---|---|---|
| **UPF_FILENAME** | YES | Name of the UPF file | `d2d_fsa.upf` |
| **UPF_DIRECTORY** | YES | Directory containing the UPF file (relative to WORKAREA or absolute) | `subip/sip/d2d_stack/src/codegen/d2d/upf_utils/LocalizeUPF` |
| **IP_NAME** | Optional | Which IP this UPF belongs to | `d2d_stack` |
| **NOTES** | Optional | Any special handling needed | `Single-supply UPF, only has vcc+vss` |

---

#### Sheet 6: `05_PRIMARY_PD_OVERRIDES`
**One row per block** whose auto-detected PRIMARY_PD from the floorplan is **wrong** and needs manual override.

| Column Header | Required? | What It Asks | Example |
|---|---|---|---|
| **BLOCK_NAME** | YES | Instance name or search pattern for the block | `subfcmemleft` |
| **SEARCH_TYPE** | YES | How to find this block in the assembly | `name` (instance name) or `module` (module name) |
| **CORRECT_PRIMARY_PD** | YES | What PRIMARY_PD should this block have? | `VCCINF` |
| **REASON** | Optional | Why the override is needed | `Floorplan says VCCFIXDIG_W but HAS says VCCINF` |

---

#### Sheet 7: `06_REFERENCE`
Read-only. Location path syntax guide, PM modes reference, validation rules.

---

### What Each Sheet Generates

| Excel Sheet | Generates This File | How |
|---|---|---|
| 01_GLOBAL_CONFIG | pd_spec.py header + gen_rum_inputs.py args | Design name, ground, top module |
| 02_SUPPLY_RAILS | pd_spec.py `supply_set()` blocks | One `with supply_set(...)` per row |
| 03_CONSUMERS | pd_spec.py `consumer()` lines inside each supply_set | One `consumer(...)` per row |
| 04_EXPLICIT_UPF | pd_spec.py `explicit_upf()` blocks | One `with explicit_upf(...)` per row |
| 05_PRIMARY_PD_OVERRIDES | gen_rum_inputs.py `soc.attrs[PRIMARY_PD]` overrides | One override per row |

---

## Phase 3 — Generate pd_spec.py and gen_rum_inputs.py

### Goal
**Write** the pd_spec.py and gen_rum_inputs.py files from the collected inputs (HAS PDF or filled Excel).

### Pre-check: Does pd_spec.py already exist?

Before generating, check if files already exist:
```bash
ls -la $WORKAREA/die/<BASE>/domains/pd_upf/pd_spec.py 2>/dev/null
ls -la $WORKAREA/die/<BASE>/domains/pd_upf/gen_rum_inputs.py 2>/dev/null
```

If pd_spec.py exists, ask the user:
- `Overwrite with new generation` (backup old file as `.bak`)
- `Keep existing — skip to Phase 4`

---

### Path HAS — Generate from HAS PDF

**When**: User said "Yes — I have a HAS PDF" in Phase 2.

#### Step 1: Extract Supply Data

1. Get HAS PDF path from user.
2. Extract text:
   ```bash
   pdftotext $HAS_PDF /tmp/has_pd_extract.txt
   ```
3. Parse MBVR and FIVR tables:
   ```bash
   grep -B2 -A30 'MBVR\|FIVR.*Domain\|Table.*Power\|Supply.*Rail' /tmp/has_pd_extract.txt
   ```
4. Present extracted supply list and ask user to confirm/correct.

#### Step 2: Query Assembly Hierarchy

1. Load SOC pickle and list partitions with their current PRIMARY_PD:
   ```bash
   $SOCB_VERSION api -e "
   import pickle
   with open('$PICKLE_PATH', 'rb') as f:
       soc = pickle.load(f)
   for child in soc.dfs:
       if hasattr(child, 'attrs'):
           pd = child.attrs.get('PRIMARY_PD', 'none')
           ht = child.attrs.get('hier_type', '')
           if ht in ('partition', 'stack', 'die'):
               print(f'{child.name}  hier_type={ht}  PRIMARY_PD={pd}')
   "
   ```
2. Use this to map blocks → supply rails for consumer() entries.

#### Step 3: Ask User for Additional Info

Use `ask_questions` to collect what the HAS doesn't tell us:
- Explicit UPF file paths (IP UPFs from sub-assemblies)
- PRIMARY_PD overrides (blocks whose floorplan-derived primary is wrong)
- Any power_ports that differ from rail names

#### Step 4: Write pd_spec.py

Use `create_file` to write the complete pd_spec.py. Follow the DSL Reference below.

#### Step 5: Write gen_rum_inputs.py

Use `create_file` to write gen_rum_inputs.py with PRIMARY_PD overrides from Step 3.

---

### Path XLS — Generate from Filled Excel Template

**When**: User said "No — I will fill an Excel template" in Phase 2.

#### Step 1: Validate the Filled Excel (Loop Until Valid)

Run `gen_pd_spec_from_xls.py` **without `--force`** so it validates first and stops on errors:

```bash
python3 $WORKAREA/.github/skills/upf-generation/references/gen_pd_spec_from_xls.py \
  --input  $WORKAREA/pd_spec_ALL_INPUTS.xlsx \
  --output $WORKAREA/die/<BASE>/domains/pd_upf/pd_spec.py
```

**If validation fails** (script exits with non-zero code or prints `✗ ERROR` lines):

1. **Parse the validation errors** from the script output. Common issues:
   - `RAIL_NAME is empty` — user left a blank row
   - `Duplicate RAIL_NAME` — same rail appears twice
   - `PARENT_SUPPLY not defined` — parent rail doesn't exist in sheet 02
   - `Circular parent dependency` — A→B→C→A chain
   - `No consumer has IS_PRIMARY=yes` — every rail needs exactly one
   - `Multiple consumers have IS_PRIMARY=yes` — only one allowed
   - `RAIL_NAME not found in 02_SUPPLY_RAILS` — typo in consumer sheet
   - `LOCATION has unrecognized syntax` — check path format

2. **Present ALL errors to the user** clearly, e.g.:
   > Your Excel has **3 errors** that must be fixed:
   > 1. Rail `VCCINF`: No consumer has IS_PRIMARY=yes (sheet 03, need exactly one)
   > 2. Rail `VCCFIXDIG_N`: PARENT_SUPPLY=`VCCIN_EHV0` not found — did you mean `VCCIN_EHV_0`?
   > 3. Consumer row 5: LOCATION=`subfcmemleft` — missing `//` prefix, should be `//subfcmemleft`
   >
   > Please fix these in the Excel and let me know when ready.

3. **Wait for user to confirm** they've fixed the file.

4. **Re-run validation** — Go back to the start of Step 1.

5. **Repeat until the script prints `✓ All validation checks passed!`** and generates the file.

This loop is **critical** — never skip validation, never use `--force` without user consent.

#### Step 2: Verify Generated Files

`gen_pd_spec_from_xls.py` automatically generates:
- **pd_spec.py** — from sheets 01 (global), 02 (rails), 03 (consumers), 04 (explicit_upf)
- **gen_rum_inputs.py** — from sheet 05 (PRIMARY_PD overrides), only if sheet 05 has data

Both explicit_upf entries and the auto-consumer loop are included in the generated pd_spec.py.

1. **Check Python syntax of both files:**
   ```bash
   python3 -c "import ast; ast.parse(open('$WORKAREA/die/<BASE>/domains/pd_upf/pd_spec.py').read()); print('pd_spec.py: OK')"
   python3 -c "import ast; ast.parse(open('$WORKAREA/die/<BASE>/domains/pd_upf/gen_rum_inputs.py').read()); print('gen_rum_inputs.py: OK')"
   ```

2. **Show summary to user:**
   ```bash
   echo "=== pd_spec.py ==="
   grep -c 'with supply_set' $WORKAREA/die/<BASE>/domains/pd_upf/pd_spec.py
   grep -c 'consumer(' $WORKAREA/die/<BASE>/domains/pd_upf/pd_spec.py
   grep -c 'with explicit_upf' $WORKAREA/die/<BASE>/domains/pd_upf/pd_spec.py
   echo "=== gen_rum_inputs.py ==="
   grep -c 'PRIMARY_PD' $WORKAREA/die/<BASE>/domains/pd_upf/gen_rum_inputs.py
   ```

3. **Show user a quick summary** and ask for confirmation before proceeding to Phase 4:
   > Generated:
   > - pd_spec.py: 12 supply sets, 28 consumers, 3 explicit UPF entries
   > - gen_rum_inputs.py: 2 PRIMARY_PD overrides
   > 
   > Shall I proceed to run PD automation (Phase 4)?

---

### pd_spec.py DSL Reference

A pd_spec.py file uses the SOCB Power Delivery Spec DSL. The agent must use this exact structure when writing pd_spec.py:

```python
"""
Spec file for a tree-shaped spec of class socb.domains.power_delivery.v_0_5.dm.PowerDeliverySpec

Design : <design_name>
Ground : <ground_net>
"""
from __future__ import annotations
from socb.domains.power_delivery.v_0_5.dm import PowerDeliverySpec
from pathlib import Path
import os

work_area = Path(os.environ.get("WORKAREA"))

def specify(spec: PowerDeliverySpec, **kwds) -> PowerDeliverySpec:
    "A function that enriches `spec` with specifications"
    include       = spec.include
    override      = spec.override
    translate     = spec.translate
    explicit_upf  = spec.explicit_upf
    instance      = spec.instance
    attr          = spec.attr
    power_switch  = spec.power_switch
    partition     = spec.partition
    consumer      = spec.consumer
    input_supply  = spec.input_supply
    control_port  = spec.control_port
    ack_port      = spec.ack_port
    supply_set    = spec.supply_set
    anchor        = spec.anchor
    provider      = spec.provider

    attr(version='0.1')
    attr(pst_power_state=True)

    # ─── Explicit UPF entries ───
    with explicit_upf(work_area / 'path/to/ip.upf'):
        attr(location='path/to/ip.upf')

    # ─── Supply sets (one block per rail) ───
    with supply_set(power='VCCINF', ground='vss'):
        attr(supply_type='digital')
        attr(source='MBVR')
        attr(description='SOC Infrastructure')
        attr(is_primary_source=True)
        with provider(location=''):
            consumer(location='//corimh', is_primary=True)
            consumer(location='//&infrastructure_module')

    # ─── Auto-consumer loop ───
    for ss in spec.supply_sets:
        pd = ss.power
        for prov in ss.providers:
            with prov:
                consumer(f"//*[='{pd}' in t_pd_domains]")

    return spec

specify(result_spec := PowerDeliverySpec.get_current_spec(), **PowerDeliverySpec.get_current_namespace())
```

### Consumer Location Syntax

| Pattern | Meaning | Example |
|---------|---------|---------|
| `/block` | Direct child | `/mio/miopcu` |
| `//block` | Descendant at any depth | `//subfcmemleft` |
| `&module` | Match by module name | `&mmc_sys_top` |
| `/<regex>` | Regex on direct child | `/<mio(pcu\|rpu)>` |
| `//<regex>` | Regex at any depth | `//<parmio_(pcu\|rpu)>` |
| `//<a>/<b>` | Multi-level descendant | `//<mem(top\|bot)left>/<mc_(a\|b\|c\|d)>` |
| `//*[=expr]` | Attribute query | `//*[='VCCINF' in t_pd_domains]` |

---

## Phase 4 — Run PD Automation & Generate RUM YAMLs

### Goal
Run gen_rum_inputs.py to execute PD automation and produce par_pwr_spec.yaml, component_pwr_spec.yaml, template_attribute.yaml.

### Steps

1. **Create output directory:**
   ```bash
   mkdir -p $WORKAREA/output/<DUT>/socb/generators/rum
   ```

2. **Run the YAML generation stage:**
   This is equivalent to the `upf_rum_yamlgen_<die>` grdlbuild target.

   For MH:
   ```bash
   # Remove stale pickle to force regeneration
   rm -f $WORKAREA/output/mh/socb/dm/cormh.pickle

   # Run gen_rum_inputs.py via SOCB API
   $SOCB_VERSION api \
     -l $WORKAREA/output/<DUT>/socb/generators/rum/gen_rum_inputs.log \
     $WORKAREA/die/<BASE>/domains/pd_upf/gen_rum_inputs.py \
     --library_name <top> \
     --pd-spec $WORKAREA/die/<BASE>/domains/pd_upf/pd_spec.py \
     --soc-pickle $WORKAREA/output/<VARIANTS>/socb/dm/*.pickle \
     --out_dir $WORKAREA/output/<DUT>/socb/generators/rum
   ```

3. **Check the log for errors:**
   ```bash
   grep -c 'ERROR' $WORKAREA/output/<DUT>/socb/generators/rum/gen_rum_inputs.log
   ```

4. **Verify output files were generated:**
   - `par_pwr_spec.yaml` — Partition power specifications
   - `component_pwr_spec.yaml` — Component power specifications (explicit_upf, pwr_map_ovrd)
   - `template_attribute.yaml` — Template attributes for RUM

5. **Quick-validate par_pwr_spec.yaml:**
   - Check `main_pwr` for top-level block and subfcs
   - Check `pwr_ports` count at top level
   - Verify `pwr_map_ovrd` entries exist for IPs with renamed supply ports

6. **If errors found:**
   - Parse and categorize errors
   - For `PRIMARY_PD` issues → add overrides in gen_rum_inputs.py
   - For missing consumer matches → fix consumer location patterns in pd_spec.py
   - For supply port mismatches → check explicit_upf paths and catalog
   - Re-run after fixes

---

## Phase 5 — Run RUM Analyse

### Goal
Run RUM analyse to elaborate RTL, build connectivity maps, and generate hierarchy reports.

### Prerequisites
- Phase 4 completed successfully
- RTL filelist exists: `$WORKAREA/output/<DUT>_prerum/genfilelist/ip/<DUT>/<DUT>.sv.rtl.f`
  - If missing, the user needs to run: `grdlbuild gen_filelist_<die>_prerum`

### Steps

1. **Run RUM analyse:**
   This is equivalent to the `upf_rum_analyse_<die>` grdlbuild target.

   ```bash
   $RUM/app/analyse/main.py \
     -top <top> \
     -f $CTH_FILELIST \
     -f $STUB_FILELIST \
     -f $WORKAREA/integration/rum/static_defines_for_rum_opts.f \
     -template_attribute_file $WORKAREA/output/<DUT>/socb/generators/rum/template_attribute.yaml \
     -target $WORKAREA/output/<DUT>/rum \
     -gen_connectivity_maps \
     -gen_hier_report \
     -implicit_blackbox \
     -elab
   ```

2. **Check for errors** in the analyse log.

3. **Verify outputs:**
   - `$WORKAREA/output/<DUT>/rum/con_map/` — Connectivity maps
   - `$WORKAREA/output/<DUT>/rum/collaterals/<top>_hier.yaml` — Hierarchy description

---

## Phase 6 — Run RUM UPF Integration

### Goal
Generate actual UPF files from the RUM YAMLs + connectivity maps + RTL.

### Prerequisites
- Phase 5 completed successfully
- **PST check**: Determine if PST (Power State Table) is enabled:
  ```bash
  grep -c 'pst_power_state=True' $WORKAREA/die/<BASE>/domains/pd_upf/pd_spec.py
  ```
  - **If PST is enabled (count > 0):**
    - PstGen crossing table MUST exist: `$WORKAREA/src/codegen/<DUT>/upf_utils/PstGen/`
    - If missing, user needs to run: `grdlbuild upf_pstgen_<die>`
    - Set: `PST_ENABLED=yes`
  - **If PST is NOT enabled (count = 0):**
    - PstGen is NOT required — skip the check entirely.
    - Set: `PST_ENABLED=no`
    - The `$PSTGEN_ROOT` directory will be **omitted** from the RUM command.

### Steps

1. **Prepare output directories:**
   ```bash
   rm -rf $WORKAREA/output/<DUT>/rum/rtl $WORKAREA/output/<DUT>/rum/upf
   mkdir -p $WORKAREA/output/<DUT>/rum/rtl $WORKAREA/output/<DUT>/rum/upf
   cp -f $WORKAREA/src/upf/cfg/* $WORKAREA/output/<DUT>/rum/upf/
   ```

2. **Build the -yaml_directories argument based on PST status:**

   If `PST_ENABLED=yes`:
   ```
   YAML_DIRS="$WORKAREA/integration/rum $PSTGEN_ROOT $SOCB_GEN/rum \
     $WORKAREA/output/*/partition/*/ub/trial/ub_integration/output/tsdb_outdir/turnin/upf_gen"
   ```

   If `PST_ENABLED=no` (omit `$PSTGEN_ROOT`):
   ```
   YAML_DIRS="$WORKAREA/integration/rum $SOCB_GEN/rum \
     $WORKAREA/output/*/partition/*/ub/trial/ub_integration/output/tsdb_outdir/turnin/upf_gen"
   ```

3. **Run RUM UPF integration:**
   ```bash
   $RUM/app/frontend_upf_integration/main.py \
     -top <top> -die <top> \
     -f $CTH_FILELIST $WORKAREA/integration/rum/static_defines_for_rum_opts.f \
     -yaml_directories $YAML_DIRS \
     -yaml_prefixes par_pwr_spec unit_pwr_spec override_spa component_pwr_spec pwr_cfg \
     -hier_description_yaml $WORKAREA/output/<DUT>/rum/collaterals/<top>_hier.yaml \
     -connectivity_map_directories $WORKAREA/output/<DUT>/rum/con_map \
     -preliminary_tcl $WORKAREA/src/upf/cfg/global_upf.cfg \
     -target $WORKAREA/output/<DUT>/rum \
     -model_root $WORKAREA \
     -unit_hierarchy_depth inf \
     -project cor \
     -compact_log \
     -run_log_parser \
     -hier_keys \
     -automatic_routing_spec \
     -analog_supplies \
     -disable_powergoods \
     -do_not_decompile_guard_macro \
     -no_prefix_on_upf_commands \
     -gen_stub_upf
   ```

4. **Copy results to codegen:**
   ```bash
   rm -rf $WORKAREA/src/codegen/<DUT>/rum
   mkdir -p $WORKAREA/src/codegen/<DUT>/rum/filelists
   cp -rf $WORKAREA/output/<DUT>/rum/rtl $WORKAREA/src/codegen/<DUT>/rum/
   touch $WORKAREA/output/<DUT>/rum/collaterals/merged_add_mod_list.txt
   ```

5. **Verify UPF output:**
   ```bash
   ls $WORKAREA/output/<DUT>/rum/upf/*.upf | wc -l
   ls $WORKAREA/output/<DUT>/rum/upf/*.upf | grep -v stub | wc -l
   ```
   
   Expected: top-level UPF (`<top>.upf`) + partition UPFs + stub UPFs for IPs.

6. **Quick-validate top-level UPF:**
   ```bash
   grep 'create_supply_net' $WORKAREA/output/<DUT>/rum/upf/<top>.upf | head -20
   grep 'create_power_domain' $WORKAREA/output/<DUT>/rum/upf/<top>.upf | head -10
   ```

---

## Phase 7 — DRC Validation & Error Analysis

### Goal
Parse the RUM logs for errors, categorize them, and provide actionable fixes.

### Steps

1. **Parse the RUM upfint log:**
   ```bash
   # Find the log
   ls $WORKAREA/output/<DUT>/rum/logs/

   # Count errors
   grep -c 'ERROR' $WORKAREA/output/<DUT>/rum/logs/*.log

   # Categorize by error code
   grep -oP 'ERROR_\d+' $WORKAREA/output/<DUT>/rum/logs/*.log | sort | uniq -c | sort -rn
   ```

2. **For each error category, provide diagnosis:**

   | Error Code | Meaning | Common Fix |
   |-----------|---------|------------|
   | ERROR_1103 | Supply not found for IP port mapping | Add `pwr_map_ovrd` in pd_spec or fix consumer location |
   | ERROR_1101 | Missing supply port at partition | Add supply port in pd_spec provider/consumer |
   | ERROR_1001 | Module not found in RTL | Check filelist, add missing RTL files |
   | ERROR_1201 | UPF source file not found | Fix explicit_upf path or catalog entry |

3. **Show error summary to user:**
   - Total errors by category
   - Top 10 most frequent error instances
   - Suggested fixes for each category

4. **If user wants to fix errors:**
   - Modify pd_spec.py, gen_rum_inputs.py, or catalog as needed
   - Re-run from the appropriate phase (usually Phase 4)

---

## Phase 8 — Diff Against Baseline

### Goal
Compare the generated UPF outputs against a previous run baseline.

### Steps

1. **Ask for baseline path:**
   Use `ask_questions` with header "Baseline":
   - Free text input for baseline directory path
   - Example: `$WORKAREA/output/<DUT>/rum_baseline/upf/`

2. **If baseline is a previous run of the same workspace:**
   - The user should have saved a copy before re-running

3. **Run diff on key files:**
   ```bash
   # Top-level UPF diff
   diff $WORKAREA/output/<DUT>/rum/upf/<top>.upf <baseline>/<top>.upf | head -100

   # par_pwr_spec.yaml diff
   diff $WORKAREA/output/<DUT>/socb/generators/rum/par_pwr_spec.yaml <baseline>/par_pwr_spec.yaml | head -100

   # component_pwr_spec.yaml diff
   diff $WORKAREA/output/<DUT>/socb/generators/rum/component_pwr_spec.yaml <baseline>/component_pwr_spec.yaml | head -100

   # Count new/removed UPF files
   comm -23 <(ls $WORKAREA/output/<DUT>/rum/upf/*.upf | xargs -n1 basename | sort) \
             <(ls <baseline>/*.upf | xargs -n1 basename | sort)
   ```

4. **Produce a diff summary:**
   - Number of changed UPF files
   - Key changes in top-level UPF (new supply nets, domains, etc.)
   - Changes in par_pwr_spec (main_pwr, pwr_ports, pwr_map_ovrd)
   - New or removed partition UPFs

5. **If errors increased vs baseline:**
   - Identify which new errors appeared
   - Provide root cause for each new error class

---

## Phase 9 — Summary & Next Steps

### Goal
Provide a complete summary of the UPF generation run and suggest next steps.

### Steps

1. **Generate summary:**
   ```
   UPF Generation Summary
   ======================
   Die: <DIE_TYPE>
   Workspace: <WORKAREA>
   SOCB Version: <SOCB_VERSION>
   RUM Version: 26.18.01

   pd_spec.py:
   - Supply sets: <count>
   - Explicit UPF entries: <count>
   - Consumer entries: <count>

   Generated Outputs:
   - par_pwr_spec.yaml: <path>
   - component_pwr_spec.yaml: <path>
   - template_attribute.yaml: <path>
   - UPF files: <count> total (<non_stub_count> partition + <stub_count> stub)
   - Top-level UPF: <path>

   Validation:
   - PD Automation DRC: <PASS/FAIL> (<error_count> errors)
   - RUM Analyse: <PASS/FAIL>
   - RUM UPF Integration: <PASS/FAIL> (<error_count> errors)
     - ERROR_1103: <count> (supply mapping)
     - ERROR_1101: <count> (missing ports)
     - Other: <count>

   Baseline Comparison:
   - Changed files: <count>
   - New errors vs baseline: <count>
   ```

2. **Suggest next steps:**
   - If errors exist → prioritize fixes by impact
   - If clean → run `grdlbuild upf_localize_<die>` for LocalizeUPF
   - Run `grdlbuild upf_filelist_prep_<die>` for filelist preparation
   - Run static CDC/lint checks with the new UPFs
   - Full build: `grdlbuild generate:upf_rum_<die>`

3. **Offer to save a snapshot** of the current outputs as a new baseline:
   ```bash
   cp -r $WORKAREA/output/<DUT>/rum/upf $WORKAREA/output/<DUT>/rum_baseline_$(date +%Y%m%d)
   cp $WORKAREA/output/<DUT>/socb/generators/rum/*.yaml $WORKAREA/output/<DUT>/rum_baseline_$(date +%Y%m%d)/
   ```

---

## Appendix A — Excel Template Workflow

The recommended structured approach uses the two helper scripts in the workspace:

### Step 1: Create the Excel template
```bash
python3 $WORKAREA/.github/skills/upf-generation/references/create_pd_spec_template.py \
  --output $WORKAREA/pd_spec_ALL_INPUTS.xlsx
```

This creates a **7-sheet** Excel workbook:
- **00_INSTRUCTIONS** — Color coding, rules, how to fill
- **01_GLOBAL_CONFIG** — DESIGN_NAME, GROUND_NET, PST_POWER_STATE, SPEC_VERSION, TOP_MODULE, DIE_TYPE, PICKLE_PATH
- **02_SUPPLY_RAILS** — One row per rail with 15 columns (RAIL_NAME, SUPPLY_TYPE, SOURCE, IS_PRIMARY_SOURCE, PARENT_SUPPLY, DESCRIPTION, DIE, VNOM, VOLTAGE_RANGE, QUALITY, CONSUMER_IPS, PM_MODES, BUMPS, FIVR_BOOT_ORDER, RA_CONFIG)
- **03_CONSUMERS** — One row per consumer with 6 columns (RAIL_NAME, LOCATION, IS_PRIMARY, POWER_PORTS, GROUND_PORTS, NOTES)
- **04_EXPLICIT_UPF** — One row per IP UPF file (UPF_FILENAME, UPF_DIRECTORY, IP_NAME, NOTES). Leave empty if no sub-IP UPFs exist.
- **05_PRIMARY_PD_OVERRIDES** — One row per block whose auto-detected PRIMARY_PD is wrong (BLOCK_NAME, SEARCH_TYPE, CORRECT_PRIMARY_PD, REASON). Leave empty if all blocks are correct.
- **06_REFERENCE** — Read-only reference for location path syntax, PM modes, validation rules

### Step 2: Fill the template
See `$WORKAREA/.github/skills/upf-generation/references/how_to_fill_template.txt` for step-by-step instructions.

**Key rules:**
- Delete all yellow example rows before running
- Each RAIL_NAME must be unique, UPPERCASE with underscores
- Each rail MUST have exactly ONE consumer with IS_PRIMARY=yes
- If IS_PRIMARY_SOURCE=no, PARENT_SUPPLY must reference another rail in the sheet
- FIVR_BOOT_ORDER must be unique integers across all FIVR rails
- Sheets 04 and 05 can be left entirely empty if not needed

### Step 3: Generate pd_spec.py
```bash
python3 $WORKAREA/.github/skills/upf-generation/references/gen_pd_spec_from_xls.py \
  --input  $WORKAREA/pd_spec_ALL_INPUTS.xlsx \
  --output $WORKAREA/die/<BASE>/domains/pd_upf/pd_spec.py
```

The script validates everything first (duplicates, parent existence, circular deps, primary consumer counts) and reports errors before generating. Use `--force` to generate despite validation errors.

### Step 4: Post-process
After generation, the agent will:
1. Add the auto-consumer attribute query loop (see Phase 3 DSL Reference)
2. Generate gen_rum_inputs.py from sheet 05_PRIMARY_PD_OVERRIDES
3. Any `Path` variables for external UPF directories

## Appendix B — gen_rum_inputs.py Template

```python
import argparse
import os
import sys
from pathlib import Path

from socb.assembly.dm import SOC, Block
from socb.domains.power_delivery.v_0_5 import PowerDeliveryAutomation
from socb.domains.power_delivery.v_0_5.dm import PowerDeliverySpec, Provider
from socb.domains.power_delivery.v_0_1.rum_yaml_generator import RUMUPFYamlGenerator
from socb.assembly.dm.reporting import print_nets
from socb.utils import logging

sys.path.append(os.path.abspath(os.path.dirname(__file__)))
from pd_utils import pickle_to_soc, run_pd_automation, gen_rum_yamls, enrich_pd_spec_w_assembly_pds, load_pd_specs

def main():
    parser = argparse.ArgumentParser(description='Power Delivery Automation Flow')
    parser.add_argument('--soc-pickle', dest="soc_pickle", required=True, nargs="+")
    parser.add_argument('--pd-spec', dest="pd_spec", required=True, nargs='+')
    parser.add_argument('--out_dir', dest="out_dir", required=False)
    parser.add_argument('--library_name', dest="library_name", required=False)
    args = parser.parse_args()

    for spec_file in args.pd_spec:
        if not os.path.isfile(spec_file):
            raise FileNotFoundError(f"PD Spec file not found: {spec_file}")

    output_dir = Path(args.out_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    soc = pickle_to_soc(*args.soc_pickle, library_name=args.library_name)
    original_spec = load_pd_specs(*args.pd_spec, soc=soc)
    enriched_spec = enrich_pd_spec_w_assembly_pds(original_spec, soc)
    pd_automation = run_pd_automation(spec=enriched_spec, soc=soc, out_dir=output_dir)

    # === PRIMARY_PD Overrides ===
    # Add per-block PRIMARY_PD overrides here if the PD automation
    # cannot auto-determine the correct primary for certain blocks.
    from socb.domains.power_delivery.v_0_1.dm import PRIMARY_PD
    # Example: soc.attrs[PRIMARY_PD] = 'VCCINF'  # top-level override

    # Validate
    pd_automation.name = "power_delivery_automation"
    pd_automation.validate(out_dir=output_dir / "drc", waiver=None, config=None)

    # Generate RUM YAMLs
    gen_rum_yamls(pd_automation, output_dir)

main()
```

## Appendix C — Common Issues & Fixes

| Issue | Symptom | Fix |
|-------|---------|-----|
| Top-level gets `vcc` as main_pwr | corimh.upf has `create_supply_net vcc` | Set `soc.attrs[PRIMARY_PD] = 'VCCINF'` in gen_rum_inputs.py |
| Subfc gets wrong main_pwr | Floorplan JSON overrides primary | Override `block.attrs[PRIMARY_PD]` in gen_rum_inputs.py |
| FSA vcc ERROR_1103 | fsa.upf declares `vcc` but partition has no `vcc` mapping | Add `pwr_map_ovrd` for affected partitions, or add FSA to VCCINF consumer list |
| Catalog space in UPF path | `location=' src/upf/fsa.upf'` (leading space) | Fix in catalog .py file: remove leading space |
| Missing explicit_upf | "Cannot source" errors for IP UPFs | Add `explicit_upf()` entry in pd_spec.py or fix catalog IP `original_upf_path` |
| Partition missing supply port | ERROR_1101 at partition boundary | Add partition as consumer of the supply set in pd_spec.py |
