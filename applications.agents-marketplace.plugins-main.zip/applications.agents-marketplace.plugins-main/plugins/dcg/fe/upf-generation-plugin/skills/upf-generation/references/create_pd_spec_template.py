#!/usr/bin/env python3
"""
create_pd_spec_template.py
===========================
Creates a fully documented Excel template for filling in pd_spec.py information.

Usage:
    python create_pd_spec_template.py
    python create_pd_spec_template.py --output /path/to/my_template.xlsx

Requirements:
    pip install openpyxl
"""

import argparse
from pathlib import Path

try:
    import openpyxl
    from openpyxl.styles import (
        PatternFill, Font, Alignment, Border, Side
    )
    from openpyxl.utils import get_column_letter
    from openpyxl.worksheet.datavalidation import DataValidation
except ImportError:
    print("ERROR: openpyxl is required. Install it with:  pip install openpyxl")
    raise SystemExit(1)


# ─────────────────────────────────────────────────────────────────────────────
#  Color palette
# ─────────────────────────────────────────────────────────────────────────────
C_TITLE          = "1F3864"   # dark navy  – sheet title row
C_HEADER_FUNC    = "C00000"   # dark red   – FUNCTIONAL column headers
C_HEADER_META    = "375623"   # dark green – METADATA column headers
C_HEADER_NEUTRAL = "404040"   # dark grey  – neutral headers
C_ROW_EXAMPLE    = "FFF2CC"   # light yellow – example row
C_ROW_INPUT      = "FFFFFF"   # white       – user input rows
C_INSTRUCTION    = "E2EFDA"   # light green – instruction cells
C_MANDATORY      = "FFE0E0"   # light red   – mandatory field highlight
C_OPTIONAL       = "EBF3FB"   # light blue  – optional field highlight
C_SECTION        = "D6E4F0"   # medium blue – section separator


def fill(hex_color):
    return PatternFill("solid", fgColor=hex_color)


def font(bold=False, color="000000", size=10):
    return Font(bold=bold, color=color, size=size, name="Calibri")


def border_thin():
    s = Side(style="thin")
    return Border(left=s, right=s, top=s, bottom=s)


def header_cell(ws, row, col, text, bg=C_HEADER_NEUTRAL, fg="FFFFFF",
                bold=True, wrap=True, width=None):
    c = ws.cell(row=row, column=col, value=text)
    c.fill = fill(bg)
    c.font = font(bold=bold, color=fg)
    c.alignment = Alignment(wrap_text=wrap, vertical="top", horizontal="center")
    c.border = border_thin()
    if width:
        ws.column_dimensions[get_column_letter(col)].width = width
    return c


def data_cell(ws, row, col, value="", bg=C_ROW_INPUT, bold=False,
              wrap=True, align="left"):
    c = ws.cell(row=row, column=col, value=value)
    c.fill = fill(bg)
    c.font = font(bold=bold)
    c.alignment = Alignment(wrap_text=wrap, vertical="top", horizontal=align)
    c.border = border_thin()
    return c


def note_cell(ws, row, col, text, bg=C_INSTRUCTION):
    c = ws.cell(row=row, column=col, value=text)
    c.fill = fill(bg)
    c.font = Font(italic=True, size=9, color="2E4053", name="Calibri")
    c.alignment = Alignment(wrap_text=True, vertical="top")
    c.border = border_thin()
    return c


def title_row(ws, text, ncols, row=1):
    ws.merge_cells(start_row=row, start_column=1, end_row=row, end_column=ncols)
    c = ws.cell(row=row, column=1, value=text)
    c.fill   = fill(C_TITLE)
    c.font   = Font(bold=True, color="FFFFFF", size=13, name="Calibri")
    c.alignment = Alignment(horizontal="center", vertical="center")
    c.border = border_thin()
    ws.row_dimensions[row].height = 28


def add_dropdown(ws, col_letter, start_row, end_row, options):
    formula = '"' + ",".join(options) + '"'
    dv = DataValidation(type="list", formula1=formula, allow_blank=True)
    dv.sqref = f"{col_letter}{start_row}:{col_letter}{end_row}"
    ws.add_data_validation(dv)


# ─────────────────────────────────────────────────────────────────────────────
#  Sheet 1 – INSTRUCTIONS
# ─────────────────────────────────────────────────────────────────────────────

def build_instructions_sheet(wb):
    ws = wb.create_sheet("00_INSTRUCTIONS", 0)
    ws.sheet_view.showGridLines = False
    ws.column_dimensions["A"].width = 30
    ws.column_dimensions["B"].width = 90

    title_row(ws, "pd_spec.py INPUT TEMPLATE — INSTRUCTIONS", 2, row=1)
    ws.row_dimensions[1].height = 28

    rows = [
        ("PURPOSE", "This Excel workbook is the input template for the pd_spec.py generator agent.\n"
                    "Fill in all sheets as instructed, then run:\n"
                    "    python gen_pd_spec_from_xls.py --input <this_file.xlsx> --output pd_spec.py"),
        ("", ""),
        ("SHEETS IN THIS WORKBOOK", ""),
        ("01_GLOBAL_CONFIG",     "Fill ONCE. Design name, ground net, PST settings. Mandatory."),
        ("02_SUPPLY_RAILS",      "Fill ONE ROW per power supply rail. Mandatory.\n"
                                 "Columns marked RED header = FUNCTIONAL (affect UPF output).\n"
                                 "Columns marked GREEN header = METADATA (documentation only)."),
        ("03_CONSUMERS",         "Fill ONE ROW per consumer() mapping.\n"
                                 "Link each row to its supply rail via the RAIL_NAME column.\n"
                                 "Each rail MUST have at least one row with IS_PRIMARY = yes."),
        ("04_REFERENCE",         "Read-only reference sheet. Location path syntax guide and validation rules."),
        ("", ""),
        ("COLOR CODING", ""),
        ("🔴 RED column header",  "FUNCTIONAL attribute — directly affects generated UPF. Do NOT leave blank."),
        ("🟢 GREEN column header","METADATA attribute — documentation only, no UPF impact. Recommended but optional."),
        ("🟡 Yellow row",         "Example row — pre-filled to show format. Delete before running agent."),
        ("🔵 Blue cell",          "Optional field. Leave blank if not applicable."),
        ("", ""),
        ("RULES — READ BEFORE FILLING", ""),
        ("Rule 1",  "RAIL_NAME must be UPPERCASE with underscores only. E.g. VCCFIXDIG_MIO, VCCINF."),
        ("Rule 2",  "Every rail must have at least one consumer row in 03_CONSUMERS."),
        ("Rule 3",  "Every rail must have exactly ONE consumer row with IS_PRIMARY = yes."),
        ("Rule 4",  "If IS_PRIMARY_SOURCE = no, PARENT_SUPPLY must name another rail defined in 02_SUPPLY_RAILS."),
        ("Rule 5",  "FIVR boot orders (FIVR_BOOT_ORDER) must be unique integers across all FIVR rails."),
        ("Rule 6",  "RA_CONFIG is only needed for FIVR-derived rails. Set to Root or Solo."),
        ("Rule 7",  "POWER_PORTS and GROUND_PORTS in 03_CONSUMERS are only needed when IP port names\n"
                    "differ from the supply name. E.g. IP port 'vssx' instead of 'vss'."),
        ("Rule 8",  "Do not rename or delete column headers. The agent reads columns by header name."),
        ("Rule 9",  "You may add as many rows as needed. Do not leave blank rows between data rows."),
        ("Rule 10", "The example rows (yellow) must be deleted before running the agent,\n"
                    "OR they will be included in pd_spec.py generation."),
    ]

    for i, (label, desc) in enumerate(rows, start=2):
        ws.row_dimensions[i].height = 45 if "\n" in desc else 20
        c1 = ws.cell(row=i, column=1, value=label)
        c2 = ws.cell(row=i, column=2, value=desc)
        if label in ("PURPOSE", "SHEETS IN THIS WORKBOOK", "COLOR CODING",
                     "RULES — READ BEFORE FILLING"):
            c1.font = Font(bold=True, size=11, color="1F3864", name="Calibri")
            c2.font = Font(bold=True, size=11, name="Calibri")
            c1.fill = fill(C_SECTION)
            c2.fill = fill(C_SECTION)
        else:
            c1.font = Font(bold=True, size=10, name="Calibri")
            c2.font = Font(size=10, name="Calibri")
        c2.alignment = Alignment(wrap_text=True, vertical="top")


# ─────────────────────────────────────────────────────────────────────────────
#  Sheet 2 – GLOBAL CONFIG
# ─────────────────────────────────────────────────────────────────────────────

def build_global_sheet(wb):
    ws = wb.create_sheet("01_GLOBAL_CONFIG", 1)
    ws.sheet_view.showGridLines = False

    title_row(ws, "01 — GLOBAL CONFIGURATION  (fill once, applies to entire pd_spec.py)", 4, row=1)

    # Column widths
    ws.column_dimensions["A"].width = 28
    ws.column_dimensions["B"].width = 22
    ws.column_dimensions["C"].width = 55
    ws.column_dimensions["D"].width = 30

    # Header row
    for col, (text, bg) in enumerate([
        ("FIELD",            C_HEADER_NEUTRAL),
        ("YOUR VALUE",       C_HEADER_FUNC),
        ("DESCRIPTION",      C_HEADER_META),
        ("EXAMPLE / DEFAULT",C_HEADER_NEUTRAL),
    ], start=1):
        header_cell(ws, 2, col, text, bg=bg, width=None)

    fields = [
        ("DESIGN_NAME",    True,  "Name of the top-level design / assembly.\nUsed for documentation in generated pd_spec.py.",
                                  "mio   /   mc   /   acc"),
        ("GROUND_NET",     True,  "Name of the ground net in the RTL.\nAll supply_sets use this as their ground reference.\nAlmost always 'vss' — only change if your design uses a different name.",
                                  "vss  (default)"),
        ("PST_POWER_STATE", True, "Set to yes to enable Power State Table (PST) generation.\n"
                                  "PST drives add_power_state and create_pst commands in the generated UPF.\n"
                                  "Required for multi-voltage designs. Set to no only for single-voltage flat designs.",
                                  "yes  (recommended)"),
        ("SPEC_VERSION",   False, "Version tag for this spec file. Stored as metadata only.\nDoes not affect UPF output. Useful for change tracking.",
                                  "0.1"),
        ("TOP_MODULE",     True,  "Top module name used by RUM for UPF generation.\nThis is passed to rum_analyse -top and rum_upfint -top.",
                                  "corimh"),
        ("DIE_TYPE",       True,  "Which die variant: mh, imh, or ioh.\nDetermines output directory paths and FIVR orientation naming.",
                                  "mh  /  imh  /  ioh"),
        ("PICKLE_PATH",    True,  "Path to the SOC assembly pickle file.\nRelative to WORKAREA or absolute.\nUsed by gen_rum_inputs.py to load the SOC hierarchy.",
                                  "output/mh/socb/dm/cormh.pickle"),
    ]

    for i, (name, mandatory, desc, example) in enumerate(fields, start=3):
        bg_val = C_MANDATORY if mandatory else C_OPTIONAL
        ws.row_dimensions[i].height = 55
        data_cell(ws, i, 1, name,   bold=True)
        data_cell(ws, i, 2, "",     bg=bg_val)
        note_cell(ws, i, 3, desc)
        data_cell(ws, i, 4, example, bg=C_ROW_EXAMPLE)

    # Dropdown for PST_POWER_STATE
    add_dropdown(ws, "B", 5, 5, ["yes", "no"])
    # Dropdown for DIE_TYPE
    add_dropdown(ws, "B", 8, 8, ["mh", "imh", "ioh"])

    # Legend
    ws.cell(row=11, column=1, value="🔴 = FUNCTIONAL (required)").font = Font(color="C00000", bold=True, size=10)
    ws.cell(row=12, column=1, value="🔵 = OPTIONAL metadata").font = Font(color="1F4E79", bold=True, size=10)


# ─────────────────────────────────────────────────────────────────────────────
#  Sheet 3 – SUPPLY RAILS
# ─────────────────────────────────────────────────────────────────────────────

RAIL_COLUMNS = [
    # (header_text, bg_color, width, description, example, mandatory)
    ("RAIL_NAME",        C_HEADER_FUNC,    22, "Unique name of the supply rail.\nMust be UPPERCASE with underscores.\nThis becomes the supply_set(power=...) name.",
                                               "VCCFIXDIG_MIO", True),
    ("SUPPLY_TYPE",      C_HEADER_META,    14, "Type of supply.\ndigital = logic/digital circuits\nanalog = PHY, PLL, analog IP",
                                               "digital  OR  analog", True),
    ("SOURCE",           C_HEADER_META,    12, "Where this supply comes from.\nMBVR = motherboard VR (board-level)\nFIVR = on-die FIVR\nOther = free text",
                                               "FIVR  OR  MBVR", True),
    ("IS_PRIMARY_SOURCE",C_HEADER_FUNC,    18, "FUNCTIONAL — affects UPF hierarchy.\nyes = this rail comes directly from the board (MBVR), no parent needed.\nno  = this rail is generated by FIVR from a parent supply.\nIf no, you MUST fill PARENT_SUPPLY.",
                                               "yes  OR  no", True),
    ("PARENT_SUPPLY",    C_HEADER_FUNC,    20, "FUNCTIONAL — required only when IS_PRIMARY_SOURCE = no.\nName of the upstream supply this rail is derived from.\nMust exactly match another RAIL_NAME in this sheet.\nE.g. VCCIN_EHV is parent of all FIVR rails.",
                                               "VCCIN_EHV", False),
    ("DESCRIPTION",      C_HEADER_META,    40, "Human-readable description of what this supply powers.\nMetadata only — not used by RUM for UPF generation.",
                                               "Supply for Digital agent logic of UIO & accelerator UIO_0", False),
    ("DIE",              C_HEADER_META,    12, "Which die this supply belongs to.\nIMH = Intel Modular Hub die\nAll = applies to all dies\nOr any custom die name.",
                                               "IMH  OR  All", False),
    ("VNOM",             C_HEADER_META,    10, "Nominal operating voltage as a string.\nExample: 0.65  or  1.25  or  0.9\nStored as metadata — does NOT set UPF voltage values.\n(Actual UPF voltages come from global_upf.cfg constants.)",
                                               "0.65", False),
    ("VOLTAGE_RANGE",    C_HEADER_META,    24, "Operating voltage range as free text.\nExample: 0.585 to 0.935\nOr: 1.71 to 1.89\nMetadata only — not parsed by RUM.",
                                               "0.63 to 0.8", False),
    ("QUALITY",          C_HEADER_META,    30, "Supply noise/ripple specification.\nFree text — metadata only.\nExample: +/-10% of Vnom",
                                               "+/-10% of Vnom", False),
    ("CONSUMER_IPS",     C_HEADER_META,    30, "Comma-separated list of IP names that consume this supply.\nDocumentation only — actual consumers are defined in 03_CONSUMERS sheet.\nExample: uio.hiop, pcie5x16, cxl, uxi",
                                               "uio.hiop, pcie5x16, cxl", False),
    ("PM_MODES",         C_HEADER_META,    24, "Power management modes — comma-separated.\nCommon values: Fixed, SVID, VID, GV, ITD, PS\nFixed = always on at fixed voltage\nSVID/VID = voltage ID controlled\nITD = Intel Thermal Design\nMetadata only.",
                                               "VID, ITD  OR  Fixed", False),
    ("BUMPS",            C_HEADER_META,    10, "Number of package bumps allocated to this supply.\nMetadata only — numeric value.\nLeave blank if unknown.",
                                               "20", False),
    ("FIVR_BOOT_ORDER",  C_HEADER_FUNC,    18, "FUNCTIONAL — required for FIVR-derived rails only.\nInteger indicating FIVR power-up sequence order.\nMust be UNIQUE across all FIVR rails in this design.\n1 = powers up first, 2 = second, etc.",
                                               "1  (unique integer)", False),
    ("RA_CONFIG",        C_HEADER_FUNC,    14, "FUNCTIONAL — required for FIVR-derived rails only.\nResource Adapter configuration:\nRoot = shared multi-consumer RA\nSolo = dedicated single-consumer RA",
                                               "Root  OR  Solo", False),
]


def build_rails_sheet(wb):
    ws = wb.create_sheet("02_SUPPLY_RAILS", 2)
    ws.sheet_view.showGridLines = False
    ws.freeze_panes = "A4"

    title_row(ws, "02 — SUPPLY RAILS  (one row per supply rail)  |  🔴 RED = FUNCTIONAL must fill  |  🟢 GREEN = metadata optional", 
              len(RAIL_COLUMNS), row=1)

    # Sub-header: description row
    ws.row_dimensions[2].height = 80
    for col, (hdr, bg, width, desc, example, mandatory) in enumerate(RAIL_COLUMNS, start=1):
        c = ws.cell(row=2, column=col, value=desc)
        c.fill = fill("F0F0F0")
        c.font = Font(italic=True, size=8, color="404040", name="Calibri")
        c.alignment = Alignment(wrap_text=True, vertical="top")
        c.border = border_thin()
        ws.column_dimensions[get_column_letter(col)].width = width

    # Header row
    ws.row_dimensions[3].height = 22
    for col, (hdr, bg, width, desc, example, mandatory) in enumerate(RAIL_COLUMNS, start=1):
        header_cell(ws, 3, col, hdr, bg=bg, width=None)

    # Example row (yellow)
    ws.row_dimensions[4].height = 18
    examples = [
        "VCCFIXDIG_MIO", "digital", "FIVR", "no", "VCCIN_EHV",
        "Supply for Digital agent logic of UIO & accelerator UIO_0",
        "IMH", "0.7", "0.63 to 0.8", "+/-10% of Vnom",
        "uio.hiop, pcie5x16, cxl", "VID, ITD", "20", "3", "Solo"
    ]
    for col, val in enumerate(examples, start=1):
        data_cell(ws, 4, col, val, bg=C_ROW_EXAMPLE)

    # 14 blank input rows
    for r in range(5, 25):
        ws.row_dimensions[r].height = 18
        for col in range(1, len(RAIL_COLUMNS) + 1):
            data_cell(ws, r, col, "", bg=C_ROW_INPUT)

    # Dropdowns
    add_dropdown(ws, "B", 4, 24, ["digital", "analog"])
    add_dropdown(ws, "C", 4, 24, ["MBVR", "FIVR", "Other"])
    add_dropdown(ws, "D", 4, 24, ["yes", "no"])
    add_dropdown(ws, "G", 4, 24, ["IMH", "All", "Other"])
    add_dropdown(ws, "O", 4, 24, ["Root", "Solo"])

    # Legend row
    ws.cell(row=26, column=1,
            value="⚠ Delete or overwrite the yellow example row before running the agent.").font = Font(
        color="C00000", bold=True, size=10)
    ws.cell(row=27, column=1,
            value="ℹ RAIL_NAME in this sheet must exactly match RAIL_NAME in 03_CONSUMERS.").font = Font(
        color="1F3864", bold=True, size=10)


# ─────────────────────────────────────────────────────────────────────────────
#  Sheet 4 – CONSUMERS
# ─────────────────────────────────────────────────────────────────────────────

CONSUMER_COLUMNS = [
    # (header_text, bg_color, width, description, example, mandatory)
    ("RAIL_NAME",     C_HEADER_FUNC, 22,
     "Name of the supply rail this consumer belongs to.\nMust exactly match a RAIL_NAME in sheet 02_SUPPLY_RAILS.",
     "VCCFIXDIG_MIO", True),

    ("LOCATION",      C_HEADER_FUNC, 40,
     "RTL hierarchy path to the consuming block.\nThis is THE most important field — it determines which RTL instance is assigned to this power domain.\n\nPath syntax:\n"
     "  /mio/miopcu           → absolute path from top\n"
     "  /<mio(pcu|rpu)>       → regex match on instance name\n"
     "  //<parmio_(pcu|rpu)>  → search at any depth with regex\n"
     "  //&avephy_8lane       → any depth, match by MODULE name\n"
     "  &rstw_top             → match instance name anywhere\n"
     "  //*[='VCCINF' in t_pd_domains]  → query expression",
     "/mio", True),

    ("IS_PRIMARY",    C_HEADER_FUNC, 14,
     "FUNCTIONAL — CRITICAL.\nyes = this is the PRIMARY power domain supply for this block/partition.\nno  = this is a secondary supply connection.\n\n"
     "RULE: Each supply rail MUST have EXACTLY ONE consumer with IS_PRIMARY = yes.\n"
     "The primary consumer is typically the partition or top instance of the IP block.",
     "yes  OR  no", True),

    ("POWER_PORTS",   C_HEADER_FUNC, 30,
     "FUNCTIONAL — fill ONLY when the IP power port name is different from the supply rail name.\n"
     "Comma-separated list of port names on the IP that carry this supply.\n\n"
     "Example: IP has port 'vccdig' but supply is VCCCFCMEM → enter: vccdig\n"
     "Example: IP has two ports: 'vccin, vccst' → enter: vccin, vccst\n\n"
     "Leave blank if the IP port name matches the supply name automatically.",
     "vccdig, vccst   OR leave blank", False),

    ("GROUND_PORTS",  C_HEADER_FUNC, 24,
     "FUNCTIONAL — fill ONLY when the IP ground port name is NOT 'vss'.\n"
     "Comma-separated list of ground port names on the IP.\n\n"
     "Example: DDR PHY uses 'vssx' instead of 'vss' → enter: vssx\n\n"
     "Leave blank if the IP uses 'vss' as ground (the default).",
     "vssx   OR leave blank", False),

    ("NOTES",         C_HEADER_META, 40,
     "Optional human notes about this consumer mapping.\nNot included in generated pd_spec.py.\nUse for tracking why this mapping exists.",
     "Optional comment or reason", False),
]


def build_consumers_sheet(wb):
    ws = wb.create_sheet("03_CONSUMERS", 3)
    ws.sheet_view.showGridLines = False
    ws.freeze_panes = "A4"

    title_row(ws, "03 — CONSUMER MAPPINGS  (one row per consumer entry)  |  Each rail MUST have at least one row with IS_PRIMARY = yes",
              len(CONSUMER_COLUMNS), row=1)

    # Description row
    ws.row_dimensions[2].height = 100
    for col, (hdr, bg, width, desc, example, mandatory) in enumerate(CONSUMER_COLUMNS, start=1):
        c = ws.cell(row=2, column=col, value=desc)
        c.fill = fill("F0F0F0")
        c.font = Font(italic=True, size=8, color="404040", name="Calibri")
        c.alignment = Alignment(wrap_text=True, vertical="top")
        c.border = border_thin()
        ws.column_dimensions[get_column_letter(col)].width = width

    # Header row
    ws.row_dimensions[3].height = 22
    for col, (hdr, bg, width, desc, example, mandatory) in enumerate(CONSUMER_COLUMNS, start=1):
        header_cell(ws, 3, col, hdr, bg=bg, width=None)

    # Example rows (yellow) — multiple to show variety
    example_rows = [
        ["VCCFIXDIG_MIO", "/mio",             "yes", "",          "",      "Primary domain — entire mio top"],
        ["VCCFIXDIG_MIO", "/<mio(pcu|rpu)>",  "no",  "",          "",      "Both stack instances"],
        ["VCCFIXDIG_MIO", "//&avephy_8lane",   "no",  "vdd_p, vdd_p_esdtmr_ehv", "",  "PHY with non-standard port names"],
        ["VCCCFCMEM",     "/mio/miopcu/parmioasf_pcu", "yes", "", "",      "Direct partition path"],
        ["VCCINF",        "&ljpll",            "no",  "vccdig, vccst", "", "LJPLL has 2 power ports for this rail"],
        ["VCCANA_MIOPHY0","&avephy_8lane_0",   "yes", "vdd_p_fw, vdd_pa", "vssx", "Analog PHY with custom gnd port"],
    ]
    for i, row_data in enumerate(example_rows, start=4):
        ws.row_dimensions[i].height = 18
        for col, val in enumerate(row_data, start=1):
            data_cell(ws, i, col, val, bg=C_ROW_EXAMPLE)

    # Blank input rows
    for r in range(4 + len(example_rows), 4 + len(example_rows) + 50):
        ws.row_dimensions[r].height = 18
        for col in range(1, len(CONSUMER_COLUMNS) + 1):
            data_cell(ws, r, col, "", bg=C_ROW_INPUT)

    # Dropdown for IS_PRIMARY
    add_dropdown(ws, "C", 4, 60, ["yes", "no"])

    # Warnings
    r = 4 + len(example_rows) + 52
    ws.cell(row=r, column=1,
            value="⚠ Delete or overwrite all yellow example rows before running the agent.").font = Font(
        color="C00000", bold=True, size=10)
    ws.cell(row=r+1, column=1,
            value="⚠ RAIL_NAME here must exactly match RAIL_NAME in sheet 02_SUPPLY_RAILS.").font = Font(
        color="C00000", bold=True, size=10)
    ws.cell(row=r+2, column=1,
            value="ℹ POWER_PORTS and GROUND_PORTS: leave blank unless the IP uses non-standard port names.").font = Font(
        color="1F3864", bold=True, size=10)


# ─────────────────────────────────────────────────────────────────────────────
#  Sheet 8 – REFERENCE
# ─────────────────────────────────────────────────────────────────────────────

def build_reference_sheet(wb):
    ws = wb.create_sheet("06_REFERENCE", 6)
    ws.sheet_view.showGridLines = False
    ws.column_dimensions["A"].width = 35
    ws.column_dimensions["B"].width = 45
    ws.column_dimensions["C"].width = 50

    title_row(ws, "04 — REFERENCE  (read-only — do not edit)", 3, row=1)

    sections = [
        ("LOCATION PATH SYNTAX", [
            ("Pattern",             "What it means",                     "Example"),
            ("/foo/bar",            "Absolute path from top",            "/mio/miopcu"),
            ("/<foo(a|b)>",         "Regex match on instance name (depth 1)", "/<mio(pcu|rpu)>"),
            ("//<foo(a|b)>",        "Regex match at ANY depth",          "//<parmio_(pcu|rpu)>"),
            ("//&modname",          "Any depth, match by MODULE name",   "//&avephy_8lane"),
            ("&instname",           "Instance name match at any depth",  "&rstw_top"),
            ("//*[=expr]",          "Query expression on block attrs",   "//*[='VCCINF' in t_pd_domains]"),
        ]),
        ("PM_MODES VALUES", [
            ("Value",   "Meaning",                              "When to use"),
            ("Fixed",   "Supply always on at fixed voltage",    "MBVR supplies, always-on rails"),
            ("SVID",    "Serial VID interface controlled",      "Board-level switchable rails"),
            ("VID",     "Voltage ID controlled (FIVR)",         "FIVR digital rails"),
            ("GV",      "Global Voltage scaling",               "Power-gated domains"),
            ("ITD",     "Intel Thermal Design",                 "Most digital FIVR rails"),
            ("PS",      "Power State controlled",               "Rails that turn off in low-power"),
        ]),
        ("IS_PRIMARY_SOURCE RULES", [
            ("Value",  "Meaning",                                 "When"),
            ("yes",    "Rail comes from board (MBVR/VCCIN_EHV).  No PARENT_SUPPLY needed.",  "MBVR rails, VCCIN_EHV itself"),
            ("no",     "Rail generated by FIVR. PARENT_SUPPLY must be filled.",               "All FIVR-derived rails"),
        ]),
        ("RA_CONFIG VALUES", [
            ("Value",  "Meaning",                                          "When"),
            ("Root",   "Shared RA — multiple sub-rails share this adapter", "VCCCFCMEM, VCCCFCIO (GV group)"),
            ("Solo",   "Dedicated RA — single rail, independent control",   "VCCFIXDIG_MIO, VCCINF"),
        ]),
        ("VALIDATION RULES", [
            ("Rule",              "Description",                            "Error if violated"),
            ("Unique RAIL_NAME",  "Each rail name must be unique",          "Duplicate rail: VCCXXX"),
            ("Parent exists",     "Parent supply must be defined in sheet 02", "Parent VCCIN_EHV not found"),
            ("One primary",       "Exactly one IS_PRIMARY=yes per rail",    "Rail VCCXXX has no primary consumer"),
            ("No circular parent","A→B→A chain not allowed",               "Circular dependency detected"),
            ("Unique boot order", "FIVR_BOOT_ORDER must be unique integers","Boot order 2 used by two rails"),
            ("No empty rail",     "Each rail needs at least one consumer",  "Rail VCCXXX has no consumers"),
        ]),
    ]

    row = 2
    for section_title, rows_data in sections:
        # Section title
        ws.merge_cells(start_row=row, start_column=1, end_row=row, end_column=3)
        c = ws.cell(row=row, column=1, value=section_title)
        c.fill = fill(C_SECTION)
        c.font = Font(bold=True, size=11, color="1F3864", name="Calibri")
        c.alignment = Alignment(horizontal="left", vertical="center")
        c.border = border_thin()
        ws.row_dimensions[row].height = 20
        row += 1

        for i, (col1, col2, col3) in enumerate(rows_data):
            bg = C_HEADER_NEUTRAL if i == 0 else ("F9F9F9" if i % 2 else "FFFFFF")
            fg = "FFFFFF" if i == 0 else "000000"
            bold = (i == 0)
            for j, val in enumerate([col1, col2, col3], start=1):
                c = ws.cell(row=row, column=j, value=val)
                c.fill = fill(bg)
                c.font = Font(bold=bold, color=fg, size=9, name="Calibri")
                c.alignment = Alignment(wrap_text=True, vertical="top")
                c.border = border_thin()
            ws.row_dimensions[row].height = 30 if i == 0 else 25
            row += 1
        row += 1  # blank separator


# ─────────────────────────────────────────────────────────────────────────────
#  Sheet 6 – EXPLICIT UPF
# ─────────────────────────────────────────────────────────────────────────────

EXPLICIT_UPF_COLUMNS = [
    # (header_text, bg_color, width, description, example, mandatory)
    ("UPF_FILENAME",  C_HEADER_FUNC, 30,
     "Name of the UPF file to source during RUM UPF integration.\n"
     "This is an existing IP UPF from a sub-assembly or stack.",
     "d2d_fsa.upf", True),

    ("UPF_DIRECTORY", C_HEADER_FUNC, 60,
     "Directory containing the UPF file.\nCan be relative to WORKAREA or absolute.\n"
     "Example (relative): subip/sip/d2d_stack/src/codegen/d2d/upf_utils/LocalizeUPF\n"
     "Example (absolute): /nfs/site/disks/.../LocalizeUPF",
     "subip/sip/d2d_stack/src/codegen/d2d/upf_utils/LocalizeUPF", True),

    ("IP_NAME",       C_HEADER_META, 20,
     "Name of the IP this UPF belongs to. Documentation only.",
     "d2d_stack", False),

    ("NOTES",         C_HEADER_META, 40,
     "Any special handling notes for this UPF file.\n"
     "E.g. 'Single-supply UPF, only has vcc+vss' or 'Contains power switches'",
     "Single-supply UPF", False),
]


def build_explicit_upf_sheet(wb):
    ws = wb.create_sheet("04_EXPLICIT_UPF", 4)
    ws.sheet_view.showGridLines = False
    ws.freeze_panes = "A4"

    title_row(ws,
        "04 — EXPLICIT UPF FILES  (one row per IP UPF file that RUM should source)  |  "
        "Leave empty if no sub-IP UPFs exist",
        len(EXPLICIT_UPF_COLUMNS), row=1)

    # Description row
    ws.row_dimensions[2].height = 80
    for col, (hdr, bg, width, desc, example, mandatory) in enumerate(EXPLICIT_UPF_COLUMNS, start=1):
        c = ws.cell(row=2, column=col, value=desc)
        c.fill = fill("F0F0F0")
        c.font = Font(italic=True, size=8, color="404040", name="Calibri")
        c.alignment = Alignment(wrap_text=True, vertical="top")
        c.border = border_thin()
        ws.column_dimensions[get_column_letter(col)].width = width

    # Header row
    ws.row_dimensions[3].height = 22
    for col, (hdr, bg, width, desc, example, mandatory) in enumerate(EXPLICIT_UPF_COLUMNS, start=1):
        header_cell(ws, 3, col, hdr, bg=bg, width=None)

    # Example rows (yellow)
    example_rows = [
        ["d2d_fsa.upf",
         "subip/sip/d2d_stack/src/codegen/d2d/upf_utils/LocalizeUPF",
         "d2d_stack", "Single-supply UPF, only has vcc + vss"],
        ["mc_top.upf",
         "subip/sip/ddrmc_stack/src/codegen/mc/IntgMstr/upf/LocalizeUPF",
         "ddrmc_stack", "MC stack UPF with VCCFIXDIG + VCCDDR domains"],
    ]
    for i, row_data in enumerate(example_rows, start=4):
        ws.row_dimensions[i].height = 18
        for col, val in enumerate(row_data, start=1):
            data_cell(ws, i, col, val, bg=C_ROW_EXAMPLE)

    # Blank input rows
    for r in range(4 + len(example_rows), 4 + len(example_rows) + 20):
        ws.row_dimensions[r].height = 18
        for col in range(1, len(EXPLICIT_UPF_COLUMNS) + 1):
            data_cell(ws, r, col, "", bg=C_ROW_INPUT)

    # Warning
    warn_row = 4 + len(example_rows) + 22
    ws.cell(row=warn_row, column=1,
            value="⚠ Delete or overwrite the yellow example rows before running the agent.").font = Font(
        color="C00000", bold=True, size=10)
    ws.cell(row=warn_row + 1, column=1,
            value="ℹ Each row becomes a 'with explicit_upf(...)' block in pd_spec.py.").font = Font(
        color="1F3864", bold=True, size=10)
    ws.cell(row=warn_row + 2, column=1,
            value="ℹ Leave this entire sheet empty if your design has no sub-IP UPF files.").font = Font(
        color="1F3864", bold=True, size=10)


# ─────────────────────────────────────────────────────────────────────────────
#  Sheet 7 – PRIMARY_PD OVERRIDES
# ─────────────────────────────────────────────────────────────────────────────

PRIMARY_PD_COLUMNS = [
    # (header_text, bg_color, width, description, example, mandatory)
    ("BLOCK_NAME",         C_HEADER_FUNC, 30,
     "Instance name or search pattern for the block whose PRIMARY_PD is wrong.\n"
     "This is the RTL instance name as it appears in the SOC assembly.",
     "subfcmemleft", True),

    ("SEARCH_TYPE",        C_HEADER_FUNC, 16,
     "How to find this block in the assembly:\n"
     "  name   = match by instance name (soc.search('block_name'))\n"
     "  module = match by module name (soc.searchall('&module_name'))",
     "name", True),

    ("CORRECT_PRIMARY_PD", C_HEADER_FUNC, 22,
     "What should PRIMARY_PD be set to for this block?\n"
     "Must be a valid supply rail name (e.g. VCCINF, VCCFIXDIG_W).\n"
     "This overrides whatever the floorplan/PD automation auto-detected.",
     "VCCINF", True),

    ("REASON",             C_HEADER_META, 50,
     "Why is the override needed? What went wrong with auto-detection?\n"
     "Documentation only — does not affect generated code.\n"
     "E.g. 'Floorplan says VCCFIXDIG_W but HAS says this block is on VCCINF'",
     "Floorplan says VCCFIXDIG_W but HAS says VCCINF", False),
]


def build_primary_pd_overrides_sheet(wb):
    ws = wb.create_sheet("05_PRIMARY_PD_OVERRIDES", 5)
    ws.sheet_view.showGridLines = False
    ws.freeze_panes = "A4"

    title_row(ws,
        "05 — PRIMARY_PD OVERRIDES  (one row per block whose auto-detected primary power domain is WRONG)  |  "
        "Leave empty if all blocks are correct",
        len(PRIMARY_PD_COLUMNS), row=1)

    # Description row
    ws.row_dimensions[2].height = 80
    for col, (hdr, bg, width, desc, example, mandatory) in enumerate(PRIMARY_PD_COLUMNS, start=1):
        c = ws.cell(row=2, column=col, value=desc)
        c.fill = fill("F0F0F0")
        c.font = Font(italic=True, size=8, color="404040", name="Calibri")
        c.alignment = Alignment(wrap_text=True, vertical="top")
        c.border = border_thin()
        ws.column_dimensions[get_column_letter(col)].width = width

    # Header row
    ws.row_dimensions[3].height = 22
    for col, (hdr, bg, width, desc, example, mandatory) in enumerate(PRIMARY_PD_COLUMNS, start=1):
        header_cell(ws, 3, col, hdr, bg=bg, width=None)

    # Example rows (yellow)
    example_rows = [
        ["corimh", "name", "VCCINF",
         "Top-level die block — PD automation defaulted to vcc instead of VCCINF"],
        ["subfcmemleft", "name", "VCCINF",
         "Floorplan says VCCFIXDIG_W but HAS says all digital blocks on VCCINF"],
        ["subfcmemright", "name", "VCCINF",
         "Same as subfcmemleft — HAS mandates VCCINF"],
    ]
    for i, row_data in enumerate(example_rows, start=4):
        ws.row_dimensions[i].height = 18
        for col, val in enumerate(row_data, start=1):
            data_cell(ws, i, col, val, bg=C_ROW_EXAMPLE)

    # Blank input rows
    for r in range(4 + len(example_rows), 4 + len(example_rows) + 20):
        ws.row_dimensions[r].height = 18
        for col in range(1, len(PRIMARY_PD_COLUMNS) + 1):
            data_cell(ws, r, col, "", bg=C_ROW_INPUT)

    # Dropdown for SEARCH_TYPE
    add_dropdown(ws, "B", 4, 30, ["name", "module"])

    # Warnings
    warn_row = 4 + len(example_rows) + 22
    ws.cell(row=warn_row, column=1,
            value="⚠ Delete or overwrite the yellow example rows before running the agent.").font = Font(
        color="C00000", bold=True, size=10)
    ws.cell(row=warn_row + 1, column=1,
            value="ℹ Each row generates a PRIMARY_PD override in gen_rum_inputs.py.").font = Font(
        color="1F3864", bold=True, size=10)
    ws.cell(row=warn_row + 2, column=1,
            value="ℹ Leave this entire sheet empty if all blocks auto-detect the correct PRIMARY_PD.").font = Font(
        color="1F3864", bold=True, size=10)
    ws.cell(row=warn_row + 3, column=1,
            value="ℹ Common symptom: top-level UPF gets 'create_supply_net vcc' instead of 'create_supply_net VCCINF'").font = Font(
        color="1F3864", bold=True, size=10)


# ─────────────────────────────────────────────────────────────────────────────
#  Main
# ─────────────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        description="Generate pd_spec.py Excel input template"
    )
    parser.add_argument(
        "--output", "-o",
        default="./pd_spec_input_template.xlsx",
        help="Output path for the Excel template (default: ./pd_spec_input_template.xlsx)"
    )
    args = parser.parse_args()

    out_path = Path(args.output)
    out_path.parent.mkdir(parents=True, exist_ok=True)

    wb = openpyxl.Workbook()
    # Remove default sheet
    wb.remove(wb.active)

    build_instructions_sheet(wb)
    build_global_sheet(wb)
    build_rails_sheet(wb)
    build_consumers_sheet(wb)
    build_explicit_upf_sheet(wb)
    build_primary_pd_overrides_sheet(wb)
    build_reference_sheet(wb)

    # Make INSTRUCTIONS the active sheet on open
    wb.active = wb["00_INSTRUCTIONS"]

    wb.save(str(out_path))
    print(f"\n✓ Template created: {out_path}")
    print(f"  Sheets: 00_INSTRUCTIONS, 01_GLOBAL_CONFIG, 02_SUPPLY_RAILS, 03_CONSUMERS,")
    print(f"          04_EXPLICIT_UPF, 05_PRIMARY_PD_OVERRIDES, 06_REFERENCE")
    print(f"\nNext steps:")
    print(f"  1. Open {out_path} in Excel or LibreOffice Calc")
    print(f"  2. Read 00_INSTRUCTIONS sheet first")
    print(f"  3. Fill ALL sheets: 01 through 05  (04 and 05 can be left empty if not needed)")
    print(f"  4. Run:  python gen_pd_spec_from_xls.py --input {out_path} --output pd_spec.py")


if __name__ == "__main__":
    main()
