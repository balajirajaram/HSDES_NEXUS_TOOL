#!/usr/bin/env python3
"""
gen_pd_spec_from_xls.py
========================
Reads the filled pd_spec input Excel template and generates a valid pd_spec.py
for RUM UPF generation. Performs full validation before writing output.

Usage:
    python gen_pd_spec_from_xls.py --input pd_spec_input_template.xlsx --output pd_spec.py
    python gen_pd_spec_from_xls.py --input filled_template.xlsx --output pd_spec.py --force

Requirements:
    pip install openpyxl
"""

import argparse
import re
import shutil
import sys
from pathlib import Path

try:
    import openpyxl
except ImportError:
    print("ERROR: openpyxl is required. Install with:  pip install openpyxl")
    sys.exit(1)

# ─────────────────────────────────────────────────────────────────────────────
#  Console helpers
# ─────────────────────────────────────────────────────────────────────────────
RED    = "\033[91m"
GREEN  = "\033[92m"
YELLOW = "\033[93m"
CYAN   = "\033[96m"
BOLD   = "\033[1m"
RESET  = "\033[0m"

def ok(msg):    print(f"{GREEN}  ✓ {msg}{RESET}")
def warn(msg):  print(f"{YELLOW}  ⚠  {msg}{RESET}")
def err(msg):   print(f"{RED}  ✗  {msg}{RESET}")
def info(msg):  print(f"    {msg}")
def section(m): print(f"\n{BOLD}{CYAN}{'─'*60}{RESET}\n{BOLD}{CYAN}  {m}{RESET}")


# ─────────────────────────────────────────────────────────────────────────────
#  Excel reader helpers
# ─────────────────────────────────────────────────────────────────────────────

def cell_val(cell) -> str:
    """Return stripped string value of a cell, empty string if None."""
    v = cell.value
    if v is None:
        return ""
    return str(v).strip()


def is_example_row(row_values: list) -> bool:
    """
    Detect if a row is still the yellow example row that the user forgot to delete.
    We check for known example rail names from the template.
    """
    known_examples = {
        "VCCFIXDIG_MIO", "VCCCFCMEM", "VCCINF", "VCCANA_MIOPHY0"
    }
    if row_values and row_values[0].upper() in known_examples:
        # Could still be real data — so we only flag if multiple cells match
        # example-specific values
        row_str = " ".join(row_values)
        example_hints = [
            "Supply for Digital agent logic of UIO",
            "vccdig, vccst",
            "uio.hiop, pcie5x16",
            "Optional comment",
        ]
        for hint in example_hints:
            if hint.lower() in row_str.lower():
                return True
    return False


def read_sheet_as_dicts(ws) -> list:
    """
    Read a worksheet that has:
      Row 2 — description row (skip)
      Row 3 — header row
      Row 4+ — data rows
    Returns list of dicts keyed by column header.
    """
    # Find header row — scan rows 2..5 for the row that has all-caps words
    header_row_idx = None
    for r in range(2, 6):
        row_vals = [cell_val(ws.cell(row=r, column=c)) for c in range(1, ws.max_column + 1)]
        upper_count = sum(1 for v in row_vals if v and v.isupper() and len(v) > 2)
        if upper_count >= 2:
            header_row_idx = r
            break

    if header_row_idx is None:
        return []

    headers = [cell_val(ws.cell(row=header_row_idx, column=c))
               for c in range(1, ws.max_column + 1)]

    rows = []
    for r in range(header_row_idx + 1, ws.max_row + 1):
        row_data = {headers[c]: cell_val(ws.cell(row=r, column=c + 1))
                    for c in range(len(headers))}
        # Skip fully empty rows
        if all(v == "" for v in row_data.values()):
            continue
        rows.append(row_data)

    return rows


def read_global_config(ws) -> dict:
    """
    Read 01_GLOBAL_CONFIG sheet.
    Returns dict with keys: design_name, ground_net, pst_enabled, spec_version
    """
    config = {}
    # This sheet has FIELD in col A, YOUR VALUE in col B, starting row 3
    for r in range(3, ws.max_row + 1):
        field = cell_val(ws.cell(row=r, column=1)).upper()
        value = cell_val(ws.cell(row=r, column=2))
        if field == "DESIGN_NAME":
            config["design_name"] = value
        elif field == "GROUND_NET":
            config["ground_net"] = value if value else "vss"
        elif field == "PST_POWER_STATE":
            config["pst_enabled"] = value.lower() in ("yes", "true", "1")
        elif field == "SPEC_VERSION":
            config["spec_version"] = value if value else "0.1"
        elif field == "TOP_MODULE":
            config["top_module"] = value
        elif field == "DIE_TYPE":
            config["die_type"] = value.lower() if value else ""
        elif field == "PICKLE_PATH":
            config["pickle_path"] = value
    return config


# ─────────────────────────────────────────────────────────────────────────────
#  Validation
# ─────────────────────────────────────────────────────────────────────────────

LOCATION_PATTERNS = [
    r"^/$",
    r"^(/[\w\*\.\-]+)+$",
    r"^/<.+>$",
    r"^//<.+>$",
    r"^//&[\w\*\.\-]+$",
    r"^&[\w\*\.\-]+",
    r"^//\*\[=.+\]$",
    r"^[\w][\w\.\-]*$",
    r"^//<[\w\(\)\|\.\*_\-]+>$",
    r"^/[\w/\.\*\-]+$",
]


def validate_location(loc: str) -> bool:
    if not loc:
        return False
    for p in LOCATION_PATTERNS:
        if re.match(p, loc):
            return True
    return False


def validate_all(global_cfg: dict, rails: list, consumers: list) -> list:
    """
    Full cross-validation. Returns list of (severity, message) tuples.
    severity: 'ERROR' or 'WARNING'
    """
    issues = []
    E = lambda m: issues.append(("ERROR", m))
    W = lambda m: issues.append(("WARNING", m))

    # ── Global config ──────────────────────────────────────────────────────
    if not global_cfg.get("design_name"):
        E("01_GLOBAL_CONFIG: DESIGN_NAME is empty.")
    if not global_cfg.get("ground_net"):
        W("01_GLOBAL_CONFIG: GROUND_NET is empty — defaulting to 'vss'.")

    # ── Rails ──────────────────────────────────────────────────────────────
    if not rails:
        E("02_SUPPLY_RAILS: No supply rails found. Sheet is empty or has only example rows.")
        return issues

    rail_names = []
    seen_names = set()
    seen_boot_orders = {}

    for i, r in enumerate(rails, start=1):
        name = r.get("RAIL_NAME", "").upper()

        if not name:
            E(f"02_SUPPLY_RAILS row {i}: RAIL_NAME is empty.")
            continue

        if name in seen_names:
            E(f"02_SUPPLY_RAILS: Duplicate RAIL_NAME '{name}'.")
        seen_names.add(name)
        rail_names.append(name)

        # supply_type
        st = r.get("SUPPLY_TYPE", "").lower()
        if st not in ("digital", "analog", ""):
            E(f"Rail '{name}': SUPPLY_TYPE must be 'digital' or 'analog', got '{st}'.")

        # is_primary_source
        ips = r.get("IS_PRIMARY_SOURCE", "").lower()
        if ips not in ("yes", "no"):
            E(f"Rail '{name}': IS_PRIMARY_SOURCE must be 'yes' or 'no', got '{ips}'.")
        elif ips == "no":
            parent = r.get("PARENT_SUPPLY", "").upper()
            if not parent:
                E(f"Rail '{name}': IS_PRIMARY_SOURCE=no but PARENT_SUPPLY is empty.")

        # FIVR boot order uniqueness
        boot_str = r.get("FIVR_BOOT_ORDER", "")
        if boot_str:
            try:
                boot_int = int(float(boot_str))
                if boot_int in seen_boot_orders:
                    E(f"Rail '{name}': FIVR_BOOT_ORDER={boot_int} is already used by rail "
                      f"'{seen_boot_orders[boot_int]}'.")
                else:
                    seen_boot_orders[boot_int] = name
            except ValueError:
                E(f"Rail '{name}': FIVR_BOOT_ORDER must be an integer, got '{boot_str}'.")

        # RA_CONFIG
        ra = r.get("RA_CONFIG", "")
        if ra and ra not in ("Root", "Solo"):
            E(f"Rail '{name}': RA_CONFIG must be 'Root' or 'Solo', got '{ra}'.")

        # VNOM
        vnom = r.get("VNOM", "")
        if vnom:
            try:
                float(vnom)
            except ValueError:
                W(f"Rail '{name}': VNOM='{vnom}' is not a valid number. Will be stored as-is.")

    # Parent supply existence + circular check
    for r in rails:
        name = r.get("RAIL_NAME", "").upper()
        ips  = r.get("IS_PRIMARY_SOURCE", "").lower()
        if ips == "no":
            parent = r.get("PARENT_SUPPLY", "").upper()
            if parent and parent not in rail_names:
                E(f"Rail '{name}': PARENT_SUPPLY='{parent}' is not defined in 02_SUPPLY_RAILS "
                  f"(known: {', '.join(rail_names)}).")

    # Circular parent detection
    parent_map = {r.get("RAIL_NAME","").upper(): r.get("PARENT_SUPPLY","").upper()
                  for r in rails}
    for start in rail_names:
        visited, cur = set(), start
        while cur:
            if cur in visited:
                E(f"Circular parent dependency detected starting from rail '{start}'.")
                break
            visited.add(cur)
            cur = parent_map.get(cur, "")

    # ── Consumers ──────────────────────────────────────────────────────────
    if not consumers:
        E("03_CONSUMERS: No consumer entries found. Every rail needs at least one consumer.")
        return issues

    # Build rail → consumers map
    rail_consumer_map = {}
    for i, c in enumerate(consumers, start=1):
        rail = c.get("RAIL_NAME", "").upper()
        loc  = c.get("LOCATION", "")
        prim = c.get("IS_PRIMARY", "").lower()

        if not rail:
            E(f"03_CONSUMERS row {i}: RAIL_NAME is empty.")
            continue
        if rail not in rail_names:
            E(f"03_CONSUMERS row {i}: RAIL_NAME='{rail}' not found in 02_SUPPLY_RAILS.")
            continue
        if not loc:
            E(f"03_CONSUMERS row {i} (rail '{rail}'): LOCATION is empty.")
            continue
        if not validate_location(loc):
            W(f"03_CONSUMERS row {i} (rail '{rail}'): LOCATION='{loc}' has unrecognized "
              f"syntax. Check 04_REFERENCE sheet for valid patterns.")
        if prim not in ("yes", "no", ""):
            E(f"03_CONSUMERS row {i} (rail '{rail}'): IS_PRIMARY must be 'yes' or 'no', got '{prim}'.")

        rail_consumer_map.setdefault(rail, []).append(c)

    # Every defined rail must have consumers
    for rname in rail_names:
        if rname not in rail_consumer_map:
            E(f"Rail '{rname}': No consumer entries found in 03_CONSUMERS. "
              f"RUM will not generate a power domain for it.")

    # Exactly one primary consumer per rail
    for rname, cons in rail_consumer_map.items():
        primaries = [c for c in cons if c.get("IS_PRIMARY","").lower() == "yes"]
        if len(primaries) == 0:
            E(f"Rail '{rname}': No consumer has IS_PRIMARY=yes. "
              f"RUM requires exactly one primary domain assignment per supply.")
        elif len(primaries) > 1:
            locs = [c["LOCATION"] for c in primaries]
            E(f"Rail '{rname}': {len(primaries)} consumers have IS_PRIMARY=yes "
              f"({', '.join(locs)}). Only ONE should be primary.")

    return issues


# ─────────────────────────────────────────────────────────────────────────────
#  Code generation
# ─────────────────────────────────────────────────────────────────────────────

def fmt_str_list(raw: str) -> str:
    """Convert 'a, b, c' → ['a', 'b', 'c'] as Python list string."""
    items = [x.strip() for x in raw.split(",") if x.strip()]
    if not items:
        return "[]"
    return "[" + ", ".join(f"'{x}'" for x in items) + "]"


def generate_consumer_line(c: dict, indent: str = "            ") -> str:
    loc   = c.get("LOCATION", "")
    prim  = c.get("IS_PRIMARY", "").lower() == "yes"
    pp    = c.get("POWER_PORTS", "")
    gp    = c.get("GROUND_PORTS", "")

    args = [f"location='{loc}'"]
    if prim:
        args.append("is_primary=True")
    if pp:
        items = [x.strip() for x in pp.split(",") if x.strip()]
        args.append(f"power_ports=[{', '.join(repr(x) for x in items)}]")
    if gp:
        items = [x.strip() for x in gp.split(",") if x.strip()]
        args.append(f"ground_ports=[{', '.join(repr(x) for x in items)}]")

    return f"{indent}consumer({', '.join(args)})"


def generate_pd_spec(global_cfg: dict, rails: list, consumers: list,
                     explicit_upfs: list = None) -> str:
    """Generate the full pd_spec.py text."""

    if explicit_upfs is None:
        explicit_upfs = []

    ground = global_cfg.get("ground_net", "vss")
    design = global_cfg.get("design_name", "unknown")

    # Build consumer lookup by rail name
    consumer_map = {}
    for c in consumers:
        rname = c.get("RAIL_NAME", "").upper()
        consumer_map.setdefault(rname, []).append(c)

    lines = []

    # ── File header ────────────────────────────────────────────────────────
    lines += [
        '"""',
        'Spec file for a tree-shaped spec of class socb.domains.power_delivery.v_0_5.dm.PowerDeliverySpec',
        '',
        f'Design : {design}',
        f'Ground : {ground}',
        '',
        'Generated by gen_pd_spec_from_xls.py',
        '',
        'For documentation:',
        '  http://visa-it.intel.com/socb/api_doc/socb/domains/power_delivery/v_0_5/dm.html#PowerDeliverySpec',
        '"""',
        '',
        'from __future__ import annotations',
        'from socb.domains.power_delivery.v_0_5.dm import PowerDeliverySpec',
        'from pathlib import Path',
        'import os',
        '',
        "work_area = Path(os.environ.get('WORKAREA'))",
        '',
        '',
        'def specify(spec: PowerDeliverySpec, **kwds) -> PowerDeliverySpec:',
        '    "A function that enriches `spec` with specifications"',
        '    # Extract `PowerDeliverySpec` methods:',
        '    include       = spec.include',
        '    override      = spec.override',
        '    translate     = spec.translate',
        '    explicit_upf  = spec.explicit_upf',
        '    instance      = spec.instance',
        '    attr          = spec.attr',
        '    power_switch  = spec.power_switch',
        '    partition     = spec.partition',
        '    consumer      = spec.consumer',
        '    input_supply  = spec.input_supply',
        '    control_port  = spec.control_port',
        '    ack_port      = spec.ack_port',
        '    supply_set    = spec.supply_set',
        '    anchor        = spec.anchor',
        '    provider      = spec.provider',
        '    # Spec:',
        '',
        f"    attr(version='{global_cfg.get('spec_version', '0.1')}')",
        '',
    ]

    if global_cfg.get("pst_enabled", True):
        lines.append("    attr(pst_power_state=True)")
        lines.append("")

    # ── Explicit UPF entries ───────────────────────────────────────────────
    if explicit_upfs:
        lines.append("    # ─── Explicit UPF entries (from 04_EXPLICIT_UPF sheet) ───")
        for eu in explicit_upfs:
            upf_file = eu.get("UPF_FILENAME", "")
            upf_dir  = eu.get("UPF_DIRECTORY", "")
            if not upf_file or not upf_dir:
                continue
            full_path = f"{upf_dir}/{upf_file}"
            lines.append(f"    with explicit_upf(work_area / '{full_path}'):")
            lines.append(f"        attr(location='{full_path}')")
            ip_name = eu.get("IP_NAME", "")
            if ip_name:
                lines.append(f"        # IP: {ip_name}")
            notes = eu.get("NOTES", "")
            if notes:
                lines.append(f"        # {notes}")
            lines.append("")
        lines.append("")

    # ── Per-rail blocks ────────────────────────────────────────────────────
    for r in rails:
        name = r.get("RAIL_NAME", "").upper()
        st   = r.get("SUPPLY_TYPE", "digital").lower()
        src  = r.get("SOURCE", "")
        ips  = r.get("IS_PRIMARY_SOURCE", "yes").lower() == "yes"
        par  = r.get("PARENT_SUPPLY", "").upper()

        lines.append(f"    with supply_set(power='{name}', ground='{ground}'):")
        lines.append(f"        attr(supply_type='{st}')")

        if src:
            lines.append(f"        attr(source='{src}')")

        desc = r.get("DESCRIPTION", "")
        if desc:
            lines.append(f"        attr(description='{desc}')")

        die = r.get("DIE", "")
        if die:
            lines.append(f"        attr(die='{die}')")

        cips = r.get("CONSUMER_IPS", "")
        if cips:
            lines.append(f"        attr(consumer_ips={fmt_str_list(cips)})")

        vnom = r.get("VNOM", "")
        if vnom:
            lines.append(f"        attr(vnom='{vnom}')")

        vrange = r.get("VOLTAGE_RANGE", "")
        if vrange:
            lines.append(f"        attr(voltage_range='{vrange}')")

        qual = r.get("QUALITY", "")
        if qual:
            lines.append(f"        attr(quality='{qual}')")

        lines.append(f"        attr(is_primary_source={ips})")

        if not ips and par:
            lines.append(f"        attr(parent='{par}')")

        pm = r.get("PM_MODES", "")
        if pm:
            lines.append(f"        attr(pm={fmt_str_list(pm)})")

        bumps = r.get("BUMPS", "")
        if bumps:
            try:
                lines.append(f"        attr(bumps={float(bumps)})")
            except ValueError:
                pass

        boot = r.get("FIVR_BOOT_ORDER", "")
        if boot:
            try:
                lines.append(f"        attr(fivr_boot_order={int(float(boot))})")
            except ValueError:
                pass

        ra = r.get("RA_CONFIG", "")
        if ra:
            lines.append(f"        attr(ra_config='{ra}')")

        # Consumer entries
        lines.append(f"        with provider(location=''):")
        for c in consumer_map.get(name, []):
            lines.append(generate_consumer_line(c))

        lines.append("")

    # ── Auto-consumer loop ─────────────────────────────────────────────────
    lines += [
        "    # Auto-assign blocks that declare their power domain via SOCB assembly attributes",
        "    for supply_set in spec.supply_sets:",
        "        power_domain = supply_set.power",
        "        for provider in supply_set.providers:",
        "            with provider:",
        "                consumer(f\"//*[='{power_domain}' in config_tar_dm_sb_rpt_pd_domains]\")",
        "                consumer(f\"//*[=dft_domain == True and '{power_domain}' in dft_pd_domains]\")",
        "                consumer(f\"//*[=dfd_domain == True and '{power_domain}' in dfd_pd_domains]\")",
        "                consumer(f\"//*[='{power_domain}' in sb_rpt_synchronizer_pd_domains]\")",
        "                consumer(f\"//*[='{power_domain}' in t_pd_domains]\")",
        "",
        "    return spec",
        "",
        "",
        "# Invoke the above function to add specs to an existing spec (if found in",
        "# the current namespace) or create a new spec and add specs to.",
        "specify(result_spec := PowerDeliverySpec.get_current_spec(), **PowerDeliverySpec.get_current_namespace())",
        "",
    ]

    return "\n".join(lines)


# ─────────────────────────────────────────────────────────────────────────────
#  gen_rum_inputs.py generation
# ─────────────────────────────────────────────────────────────────────────────

def generate_gen_rum_inputs(global_cfg: dict, pd_overrides: list) -> str:
    """Generate a gen_rum_inputs.py with PRIMARY_PD overrides from sheet 05."""

    top_module = global_cfg.get("top_module", global_cfg.get("design_name", "corimh"))
    lines = [
        'import argparse',
        'import os',
        'import sys',
        'from pathlib import Path',
        '',
        'from socb.assembly.dm import SOC, Block',
        'from socb.domains.power_delivery.v_0_5 import PowerDeliveryAutomation',
        'from socb.domains.power_delivery.v_0_5.dm import PowerDeliverySpec, Provider',
        'from socb.domains.power_delivery.v_0_1.rum_yaml_generator import RUMUPFYamlGenerator',
        'from socb.assembly.dm.reporting import print_nets',
        'from socb.utils import logging',
        '',
        "sys.path.append(os.path.abspath(os.path.dirname(__file__)))",
        'from pd_utils import pickle_to_soc, run_pd_automation, gen_rum_yamls, enrich_pd_spec_w_assembly_pds, load_pd_specs',
        '',
        '',
        'def main():',
        "    parser = argparse.ArgumentParser(description='Power Delivery Automation Flow')",
        '    parser.add_argument(\'--soc-pickle\', dest="soc_pickle", required=True, nargs="+")',
        '    parser.add_argument(\'--pd-spec\', dest="pd_spec", required=True, nargs=\'+\')',
        '    parser.add_argument(\'--out_dir\', dest="out_dir", required=False)',
        '    parser.add_argument(\'--library_name\', dest="library_name", required=False)',
        '    args = parser.parse_args()',
        '',
        '    for spec_file in args.pd_spec:',
        '        if not os.path.isfile(spec_file):',
        '            raise FileNotFoundError(f"PD Spec file not found: {spec_file}")',
        '',
        '    output_dir = Path(args.out_dir)',
        '    output_dir.mkdir(parents=True, exist_ok=True)',
        '',
        '    soc = pickle_to_soc(*args.soc_pickle, library_name=args.library_name)',
        '    original_spec = load_pd_specs(*args.pd_spec, soc=soc)',
        '    enriched_spec = enrich_pd_spec_w_assembly_pds(original_spec, soc)',
        '    pd_automation = run_pd_automation(spec=enriched_spec, soc=soc, out_dir=output_dir)',
        '',
        '    # === PRIMARY_PD Overrides (from 05_PRIMARY_PD_OVERRIDES sheet) ===',
        '    from socb.domains.power_delivery.v_0_1.dm import PRIMARY_PD',
    ]

    for ovr in pd_overrides:
        block_name   = ovr.get("BLOCK_NAME", "")
        search_type  = ovr.get("SEARCH_TYPE", "name").lower()
        correct_pd   = ovr.get("CORRECT_PRIMARY_PD", "")
        reason       = ovr.get("REASON", "")

        lines.append(f"    # Override: {reason}" if reason else f"    # Override for {block_name}")
        if search_type == "module":
            lines.append(f"    for _blk in soc.searchall('&{block_name}'):")
            lines.append(f"        _blk.attrs[PRIMARY_PD] = '{correct_pd}'")
        else:
            lines.append(f"    _blk = soc.search('{block_name}')")
            lines.append(f"    if _blk:")
            lines.append(f"        _blk.attrs[PRIMARY_PD] = '{correct_pd}'")

    lines += [
        '',
        '    # Validate',
        '    pd_automation.name = "power_delivery_automation"',
        '    pd_automation.validate(out_dir=output_dir / "drc", waiver=None, config=None)',
        '',
        '    # Generate RUM YAMLs',
        '    gen_rum_yamls(pd_automation, output_dir)',
        '',
        '',
        'main()',
        '',
    ]

    return "\n".join(lines)


# ─────────────────────────────────────────────────────────────────────────────
#  Main
# ─────────────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        description="Generate pd_spec.py from a filled Excel template"
    )
    parser.add_argument("--input",  "-i", required=True,
                        help="Path to the filled Excel template (.xlsx)")
    parser.add_argument("--output", "-o", default="./pd_spec.py",
                        help="Output path for pd_spec.py (default: ./pd_spec.py)")
    parser.add_argument("--force",  "-f", action="store_true",
                        help="Write output even if validation errors exist")
    args = parser.parse_args()

    in_path  = Path(args.input)
    out_path = Path(args.output)

    # ── Load workbook ──────────────────────────────────────────────────────
    section("LOADING EXCEL TEMPLATE")
    if not in_path.exists():
        err(f"Input file not found: {in_path}")
        sys.exit(1)

    wb = openpyxl.load_workbook(str(in_path), data_only=True)
    ok(f"Loaded: {in_path}")

    # Check required sheets
    required_sheets = ["01_GLOBAL_CONFIG", "02_SUPPLY_RAILS", "03_CONSUMERS"]
    for s in required_sheets:
        if s not in wb.sheetnames:
            err(f"Required sheet '{s}' not found in workbook.")
            err(f"Available sheets: {', '.join(wb.sheetnames)}")
            sys.exit(1)

    # ── Read data ──────────────────────────────────────────────────────────
    section("READING DATA")

    global_cfg = read_global_config(wb["01_GLOBAL_CONFIG"])
    ok(f"Global config: design='{global_cfg.get('design_name','')}', "
       f"ground='{global_cfg.get('ground_net','vss')}', "
       f"pst={global_cfg.get('pst_enabled',True)}")

    rail_rows = read_sheet_as_dicts(wb["02_SUPPLY_RAILS"])
    # Filter out example rows
    rails_filtered = []
    example_skipped = 0
    for r in rail_rows:
        row_vals = list(r.values())
        if is_example_row(row_vals):
            example_skipped += 1
            warn(f"Skipping example row (rail '{r.get('RAIL_NAME','')}') — "
                 f"delete example rows from template before running.")
        else:
            rails_filtered.append(r)
    rails = rails_filtered

    ok(f"Supply rails loaded: {len(rails)}  (skipped {example_skipped} example rows)")
    for r in rails:
        info(f"  {r.get('RAIL_NAME','')}  [{r.get('SUPPLY_TYPE','')}]  "
             f"src={r.get('SOURCE','')}  primary_src={r.get('IS_PRIMARY_SOURCE','')}")

    consumer_rows = read_sheet_as_dicts(wb["03_CONSUMERS"])
    consumers_filtered = []
    cex_skipped = 0
    for c in consumer_rows:
        row_vals = list(c.values())
        if is_example_row(row_vals):
            cex_skipped += 1
        else:
            consumers_filtered.append(c)
    consumers = consumers_filtered

    ok(f"Consumer entries loaded: {len(consumers)}  (skipped {cex_skipped} example rows)")

    # ── Read optional sheets ───────────────────────────────────────────────
    explicit_upfs = []
    if "04_EXPLICIT_UPF" in wb.sheetnames:
        eu_rows = read_sheet_as_dicts(wb["04_EXPLICIT_UPF"])
        for eu in eu_rows:
            if eu.get("UPF_FILENAME", "") and eu.get("UPF_DIRECTORY", ""):
                explicit_upfs.append(eu)
        ok(f"Explicit UPF entries loaded: {len(explicit_upfs)}")
    else:
        info("Sheet 04_EXPLICIT_UPF not found — skipping.")

    pd_overrides = []
    if "05_PRIMARY_PD_OVERRIDES" in wb.sheetnames:
        ovr_rows = read_sheet_as_dicts(wb["05_PRIMARY_PD_OVERRIDES"])
        for ovr in ovr_rows:
            if ovr.get("BLOCK_NAME", "") and ovr.get("CORRECT_PRIMARY_PD", ""):
                pd_overrides.append(ovr)
        ok(f"PRIMARY_PD overrides loaded: {len(pd_overrides)}")
    else:
        info("Sheet 05_PRIMARY_PD_OVERRIDES not found — skipping.")

    # ── Validate ───────────────────────────────────────────────────────────
    section("VALIDATION")
    issues = validate_all(global_cfg, rails, consumers)

    errors   = [m for sev, m in issues if sev == "ERROR"]
    warnings = [m for sev, m in issues if sev == "WARNING"]

    for m in warnings:
        warn(m)
    for m in errors:
        err(m)

    if errors:
        print(f"\n{BOLD}{RED}  Found {len(errors)} ERROR(s) and {len(warnings)} WARNING(s).{RESET}")
        if not args.force:
            err("pd_spec.py NOT generated due to validation errors.")
            err("Fix the issues in the Excel file and re-run.")
            err("Use --force to generate anyway (may cause RUM failures).")
            sys.exit(1)
        else:
            warn("--force flag set: generating despite errors. RUM may fail.")
    else:
        ok(f"All validation checks passed! ({len(warnings)} warning(s))")

    # ── Generate ───────────────────────────────────────────────────────────
    section("GENERATING pd_spec.py")
    content = generate_pd_spec(global_cfg, rails, consumers, explicit_upfs)

    out_path.parent.mkdir(parents=True, exist_ok=True)
    if out_path.exists():
        backup = str(out_path) + ".bak"
        shutil.copy(str(out_path), backup)
        warn(f"Existing file backed up to: {backup}")

    with open(str(out_path), "w") as f:
        f.write(content)

    ok(f"Generated: {out_path}")

    # ── Generate gen_rum_inputs.py if overrides exist ──────────────────────
    if pd_overrides:
        section("GENERATING gen_rum_inputs.py")
        rum_content = generate_gen_rum_inputs(global_cfg, pd_overrides)
        rum_path = out_path.parent / "gen_rum_inputs.py"
        if rum_path.exists():
            rum_backup = str(rum_path) + ".bak"
            shutil.copy(str(rum_path), rum_backup)
            warn(f"Existing gen_rum_inputs.py backed up to: {rum_backup}")
        with open(str(rum_path), "w") as f:
            f.write(rum_content)
        ok(f"Generated: {rum_path}")
        info(f"  PRIMARY_PD overrides: {len(pd_overrides)}")
        for ovr in pd_overrides:
            info(f"    {ovr['BLOCK_NAME']} → {ovr['CORRECT_PRIMARY_PD']}  ({ovr.get('REASON','')})")

    # ── Summary ────────────────────────────────────────────────────────────
    section("SUMMARY")
    info(f"Design         : {global_cfg.get('design_name','')}")
    info(f"PST enabled    : {global_cfg.get('pst_enabled', True)}")
    info(f"Supply rails   : {len(rails)}")
    info(f"Total consumers: {len(consumers)}")
    info(f"Explicit UPFs  : {len(explicit_upfs)}")
    info(f"PD overrides   : {len(pd_overrides)}")
    info(f"Output file    : {out_path}")

    section("NEXT STEPS")
    info("1. Review generated file:")
    info(f"     cat {out_path}")
    info("")
    info("2. Run upf_rum_yamlgen to validate against RTL hierarchy:")
    info("     make -C integration/rum rum_yamlgen")
    info("")
    info("3. Check for NOTICE/ERROR messages in the log:")
    info(f"     grep -E '^-E-|NOTICE' output/{global_cfg.get('design_name','')}/rum/logs/upf_gen_*.log")
    info("")
    info("4. If a consumer shows '!! NOTICE: location spec did not find any assembly blocks',")
    info("   update the LOCATION pattern in the Excel 03_CONSUMERS sheet and re-run.")


if __name__ == "__main__":
    main()
