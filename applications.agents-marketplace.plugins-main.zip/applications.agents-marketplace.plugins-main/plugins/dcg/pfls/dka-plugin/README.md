# DKA Plugin

Design Knowledge Assistant (DKA) is an enterprise GenAI-powered platform that unifies engineering knowledge from multiple sources into a single intelligent workflow, enabling faster and more informed decision-making.
It delivers real-time, context-aware insights by integrating data across design specifications, HSD articles, Jira project data, and repositories such as ProMark, SharePoint, RDC, Wiki, and GitHub. The platform enables users to interact with both unstructured and structured data using natural language, including advanced querying capabilities.
DKA is accessible through a Web UI and Microsoft Teams, allowing seamless integration into daily workflows. It is built on Azure and OpenAI technologies, leveraging enterprise-grade cloud infrastructure with strict security enforcement across all layers, including APIs, agents, and chatbot responses to protect sensitive data

## Version

**1.0.0**

## Features
[Design Knowledge Assistant Wiki](https://wiki.ith.intel.com/spaces/dka/pages/4096894277/Design+Knowledge+Assistant)

- Vector search across Intel design knowledge sources: SharePoint, Promark, HSDES, JIRA, GitHub, and other enterprise sources
- Natural language queries via `@dka`
- Row-level security that respects your permissions
- HSD security analysis with vulnerability identification and severity assessment
- BEAT RCA (Root Cause Analysis) agent support

## Skills

### 1. core-dka

**Purpose:** Shared MCP app providers and interaction patterns used across all DKA skills — Approval, Choice, and Generative UI.

**When to use:** Referenced by all other DKA skills. Provides full documentation for `Search_mcp_unified_vector_search`, `request_approval`, `choose`, `generate_prefab_ui`, and `search_prefab_components`.

**Location:** [`skills/core-dka/SKILL.md`](skills/core-dka/SKILL.md)

**Key Features:**
- Unified Vector Search with semantic and exact ID lookup
- Human-in-the-loop Approval gate
- Structured Choice prompts
- Generative UI for charts and tables via Prefab Python

---

### 2. hsd-security-analysis

**Purpose:** Intel hardware security domain expertise for analyzing HSD articles — vulnerability identification, severity assessment, threat model evaluation, and security recommendations.

**When to use:** When analyzing an HSD article for security vulnerabilities, assessing threat model requirements, or reviewing HSD articles for compliance with Intel security practices.

**Location:** [`skills/hsd-security-analysis/SKILL.md`](skills/hsd-security-analysis/SKILL.md)

**Key Features:**
- 24-domain security taxonomy (Memory Safety, TDX/SGX, SMM, Boot Chain, Spectre, etc.)
- Severity classification: CRITICAL / HIGH / MEDIUM / LOW
- Execution plan presentation before any tool calls
- Batch and comparison analysis patterns
- Detailed keyword reference in [`skills/hsd-security-analysis/reference.md`](skills/hsd-security-analysis/reference.md)

---

## MCP Server Configuration

### VS Code

The plugin uses the MCP server configuration in `.mcp.json`:

```json
{
  "mcpServers": {
    "dka": {
      "type": "http",
      "url": "https://apisx.intel.io/dka/v1/mcp",
      "headers": {
        "User-Agent": "VS-Code-MCP-Client/1.0 (Intel-Corporate)",
        "X-Client-Version": "1.0.0"
      },
      "oauth": {
        "clientId": "fe0244e5-ad70-4ee5-98d4-3cbd0c9afb1a"
      }
    }
  }
}
```

Authentication is handled automatically via OAuth — no token scripts or Kerberos configuration required.

## Available MCP Tools

| Tool                                     | Description                                                             |
| ---------------------------------------- | ----------------------------------------------------------------------- |
| `Search_mcp_unified_vector_search`       | Semantic/exact-ID search over HSDES articles and Intel specifications   |
| `Search_mcp_retrieve_document_chunks`    | Retrieve specific document chunks by ID                                 |
| `Agents_mcp_beat_rca_agent_stream`       | Run a server-side BEAT RCA analysis                                     |
| `request_approval`                       | Human-in-the-loop approval gate (Approve / Reject card)                 |
| `choose`                                 | Present user with structured clickable options                          |
| `generate_prefab_ui`                     | Render streaming interactive charts and tables via Prefab Python        |
| `search_prefab_components`               | Discover available Prefab UI components                                 |

## Installation

The plugin is installed via the marketplace. No manual installation steps required.

## Usage

**Discovering related HSDs:**

1. Ask: *"Find TDX-related HSDs for Granite Rapids"*
2. The agent uses `Search_mcp_unified_vector_search` with semantic query and `design_items=["GNR"]`
3. Results are presented; use `choose` to confirm batch analysis scope

**Batch security analysis:**

1. Use `choose` to select analysis scope
2. `Agents_mcp_beat_rca_agent_stream` or `hsd-security-analysis` skill runs on each selected HSD
3. `generate_prefab_ui` renders a severity distribution chart and findings table
4. `request_approval` gates any CSV export to the workspace

## Troubleshooting

### Authentication fails (401/403)

- **Cause:** OAuth token expired or client ID misconfigured
- **Solution:** Verify the `clientId` in `.mcp.json` matches `fe0244e5-ad70-4ee5-98d4-3cbd0c9afb1a` and re-authenticate

### No results from vector search

- **Cause:** Overly narrow filters or HSD ID not indexed
- **Solution:** Remove `design_items` or `data_sources` filters; verify the HSD ID exists in HSDES

### Generative UI not rendering

- **Cause:** `fastmcp[apps]` not available in the server environment
- **Solution:** Ensure the DKA server is running with `fastmcp[apps]` installed

## Support

**Owners:**
- DKA Team — Design Knowledge Assistant

**Repository:** https://github.com/intel-innersource/applications.agents-marketplace.plugins

**MCP Endpoint:** https://apisx.intel.io/dka/v1/mcp

## Changelog

### 1.0.0
- Initial release
- `core-dka` skill: shared providers (Unified Vector Search, Approval, Choice, Generative UI)
- `hsd-security-analysis` skill: 24-domain security taxonomy and batch analysis patterns
- OAuth-authenticated HTTP MCP server (no Kerberos required)
