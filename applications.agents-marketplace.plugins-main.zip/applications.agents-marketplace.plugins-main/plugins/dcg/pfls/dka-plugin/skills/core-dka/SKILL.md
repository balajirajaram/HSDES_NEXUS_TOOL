---
name: core-dka
description: Shared MCP app providers and interaction patterns used across all DKA skills — Approval, Choice, and Generative UI.
---

# Core DKA Skill Utilities

This file defines shared tool providers and interaction patterns that are common across all DKA skills. Individual skills reference this file rather than duplicating the content.

---

## Available MCP Tools

### Unified Vector Search (`Search_mcp_unified_vector_search`)

**Purpose**: Retrieve content and related documents from Intel's knowledge base. Supports semantic search, exact ID lookup, and filtered queries by data source, product, or tenant.

**Registered tool**:

| Tool                               | Type | Description                                             |
| ---------------------------------- | ---- | ------------------------------------------------------- |
| `Search_mcp_unified_vector_search` | Tool | Vector search over HSDES articles and related documents |

**Core parameters**:

| Parameter        | Type    | Description                                                            |
| ---------------- | ------- | ---------------------------------------------------------------------- |
| `query`          | string  | Search text or an exact HSD ID                                         |
| `extract_hsd_id` | boolean | Set `true` to treat `query` as an HSD ID and retrieve the full article |
| `retrieve_k`     | integer | Number of results to return (default 5; increase for broader searches) |
| `data_sources`   | string  | Filter by source type: `"hsdes_bug"`, `"hsdes_feature"`, etc.          |
| `design_items`   | list    | Filter by product code(s) — see product code table below               |
| `hsdes_tenants`  | list    | Filter by tenant (e.g., `"server_platf"`, `"central_firmware"`)        |

**Product codes**:

| Code | Product         |
| ---- | --------------- |
| COR  | Coral Rapids    |
| DMR  | Diamond Rapids  |
| GNR  | Granite Rapids  |
| SPR  | Sapphire Rapids |
| BHS  | Birchstream     |

**Response structure**:

- `hsd_article_data.article_text` — full article text (returned when `extract_hsd_id=true` matches an ID)
- `results.{source}.data[]` — array of search results, each with `id`, `title`, `description`, `comments`, `domain`, `component`, `status`

**General usage patterns**:

- **Exact article lookup**: Set `query` to the HSD ID, `extract_hsd_id=true`, `retrieve_k=1`
- **Keyword / semantic search**: Set `query` to relevant keywords; optionally filter by `data_sources`, `design_items`, or `hsdes_tenants`
- **Discovery before batch analysis**: Use keyword search with higher `retrieve_k` to surface related articles, then let the user confirm scope with `choose` before iterating

---

## Available App Providers

These three providers are registered on the MCP server for all skills. Use them at the appropriate decision points in any skill workflow.

### Approval (`request_approval`)

**Purpose**: Add a human-in-the-loop confirmation gate before taking any action that is hard to reverse or has broad impact (e.g., writing files, triggering downstream workflows, exporting data).

**Registered tool**:

| Tool               | Type  | Description                                                                                     |
| ------------------ | ----- | ----------------------------------------------------------------------------------------------- |
| `request_approval` | Model | Shows an approval card with Approve/Reject buttons; sends the user's decision back as a message |

**Usage pattern**: Call `request_approval` with a `summary` (and optional `details`). The LLM must stop and wait for the `"I selected:"` response before proceeding.

```python
request_approval(
    summary="Export 12 HSD findings to CSV and write to workspace",
    details="This will overwrite any existing hsd_security_analysis.csv file.",
    title="Confirm Export",
    approve_text="Export",
    approve_variant="default",    # "default" | "destructive" | "success" | "info"
    reject_text="Cancel",
)
```

> **Note**: Approval is an advisory gate, not a hard enforcement mechanism. For security-critical enforcement, implement approval logic server-side in your tool implementations.

**When to use**:

- Before writing any file to the workspace — always pass the full intended file path in `details`
- Before triggering a batch run with a large scope (e.g., >10 items)
- Whenever the user should explicitly confirm an irreversible or high-impact action

---

### Choice (`choose`)

**Purpose**: Present the user with a set of clickable options instead of asking for free-text input. The selection flows back into the conversation as a structured `"I selected:"` message.

**Registered tool**:

| Tool     | Type  | Description                                                                           |
| -------- | ----- | ------------------------------------------------------------------------------------- |
| `choose` | Model | Shows a card with one button per option; sends the user's selection back as a message |

**Usage pattern**: Call `choose` with a `prompt` and a list of `options`. The LLM must stop and wait for the `"I selected:"` response before proceeding.

```python
choose(
    prompt="Which articles should be included in the batch analysis?",
    options=["All results", "HIGH/CRITICAL only", "Let me filter manually"],
    title="Select Analysis Scope",  # optional card heading
)
```

**When to use**:

- Before starting a batch run when the scope isn't explicit — do not assume, always ask
- When the user needs to select between analysis modes, filter criteria, or output formats
- As a branching point anywhere in a workflow where multiple valid paths exist

---

### Generative UI (`generate_prefab_ui`, `search_prefab_components`)

**Purpose**: Let the LLM write Prefab Python code at runtime to render streaming, interactive visualizations — charts, tables, cards — directly in the UI.

**Registered tools**:

| Tool                       | Type | Description                                                                                             |
| -------------------------- | ---- | ------------------------------------------------------------------------------------------------------- |
| `generate_prefab_ui`       | Tool | Accepts Python code using Prefab components, executes in a Pyodide sandbox, streams the rendered result |
| `search_prefab_components` | Tool | Lets the LLM discover available Prefab components before writing code                                   |

**Usage pattern**: Optionally call `search_prefab_components` first to discover components, then call `generate_prefab_ui` with a `code` argument (Prefab Python) and a `data` argument for real data from the conversation.

> **CRITICAL — data injection model**: Each key in the `data=` dict is injected as a **separate top-level variable** in the sandbox. A dict passed as `data={"chart": ..., "rows": ...}` makes `chart` and `rows` available as globals — **not** a variable called `data`. Never write `data["chart"]` or `data["rows"]` in the code string; write `chart` and `rows` directly. If you do not pass `data=`, define all values inline in the code string instead.

```python
generate_prefab_ui(
    code="""
from prefab_ui.components import Column, Heading, Table
from prefab_ui.components.charts import BarChart, ChartSeries
from prefab_ui.app import PrefabApp

with PrefabApp() as app:
    with Column(gap=4):
        Heading("Results by Severity")
        BarChart(data=chart, series=[ChartSeries(data_key="count")], x_axis="severity")
        Table(data=rows, columns=["ID", "Max Severity", "Verdict", "Rationale"])
""",
    data={"chart": severity_counts, "rows": findings_rows}
)

generate_prefab_ui(
    code="""
from prefab_ui.components import Column, Heading, Table
from prefab_ui.components.charts import BarChart, ChartSeries
from prefab_ui.app import PrefabApp

chart = [{"severity": "HIGH", "count": 3}, {"severity": "CRITICAL", "count": 1}]
rows  = [{"ID": "12345", "Max Severity": "CRITICAL", "Verdict": "YES", "Rationale": "..."}]

with PrefabApp() as app:
    with Column(gap=4):
        Heading("Results by Severity")
        BarChart(data=chart, series=[ChartSeries(data_key="count")], x_axis="severity")
        Table(data=rows, columns=["ID", "Max Severity", "Verdict", "Rationale"])
"""
)

```

**When to use**:

- After analysis is complete and structured data is ready to pass as `data=` — do not call speculatively
- Prefer over plain markdown tables when the data set has more than 5 items or when the user asks for a visual summary
- For rendering comparison cards, severity distribution charts, or findings tables

> **Requirements**: Requires `fastmcp[apps]` (installs `prefab-ui`). Only the Python standard library and Prefab components are available in the sandbox — external packages (NumPy, pandas) are not supported.

---

## Interact Pattern

Use the app providers at the right decision points in any skill workflow to keep the user in control without requiring free-text input:

| Situation                                          | Tool                 | What to do                                                               |
| -------------------------------------------------- | -------------------- | ------------------------------------------------------------------------ |
| User needs to narrow scope before a batch run      | `choose`             | Offer: "All results", "HIGH/CRITICAL only", "Let me filter manually"     |
| User needs to select output format                 | `choose`             | Offer: "Visual chart (Generative UI)", "Detailed markdown", "CSV export" |
| User needs to pick a filter (product, severity...) | `choose`             | Offer the relevant enumerated values as options                          |
| About to write any file to the workspace           | `request_approval`   | Show filename, row count, and full destination path in `details`         |
| About to trigger a large batch run (>10 items)     | `request_approval`   | Show estimated scope and confirm before proceeding                       |
| Analysis is complete with >5 results               | `generate_prefab_ui` | Render severity distribution chart and findings/results table            |
| A single item result card is requested             | `generate_prefab_ui` | Render a styled card with key fields, badge, and verdict                 |

**Rules** (apply to every skill that uses these providers):

- Always call `choose` **before** starting a batch run when scope isn't explicit in the user's request.
- Always call `request_approval` **before** writing any file to the workspace.
- Call `generate_prefab_ui` only **after** analysis is complete and `data=` is ready.
- Wait for the `"I selected:"` response from both `choose` and `request_approval` before taking the next action.
- Never batch multiple `choose` or `request_approval` calls together — one gate at a time.
