---
name: hsd-security-analysis
description: Intel hardware security domain expertise for analyzing HSD articles — vulnerability identification, severity assessment, threat model evaluation, and security recommendations.
---

# HSD Security Analysis

## Domain

This skill provides expertise in Intel hardware/firmware security for analyzing HSDES (Hardware Security Design) articles. It covers vulnerability identification, severity classification, threat model assessment, and security recommendations across Intel's silicon, firmware, and platform security domains.

## When to Use

Use this skill when the user's request involves any of the following:

- Analyzing an HSD article for security vulnerabilities
- Assessing whether a hardware/firmware change requires a formal threat model
- Identifying security risks in platform firmware, silicon features, or boot chain changes
- Reviewing HSD articles for compliance with Intel security practices
- Comparing security posture across multiple HSD articles
- Summarizing security findings from HSD data
- Any question about Intel hardware security concepts (TEE, SMM, secure boot, side-channels, etc.)

## Available MCP Tools

> Full documentation for **Unified Vector Search**, **Approval**, **Choice**, and **Generative UI** is in [`core/SKILL.md`](../core-dka/SKILL.md). The sections below cover the HSD-specific tool and usage examples only.

### 1. Unified Vector Search (`Search_mcp_unified_vector_search`)

See [`core/SKILL.md`](../core-dka/SKILL.md) for full parameter reference, product code table, and response structure.

**HSD-specific usage examples**:

```python
# Retrieve a full article by ID
Search_mcp_unified_vector_search(query="22016029995", extract_hsd_id=True, retrieve_k=1)
# → hsd_article_data.article_text contains the full article

# Find related security HSDs by keyword
Search_mcp_unified_vector_search(
    query="SMM handler DMA buffer firmware",
    data_sources="hsdes_bug",
    design_items=["GNR"],
    hsdes_tenants=["server_platf"],
    retrieve_k=10,
)

# Broad discovery before a batch run (present results → use choose to confirm scope)
Search_mcp_unified_vector_search(
    query="secure boot ACM Coral Rapids",
    data_sources="hsdes_feature",
    design_items=["COR"],
    retrieve_k=20,
)
```

### 2. Security Requirements Agent (`Agents_mcp_security_req_agent_stream`)

**Purpose**: Run a comprehensive server-side security analysis on an HSD article.

**Parameters**: `HSD_ID` — the HSDES article ID to analyze.

**Response**: Streaming text containing a detailed security requirements analysis covering applicable security domains, identified risks, and recommendations.

**When to use**: Use the Security Requirements Agent when analyzing a **single HSD ID**. It provides a comprehensive server-side security assessment with full context for that article.

**When to combine with Unified Vector Search**: When the user wants to find **similar HSD IDs** and understand the **security impact across related articles**, use Unified Vector Search first to discover related HSDs (via keyword or semantic search), then run the Security Requirements Agent on each relevant HSD ID to get detailed security analysis. This combined approach gives both breadth (finding related articles) and depth (security assessment per article).

### 3. Approval, Choice, and Generative UI

These three app providers are shared across all DKA skills. Full documentation — tool signatures, usage patterns, configuration options, and interaction rules — is in [`core/SKILL.md`](../core-dka/SKILL.md).

**HSD-specific usage notes**:

- Use `choose` to let the user pick analysis scope (all HSDs vs. HIGH/CRITICAL only) or output format (visual / markdown / CSV) before starting a batch run.
- Use `request_approval` before writing any CSV export to the workspace. Always include the target filename and row count in `details`.
- Use `generate_prefab_ui` after batch analysis to render a severity distribution bar chart and a per-HSD findings table. Prefer it over markdown tables when analyzing more than 5 HSDs.

---

## Security Domain Knowledge

Intel hardware security spans multiple interconnected domains. When analyzing HSD articles, evaluate the content against these domains based on what the article references. Not all domains apply to every article — match based on the technical content present.

### Severity Framework

Findings are classified by severity — use this to prioritize and communicate risk:

| Severity     | Meaning                                                                                    | Examples                                                                     |
| ------------ | ------------------------------------------------------------------------------------------ | ---------------------------------------------------------------------------- |
| **CRITICAL** | Exploitable vulnerability that breaks a trust boundary or enables arbitrary code execution | Boot chain bypass, SMM escape, TEE key exposure, buffer overflow in firmware |
| **HIGH**     | Significant security weakness requiring remediation before production                      | IOMMU gaps, missing lock bits, debug port exposure, weak key management      |
| **MEDIUM**   | Security concern that should be addressed but has limited exploitability                   | Memory map config risk, fuse misconfiguration, timing info leakage           |
| **LOW**      | Minor observation with minimal security impact                                             | Topology discovery info, boot timing data exposure                           |

### Security Domains

The following domains should be evaluated when analyzing HSD articles. Each domain includes the concepts to look for and what constitutes a finding:

1. **Memory Safety & DMA** — Buffer overflows, use-after-free, integer overflows, DMA race conditions, IOMMU mapping gaps, memory map misconfigurations
2. **Trusted Execution Environments (TDX/SGX/SEAM/TME)** — TEE register access control, trust module integrity, encryption key management, TD migration, interrupt injection, epoch/versioning
3. **SMM/SMI/SMRAM** — SMM attack surface (ring -2), SMI handler vulnerabilities, SMRAM lock enforcement, PRM privilege transitions
4. **Firmware Integrity & Boot Chain** — Secure/measured boot, ACM trust anchor, flash/SPI protection, microcode integrity, rollback prevention, runtime updates
5. **Speculative Execution & Side-Channels** — Spectre/Meltdown, transient execution, timing attacks, cache side-channels, known microarchitectural vulnerabilities (MDS/TAA/L1TF)
6. **Access Control & Privilege** — Privilege escalation, lock bit enforcement, SAI/RAC/WAC policies, CPL-based access
7. **Platform Interfaces (eSPI/BMC/GPIO)** — eSPI validation, BMC security posture, GPIO signal injection risks
8. **Debug & Manufacturing** — JTAG/DCI/ITP exposure, fuse overrides, strap security
9. **Cryptography & Key Management** — Key lifecycle, cleartext exposure, entropy/RNG, attestation/PCR measurements
10. **Reset & Power State** — State leakage across resets, reset glitch attacks
11. **Cache (NEM/LLC)** — No-eviction mode integrity, cache poisoning, coherency attacks
12. **Paging & Address Translation** — Page table manipulation, EPT violations/bypass
13. **Multi-Socket & Interconnect** — Inter-CBB authentication, UPI traffic integrity
14. **PCIe/CXL/IO** — Re-timer interposition, IDE misconfiguration, config space access, unused IO exposure
15. **RAS & Error Handling** — Error injection abuse, viral error propagation
16. **Virtualization (VMX/VT-x)** — VM escape, VMX control misconfiguration
17. **Power Management** — C-state data leakage, voltage/frequency fault injection (Plundervolt)
18. **Supply Chain** — Third-party firmware trust, OpROM verification
19. **Denial of Service** — Triggerable deadlocks, resource exhaustion
20. **Rollback & Anti-Replay** — Downgrade attacks, replay protection, monotonic counters

For detailed keyword patterns and descriptions for each domain, see the `reference.md` supporting file.

## Execution Plan (Required)

Before performing any analysis, **always present an execution plan** to the user. This gives visibility into what will happen and lets the user course-correct before tool calls are made.

### Format

Present the plan as a numbered list with a brief summary line:

```
**Plan:** Analyze HSD 22016029995 for security vulnerabilities

1. Retrieve article content via Unified Vector Search (extract_hsd_id)
2. Run Security Requirements Agent for deep analysis
3. Scan article against 20 security domains
4. Assess threat model requirement and produce verdict
5. Present findings with severity breakdown
```

### Rules

- **Always show the plan before the first tool call.** Do not silently start retrieving or analyzing.
- For **single HSD analysis**: List the Retrieve → Scan → Assess → Present steps.
- For **multi-HSD or batch analysis**: List discovery, per-HSD iteration, and output format.
- For **comparison requests**: List which HSDs will be retrieved, that both will be analyzed in parallel, and the comparison output format.
- For **search-then-analyze flows**: Note that search results will be shown first for user selection before running analysis.
- Keep it concise — 3–7 steps max. One line per step.
- If the user has already seen a plan (e.g., from a previous turn in the same flow), do not repeat it.

### Examples

**Single HSD:**

```
**Plan:** Security analysis of HSD 22016029995

1. Retrieve article content and run Security Requirements Agent (parallel)
2. Scan against security domain taxonomy
3. Assess threat model requirement
4. Present findings with severity breakdown and verdict
```

**Batch / search-based:**

```
**Plan:** Find and analyze firmware-related HSDs on Granite Rapids

1. Search for HSDs via Unified Vector Search (keywords: firmware, boot, GNR)
2. Use Choice to let user confirm analysis scope (all results vs. HIGH/CRITICAL only)
3. Run Security Requirements Agent on each selected HSD
4. Produce per-HSD findings; render severity chart via Generative UI
5. Request Approval before writing CSV to workspace
```

**Comparison:**

```
**Plan:** Compare HSDs 22016029995 and 22019570414

1. Retrieve both articles and run Security Requirements Agent (parallel)
2. Scan both against security domain taxonomy
3. Render side-by-side comparison card via Generative UI
4. Present verdict and severity badges
```

**Interactive single HSD with output selection:**

```
**Plan:** Analyze HSD 22016029995 — user-selected output format

1. Run Security Requirements Agent and scan against domains
2. Use Choice to ask user: Summary card / Detailed markdown / CSV export
3. Render output in chosen format (Generative UI for visual, markdown for text)
4. Request Approval if user selects CSV export
```

## Analysis Patterns

These are composable building blocks — combine them based on what the user needs:

### Retrieve

- **Single HSD ID**: Use the Security Requirements Agent (`Agents_mcp_security_req_agent_stream`) directly with the HSD ID. No need for vector search.
- **Similar / related HSDs + security impact**: First use Unified Vector Search (`Search_mcp_unified_vector_search`) with security-relevant keywords or an HSD ID to discover related articles, then run the Security Requirements Agent on each discovered HSD ID for detailed security analysis.

### Interact

See [`core/SKILL.md`](../core-dka/SKILL.md) for the full Interact pattern, decision table, and rules that apply to all DKA skills.

**HSD-specific decision points**:

| Situation                              | Tool                 | Options to offer                                               |
| -------------------------------------- | -------------------- | -------------------------------------------------------------- |
| Scope unclear before a batch HSD run   | `choose`             | "All results", "HIGH/CRITICAL only", "Let me filter manually"  |
| Output format selection after analysis | `choose`             | "Visual chart", "Detailed markdown", "CSV export", "All three" |
| Product family filter needed           | `choose`             | "GNR", "DMR", "COR", "SPR", "BHS" (or others from the article) |
| About to write CSV to workspace        | `request_approval`   | Include filename, row count, full path in `details`            |
| Batch run >10 HSDs                     | `request_approval`   | Show HSD count and estimated run time before confirming        |
| >5 HSDs analyzed, findings ready       | `generate_prefab_ui` | Severity bar chart + per-HSD findings table                    |
| Single HSD summary card requested      | `generate_prefab_ui` | Card with severity badge, matched domains, and verdict         |

### Scan

Match article content against the security domains listed above. Identify which domains are relevant based on keywords and technical content in the article. For each relevant domain, determine if the article describes a vulnerability, a security-sensitive change, or a benign modification.

### Assess

Evaluate overall risk and determine if formal action is required.

#### Decision Criteria

- **Formal threat model required (YES)** — All of these must be true:
  - The change introduces or modifies a security/trust boundary or authentication/authorization mechanism
  - The change exposes new attack surfaces (network interfaces, APIs, hardware interfaces, IPC)
  - The change handles sensitive data (cryptographic keys, credentials, PII, firmware, privileged state)
  - The risk cannot be adequately mitigated by standard secure coding practices alone

- **Formal threat model not required (NO)** — Any of these is true:
  - Bug fix, performance improvement, refactor, or documentation update with no security-relevant behavioral change
  - Change is isolated within an already-modeled trust boundary with no new external exposure
  - Low or negligible risk with no new threat vectors
  - Existing controls already cover identified risks without modification

- **Inconclusive** — Key context is missing (component type, data sensitivity, deployment environment), or the article is too vague to make a confident determination.

Do NOT return YES simply because security is mentioned, because the analysis contains precautionary language, or because a theoretical risk exists. Require concrete evidence of new, unmitigated attack surface.

#### Standardized Verdict Output

Always conclude the assessment with a structured verdict block in exactly this format. This format is required for automated parsing by downstream batch pipelines:

```
VERDICT: YES | NO | INCONCLUSIVE
Reasoning: <2-3 sentences citing specific evidence from the analysis>
Scope: <assets, threat actors, attack surfaces>              ← ONLY if VERDICT is YES
Methodology: <e.g. STRIDE, attack tree>                      ← ONLY if VERDICT is YES
Missing Information: <what specific details are needed>      ← ONLY if VERDICT is INCONCLUSIVE
```

Rules:

- The `VERDICT:` line must contain exactly one of `YES`, `NO`, or `INCONCLUSIVE`. No other values are accepted.
- `Reasoning:` is always required regardless of verdict.
- `Scope:` and `Methodology:` lines must only appear when the verdict is `YES`.
- `Missing Information:` must only appear when the verdict is `INCONCLUSIVE`.
- Do not wrap the verdict block in markdown code fences — emit it as plain text at the end of your response.

### Compare

When analyzing multiple HSD articles, cross-reference findings to identify patterns — shared vulnerability domains, escalating risk across related changes, or gaps in coverage.

### Summarize

Condense findings into a structured report:

- Overall severity (highest finding severity)
- Count of findings per severity level
- Key findings with category and description
- Recommendation (threat model needed / standard review sufficient / more information needed)

**Output format selection**: After analysis, use `choose` to ask the user how they want the summary delivered:

```
choose(
    prompt="How would you like the findings summary?",
    options=["Visual chart (Generative UI)", "Detailed markdown report", "CSV export", "All three"],
    title="Select Output Format",
)
```

- **Visual chart**: Use `generate_prefab_ui` to render a severity distribution bar chart plus a findings table. Preferred when analyzing >5 HSDs.
- **Detailed markdown**: Emit the structured text report inline in the chat response.
- **CSV export**: Use `request_approval` with filename and row count before writing the file.

Use this single-line prefix format for each HSD so results are parsable by automated pipelines:

```
[<SEVERITY>] HSD <ID> — <N> finding(s):
  1. [<SEVERITY>] <Category>: <Description>
  2. [<SEVERITY>] <Category>: <Description>
```

If no vulnerabilities are found: `[NO VULNS] HSD <ID>: No security vulnerabilities identified from available article data.`
If insufficient data: `[NO DATA] HSD <ID>: Insufficient article data for analysis.`

### Batch Analysis

When the user asks to analyze multiple HSD IDs at once, follow this full interactive flow:

1. **Discover**: If the user provides a topic or single HSD ID and wants related articles, use Unified Vector Search to find similar HSDs first. Show the result count before proceeding.

2. **Confirm scope** (if not explicit): Use `choose` to let the user select the analysis scope before iterating:

   ```
   choose(
       prompt=f"Found {n} HSDs. Which articles should be analyzed?",
       options=["All results", "HIGH/CRITICAL severity hits only", "Let me filter manually"],
       title="Analysis Scope",
   )
   ```

   Wait for the `"I selected:"` response before starting iteration.

3. **Iterate**: Run the Security Requirements Agent on each HSD ID individually using the Retrieve → Scan → Assess flow.

4. **Progress**: When processing more than 5 HSDs, report progress after each article (e.g., `"Analyzed 3/10: HSD 22016029995 — CRITICAL, 4 findings"`).

5. **Visualize**: After all articles are analyzed, use `generate_prefab_ui` to render a severity distribution chart and findings table:

   > **Reminder**: `data={"chart": ..., "rows": ...}` injects `chart` and `rows` as top-level variables — reference them directly, not as `data["chart"]` / `data["rows"]`.

   ```python
   generate_prefab_ui(
       code="""
   from prefab_ui.components import Column, Heading, Table
   from prefab_ui.components.charts import BarChart, ChartSeries
   from prefab_ui.app import PrefabApp

   with PrefabApp() as app:
       with Column(gap=4):
           Heading("HSD Batch Security Analysis")
           BarChart(data=chart, series=[ChartSeries(data_key="count")], x_axis="severity")
           Table(data=rows, columns=["HSD ID", "Max Severity", "Verdict", "Rationale"])
   """,
       data={"chart": severity_counts, "rows": findings_rows}
   )
   ```

6. **Output format**: Use `choose` to ask whether to also export to CSV:

   ```
   choose(
       prompt="Analysis complete. Export results to CSV?",
       options=["Yes, save CSV to workspace", "No, markdown summary is enough"],
       title="Export",
   )
   ```

7. **CSV export** (if selected): Use `request_approval` before writing the file:
   ```
   request_approval(
       summary=f"Write {n} HSD results to hsd_security_analysis_<timestamp>.csv",
       details="File will be saved to the workspace root. Existing file will be overwritten.",
       title="Confirm CSV Export",
       approve_text="Save File",
       approve_variant="default",
       reject_text="Cancel",
   )
   ```
   Only write the file after receiving an Approve response.

**CSV format**:

```csv
HSD ID,Max Severity,Vulnerability Domains,Threat Model Required,Brief Rationale
22016029995,CRITICAL,"Memory Safety, SMM",YES,New SMM handler exposes unvalidated DMA buffer
22016030001,LOW,Topology,NO,Read-only enumeration change no new attack surface
```

**Column definitions**:

- **HSD ID**: The HSDES article identifier.
- **Max Severity**: The highest severity finding (CRITICAL / HIGH / MEDIUM / LOW / NONE).
- **Vulnerability Domains**: Comma-separated list of matched security domains from the taxonomy (wrapped in quotes if multiple).
- **Threat Model Required**: The `VERDICT` value (YES / NO / INCONCLUSIVE).
- **Brief Rationale**: One-sentence justification for the verdict. Avoid commas in this field or wrap in quotes.

**File delivery**: Use a descriptive filename like `hsd_security_analysis_<timestamp>.csv` and inform the user of the full file path after writing.
