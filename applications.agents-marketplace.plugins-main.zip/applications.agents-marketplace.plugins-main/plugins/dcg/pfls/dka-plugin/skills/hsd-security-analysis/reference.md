# Security Vulnerability Taxonomy

Detailed keyword patterns and finding descriptions for each security domain. Use this reference when scanning HSD article content for security relevance.

## 1. Memory Safety & DMA

| Finding                     | Severity | Trigger Keywords                                                                                  | Description                                                                                                                        |
| --------------------------- | -------- | ------------------------------------------------------------------------------------------------- | ---------------------------------------------------------------------------------------------------------------------------------- |
| DMA Race Condition          | CRITICAL | dma + (race, concurrent, replicat, migrat, parallel)                                              | Concurrent DMA operations during memory migration/replication could expose stale data if drain/synchronization is incomplete       |
| IOMMU Mapping Gap           | HIGH     | iommu, vt-d, dmar                                                                                 | Improper IOMMU/VT-d mapping transitions could create windows for DMA-based memory access attacks                                   |
| DMA Transaction Abort       | HIGH     | dma + (abort, timeout, hang, deadlock)                                                            | DMA transaction abort/timeout handling may leave memory regions in an inconsistent state accessible to attackers                   |
| Memory Map Misconfiguration | CRITICAL | (memory map, mmap, address decode, tolm, tohm, mmcfg) + (overlap, gap, hole, conflict, misconfig) | Memory map overlaps or gaps in address decode could create unprotected regions exploitable for data exfiltration or code injection |
| Memory Map Configuration    | MEDIUM   | memory map, mmap, address decode, memory range, tolm, tohm, mmcfg                                 | Memory map/address decode changes require careful validation to prevent creation of unprotected memory windows                     |
| Buffer Overflow             | CRITICAL | buffer overflow, out of bound, out-of-bound, oob, heap overflow, stack overflow                   | Potential buffer overflow/out-of-bounds access could enable arbitrary code execution or privilege escalation in firmware           |
| Memory Corruption           | HIGH     | uninitialized, uninit, use after free, use-after-free, dangling pointer, stale pointer            | Uninitialized memory usage or use-after-free conditions could leak sensitive data or enable code execution                         |
| Integer Overflow            | HIGH     | integer overflow, integer underflow, truncat, wraparound                                          | Integer overflow/underflow could lead to incorrect size calculations, resulting in buffer overflows or logic bypasses              |

## 2. Trusted Execution Environments (TDX, SGX, SEAM, TME)

**Trigger**: tdx, tee, seam, sgx, mktme, tme, td guest, td-guest

| Finding                      | Severity | Additional Keywords                              | Description                                                                                                                         |
| ---------------------------- | -------- | ------------------------------------------------ | ----------------------------------------------------------------------------------------------------------------------------------- |
| TEE Register Access Control  | HIGH     | register, msr, control, program, config          | TEE-designated control registers/MSRs must enforce strict access policies; bypass could allow unauthorized configuration changes    |
| Trust Module Integrity       | CRITICAL | module, p-seam, pseam                            | TDX/P-SEAM module integrity is the root of trust; compromise undermines the entire confidential computing chain                     |
| TEE Encryption Key Exposure  | CRITICAL | key, keyid, key_id, encrypt                      | TME/MKTME/TDX encryption key management flaws could expose VM memory contents, breaking confidentiality guarantees                  |
| TD Migration Security        | HIGH     | migration, live migrat, td migrat                | TD migration must preserve confidentiality and integrity; gaps during migration could expose guest secrets or allow state tampering |
| TEE Interrupt Injection      | HIGH     | interrupt, posted interrupt, ipi, nmi, exception | Improper interrupt/exception handling in TEE context could allow host-to-TD attacks or information leakage through side channels    |
| TEE Version/Epoch Management | MEDIUM   | epoch, version, revoc                            | TEE module versioning and epoch management must prevent rollback to vulnerable versions                                             |

## 3. SMM / SMI / SMRAM

| Finding                   | Severity | Trigger Keywords                                   | Description                                                                                                                |
| ------------------------- | -------- | -------------------------------------------------- | -------------------------------------------------------------------------------------------------------------------------- |
| SMM Attack Surface        | CRITICAL | smm, smi, smram, smbase, system management mode    | SMM-dependent operations are high-privilege (ring -2) targets; vulnerabilities in SMI handlers enable privilege escalation |
| SMI Handler Vulnerability | CRITICAL | smm + (callout, callback, handler)                 | SMI handlers/callouts executing outside SMRAM risk TOCTOU attacks if they reference non-SMRAM memory                       |
| SMRAM Lock Enforcement    | HIGH     | smm + (lock, smrr, tseg)                           | SMRAM range locks (SMRR/TSEG) must be properly configured and locked before OS handoff to prevent unauthorized SMM access  |
| PRM Privilege Reduction   | HIGH     | prm, platform runtime mechanism, runtime mechanism | Transitioning from SMM to OS-level PRM handlers exposes error registers at lower privilege, increasing attack surface      |

## 4. Firmware Integrity & Boot Chain

| Finding                         | Severity | Trigger Keywords                                                      | Description                                                                                                                    |
| ------------------------------- | -------- | --------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------ |
| Boot Chain Integrity            | CRITICAL | secure boot, verified boot, measured boot, boot guard, btg            | Secure/measured boot chain modifications must not weaken the chain of trust from ACM through firmware to OS loader             |
| Boot Security Bypass            | CRITICAL | (secure boot) + (bypass, skip, disable, workaround)                   | Any mechanism to bypass/disable secure boot verification creates a critical vulnerability allowing unsigned code execution     |
| ACM Trust Anchor                | CRITICAL | acm, authenticated code module, startup acm, sinit                    | ACM is the hardware root of trust; any vulnerability in ACM execution or verification compromises the entire platform security |
| ACM Single-Thread Trust         | HIGH     | acm + (single thread, bsp, pbsp)                                      | All trust derives from ACM execution on BSP/PBSP; compromise of this single point undermines the verified boot chain           |
| Flash Storage Protection        | HIGH     | flash, spi, ifwi, bios update, firmware volume, fv                    | SPI/flash firmware images must be protected against unauthorized writes; lack of write protection enables persistent implants  |
| Flash TOCTOU                    | CRITICAL | flash + (race, toctou, time-of-check)                                 | Time-of-check-time-of-use race on flash reads could allow swapping verified firmware with malicious code                       |
| Microcode Patch Integrity       | HIGH     | (ucode, microcode, pcode) + (patch, update, load, revision)           | Microcode/pcode patches must be cryptographically signed and verified; unsigned patches create code injection vectors          |
| Microcode Rollback              | CRITICAL | (ucode, microcode, pcode) + (rollback, downgrade, revert)             | Microcode rollback to vulnerable versions must be prevented via anti-rollback mechanisms                                       |
| Firmware Patch Space Exhaustion | MEDIUM   | patch space, fw update, longevity, 10 year, 12 year, end of life, eol | Extended lifecycle requirements risk exhausting FW patch space, leaving platforms unable to deploy critical security fixes     |
| Runtime Update Integrity        | HIGH     | seamless, runtime update, live update, capsule update                 | Seamless/live firmware updates must be atomically verified; partial or corrupted updates could leave the platform insecure     |

## 5. Speculative Execution & Side-Channels

| Finding                         | Severity | Trigger Keywords                                                        | Description                                                                                                 |
| ------------------------------- | -------- | ----------------------------------------------------------------------- | ----------------------------------------------------------------------------------------------------------- |
| Speculative Execution Attack    | CRITICAL | spectre, meltdown, speculative, transient execution, branch predict     | Speculative/transient execution vulnerabilities could leak sensitive data across trust boundaries           |
| Side-Channel Attack             | HIGH     | side channel, side-channel, timing attack, cache timing, power analysis | Side-channel information leakage (timing, cache, power) could reveal cryptographic keys or sensitive data   |
| Timing Information Leakage      | LOW      | boot time, fpdt, instrumentation                                        | Boot timing data (FPDT) could reveal security feature initialization durations, aiding timing-based attacks |
| ACPI Table Integrity            | MEDIUM   | (boot time, fpdt) + (acpi, table)                                       | ACPI tables not integrity-verified could be modified to mask malicious boot behavior                        |
| Known Microarchitectural Attack | CRITICAL | mds, taa, l1tf, zombieload, ridl, fallout, srbds                        | References to known microarchitectural vulnerabilities require mitigation verification                      |

## 6. Access Control & Privilege Escalation

| Finding                             | Severity | Trigger Keywords                                                                       | Description                                                                                                       |
| ----------------------------------- | -------- | -------------------------------------------------------------------------------------- | ----------------------------------------------------------------------------------------------------------------- |
| Privilege Escalation                | CRITICAL | privilege escalat, privesc, ring0, ring 0, ring-0, kernel mode                         | Potential privilege escalation from lower to higher privilege ring could allow unauthorized system control        |
| Lock Bypass                         | CRITICAL | (lock bit, lock register, write once, lock_ctrl) + (bypass, race, before lock, unlock) | Lock bit/register bypass could allow modification of security-critical configuration after it should be immutable |
| Lock Register Configuration         | MEDIUM   | lock bit, lock register, write once, write-once, lock_ctrl                             | Lock registers must be properly set before OS handoff; late or missing locks leave security settings modifiable   |
| Security Attribute Misconfiguration | HIGH     | sai, security attribute, access policy, rac, wac                                       | SAI/RAC/WAC policy misconfiguration could allow unauthorized register or memory access                            |
| CPL-Based Access Violation          | HIGH     | (cpl, current privilege level, ring3, ring 3) + (access, read, write, control)         | Improper CPL enforcement could allow user-mode access to privileged resources                                     |

## 7. Platform Interfaces (eSPI / BMC / GPIO)

| Finding                 | Severity | Trigger Keywords                                                  | Description                                                                                                        |
| ----------------------- | -------- | ----------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------ |
| eSPI Interface Security | HIGH     | espi, e-spi                                                       | eSPI bus transactions must be validated; unauthenticated eSPI messages could inject false platform events          |
| BMC Security            | HIGH     | bmc, baseboard management, ipmi, redfish                          | BMC has high-privilege platform access; compromised BMC can modify firmware, read memory, and control power states |
| GPIO Signal Injection   | MEDIUM   | (gpio, vgpio, pin mux) + (security, strap, signal, inject, spoof) | GPIO/vGPIO signal paths could be exploited to inject false triggers if not properly authenticated or filtered      |

## 8. Debug & Manufacturing Interfaces

| Finding                 | Severity | Trigger Keywords                                                     | Description                                                                                                     |
| ----------------------- | -------- | -------------------------------------------------------------------- | --------------------------------------------------------------------------------------------------------------- |
| Debug Port Exposure     | HIGH     | jtag, dci, itp, debug port, trace hub                                | Hardware debug interfaces must be disabled in production; enabled debug features create backdoor access paths   |
| Fuse Override/Bypass    | CRITICAL | (fuse, softfuse, hard fuse, otp) + (debug, enable, override, bypass) | Debug fuse override or bypass enables attacker access to debug capabilities that should be permanently disabled |
| Fuse Configuration      | MEDIUM   | fuse, softfuse, hard fuse, otp                                       | Fuse/OTP settings define security posture; misconfigured fuses can weaken platform security permanently         |
| Strap Security Override | HIGH     | (strap, soft strap, softstrap) + (security, debug, override)         | Soft straps modifiable after manufacturing could override security-critical hardware configurations             |

## 9. Cryptography & Key Management

| Finding                      | Severity | Trigger Keywords                                                                                                 | Description                                                                                     |
| ---------------------------- | -------- | ---------------------------------------------------------------------------------------------------------------- | ----------------------------------------------------------------------------------------------- |
| Key Management Risk          | HIGH     | (secret, key, encrypt, decrypt, crypto, aes, rsa, sha, hmac) + (manage, store, generat, wrap, derive, provision) | Cryptographic key lifecycle must be secured; weak key management undermines all security        |
| Key Exposure                 | CRITICAL | (secret, key, encrypt, crypto) + (clear text, cleartext, plain text, plaintext, unencrypt, exposed)              | Cryptographic keys stored or transmitted in cleartext could be intercepted                      |
| Entropy/RNG Weakness         | HIGH     | (secret, key, crypto) + (random, entropy, rng, seed)                                                             | Insufficient entropy or weak RNG could produce predictable keys                                 |
| Attestation Gap              | HIGH     | attestation, measurement, pcr, tpm, quote                                                                        | Missing or incomplete platform measurements could allow boot in an unverified state             |
| Measurement Order Dependency | HIGH     | (attestation, pcr) + (extend, order, sequenc)                                                                    | PCR extend order changes could mask unauthorized firmware modifications from remote attestation |

## 10. Reset & Power State

| Finding             | Severity | Trigger Keywords                                                                                         | Description                                                                                                  |
| ------------------- | -------- | -------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------ |
| Reset State Leakage | HIGH     | (reset, warm reset, cold reset, power cycle, s3, s4, s5) + (state, persist, clear, retain, leak, surviv) | Sensitive state persisting across reset/power transitions could be extracted by attacker-forced reset cycles |
| Reset Glitch Attack | CRITICAL | (reset, power cycle) + (attack, glitch, fault inject, voltage)                                           | Power/reset glitching could skip security initialization, allowing boot into an unsecured state              |

## 11. Cache (NEM / LLC)

| Finding                  | Severity | Trigger Keywords                                      | Description                                                                                                         |
| ------------------------ | -------- | ----------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------- |
| NEM/Cache Integrity      | HIGH     | nem, no-eviction, no eviction, cache-as-ram, car, llc | No-Eviction Mode operates before DRAM init; cache corruption/eviction could silently modify executing firmware code |
| NEM Boundary Enforcement | MEDIUM   | (nem, no-eviction, cache-as-ram) + (oem, vendor)      | Shared NEM space between OEM and Intel code requires strict boundary enforcement                                    |
| Cache Coherency Attack   | HIGH     | cache poison, cache inject, cache line, snoop, mesi   | Cache coherency protocol manipulation could inject or modify data in-flight                                         |

## 12. Paging & Address Translation

| Finding              | Severity | Trigger Keywords                                                              | Description                                                                                     |
| -------------------- | -------- | ----------------------------------------------------------------------------- | ----------------------------------------------------------------------------------------------- |
| Paging Mode Security | HIGH     | paging, page table, cr3, cr4, la57, 5-level, 4-level, ept, nested paging      | Incorrect paging mode or page table manipulation could create exploitable address space layouts |
| EPT Violation/Bypass | CRITICAL | (ept, extended page table, nested paging, slat) + (violat, misconfig, bypass) | EPT/nested paging misconfiguration could allow VM escape or unauthorized host memory access     |

## 13. Multi-Socket & Interconnect

| Finding                       | Severity | Trigger Keywords                                                      | Description                                                                                                  |
| ----------------------------- | -------- | --------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------ |
| Inter-CBB Authentication      | HIGH     | multi-socket, multi socket, secondary cbb, remote init, pbsp          | Remote initialization between CBBs must be authenticated; unauthenticated channels enable firmware injection |
| Inter-Socket Traffic Exposure | MEDIUM   | (upi, interconnect, ktl, qpi) + (traffic, snoop, coheren, link train) | UPI/interconnect traffic should be integrity-protected to prevent interposition or eavesdropping             |

## 14. SIPI / AP Init

| Finding            | Severity | Trigger Keywords                                        | Description                                                                                                 |
| ------------------ | -------- | ------------------------------------------------------- | ----------------------------------------------------------------------------------------------------------- |
| SIPI Spoofing Risk | HIGH     | sipi, wait-for-sipi, wait for sipi, ap init, ap startup | Cores in Wait-for-SIPI state could be awakened by spoofed SIPI signals to execute malicious code pre-policy |

## 15. PCIe / CXL / IO

| Finding                  | Severity | Trigger Keywords                                              | Description                                                                                          |
| ------------------------ | -------- | ------------------------------------------------------------- | ---------------------------------------------------------------------------------------------------- |
| Re-timer Interposition   | HIGH     | (pcie, cxl) + (retimer, re-timer, redriver)                   | Third-party re-timers in PCIe/CXL paths could intercept or modify link traffic if not authenticated  |
| PCIe IDE/Integrity       | HIGH     | (pcie, cxl) + (ide, integrity, tee-io, selective_ide)         | PCIe IDE misconfiguration could expose device-to-host traffic to interception                        |
| PCIe Config Space Access | MEDIUM   | (pcie, cxl) + (bar, mmio, config space, cfg space)            | Improperly protected PCIe BAR/config space could allow unauthorized device reconfiguration           |
| Unused IO Exposure       | MEDIUM   | (pcie, cxl) + (unused, clock gate, disable, dormant, phantom) | Hardware-gated but not BIOS-disabled IO IPs could be reactivated, exposing additional attack surface |

## 16. RAS & Error Handling

| Finding                   | Severity | Trigger Keywords                                                            | Description                                                                                         |
| ------------------------- | -------- | --------------------------------------------------------------------------- | --------------------------------------------------------------------------------------------------- |
| Error Injection Abuse     | HIGH     | (mca, machine check, uncorrectable error) + (inject, poison, corrupt, fake) | Error injection capabilities must be restricted; unrestricted access enables DoS or data corruption |
| Error Handling DoS        | MEDIUM   | (mca, machine check) + (handler, panic, reboot, fatal)                      | Triggerable fatal machine check errors could be exploited for denial-of-service                     |
| Error Containment Failure | HIGH     | viral, viral error, containment, error propagat                             | Viral error propagation across system domains could cause cascading failures                        |

## 17. Topology & Enumeration

| Finding            | Severity | Trigger Keywords                                               | Description                                                                     |
| ------------------ | -------- | -------------------------------------------------------------- | ------------------------------------------------------------------------------- |
| Topology Spoofing  | HIGH     | (topology, discovery, enumerat) + (spoof, fake, inject, modif) | Spoofed platform topology could misdirect security policies to wrong components |
| Topology Discovery | LOW      | topology, discovery, enumerat                                  | Topology information should come from trusted hardware sources                  |

## 18. Power Management

| Finding                           | Severity | Trigger Keywords                                                                                       | Description                                                                                                             |
| --------------------------------- | -------- | ------------------------------------------------------------------------------------------------------ | ----------------------------------------------------------------------------------------------------------------------- |
| Power State Data Leakage          | MEDIUM   | (c-state, c6, pkg-c, idle, power gate) + (state, leak, persist, context, save, restore)                | CPU/package power state transitions may not properly clear sensitive register contents                                  |
| Voltage/Frequency Fault Injection | CRITICAL | (turbo, frequency, voltage, vr, plundervolt, clkscrew) + (inject, fault, glitch, undervolting, modify) | Software-controlled voltage/frequency manipulation could induce computational faults, breaking cryptographic operations |

## 19. Virtualization (VMX / VT-x)

| Finding              | Severity | Trigger Keywords                                                            | Description                                                                       |
| -------------------- | -------- | --------------------------------------------------------------------------- | --------------------------------------------------------------------------------- |
| VM Escape            | CRITICAL | (vmx, vt-x, vmcs, vmm, hypervisor, vm exit) + (escape, bypass, break out)   | VM escape vulnerability could allow guest-to-host privilege escalation            |
| VMX Control Security | HIGH     | (vmx, vt-x, vmcs, vmm, hypervisor) + (control, register, shadow, intercept) | VMX control register/shadow misconfiguration could weaken VM isolation boundaries |

## 20. Supply Chain & Third-Party

| Finding                    | Severity | Trigger Keywords                                                                                                | Description                                                                                                |
| -------------------------- | -------- | --------------------------------------------------------------------------------------------------------------- | ---------------------------------------------------------------------------------------------------------- |
| Third-Party Firmware Trust | HIGH     | (third party, 3rd party, third-party, vendor, supplier, oem blob) + (firmware, binary, blob, oprom, option rom) | Third-party firmware blobs/OpROMs may not be verified; malicious vendor code could run with high privilege |

## 21. Denial of Service

| Finding             | Severity | Trigger Keywords                                                                                       | Description                                                                           |
| ------------------- | -------- | ------------------------------------------------------------------------------------------------------ | ------------------------------------------------------------------------------------- |
| Denial of Service   | MEDIUM   | (deadlock, livelock, hang, watchdog, timeout) + (security, attack, exploit, trigger, malicious, force) | Triggerable deadlock/hang condition could be exploited for denial-of-service attacks  |
| Resource Exhaustion | MEDIUM   | resource exhaust, starvation, flood, infinite loop                                                     | Resource exhaustion or starvation conditions could be exploited for denial-of-service |

## 22. Information Disclosure

| Finding                    | Severity | Trigger Keywords                                                              | Description                                                                        |
| -------------------------- | -------- | ----------------------------------------------------------------------------- | ---------------------------------------------------------------------------------- |
| Information Disclosure     | HIGH     | information leak, info leak, information disclos, data leak                   | Information leakage could expose sensitive platform data, keys, or configuration   |
| MSR/CPUID Information Leak | MEDIUM   | (cpuid, model specific register, rdmsr, wrmsr) + (leak, expos, read, disclos) | Exposed MSR or CPUID values could reveal security feature status or internal state |

## 23. Rollback & Anti-Replay

| Finding                   | Severity | Trigger Keywords                                         | Description                                                                             |
| ------------------------- | -------- | -------------------------------------------------------- | --------------------------------------------------------------------------------------- |
| Rollback/Downgrade Attack | HIGH     | rollback, anti-rollback, replay, downgrade, version roll | Missing anti-rollback protections could allow downgrade to vulnerable firmware versions |
| Replay Attack Protection  | MEDIUM   | nonce, freshness, replay protect, monotonic counter      | Anti-replay mechanisms must be verified to prevent replay attacks                       |

## 24. Management Engine

| Finding                    | Severity | Trigger Keywords                                | Description                                                                                           |
| -------------------------- | -------- | ----------------------------------------------- | ----------------------------------------------------------------------------------------------------- |
| Management Engine Security | HIGH     | manageability, amt, me, csme, management engine | Intel ME/CSME has deep platform access; vulnerabilities could enable persistent, OS-invisible attacks |
