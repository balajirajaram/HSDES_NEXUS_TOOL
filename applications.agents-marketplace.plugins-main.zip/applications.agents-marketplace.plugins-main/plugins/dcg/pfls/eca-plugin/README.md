# ECA Plugin

ECA IP PE Analytics is an MCP-based solution that provides structured data access to Intel's Product Engineering (PE) data warehouse. It enables teams to query enterprise PE data sources — HSDES, Jira, OneBom (IBDS), and Atlas — using natural language or direct SQL, backed by a Snowflake data warehouse exposed via a secure API gateway.

## Version

**1.0.0**

## Features

[ECA IP PE Analytics MCP Server Wiki](https://wiki.ith.intel.com/spaces/dka/pages/4802222194/MCP+server+-+PE+ECA)

- Natural language (NL to SQL) queries via `ECA_IP_PE_ANALYTICS_CORTEX_AGENT`
- Direct SQL execution against the PE Snowflake database via `ECA_IP_PE_ANALYTICS_SQL_EXEC`
- Structured data access across HSDES, Jira, OneBom (IBDS), and Atlas
- Row-level security respecting your AGS-provisioned Snowflake roles

## Data Sources

| Data Source | Description |
|-------------|-------------|
| **HSDES** | Hardware/Software Design Engineering System |
| **Jira** | Project and issue tracking |
| **OneBom (IBDS)** | Bill of Materials data |
| **Atlas** | Product/platform metadata |

## Skills

### 1. eca-pe-analytics

**Purpose:** Query Intel Product Engineering structured data using natural language or direct SQL against the PE Snowflake database.

**When to use:** When querying HSDES bugs/features, Jira issues, OneBom BOM data, or Atlas product metadata using natural language; or when running SQL directly against the PE Snowflake schemas.

**Location:** [`skills/eca-pe-analytics/SKILL.md`](skills/eca-pe-analytics/SKILL.md)

**Key Features:**
- NL-to-SQL translation via Cortex Agent
- Direct SQL execution against PE Snowflake schemas
- Covers HSDES, Jira, OneBom (IBDS), and Atlas data sources

---

## Setup

### Step 1 – Request AGS Access

Apply for access to the **ECA IP PE Analytics** resource through AGS (Access and Group Services).  
Ensure your role grants access to the relevant Snowflake schemas for your data source(s).

---

### Step 2 – Generate a Snowflake PAT Token

1. Log in to **Snowsight** (Snowflake UI).
2. Navigate to **Settings → Security → Authentication → Programmatic Access Tokens**.
3. Click **Generate Token** — select **All Roles** or choose specific roles as needed.
4. Copy the generated token securely.

> Reference: [Snowflake Programmatic Access Token Documentation](https://docs.snowflake.com/en/user-guide/programmatic-access-tokens)

---

### Step 3 – Configure `.mcp.json`

Replace `<YOUR_SNOWFLAKE_PAT_TOKEN>` in `.mcp.json` with the token generated in Step 2:

```json
{
  "mcpServers": {
    "ECDW_apigee_sso": {
      "type": "http",
      "url": "https://apisx.intel.io/ecdw/v1/mcp",
      "headers": {
        "User-Agent": "VS-Code-MCP-Client/1.0 (Intel-Corporate)",
        "X-Client-Version": "1.0.0",
        "patToken": "<YOUR_SNOWFLAKE_PAT_TOKEN>"
      },
      "oauth": {
        "clientId": "6ec96f0e-77cc-4743-bb7a-cd662a95a04d"
      }
    }
  }
}
```

> **Security:** Do **not** commit `.mcp.json` with your PAT token to source control.

---

### Step 4 – Start the MCP Server

Once the configuration is saved, reload/restart your MCP client (e.g., VS Code).  
The server will connect using:

- **Endpoint:** `https://apisx.intel.io/ecdw/v1/mcp`
- **Client ID:** `6ec96f0e-77cc-4743-bb7a-cd662a95a04d`

---

## MCP Server Configuration

The plugin uses the MCP server configuration in `.mcp.json`:

```json
{
  "mcpServers": {
    "ECDW_apigee_sso": {
      "type": "http",
      "url": "https://apisx.intel.io/ecdw/v1/mcp",
      "headers": {
        "User-Agent": "VS-Code-MCP-Client/1.0 (Intel-Corporate)",
        "X-Client-Version": "1.0.0",
        "patToken": "<YOUR_SNOWFLAKE_PAT_TOKEN>"
      },
      "oauth": {
        "clientId": "6ec96f0e-77cc-4743-bb7a-cd662a95a04d"
      }
    }
  }
}
```

Authentication uses a combination of Snowflake PAT token (in headers) and OAuth client credentials — no Kerberos configuration required.

---

## Available MCP Tools

| Tool | Description |
|------|-------------|
| `ECA_IP_PE_ANALYTICS_CORTEX_AGENT` | Query PE data using natural language (NL to SQL via Cortex Agent) |
| `ECA_IP_PE_ANALYTICS_SQL_EXEC` | Execute SQL queries directly against the PE Snowflake database |

---

## Usage

### Natural Language Query (Cortex Agent)

Use `ECA_IP_PE_ANALYTICS_CORTEX_AGENT` to ask questions in plain English:

> *"How many open bugs are there in HSDES?"*  
> *"Show me Jira issues for project GTXKS submitted in the last 30 days."*  
> *"What are the top 10 components with the most open HSDES features?"*

### Direct SQL Execution

Use `ECA_IP_PE_ANALYTICS_SQL_EXEC` to run SQL directly against the PE Snowflake schemas:

```sql
SELECT DISTINCT projectKey
FROM PRODUCT_ENGINEERING.DESIGN_ANALYSIS.V_dka_jira_issues;
```

```sql
SELECT component, COUNT(*) AS open_bugs
FROM PRODUCT_ENGINEERING.DESIGN_ANALYSIS.V_dka_hsdes_bugs
WHERE status = 'open'
GROUP BY component
ORDER BY open_bugs DESC
LIMIT 10;
```

---

## Troubleshooting

### Authentication fails (401/403)

- **Cause:** PAT token expired, AGS access revoked, or `clientId` misconfigured
- **Solution:** Verify your AGS access is active, regenerate your Snowflake PAT token, and confirm the `clientId` is `6ec96f0e-77cc-4743-bb7a-cd662a95a04d`

### PAT token expired

- PAT tokens have an expiration date — regenerate and update `.mcp.json` before the token expires
- Navigate to **Snowsight → Settings → Security → Programmatic Access Tokens** to generate a new token

### No results from Cortex Agent

- **Cause:** Ambiguous natural language query or insufficient AGS role permissions
- **Solution:** Rephrase the query with more specific column/table references, or check your Snowflake role grants

### SQL execution errors

- **Cause:** Schema or view name mismatch, or insufficient Snowflake role permissions
- **Solution:** Query `INFORMATION_SCHEMA` to verify accessible schemas, or contact the ECA team for schema documentation

---

## Support

**Owners:**
- ECA / DKA Team — Product Engineering Analytics

**Wiki:** https://wiki.ith.intel.com/spaces/dka/pages/4802222194/MCP+server+-+PE+ECA

**Repository:** https://github.com/intel-innersource/applications.agents-marketplace.plugins

**MCP Endpoint:** https://apisx.intel.io/ecdw/v1/mcp

---

## Changelog

### 1.0.0
- Initial release
- `eca-pe-analytics` skill: NL-to-SQL via Cortex Agent and direct SQL execution patterns
- Snowflake PAT + OAuth authenticated HTTP MCP server
- Covers HSDES, Jira, OneBom (IBDS), and Atlas data sources
