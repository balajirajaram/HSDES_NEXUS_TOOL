---
name: eca-pe-analytics
description: Query Intel Product Engineering structured data (HSDES, Jira, OneBom/IBDS, Atlas) using natural language (NL to SQL via Cortex Agent) or direct SQL against the PE Snowflake database.
---

# ECA IP PE Analytics Skill

This skill defines usage patterns and tool guidance for querying Intel's Product Engineering structured data warehouse via the `ECDW_apigee_sso` MCP server.

---

## Available MCP Tools

| Tool | Type | Description |
|------|------|-------------|
| `ECA_IP_PE_ANALYTICS_CORTEX_AGENT` | Tool | Natural language query — translates plain-English questions to SQL and executes against the PE Snowflake database |
| `ECA_IP_PE_ANALYTICS_SQL_EXEC` | Tool | Execute SQL queries directly against the PE Snowflake database |

---

## Data Sources

| Data Source | Description | Example Use |
|-------------|-------------|-------------|
| **HSDES** | Hardware/Software Design Engineering System | Bug counts, feature tracking, component status |
| **Jira** | Project and issue tracking | Sprint issues, project metrics, assignee workload |
| **OneBom (IBDS)** | Bill of Materials data | Component inventory, BOM hierarchy |
| **Atlas** | Product/platform metadata | Platform definitions, product catalog |

---

## Tool: `ECA_IP_PE_ANALYTICS_CORTEX_AGENT`

**Purpose**: Ask questions about PE data in plain English. The Cortex Agent translates the question to SQL and executes it against the PE Snowflake database.

**When to use**:
- When the user asks a natural language question about HSDES, Jira, OneBom, or Atlas data
- When the user does not know the exact schema or table names
- For exploratory queries where the exact SQL is not pre-defined

**Usage pattern**:

```
ECA_IP_PE_ANALYTICS_CORTEX_AGENT(
    query="How many open bugs are there in HSDES for Granite Rapids?"
)
```

**Example questions**:

| User Question | Tool |
|---------------|------|
| "How many open bugs are in HSDES?" | `ECA_IP_PE_ANALYTICS_CORTEX_AGENT` |
| "Show Jira issues for project GTXKS in the last 30 days" | `ECA_IP_PE_ANALYTICS_CORTEX_AGENT` |
| "What components have the most open HSDES features?" | `ECA_IP_PE_ANALYTICS_CORTEX_AGENT` |
| "List all Jira epics in PFLS with status In Progress" | `ECA_IP_PE_ANALYTICS_CORTEX_AGENT` |
| "Show OneBom entries for a specific part number" | `ECA_IP_PE_ANALYTICS_CORTEX_AGENT` |

---

## Tool: `ECA_IP_PE_ANALYTICS_SQL_EXEC`

**Purpose**: Execute a SQL query directly against the PE Snowflake database. Use when the user provides or requests a specific SQL query.

**When to use**:
- When the user provides an explicit SQL query to run
- When a previous Cortex Agent response reveals a query that needs refinement
- For precise, schema-aware queries where the exact SQL is known

**Usage pattern**:

```sql
-- Distinct Jira project keys
SELECT DISTINCT projectKey
FROM PRODUCT_ENGINEERING.DESIGN_ANALYSIS.V_dka_jira_issues;

-- Top components by open HSDES bugs
SELECT component, COUNT(*) AS open_bugs
FROM PRODUCT_ENGINEERING.DESIGN_ANALYSIS.V_dka_hsdes_bugs
WHERE status = 'open'
GROUP BY component
ORDER BY open_bugs DESC
LIMIT 10;

-- HSDES features by product
SELECT design_id, title, status, component
FROM PRODUCT_ENGINEERING.DESIGN_ANALYSIS.V_dka_hsdes_features
WHERE design_id LIKE 'GNR%'
LIMIT 20;
```

---

## Workflow Patterns

### Pattern 1 — Natural Language Exploration

1. User asks a question in plain English
2. Call `ECA_IP_PE_ANALYTICS_CORTEX_AGENT` with the question as `query`
3. Present the results; optionally offer to refine with `ECA_IP_PE_ANALYTICS_SQL_EXEC` if the user wants to adjust filters

### Pattern 2 — Direct SQL Execution

1. User provides or requests a specific SQL query
2. Call `ECA_IP_PE_ANALYTICS_SQL_EXEC` with the SQL
3. Present the results; offer to render a table or chart if the result set has more than 5 rows

### Pattern 3 — Schema Discovery → SQL Execution

1. User wants to explore what data is available
2. Use `ECA_IP_PE_ANALYTICS_SQL_EXEC` with an `INFORMATION_SCHEMA` query to list accessible views/tables
3. Follow up with a targeted query once the schema is confirmed

```sql
-- Discover accessible views in the PE analytics schema
SELECT table_name, table_type
FROM INFORMATION_SCHEMA.TABLES
WHERE table_schema = 'DESIGN_ANALYSIS'
ORDER BY table_name;
```

---

## Key Schema References

> **Note**: Exact view names and column schemas may vary. Use `INFORMATION_SCHEMA` queries or `ECA_IP_PE_ANALYTICS_CORTEX_AGENT` to explore available data.

---

## Authentication Notes

- The MCP server requires a **Snowflake Programmatic Access Token (PAT)** set in the `patToken` header of `.mcp.json`
- PAT tokens expire — regenerate and update `.mcp.json` before expiration
- AGS access must be active for the relevant Snowflake schemas
- Do **not** commit `.mcp.json` with your PAT token to source control

> Setup guide: [ECA IP PE Analytics MCP Server Wiki](https://wiki.ith.intel.com/spaces/dka/pages/4802222194/MCP+server+-+PE+ECA)

---

## Error Handling

| Error | Likely Cause | Resolution |
|-------|-------------|------------|
| `401 Unauthorized` | PAT token expired or invalid | Regenerate PAT in Snowsight and update `.mcp.json` |
| `403 Forbidden` | AGS access not provisioned | Request AGS access to the ECA IP PE Analytics resource |
| `No results` | Query too narrow or schema mismatch | Try `ECA_IP_PE_ANALYTICS_CORTEX_AGENT` with a broader question, or verify view names via `INFORMATION_SCHEMA` |
| `SQL error` | Invalid column/table reference | Check schema with `INFORMATION_SCHEMA` query or consult the ECA team |
