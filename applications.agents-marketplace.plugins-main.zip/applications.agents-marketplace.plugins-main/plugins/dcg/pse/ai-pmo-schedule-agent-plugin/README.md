# AI PMO Schedule Agent Plugin

> Plugin enables PMs to generate GANTT charts and includes an agent that scans M365 content for schedule changes.

## Features

- **GANTT Chart Generator** — reads an Excel file with schedule/dependency data and produces a color-coded GANTT chart (Excel + HTML) with critical path analysis, dependency arrows, and milestone markers
- **Schedule Agent** — automatically fetches recent emails and Teams messages via Microsoft Graph, cross-references them against your GANTT schedule, and sends a weekly report to your Teams self-chat with at-risk tasks, confirmed slips, and a suggested-update Excel file
- **Suggested Update Excel** — agent output includes a highlighted workbook (`Suggested Schedule` + `Agent Change Log` tabs) showing which tasks have been flagged and what revised dates are recommended
- **Critical Path Analysis** — CPM-based forward/backward pass with float calculation, Top Risks table, and target-milestone filtering
- **Workweek Format** — native support for Intel WW'YY notation (e.g. `WW30'26`), Monday-based; WW01 = the Monday on or before January 1

## Installation

### Prerequisites

- Python 3.8 or higher
- pip
- Microsoft 365 account (for Schedule Agent)
- GitHub personal access token (PAT) with access to [GitHub Models](https://github.com/marketplace/models) (for Schedule Agent LLM backend) — a Copilot seat is **not** required; any GitHub account with GitHub Models access works

### Setup

```bash
# Clone the source repository
git clone https://github.com/intel-innersource/AI-PMO-Schedule-Gantt-Chart-Generator.git
cd AI-PMO-Schedule-Gantt-Chart-Generator

# Install dependencies
pip install -r requirements.txt

# (Schedule Agent only) Copy and fill in the config template
cp schedule_agent_config.template.json schedule_agent_config.json
# Windows: copy schedule_agent_config.template.json schedule_agent_config.json

# Edit schedule_agent_config.json — set graph.client_id from your Azure AD app registration

# (Schedule Agent only) Set your GitHub PAT as an environment variable
export GITHUB_TOKEN=github_pat_YOUR_TOKEN_HERE
# Windows: set GITHUB_TOKEN=github_pat_YOUR_TOKEN_HERE
# Windows PowerShell: $env:GITHUB_TOKEN = "github_pat_YOUR_TOKEN_HERE"

# (Schedule Agent only) One-time auth
python setup_agent_auth.py
```

### Windows EXE (no Python required)

A standalone Windows executable is available for the GANTT generator only:

```cmd
gantt_chart_MMDDYY.exe "C:\path\to\your\schedule.xlsx"
```

## Usage

### GANTT Chart Generator

```bash
# Basic — generates Excel GANTT tab + HTML file
python src/main.py "path/to/schedule.xlsx"

# With options
python src/main.py "schedule.xlsx" --output-dir "C:\output"
python src/main.py "schedule.xlsx" --target-milestone "SOP PO start"
python src/main.py "schedule.xlsx" --year 2027
```

**Input:** Excel file with a `Dependencies` sheet containing task names, owners, dates, durations, and dependency formulas.

**Output:**
- `<name>.xlsx` — original file updated with a color-coded GANTT tab
- `<name>.html` — standalone interactive GANTT (open in any browser)
- `<name>_milestones.xlsx` — milestone schedule table

### Schedule Agent

```bash
# Analyze last 7 days of email, send Teams report + write suggested-update Excel
python schedule_agent.py

# Look back 14 days
python schedule_agent.py --days 14

# Console output only (no Teams message, no Excel)
python schedule_agent.py --dry-run
```

**Output:**
- Teams self-chat HTML report: at-risk tasks, confirmed slips, past-due items, action items
- `output/<filename>_agent_MMDDYY.xlsx`:
  - **Suggested Schedule** sheet — all tasks; flagged rows color-coded (🔴 slip / 🟡 at-risk / 🟡 past-due / 🟢 complete) with suggested revised dates and strikethrough on superseded originals
  - **Agent Change Log** sheet — timestamped delta table for audit trail

### Scheduling Automatically (Windows)

```powershell
# Import Task Scheduler task — runs every Monday at 7 AM
Register-ScheduledTask -Xml (Get-Content schedule_agent_task.xml -Raw) -TaskName "JGS Schedule Agent" -Force
```

## Input File Format

The GANTT generator reads a **Dependencies** sheet (sole source of truth). Required columns:

| Column | Description |
|---|---|
| `Domain area` | Work stream / domain |
| `Component` | Component name |
| `Task` | Task description |
| `Owner` | Task owner |
| `Task start date` | `WW31'26` or `31'26` format |
| `Task end date` | `WW15'27` format |
| `Duration of task (weeks...)` | e.g. `5w`, `10 weeks` |
| `Dependency need by date` | e.g. `Other Task + 4w`, `Finish = Task end` |
| `Directly Connected Platform Milestone` | Milestone name |

## Schedule Agent — Azure AD Setup

The Schedule Agent requires an Azure AD app registration for Microsoft Graph access:

1. Go to [portal.azure.com](https://portal.azure.com) → App registrations → New registration
2. Name: e.g. `JGS Schedule Agent` | Single tenant
3. Authentication → Allow public client flows = **Yes**
4. API permissions → Microsoft Graph → Delegated: `Mail.Read`, `Chat.ReadWrite`, `User.Read`
5. Copy the **Application (client) ID** into `schedule_agent_config.json` → `graph.client_id`

## Security

- `schedule_agent_config.json` is gitignored — **never commit it**
- Store your GitHub PAT in the `GITHUB_TOKEN` environment variable, not in the config file
- The MSAL token cache (`.schedule_agent_token_cache.json`) is also gitignored

## Troubleshooting

| Problem | Fix |
|---|---|
| `Permission denied` writing Excel | Close the Excel file before running |
| `ModuleNotFoundError` | Run `pip install -r requirements.txt` |
| `AADSTS700016` auth error | Register Azure AD app and set `graph.client_id` in config |
| Tasks missing from critical path | Check duration is not `0` or `?`; verify dependency names match exactly |
| Date parsing errors | Ensure dates use `WW'YY` format with standard ASCII apostrophe |

## Support

- **Owner:** Jason Kerby — jason.c.kerby@intel.com
- **Source repo:** https://github.com/intel-innersource/AI-PMO-Schedule-Gantt-Chart-Generator

## Changelog

### 1.1.0 (2026-07-06)
- Added `agents/gantt-chart-generator.agent.md` — step-by-step agent for running the GANTT generator
- Added `agents/schedule-validator.agent.md` — step-by-step agent for M365 email analysis and Teams reporting

### 1.0.0 (2026-07-06)
- Initial marketplace publication (plugin.json + README only)
- GANTT Chart Generator with critical path analysis, HTML export, milestone PDF
- Schedule Agent with Microsoft Graph email analysis, GitHub Models LLM backend, suggested-update Excel output
