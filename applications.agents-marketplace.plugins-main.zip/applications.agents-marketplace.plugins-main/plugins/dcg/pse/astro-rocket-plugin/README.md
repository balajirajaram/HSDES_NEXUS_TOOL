# astro-rocket-plugin

Generate, review, validate, and debug Rocket CLI configurations using AI — directly from VS Code Copilot chat. Describe your hardware in plain English; Copilot generates and validates the full `rocket` command via the `astro` MCP server running on your SUT.

**Version:** 1.0.0 &nbsp;|&nbsp; **Owners:** [Hitesh Kumar](mailto:hitesh.kumar@intel.com) · [Warren T Leitner](mailto:warren.t.leitner@intel.com) · [Dudi Amar](mailto:dudi.amar@intel.com)

---

## Quick Start

1. **Install** this plugin from the Intel Copilot Marketplace
2. **Connect to your SUT** — type in Copilot chat:
   > *"set up my astro connection"*

  Copilot guides you to the bundled setup script. It will point you to the installed
  plugin folder and tell you exactly which command to run. No manual config editing needed.
3. **Ask** — generate configs, review commands, or debug failing tests using the examples in [Usage](#usage) below

> Connection setup is **one-time per SUT** and persists across VS Code sessions.
> To switch SUTs, say *"reconfigure astro for a new SUT"*.

---

## Prerequisites (One-Time SUT Setup)

Complete these steps once on each SUT before the first connection.

### 1 — Verify `astro` is installed on the SUT

```bash
dpkg -l python3-astro
```

If not installed, the setup script will install it automatically via `apt-get`. If automatic installation fails, contact your SVOS admin.

### 2 — Set up passwordless SSH from your dev machine

The setup script handles this automatically for both local and Remote SSH users — it generates a key if one doesn't exist, copies it to the SUT, and writes the SSH config.

> **VS Code Remote SSH users:** Open Extensions, search `@agentPlugins astro-rocket-plugin`, click the gear icon (⚙) and select **Open Extension Folder** or **Open Plugin Folder** (label varies by VS Code version), and run the bundled setup script from the local plugin folder. The agent terminal runs on the remote workspace host — the script must run locally.

### 3 — Authenticate GitHub Copilot on the SUT

```bash
ssh root@<sut-ip>
gh auth login   # Choose: GitHub.com → HTTPS → Device flow
```

> **Intel corporate proxy:** `astro` applies the Intel corporate proxy automatically. No manual proxy environment variables are needed.

---

## Usage

Type any of these phrases in VS Code Copilot chat:

### Connect to a SUT

```
set up my astro connection
configure SUT connection
astro MCP server is not connecting
astro is not connected
```

Copilot runs the `acquire-connection` skill:
1. Directs you to the installed plugin folder via Extensions → `@agentPlugins astro-rocket-plugin` → gear icon (⚙) → **Open Extension Folder** / **Open Plugin Folder**
2. Tells you to run the bundled setup script from that folder — the script handles all prompting, key generation, passwordless SSH, config writing, `/usr/bin/astro --help` verification, and `python3-astro` installation
3. Prompts you to restart the MCP server once the script completes

### Generate a Rocket Config

```
generate rocket config for DSA and VTd
generate rocket config for dram, pcie, and vtd
```

### Review an Existing Command

```
review rocket --atlas "--hw dsa" --cfgs
```

### Debug a Failing Test

```
triage the failing test in /root/rocket_runs/test_20260601
debug my rocket run
```

### Reconfigure / Switch SUT

```
reconfigure astro for a new SUT
switch to a different SUT
reset astro connection
```

Copilot re-runs the `acquire-connection` skill — directs you to the bundled setup script to overwrite the SSH config with the new SUT's values.

---

## How It Works

```
VS Code (dev machine)
  │
  │  ~/.config/astro-rocket/ssh_config  (written by bundled setup script)
  │
  ▼
SSH into SUT  ──►  /usr/bin/astro --base-dir /root --log-level warning mcp
                         │
                         │  JSON-RPC over stdin/stdout
                         ▼
                   MCP tools exposed to Copilot chat
```

`astro` is a Python CLI tool (`/usr/bin/astro`, package `python3-astro`) installed on DMR/SVOS validation machines. It knows the full hardware module registry and generates validated Rocket CLI commands from natural-language prompts.

### Skills

| Skill | Purpose |
|-------|---------|
| `acquire-connection` | Sets up the SUT connection by directing the user to the bundled setup script. The script handles key generation, passwordless SSH, SSH config writing, `/usr/bin/astro --help` verification, and `python3-astro` installation. Triggered automatically when the MCP server is not connected. |
| `astro-rocket` | Workflow skill for generating, reviewing, checking, and debugging Rocket configs. Handles multi-step generate→review→present workflows and clarification loops. |

### MCP Tools

| Tool | What it does |
|------|-------------|
| `mcp_astro_config` | Generate a Rocket CLI command from a natural-language hardware description. Runs the full pipeline: preprocess → generate → validate → review → present. |
| `mcp_astro_review` | Review an existing Rocket command string for correctness. Returns `approved`, `needs_clarification`, or `rejected` with reasoning. |
| `mcp_astro_check` | Validate generated rocket config files in a directory. *(May be "coming soon" depending on installed version.)* |
| `mcp_astro_debug` | Triage a failing rocket test run from a given path. *(May be "coming soon" depending on installed version.)* |

All tools accept a single natural-language `prompt` string.

---

## Troubleshooting

| Symptom | Fix |
|---------|-----|
| MCP server not connecting after setup | Restart the server: `Ctrl+Shift+P` → `MCP: Restart Server` → select **astro** |
| Tool not discovered / "server not connected" | Reload VS Code: `Ctrl+Shift+P` → *Developer: Reload Window* |
| SSH connection refused | Run `ssh-copy-id root@<sut>`, then verify `ssh root@<sut>` succeeds without a password |
| "Failed to parse message: banner text" | Ensure `.mcp.json` invokes `/usr/bin/astro` directly (no `bash -lc` wrapper) |
| Geni auth error | Confirm `use_faceless_auth: true` in `/usr/lib/python3/dist-packages/astro/rocket_config_gen/CONFIG.yml` on SUT |
| `mcp_astro_check` / `mcp_astro_debug` fails immediately | Feature may not be in the installed version — check `dpkg -l python3-astro` |

---

## Revoking SSH Access

Remove your public key from `~/.ssh/authorized_keys` on the SUT:

**Linux / macOS:**
```bash
KEY=$(awk '{print $2}' ~/.ssh/id_ed25519.pub)
ssh root@<sut> "grep -v '$KEY' ~/.ssh/authorized_keys > /tmp/ak && mv /tmp/ak ~/.ssh/authorized_keys"
```

**Windows PowerShell:**
```powershell
$key = (Get-Content "$env:USERPROFILE\.ssh\id_ed25519.pub").Split(" ")[1]
ssh root@<sut> "grep -v '$key' ~/.ssh/authorized_keys > /tmp/ak && mv /tmp/ak ~/.ssh/authorized_keys"
```

---

## Owners

- Hitesh Kumar — hitesh.kumar@intel.com
- Warren T Leitner — warren.t.leitner@intel.com
- Dudi Amar — dudi.amar@intel.com
