---
name: acquire-connection
description: >-
  Set up the astro MCP server SSH connection before calling any astro tools
  (mcp_astro_config, mcp_astro_review, mcp_astro_check, mcp_astro_debug).
  Use when: astro MCP server is not connected, config file is missing,
  switching to a different SUT, connection errors from astro tools.
argument-hint: "setup | reconfigure"
---

# Acquire Connection

## When to Use

Load and follow this skill **before calling any astro MCP tool** when the server is not
connected or when switching to a different SUT.

Run it **once per SUT**. The setup script writes the SSH config on the system where the
astro MCP client runs, and that config persists across VS Code sessions.

---

## Constraints

- Do **not** collect SUT hostname, SSH key path, working directory, passwords, or tokens in chat.
- Do **not** build inline SSH config commands.
- Do **not** run manual SSH probes or ask the user to paste SSH debug output.
- Do **not** assume the agent terminal is on the same system as the astro MCP client.

The setup scripts own all prompting, key generation, passwordless SSH setup, SSH config
writing, `/usr/bin/astro --help` verification, and `python3-astro` installation.

---

## Step 1 — Direct the User to the Setup Script

Tell the user to run the bundled setup script from the installed astro plugin folder.

1. Open the **Extensions** view (`Ctrl+Shift+X`).
2. Search for `@agentPlugins astro-rocket-plugin`.
3. Click the **gear icon (⚙)** next to the extension entry, then select **Open Extension Folder** or **Open Plugin Folder** (label varies by VS Code version).
   This opens the parent plugin folder (e.g. `…/plugins/dcg/pse`).
4. Open a terminal in that folder:
   - **Windows:** In File Explorer, Shift+Right-click the folder → **Open in Terminal** (or **Open PowerShell window here**)
   - **Linux / macOS:** Right-click the folder in your file manager → **Open Terminal Here**, or `cd` to the path shown.
5. Run the setup script for that machine's OS.

**Windows (PowerShell):**
```powershell
powershell -ExecutionPolicy Bypass -File .\astro-rocket-plugin\skills\acquire-connection\scripts\setup.ps1
```

**Linux / macOS:**
```bash
bash ./astro-rocket-plugin/skills/acquire-connection/scripts/setup.sh
```

If the user is in VS Code Remote SSH, emphasize that this must be run from the local
extension folder, not from the remote workspace terminal. The agent may have access to
astro tools through VS Code, but its shell commands run on the remote workspace host.

---

## Step 2 — Wait for Script Completion

Tell the user the script will prompt for a few values and then run automatically:

- **SUT hostname or IP** — required.
- **SSH private key path** — optional; press Enter to accept the default shown in brackets.
- **Working directory on SUT** — optional; press Enter to accept the default shown in brackets.
- Generate an SSH key if needed.
- Set up passwordless SSH authentication.
- Write the local SSH config used by the astro MCP client.
- Verify `/usr/bin/astro --help` works on the SUT.
- Install `python3-astro` on the SUT if astro is missing.

Do not ask the user to paste script output unless they explicitly ask for help with a
script failure. If the script fails, tell the user to follow the error message printed by
the script and re-run this skill after fixing it.

---

## Step 3 — Restart the MCP Server

After the user confirms the script completed successfully, tell them:

> "Connection setup completed. Please restart the astro MCP server:
> `Ctrl+Shift+P` → type `MCP: Restart Server` → select **astro**"

---

## Step 4 — Continue the Original Request

After the MCP server restarts, retry the original astro tool call.

If the astro MCP tools are still unavailable, report that the server is still not
connected and ask the user to check the MCP server output in VS Code. Do not run manual
SSH commands from the agent terminal to debug it.

