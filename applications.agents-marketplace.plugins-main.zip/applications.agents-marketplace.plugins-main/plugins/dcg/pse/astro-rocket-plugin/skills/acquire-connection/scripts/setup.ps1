# astro-rocket SUT connection setup
# Writes %USERPROFILE%\.config\astro-rocket\ssh_config used by the astro MCP server.

$ConfigDir  = "$env:USERPROFILE\.config\astro-rocket"
$ConfigFile = "$ConfigDir\ssh_config"

function Test-Astro {
    ssh -F $ConfigFile -o BatchMode=yes -o ConnectTimeout=5 -o RemoteCommand=none astro-sut "/usr/bin/astro --help >/dev/null 2>&1" | Out-Null
    return ($LASTEXITCODE -eq 0)
}

function Install-Astro {
    Write-Host "  Installing python3-astro on SUT..." -ForegroundColor Yellow
    ssh -F $ConfigFile -o BatchMode=yes -o ConnectTimeout=5 -o RemoteCommand=none astro-sut "apt-get update && DEBIAN_FRONTEND=noninteractive apt-get install -y python3-astro"
    return ($LASTEXITCODE -eq 0)
}

Write-Host ""
Write-Host "=== astro-rocket SUT Connection Setup ===" -ForegroundColor Cyan
Write-Host ""

# ── ASTRO_HOST (required) ────────────────────────────────────────────────────
do {
    $AstroHost = Read-Host "SUT hostname or IP (e.g. DMR4778 or 10.x.x.x)"
    if (-not $AstroHost) {
        Write-Host "  Error: SUT hostname is required." -ForegroundColor Red
    }
} while (-not $AstroHost)

# ── ASTRO_SSH_KEY (optional) ─────────────────────────────────────────────────
$AstroSshKey = Read-Host "SSH private key path (leave blank to use ~/.ssh/id_ed25519)"
if (-not $AstroSshKey) { $AstroSshKey = "~/.ssh/id_ed25519" }

$ExpandedKey = $AstroSshKey -replace "^~", $env:USERPROFILE

# ── Ensure SSH key exists ────────────────────────────────────────────────────
if (-not (Test-Path $ExpandedKey)) {
    Write-Host ""
    Write-Host "SSH key not found at $AstroSshKey. Generating a new ed25519 key (no passphrase)..." -ForegroundColor Yellow
    $KeyDir = Split-Path $ExpandedKey
    if (-not (Test-Path $KeyDir)) { New-Item -Force -Path $KeyDir -ItemType Directory | Out-Null }
    ssh-keygen -t ed25519 -f $ExpandedKey -N '""'
    Write-Host "  Key generated: $ExpandedKey" -ForegroundColor Green
}

# ── ASTRO_BASE_DIR (optional) ────────────────────────────────────────────────
$AstroBaseDir = Read-Host "Working directory on SUT (leave blank to use /root)"
if (-not $AstroBaseDir) { $AstroBaseDir = "/root" }

# ── Ensure passwordless SSH auth to SUT ──────────────────────────────────────
$SshAuthOk = $false
Write-Host ""
Write-Host "Testing SSH connection to root@$AstroHost..."
$testResult = ssh -o BatchMode=yes -o ConnectTimeout=5 -o StrictHostKeyChecking=accept-new "root@$AstroHost" "echo ok" 2>$null
if ($testResult -eq "ok") {
    Write-Host "  Passwordless SSH already works." -ForegroundColor Green
    $SshAuthOk = $true
} else {
    Write-Host "  Passwordless auth not set up. Attempting to copy public key to SUT..." -ForegroundColor Yellow
    Write-Host "  (You may be prompted for the root password once.)"
    $pubkey = Get-Content "${ExpandedKey}.pub"
    ssh -o StrictHostKeyChecking=accept-new "root@$AstroHost" "mkdir -p ~/.ssh && echo '$pubkey' >> ~/.ssh/authorized_keys && chmod 600 ~/.ssh/authorized_keys"
    if ($LASTEXITCODE -eq 0) {
        $verifyResult = ssh -o BatchMode=yes -o ConnectTimeout=5 -o StrictHostKeyChecking=accept-new "root@$AstroHost" "echo ok" 2>$null
        if ($verifyResult -eq "ok") {
            Write-Host "  Passwordless SSH now works." -ForegroundColor Green
            $SshAuthOk = $true
        }
    }
    if (-not $SshAuthOk) {
        Write-Host ""
        Write-Host "  Could not set up passwordless SSH automatically." -ForegroundColor Yellow
        Write-Host "  Run this command manually, then re-run this skill:" -ForegroundColor Yellow
        Write-Host "    type $ExpandedKey.pub | ssh root@$AstroHost `"cat >> ~/.ssh/authorized_keys`"" -ForegroundColor Cyan
    }
}

# ── Write config ─────────────────────────────────────────────────────────────
$RemoteCmd = "/usr/bin/astro --base-dir $AstroBaseDir --log-level warning mcp"

New-Item -Force -Path $ConfigDir -ItemType Directory | Out-Null

$Lines = @(
    "Host astro-sut",
    "  HostName $AstroHost",
    "  User root",
    "  IdentityFile $AstroSshKey",
    "  StrictHostKeyChecking no",
    "  RequestTTY no",
    "  RemoteCommand $RemoteCmd"
)
$Lines -join "`n" | Set-Content -Encoding UTF8 -Path $ConfigFile

Write-Host ""
Write-Host "SSH config written to $ConfigFile" -ForegroundColor Green
Write-Host "  Host : $AstroHost"
Write-Host "  Key  : $AstroSshKey"
Write-Host "  Dir  : $AstroBaseDir"
Write-Host ""

$AstroReady = $false
if ($SshAuthOk) {
    Write-Host "Verifying astro on SUT..." -ForegroundColor Cyan
    if (Test-Astro) {
        Write-Host "  /usr/bin/astro is ready." -ForegroundColor Green
        $AstroReady = $true
    } else {
        Write-Host "  /usr/bin/astro missing or broken." -ForegroundColor Yellow
        if (Install-Astro) {
            if (Test-Astro) {
                Write-Host "  /usr/bin/astro installed and verified." -ForegroundColor Green
                $AstroReady = $true
            } else {
                Write-Host "  Error: /usr/bin/astro still not working after installation." -ForegroundColor Red
                exit 1
            }
        } else {
            Write-Host "  Error: Failed to install python3-astro." -ForegroundColor Red
            exit 1
        }
    }
}

if ($SshAuthOk -and $AstroReady) {
    Write-Host "All done. Restart the astro MCP server in VS Code to connect." -ForegroundColor Green
} else {
    Write-Host "WARNING: Setup incomplete." -ForegroundColor Yellow
    if (-not $SshAuthOk) {
        Write-Host "SSH key auth is not yet set up." -ForegroundColor Yellow
        Write-Host "Run the following command, then re-run this skill to verify:" -ForegroundColor Yellow
        Write-Host "  type `"$ExpandedKey.pub`" | ssh root@$AstroHost `"cat >> ~/.ssh/authorized_keys`"" -ForegroundColor Cyan
    }
}
Write-Host ""
Write-Host "Note: Ensure 'gh auth login' has been run on the SUT for Copilot auth."
