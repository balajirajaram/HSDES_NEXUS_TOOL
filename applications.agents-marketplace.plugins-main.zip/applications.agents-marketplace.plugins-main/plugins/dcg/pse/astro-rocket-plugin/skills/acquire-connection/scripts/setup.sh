#!/usr/bin/env bash
# astro-rocket SUT connection setup
# Writes ~/.config/astro-rocket/ssh_config used by the astro MCP server.
set -euo pipefail

CONFIG_DIR="$HOME/.config/astro-rocket"
CONFIG_FILE="$CONFIG_DIR/ssh_config"

verify_astro() {
    ssh -F "$CONFIG_FILE" -o BatchMode=yes -o ConnectTimeout=5 -o RemoteCommand=none astro-sut '/usr/bin/astro --help >/dev/null 2>&1'
}

install_astro() {
    echo "  Installing python3-astro on SUT..."
    ssh -F "$CONFIG_FILE" -o BatchMode=yes -o ConnectTimeout=5 -o RemoteCommand=none astro-sut 'apt-get update && DEBIAN_FRONTEND=noninteractive apt-get install -y python3-astro'
}

echo ""
echo "=== astro-rocket SUT Connection Setup ==="
echo ""

# ── ASTRO_HOST (required) ────────────────────────────────────────────────────
while true; do
    read -r -p "SUT hostname or IP (e.g. DMR4778 or 10.x.x.x): " ASTRO_HOST
    if [[ -n "$ASTRO_HOST" ]]; then
        break
    fi
    echo "  Error: SUT hostname is required."
done

# ── ASTRO_SSH_KEY (optional) ─────────────────────────────────────────────────
read -r -p "SSH private key path (leave blank to use ~/.ssh/id_ed25519): " ASTRO_SSH_KEY
ASTRO_SSH_KEY="${ASTRO_SSH_KEY:-~/.ssh/id_ed25519}"
EXPANDED_KEY="${ASTRO_SSH_KEY/#\~/$HOME}"

# ── Ensure SSH key exists ────────────────────────────────────────────────────
if [[ ! -f "$EXPANDED_KEY" ]]; then
    echo ""
    echo "SSH key not found at $ASTRO_SSH_KEY. Generating a new ed25519 key (no passphrase)..."
    mkdir -p "$(dirname "$EXPANDED_KEY")"
    ssh-keygen -t ed25519 -f "$EXPANDED_KEY" -N ""
    echo "  Key generated: $EXPANDED_KEY"
fi

# ── ASTRO_BASE_DIR (optional) ────────────────────────────────────────────────
read -r -p "Working directory on SUT (leave blank to use /root): " ASTRO_BASE_DIR
ASTRO_BASE_DIR="${ASTRO_BASE_DIR:-/root}"

# ── Ensure passwordless SSH auth to SUT ──────────────────────────────────────
SSH_AUTH_OK=false
echo ""
echo "Testing SSH connection to root@$ASTRO_HOST..."
if ssh -o BatchMode=yes -o ConnectTimeout=5 -o StrictHostKeyChecking=accept-new "root@$ASTRO_HOST" 'echo ok' 2>/dev/null | grep -q 'ok'; then
    echo "  Passwordless SSH already works."
    SSH_AUTH_OK=true
else
    echo "  Passwordless auth not set up. Attempting to copy public key to SUT..."
    echo "  (You may be prompted for the root password once.)"
    if ssh-copy-id -o StrictHostKeyChecking=accept-new -i "${EXPANDED_KEY}.pub" "root@$ASTRO_HOST"; then
        if ssh -o BatchMode=yes -o ConnectTimeout=5 -o StrictHostKeyChecking=accept-new "root@$ASTRO_HOST" 'echo ok' 2>/dev/null | grep -q 'ok'; then
            echo "  Passwordless SSH now works."
            SSH_AUTH_OK=true
        fi
    fi
    if [[ "$SSH_AUTH_OK" == "false" ]]; then
        echo ""
        echo "  Could not set up passwordless SSH automatically."
        echo "  Run this command manually, then re-run this skill:"
        echo "    ssh-copy-id -i ${EXPANDED_KEY}.pub root@$ASTRO_HOST"
    fi
fi

# ── Write config ─────────────────────────────────────────────────────────────
REMOTE_CMD="/usr/bin/astro --base-dir $ASTRO_BASE_DIR --log-level warning mcp"

mkdir -p "$CONFIG_DIR"
printf 'Host astro-sut\n  HostName %s\n  User root\n  IdentityFile %s\n  StrictHostKeyChecking no\n  RequestTTY no\n  RemoteCommand %s\n' \
    "$ASTRO_HOST" "$ASTRO_SSH_KEY" "$REMOTE_CMD" > "$CONFIG_FILE"

echo ""
echo "SSH config written to $CONFIG_FILE"
echo "  Host : $ASTRO_HOST"
echo "  Key  : $ASTRO_SSH_KEY"
echo "  Dir  : $ASTRO_BASE_DIR"
echo ""

ASTRO_READY=false
if [[ "$SSH_AUTH_OK" == "true" ]]; then
    echo "Verifying astro on SUT..."
    if verify_astro; then
        echo "  /usr/bin/astro is ready."
        ASTRO_READY=true
    else
        echo "  /usr/bin/astro missing or broken."
        if install_astro; then
            if verify_astro; then
                echo "  /usr/bin/astro installed and verified."
                ASTRO_READY=true
            else
                echo "  Error: /usr/bin/astro still not working after installation."
                exit 1
            fi
        else
            echo "  Error: Failed to install python3-astro."
            exit 1
        fi
    fi
fi

if [[ "$SSH_AUTH_OK" == "true" && "$ASTRO_READY" == "true" ]]; then
    echo "All done. Restart the astro MCP server in VS Code to connect."
else
    echo "WARNING: Setup incomplete."
    if [[ "$SSH_AUTH_OK" == "false" ]]; then
        echo "SSH key auth is not yet set up."
        echo "Run the following command, then re-run this skill to verify:"
        echo "  ssh-copy-id -i ${EXPANDED_KEY}.pub root@$ASTRO_HOST"
    fi
fi
echo ""
echo "Note: Ensure 'gh auth login' has been run on the SUT for Copilot auth."
