---
name: astro-rocket
description: >-
  Use when generating, reviewing, checking, or debugging Rocket CLI configurations
  on a DMR/SVOS SUT. Triggers: rocket config, generate rocket, review rocket command,
  validate rocket configs, debug rocket test, triage rocket, dsa, vtd, pcie, dram,
  hardware modules, mcp_astro_config, mcp_astro_review, mcp_astro_check, mcp_astro_debug.
  Handles multi-step generate→review→present workflows and clarification loops.
argument-hint: "Describe your rocket config goal, or paste a rocket command to review"
user-invocable: true
---

# astro-rocket: Rocket Config Generation & Review

`astro` is an AI-powered Rocket CLI assistant running as an MCP server on the SUT.
It exposes four tools via the `astro` MCP server connection declared in `.mcp.json`
(bundled with this plugin).

The MCP server connects via SSH key auth (OpenSSH) — no password required at runtime once
`ssh-copy-id root@<sut>` has been run once from the dev machine.

## Understanding base-dir

`--base-dir` is the **working directory on the SUT** — not the astro install location.
VS Code prompts for this value at server startup (default: `/root`).

| Path | Purpose |
|------|---------|
| `/usr/bin/astro` | astro binary (system install via `python3-astro` package) |
| `/usr/lib/python3/dist-packages/astro/rocket_config_gen/astro.yaml` | Pipeline registry (install-time, not base-dir) |
| `--base-dir <path>` | Where output configs are written; where rocket test run artifacts are read from for debug/triage |

Set `--base-dir` to the directory where your rocket test runs live or where you want
generated configs to land.

---

## Pre-Flight: Is the astro MCP Server Connected?

Before calling any astro tool, confirm the `astro` MCP server is running and connected.

If it is **not connected** (tools unavailable, or the MCP output log shows
`"No SUT config found"`), load and follow the **`acquire-connection`** skill first:

1. The skill runs a setup script in the terminal that prompts for your SUT hostname,
   SSH key path, base directory, and optional GitHub token.
2. Values are saved to `~/.config/astro-rocket/config` (Linux/macOS) or
   `%USERPROFILE%\.config\astro-rocket\config` (Windows).
3. After the script completes, restart the astro MCP server:
   `Ctrl+Shift+P` → `MCP: Restart Server` → select **astro**.
4. Return here and proceed with the requested workflow.

This is a **one-time setup per SUT**. The config persists across VS Code sessions.
Re-run `acquire-connection` only when switching to a different SUT.

---

## When to Use Each Tool

| User intent | Tool |
|---|---|
| "generate rocket config for DSA and VTd" | `mcp_astro_config` |
| "create a rocket command for [hardware list]" | `mcp_astro_config` |
| "what rocket command do I need for PCIe?" | `mcp_astro_config` || "generate config for DSA and VTD and then run the test" | `mcp_astro_config` (activates rocket-run stage) || "review `rocket --atlas ...`" | `mcp_astro_review` |
| "is this rocket command correct?" | `mcp_astro_review` |
| "check the command I wrote" | `mcp_astro_review` |
| "validate/check configs in ./path" | `mcp_astro_check` |
| "triage/debug the failing test in ./path" | `mcp_astro_debug` |

---

## Workflow 1 — Generate a Rocket Config

```
User: "generate rocket config for DSA and VTd"
```

1. Call `mcp_astro_config` with the user's full natural-language prompt.
   Include any hardware names, variant hints, or constraints the user mentioned.

2. Parse the result for `Command :` and `Decision :`.

3. **If `Decision : approved`** — present the structured result and stop:
   ```
   Command  : rocket --atlas "--hw dram,dsa,vtd" --cfgs
   Decision : approved
   Reasoning: DSA and VTd hardware correctly mapped; dram included as required base
   ```

4. **If `Decision : needs_clarification`** — extract the clarifying question from
   `Feedback :` or `Reasoning:`, ask the user, then call `mcp_astro_config` again
   with an enriched prompt that includes the original request plus the user's answer.
   Repeat until approved or max 3 iterations.

5. **If the call fails** — report the error message and suggest re-running with
   `--log-level debug` for more detail (the user can update `.mcp.json` temporarily).

---

## Workflow 2 — Review an Existing Command

```
User: "review rocket --atlas '--hw dram,dsa,vtd' --cfgs"
```

1. Call `mcp_astro_review` with the command string as the `prompt` value.

2. Present `Decision`, `Reasoning`, and `Feedback` from the result:
   - **`approved`** with no feedback → state the command is valid
   - **`needs_clarification`** → explain what's missing and ask the user
   - **`rejected`** → explain the issues and offer to generate a corrected command
     via `mcp_astro_config`

---

## Workflow 3 — Validate Configs (mcp_astro_check)

> The check pipeline may be marked "coming soon" in the current installation.
> Attempt the call; if it fails, inform the user and suggest manual validation.

1. Ask the user for the path to the configs directory if not already provided.
2. Call `mcp_astro_check` with: `"validate the rocket configs in <path>"`
3. Present any validation errors or confirmation of correctness.

---

## Workflow 4 — Debug a Failing Rocket Test (mcp_astro_debug)

> The debug pipeline may be marked "coming soon" in the current installation.

1. Ask the user for the path to the rocket test directory (absolute, or relative to
   the `--base-dir` configured in `.mcp.json`).
2. Call `mcp_astro_debug` with: `"triage the failing test in <path>"`
3. Present findings and suggested fixes from the result.

---

## Workflow 5 — Generate Config and Run the Test

```
User: "generate rocket config for DSA and VTD and then run the test"
```

1. Call `mcp_astro_config` with the hardware description **plus an additive run phrase**.
   Supported phrases (must follow the hardware description):
   - `and then run the test` / `and run the test` / `then run the test`
   - `also run the test` / `run the rocket test after`

2. The pipeline runs config generation as normal (preprocess → generate → validate
   → review → build-config), then executes the `rocket-run` stage which:
   - Requests approval (auto-approved in MCP mode)
   - Runs `killmax && umount /sv && rmmodsvos2 && mount /sv && rocket --rerun --save`
     from the `--base-dir` output directory on the SUT
   - Streams rocket test output to the SUT terminal (not visible in chat)

3. The MCP tool returns the same structured block as a config-only call.
   The test result (pass/fail, duration) is logged on the SUT.

4. **If the test fails** — the pipeline loops back to `rocket-generate` with the
   failure context so it can propose a corrected config. Present the updated command
   and ask the user whether to run again.

5. **Prerequisite** — the generated configs must exist in `--base-dir` on the SUT
   before `rocket --rerun` is invoked. This is handled automatically when both
   config generation and run are requested in the same call.

---

## Output Format

Always present astro results as a structured block — not buried in prose:

```
Command  : <rocket command or "N/A">
Status   : success | failed
Decision : approved | needs_clarification | rejected
Reasoning: <one-sentence explanation>
Feedback : <actionable note if any, else omit>
```

---

## One-Time SUT Prerequisites

Each user must complete this setup once on their SUT:

```bash
# 1. Verify astro is installed
dpkg -l python3-astro

# 2. Set up SSH key auth from your dev machine
ssh-keygen -t ed25519       # skip if you already have a key
ssh-copy-id root@<sut-ip>
ssh -T root@<sut-ip>        # verify passwordless login

# 3. Authenticate GitHub Copilot on the SUT (device flow)
ssh root@<sut-ip>
gh auth login               # choose GitHub.com, HTTPS, device flow
                            # visit github.com/login/device and enter the code shown

# 4. Verify astro MCP starts cleanly
/usr/bin/astro --base-dir /root --log-level warning mcp
# Should emit JSON-RPC ready output — Ctrl+C to exit
```

Intel corporate proxy note: astro's MCP server applies the Intel corporate proxy
(`ProxyConfig().apply_to_environment()`) automatically — no manual proxy env vars needed.

---

## Tool Reference

Full parameter schemas, example calls, and expected outputs:
→ [references/tools.md](./references/tools.md)
