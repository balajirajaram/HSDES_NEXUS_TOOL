# astro MCP Tool Reference

All tools are exposed by the `astro` MCP server declared in `.mcp.json` (bundled with this plugin).
The server runs `/usr/bin/astro --base-dir <dir> --log-level warning mcp` on the SUT via SSH.

---

## Connection & Auth

| Item | Value |
|------|-------|
| Binary | `/usr/bin/astro` (system install on SUT via `python3-astro` package) |
| Pipeline registry | `/usr/lib/python3/dist-packages/astro/rocket_config_gen/astro.yaml` |
| base-dir | Prompted by VS Code at startup (default `/root`) — working dir for output & test artifacts |
| SUT access | SSH key auth — run `ssh-copy-id root@<sut>` once from dev machine |
| Geni auth | Faceless tokens auto-obtained on SUT (`use_faceless_auth: true` in CONFIG.yml) |
| GitHub/Copilot auth | `gh auth login` on SUT (device flow); token optionally passed as `COPILOT_GITHUB_TOKEN` |

---

## mcp_astro_config

Generates a Rocket CLI command from a natural-language description.
Runs the full `rocket_config_gen` pipeline: preprocess → generate → validate → review → present.

### Input schema
```json
{
  "prompt": "<natural language description of the rocket config you need>"
}
```

### Example calls

| Prompt | Expected command |
|--------|-----------------|
| `"generate rocket config for DSA and VTd"` | `rocket --atlas "--hw dram,dsa,vtd" --cfgs` |
| `"rocket config for PCIe Arden platform"` | `rocket --atlas "--hw pcie" --cfgs --platform arden` |
| `"create config for dram only baseline"` | `rocket --atlas "--hw dram" --cfgs` |
| `"generate rocket config for DSA and VTD and then run the test"` | generates config + runs test on SUT |
| `"create rocket config for DSA and VTD and run the test"` | generates config + runs test on SUT |

### Output (success — config only)
```
Pipeline : config
Status   : success
Command  : rocket --atlas "--hw dram,dsa,vtd" --cfgs
Decision : approved
Reasoning: DSA and VTd hardware correctly mapped; dram included as required base
```

### Output (success — config + run)
```
Pipeline : config
Status   : success
Command  : rocket --atlas "--hw dram,dsa,vtd" --cfgs
Decision : approved
Reasoning: DSA and VTd hardware correctly mapped; dram included as required base
```
> Rocket test output (stdout/stderr) streams to the SUT terminal, not to chat.
> The test runs `killmax && umount /sv && rmmodsvos2 && mount /sv && rocket --rerun --save`
> from the `--base-dir` output directory on the SUT.
> A non-zero exit triggers a config-correction loop back to `rocket-generate`.

### Output (needs clarification)
```
Pipeline : config
Status   : needs_clarification
Question : Please specify whether you want base_vtd or dsa_vtd variant
Hint     : Re-run this tool with a prompt that answers the question above.
```

### Notes
- The pipeline iterates up to 10 times internally; provide the most specific prompt possible.
- Hardware synonyms are resolved automatically (e.g. "vtd" → VT-d module).
- `dram` is typically required as the base hardware module even if not explicitly requested.
- **Run stage**: append an additive phrase like `and then run the test` to the prompt to
  activate the `rocket-run` stage after config generation. The run is auto-approved in MCP
  mode. Supported phrases: `and then run the test`, `and run the test`, `then run the test`,
  `also run the test`, `run the rocket test after`.

---

## mcp_astro_review

Reviews an existing Rocket CLI command string for correctness against known good patterns.
Runs the `rocket_config_gen` review stage directly.

### Input schema
```json
{
  "prompt": "<the rocket command string to review>"
}
```

### Example calls
```json
{ "prompt": "review rocket --atlas \"--hw dram,dsa,vtd\" --cfgs" }
{ "prompt": "is rocket --atlas \"--hw dsa\" --cfgs correct?" }
```

### Output (approved)
```
Decision : approved
Reasoning: Hardware flags and config selection are correct for DSA+VTd testing
Feedback :
```

### Output (issues found)
```
Decision : needs_clarification
Reasoning: dram base module missing from hardware list
Feedback : Add dram to --hw list: rocket --atlas "--hw dram,dsa,vtd" --cfgs
```

---

## mcp_astro_check

Validates existing rocket config files in a directory.

> This pipeline may be listed as "coming soon" in the current installation.
> Attempt the call; if it returns an error, report back to the user.

### Input schema
```json
{
  "prompt": "validate the rocket configs in <absolute-path-or-relative-to-base-dir>"
}
```

### Example call
```json
{ "prompt": "validate the rocket configs in /root/my_rocket_test" }
```

---

## mcp_astro_debug

Triages a failing rocket test run using log and artifact analysis.

> This pipeline may be listed as "coming soon" in the current installation.

### Input schema
```json
{
  "prompt": "triage the failing test in <absolute-path-or-relative-to-base-dir>"
}
```

### Example call
```json
{ "prompt": "triage the failing test in /root/rocket_runs/test_20260601" }
```

### Notes
- The path should point to the rocket test run directory (contains logs, results, configs).
- Relative paths are resolved from the `--base-dir` configured in `.mcp.json`.

---

## Troubleshooting

| Symptom | Likely cause | Fix |
|---------|-------------|-----|
| "Failed to parse message: banner text" | Login shell activating old virtualenv | `.mcp.json` must invoke `/usr/bin/astro` directly (no `bash -lc` wrapper) |
| Tool not discovered / "server not connected" | MCP server not started | Reload VS Code window (`Ctrl+Shift+P` → Developer: Reload Window) |
| SSH connection refused / timeout | SSH key not set up | Run `ssh-copy-id root@<sut>` from dev machine; verify with `ssh -T root@<sut>` |
| "Not authenticated" / Geni auth error | `use_faceless_auth` not set on SUT | Confirm `use_faceless_auth: true` in `/usr/lib/python3/dist-packages/astro/rocket_config_gen/CONFIG.yml` |
| Pipeline loops forever on clarification | Ambiguous prompt | Re-run with a more specific prompt including hardware list and variant |
| `mcp_astro_check` / `mcp_astro_debug` fails immediately | Pipeline not yet implemented in installed version | Inform user — check `dpkg -l python3-astro` for installed version |
