# ContextStore

> Never lose your Copilot session — checkpoint your context, restore in a fresh chat with 98% fewer tokens.

A custom VS Code Copilot agent that saves and restores conversation context to structured markdown files. Designed around the 200k token context window constraint — instead of replaying your entire session history (50k+ tokens), ContextStore compresses everything that matters into a ~1-2k token checkpoint.

## The Problem

When you close a Copilot chat and come back later, you lose all context. Resuming an old session reloads the full history — dead ends, verbose tool output, and all — consuming tens of thousands of tokens before you've done any new work. For long or complex sessions, this is wasteful and slow.

## The Solution

ContextStore saves the **minimum needed to resume**: your goal, current state, key decisions (and *why* they were made), files touched, and exact next steps. Restore it in a fresh chat with a single command.

```
Full session history:    50,000 tokens  →  wasteful
ContextStore checkpoint:  1,500 tokens  →  everything you need
```

## Commands

| Command | What it does |
|---------|-------------|
| `/save-context` | Save current session to `.contexts/` |
| `/restore-context` | Resume from the most recent checkpoint |
| `@ContextStore compact` | Save + advise starting a fresh chat (context window reset) |
| `@ContextStore list` | Show all saved sessions |
| `@ContextStore clean` | Remove old checkpoints (>7 days) |

## Setup

Copy the `.github/` folder into any VS Code workspace:

```
your-project/
├── .github/
│   ├── agents/
│   │   └── context-store.agent.md        ← main agent
│   ├── prompts/
│   │   ├── save-context.prompt.md        ← /save-context slash command
│   │   └── restore-context.prompt.md     ← /restore-context slash command
│   └── instructions/
│       └── context-awareness.instructions.md  ← always-on reminder
└── .contexts/                             ← checkpoints saved here
```

No extensions to install. No configuration. Just files.

Requires: [VS Code](https://code.visualstudio.com/) with [GitHub Copilot](https://github.com/features/copilot).

## How It Works

### Saving

When you run `/save-context` or `@ContextStore compact`, the agent analyzes your conversation and writes a structured checkpoint:

```markdown
---
session: "Refactoring payments API"
created: "2026-06-01T14:30:00Z"
status: "paused"
---

## Goal
Refactor the payments API to use DTOs across all endpoints.

## Current State
- Progress: 3/5 endpoints converted
- Next Step: Convert /checkout endpoint
- Blockers: None

## Key Decisions
- Using DTOs over raw maps for type safety and serialization consistency
- ...

## Files Touched
| File | Action | Purpose |
|------|--------|---------|
| src/api/payments.ts | modified | Added DTO layer to /charge and /refund |

## Resume Instructions
1. Open src/api/payments.ts
2. Convert the /checkout handler to use CheckoutRequestDTO
3. ...
```

### Restoring

In a new chat, `/restore-context` reads the latest checkpoint and briefs you:

> "You were refactoring the payments API. 3/5 endpoints done. Next step: convert /checkout. Ready to continue?"

### Compact

`@ContextStore compact` is a deliberate context window reset. It saves your context, then tells you to open a new chat. You start with ~198k tokens free and full continuity.

## Proactive Suggestions

The agent monitors the conversation and proactively suggests compacting when:

- The session exceeds ~15–20 turns
- You mention the model forgetting earlier details
- Heavy multi-file work has generated lots of tool output
- You're switching to a different task

## Design Principles

- **Compression over completeness** — store the minimum needed to resume
- **WHY over WHAT** — decision rationale is expensive to re-derive
- **File references over content** — point to files, don't duplicate them
- **Actionable next steps** — always capture what to do next
- **< 2000 tokens per checkpoint** — stays small for fast restoration

## Checkpoint Storage

Checkpoints are plain markdown files in `.contexts/`:

```
.contexts/
├── README.md
├── 20260529-1200-context-store-agent.md
├── 20260529-1215-context-store-build.md
└── 20260601-1430-payments-api-refactor.md
```

Naming format: `YYYYMMDD-HHmm-short-description.md`

Since they're plain files, you can:
- Commit them to git to share context with teammates
- Open and edit them manually
- Use them across machines

## License

MIT
