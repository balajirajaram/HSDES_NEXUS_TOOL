---
description: "Apply to all workspace files. Reminds the agent about context persistence capabilities."
applyTo: "**"
---

# Context Persistence

This workspace has a ContextStore agent for saving and restoring conversation context.

## Available Commands

- `/save-context` — Save current session state to `.contexts/`
- `/restore-context` — Resume from a saved checkpoint
- `@ContextStore` — Full agent for managing context (save, restore, list, clean, compact)
- `@ContextStore compact` — Save context + advise starting a fresh chat (context window reset)

## When to Suggest Saving

If a conversation has been going on for a while and the user seems to be wrapping up
or switching tasks, remind them they can save context with `/save-context`.

## When to Suggest Compacting

The Copilot context window is 200k tokens. Proactively suggest `@ContextStore compact` when:
- The conversation has had many exchanges (>15-20 turns)
- The user reports the model "forgetting" earlier context
- Complex multi-file work has generated lots of tool output
- The user is about to start a significantly different task

Compacting saves everything and lets the user restore in a fresh 200k window.
