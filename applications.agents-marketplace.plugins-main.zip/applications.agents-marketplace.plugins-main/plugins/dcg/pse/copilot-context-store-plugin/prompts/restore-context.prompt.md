---
description: "Restore saved conversation context and resume work from a previous session"
---

# Restore Context

Resume from a previously saved context checkpoint.

1. List all files in `.contexts/` directory, sorted by most recent
2. If multiple exist, show them briefly and ask which to restore (default: most recent)
3. Read the selected checkpoint file
4. Present a brief summary of:
   - What we were doing
   - Where we left off  
   - What the next step is
5. Ask if I want to continue with the planned next step or change direction

Keep the restoration summary concise — the goal is to rebuild context with minimal tokens.
