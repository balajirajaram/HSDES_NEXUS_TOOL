---
description: "Quick-save current conversation context to a checkpoint file for later resumption"
---

# Save Context

Save the current conversation context so I can resume later.

**Important**: Scan the conversation from the very first message to the latest. Do not summarize only recent turns — the original goal and all work performed must be captured, even if they happened early in the session.

Analyze the full conversation and create a compressed checkpoint in `.contexts/` that captures:

1. **Goal**: What was the original goal when this session started? (go back to the first message)
2. **All work done**: Every significant task completed across the entire session, not just recent ones
3. **State**: What's done, what's next?
4. **Decisions**: Key choices made and why (from the entire session)
5. **Files**: Every file touched and why
6. **Resume plan**: Exact steps to continue

Use format: `.contexts/{{datetime}}-{{slug}}.md`

Where `{{datetime}}` is `YYYYMMDD-HHmm` and `{{slug}}` is a 2-3 word kebab-case summary.

Keep the total checkpoint under 2000 tokens. Prioritize actionability over completeness. If the session was long, group tasks under phases rather than listing every micro-step.
