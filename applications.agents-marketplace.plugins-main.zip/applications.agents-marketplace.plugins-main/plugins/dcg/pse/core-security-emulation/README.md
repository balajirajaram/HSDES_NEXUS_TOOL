# core-security-emulation

Core security CSLE/RTL transient-execution side-channel emulation plugin for Intel core_emu platforms (DMR, COR, NWP, etc.).

## What's Included

### Skills
- **core_sle-emulation** — Create, debug, and extend CPU cache side-channel tests (.max files). Covers RRSBA, Meltdown, SYSCALL/IRETQ, VMX G/H, and EMU_CLONE_PATCH CREG patchlet workflows.

### Agents
- **@transientWatch** — Closed-loop test orchestrator: submits emulation runs, watches for completion, interprets 7-layer side-channel verdicts, and autonomously debugs failures by patching source and relaunching.

## Quick Start

1. Install the plugin from the DCG marketplace
2. Set `$MODEL_ROOT` to your emulation model path
3. Set `$SANDBOX_ROOT` to your working directory
4. Use the `core_sle-emulation` skill for test authoring or invoke `@transientWatch` for end-to-end runs

## Owners

- Sayee Santhosh Ramesh (sayee.santhosh.ramesh@intel.com)
- Anil Yatavelli (anil.yatavelli@intel.com)
- Neelima Krishnan (neelima.krishnan@intel.com)
