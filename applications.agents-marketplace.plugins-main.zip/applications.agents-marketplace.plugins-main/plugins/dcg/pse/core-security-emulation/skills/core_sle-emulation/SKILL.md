---
name: core_sle-emulation
description: "Create, debug, and extend CPU cache side-channel emulation tests (.max files) for DMR/COR/NWP CSLE/RTL. USE FOR: writing RRSBA same-IP gadget tests; creating Meltdown RDCL speculative-load tests; adding user-supervisor transitions (int 0x80, retf, ud2→wrmsr, SYSCALL/IRETQ); debugging MAX→m4→iASM build failures; understanding framework limitations; creating A/B mitigation verification tests with IA32_SPEC_CTRL or IA32_ARCH_CAPABILITIES; injecting custom uCode CREG patchlets via EMU_CLONE_PATCH for predictor chicken-bit A/B experiments. Covers proven patterns for protected-mode (USE16) and 64BIT long-mode (USE64) segment setup, IDT gate installation, privilege transitions, cache Flush+Reload timing probes, speculative gadget construction, and FIT patch pipeline for custom CREG overrides. Includes comprehensive 64BIT pitfall catalog (ds: syntax, USER vs DPL, stack RESERVE, deferred evaluation)."
---

# CSLE/RTL Emulation Test Skill

Build and debug CPU microarchitectural side-channel tests (Meltdown, RRSBA) in MAX Perl framework for core_emu RTL emulation.

> **Platform note**: Examples below reference PNC-E0 as the baseline platform.
> Adapt model paths, CPUID, and stepping symbols to your target (DMR, COR, NWP, etc.).

> **Terminology note**: The default test environment in this repo (`-m ucrun` + `zsim`)
> is **uSIM/ucrun** — a *functional/architectural* simulator. "CSLE" properly refers
> to the real RTL co-simulation environment. The two are distinct:
> - **uSIM/ucrun**: fast, deterministic, architecturally-correct. Does NOT model
>   cycle-accurate cache timing. F+R latency probes return identical values for
>   hit vs miss. Good for plumbing/transition/MSR/fault validation.
> - **CSLE (real RTL emulation)**: models actual cache hierarchy and timing.
>   Required for side-channel *observability* validation (e.g., A/B mitigation
>   efficacy measurements).
>
> File names ending in `_csle.max` in this repo are a historical naming convention
> and run under uSIM/ucrun by default. The build flow described here applies to
> both targets, but signal interpretation differs.

## When to Use

- Writing new `.max` speculative-execution tests
- Debugging build failures (MAX→m4→iASM pipeline)
- Adding privilege transitions (CPL=0 ↔ CPL=3) to tests
- Creating A/B mitigation verification tests
- Injecting custom uCode CREG patchlets (EMU_CLONE_PATCH) for chicken-bit experiments
- Understanding why a test FAILs on CSLE/emurun
- Adapting proven patterns to new speculation vectors

## Quick Reference

| Resource | Path |
|----------|------|
| Platform & toolchain | [./references/platform.md](./references/platform.md) |
| MAX framework rules | [./references/max-framework.md](./references/max-framework.md) |
| RRSBA gadget patterns | [./references/rrsba-patterns.md](./references/rrsba-patterns.md) |
| Meltdown gadget patterns | [./references/meltdown-patterns.md](./references/meltdown-patterns.md) |
| Build errors catalog | [./references/build-errors.md](./references/build-errors.md) |
| iASM 64BIT immediate encoding | [./references/iasm-encoding.md](./references/iasm-encoding.md) |
| Pre-Si optimisation recipes (RTL-validated) | [./references/presi-optimization.md](./references/presi-optimization.md) |
| Cross-mode (bit-47 aliasing) + VMX G/H | [./references/cross-mode-and-vmx.md](./references/cross-mode-and-vmx.md) |
| CSLE/RTL cache observability (IDI tracker) | [./references/cache-observability.md](./references/cache-observability.md) |
| EMU_CLONE_PATCH (custom uCode CREG patchlets) | [./references/emu-clone-patch.md](./references/emu-clone-patch.md) |

## Procedure

### Creating a New Test

1. **Choose the template**: Start from a proven PASS test closest to your objective
   - CPL=3 cache probe: `rrsba_sameip_user_csle.max`
   - CPL=0 via int 0x80: `rrsba_sameip_cpl0_csle.max` or `cpl3_baseline_use16_csle.max`
   - A/B mitigation: `rrsba_sameip_dis_u_ab_csle.max`
   - Meltdown RDCL: `meltdown_rdcl_csle.max`

2. **Segment layout**: Use the proven USE16 protected-mode layout (see [platform.md](./references/platform.md))

3. **Privilege transitions**: For int 0x80 from CPL=3, install IDT gate at RUNTIME (not `$idt->handler` which only works for vectors 0-31)

4. **Build**: `-b wmtbuild -bs "MAX_FLAGS='-mode=PM'" -bs-`

5. **Run**: choose by what you need to validate:
   - `-dut ucode -m ucrun` — micro-simulator. Functional only (no cache
     timing, no speculation modelling). **Use this for build validation
     and structural correctness** (privilege transitions, IDT delivery,
     test completes). Much faster turnaround. Ask the user before
     escalating to emurun.
   - `-dut core_emu -m emurun -zebu -c 200000000` — full RTL emulation.
     Required when the verdict depends on **cache-miss timing
     discrimination** or **actual speculation** (Flush+Reload A/B,
     Meltdown RDCL leakage, RRSBA bypass observability). On ucrun these
     tests will produce identical LAT_PROBE values and meaningless verdicts.

6. **Verdict**: EBX=0xACED at hlt → PASS; EBX=0xDEAD → FAIL.

   **WARNING — non-selfchecking PASS trap**: if `.rpt` says
   `PASS Non-selfchecking test passed`, that ONLY means `hlt` was reached.
   It does NOT confirm the gadget executed. A silent #GP in the prologue
   followed by the vector-13 handler hlting will also report PASS. Before
   trusting the result, ALWAYS:
   - Open `zsim_trace_1.log` and confirm the CPL transitions
     (`(16p, CPL=0)` → `(16p, CPL=3)` → `(16p, CPL=0)` → `(16p, CPL=3)`).
   - grep `>>> #GP` in the trace — every fault must be intentional.
   - Check `INSTRUCTIONS:` in `.rpt` is in the hundreds-to-thousands.
     INSTRUCTIONS < 50 means a prologue fault.

### Pre-Build Syntax Checks

**Run these checks BEFORE submitting a .max file for build. Each catches a
known silent killer in the MAX→m4→iASM pipeline.**

1. **No backticks** — m4 uses backtick as open-quote. Any unmatched `` ` `` in
   comments, TITLE, DESC, or heredoc body causes `gm4: ERROR: end of file in string`.
   ```
   grep '`' test.max    # must return ZERO matches
   ```

2. **No duplicate EQUs** — iASM EQUs are GLOBAL across all segments. If the same
   constant name is defined in both ring3_code_seg and MAIN_CODE (e.g., `WITNESS_LIN`),
   iASM errors: `Equate has already been defined`. Define shared constants in ONE
   segment only.

3. **No `[ds:LABEL]`** — iASM rejects segment-override syntax in 64-bit mode.
   Use `mov reg, _linaddr LABEL` then `[reg+offset]`.

4. **No `lea rax, [rip + LABEL]`** — iASM miscomputes RIP-relative in MAX context.
   Use `mov rax, _linaddr LABEL`.

5. **No `.align`** — use `align` (no dot). iASM uses Intel syntax.

6. **Interpolating heredocs (double-quoted `<<"END"`)** — verify no accidental `$`
   or `@` in assembly that would be Perl-interpolated. Only `$variable_name` patterns
   that you intentionally want expanded should appear.

### Debugging Build Failures

**CRITICAL — check files in this order. Skipping a step costs hours.**

1. **First, identify which stage failed** by looking at output file sizes:
   - `.m4` is ~23 lines → MAX/Perl died (see step 2)
   - `.m4` is large but no `.asm` → m4 macro expansion died
   - `.asm` exists but no `.obj` → **iASM (assembler) failed → go to step 3**
   - `.obj` exists but test FAILs → runtime issue (separate flow)

2. **MAX/Perl failure**: grep `.rpt` for `Error 255` and read the line(s)
   immediately above it for the Perl die message.

3. **iASM failure — DO NOT grep `.rpt`. The real error is in `.lst`.**
   The `.rpt` only contains the generic `gmake [.obj] Error 255` line.
   ```powershell
   Select-String -Path *.lst -Pattern '\*\*\*\* ERROR'
   ```
   Then read 15 lines of context around each match to see the offending
   instruction. Also check `Error(s) generated` count near end of file.

4. **Silent iASM miscompiles** (no error, wrong opcode): when a privilege
   transition or interrupt return misbehaves at runtime, inspect the
   assembled opcodes in `.lst` for the relevant instruction. Known traps:
   - `push word ptr (expr)` → opcode `FF36` (mem push), NOT `68` (imm push)
   - `retf` mnemonic → rejected outright; must use `db 0CBh`
   - See [build-errors.md](./references/build-errors.md) for the full list.

5. Common killers and silent traps: see [build-errors.md](./references/build-errors.md)

### Debugging Runtime Failures

1. Check witness segment in memory dump (sentinels: 0xBADCFFEE=not reached, 0xCAFEBABE=reached)
2. If ARCH_TRAIN_DONE=0xBADCFFEE → never entered handler (IDT gate issue)
3. If VERDICT=0xBADCFFEE → gadget crashed before probe
4. If VERDICT=0xDEAD but expected HIT → threshold too low, or MTRR/cache not WB

---

## 64BIT Long Mode — Pitfalls & Proven Patterns

The sections above assume USE16 protected mode (`-mode=PM`). Long-mode
64BIT tests (`-mode=64BIT`) have an entirely different set of traps.
**Every item below was discovered through real build/run failures on PNC-E0.**

### Mode Name

The mode is `64BIT`, NOT `PM64`. Template file is `64BIT_template.pm`.
Valid modes: `64BIT`, `PM`, `COMP`, `RM`, `VM86` (see Generic_template.pm ~line 153).

Build command:
```
-b wmtbuild -bs "MAX_FLAGS='-mode=64BIT'" -bs-
```

### Deferred Evaluation of Framework Directives

`$test->load_segreg()` and `$test->load_ss()` read `$self->{_STATUS}{DEFAULT_MODE}`,
which is ONLY populated during the **print phase** (Testgen.pm:878). Calling them
at code-construction time (e.g., `$code->{CODE} .= $test->load_segreg(...)`)
causes `"MODE undefined" croak at Asmgen.pm:846`.

**Fix**: Put framework directives inside a **single-quoted heredoc** so they are
evaluated at print time, not construction time:
```perl
$code->{CODE} .= <<'CODE';
$test->load_segreg('DS'=>$witness_seg)
$test->load_ss('SS'=>$stack)
CODE
```

### `"USER"` Is NOT a GDT Descriptor TYPE

`"USER"` is a **page table** attribute (sets U/S bit in PTE, IA32.pm line 998).
It is NOT a valid GDT descriptor TYPE keyword.

Valid GDT TYPE values for memory segments:
`RO`, `RW`, `EO`, `ER`, `CONFORM`, `ACCESSED`, `EXPANDDOWN`, `CODE`, `DATA`,
`NONCONFORM`, `NOTACCESSED`, `EXPANDUP`.

To make a segment accessible at CPL=3, set TWO things:
1. `'DPL' => 3` inside `ATTR => {}` — sets the GDT descriptor privilege level
2. `'PAGING_ATTR' => {'USER' => 1}` at the **segment level** (next to CLASS, TID) —
   sets the U/S bit in page table entries

**Wrong** (fatal: `GEN_DESC: Undefined descriptor attribute`):
```perl
$seg = $test->new_seg("CLASS"=>"DATA", "ATTR"=>{
    'TYPE' => ["RW", "USER", "ACCESSED"],   # USER is not a TYPE!
});
```

**Correct**:
```perl
$seg = $test->new_seg("CLASS"=>"DATA",
    'PAGING_ATTR' => {'USER' => 1},          # page-level U/S=1
    "ATTR" => {
        'DPL'  => 3,                          # GDT DPL=3
        'TYPE' => ["RW", "ACCESSED"],         # no USER here
    },
);
```

### `lea rax, [rip + LABEL]` Does NOT Compute RIP-Relative in iASM/MAX

In standard x86-64, `lea rax, [rip + label]` encodes a RIP-relative displacement
that resolves to the label's absolute address at runtime. But in iASM with the MAX
framework, `[rip + LABEL]` adds the label's **segment-base-relative offset** to RIP
as a literal displacement — NOT the true RIP-relative distance.

Example: if `ring0_gadget` is at segment offset `0xE5` and the `lea` is at `0x99`
(RIP_next = `0xA0`), iASM encodes `[rip + 0xE5]` → RAX = `0xA0 + 0xE5 = 0x185`,
not the intended `0xE5`.

**Fix**: Use `_linaddr` to get the absolute linear address:
```asm
  ; WRONG: lea rax, [rip + ring0_gadget]   ; gives rip + segment_offset, not rip-relative
  ; CORRECT:
  mov     rax, _linaddr ring0_gadget        ; framework resolves to absolute VA
```

This affects any use of `[rip + LABEL]` where the label is in the same code segment.
The `lea rip+label` pattern can appear to work if the wrong address happens to
land on valid code (as observed in cpl3_baseline_csle.max where the LSTAR was
wrong but the test still passed by accident).

### iASM Rejects `[ds:LABEL]` in 64-Bit Mode

In 64-bit long mode, iASM rejects `[ds:LABEL]` with `"Error near ':' : syntax error"`.
Segment override prefixes on DS/ES/SS are ignored by hardware in 64-bit mode, and
iASM refuses the syntax entirely for cross-segment label references.

**Fix**: Load the base address into a register with `_linaddr`, then use
register+offset addressing:
```asm
  ; Define offsets from the data block base
  W_CPL0_REACHED  equ 0x04
  W_USER_REACHED  equ 0x08

  ; Load base once
  mov  rbx, _linaddr MY_DATA

  ; Access fields via register+offset
  mov  dword ptr [rbx+W_CPL0_REACHED], 0xCAFEBABE
  mov  eax, dword ptr [rbx+W_USER_REACHED]
```

The framework's own generated code never uses `[label]` in 64-bit mode — it always
uses register-indirect. Follow the same pattern.

### `.align` vs `align`

iASM uses Intel syntax: the directive is **`align`**, not **`.align`** (which is
AT&T/NASM syntax). `.align 4096` → `"Error near '.' : syntax error"`.

### Framework Stack RESERVE is Tiny (0xFF)

In 64BIT mode, Generic_template.pm creates the default `$stack` with
`RESERVE => 0xFF` (only 255 bytes). Only addresses within ~1 page of the stack
BASE get page-table mappings. If your `RING0_RSP` equ points far above the
BASE, pushes will #PF into unmapped pages → #DF → self-check fail.

**Fix**: Override the framework stack RESERVE and keep RSP within it:
```perl
$stack->{ATTR}{BASE} = 0x7FFF0000;
$stack->{RESERVE}    = 0xFFF;       # 4K (framework default is 0xFF)
```
```asm
  RING0_RSP  equ  0x7FFF0FF0       ; within BASE+RESERVE, not 0xF000 above
```

### No Separate ring0_stack_seg Needed

The framework's `$stack` segment IS the ring-0 stack in 64BIT mode. Creating a
second segment at the same OFFSET causes iASM error 15 (`Bytes from previous line
overwrite initialized memory`). Just set `$stack->{ATTR}{BASE}` and
`$stack->{RESERVE}` on the existing `$stack`.

### Proven 64BIT Segment Layout

```
Segment        Linear Base     DPL  Purpose
───────────────────────────────────────────────────────────
code           0x00100000      0    CPL0 main code (framework, override BASE)
data           (auto)          0    CPL0 data (framework)
stack          0x7FFF0000      0    CPL0 stack (framework, override BASE+RESERVE)
witness        0x00C00000      3    Result structure (4K, PAGING_ATTR USER=1)
ring3_code     0x00800000      3    CPL3 test body (16K, PAGING_ATTR USER=1)
ring3_stack    0x7FFE0000      3    CPL3 stack (16K, PAGING_ATTR USER=1)
```

### CRITICAL: MTRR + CR0 Cache Enable (64BIT)

**Without explicit cache setup, memory type defaults to UC on RTL emulation.**
This means speculative loads CANNOT fill the cache, making Flush+Reload
observation impossible. Symptoms: LAT_PROBE ≈ LAT_CONTROL ≈ 4000-5000 cycles
(both DRAM miss, no cache hits ever). The PM/USE16 template may set this
implicitly, but 64BIT does NOT.

**Required prologue** (add BEFORE any memory access that needs caching):
```asm
  ; Clear CR0.CD (bit 30) and CR0.NW (bit 29) — enable caching
  mov     rax, cr0
  and     eax, 0x9FFFFFFF
  mov     cr0, rax

  ; Set MTRR default type to Write-Back, enable MTRRs
  IA32_MTRR_DEF_TYPE  equ 0x2FF
  MTRR_DEFTYPE_WB     equ 0x00000806   ; E=1 (bit 11), type=6 (WB)
  mov     ecx, IA32_MTRR_DEF_TYPE
  mov     eax, MTRR_DEFTYPE_WB
  xor     edx, edx
  wrmsr
  mfence
```

**Proven on RTL**: `rrsba_sameip_dis_s_ab_csle.max` includes this and shows
LAT_PROBE=228 (cache HIT). Same test without it shows LAT_PROBE≈4800 (always DRAM).

### SYSCALL/SYSRET Setup (64BIT Long Mode)

```asm
  ; IA32_STAR[47:32] = kernel CS selector
  mov  ecx, 0xC0000081         ; MSR_STAR
  xor  eax, eax
  mov  edx, 0x00130000
  or   dx, code_sel            ; framework kernel CS
  wrmsr

  ; IA32_LSTAR = SYSCALL landing pad address
  mov  ecx, 0xC0000082         ; MSR_LSTAR
  mov  rax, _linaddr ring0_return   ; MUST use _linaddr, NOT lea [rip+label]
  mov  rdx, rax
  shr  rdx, 32
  wrmsr

  ; IA32_FMASK = clear IF on entry
  mov  ecx, 0xC0000084         ; MSR_FMASK
  mov  eax, 0x200              ; RFLAGS_IF_BIT
  xor  edx, edx
  wrmsr
```

### IRETQ Frame for CPL0→CPL3

```asm
  push  ring3_stack_sel       ; SS  (DPL=3 selector, RPL=3 built-in)
  push  RING3_RSP             ; RSP
  pushfq
  and   qword ptr [rsp], ~0x200  ; clear IF
  push  ring3_code_sel        ; CS  (DPL=3 selector)
  mov   rax, _linaddr user_entry ; absolute linear address
  push  rax                   ; RIP
  iretq
```

### Ring-3 Code in 64BIT: Use Absolute VAs

In ring-3 code (separate `$ring3_code_seg->code(...)` block), access witness
fields by loading their absolute virtual address into a register:
```asm
  mov  rcx, 0x00C0000C       ; absolute VA of CPL_AT_GADGET
  mov  dword ptr [rcx], eax
```
Do NOT use `_linaddr` in ring3 code — it is a framework macro that only works
in the code segment context.

### iASM `-32` Flag Is Normal

The build system passes `-32` to iASM even for 64BIT tests. This is correct —
the test boots in USE16 real mode, transitions through PM, then enters long mode.
The `-32` flag sets the initial output format. USE64 segments within the test
still assemble correctly. Do NOT try to force `-64`.

### No Backticks in `$test->{TITLE}` or `$test->{DESC}`

The framework dumps TITLE and DESC into the `.m4` file. m4 uses backtick (`` ` ``)
as its open-quote character. An unmatched backtick (e.g., `` `syscall` ``) causes
`"ERROR: end of file in string"` at the m4 stage.

**Fix**: Use plain text or uppercase instead of backtick-quoted words:
```perl
# WRONG:  "... a real `syscall` instruction ..."
# CORRECT: "... a real SYSCALL instruction ..."
```

---

## Custom uCode CREG Patchlets (EMU_CLONE_PATCH)

Inject custom CREG overrides into emulation runs via the FIT patch pipeline.
Enables A/B testing of predictor chicken-bits without model rebuild.
See [emu-clone-patch.md](./references/emu-clone-patch.md) for full details.

### Quick Start

1. Clone model patch directory:
   ```
   cp -r $MODEL/debug/emulation/patch_default_server/ ./patch_custom/
   ```
2. Create `.patchlet` in `patch_custom/patchlets/`:
   ```
   applicable_steppings(PNC_E0)
   creg([BPU1_CR_DEBUG3_ADDR] = 0xffffffff:BPU1_CR_DEBUG3_DIS_FFEIP_NOT_TAKEN_MASK)
   ```
3. Add `patchlet(filename.patchlet)` to `patch_custom/patch_default_server.patch`
4. Set envvars in run script:
   ```tcsh
   setenv EMU_CLONE_PATCH $PWD/patch_custom
   setenv EMU_FORCE_PATCH_COMPILATION 1
   ```
5. Submit via `emurun` — patch builds automatically during pre-exec

### Verification

Check `ucode_patch/` in run area for:
- `.pcmd` → your `creg()` line present
- `.summary` → your bug ID + `load_time creg 1`
- `testbench.log` → `IDI_TB: FIT patch load: Expecting to find patch`

### A/B Pattern

- **Run A**: patch_custom WITHOUT your patchlet → baseline
- **Run B**: patch_custom WITH your patchlet → treatment
- Use same seed + `EMU_DISABLE_RANDOM_FLOWS=TRUE` for determinism
- Compare EBX verdict, cycle counts, and bus-trace differences

### Key Gotchas

- `EMU_FORCE_PATCH_COMPILATION=1` is REQUIRED or cached .obj reused
- Never set `UCODE_FIT_PATCH_INC` alongside `EMU_CLONE_PATCH` (different path)
- `FIT_BOOT_DIS` must be 0 (default) for patch load to occur
- CREG symbols live in `creg_ucode.pm` inside the model's patch directory
- Setting a CREG that doesn't affect the active prediction path = no observable change
