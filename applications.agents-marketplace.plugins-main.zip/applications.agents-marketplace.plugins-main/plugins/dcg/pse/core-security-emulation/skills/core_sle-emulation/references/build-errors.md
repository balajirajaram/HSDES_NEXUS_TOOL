# Build Errors Catalog

## Fatal Errors (Build Fails)

### 64BIT Mode — `MODE undefined` at Asmgen.pm:846

**Cause**: `$test->load_segreg()` or `$test->load_ss()` called at code-construction
time (e.g., `$code->{CODE} .= $test->load_segreg(...)`). These methods read
`$self->{_STATUS}{DEFAULT_MODE}`, which is only populated during the **print phase**
(Testgen.pm:878).

**Fix**: Put framework directives in a single-quoted heredoc for deferred evaluation:
```perl
$code->{CODE} .= <<'CODE';
$test->load_segreg('DS'=>$witness_seg)
$test->load_ss('SS'=>$stack)
CODE
```

---

### 64BIT Mode — `GEN_DESC: Undefined descriptor attribute for <name>: USER`

**Cause**: `"USER"` used in `TYPE => [...]` array of a segment ATTR hash.
`USER` is a page table attribute (sets U/S bit in PTE), NOT a valid GDT
descriptor TYPE keyword. Valid GDT TYPEs: `RO`, `RW`, `EO`, `ER`, `CONFORM`,
`ACCESSED`, `EXPANDDOWN`, `CODE`, `DATA`, `NONCONFORM`, `NOTACCESSED`, `EXPANDUP`.

**Fix**: Remove `"USER"` from TYPE. Add `'DPL' => 3` in ATTR and
`'PAGING_ATTR' => {'USER' => 1}` at segment level.

---

### 64BIT Mode — `Error near ':' : syntax error` (iASM, 13+ instances)

**Cause**: `[ds:LABEL]` syntax in 64-bit code. iASM rejects segment override
prefix `ds:` for cross-segment label references in 64-bit mode.

**Fix**: Load base address into a register via `_linaddr`, use register+offset:
```asm
mov  rbx, _linaddr MY_DATA
mov  dword ptr [rbx+0x04], 0xCAFEBABE
```

---

### 64BIT Mode — `Error near '.' : syntax error` (iASM)

**Cause**: `.align 4096` — AT&T/NASM syntax. iASM uses Intel syntax.

**Fix**: `align 4096` (no dot).

---

### 64BIT Mode — `Bytes from previous line overwrite initialized memory` (iASM Error 15)

**Cause**: Two segments at the same address. Typically from creating a
`$ring0_stack_seg` at the same OFFSET as the framework's `$stack`.

**Fix**: Don't create a separate ring0 stack segment. Use the framework's
`$stack` — just set `$stack->{ATTR}{BASE}` and `$stack->{RESERVE}`.

---

### 64BIT Mode — `gm4: ERROR: end of file in string`

**Cause**: Backtick (`` ` ``) anywhere in the .max file that ends up in the .m4
output. m4 interprets backtick as open-quote. An unmatched backtick reads to EOF
looking for the closing apostrophe (`'`).

Common locations where backticks sneak in:
- `$test->{TITLE}` or `$test->{DESC}` strings
- Assembly comments (`;` lines) inside heredocs
- Perl comments (`#` lines) that get passed through

**Symptom**: `.m4` file is generated but conversion to `.asm` fails. Logbook shows:
```
gm4:xmode_ta_sameip_indirect_ab_csle.m4:775: ERROR: end of file in string
gmake: *** [test.asm] Error 1
```

**Fix**: Remove ALL backticks from the .max file. Use plain text in comments.
```asm
; BAD:  ; converge here via `jmp indirect_branch_k`.
; GOOD: ; converge here via jmp indirect_branch_k.
```

**Syntax check rule**: Before submitting a .max file for build, grep for backticks:
```
grep '`' test.max
```
Any match is a potential m4 failure. Remove or replace with quotes/parens.

---

### 64BIT Mode — SYSCALL lands at wrong address (LSTAR off by variable offset)

**Cause**: `lea rax, [rip + LABEL]` used to compute LSTAR. iASM adds the label's
segment-offset value as a literal displacement to RIP, not the true RIP-relative
distance. Result: LSTAR = RIP_next + label_offset, not label_absolute_VA.

**Symptom**: SYSCALL enters the wrong code address. May silently succeed if the
wrong address happens to contain valid code, or may #PF/crash into zero-fill.

**Fix**: Use `mov rax, _linaddr LABEL` instead of `lea rax, [rip + LABEL]`.

---

### `Entry name for IDT Segment (idt) not defined`

**Cause**: `$idt->handler()` called with vector > 31 (e.g., `'VECTOR'=>0x80`), OR with unsupported parameters like `'DPL'=>3`.

**Fix**: 
- For vectors > 31: remove `$idt->handler` call entirely. Install IDT gate at **runtime** via memory writes (see max-framework.md).
- For DPL issue: only pass `'VECTOR'` and `'CODE'` to `$idt->handler()`.

**Signature in .rpt**:
```
Entry name for IDT Segment (idt) not defined
  at (eval 9) line 379
gmake: *** [test.m4] Error 255
```

---

### `Odd number of elements in hash assignment at Segment.pm line 765`

**Cause**: Unrecognized key-value pair in `$idt->handler()` or `$test->new_seg()`. The extra key makes the hash have an odd element count.

**Fix**: Remove unsupported parameters. For `handler()`, only use `'VECTOR'` and `'CODE'`.

---

### Labels not resolving in handler CODE

**Cause**: Handler CODE passed to `$idt->handler()` assembles in a **separate context**. Labels from the main `$code->{CODE}` block are not visible.

**Fix**: Make handler self-contained (no cross-context label references), OR move handler code inline into `$code->{CODE}` with a label.

---

### `.m4` file only 23 lines

**Cause**: MAX Perl died during expansion. The file only contains the header comments. A fatal Perl error prevented code generation.

**Fix**: Look for the `Error 255` line in `.rpt` and the Perl error immediately above it.

---

### `**** ERROR 1 **** Unknown instruction mnemonic` at `retf`

**Cause**: iASM (PantherCove -32) does NOT accept the `retf` mnemonic. Confirmed
on PNC-E0 24ww14a model. `iretd` IS accepted.

**Symptom**: `.rpt` shows `gmake: *** [test.obj] Error 255`. The actual
`**** ERROR 1 ****` line is in `<test>.lst`, not `.rpt`.

**Fix**: Emit the opcode directly:
```asm
db 0CBh   ; retf (16-bit far ret, no immediate)
```
For inter-privilege returns the CPU still pops SS:SP based on target CS RPL.

---

### `push word ptr (expr)` silently builds wrong code

**Cause**: iASM treats `word ptr <expr>` as a memory operand (`m16`), so
`push word ptr (sel | 3)` assembles to opcode `FF 36 xxxx` (`push m16` =
push from `[xxxx]`) instead of `68 xxxx` (`push imm16`). NO assembler error
is raised — the test silently pushes garbage.

**Diagnostic**: Inspect `.lst`. Immediate-push has opcode `68 xxxx`. Memory-push
shows `FF36 xxxx`.

**Fix** (proven pattern from cpl3_step2_retf_csle.max):
```asm
mov ax, ring3_stack_sel   ; MAX-built DPL=3 selectors already carry RPL=3
push ax                   ; SS3
mov ax, 0x0FFE
push ax                   ; SP3
mov ax, ring3_code_sel
push ax                   ; CS3
mov ax, offset ring3_entry
push ax                   ; IP3
db 0CBh                   ; far retf
```

Do NOT add `| 3` — `$test->new_seg(... DPL=>3)` already encodes RPL=3 in the
emitted selector value.

---

## Warnings (Usually Harmless)

### `Argument "max" isn't numeric in bitwise and (&) at Seed.pm line 66`

**Cause**: Seed.pm parsing issue in the toolchain. Harmless.

**Action**: Ignore.

---

### `Use of uninitialized value in pattern match at Max.pm line 283`

**Cause**: Framework internal warning during segment processing. Appears multiple times.

**Action**: Ignore — look for actual fatal errors below these.

---

### `Hexadecimal number > 0xffffffff non-portable at Segment.pm`

**Cause**: 64-bit hex literals in 32-bit Perl. Appears for addresses like 0xFFE00000.

**Action**: Ignore — the framework handles this correctly despite the warning.

---

### `Use of uninitialized value in numeric eq at Generic_template.pm`

**Cause**: Template processing internal. Harmless.

**Action**: Ignore.

---

### `"my" variable @ISA masks earlier declaration`

**Cause**: Framework internal redeclaration. Harmless.

**Action**: Ignore.

---

## Runtime Failures (Build OK, Test FAILs)

### 64BIT Mode — `#PF` at `push` in IRETQ frame setup → `#DF` → self-check fail

**Cause**: `RING0_RSP` points to an address far above the stack segment BASE,
but the framework stack only has `RESERVE=0xFF` (255 bytes). Only addresses
within ~1 page of BASE get page-table entries. Pushes to unmapped pages #PF.
With no IDT handler, this cascades to #DF and self-check failure.

**Signature**: `EID: 97576 self check test failed`, `CONVERTOR_CHECKPOINT: at 28.73`,
66 instructions, #PF at the `push ring3_stack_sel` address.

**Fix**: Override framework stack RESERVE and keep RSP within it:
```perl
$stack->{RESERVE} = 0xFFF;   # 4K (default is 0xFF = 255 bytes!)
```
```asm
RING0_RSP  equ  BASE + 0xFF0  ; within the reserve, not 0xF000 above
```

---

### All sentinels still 0xBADCFFEE

**Diagnosis**: Handler was never entered. IDT gate not installed correctly.

**Check**:
- Is the full 8-byte gate written? (Not just byte 5)
- Is the selector correct? (`cs` at time of write = CPL0 code selector)
- Is the offset correct? (Must be code-segment-relative offset of handler label)

---

### ARCH_TRAIN_DONE = 0xCAFEBABE but VERDICT = 0xBADCFFEE

**Diagnosis**: Crashed between training and verdict (likely in RSB drain or trigger phase).

**Check**:
- Stack overflow in push chain (4 KiB kernel stack with 42×2 = 84 bytes + training pushes)
- Missing `add esp` after push chain

---

### VERDICT = 0xDEAD (expected HIT but got MISS)

**Diagnosis**: RRSBA not predicting, or cache not in WB mode.

**Check**:
- MTRR initialization present? (All memory defaults UC without it)
- reload_buf address in valid WB range?
- Enough training iterations? (100 is proven)
- SPEC_CTRL accidentally set? (Should be 0 for baseline)

---

### #GP during prologue (before retf)

**Diagnosis**: Segment setup issue.

**Check**:
- TSS loaded before `ltr`?
- All segment selectors valid?
- `cpl0_kstack` has sufficient size for exception frames?

---

## Debugging Workflow

1. **Check `.rpt`**: `Select-String -Path "*.rpt" -Pattern "Error|FAIL|Entry name|gmake"`
2. **Check `.m4` line count**: If ~23 lines → Perl died during expansion
3. **If build OK but runtime FAIL**: Check witness segment in dump for sentinel values
4. **Progressive diagnosis**: Which sentinel was last written to 0xCAFEBABE? That's the last phase reached.
