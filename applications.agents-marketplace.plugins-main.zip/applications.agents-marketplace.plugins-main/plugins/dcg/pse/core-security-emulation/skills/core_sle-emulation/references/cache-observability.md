# CSLE / RTL Cache Observability (PNC core_emu, ZeBu ZSE4)

## Bottom Line
- CSLE DOES model caches + the IDI bus. PMU and `rdtsc` look flat on CSLE for
  most microarch workloads only because boot leaves MTRRs disabled. With
  proper setup, side-channel observation works at the **bus-trace level**.
- The ONLY ground-truth observation channel that works reliably is
  `bfm_tracker_0.uncore.log` (IDI bus trace). Open this FIRST when triaging
  any cache/coherence question.

## Proven WB-MTRR Prologue (single wrmsr, no wbinvd)
```asm
mov ecx, 0x2FF        ; IA32_MTRR_DEF_TYPE
mov eax, 0x00000806   ; E=1, FE=0, default type=WB
xor edx, edx
wrmsr
```
- Readback at DS witness slot expected = `0x00000806`.
- DO NOT use `wbinvd` in CSLE tests: BFM `IDIUncoreTestbench.so` is missing
  `IDI::CIDIMemory::LLCFlushOnlyAccessedLines(...)` symbol. Crashes the sim
  even with `WBINVD_SKIP_LLC_FLUSH=ON`. Program MTRRs on cold caches only.

## Address-Space Gotchas
- Build's `RSV_PHYS_RANGES` includes `0x200000–0x4FFFFF`. Any segment placed
  there (e.g. legacy `reload_buf` @ `0x00400000`) generates ZERO bus traffic —
  the BFM intercepts before it reaches the IDI tracker. Move oracles to
  `0x00500000+` (or any non-reserved range).
- Proven bus-observable address: `0x00500000` (`oracle_probe_csle`, ww18).
- Bus traffic to our oracle came back as `PRd` (Partial Read / uncached),
  NOT `DRd_Opt`, even with WB defType. Address-level observability still
  works — opcode does not matter for side-channel detection. The segment is
  being treated as UC by the LLC modeller despite WB defType (root cause not
  yet determined; non-blocking).

## Triage One-Liners (PowerShell)
```powershell
# DS witness slots @ 0x9000
Select-String -Path "$run\idi_tb.mem.dump.end" -Pattern "^00009[0-3]"

# Bus traffic to our oracle region (any opcode)
Select-String -Path "$run\bfm_tracker_0.uncore.log" -Pattern "0000000[5][0-9a-fA-F]{5}"

# What address ranges ARE active on the bus?
Select-String -Path "$run\bfm_tracker_0.uncore.log" `
              -Pattern "DRd_Opt\s+([0-9a-fA-F]{7})" |
    % { $_.Matches[0].Groups[1].Value } | Group-Object |
    Sort Count -Desc | Select -First 10
```

## False-Positive Fail Signals to Ignore
- `EID 5524: IDI Credits mismatch` — if it fires AFTER `EBX=0xACED` and
  `HLT`, it is post-HLT checker noise (1 credit unreturned at shutdown), not
  a functional failure. Confirm in `testbench.log` that
  `EBX register is 0x0000aced` before treating EID 5524 as real.

## Saved-MSR Dumps Lie
- `archsim_msr.def.saved_by_setMSR` is a **build-time enumeration**, not the
  runtime register file. Variable MTRRs may be listed as occupied here while
  all 10 are actually zero at runtime. Always confirm with `rdmsr` from
  inside the test.

## Files That Matter in a Run Dir
| File                          | Purpose                                            |
| ----------------------------- | -------------------------------------------------- |
| `bfm_tracker_0.uncore.log`    | IDI bus trace — ground truth                       |
| `idi_tb.mem.dump.end`         | Memory @ HLT (DS witness slots)                    |
| `testbench.log`               | EBX, sleep reason, end-of-test checkers            |
| `simics.out.log`              | Library load errors (symbol-lookup failures here)  |
| `logbook.log`                 | Build summary — grep `FATAL` for parser errors     |

## ucrun (uSIM) vs emurun (RTL) Quick Reference
| Aspect                   | ucrun (uSIM)         | emurun (CSLE/RTL)        |
| ------------------------ | -------------------- | ------------------------ |
| Cache model              | NO                   | YES (LLC + IDI)          |
| Speculation model        | NO                   | YES                      |
| F+R latency signal       | flat (~30c always)   | HIT≈224, MISS≈280        |
| Use for                  | plumbing / faults / IDT / MSR | side-channel verdicts |
| Cycle budget             | seconds              | minutes-to-tens-of-minutes |
| End-of-test              | `EBX=0xACED` at HLT  | `EBX=0xACED` at HLT      |
