# Cross-Mode (Bit-47 Aliasing) and VMX Guest/Host Patterns

## Bit-47 Aliasing for User↔Supervisor Same-IP (64BIT)

### Core Concept
The BTB does NOT use bit 47 for index/tag matching. Stripping bit 47 from a
kernel address (`addr & 0x7FFFFFFFFFFF`) gives a user-space address that
aliases to the same BTB slot. This is the Linux PoC technique (`poc_app.c`).

### Address Layout
```
User gadget:    VA 0x0000000000800000   (USER page, DPL=3)
Kernel gadget:  VA 0xFFFF800000800000   (SUPERVISOR page, DPL=0)
                       ↑
                bit-47 set / cleared — both alias to the same BTB slot
```

### Test Pattern
1. CPL=3 trains BTB at user gadget VA (low canonical half).
2. Transition to CPL=0 (int 0x80 / SYSCALL / IRETQ as appropriate).
3. CPL=0 jumps through indirect predictor at the corresponding high-canonical
   VA (`addr | 0xFFFF800000000000`).
4. BTB delivers user-trained target speculatively → encode secret into F+R buffer.
5. CPL=3 probe → verdict.

Mitigation (IPRED_DIS_S / RRSBA_DIS_S) must clear that high-canonical prediction.

---

## VMX Guest→Host Side-Channel Pattern

Reference: `ke/duibp_eibrs_gh/max/eibrs_gh_indirect_ab_csle.max`.

### Architecture
- Uses standard `64BIT_template.pm` (NOT LT1/VT3 VMX template).
- Manual VMCS setup via `vmwrite` (~50 fields).
- Same CR3 shared between guest and host (identity-mapped).
- Guest and host execute indirect branch at the SAME VA (`0x00800000`).
- eIBRS G/H VMX-mode tag is the protection boundary.

### VMX Setup Sequence
1. `CR4.VMXE = 1`
2. CR0 fixup from `IA32_VMX_CR0_FIXED0` (MSR 0x486)
3. CR4 fixup from `IA32_VMX_CR4_FIXED0` (MSR 0x488)
4. Read VMCS revision from `IA32_VMX_BASIC` (MSR 0x480, bits 30:0)
5. Write revision into VMXON region (4KB @ 0x02000000) and VMCS region (4KB @ 0x02001000)
6. `vmxon  [region_ptr]`
7. `vmclear [vmcs_ptr]`
8. `vmptrld [vmcs_ptr]`
9. ~50 `vmwrite` calls for controls + guest + host state
10. `vmlaunch`

### Key VMCS Configuration
- Execution controls: read must-be-1 from MSRs `0x481–0x484`, OR in desired bits.
- `PROCCTRL bit 24` = unconditional I/O exit (OUT-triggered VMEXIT).
- `PROCCTRL bit 28` = use MSR bitmaps (MUST set if guest RDMSR/WRMSR shouldn't exit).
- `EXITCTRL  bit 9`  = 64-bit host.
- `EXITCTRL  bit 21` = load `IA32_EFER` on exit (host EFER recovery).
- `ENTRYCTRL bit 9`  = IA-32e mode guest.
- `ENTRYCTRL bit 14` = load `IA32_EFER` on entry (guest SYSCALL needs SCE=1).
- `VMCS_LINK_PTR = -1` → `xor rax,rax; not rax; vmwrite ...`.
- `VMCS_SECONDARY_CTRL` MUST be written when proc-based bit 26 is must-be-1
  (read from MSR `0x48B`).
- `VMCS_GUEST_PERF_GLOBAL` (`0x2808`) MUST be written when entry bit 12 is
  must-be-1 (set to 0).

### PNC-E0 Must-Be-1 Bits (capability MSRs)
- **Pin-based (0x481)**: bits 1, 2, 4 — harmless.
- **Proc-based (0x482)**: 1, 4, 5, 6, 8, 13, 14, **15 (CR3-load exit!)**,
  **16 (CR3-store exit!)**, **26 (activate secondary!)**.
- **Exit (0x483)**: bits 0–8, 10, 11, 13, 14, 16, 17 — reserved, nothing dangerous.
- **Entry (0x484)**: bits 0–8, **12 (load PERF_GLOBAL_CTRL!)**.

### CRITICAL: CR3-load/store Exiting Is Must-Be-1 on PNC-E0
- Guest CANNOT use `mov rax, cr3` or `mov cr3, rax` without VMEXIT.
- **Framework page tables live at HIGH PA (>2GB) → NOT identity-accessible.**
  CR3=0xeb890000, PDPT at 0xc0560000 — outside the identity map.
- **Solution: build CUSTOM guest page tables inside the VMX region**
  (`vmx_region @ 0x02000000`):
  - PML4/PDPT/PD at `0x02003000–0x02006000`.
  - 2MB pages, USER bit on all entries, covers 0–2GB.
  - `VMCS_GUEST_CR3` = custom PML4 PA (NOT host CR3).
  - Host keeps the framework's CR3 unchanged.
- `INVLPG` is safe in guest (bit 9 NOT must-be-1).
- CR4 writes are safe with mask=0 (guest owns all bits, no exit).

### A/B Pattern
- Pass A: Host IBRS=0 after VMEXIT → no G/H tag check → HIT (if not always-on).
- Pass B: Host IBRS=1 after VMEXIT → G/H tag enforced → MISS.
- VMRESUME for Pass B (update guest RIP and host RIP in VMCS between passes).
- Expected on PNC-E0: both MISS (eIBRS always-on, G/H tag always enforced).

### VMEXIT Flow
1. Guest trains BTB (100 iterations of push/clflush/BHB/pop/`jmp rsi` → disclosure gadget).
2. Guest does `out dx, al` (`DX=0xE8`) → I/O VMEXIT (reason `0x1E`).
3. Host VMEXIT handler: `wrmsr IBRS`, flush probe line, execute indirect branch at
   same VA, probe with `rdtsc`.

### Build/Run
```
-b wmtbuild -bs "MAX_FLAGS='-mode=64BIT'" -bs-
-dut core_emu -m emurun -zebu -c 200000000
```

### Pitfalls
- `mov rax, 0xFFFFFFFF` only gives 32-bit zero-extended! Use `xor rax,rax; not rax`
  for full -1.
- In 64-bit mode, a single `vmwrite` suffices for 64-bit VMCS fields (no `_HI` needed).
- `vmxon`/`vmclear`/`vmptrld` take a 64-bit memory operand (pointer to PA of region).
- Host selectors must have RPL=0 (`and eax, 0xFFFC` after reading).
- VMCS regions must be 4KB aligned.
- Guest shares host page tables → `_linaddr` labels resolve correctly for both.
- **ALWAYS read capability MSRs and check must-be-1 bits before first run.**
- `IA32_FEATURE_CONTROL` (0x3A) must be locked with VMX-outside-SMX enabled (write 0x5).
- Host TR selector CANNOT be 0 — CSLE framework doesn't load TSS; you must add your own.
- iASM may not support `|` in expressions — use separate OR instructions.
