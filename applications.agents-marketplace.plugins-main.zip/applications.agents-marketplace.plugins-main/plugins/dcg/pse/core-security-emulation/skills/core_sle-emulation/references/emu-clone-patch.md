# EMU_CLONE_PATCH — Custom CREG Patchlet Workflow

Inject custom uCode CREG overrides into PNC-E0 emulation runs via the FIT
patch pipeline. Enables A/B testing of individual BPU/predictor chicken-bit
configurations without rebuilding the model.

## Overview

The emulation model ships a default patch directory (`patch_default_server/`)
containing `.patchlet` files that program CREGs at boot. By cloning this
directory and adding custom patchlets, you can override any CREG bit and have
it applied during FIT patch load — before test code executes.

## Pipeline

```
run_test script
  ├── setenv EMU_CLONE_PATCH ./patch_custom
  ├── setenv EMU_FORCE_PATCH_COMPILATION 1
  └── emurun submission
         │
         ▼
emul_TREX.pm → Emulation_stress_gen.py
         │  Checks: FIT_BOOT_DIS=0 && EN_FIT_PATCH_LOAD=1
         ▼
build_patch.py
  ├── reads patch_default_server.patch (recipe)
  ├── reads patch_template.template
  └── reads patchlets/*.patchlet
         │
         ▼
build_patchlets → .pcmd
build_patch_pcmd → _bios.inc
inc2obj_core_emu.py → .obj
         │
         ▼
Output: core_emu_fit_patch_table.obj
        core_emu_patch_fit.obj
        patch_default_server_bios.inc
         │
         ▼
ZeBu FIT Patch Load (hardware boot)
  Physical base: 0xFFEAF390
  /origin 3ffabce4 (DWORD-addressed in .obj)
  CREGs applied by uCode patch loader during BIOS init
```

## Directory Layout

```
$SANDBOX/
├── run_test_clone_patch              ← tcsh script with EMU_ envvars
├── patch_custom/                     ← cloned from model's patch_default_server/
│   ├── patch_default_server.patch    ← recipe file (add patchlet line here)
│   ├── patch_template.template       ← FIT patch template (do not modify)
│   └── patchlets/
│       ├── (original model patchlets)
│       └── YOUR_CUSTOM.patchlet      ← custom CREG override
└── run_area/
    └── ucode_patch/                  ← built artifacts (.obj/.inc/.pcmd/.summary)
```

## Patchlet File Format

```
# b13015253979.patchlet — Workaround description
applicable_steppings(PNC_E0)
creg([CREG_ADDR_SYMBOL] = value:CREG_MASK_SYMBOL)
```

### Syntax Rules
- `applicable_steppings(PNC_E0)` — required; matches CPUID stepping
- `creg([ADDR] = value:MASK)` — sets masked bits at the CREG address
- `value` is typically `0xffffffff` (all-ones through the mask)
- `MASK` is a symbol from `creg_ucode.pm` (e.g., `BPU1_CR_DEBUG3_DIS_FFEIP_NOT_TAKEN_MASK`)
- ADDR is also a symbol (e.g., `BPU1_CR_DEBUG3_ADDR`)
- Lines starting with `#` are comments
- No Perl/m4 interpolation — plain text file

### Example: Disable FFEIP not-taken prediction

```
applicable_steppings(PNC_E0)
creg([BPU1_CR_DEBUG3_ADDR] = 0xffffffff:BPU1_CR_DEBUG3_DIS_FFEIP_NOT_TAKEN_MASK)
```

Resolves to: CREG address `0b0000110110111`, mask `0x0000000004000000` (bit 26).

## Recipe File Modification

Add one line to `patch_custom/patch_default_server.patch`:
```
patchlet(b13015253979.patchlet)
```
Place it among the other `patchlet(...)` lines (e.g., line 163 area).

## Required Environment Variables

| Variable | Value | Purpose |
|----------|-------|---------|
| `EMU_CLONE_PATCH` | Path to custom patch dir | Redirects patch build to your directory |
| `EMU_FORCE_PATCH_COMPILATION` | `1` | Forces rebuild even if cached .obj exists |
| `EMU_DISABLE_RANDOM_FLOWS` | `TRUE` | (Optional) Suppresses BFM runtime randomness for determinism |

**IMPORTANT**: `EMU_DISABLE_RANDOM_FLOWS=TRUE` does NOT block patch build —
it only suppresses BFM runtime randomness.

## Run Script Template (tcsh)

```tcsh
#!/bin/tcsh
setenv EMU_CLONE_PATCH $PWD/patch_custom
setenv EMU_FORCE_PATCH_COMPILATION 1
setenv EMU_DISABLE_RANDOM_FLOWS TRUE

# Standard emurun submission
run_test -test YOUR_TEST.max \
    -dut core_emu -m emurun -zebu -c 200000000 \
    -b wmtbuild -bs "MAX_FLAGS='-mode=PM'" -bs- \
    -seed 1
```

## Verification: Confirming Patchlet Was Loaded

Check these artifacts in the run area's `ucode_patch/` directory:

| Artifact | What to look for |
|----------|-----------------|
| `.pcmd` | `source_file(file=patchlets/YOUR.patchlet, ...)` + your `creg()` line |
| `.summary` | Your bug ID + `load_time ... creg 1` |
| `.msummary` | Total CREG count includes yours (`load_time creg N`) |
| `testbench.log` | `IDI_TB: FIT patch load: Expecting to find patch in ... core_emu_patch_fit.obj` |

## Finding CREG Symbols

CREG address and mask symbols are defined in `creg_ucode.pm` within the model:
```
$MODEL/debug/emulation/patch_default_server/creg_ucode.pm
```

Search pattern:
```powershell
Select-String -Path creg_ucode.pm -Pattern "BPU1_CR_DEBUG3"
```

Common BPU debug CREGs:
| Symbol | Address | Notes |
|--------|---------|-------|
| `BPU1_CR_DEBUG3_ADDR` | `0b0000110110111` | General BPU debug register 3 |
| `BPU1_CR_DEBUG3_DIS_FFEIP_NOT_TAKEN_MASK` | `0x04000000` (bit 26) | Disables FFEIP not-taken |

## Behavioral Expectations

- Setting a CREG that does NOT affect the test's active prediction path
  produces NO observable change (e.g., disabling FFEIP while attacking TA
  yields same ACED result with near-identical cycle count).
- To observe behavioral change, target a CREG that controls the ACTIVE
  attack/prediction path for your test.
- Clock jitter of ~80K cycles between runs is normal ZeBu noise.

## Common Mistakes

1. **Forgetting `patchlet()` line in recipe** — patchlet file exists but
   never gets compiled. Check `.summary` for your bug ID.
2. **Wrong stepping** — `applicable_steppings(PNC_E0)` must match the model.
   Wrong stepping = patchlet silently skipped.
3. **Missing `EMU_FORCE_PATCH_COMPILATION`** — cached .obj from previous run
   used; your new patchlet ignored.
4. **Using `UCODE_FIT_PATCH_INC`** — this envvar triggers a DIFFERENT code
   path (pre-built .inc inclusion) and SKIPS `build_patch.py` entirely.
   Never set it alongside `EMU_CLONE_PATCH`.
5. **FIT_BOOT_DIS=1** — disables FIT patch load entirely. Ensure it's 0
   (default) or unset.

## A/B Testing Pattern

For controlled experiments comparing "with CREG" vs "without CREG":

1. **Run A (baseline)**: Clone patch dir WITHOUT your custom patchlet
2. **Run B (treatment)**: Clone patch dir WITH your custom patchlet
3. Compare: cycle count, EBX verdict, and any bus-trace differences

Both runs should use identical seeds (`-seed 1`) and `EMU_DISABLE_RANDOM_FLOWS=TRUE`
for maximum determinism.

## Proven Results (Example: PNC-E0)

| Run | Custom CREG | Result | Clocks |
|-----|-------------|--------|--------|
| Baseline (no extra patchlet) | None | ACED | ~18.26M |
| `dis_ffeip_not_taken=1` | `DEBUG3[26]=1` | ACED | ~18.34M |

Model: `$MODEL_ROOT` (validated on PNC-E0, ZeBu ZSE4, seed=1).
