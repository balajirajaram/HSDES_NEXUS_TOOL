# iASM 64BIT Encoding Pitfalls (Immediate Operand Sizes)

## Immediate Operand Size Limits

**Rule**: In x86-64, ALU instructions (`AND`, `OR`, `ADD`, `SUB`, `CMP`, …)
with a 64-bit register operand can only encode a **sign-extended 32-bit immediate**.

**Encodable ranges**:
- `0x00000000` – `0x7FFFFFFF` (positive, fits in 32 bits)
- `0xFFFFFFFF80000000` – `0xFFFFFFFFFFFFFFFF` (negative / high-set, sign-extends from 32-bit)

**NOT encodable**: any positive value > `0x7FFFFFFF` (e.g. `0x000FFFFFFFFFF000`).

### Common PTE Mask Patterns

| Pattern                                | Encodable? | Reason                                  |
| -------------------------------------- | ---------- | --------------------------------------- |
| `and rax, 0xFFFFFFFFFFFFF000`          | YES        | Sign-extends from `0xFFFFF000`          |
| `and rbx, 0x000FFFFFFFFFF000`          | **NO**     | Positive 48-bit value, > 32 bits        |
| `and eax, 0x9FFFFFFF`                  | YES        | 32-bit op, zero-extends                 |
| `or qword ptr [rcx+X], 4`              | YES        | Small positive immediate                |

### Fix for PTE Address Extraction (PA < 4GB)
Instead of: `and rbx, 0x000FFFFFFFFFF000` (FAILS)
Use: `and ebx, 0xFFFFF000` (zero-extends to 64 bits, clears bits 63:32 and 11:0).

This works when physical addresses are below 4GB (identity-mapped CSLE tests).

### Fix for General Case (PA might be > 4GB)
```asm
mov rdi, 0x000FFFFFFFFFF000
and rbx, rdi
```

`mov r64, imm64` always has a dedicated 10-byte encoding and is unrestricted.

## Pre-Build Scan (run before submitting)

Cannot run iASM on Windows, so manually scan for:
1. Any `and|or|add|sub r64, imm` where imm doesn't fit sign-extended 32-bit.
2. `jmp $-2` in a double-quoted heredoc → must escape as `jmp \$-2`.
3. Cross-segment `_linaddr` → OK in double-quoted heredocs (Perl interpolates
   `_linaddr` macro at print time).

```powershell
# Catch large immediates with 64-bit registers (heuristic)
Select-String -Path *.max `
    -Pattern '\b(and|or|add|sub)\s+r\w+,\s*0x[0-9a-fA-F]{9,}'
```

## Error Signature in `.lst`
```
**** ERROR N **** Value too large to encode
```
Means an immediate operand exceeds the instruction's encoding capacity.
The `.rpt` only shows `gmake: *** [test.obj] Error 255` — always open `.lst`.

## Related Pitfalls (cross-references)
- `retf` mnemonic rejected → use `db 0CBh`. See `build-errors.md`.
- `push word ptr (expr)` silently builds memory-push opcode `FF36`. See `build-errors.md`.
- iASM is case-insensitive for all symbol kinds (EQU = label = data label).
  Define each name once across heredocs.
- Hex literals `> 0xFFFFFFFF` trigger Perl "non-portable" warnings; if cascaded,
  split a `dq 0xDEADBEEFDEADBEEF` into two `dd 0xDEADBEEF`.
- `&SIGNAL_PASS(0acedh)`: Perl can't evaluate iASM hex syntax; use
  `&SIGNAL_PASS()` (no arg) and set EBX explicitly before HLT.
