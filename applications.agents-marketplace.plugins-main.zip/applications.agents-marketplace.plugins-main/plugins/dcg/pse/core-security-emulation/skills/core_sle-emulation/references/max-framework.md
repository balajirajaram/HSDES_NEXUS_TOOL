# MAX Framework Rules & Syntax

## Heredoc Patterns

| Style | Interpolates? | Use For |
|-------|---------------|---------|
| `<<'LABEL'` | No | Assembly containing `$` (e.g., `jmp $`) or `@` |
| `<<"LABEL"` | Yes | Code needing Perl variables (`$push_chain`, `$sled`) |
| `<<'CODE'` … `CODE` | No | Framework directives (`$test->load_segreg(...)`) |

**Danger**: Assembly `$` (current IP) in a double-quoted heredoc gets eaten by Perl. Always use single-quoted heredocs for ring3 code containing `jmp $`.

## Framework Segment Creation

```perl
$my_seg = $test->new_seg("CLASS"=>"DATA", "ATTR"=>{
    'NAME'    => "my_seg_name",
    'BASE'    => 0x32000,
    'SIZE'    => "USE16",
    'LIMIT'   => 0xFFF,
    'RESERVE' => 0xFFF,
    'TYPE'    => ["RW", "ACCESSED"],
    'DPL'     => 3,
});
```

Valid CLASS values: `"CODE"`, `"DATA"`, `"STACK"`, `"TSS"`

The framework auto-generates `<name>_sel` for each segment (e.g., `witness_sel`, `ring3_code_sel`).

## Code Emission

```perl
# Framework directives (single-quoted, processed by MAX)
$code->{CODE} .= <<'CODE';
$test->load_segreg('DS'=>$data)
$test->load_ss('SS'=>$stack)
CODE

# Assembly code (inline, interpolated for Perl vars)
$code->{CODE} .= <<"ASM";
  mov eax, 0x12345678
$my_perl_var
  ret
ASM
```

## Ring-3 Code Segment

```perl
$ring3_code_seg->code(<<'RING3_CODE');
ring3_entry:
  mov ax, witness_sel
  mov ds, ax
  int 0x80
  hlt
  jmp $          ; safe: single-quoted heredoc
RING3_CODE
```

## IDT Handlers

### Framework API (vectors 0-31 ONLY)

```perl
$idt->handler('VECTOR'=>6,  'CODE'=>'&END_OF_TEST');       # simple redirect
$idt->handler('VECTOR'=>13, 'CODE'=><<'GP_HANDLER');       # inline handler
  add esp, 4                    ; pop error code
  mov eax, dword ptr ds:[0x08]  ; read redirect address
  mov dword ptr [esp], eax      ; overwrite saved EIP
  iretd
GP_HANDLER
```

**ONLY** `'VECTOR'` and `'CODE'` are valid parameters. No `'DPL'`, no `'TYPE'`.

### Runtime IDT Writes (vectors ≥ 32, e.g., int 0x80)

**THREE things must be done together; missing any one causes false-PASS or triple-fault.**

1. **Flat DS**: `sidt` returns a LINEAR address (e.g. ~0xd8d0c900) outside the limit of the small `$data` segment. Without a flat segment for DS, the very first IDT write #GPs.
2. **66h prefix on sidt/lidt**: In USE16 without `66h`, sidt/lidt use the **286 legacy format (24-bit base)** and silently truncate the high byte. ebx ends up wrong; writes go to unmapped memory; lidt installs a truncated base. Must prefix with `db 66h`.
3. **Widen IDTR.limit**: The framework's default IDT limit is < 0x400. Without `lidt` widening it, the gate bytes are written successfully but the CPU rejects dispatch with `"#GP, offset (0x400) not within IDT limit"`.

If any step is missing, the test "PASSes" via the #GP → vector-13-handler → hlt accident. ALWAYS verify with `zsim_trace_1.log`.

```perl
$flat_seg = $test->new_seg("CLASS"=>"DATA", "PHYSMAP"=>'LINEAR', "ATTR"=>{
    'NAME'     => "flatds",
    'BASE'     => 0x0,
    'SIZE'     => "USE16",
    'LIMIT'    => 0xFFFFF,        # with GRANULAR=1 -> 4 GiB
    'GRANULAR' => 1,
    'RESERVE'  => 0xFFF,
    'TYPE'     => ["RW", "ACCESSED"],
    'DPL'      => 0,
});
```

```nasm
  ; (1) Point DS at the flat segment for the IDT writes
  mov ax, flatds_sel
  mov ds, ax

  ; (2) Get IDT base -- 66h prefix MANDATORY in USE16
  sub esp, 8
  db 66h
  sidt [esp]                      ; 16-bit limit + 32-bit base
  mov ebx, dword ptr [esp+2]      ; full 32-bit IDT base (linear)
  add esp, 8

  ; Write 8-byte gate: IDT[0x80] at base + 0x80*8 = base + 0x400
  mov eax, offset my_handler_label
  mov ecx, ebx
  add ecx, 0x400
  mov word  ptr [ecx + 0], ax       ; offset[15:0]
  mov word  ptr [ecx + 2], cs       ; selector = current CS
  mov byte  ptr [ecx + 4], 0        ; reserved
  mov byte  ptr [ecx + 5], 0xEE     ; P=1, DPL=3, 32-bit int gate
  shr eax, 16
  mov word  ptr [ecx + 6], ax       ; offset[31:16]
  mfence

  ; (3) Widen IDTR.limit so vector 0x80 dispatches. 66h prefix MANDATORY.
  sub esp, 8
  mov word  ptr [esp+0], 0x7FF      ; covers vectors 0..0xFF
  mov dword ptr [esp+2], ebx        ; original 32-bit base
  db 66h
  lidt [esp]
  add esp, 8
  mfence

  ; Restore DS to a meaningful segment (e.g. witness) before retf
  mov ax, witness_sel
  mov ds, ax
```

Handler must be **inline in main code segment** (labels resolve in same context).

## Privilege Transitions

### retf to CPL=3 (USE16)

```nasm
  ; USE16 retf with privilege change pops: IP, CS, SP, SS (16-bit each)
  push word ptr (ring3_stack_sel | 3)
  push word ptr 0x0FFE
  push word ptr (ring3_code_sel  | 3)
  push word ptr offset ring3_entry
  retf
```

Key: OR selectors with RPL=3 (`| 3`).

### int 0x80 from CPL=3 → CPL=0

Hardware pushes onto TSS.SS0:ESP0 stack:
```
[esp+0]  EIP     (return address in ring3)
[esp+4]  CS      (ring3 CS)
[esp+8]  EFLAGS
[esp+12] ESP     (ring3 ESP)
[esp+16] SS      (ring3 SS)
```

Return with `iretd` (pops all 5 values, restores CPL=3).

### ud2 → #UD handler (inter-pass gate)

```perl
$idt->handler('VECTOR'=>6, 'CODE'=><<'UD_HANDLER');
  mov ecx, 0x48        ; IA32_SPEC_CTRL
  mov eax, 0x20        ; RRSBA_DIS_U
  xor edx, edx
  wrmsr
  mfence
  add dword ptr [esp], 2   ; skip 2-byte ud2
  iretd
UD_HANDLER
```

Works from CPL=3 because #UD is a hardware exception (bypasses gate DPL check).

## Test Documentation Block

```perl
$test->{TITLE} = "Short title\n";
$test->{DESC}  = "Longer description...\n";
$test->author("ke");
$test->date("2026");
```

## Test Tail

```perl
$code->{CODE} .= <<'CODE';
  mov dx, 0x6060
  mov al, 0
  out dx, al
&SIGNAL_FAIL()
CODE
```

## File Footer

```perl
}#

$test->print
$test->print_header
```

The `}#` closes the initial `#{-` block.
