# Platform & Toolchain

> **Note**: Paths below use PNC-E0 as an example. Set `$MODEL_ROOT` and
> `$RTL_SOURCE` to your actual model for the target stepping.

## Target

| Item | Value |
|------|-------|
| CPU | PNC-E0 (Panther Cove) — adapt for your target |
| Model | `core_emu-<product>-<stepping>-master-<ww>` (e.g. `core_emu-pnc-e0-master-26ww15b`) |
| CPUID | `0x00400F10` (stepping 0x0 = E0) — check your target |
| Model path | `$MODEL_ROOT` (e.g. `/nfs/site/proj/<product>/<product>.emulation.models.01/core_emu/<model>`) |
| RTL source | `$RTL_SOURCE` (e.g. `/p/hdk/rtl/models/xhdk74/<product>/core/<model>/`) |
| Modes | PM (`-mode=PM`, USE16) or 64BIT (`-mode=64BIT`, USE64) |

## Build Commands

| Mode | Command |
|------|---------|
| PM (USE16) | `-b wmtbuild -bs "MAX_FLAGS='-mode=PM'" -bs-` |
| 64BIT (Long Mode) | `-b wmtbuild -bs "MAX_FLAGS='-mode=64BIT'" -bs-` |

Valid modes: `64BIT`, `PM`, `COMP`, `RM`, `VM86` (NOT `PM64`).

## Run Commands

| Simulator | Command | When |
|-----------|---------|------|
| Emulation (RTL) | `-dut core_emu -m emurun -zebu -c 200000000` | Final validation |
| CSLE | `-dut ucode -m ucrun` | Quick functional check |

**CRITICAL**: Never use `-m ucrun` alone for cache side-channel tests. Microarchitectural speculation state is not modeled in ucrun. Always use **emurun** or **CSLE** for timing-dependent tests.

## FIT Patch Pipeline (Custom CREG Overrides)

| Item | Value |
|------|-------|
| Patch source dir | `$MODEL/debug/emulation/patch_default_server/` |
| CREG symbol definitions | `creg_ucode.pm` (inside patch dir) |
| FIT patch physical base | `0xFFEAF390` |
| FIT patch DWORD origin | `/origin 3ffabce4` |

See [emu-clone-patch.md](./emu-clone-patch.md) for full workflow.

## Pipeline

```
Perl MAX (.max) → m4 (.m4) → iASM (-b PantherCove -32) → binary
```

Test library: `pnc_max_lib_24ww33`

## Proven Segment Layout

```
Segment       Linear Base    DPL  Size    Purpose
─────────────────────────────────────────────────────────────
code          0x02000        0    USE16   CPL0 main code (framework default)
data          0x09000        0    USE16   CPL0 data (framework default)
stack         (auto)         0    USE16   CPL0 stack (framework default)
ring3_code    0x20000        3    USE16   CPL=3 test body (4-64 KiB)
ring3_stack   0x30000        3    USE16   CPL=3 stack (4 KiB)
witness       0x32000        3    USE16   Result structure (4 KiB)
cpl0_kstack   0x34000        0    USE32   Exception/int stack for TSS.SS0
reload_buf    0xFFE00000     0    USE16   Cache probe array (1 MiB, 256×4KiB lines)
secret_data   0x40000        0    USE16   Meltdown: DPL=0 secret (4 KiB)
tss           (auto)         —    USE32   Task State Segment
```

Notes:
- reload_buf at 0xFFE00000 (RRSBA) or 0x00100000 (Meltdown) — both work with WB MTRRs
- witness DPL=3 so both CPL=0 handler and CPL=3 code can read/write

## MTRR Initialization (Required)

```nasm
  ; Clear CR0.CD/NW
  mov eax, cr0
  and eax, 0x9FFFFFFF
  mov cr0, eax

  ; Enable WB default MTRR
  mov ecx, 0x2FF            ; IA32_MTRR_DEF_TYPE
  mov eax, 0x00000806       ; E=1, FE=1, type=WB(6)
  xor edx, edx
  wrmsr
  mfence
```

Without this, all memory defaults to UC and timing probes return constant values.

## TSS Setup (Required for Privilege Transitions)

```perl
$tss_seg = $test->new_seg("CLASS"=>"TSS",
    RESERVE => 0x67,
    'CS'    => $code,
    'DS'    => $data,
    'SS'    => $stack,
    'SS0'   => $cpl0_kstack_seg,
    'ESP0'  => $cpl0_kstack_seg->limit,
    "ATTR"  => {
        'NAME' => "mytss",
        'SIZE' => "USE32",
        'TYPE' => ["TSS", "386", "AVAIL"],
    },
);
```

Load in prologue: `mov ax, mytss_sel` / `ltr ax`

## Self-Check Convention

| EBX Value | Meaning |
|-----------|---------|
| 0xACED | PASS (expected behavior observed) |
| 0xDEAD | FAIL (mitigation blocked / unexpected miss) |

Framework uses `hlt` → #GP → END_OF_TEST to terminate. The EBX value is the self-check result visible in dumps.
