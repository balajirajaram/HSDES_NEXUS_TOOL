# Pre-Si Optimization — Proven Recipes (RTL Validated)

Optimizations for CSLE side-channel tests that must fit within emulation
cycle budgets. All numbers below were validated on PNC-E0 as the example platform
(`$MODEL_ROOT`), ZSE4, seed=1.

## Universal (Flush+Reload of any flavor)

### 1. Scrambled Flush Loop
- Use coprime multiplier: `(k * 37 + 13) & MASK`
- gcd(37, N) = 1 for N = 64, 128 → bijection (visits every index exactly once)
- Reduces sequential clflush stalls by randomising cache-set access order
- `MASK = line_count - 1` (must be power of 2)

Note: the older Meltdown gadget uses `(k * 167 + 13) & 0xFF` over 256 lines.
For the optimised line counts below, switch to `*37+13`.

### 2. Reduced Flush/Reload Line Count
- Only cover the minimum range needed for the secret/probe values
- RRSBA: 256 → **64** lines (probe=0x20, control=0x80 → 0x80 needs explicit flush)
- Meltdown: 256 → **128** lines (SECRET=0x42=index 66, can't go below 67)
- Rule: `min_lines = max(probe_index, control_index) + 1`, round up to power of 2

### 3. Explicit Flush of Out-of-Scope Lines
- When the reduced loop range excludes a needed control line
  (e.g. control page 0x80 with only 64-line loop), add an explicit
  `clflush` for that specific line after the loop.
- Costs 1 instruction vs. the savings of N fewer loop iterations.

## RRSBA-Specific

### 4. RSB Drain Reduction: 40 → 32 entries
- 32 unmatched push/ret pairs are sufficient to drain the PNC RSB
- Stack offset: 33×8 = 264 bytes (64-bit) or 33×2 = 66 bytes (USE16)
- Saves 8 push/ret pairs × 3 instructions each = 24 fewer instructions

### 5. Pre-drain + Post-drain clflush of Return Address
- Pre-drain: `clflush [r15]` where `r15 = rsp + 264` (safe_landing slot)
- Post-drain: `clflush [rsp]` at `goto_trained_ret` (rsp now points to same slot)
- Purpose: ensures the final ret target stays cache-cold → forces RRSBA speculation
- Both flushes are present in the original .c reference; the .max equivalent is
  `lea r15, [rsp+264]; clflush [r15]` placed before the ret chain.

### 6. BHR Randomisation — SKIP for CSLE
- The .c reference uses 6×(rdrand + 64 shift/branch) = 384 extra branches
- Proven unnecessary: 32-bit and 64-bit .max variants PASS on RTL without BHR
- 100-iteration training loop saturates the predictor in CSLE structure
- Would add ~400 instructions per pass — counterproductive for pre-Si budgets

## Meltdown-Specific

### 7. SAMPLES Reduction: 4 → 1
- Biggest cycle win for Meltdown (eliminates 3/4 of the hot loop)
- Single iteration suffices on RTL for transient forwarding

### 8. INFLATE Chain Reduction: 300 → 150
- RAW dependency chain to keep OOO window open past fault retire
- 150 `add` instructions still saturate PNC ROB (~512 entries)

## RTL Validation Reference Numbers

### RRSBA DIS_S (64-bit, supervisor, SPEC_CTRL bit 6)
- Pass A: LAT_PROBE=224 (HIT), LAT_CTRL=256 → VERDICT_A=ACED
- Pass B: LAT_PROBE=280 (MISS), LAT_CTRL=276 → VERDICT_B=DEAD
- AB_VERDICT=ACED, PLUMBING=ACED, Cycles=17.45M

### RRSBA DIS_U (64-bit, user-mode CPL=3, SPEC_CTRL bit 5)
- Pass A: LAT_PROBE=224 (HIT), LAT_CTRL=256 → VERDICT_A=ACED
- Pass B: LAT_PROBE=264 (MISS), LAT_CTRL=280 → VERDICT_B=DEAD
- AB_VERDICT=ACED, PLUMBING=ACED, Cycles=17.45M

### RRSBA same-IP CPL0 via int 0x80 (USE16 PM)
- Witness @ 0x32000, threshold=250
- LAT_PROBE=224 (HIT line 0x20), LAT_CONTROL=308 (MISS line 0x80)
- Δ = 84 cycles clean signal, VERDICT=0xACED
- 17.35M cycles, 12m34s wall (`-m emurun -zebu`)

### Key Build/Run Parameters
- Threshold: 250 cycles (hardcoded in RRSBA, runtime-calibrated in Meltdown)
- Training iterations: 100
- Model: `$MODEL_ROOT` (validated on PNC-E0)
- Build: `-b wmtbuild -bs "MAX_FLAGS='-mode=64BIT'" -bs- -seed 1`
- Run:   `-dut core_emu -m emurun -zebu -c 200000000`

## Decision Matrix — When to Apply What

| Optimisation                | Flush+Reload | RSB-based | Fault-based | Cost                       |
| --------------------------- | ------------ | --------- | ----------- | -------------------------- |
| Scrambled flush             | Always       | Always    | Always      | 0 (replaces sequential)    |
| Reduced lines               | Always       | Always    | Always      | 0                          |
| Explicit OOB flush          | If reduced   | If reduced| If reduced  | 1 clflush                  |
| RSB drain 40→32             | —            | Always    | —           | 0 (saves 8 entries)        |
| Pre/post clflush [rsp]      | —            | Always    | —           | 2 instructions             |
| BHR randomisation           | —            | Skip CSLE | —           | Saves ~400 insns           |
| SAMPLES reduction           | —            | —         | Always      | Major win                  |
| INFLATE reduction           | —            | —         | If ROB sat. | Moderate win               |
