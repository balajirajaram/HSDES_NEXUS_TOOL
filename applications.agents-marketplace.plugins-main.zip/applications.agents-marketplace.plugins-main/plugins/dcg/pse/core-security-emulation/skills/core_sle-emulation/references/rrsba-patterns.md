# RRSBA Same-IP Gadget Patterns

## Overview

RRSBA (Restricted Return Stack Buffer Alternate) allows RET instructions to use branch-predictor history when the RSB is empty. The same-IP gadget trains the branch predictor so that a RET at a known IP predicts a specific target, then empties the RSB so the trained prediction takes effect speculatively.

## IA32_SPEC_CTRL (MSR 0x48) Bits

| Bit | Value | Name | Effect |
|-----|-------|------|--------|
| 5 | 0x20 | RRSBA_DIS_U | Disable RRSBA predictions at CPL=3 |
| 6 | 0x40 | RRSBA_DIS_S | Disable RRSBA predictions at CPL=0 |

## 6-Phase Gadget (Proven at CPL=3 and CPL=0)

### Phase 1: FLUSH (Scrambled)

```nasm
  xor ebx, ebx
flush_loop:
  cmp ebx, 256
  jge flush_done
  mov eax, ebx
  imul eax, eax, 167       ; coprime scramble
  add eax, 13
  and eax, 0xFF
  shl eax, 12              ; × 4096
  clflush es:[eax]         ; ES = reload_buf
  inc ebx
  jmp flush_loop
flush_done:
  mfence
```

Scrambled order prevents HW prefetcher from pulling in adjacent lines.

### Phase 2: BTB Training (100 iterations)

```nasm
  xor ecx, ecx
train_loop:
  cmp ecx, 100             ; TRAIN_ITERATIONS
  jge train_done
  push ecx
  mov ax, offset actual_target
  push ax
  jmp trained_ret           ; → trained_ret: ret → pops actual_target
after_gadget:
  pop ecx
  inc ecx
  jmp train_loop
train_done:
```

After 100 iterations, the branch predictor associates `trained_ret`'s IP with target `actual_target`.

### Phase 3: Flush Target Line

```nasm
  mov eax, 0x20
  shl eax, 12              ; line 0x20 = the secret index
  clflush es:[eax]
  mfence
```

### Phase 4: RSB Drain (42-entry push chain)

```nasm
  ; Perl-generated: 42 entries
  mov ax, offset safe_landing
  push ax
  mov ax, offset goto_trained_ret
  push ax
  mov ax, offset vrsled_40
  push ax
  ...
  mov ax, offset vrsled_1
  push ax

  add esp, 82              ; skip past chain (but RSB entries remain!)
  clflush [esp]            ; ensure cold read for any stale pointers
  sub esp, 82
  mfence
```

The 42 pushes each create an RSB entry (push+ret pair). The `add esp; sub esp` is to position ESP without executing the rets — the actual drain happens in Phase 5.

### Phase 5: Trigger

```nasm
  ret                      ; RSB empty → RRSBA predicts actual_target
                           ; speculatively executes disclosure gadget

; --- ret-sled landing pads (40 rets) ---
vrsled_1:  ret
vrsled_2:  ret
...
vrsled_40: ret

goto_trained_ret:
  clflush [esp]
  mfence
  jmp trained_ret          ; chains back for final trigger

safe_landing:
  ; architectural landing after all rets execute
```

### Phase 6: Probe + Verdict

```nasm
  ; Probe target line (0x20)
  mfence
  rdtsc
  mov edi, eax
  mov eax, 0x20
  shl eax, 12
  mov bl, byte ptr es:[eax]
  mfence
  rdtsc
  sub eax, edi
  mov dword ptr ds:[LAT_PROBE], eax

  ; Probe control line (0x80)
  mfence
  rdtsc
  mov edi, eax
  mov eax, 0x80
  shl eax, 12
  mov bl, byte ptr es:[eax]
  mfence
  rdtsc
  sub eax, edi
  mov dword ptr ds:[LAT_CONTROL], eax

  ; Verdict
  mov ecx, ds:[LAT_PROBE]
  cmp ecx, 250             ; RRSBA_THRESHOLD
  jge verdict_miss
  mov dword ptr ds:[VERDICT], 0xACED    ; HIT
  jmp verdict_done
verdict_miss:
  mov dword ptr ds:[VERDICT], 0xDEAD    ; MISS
verdict_done:
```

## Disclosure Gadget (same-IP target)

```nasm
trained_ret:
  ret
  hlt                       ; safety

actual_target:
  mov ebx, 0x20
  shl ebx, 12
  mov bl, byte ptr es:[ebx] ; touches reload_buf[0x20 << 12]
  jmp after_gadget
```

During training: actual_target runs architecturally.
During trigger: actual_target runs SPECULATIVELY (RRSBA prediction), caching line 0x20.

## A/B Test Structure (Mitigation Verification)

```
Pass A (baseline):
  - IA32_SPEC_CTRL = 0x00 (no mitigation)
  - Expected: LAT_PROBE < 250 → HIT → VERDICT_A = 0xACED

  ud2  ; → #UD handler writes SPEC_CTRL = 0x20, iretd

Pass B (mitigated):
  - IA32_SPEC_CTRL = 0x20 (RRSBA_DIS_U)
  - Expected: LAT_PROBE ≥ 250 → MISS → VERDICT_B = 0xDEAD

Combined: (A==ACED && B==DEAD) → PASS; else FAIL
```

## Witness Segment Layout

```
Offset  Field               Sentinel    Success
0x00    MY_DATA             random      unchanged
0x04    LAT_THRESH          0xDEADBEEF  250
0x10    ARCH_TRAIN_DONE     0xBADCFFEE  0xCAFEBABE
0x14    ARCH_DRAIN_DONE     0xBADCFFEE  0xCAFEBABE
0x18    ARCH_TRIGGER_DONE   0xBADCFFEE  0xCAFEBABE
0x1C    LAT_PROBE           0xDEADBEEF  <250 (HIT)
0x20    LAT_CONTROL         0xDEADBEEF  >250 (MISS)
0x24    VERDICT             0xBADCFFEE  0xACED or 0xDEAD
```

## CPL=0 Variant (int 0x80)

When running the gadget at CPL=0 (supervisor mode):
- The handler is **inline** in the main code segment (not via `$idt->handler`)
- IDT[0x80] is written at **runtime** (full 8-byte gate, DPL=3)
- reload_buf has DPL=0 (only CPL=0 can access)
- witness keeps DPL=3 (so CPL=3 can read verdict after iretd)
- push ds/es at handler entry, pop es/ds before iretd

## Reference Tests

| Test | Privilege | Type | Status |
|------|-----------|------|--------|
| `rrsba_sameip_user_csle.max` | CPL=3 | Baseline | PASS |
| `rrsba_sameip_dis_u_ab_csle.max` | CPL=3 | A/B | PASS |
| `rrsba_sameip_dis_s_ab_csle.max` | CPL=0 | A/B | PASS |
| `rrsba_sameip_cpl0_csle.max` | CPL=0 | Baseline | IN PROGRESS |
| `cpl3_baseline_use16_csle.max` | CPL=3→0→3 | Plumbing | PASS |
