# Create Intel GitHub Inventory Repo Plugin

Interactively onboard a new repository to **Intel 1Source** (`intel-innersource`, `intel-sandbox`, `intel-collab`, or `intel-restricted`) by generating the required inventory files and opening a pull request against [`intel-innersource/inventory`](https://github.com/intel-innersource/inventory).

## Version

**1.0.0**

## Features

- Live discovery of orgs and namespaces via `gh api` — no hard-coded org list
- Recursive namespace picker that walks the existing inventory tree
- Deterministic validators for project / repo names, acronym allowlist, and namespace collisions
- HITL (Human-In-The-Loop) confirmation on every normalized value (name, descriptions, governors, owners, topics, visibility, teams)
- Auto-renders `namespace.yml`, `repos.yml`, and optional `teams/<name>.yml` from templates
- Restricted (IPAS / export-controlled) and Collab (CNDA) questionnaires when the target org requires them
- AGS↔GitHub team-wiring workflow with 4-mode AGS picker
- Forks `intel-innersource/inventory`, sparse-fetches only the relevant org subtree, commits on a `user/<idsid>/add-<project>` branch, and opens the PR (with questionnaire comment when needed)

## Skills

### 1. create-innersource-project

**Purpose:** Phase-orchestrated workflow to onboard a new repo/namespace to 1Source and open the inventory PR.

**When to use:**

- User wants to create a new innersource project/repo
- User asks to add a repo to `intel-innersource`, `intel-sandbox`, `intel-collab`, or `intel-restricted`
- User asks to open an inventory PR
- User asks to onboard a new project to 1Source

**Location:** [`skills/create-innersource-project/SKILL.md`](skills/create-innersource-project/SKILL.md)

**Key Features:**

- Phase A — auth + lazy fork/clone of the inventory repo
- Phase B — pick destination from live folder listings (org, parent namespace, project name)
- Phase C — content collection (descriptions, governors, owners, topics, visibility, restricted/collab questionnaires, team wiring)
- Phase D — preview, render YAML, commit, push, open PR

## Prerequisites

- Windows + PowerShell 5.1+ (scripts are `.ps1`)
- [`git`](https://git-scm.com/) and [GitHub CLI (`gh`)](https://cli.github.com/) installed and on `PATH`
  - The skill offers to install them via `winget` on first run if missing
- Intel network access (the skill sets `HTTP_PROXY` / `HTTPS_PROXY` to `proxy-chain.intel.com:911` automatically)
- An authenticated `gh auth login` session for `github.com`

## Usage

In your AI agent client, invoke the skill by saying any of:

- "Create a new innersource project."
- "Onboard a new repo to intel-innersource."
- "Open an inventory PR to add `<my-repo>`."
- "Add a repo to intel-sandbox / intel-collab / intel-restricted."

You can optionally pass a starting hint as the project name, e.g.:

```
Create a new innersource project: agents-marketplace
```

The agent walks you through each phase, asking only what it cannot derive, and confirming every value before any file is written.

## What Gets Created

A single PR against `intel-innersource/inventory` that adds:

```
organizations/<org>/repos/<parent>/<project>/namespace.yml
organizations/<org>/repos/<parent>/<project>/repos.yml
teams/<project>.yml                              # only when AGS team wiring is needed
```

One PR per skill invocation (one new namespace + one repo). Re-invoke the skill after merge to add additional repos under the same project group.

## Troubleshooting

### `gh auth status` reports "not logged in"

- The skill re-prompts you to run `gh auth login` until an authenticated session is detected
- If the browser flow fails behind the corporate proxy, run `gh auth login --hostname github.com --git-protocol https --web` manually in a terminal with the Intel proxy env vars set

### `inventory` repo unreachable

- Make sure you are on the Intel network or VPN
- Verify the proxy variables: `HTTP_PROXY`, `HTTPS_PROXY`, `NO_PROXY`

### Namespace collision

- The validator refuses names that already exist upstream — pick a different project name when prompted

See [`skills/create-innersource-project/references/failure-modes.md`](skills/create-innersource-project/references/failure-modes.md) for the full failure-mode recovery table.

## Support

**Owners:**

- idan.matan.porat@intel.com
- aviv.noah@intel.com

**Repository:** https://github.com/intel-innersource/applications.agents-marketplace.plugins

## Changelog

### 1.0.0

- Initial release
- `create-innersource-project` skill: full Phase A–D workflow with HITL gates, live `gh api` discovery, YAML rendering from templates, and automated inventory PR creation
