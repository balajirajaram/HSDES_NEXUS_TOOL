﻿---
name: create-innersource-project-skill
description: "Interactively create a new Intel 1Source inventory project (namespace.yml + repos.yml [+ team yml]) and open an inventory pull request against intel-innersource/inventory. Use when: a user wants to onboard a new repo/namespace to intel-innersource, intel-sandbox, intel-collab, or intel-restricted; create a new project in 1Source; submit an inventory PR to add a repository."
argument-hint: "[project-name]  (optional starting hint, e.g. 'agents-marketplace')"
---

# Create Intel Innersource Project (Orchestrator)

This file is a phase orchestrator. Reference material lives in [`./references/`](./references/) and should be read **only when the current branch needs it**, keeping the agent's context lean.

## Reference Loading

When a phase names a reference file, read it with the `read_file` tool before executing that step. Keep it in context for the rest of the run. Never preload branch-gated references you have not reached (e.g. `org-restricted.md` if `$org != intel-restricted`).

**Read at skill start, once:**

- [`references/agent-conventions.md`](references/agent-conventions.md) â€” helper scripts, JSON contract, HITL rendering rules
- [`references/naming-and-acronyms.md`](references/naming-and-acronyms.md) â€” naming rules + acronym allowlists (referenced repeatedly)

**Read only when needed:**

- [`references/org-restricted.md`](references/org-restricted.md) â€” only if `$org == intel-restricted`
- [`references/org-collab.md`](references/org-collab.md) â€” only if `$org == intel-collab`
- [`references/team-wiring.md`](references/team-wiring.md) â€” Phase C8
- [`references/pr-publish.md`](references/pr-publish.md) â€” Phase D4
- [`references/failure-modes.md`](references/failure-modes.md) â€” on first error, or proactively if a step looks blocked

## When to Use

Triggers: "create a new innersource project/repo", "add a repo to 1Source / intel-innersource / intel-sandbox / intel-collab / intel-restricted", "open an inventory PR", "onboard a new project to 1Source".

Flow: auth â†’ fork+lazy-clone inventory â†’ pick destination from live tree â†’ collect content (HITL on every normalized value) â†’ write `namespace.yml` + `repos.yml` (+ `teams/<name>.yml` when AGS wiring is needed) â†’ commit â†’ push â†’ open PR (+ questionnaire comment for restricted/collab).

## Operating Principles (apply to every step)

1. **Zero-leave-terminal.** Inline every reference the user might need (acronyms, naming rules, governor/restricted criteria) into the prompt that needs it.
2. **Auto-derive â†’ HITL.** Every computed value (repo name, branch, team names, topics, description rewording) is shown with `[a]ccept / [e]dit / [r]egenerate / [q]uit` before use. Never silently transform.
3. **Live data, not hard-coded.** Org names and namespace structure come from `gh api` / the cloned tree, never from this file.
4. **Numbered defaults.** Selections are numbered with one default highlighted; Enter accepts it.
5. **Validate at the boundary.** Names hit [Repository Naming Rules](#repository-naming-rules) before any write; reject + re-prompt citing the violated rule.
6. **One PR per run.** One new namespace + one repo (+ optional teams file).

> Helper scripts catalog and HITL rendering rules live in [`references/agent-conventions.md`](references/agent-conventions.md) (read at skill start).

---

## Phase A â€” Setup (run before any content prompts)

### A0. Pick your shell

This skill ships two parallel sets of helpers:

- **Windows** uses the `.ps1` scripts in [`./scripts/`](./scripts/) and runs in the built-in Windows PowerShell (5.1) or PowerShell 7+.
- **Linux / macOS** uses the `.sh` scripts in the same folder and runs in `bash` 4+. No PowerShell install required.

Follow the matching code block for your OS in every step below. After cloning this skill, Linux/macOS users mark the scripts executable once:

```bash
chmod +x "$skillDir"/scripts/*.sh
```

### A1. Prerequisite binaries

```powershell
# Windows
git --version
gh --version
$PSVersionTable.PSEdition
$PSVersionTable.PSVersion
```

```bash
# Linux / macOS
git --version
gh --version
perl -MJSON::PP -e 'print "ok\n"'   # JSON::PP is core perl, preinstalled
curl --version | head -1
bash --version | head -1
```

If any prerequisite is missing, propose the relevant install command via HITL accept (`[a] install / [q] quit`) and run it on `[a]`:

On Windows:

```powershell
winget install --id Git.Git --silent --accept-package-agreements --accept-source-agreements
winget install --id GitHub.cli --silent --accept-package-agreements --accept-source-agreements
```

On Linux (Debian/Ubuntu):

```bash
sudo apt update && sudo apt install -y git gh curl
```

On Linux (RHEL/Fedora):

```bash
sudo dnf install -y git gh curl
```

On macOS:

```bash
brew install git gh curl
```

Re-check the versions before proceeding.

### A2. GitHub auth

Set Intel proxy env vars for the current shell session (inherited by `gh` / `git`):

```powershell
# Windows
$env:HTTP_PROXY  = "http://proxy-chain.intel.com:911/"
$env:HTTPS_PROXY = "http://proxy-chain.intel.com:911/"
$env:NO_PROXY    = "localhost,127.0.0.1,.intel.com"
```

```bash
# Linux / macOS
export HTTP_PROXY='http://proxy-chain.intel.com:911/'
export HTTPS_PROXY='http://proxy-chain.intel.com:911/'
export NO_PROXY='localhost,127.0.0.1,.intel.com'
export http_proxy="$HTTP_PROXY" https_proxy="$HTTPS_PROXY" no_proxy="$NO_PROXY"
```

Then run `gh auth status`. If it reports not logged in, run `gh auth login --hostname github.com --git-protocol https --web` and wait for the user to finish the browser flow, then run `gh auth status` again. Keep re-prompting the user to log in (re-running `gh auth login` then re-checking `gh auth status`) until the status check reports an authenticated session on `github.com`. Then capture the active identity:

```powershell
# Windows
$ghLogin = (gh api user --jq .login)
$ghEmail = (gh api user --jq .email)
$ghName  = (gh api user --jq .name)
```

```bash
# Linux / macOS
ghLogin="$(gh api user --jq .login)"
ghEmail="$(gh api user --jq .email)"
ghName="$(gh api user --jq .name)"
```

### A3. Verify inventory reachability

```powershell
# Windows
$repoInfo = gh repo view intel-innersource/inventory --json name,defaultBranchRef --jq '{name: .name, defaultBranch: .defaultBranchRef.name}' | ConvertFrom-Json
$defaultBranch = $repoInfo.defaultBranch
```

```bash
# Linux / macOS
defaultBranch="$(gh repo view intel-innersource/inventory --json defaultBranchRef --jq '.defaultBranchRef.name')"
```

Must resolve `defaultBranch` to a non-null value (usually `master`).

### A4. Idsid

Show the user:

```
Your Intel idsid (the local-part of your @intel.com email; used in the PR branch name).
Detected from gh: <best-guess from $ghEmail or $ghName>
[a] accept   [e] type a different idsid
>
```

Store as `$idsid`.

### A5. Fork + lazy sparse clone (fast â€” no full tree download)

Metadata-only clone now; sparse-fetch the picked org's subtree in the background after B1.

```powershell
# Windows
$work = Join-Path ([Environment]::GetFolderPath('UserProfile')) 'gitwork'
$forkInfo = & "$skillDir\scripts\New-LazyFork.ps1" `
    -GhLogin $ghLogin -WorkDir $work -DefaultBranch $defaultBranch | ConvertFrom-Json
$inv = $forkInfo.inv
```

```bash
# Linux / macOS
work="$HOME/gitwork"
forkInfo="$("$skillDir/scripts/new-lazy-fork.sh" \
    --gh-login "$ghLogin" --work-dir "$work" --default-branch "$defaultBranch")"
inv="$(jq -r .inv <<< "$forkInfo")"
```

`$inv` is the local clone root. Do NOT iterate `$inv\organizations` for org/namespace lists before the relevant sparse-fetch â€” use live `gh api` calls (via the scripts below) until D3.

**Surface the local path for inspection.** Print `$inv` prominently and offer an HITL gate before continuing â€” the user may want to open the clone in Explorer / a second shell to verify state:

```powershell
# Windows
Write-Host ""
Write-Host "Inventory cloned to: $inv" -ForegroundColor Cyan
Write-Host ""
```

```bash
# Linux / macOS
printf '\nInventory cloned to: %s\n\n' "$inv"
```

Render an HITL prompt (via `vscode_askQuestions` â€” see [`references/agent-conventions.md`](references/agent-conventions.md)) with:

- question: `Inventory fork ready at $inv. Continue?`
- options:
  - `Continue` _(recommended)_
  - `Open folder` â€” on selection, run:

```powershell
# Windows
try {
    if ($IsWindows -or $PSVersionTable.PSEdition -eq 'Desktop') { Start-Process explorer.exe $inv -ErrorAction Stop }
    elseif ($IsMacOS) { & open $inv }
    elseif ($IsLinux) { & xdg-open $inv 2>$null }
} catch { }
```

```bash
# Linux / macOS
case "$(uname -s)" in
    Darwin) open "$inv" >/dev/null 2>&1 || true ;;
    Linux)  xdg-open "$inv" >/dev/null 2>&1 || true ;;
esac
```

then re-prompt

- `Quit`

Do not preload any files from `$inv` into context regardless of the user's choice â€” keep using live `gh api` calls until D3.

---

## Phase B â€” Pick destination (everything from live folder listings)

### B1. Organization picker

List org directories via the GitHub Contents API (instant â€” no clone needed).

```powershell
# Windows
$orgs = & "$skillDir\scripts\Get-OrgList.ps1" -DefaultBranch $defaultBranch | ConvertFrom-Json
```

```bash
# Linux / macOS
orgs="$("$skillDir/scripts/get-org-list.sh" --default-branch "$defaultBranch")"
```

Show as a numbered list and tell the user one-line semantics for each (these descriptions live in the prompt itself â€” no doc lookup needed):

```
Which 1Source organization should host this repo?
  1. intel-innersource  â€” production. Read-only access for all Intel Blue Badges by default.
  2. intel-sandbox      â€” experimentation / migration staging. Internal type allows Green Badge read.
  3. intel-collab       â€” collaboration with external parties under a CNDA. Requires sponsors + CNDA #.
  4. intel-restricted   â€” Top Secret / IPAS exploit / NDA-restricted / export-controlled. Requires Data Classification review.
> Select [1]:
```

Store as `$org`. If `intel-restricted` or `intel-collab`, mark `$needsQuestionnaire = true` (handled in Phase C).

Immediately after the org is picked, kick off the sparse fetch for just that org's subtree in the background â€” the working tree will be ready by the time the user finishes B2's drill-down or, worst case, before D3:

```powershell
# Windows
$sparseJob = Start-Job -Name 'sparseFetch' -ScriptBlock {
    param($repoPath, $org)
    Set-Location $repoPath
    git sparse-checkout set "organizations/$org" 'teams'
} -ArgumentList $inv, $org
```

```bash
# Linux / macOS
(
    cd "$inv" && git sparse-checkout set "organizations/$org" 'teams'
) >/tmp/sparse-fetch.log 2>&1 &
sparsePid=$!
```

### B2. Parent namespace â€” recursive picker

**What B2 does:** walks you down the existing namespace tree to lock in the FIRST N-1 components of your repo name. **What B3 does:** names the LAST component (your project folder). Every repo needs at least 3 components:

```
<function> . <domain> . <project-name> [ . <sub-component> ]
   level 1     level 2      level 3            level 4+
   (B2)        (B2)         (B3)               (C1, optional)
```

So if your final repo is `applications.services.agents-marketplace`, then in B2 you pick `applications` (level 1) and `services` (level 2 â€” an intermediate namespace), and in B3 you name `agents-marketplace` (level 3 â€” your project folder).

For each level, list directories via the GitHub Contents API:

```powershell
# Windows
$entries = & "$skillDir\scripts\Get-NamespaceLevel.ps1" `
    -RelPath $relPath -DefaultBranch $defaultBranch | ConvertFrom-Json
# $relPath e.g. 'organizations/intel-innersource/repos/applications'
# Each entry: { Name, Description }
```

```bash
# Linux / macOS
entries="$("$skillDir/scripts/get-namespace-level.sh" \
    --rel-path "$relPath" --default-branch "$defaultBranch")"
# Each entry: { name, description }
```

Use `$entries` directly to render the picker. Do NOT reimplement the listing or YAML decode inline.

Prompt template (repeated at each level). Render options in fixed `1 â†’ 2 â†’ existing-children` order; only the highlighted default changes per level:

```
Current path:       organizations/<org>/repos/<path-so-far>
Components so far:  <n>     (need â‰¥2 before you can stop here and name a project)

You're picking an INTERMEDIATE namespace at this level â€” NOT your project folder.
Your project folder is the LAST component and is named in the next step (B3).

  1. âœ“ Use this level â€” stop drilling and name my project under
        '<path-so-far>'.                                              (only shown when components-so-far â‰¥ 2)
  2. + Create a NEW intermediate namespace here (it will hold further
        sub-namespaces and/or projects beneath it).
  3. ai            â€” Artificial intelligence projects (frameworks, models, tooling).
  4. analytics     â€” Data analytics platforms and services.
  5. automation    â€” General automation tools.
  ...
  [q] quit

> Select [<smart-default-based-on-user-description>]:
```

Behavior:

- **Option 1 ("use this level")**: shown only when components-so-far â‰¥ 2. Selecting it locks `$parentPath` = current path (relative to `organizations/<org>/repos/`) and proceeds to B3 to name the project.
- **Option 2 ("create NEW intermediate namespace")**: prompt for the name (same rules as B3, enforced via `Test-ProjectName.ps1`), HITL-confirm, then **ask the intent gate below** before drilling in.
- **Existing child**: drill in and re-prompt at the next level.
- Smart default from project-name hint suffix only: `-lib` â†’ `libraries`, `-service` â†’ `applications`. Otherwise no default.

**Intent gate (run immediately after the user types a name under option 2):**

```
You typed:  '<typedName>'

Is this:
  [n] a new INTERMEDIATE namespace â€” it will contain other projects/sub-namespaces beneath it; we'll drill into it now
  [p] my actual PROJECT folder â€” stop here, this name IS my project (skip the next prompt)
> [n]:
```

- **`[n]`** (default): validate via `Test-ProjectName.ps1`, HITL-confirm, drill into `<path-so-far>/<typedName>`, re-prompt at the new level.
- **`[p]`**: **first check `components-so-far â‰¥ 2`** (i.e. `<path-so-far>` already has â‰¥2 dot-separated levels). If not, reject with `"Can't stop here â€” '<path-so-far>.<typedName>' would only be <N> components, but rule 4 requires â‰¥3 (function.domain.project-name). Pick [n] to drill deeper, or pick an existing child to drill into."` and re-show the gate. If the check passes, validate via `Test-ProjectName.ps1` AND `Test-NameCollision.ps1` (using current `<path-so-far>` as `-ParentPath` and `<typedName>` as `-ProjectName`). HITL-confirm. On accept, set `$projectName = <typedName>`, set `$parentPath = <path-so-far>`, and SKIP B3 â€” proceed directly to C1.

**Stop drilling** when:

- User picks option 1 ("use this level"), OR
- User picks option 2 + `[p]` in the intent gate (project name resolved early), OR
- The current directory has no sub-directories AND â‰¥2 components have been chosen (auto-lock to option 1); if <2 components and no children exist, force the user into option 2.

`$parentPath` is the path relative to `organizations/<org>/repos/` once locked in.

### B3. New project (folder + namespace) name

> **Skip this step** if `$projectName` was already set by B2's intent gate (user picked `[p]` after option 2). In that case `Test-ProjectName.ps1` and `Test-NameCollision.ps1` already ran during the gate â€” proceed straight to C1.

```
The "project name" is the new folder that will be created under:
  organizations/<org>/repos/<parentPath>/

It also becomes the last component of your repo name(s).

Rules (must satisfy ALL):
  â€¢ lowercase aâ€“z, digits 0â€“9, hyphens '-'
  â€¢ NO underscores, NO uppercase, NO dots
  â€¢ NO team / division / org acronyms (e.g. DCG, IAGS) â€” put those in the description instead
  â€¢ silicon codenames spelled out (e.g. 'skylake' not 'skl')
  â€¢ only these acronyms allowed as-is in names: ai bios ci cicd cpu efi fpga gpu hpc hr oa os pdk rfid rtl rtos ui vpu xpu

Examples:
  âœ“ agents-marketplace
  âœ“ 1source-documentation
  âœ- AgentsMarketplace      (no uppercase)
  âœ- agents_marketplace     (no underscores)
  âœ- dcg-agents             (no team acronyms)

Project name?
>
```

Enforce with the deterministic validator BEFORE the HITL accept:

```powershell
# Windows
$check = & "$skillDir\scripts\Test-ProjectName.ps1" -Name $projectName | ConvertFrom-Json
if (-not $check.ok) {
    Write-Host "Rejected: $($check.violations -join '; ')" -ForegroundColor Yellow
    # re-prompt
}
```

```bash
# Linux / macOS
check="$("$skillDir/scripts/test-project-name.sh" --name "$projectName")"
if [[ "$(jq -r .ok <<< "$check")" != "true" ]]; then
    echo "Rejected: $(jq -r '.violations|join("; ")' <<< "$check")"
    # re-prompt
fi
```

The acronym heuristic flags suspect tokens but allows override after the user confirms in HITL that the token is a real word (e.g. `core`, `data`, `auth` would flag â€” user keeps; `dcg`, `iags` flag â€” user fixes). Then HITL-confirm. Check for collision against the live remote (does not depend on the sparse fetch being done):

```powershell
# Windows
$collision = & "$skillDir\scripts\Test-NameCollision.ps1" `
    -Org $org -ParentPath $parentPath -ProjectName $projectName `
    -DefaultBranch $defaultBranch | ConvertFrom-Json
if ($collision.exists) { <re-prompt: "That project folder already exists upstream. Pick a different name."> }
```

```bash
# Linux / macOS
collision="$("$skillDir/scripts/test-name-collision.sh" \
    --org "$org" --parent-path "$parentPath" --project-name "$projectName" \
    --default-branch "$defaultBranch")"
if [[ "$(jq -r .exists <<< "$collision")" == "true" ]]; then
    : # re-prompt: "That project folder already exists upstream. Pick a different name."
fi
```

This skill creates NEW namespaces only â€” refuse and re-prompt on collision.

---

## Phase C â€” Content (interactive, with HITL on every normalized value)

### C1. Repo name(s)

The repo name is the `name:` field inside `repos.yml`. It must equal `<parentPath-with-dots>.<projectName>[.<sub-component>]`.

Compute the default automatically and show inline guidance:

```
Your repo name builds from your destination + project name + optional sub-component.

Base (auto-derived):
  <parentPath joined with '.'>.<projectName>
  = applications.services.agents-marketplace

When to add a sub-component (4th+ level):
  â€¢ Multiple repos under ONE project group. Examples:
      applications.services.agents-marketplace.plugins
      applications.services.agents-marketplace.docs
      applications.services.agents-marketplace.tests
  â€¢ Mirroring or namespacing a sub-product:
      libraries.math.sharp3d.cli

When NOT to add a sub-component:
  â€¢ This is the single, primary repo for the project â€” use the base.

Rules: same as project-name rules + total length â‰¤ 100 chars + â‰¥3 components.

Proposed repo name:
  applications.services.agents-marketplace

[a] accept   [e] edit (type the full name)   [+] add a sub-component   [q] quit
>
```

If `[+]`, prompt for the sub-component (same character rules as project-name), append with a dot, re-show the HITL.

Store as `$repoName`. Validate against all rules. Reject and re-prompt on violation.

> If the user wants **multiple** repos in this PR, tell them this skill is one-repo-per-PR by design (easier review). They can re-invoke the skill after merge for additional repos in the same project group.

### C2. Descriptions

Collect two descriptions. **Each one runs through HITL with acronym detection.**

```
Namespace description (1â€“2 sentences) â€” what kinds of repositories live under
'<parentPath>.<projectName>'?

Rules:
  â€¢ Expand ALL acronyms/abbreviations on first use, except the well-known set:
      API BIOS CPU FPGA GPU OA OS PDK REST RSA SSH URL XML
  â€¢ Acceptable abbreviations: arch, demo, devops, lab(s)

>
```

After the user types it, scan for tokens matching `[A-Z]{2,}` that are NOT in the allowlist. For each unknown acronym, ask:

```
Detected unexpanded acronym: 'DCG'.
Please expand it (the description will be updated automatically) or confirm it should stay as-is.

[e]xpand it (type the expansion)   [k]eep as-is   [r]emove the word
>
```

Apply the user's choice to the text and re-show the full description for HITL accept.

Repeat the same flow for the **repo description**:

```
Repo description (1â€“3 sentences) â€” what does THIS repo contain and what is it used for?
Same expansion rules apply.
>
```

Store as `$nsDescription` and `$repoDescription`.

### C3. Governors & owners

Inline reference (no doc lookup):

```
Two roles, both required (â‰¥2 emails each):

  â€¢ OWNERS    â€” review PRs INTO this repo. Contact point for the repo.
  â€¢ GOVERNORS â€” review inventory PRs that touch this namespace and anything beneath it.
                (Top two namespace levels are governed only by top-level governors.)

Input format: comma- or newline-separated Intel emails (â‰¥2 required).
Example: first.last@intel.com, first.last2@intel.com

Are owners and governors the same people? [Y/n]
```

- **Default Y**: prompt once for the list of Intel emails (format / example as above). Reuse for both lists.
- **N**: prompt for governors, then owners â€” same format / example shown in each prompt.

Validation:

- Every entry matches `^[a-z0-9._%+-]+@intel\.com$` (case-insensitive).
- â‰¥2 entries, no duplicates.

After collection, show:

```
Governors (will be written to namespace.yml):
  - <e1>
  - <e2>
  ...
Owners (will be written to repos.yml):
  - <e1>
  - <e2>
  ...

[a] accept   [e] edit   [q] quit
>
```

Store as `$governors[]`, `$owners[]`.

### C4. Topics

Inline reference:

```
Topics are category labels that help repo discovery via GitHub search.
GitHub will AUTO-ADD programming-language topics â€” you only need to add
domain / keyword tags.

Rules: lowercase, hyphens allowed, NO spaces, NO underscores.

Suggested from your description:
  agents, plugins, vscode, extensions

[a] accept   [e] edit (comma-separated list)   [+] add more   [-] remove some   [q] quit
>
```

Generate the suggestion by extracting nouns/keywords from `$repoDescription` and `$projectName`. HITL until accepted. Store as `$topics[]`.

### C5. Visibility

```
Repository visibility:
  1. private   â€” recommended default. Access only via configured teams / permissions.
  2. internal  â€” read access for ALL org members including Green Badge workers.
                 NOT allowed in intel-restricted or intel-collab.
                 Required if you plan to share GitHub Actions workflows across repos.
> Select [1]:
```

If `$org` âˆˆ {restricted, collab}, hide option 2 entirely and lock to `private`.

Store as `$visibility`.

### C6. Restricted questionnaire â€” only if `$org == intel-restricted`

> Read [`references/org-restricted.md`](references/org-restricted.md) and follow its spec. Collect `$restrictedAnswers` (fields: what, why, diligence, impact, architecture) and `$allowOverrideName`.

### C7. Collab questionnaire â€” only if `$org == intel-collab`

> Read [`references/org-collab.md`](references/org-collab.md) and follow its spec. Collect `$sponsors[]`, `$externalEmails[]`, `$cndaNumber`.

### C8. Permissions & teams (the AGSâ†”GitHub bridge)

> Read [`references/team-wiring.md`](references/team-wiring.md) and follow its spec. Show the AGS bridge reference, run the default-permission-plan prompt, then run the per-team 4-mode AGS picker (smart default: `gb-` prefix â†’ mode 4, else mode 1). Collect `$permissions` map and `$teamsToCreate[]`.

---

## Phase D â€” Review, write, commit, push, PR

### D1. Full summary + file previews (HITL gate)

Render every collected value PLUS a full preview of each file that will be written. Wait for explicit `a` accept.

```
â”€â”€â”€ Summary â”€â”€â”€
Organization:    <org>
Parent path:     organizations/<org>/repos/<parentPath>
New folder:      <projectName>
Repo name:       <repoName>
Visibility:      <visibility>
Governors:       <list>
Owners:          <list>
Topics:          <list>
Permissions:     <pretty-printed>
Teams to create: <list, each with AGS wiring mode>
Restricted Q's:  <yes/no>     Collab Q's: <yes/no>
Branch:          user/<ghLogin>/add-<projectName>
PR title:        Add <projectName> namespace and repo in <org>

â”€â”€â”€ organizations/<org>/repos/<parentPath>/<projectName>/namespace.yml â”€â”€â”€
<full YAML>

â”€â”€â”€ organizations/<org>/repos/<parentPath>/<projectName>/repos.yml â”€â”€â”€
<full YAML>

â”€â”€â”€ teams/<projectName>.yml â”€â”€â”€        (only if $teamsToCreate not empty)
<full YAML>

[a] accept and create the PR
[e] go back and edit a specific section
[q] quit without writing anything
>
```

### D2. Render YAML files

The three output files are rendered by `Render-InventoryYaml.ps1` from a single state object. File-structure templates live in [`./templates/`](./templates/): `namespace.yml.tmpl`, `repos.yml.tmpl`, `teams.yml.tmpl`. All conditional logic (sponsors, allow-override-name, permission rows, team modes) lives in the render script â€” do NOT reproduce the schema in skill prose or hand-assemble YAML strings.

Build the state object in the parent shell from the collected variables, hand it to the renderer as compact JSON:

```powershell
$state = @{
    nsDescription     = $nsDescription
    governors         = $governors
    repoName          = $repoName
    repoDescription   = $repoDescription
    visibility        = $visibility
    owners            = $owners
    topics            = $topics
    sponsors          = $sponsors           # populate only when $org == intel-collab; else @() or omit
    allowOverrideName = $allowOverrideName  # bool; only true for intel-restricted when user opted in
    permissions = @{
        ownersAsAdmins    = $true
        allowExtraMembers = $false
        blocks = @{
            admin = @("$projectName-admins")
            write = @("$projectName-maintainers")
            read  = @("gb-$projectName-readers")
            # add 'maintain' / 'triage' here if the final permissions plan includes them
        }
    }
    teams = @(
        # one entry per team in $teamsToCreate; mode is one of:
        #   'managed-by-1source'  â€” 1Source creates the AGS entitlement (option 1)
        #   'external-ad-group'   â€” user supplied an existing AZAD-CORP display name (option 2)
        #   'members'             â€” generic-account team (sys_*_gh@intel.com listed under members)
        @{ name = "$projectName-admins";      mode = 'managed-by-1source'; adGroup = "$projectName-admins";        owners = $owners; organizations = @('intel-innersource','intel-sandbox') }
        @{ name = "$projectName-maintainers"; mode = 'external-ad-group';  adGroup = '<AZAD-CORP Display Name>';   owners = $owners; organizations = @('intel-innersource','intel-sandbox') }
        @{ name = "gb-$projectName-readers";  mode = 'members';            members = @('sys_<thing>_gh@intel.com'); owners = $owners; organizations = @('intel-innersource','intel-sandbox') }
    )
}

$rendered = & "$skillDir\scripts\Render-InventoryYaml.ps1" `
    -StateJson ($state | ConvertTo-Json -Depth 6 -Compress) | ConvertFrom-Json

$namespaceYml = $rendered.namespaceYml
$reposYml     = $rendered.reposYml
$teamsYml     = $rendered.teamsYml   # empty string when state.teams is empty/missing
```

```bash
# Linux / macOS
# Build the equivalent state JSON via jq. Adapt this block to your collected variables;
# every key under .permissions.blocks may be admin/maintain/write/triage/read.
governorsJson="$(printf '%s\n' "${governors[@]}" | jq -R . | jq -s -c .)"
ownersJson="$(printf '%s\n' "${owners[@]}"     | jq -R . | jq -s -c .)"
topicsJson="$(printf '%s\n'    "${topics[@]}"   | jq -R . | jq -s -c .)"
sponsorsJson="$(printf '%s\n'  "${sponsors[@]:-}" | jq -R . | jq -s -c 'map(select(length>0))')"

stateJson="$(jq -cn \
    --arg nsDescription "$nsDescription" --arg repoName "$repoName" \
    --arg repoDescription "$repoDescription" --arg visibility "$visibility" \
    --argjson governors "$governorsJson" --argjson owners "$ownersJson" \
    --argjson topics    "$topicsJson"    --argjson sponsors "$sponsorsJson" \
    --argjson allowOverrideName "${allowOverrideName:-false}" \
    --arg projectName "$projectName" \
    '{nsDescription:$nsDescription, governors:$governors,
      repoName:$repoName, repoDescription:$repoDescription,
      visibility:$visibility, owners:$owners, topics:$topics,
      sponsors:$sponsors, allowOverrideName:$allowOverrideName,
      permissions:{ownersAsAdmins:true, allowExtraMembers:false,
        blocks:{admin:[($projectName+"-admins")],
                write:[($projectName+"-maintainers")],
                read:[("gb-"+$projectName+"-readers")]}},
      teams:[
        {name:($projectName+"-admins"),       mode:"managed-by-1source",
         adGroup:($projectName+"-admins"),     owners:$owners,
         organizations:["intel-innersource","intel-sandbox"]},
        {name:($projectName+"-maintainers"),  mode:"external-ad-group",
         adGroup:"<AZAD-CORP Display Name>",   owners:$owners,
         organizations:["intel-innersource","intel-sandbox"]},
        {name:("gb-"+$projectName+"-readers"),mode:"members",
         members:["sys_<thing>_gh@intel.com"], owners:$owners,
         organizations:["intel-innersource","intel-sandbox"]}
      ]}')"

rendered="$("$skillDir/scripts/render-inventory-yaml.sh" --state-json "$stateJson")"
namespaceYml="$(jq -r .namespaceYml <<< "$rendered")"
reposYml="$(jq -r .reposYml         <<< "$rendered")"
teamsYml="$(jq -r .teamsYml         <<< "$rendered")"   # empty string when no teams
```

Notes:

- Omit the `teams` array (or pass `@()`) to skip writing `teams/<projectName>.yml`.
- `guid:` is intentionally not in the namespace template â€” 1Source automation adds it during the PR.
- Files are written UTF-8 (no BOM), LF line endings, 2-space indent. Edit the `.tmpl` files to change shape; edit `Render-InventoryYaml.ps1` to change conditional logic.

### D3. Branch, write, commit

Join the background sparse-fetch job in the parent shell BEFORE calling the write script (Start-Job state cannot cross subprocess boundaries):

```powershell
# Windows
if ($sparseJob -and $sparseJob.State -eq 'Running') {
    Write-Host 'Finishing inventory sparse-fetch...' -NoNewline
    Wait-Job $sparseJob | Out-Null
    Write-Host ' done.'
}
Receive-Job $sparseJob -ErrorAction SilentlyContinue | Out-Null
Remove-Job  $sparseJob -ErrorAction SilentlyContinue

$branch       = "user/$ghLogin/add-$projectName"
$commitTitle  = "Add $projectName namespace and repo in $org"
$commitBody   = "Adds organizations/$org/repos/$parentPath/$projectName with`nnamespace.yml (governors: $($governors.Count)) and repos.yml`ndefining $repoName. $repoDescription"

$writeResult = & "$skillDir\scripts\Write-InventoryFiles.ps1" `
    -InventoryPath $inv -DefaultBranch $defaultBranch -Branch $branch `
    -Org $org -ParentPath $parentPath -ProjectName $projectName `
    -NamespaceYml $namespaceYml -ReposYml $reposYml -TeamsYml $teamsYml `
    -CommitTitle $commitTitle -CommitBody $commitBody | ConvertFrom-Json
```

```bash
# Linux / macOS
if [[ -n "${sparsePid:-}" ]] && kill -0 "$sparsePid" 2>/dev/null; then
    printf 'Finishing inventory sparse-fetch...'
    wait "$sparsePid" || true
    echo ' done.'
fi

branch="user/$ghLogin/add-$projectName"
commitTitle="Add $projectName namespace and repo in $org"
commitBody=$'Adds organizations/'"$org"'/repos/'"$parentPath"'/'"$projectName"$'\nwith namespace.yml (governors: '"${#governors[@]}"$') and repos.yml\ndefining '"$repoName"$'. '"$repoDescription"

tmpNs="$(mktemp)";    printf '%s' "$namespaceYml" > "$tmpNs"
tmpRepos="$(mktemp)"; printf '%s' "$reposYml"     > "$tmpRepos"
teamsArgs=()
if [[ -n "${teamsYml:-}" ]]; then
    tmpTeams="$(mktemp)"; printf '%s' "$teamsYml" > "$tmpTeams"
    teamsArgs+=(--teams-yml-file "$tmpTeams")
fi

writeResult="$("$skillDir/scripts/write-inventory-files.sh" \
    --inventory-path "$inv" --default-branch "$defaultBranch" --branch "$branch" \
    --org "$org" --parent-path "$parentPath" --project-name "$projectName" \
    --namespace-yml-file "$tmpNs" --repos-yml-file "$tmpRepos" \
    "${teamsArgs[@]}" \
    --commit-title "$commitTitle" --commit-body "$commitBody")"
```

Assemble `$namespaceYml`, `$reposYml`, `$teamsYml` in the parent shell via the [Phase D2 render step](#d2-render-yaml-files). Pass an empty string `''` (PowerShell) or omit the teams-file flag (bash) to skip the teams file.

### D4. Push + open PR (+ optional questionnaire comment)

> Read [`references/pr-publish.md`](references/pr-publish.md) and follow its spec. Assemble `$prBody` and `$commentBody`, then:

```powershell
# Windows
$publish = & "$skillDir\scripts\Publish-InventoryPR.ps1" `
    -InventoryPath $inv -GhLogin $ghLogin -Branch $branch `
    -DefaultBranch $defaultBranch `
    -Title $commitTitle -Body $prBody `
    -CommentBody $commentBody | ConvertFrom-Json
```

```bash
# Linux / macOS
tmpPrBody="$(mktemp)";      printf '%s' "$prBody"      > "$tmpPrBody"
commentArgs=()
if [[ -n "${commentBody:-}" ]]; then
    tmpComment="$(mktemp)"; printf '%s' "$commentBody" > "$tmpComment"
    commentArgs+=(--comment-body-file "$tmpComment")
fi
publish="$("$skillDir/scripts/publish-inventory-pr.sh" \
    --inventory-path "$inv" --gh-login "$ghLogin" --branch "$branch" \
    --default-branch "$defaultBranch" \
    --title "$commitTitle" --body-file "$tmpPrBody" \
    "${commentArgs[@]}")"
```

Show D6 closing instructions on success.

---

> Naming rules, acronym allowlists, failure-mode recovery table, and skill-author references are all in [`references/`](references/). Read on demand:
>
> - Naming rules + acronym allowlists â†’ [`references/naming-and-acronyms.md`](references/naming-and-acronyms.md) (read at start)
> - Failure recovery + reference URLs â†’ [`references/failure-modes.md`](references/failure-modes.md)
