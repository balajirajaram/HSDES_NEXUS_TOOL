# Agent Conventions

Applied throughout the skill: how to call helper scripts, parse their output, and render every prompt the user sees.

## Helper scripts (deterministic, called verbatim)

All fragile / multi-line / hallucination-prone work lives in PowerShell scripts in `./scripts/`. Invoke them verbatim with named params and parse their JSON stdout. **Never reimplement their logic inline.** Resolve their path via `$skillDir = Split-Path $PSCommandPath -ErrorAction SilentlyContinue` if available, else hard-code the absolute skill folder path the user is invoking from.

| Script                     | Purpose                                                      | Returns (JSON)                                       |
| -------------------------- | ------------------------------------------------------------ | ---------------------------------------------------- |
| `New-LazyFork.ps1`         | A5 — fork + metadata-only sparse clone, wire upstream        | `{inv, defaultBranch}`                               |
| `Get-OrgList.ps1`          | B1 — list orgs under `organizations/`                        | `[<name>, ...]`                                      |
| `Get-NamespaceLevel.ps1`   | B2 — list child namespaces + descriptions at a path          | `[{Name, Description}, ...]`                         |
| `Test-ProjectName.ps1`     | B3 — deterministic name validator                            | `{ok, violations:[]}`                                |
| `Test-NameCollision.ps1`   | B3 — does the target folder already exist upstream           | `{exists, path}`                                     |
| `Render-InventoryYaml.ps1` | D2 — render namespace/repos/teams yml from a state object    | `{namespaceYml, reposYml, teamsYml}`                 |
| `Write-InventoryFiles.ps1` | D3 — sync upstream, create branch, write yml, commit         | `{branch, committed, filesWritten}`                  |
| `Publish-InventoryPR.ps1`  | D4+D5 — push, `gh pr create`, optional questionnaire comment | `{pushed, prUrl, prCreated, fallbackUrl, commented}` |

Parse stdout with `ConvertFrom-Json`. Each script sets `$ErrorActionPreference = 'Stop'` and emits a single compact JSON object/array on success.

## HITL accept template

Every time you compute / normalize / suggest a value (repo name, branch name, description rewrite, team list, topic list, full file preview, commit message), present it for user confirmation.

**Rendering rules (apply in this order):**

1. In VS Code Copilot Chat, render via the `vscode_askQuestions` tool. Put the proposed value / context in `message`, choices in `options` as clickable buttons. Do NOT also echo the prompt as plain text. Rules for `options`: (a) NO leading `N.` in `label` — the tool auto-numbers; (b) use `description` for per-option detail (not `label`); (c) mark the smart default with `recommended: true`.
2. Otherwise (plain terminal), print:

   ```
   Proposed <thing>:
   <value>

   [a] accept   [e] edit   [r] regenerate from a different angle   [q] quit
   >
   ```

   and read one keypress from stdin.

Repeat until accepted. Never proceed past a generated value without an explicit accept.
