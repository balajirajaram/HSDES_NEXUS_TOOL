# Failure Modes & Recovery

Loaded on demand when a step errors, or at any time the agent feels stuck.

| Symptom                                                | Action                                                                                                                                    |
| ------------------------------------------------------ | ----------------------------------------------------------------------------------------------------------------------------------------- |
| `gh` not installed                                     | Install `gh` with your OS package manager (`winget` / `apt` / `dnf` / `brew`), then re-invoke.                                          |
| `gh auth status` not logged in                         | Run `gh auth login --hostname github.com --git-protocol https --web` from within the skill, then re-check `gh auth status`. Do NOT abort. |
| `gh repo view intel-innersource/inventory` returns 404 | Active gh account doesn't have Intel SSO. Run `gh auth refresh -h github.com -s read:org` from within the skill, then re-check.           |
| Fork already exists                                    | `gh repo fork` is idempotent. Sync via `git fetch upstream` + `git merge --ff-only`.                                                      |
| Target folder already exists in inventory              | Stop. This skill is for NEW namespaces. Tell the user to invoke a different (smaller-scope) edit flow manually.                           |
| `git push` fails with EC proxy / 403                   | Offer to create the fork in `intel-sandbox` as `personal.<idsid>.inventory` per EC Proxy guidelines; otherwise push from a non-EC host.   |
| Name validation rejects user input                     | Print the specific rule violated and re-prompt. NEVER silently rewrite. Use HITL accept on any suggestion.                                |
| Acronym detected in description, not in allowlist      | Inline mini-prompt: `[e]xpand / [k]eep / [r]emove`. Apply to text. Re-show HITL.                                                          |
| <2 owners or <2 governors                              | Re-prompt. Inventory automation rejects PRs that violate this.                                                                            |
| `gh pr create` fails                                   | Print the compare-fork URL so user can open the PR via browser without losing the pushed branch.                                          |

## References (skill-author only — never show users in the running skill)

- 1Source Docs — Inventory Pull Requests: <https://1source.intel.com/docs/getting_started/pull_request/inventory_pull_request>
- 1Source Docs — Adding and Transferring Repos: <https://1source.intel.com/docs/getting_started/pull_request/inventory_pull_request#adding-and-transferring-repos>
- 1Source Docs — Repository Naming Scheme: <https://1source.intel.com/docs/governance/namespaces>
- 1Source Docs — Team and Access Management: <https://1source.intel.com/docs/getting_started/pull_request/team_and_access_management>
- 1Source Docs — Intel Restricted Organization: <https://1source.intel.com/docs/governance/intel-restricted-organization>
- 1Source Inventory schemas: <https://github.com/intel-innersource/inventory#schemas>
