# Naming Rules & Acronym Handling

Loaded by: **B2** (intent gate validation), **B3** (project name validation), **C1** (repo name validation), **C2** (description acronym scan).

## Repository Naming Rules

Validate every namespace component and project / repo name. Reject + re-prompt on violation, citing the specific rule.

1. Lowercase `a-z`, digits `0-9`, hyphens `-` only.
2. NO underscores. NO uppercase. NO dots inside a component (dots only separate components in the full repo name).
3. The first two levels (`function.domain`) CANNOT contain hyphens.
4. Repo name MUST have ≥3 components: `function.domain.project-name`.
5. Repo name length ≤ 100 chars total.
6. NO team / division / business-unit / org acronyms in the name.
7. Silicon program codenames spelled out (`skylake` not `skl`, `kabylake` not `kbl`).
8. Acronyms allowed in names: `ai bios ci cicd cpu efi fpga gpu hpc hr oa os pdk rfid rtl rtos ui vpu xpu`. Any other acronym must be spelled out.
9. Acronyms allowed unexpanded in DESCRIPTIONS: `API BIOS CPU FPGA GPU OA OS PDK REST RSA SSH URL XML`. All others MUST be expanded on first use.
10. Allowed abbreviations in descriptions: `arch`, `demo`, `devops`, `lab(s)`.

## Name validator usage (B3 / C1)

```powershell
$check = & "$skillDir\scripts\Test-ProjectName.ps1" -Name $projectName | ConvertFrom-Json
if (-not $check.ok) {
    Write-Host "Rejected: $($check.violations -join '; ')" -ForegroundColor Yellow
    # re-prompt
}
```

The acronym heuristic flags suspect tokens but allows override after the user confirms in HITL that the token is a real word (e.g. `core`, `data`, `auth` would flag — user keeps; `dcg`, `iags` flag — user fixes).

## Inline rules-shown-to-user (B3 prompt body)

```
Rules (must satisfy ALL):
  • lowercase a–z, digits 0–9, hyphens '-'
  • NO underscores, NO uppercase, NO dots
  • NO team / division / org acronyms (e.g. DCG, IAGS) — put those in the description instead
  • silicon codenames spelled out (e.g. 'skylake' not 'skl')
  • only these acronyms allowed as-is in names: ai bios ci cicd cpu efi fpga gpu hpc hr oa os pdk rfid rtl rtos ui vpu xpu

Examples:
  ✓ agents-marketplace
  ✓ 1source-documentation
  ✗ AgentsMarketplace      (no uppercase)
  ✗ agents_marketplace     (no underscores)
  ✗ dcg-agents             (no team acronyms)
```

## Description acronym scan flow (C2)

After the user types each description (namespace + repo), scan for tokens matching `[A-Z]{2,}` that are NOT in the rule-9 allowlist. For each unknown acronym, ask:

```
Detected unexpanded acronym: 'DCG'.
Please expand it (the description will be updated automatically) or confirm it should stay as-is.

[e]xpand it (type the expansion)   [k]eep as-is   [r]emove the word
>
```

Apply the user's choice to the text and re-show the full description for HITL accept.

Description prompt body to show inline:

```
Rules:
  • Expand ALL acronyms/abbreviations on first use, except the well-known set:
      API BIOS CPU FPGA GPU OA OS PDK REST RSA SSH URL XML
  • Acceptable abbreviations: arch, demo, devops, lab(s)
```
