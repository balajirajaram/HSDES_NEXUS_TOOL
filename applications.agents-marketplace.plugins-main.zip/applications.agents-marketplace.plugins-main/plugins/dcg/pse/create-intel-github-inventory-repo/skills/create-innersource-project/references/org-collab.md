# Phase C7 — Collab Questionnaire

Loaded ONLY when `$org == intel-collab`. Collect three values; sponsors goes into `repos.yml`, the other two are posted as a PR comment (handled by `pr-publish.md`).

## Collect (each HITL-confirmed)

- **Sponsors** — ≥2 Intel emails who may add external collaborators. Written to `sponsors:` in `repos.yml`. Same validation as owners: every entry matches `^[a-z0-9._%+-]+@intel\.com$`, ≥2 entries, no duplicates.
- **External party emails** — informational, posted as a PR comment.
- **CNDA document number** — required, posted as a PR comment.

## Output

Store as `$sponsors[]`, `$externalEmails[]`, `$cndaNumber`.
