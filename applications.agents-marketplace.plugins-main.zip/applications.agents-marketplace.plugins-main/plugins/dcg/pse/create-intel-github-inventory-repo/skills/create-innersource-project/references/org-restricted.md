# Phase C6 — Restricted Questionnaire

Loaded ONLY when `$org == intel-restricted`. Collect plain-text answers; they will be posted as a single PR comment after the PR opens (handled by `pr-publish.md`).

## Inline criteria to show the user

```
intel-restricted requires a Data Classification review. Answer 5 questions.

Acceptable justifications (your "Why" must map to at least one):
  • Intel Top Secret (IPAS exploit code, pre-launch product info >3 years out,
    cryptographic keys, classified data)
  • Third-party NDA disclosure restriction (have the NDA clause handy)
  • Export-controlled (will use AGS entitlements with export-control flags)

NOT acceptable as the sole justification:
  • "Fear of leak / loss of competitiveness"
  • "Fear of misuse by other Intel teams"
  • "Not intended to be open-sourced"

Each answer is HITL-confirmed before we commit.
```

## The five questions (each HITL-confirmed)

1. **What is the code?** — simple-terms description, all acronyms expanded.
2. **Why should it be restricted?** — must reference one acceptable justification above.
3. **Diligence done?** — names of senior leaders / security / legal consulted (+ NDA clause if applicable).
4. **Impact** — what reference value is lost to 1Source/Innersource by restricting it?
5. **Architecture** — is the minimum IP isolated? Future plan to narrow further?

## Optional: secret repo name

```
Does the repository NAME itself need to be secret?
  • If yes, we'll set `allow-override-name: true` in repos.yml and you can rename
    the repo via GitHub Settings AFTER it's created. Pick a meaningful-but-opaque
    name now.
[y/N]:
```

If yes, set `$allowOverrideName = true`. If the user already picked the visible name in B3/C1, prompt them to revise it now and re-validate via `Test-ProjectName.ps1`.

## Output

Store all answers in `$restrictedAnswers` with fields: `what`, `why`, `diligence`, `impact`, `architecture`. Store `$allowOverrideName` (bool).
