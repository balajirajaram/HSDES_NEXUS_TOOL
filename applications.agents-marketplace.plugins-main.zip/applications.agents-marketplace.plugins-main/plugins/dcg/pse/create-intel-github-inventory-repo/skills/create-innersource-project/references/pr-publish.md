# Phase D4 — Push, Open PR, Post Questionnaire Comment

Loaded at D4. Assembles the PR body and the optional questionnaire comment in the parent shell, then hands both to `Publish-InventoryPR.ps1`. That script pushes, runs `gh pr create`, and posts the comment in one call.

## Assemble PR body

```powershell
$prBody = @"
$commitBody

---
**Owners:** $($owners -join ', ')
**Topics:** $($topics -join ', ')
**Visibility:** $visibility
"@
```

## Assemble optional questionnaire comment

```powershell
$commentBody = ''
if ($org -eq 'intel-restricted') {
    $commentBody = @"
**Restricted Repository Questionnaire**

**What is the code?**
$($restrictedAnswers.what)

**Why should it be restricted?**
$($restrictedAnswers.why)

**Diligence done?**
$($restrictedAnswers.diligence)

**Impact**
$($restrictedAnswers.impact)

**Architecture**
$($restrictedAnswers.architecture)
"@
} elseif ($org -eq 'intel-collab') {
    $commentBody = @"
**Collab Questionnaire**

**CNDA document number:** $cndaNumber

**External party emails:**
$( $externalEmails | ForEach-Object { "- $_" } | Out-String )
"@
}
```

## Publish

```powershell
$pub = & "$skillDir\scripts\Publish-InventoryPR.ps1" `
    -InventoryPath $inv -GhLogin $ghLogin -Branch $branch -DefaultBranch $defaultBranch `
    -Title $commitTitle -Body $prBody -CommentBody $commentBody | ConvertFrom-Json

if ($pub.prCreated) {
    Write-Host $pub.prUrl
} elseif ($pub.pushed) {
    Write-Host "Branch pushed: $branch"
    Write-Host "Open the PR manually: $($pub.fallbackUrl)"
} else {
    Write-Host "Push failed — see git output above. No PR opened." -ForegroundColor Red
}
```

## D6 — Closing instructions (after success)

```
✓ PR opened: <URL>

Next:
  1. 1Source automation will append a summary of added namespaces / repos / teams
     to the PR description automatically.
  2. A namespace governor must approve. For restricted/collab orgs, a second
     governor (Data Classification or Collab) must also approve.
  3. To revise: edit files locally on branch '<branch>', then
        git add . ; git commit ; git push
     The PR updates automatically.
  4. When approved, scroll to the bottom of the PR and click
     "Enable auto-merge (squash)". Do NOT click "Update branch" yourself —
     1Source automation handles that.
  5. After merge, the repo is created in GitHub by inventory automation
     (usually within ~1 hour).
```
