# Phase C8 — Permissions & Teams (AGS↔GitHub Bridge)

Loaded at C8. Defines the permission plan, the team-wiring picker, and the per-mode follow-ups.

## Inline reference (show to user)

```
On GitHub:
  GitHub Repo  <-- assigns permission -->  GitHub Team  <-- syncs members from -->  AGS entitlement (AZAD-CORP)

A `teams/<file>.yml` is what creates / wires up that GitHub Team in 1Source.
You need a team yml for EVERY team referenced in repos.yml UNLESS:
  • The team already exists in inventory's teams/ folder (we reuse by name), OR
  • You explicitly want to skip wiring and add individuals via the GitHub UI later
    (requires `allow-extra-members: true`; you take on ISPOL60 compliance manually).

Permission levels available:
  admin     — full control (settings, delete, manage access)
  maintain  — manage repo without admin/destructive actions
  write     — push branches directly. Auto-subscribes members to ALL notifications.
              Keep this list TINY. Big groups with write break the watch list.
  triage    — manage issues/PRs without code write
  read      — view + submit PRs from forks (the default contribution model)

`owners-as-admins: true` — gives every email in repos.yml `owners:` admin permission
                          automatically. Recommended ON. Default: ON.

`allow-extra-members: true` — lets you add individuals via GitHub UI without them
                              being wiped by the next 1Source sync. Default: OFF.
```

## Default permission plan prompt

```
Default permission plan (derived from project name '<projectName>'):

  admin:
    - <projectName>-admins
  write:
    - <projectName>-maintainers
  read:
    - gb-<projectName>-readers       (generic accounts / broad read)
  owners-as-admins: true
  allow-extra-members: false

[a] accept all 3 rows + flags
[e] edit per row (you'll be asked about each row + each flag)
[m] minimal plan: just `admin: <projectName>-admins` + `owners-as-admins: true`
    (rely on innersource implicit read; OK for non-private or low-control repos)
[c] custom (add/remove arbitrary rows; pick from admin/maintain/write/triage/read)
[q] quit
>
```

## Per-team AGS wiring picker

After the permission plan is finalized, **for each team name listed**, show this prompt with all four options in fixed 1→2→3→4 order. Do NOT reorder based on the team name — only the highlighted default changes.

```
Team: '<teamName>'
How is this team wired to AGS (the system that controls who's in the team)?

A GitHub team's members come from an AGS entitlement — an Active Directory
group whose display name usually starts with `AZAD-CORP-…`. The only
exception is generic / machine-account teams, which list accounts directly.
Pick the option that matches your situation:

  1. CREATE a brand-new AGS entitlement
     Pick this when no AD group exists yet and you want 1Source to make one.
     • 1Source automation creates entitlement `<teamName>` in AZAD-CORP.
     • Writes `managed-by-1source: true` in the team yml.
     • AGS owner is set to 'Owner-1Source Github'.
     • Caveat: a managed-by-1source entitlement CANNOT later be attached to
       an AGS Role — if you need that, create the entitlement manually in AGS
       first and pick option 2 instead.
     What you need from you: nothing. Just confirm.

  2. USE an EXISTING AGS entitlement
     Pick this when your team already has an AD group in AGS and you want
     GitHub team membership synced from it.
     • Membership flows FROM AGS → GitHub; add/remove people in AGS,
       https://ags.intel.com — NOT in GitHub.
     What you need from you: the exact `Role/Entitlement Display Name`
     from AGS (usually starts with `AZAD-CORP-`). You'll paste it next.

  3. SKIP this team's yml — already defined in inventory's `teams/` folder
     Pick this ONLY when you've verified the team yml already exists.
     Search https://github.com/intel-innersource/inventory/tree/<defaultBranch>/teams
     for a file containing `name: <teamName>`.
     • No new yml is written; repos.yml just references the team by name.
     What you need from you: confirm the existing file is the one you mean.

  4. GENERIC-ACCOUNT team (no AGS — list machine accounts directly)
     Pick this for teams of service / faceless / generic accounts
     (`sys_*_gh@intel.com`-style emails). These CANNOT come from AGS — they
     must be listed directly under `members:` in the team yml.
     What you need from you: the list of `@intel.com` generic-account
     emails (≥1). You'll paste them next.

> Select [<default>]:
```

**Smart default**: if `<teamName>` begins with `gb-` → default is **4**; otherwise default is **1**. Tell the user inline why the default was chosen (e.g. `(gb- prefix usually denotes a generic-account team)`), but always render options 1→2→3→4 in that order.

## Per-mode follow-up

- **1 (CREATE)** — no follow-up. Add `{ name: <teamName>, mode: 'managed-by-1source', adGroup: <teamName>, owners: $owners, organizations: [...] }` to `$teamsToCreate[]`.

- **2 (USE EXISTING)** — prompt:

  ```
  Paste the exact AGS Role/Entitlement Display Name (typically starts with AZAD-CORP-):
  >
  ```

  HITL-confirm. Add `{ name: <teamName>, mode: 'external-ad-group', adGroup: <pasted>, owners: $owners, organizations: [...] }`.

- **3 (SKIP)** — do not add to `$teamsToCreate[]`. Verify the existing file before continuing:

  ```powershell
  Get-ChildItem $inv\teams -Recurse -Filter '*.yml' | Select-String -Pattern "name:\s*$teamName"
  ```

  If zero matches, warn and re-prompt (they probably meant 1 or 2).

- **4 (GENERIC)** — prompt:

  ```
  Generic-account emails for this team (comma- or newline-separated, ≥1, all @intel.com).
  Example: sys_jacks_gh@intel.com, sys_jacks_ci@intel.com
  >
  ```

  Validate every entry against `^[a-z0-9._%+-]+@intel\.com$`. HITL-confirm. Add `{ name: <teamName>, mode: 'members', members: [<emails>], owners: $owners, organizations: [...] }`.

## Output

Store the finalized `$permissions` map and `$teamsToCreate[]`.
