<#
.SYNOPSIS
  List directory entries at one namespace level via the GitHub Contents API.
  For each child dir, best-effort fetches its namespace.yml description.

.OUTPUT
  JSON array of { Name, Description } objects, alphabetically.
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory)] [string] $RelPath,
    [Parameter(Mandatory)] [string] $DefaultBranch
)

$ErrorActionPreference = 'Stop'

$raw   = gh api "repos/intel-innersource/inventory/contents/$RelPath`?ref=$DefaultBranch"
$items = ($raw | ConvertFrom-Json) |
         Where-Object { $_.type -eq 'dir' } |
         Sort-Object name

$results = foreach ($it in $items) {
    $desc = ''
    $ymlPath = "$RelPath/$($it.name)/namespace.yml"
    try {
        $ymlRaw = gh api "repos/intel-innersource/inventory/contents/$ymlPath`?ref=$DefaultBranch" 2>$null
        if ($LASTEXITCODE -eq 0) {
            $resp = $ymlRaw | ConvertFrom-Json
            if ($resp.content) {
                $decoded = [Text.Encoding]::UTF8.GetString(
                    [Convert]::FromBase64String($resp.content -replace '\s',''))
                $line = ($decoded -split "`n" |
                         Where-Object { $_ -match '^description:' } |
                         Select-Object -First 1)
                if ($line) { $desc = ($line -replace '^description:\s*','').Trim('"') }
            }
        }
    } catch { }
    [PSCustomObject]@{ Name = $it.name; Description = $desc }
}

,$results | ConvertTo-Json -Depth 3 -Compress
