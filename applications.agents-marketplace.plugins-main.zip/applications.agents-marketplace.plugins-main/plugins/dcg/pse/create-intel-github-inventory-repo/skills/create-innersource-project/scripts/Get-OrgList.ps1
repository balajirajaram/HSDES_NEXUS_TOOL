<#
.SYNOPSIS
  List top-level organizations under organizations/ via the GitHub Contents API.

.OUTPUT
  JSON array of org names sorted alphabetically.
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory)] [string] $DefaultBranch
)

$ErrorActionPreference = 'Stop'

$raw = gh api "repos/intel-innersource/inventory/contents/organizations?ref=$DefaultBranch"
$orgs = ($raw | ConvertFrom-Json) |
        Where-Object { $_.type -eq 'dir' } |
        ForEach-Object { $_.name } |
        Sort-Object

# Always emit an array, even with a single result.
,$orgs | ConvertTo-Json -Compress
