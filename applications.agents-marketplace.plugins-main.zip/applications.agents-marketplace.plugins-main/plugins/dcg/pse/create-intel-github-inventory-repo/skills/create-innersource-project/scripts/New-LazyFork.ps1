<#
.SYNOPSIS
  Fork intel-innersource/inventory (idempotent) and create a metadata-only
  sparse clone at $WorkDir\inventory. Wires upstream remote and initializes
  cone-mode sparse-checkout with an empty set.

.OUTPUT
  JSON: { "inv": "<absolute path to clone>", "defaultBranch": "<branch>" }
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory)] [string] $GhLogin,
    [Parameter(Mandatory)] [string] $WorkDir,
    [Parameter(Mandatory)] [string] $DefaultBranch
)

$ErrorActionPreference = 'Stop'

New-Item -ItemType Directory -Force -Path $WorkDir | Out-Null
Set-Location $WorkDir

# Idempotent fork.
gh repo fork intel-innersource/inventory --clone=false --remote=false | Out-Null

$inv = Join-Path $WorkDir 'inventory'

if (-not (Test-Path (Join-Path $inv '.git'))) {
    git clone --filter=blob:none --no-checkout --depth=1 `
        "https://github.com/$GhLogin/inventory.git" $inv | Out-Null
}

Set-Location $inv

# Wire upstream (idempotent).
$existingRemotes = git remote
if ($existingRemotes -notcontains 'upstream') {
    git remote add upstream https://github.com/intel-innersource/inventory.git | Out-Null
}

git sparse-checkout init --cone | Out-Null
git sparse-checkout set '' | Out-Null
git checkout $DefaultBranch --quiet

@{ inv = $inv; defaultBranch = $DefaultBranch } | ConvertTo-Json -Compress
