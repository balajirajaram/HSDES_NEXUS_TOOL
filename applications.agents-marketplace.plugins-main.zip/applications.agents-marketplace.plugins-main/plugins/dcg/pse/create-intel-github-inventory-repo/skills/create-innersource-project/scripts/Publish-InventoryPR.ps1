<#
.SYNOPSIS
  Push the user branch to the fork and open a PR against intel-innersource/inventory.
  Optionally posts a follow-up comment (e.g. restricted/collab questionnaire).

.OUTPUT
  JSON: {
    pushed:       <bool>,
    prUrl:        "<url or empty>",
    prCreated:    <bool>,
    fallbackUrl:  "<compare url to use if prCreated=false>",
    commented:    <bool>
  }
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory)] [string] $InventoryPath,
    [Parameter(Mandatory)] [string] $GhLogin,
    [Parameter(Mandatory)] [string] $Branch,
    [Parameter(Mandatory)] [string] $DefaultBranch,
    [Parameter(Mandatory)] [string] $Title,
    [Parameter(Mandatory)] [string] $Body,
    [Parameter()]          [string] $CommentBody
)

$ErrorActionPreference = 'Continue'

Set-Location $InventoryPath

git push -u origin $Branch
$pushed = ($LASTEXITCODE -eq 0)

$prUrl       = ''
$prCreated   = $false
$fallbackUrl = "https://github.com/intel-innersource/inventory/compare/$DefaultBranch...$($GhLogin):$Branch`?expand=1"
$commented   = $false

if ($pushed) {
    $head = "$GhLogin`:$Branch"
    $prUrl = gh pr create `
        --repo intel-innersource/inventory `
        --base $DefaultBranch `
        --head $head `
        --title $Title `
        --body  $Body 2>$null
    $prCreated = ($LASTEXITCODE -eq 0 -and $prUrl)

    if ($prCreated -and $CommentBody) {
        gh pr comment $prUrl --body $CommentBody 2>$null | Out-Null
        $commented = ($LASTEXITCODE -eq 0)
    }
}

if (-not $prUrl) { $prUrl = '' }

@{
    pushed      = $pushed
    prUrl       = $prUrl
    prCreated   = $prCreated
    fallbackUrl = $fallbackUrl
    commented   = $commented
} | ConvertTo-Json -Compress
