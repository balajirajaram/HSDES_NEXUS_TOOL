<#
.SYNOPSIS
  Render namespace.yml / repos.yml / teams.yml from a single state object.
  Templates live in ../templates/. All conditional fragment logic
  (sponsors, allow-override-name, permission rows, team modes) is handled here.

.PARAMETER StateJson
  Compact JSON describing every collected value. Required fields:
    nsDescription, governors[], repoName, repoDescription, visibility,
    owners[], topics[]
  Optional fields:
    sponsors[]                 - emitted when non-empty (intel-collab only)
    allowOverrideName          - bool, emitted as 'allow-override-name: true'
                                 (intel-restricted only)
    permissions = {
      ownersAsAdmins:   bool,
      allowExtraMembers: bool,
      blocks: {
        admin:    [team, ...],
        maintain: [team, ...],
        write:    [team, ...],
        triage:   [team, ...],
        read:     [team, ...]
      }
    }
    teams = [
      {
        name:          "...",
        mode:          "managed-by-1source" | "external-ad-group" | "members",
        adGroup:       "..."             # for managed-by-1source / external-ad-group
        members:       [email, ...]      # for mode=members (generic-account team)
        owners:        [email, ...],
        organizations: ["intel-innersource", "intel-sandbox", ...]
      }, ...
    ]

.OUTPUT
  JSON: { namespaceYml, reposYml, teamsYml }
  teamsYml is "" when no teams need to be written.
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory)] [string] $StateJson
)

$ErrorActionPreference = 'Stop'

$tplDir   = Join-Path (Split-Path $PSScriptRoot -Parent) 'templates'
$nsTpl    = Get-Content -Raw -Path (Join-Path $tplDir 'namespace.yml.tmpl')
$reposTpl = Get-Content -Raw -Path (Join-Path $tplDir 'repos.yml.tmpl')
$teamsTpl = Get-Content -Raw -Path (Join-Path $tplDir 'teams.yml.tmpl')

$s = $StateJson | ConvertFrom-Json

function Format-Bullets {
    param([array] $Items, [string] $Indent = '  ')
    if (-not $Items -or $Items.Count -eq 0) { return '' }
    return (($Items | ForEach-Object { "$Indent- $_" }) -join "`n")
}

function Apply-Tokens {
    param([string] $Template, [hashtable] $Tokens)
    foreach ($k in $Tokens.Keys) {
        $Template = $Template.Replace("{{$k}}", [string]$Tokens[$k])
    }
    return $Template
}

# ---------------- namespace.yml ----------------
$nsYml = Apply-Tokens $nsTpl @{
    NS_DESCRIPTION    = $s.nsDescription
    GOVERNORS_BULLETS = Format-Bullets $s.governors
}

# ---------------- repos.yml: build conditional chunks ----------------
$sponsorsBlock = ''
if ($s.sponsors -and $s.sponsors.Count -gt 0) {
    $sponsorsBlock = "sponsors:`n" + (Format-Bullets $s.sponsors) + "`n"
}

$allowOverrideLine = ''
if ($s.allowOverrideName) {
    $allowOverrideLine = "allow-override-name: true`n"
}

$permLines = New-Object System.Collections.Generic.List[string]
if ($s.permissions) {
    if ($s.permissions.ownersAsAdmins)    { $permLines.Add('  owners-as-admins: true') }
    if ($s.permissions.allowExtraMembers) { $permLines.Add('  allow-extra-members: true') }
    foreach ($level in 'admin','maintain','write','triage','read') {
        $teamsAtLevel = $s.permissions.blocks.$level
        if ($teamsAtLevel -and $teamsAtLevel.Count -gt 0) {
            $permLines.Add("  ${level}:")
            foreach ($t in $teamsAtLevel) { $permLines.Add("    - $t") }
        }
    }
}
$permRendered = ($permLines -join "`n")

$reposYml = Apply-Tokens $reposTpl @{
    REPO_NAME                   = $s.repoName
    REPO_DESCRIPTION            = $s.repoDescription
    VISIBILITY                  = $s.visibility
    OWNERS_BULLETS              = Format-Bullets $s.owners
    TOPICS_BULLETS              = Format-Bullets $s.topics
    SPONSORS_BLOCK              = $sponsorsBlock
    ALLOW_OVERRIDE_NAME_LINE    = $allowOverrideLine
    PERMISSIONS_FLAGS_AND_TEAMS = $permRendered
}

# ---------------- teams.yml ----------------
$teamsYml = ''
if ($s.teams -and $s.teams.Count -gt 0) {
    $entries = foreach ($t in $s.teams) {
        $lines = New-Object System.Collections.Generic.List[string]
        $lines.Add("- name: $($t.name)")

        switch ($t.mode) {
            'managed-by-1source' {
                $lines.Add("  ad-group: $($t.adGroup)")
                $lines.Add('  managed-by-1source: true')
            }
            'external-ad-group' {
                $lines.Add("  ad-group: $($t.adGroup)")
            }
            'members' {
                # No ad-group; emit members below.
            }
            default {
                throw "Unknown team mode '$($t.mode)' for team '$($t.name)' (expected: managed-by-1source | external-ad-group | members)"
            }
        }

        if ($t.owners -and $t.owners.Count -gt 0) {
            $lines.Add('  owners:')
            foreach ($o in $t.owners) { $lines.Add("    - $o") }
        }

        if ($t.mode -eq 'members' -and $t.members -and $t.members.Count -gt 0) {
            $lines.Add('  members:')
            foreach ($m in $t.members) { $lines.Add("    - $m") }
        }

        if ($t.organizations -and $t.organizations.Count -gt 0) {
            $lines.Add('  organizations:')
            foreach ($o in $t.organizations) { $lines.Add("    - $o") }
        }

        $lines -join "`n"
    }

    $teamsBody = $entries -join "`n`n"
    $teamsYml  = Apply-Tokens $teamsTpl @{ TEAMS_BODY = $teamsBody }
}

@{
    namespaceYml = $nsYml
    reposYml     = $reposYml
    teamsYml     = $teamsYml
} | ConvertTo-Json -Depth 4 -Compress
