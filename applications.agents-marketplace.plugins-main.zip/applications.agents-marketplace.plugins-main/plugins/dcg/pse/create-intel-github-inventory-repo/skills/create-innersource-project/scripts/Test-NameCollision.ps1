<#
.SYNOPSIS
  Check whether a target project folder already exists upstream in inventory.

.OUTPUT
  JSON: { "exists": <bool>, "path": "<full relative path checked>" }
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory)] [string] $Org,
    [Parameter(Mandatory)] [string] $ParentPath,
    [Parameter(Mandatory)] [string] $ProjectName,
    [Parameter(Mandatory)] [string] $DefaultBranch
)

$ErrorActionPreference = 'Continue'   # 404 is expected; do not throw.

$path = "organizations/$Org/repos/$ParentPath/$ProjectName"
gh api "repos/intel-innersource/inventory/contents/$path`?ref=$DefaultBranch" 2>$null | Out-Null
$exists = ($LASTEXITCODE -eq 0)

@{ exists = $exists; path = $path } | ConvertTo-Json -Compress
