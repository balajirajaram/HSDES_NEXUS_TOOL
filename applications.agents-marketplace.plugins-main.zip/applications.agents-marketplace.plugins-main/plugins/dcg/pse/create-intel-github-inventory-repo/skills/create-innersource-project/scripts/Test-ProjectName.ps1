<#
.SYNOPSIS
  Validate a project / namespace component name against deterministic rules.

.OUTPUT
  JSON: { "ok": <bool>, "violations": [<string>, ...] }
  An empty violations array with ok=true means the name passes deterministic
  checks. Suspect-acronym violations may still need a HITL override.
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory)] [string] $Name
)

$ErrorActionPreference = 'Stop'

$bad = New-Object System.Collections.Generic.List[string]

if ($Name.Length -lt 1)                       { $bad.Add('empty') }
if ($Name -cnotmatch '^[a-z0-9-]+$')          { $bad.Add('chars: only a-z 0-9 hyphen (no uppercase, underscore, dot, space)') }
if ($Name -match '^-' -or $Name -match '-$')  { $bad.Add('no leading/trailing hyphen') }
if ($Name -match '--')                         { $bad.Add('no consecutive hyphens') }

$allowedAcronyms = @(
    'ai','bios','ci','cicd','cpu','efi','fpga','gpu','hpc','hr',
    'oa','os','pdk','rfid','rtl','rtos','ui','vpu','xpu'
)

foreach ($tok in ($Name -split '-')) {
    if ($tok.Length -ge 2 -and $tok.Length -le 5 -and
        $tok -match '^[a-z]+$' -and $tok -notin $allowedAcronyms) {
        $bad.Add("suspect acronym token '$tok' - if it's a team/division/codename, spell it out")
    }
}

@{
    ok         = ($bad.Count -eq 0)
    violations = $bad.ToArray()
} | ConvertTo-Json -Compress
