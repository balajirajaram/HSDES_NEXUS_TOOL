<#
.SYNOPSIS
  Sync inventory clone with upstream, create the user branch, write the
  namespace.yml / repos.yml / (optional) teams yml files, stage, and commit.

  YAML content is supplied as fully-rendered strings from the caller so the
  caller (the skill) owns conditional fragment assembly.

.OUTPUT
  JSON: { "branch": "<name>", "committed": <bool>, "filesWritten": [<path>, ...] }
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory)] [string] $InventoryPath,
    [Parameter(Mandatory)] [string] $DefaultBranch,
    [Parameter(Mandatory)] [string] $Branch,
    [Parameter(Mandatory)] [string] $Org,
    [Parameter(Mandatory)] [string] $ParentPath,
    [Parameter(Mandatory)] [string] $ProjectName,
    [Parameter(Mandatory)] [string] $NamespaceYml,
    [Parameter(Mandatory)] [string] $ReposYml,
    [Parameter()]          [string] $TeamsYml,
    [Parameter(Mandatory)] [string] $CommitTitle,
    [Parameter(Mandatory)] [string] $CommitBody
)

$ErrorActionPreference = 'Stop'

Set-Location $InventoryPath

git fetch upstream --quiet
git merge "upstream/$DefaultBranch" --ff-only | Out-Null

git checkout -b $Branch 2>$null
if ($LASTEXITCODE -ne 0) { git checkout $Branch | Out-Null }

$dest = Join-Path $InventoryPath 'organizations'
$dest = Join-Path $dest $Org
$dest = Join-Path $dest 'repos'
foreach ($segment in ($ParentPath -split '/')) {
  if ($segment) { $dest = Join-Path $dest $segment }
}
$dest = Join-Path $dest $ProjectName
New-Item -ItemType Directory -Force -Path $dest | Out-Null

$written = New-Object System.Collections.Generic.List[string]

$nsFile    = Join-Path $dest 'namespace.yml'
$reposFile = Join-Path $dest 'repos.yml'
Set-Content -Path $nsFile    -Value $NamespaceYml -Encoding utf8 -NoNewline
Set-Content -Path $reposFile -Value $ReposYml     -Encoding utf8 -NoNewline
$written.Add($nsFile); $written.Add($reposFile)

if ($TeamsYml) {
    $teamsDir = Join-Path $InventoryPath 'teams'
    New-Item -ItemType Directory -Force -Path $teamsDir | Out-Null
    $teamsFile = Join-Path $teamsDir "$ProjectName.yml"
    Set-Content -Path $teamsFile -Value $TeamsYml -Encoding utf8 -NoNewline
    $written.Add($teamsFile)
}

git add -A
git commit -m $CommitTitle -m $CommitBody | Out-Null
$committed = ($LASTEXITCODE -eq 0)

@{
    branch       = $Branch
    committed    = $committed
    filesWritten = $written.ToArray()
} | ConvertTo-Json -Compress
