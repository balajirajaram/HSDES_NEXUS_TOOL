#!/usr/bin/env bash
# Shared JSON helpers backed by perl + JSON::PP (core module since Perl 5.14, 2011).
# Perl is preinstalled on every mainstream Linux distro and on macOS by default, so
# this avoids requiring jq on Linux/macOS targets.
#
# Sourced by every sibling script:
#     . "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/_json.sh"

# json_get <path>
#   Reads JSON from stdin, prints the scalar at the dotted path (e.g. ".foo.bar" or ".foo[0]").
#   Bools print "true"/"false". Missing prints empty. Non-scalars print compact JSON.
json_get() {
    perl -MJSON::PP -e '
        my $path = shift // "";
        local $/; my $j = decode_json(<STDIN> // "null");
        for my $p (grep { length } split /[\.\[\]]+/, $path) {
            if    (ref $j eq "ARRAY") { $j = $j->[$p+0]; }
            elsif (ref $j eq "HASH")  { $j = $j->{$p}; }
            else                       { $j = undef; last; }
        }
        if    (!defined $j)             { print ""; }
        elsif (JSON::PP::is_bool($j))   { print $j ? "true" : "false"; }
        elsif (ref $j)                  { print encode_json($j); }
        else                            { print $j; }
    ' "$1"
}

# json_get_lines <path>
#   Reads JSON from stdin, treats value at path as array, prints each element on a line.
#   Strings are printed raw; objects/arrays are compact-encoded.
json_get_lines() {
    perl -MJSON::PP -e '
        my $path = shift // "";
        local $/; my $j = decode_json(<STDIN> // "null");
        for my $p (grep { length } split /[\.\[\]]+/, $path) {
            if    (ref $j eq "ARRAY") { $j = $j->[$p+0]; }
            elsif (ref $j eq "HASH")  { $j = $j->{$p}; }
            else                       { $j = undef; last; }
        }
        return unless ref $j eq "ARRAY";
        for my $e (@$j) {
            if    (!defined $e)           { print "\n"; }
            elsif (JSON::PP::is_bool($e)) { print($e ? "true" : "false"), print "\n"; }
            elsif (ref $e)                { print encode_json($e), "\n"; }
            else                          { print $e, "\n"; }
        }
    ' "$1"
}

# json_len <path>
#   Reads JSON from stdin, prints integer length of array/object at path (0 otherwise).
json_len() {
    perl -MJSON::PP -e '
        my $path = shift // "";
        local $/; my $j = decode_json(<STDIN> // "null");
        for my $p (grep { length } split /[\.\[\]]+/, $path) {
            if    (ref $j eq "ARRAY") { $j = $j->[$p+0]; }
            elsif (ref $j eq "HASH")  { $j = $j->{$p}; }
            else                       { $j = undef; last; }
        }
        if    (ref $j eq "ARRAY") { print scalar(@$j); }
        elsif (ref $j eq "HASH")  { print scalar(keys %$j); }
        else                       { print 0; }
    ' "$1"
}

# json_truthy <path>
#   Exit 0 if value at path is truthy; 1 otherwise. Mirrors jq -e behavior:
#   null/false/missing -> falsy; everything else -> truthy.
json_truthy() {
    perl -MJSON::PP -e '
        my $path = shift // "";
        local $/; my $j = decode_json(<STDIN> // "null");
        for my $p (grep { length } split /[\.\[\]]+/, $path) {
            if    (ref $j eq "ARRAY") { $j = $j->[$p+0]; }
            elsif (ref $j eq "HASH")  { $j = $j->{$p}; }
            else                       { exit 1; }
        }
        exit 1 if !defined $j;
        exit 1 if JSON::PP::is_bool($j) && !$j;
        exit 0;
    ' "$1"
}

# json_contains <path> <needle>
#   Exit 0 if array at path contains the string needle.
json_contains() {
    perl -MJSON::PP -e '
        my ($path, $needle) = @ARGV;
        local $/; my $j = decode_json(<STDIN> // "null");
        for my $p (grep { length } split /[\.\[\]]+/, $path // "") {
            if    (ref $j eq "ARRAY") { $j = $j->[$p+0]; }
            elsif (ref $j eq "HASH")  { $j = $j->{$p}; }
            else                       { exit 1; }
        }
        exit 1 unless ref $j eq "ARRAY";
        for my $e (@$j) { next if ref $e; exit 0 if defined($e) && $e eq $needle; }
        exit 1;
    ' "$1" "$2"
}

# json_string
#   Reads raw bytes from stdin, emits a properly quoted/escaped JSON string literal.
json_string() {
    perl -MJSON::PP -e '
        local $/; my $s = <STDIN>; $s //= "";
        print encode_json($s);
    '
}

# json_string_from_file <file>
#   Like json_string but reads from a file path (preserves binary-safe content).
json_string_from_file() {
    perl -MJSON::PP -e '
        open my $fh, "<:raw", $ARGV[0] or die "open: $!";
        local $/; my $s = <$fh>; close $fh; $s //= "";
        print encode_json($s);
    ' "$1"
}

# json_lines_to_array
#   Reads one element per line from stdin, emits compact JSON array of strings.
#   Skips empty lines.
json_lines_to_array() {
    perl -MJSON::PP -e '
        my @a; while (<STDIN>) { chomp; next unless length; push @a, $_; }
        print JSON::PP->new->encode(\@a);
    '
}

# json_jsonl_to_array
#   Reads one JSON value per line from stdin, emits compact JSON array.
json_jsonl_to_array() {
    perl -MJSON::PP -e '
        my @a; while (<STDIN>) { chomp; next unless length; push @a, decode_json($_); }
        print JSON::PP->new->encode(\@a);
    '
}

# json_obj k1 v1 k2 v2 ...
#   Build a compact JSON object from key/value pairs.
#   By default values are strings. Prefix a key with ':' to pass the value as
#   a raw JSON literal (number, bool, array, object, null).
#       json_obj name "Alice" age :30 tags :'["a","b"]'
json_obj() {
    perl -MJSON::PP -e '
        my %o;
        while (@ARGV) {
            my $k = shift @ARGV; my $v = shift @ARGV; $v //= "";
            my $raw = ($k =~ s/^://);
            if ($raw) {
                $o{$k} = decode_json(length($v) ? $v : "null");
            } else {
                $o{$k} = $v;
            }
        }
        print JSON::PP->new->encode(\%o);
    ' "$@"
}
