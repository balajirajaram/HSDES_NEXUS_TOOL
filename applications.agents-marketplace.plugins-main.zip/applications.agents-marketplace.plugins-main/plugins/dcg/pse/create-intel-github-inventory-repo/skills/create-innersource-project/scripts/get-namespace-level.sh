#!/usr/bin/env bash
# List directory entries at one namespace level via the GitHub Contents API.
# For each child dir, best-effort fetches its namespace.yml description.
# Output: JSON array of {Name, Description} objects, alphabetically.
#
# Usage: get-namespace-level.sh --rel-path <path> --default-branch <branch>

set -euo pipefail
IFS=$'\n\t'

REL_PATH=""; DEFAULT_BRANCH=""
while [[ $# -gt 0 ]]; do
    case "$1" in
        --rel-path) REL_PATH="$2"; shift 2 ;;
        --default-branch) DEFAULT_BRANCH="$2"; shift 2 ;;
        -h|--help) sed -n '2,6p' "$0"; exit 0 ;;
        *) echo "Unknown arg: $1" >&2; exit 2 ;;
    esac
done

if [[ -z "$REL_PATH" || -z "$DEFAULT_BRANCH" ]]; then
    echo "Missing required arg(s)" >&2; exit 2
fi

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=_json.sh
. "$SCRIPT_DIR/_json.sh"

names="$(gh api "repos/intel-innersource/inventory/contents/${REL_PATH}?ref=${DEFAULT_BRANCH}" \
    --jq '.[] | select(.type=="dir") | .name' | sort)"

results_file="$(mktemp)"
trap 'rm -f "$results_file"' EXIT

while IFS= read -r name; do
    [[ -z "$name" ]] && continue
    desc=""
    yml_path="${REL_PATH}/${name}/namespace.yml"
    if content_b64="$(gh api "repos/intel-innersource/inventory/contents/${yml_path}?ref=${DEFAULT_BRANCH}" --jq '.content // ""' 2>/dev/null)"; then
        content_b64="$(printf '%s' "$content_b64" | tr -d '[:space:]')"
        if [[ -n "$content_b64" ]]; then
            decoded="$(printf '%s' "$content_b64" | base64 -d 2>/dev/null || true)"
            line="$(printf '%s\n' "$decoded" | grep -E '^description:' | head -n1 || true)"
            if [[ -n "$line" ]]; then
                desc="${line#description:}"
                desc="${desc# }"
                desc="${desc#\"}"
                desc="${desc%\"}"
            fi
        fi
    fi
    json_obj Name "$name" Description "$desc" >> "$results_file"
    printf '\n' >> "$results_file"
done <<< "$names"

json_jsonl_to_array < "$results_file"
