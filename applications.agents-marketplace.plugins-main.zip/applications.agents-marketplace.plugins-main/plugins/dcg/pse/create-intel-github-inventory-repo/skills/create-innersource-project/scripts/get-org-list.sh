#!/usr/bin/env bash
# List top-level organizations under organizations/ via the GitHub Contents API.
# Output: JSON array of org names sorted alphabetically.
# Usage: get-org-list.sh --default-branch <branch>

set -euo pipefail
IFS=$'\n\t'

DEFAULT_BRANCH=""
while [[ $# -gt 0 ]]; do
    case "$1" in
        --default-branch) DEFAULT_BRANCH="$2"; shift 2 ;;
        -h|--help) sed -n '2,4p' "$0"; exit 0 ;;
        *) echo "Unknown arg: $1" >&2; exit 2 ;;
    esac
done

if [[ -z "$DEFAULT_BRANCH" ]]; then
    echo "Missing required --default-branch" >&2; exit 2
fi

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=_json.sh
. "$SCRIPT_DIR/_json.sh"

gh api "repos/intel-innersource/inventory/contents/organizations?ref=$DEFAULT_BRANCH" \
    --jq '.[] | select(.type=="dir") | .name' \
    | sort | json_lines_to_array
