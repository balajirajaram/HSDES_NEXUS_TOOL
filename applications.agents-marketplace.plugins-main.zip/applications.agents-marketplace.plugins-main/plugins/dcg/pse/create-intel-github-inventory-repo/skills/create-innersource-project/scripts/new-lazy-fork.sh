#!/usr/bin/env bash
# Fork intel-innersource/inventory (idempotent) and create a metadata-only
# sparse clone at $WorkDir/inventory. Wires upstream remote and initializes
# cone-mode sparse-checkout with an empty set.
#
# Usage: new-lazy-fork.sh --gh-login <login> --work-dir <dir> --default-branch <branch>
# Output: JSON {"inv": "<abs path>", "defaultBranch": "<branch>"}

set -euo pipefail
IFS=$'\n\t'

GH_LOGIN=""; WORK_DIR=""; DEFAULT_BRANCH=""
while [[ $# -gt 0 ]]; do
    case "$1" in
        --gh-login) GH_LOGIN="$2"; shift 2 ;;
        --work-dir) WORK_DIR="$2"; shift 2 ;;
        --default-branch) DEFAULT_BRANCH="$2"; shift 2 ;;
        -h|--help) sed -n '2,7p' "$0"; exit 0 ;;
        *) echo "Unknown arg: $1" >&2; exit 2 ;;
    esac
done

if [[ -z "$GH_LOGIN" || -z "$WORK_DIR" || -z "$DEFAULT_BRANCH" ]]; then
    echo "Missing required arg(s)" >&2; exit 2
fi

mkdir -p "$WORK_DIR"
cd "$WORK_DIR"

gh repo fork intel-innersource/inventory --clone=false --remote=false >/dev/null 2>&1 || true

inv="$WORK_DIR/inventory"

if [[ ! -d "$inv/.git" ]]; then
    git clone --filter=blob:none --no-checkout --depth=1 \
        "https://github.com/$GH_LOGIN/inventory.git" "$inv" >/dev/null
fi

cd "$inv"

if ! git remote | grep -qx upstream; then
    git remote add upstream https://github.com/intel-innersource/inventory.git
fi

git sparse-checkout init --cone >/dev/null
git sparse-checkout set '' >/dev/null
git checkout "$DEFAULT_BRANCH" --quiet

# shellcheck source=_json.sh
. "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/_json.sh"
json_obj inv "$inv" defaultBranch "$DEFAULT_BRANCH"
