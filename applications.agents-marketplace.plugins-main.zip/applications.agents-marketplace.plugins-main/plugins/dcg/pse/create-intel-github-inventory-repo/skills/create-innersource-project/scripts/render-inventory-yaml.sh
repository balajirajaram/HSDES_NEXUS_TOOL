#!/usr/bin/env bash
# Render namespace.yml / repos.yml / teams.yml from a single state JSON.
# Templates live in ../templates/. All conditional fragment logic (sponsors,
# allow-override-name, permission rows, team modes) is handled here.
#
# Usage:
#   render-inventory-yaml.sh --state-json '<JSON>'
#   render-inventory-yaml.sh --state-file <path>
#
# Required state fields:
#   nsDescription, governors[], repoName, repoDescription, visibility,
#   owners[], topics[]
# Optional state fields:
#   sponsors[], allowOverrideName (bool),
#   permissions = { ownersAsAdmins, allowExtraMembers, blocks:{admin,maintain,write,triage,read} }
#   teams = [ { name, mode, adGroup, members[], owners[], organizations[] } ]
#
# Output: JSON {namespaceYml, reposYml, teamsYml}
# teamsYml is "" when no teams need to be written.

set -euo pipefail
IFS=$'\n\t'

STATE=""
while [[ $# -gt 0 ]]; do
    case "$1" in
        --state-json) STATE="$2"; shift 2 ;;
        --state-file) STATE="$(cat "$2")"; shift 2 ;;
        -h|--help) sed -n '2,20p' "$0"; exit 0 ;;
        *) echo "Unknown arg: $1" >&2; exit 2 ;;
    esac
done

if [[ -z "$STATE" ]]; then
    echo "Missing required --state-json or --state-file" >&2; exit 2
fi

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TPL_DIR="$(cd "$SCRIPT_DIR/../templates" && pwd)"
# shellcheck source=_json.sh
. "$SCRIPT_DIR/_json.sh"

# Format an array of items as YAML bullets at the given indent.
# Args: <dotted-path> <indent>
fmt_bullets() {
    local path="$1" indent="$2"
    local out="" first=1
    while IFS= read -r item; do
        [[ -z "$item" ]] && continue
        if (( first )); then out="${indent}- ${item}"; first=0
        else out="${out}"$'\n'"${indent}- ${item}"
        fi
    done < <(json_get_lines "$path" <<< "$STATE")
    printf '%s' "$out"
}

apply_tokens() {
    # Reads template from stdin, applies tokens via successive awk passes.
    # Tokens passed as alternating <key> <value> pairs.
    local input
    input="$(cat)"
    while (( $# > 0 )); do
        local k="$1" v="$2"; shift 2
        input="$(awk -v needle="{{${k}}}" -v repl="$v" '
            {
                line=$0
                out=""
                while ((idx = index(line, needle)) > 0) {
                    out = out substr(line, 1, idx-1) repl
                    line = substr(line, idx + length(needle))
                }
                print out line
            }
        ' <<< "$input")"
    done
    printf '%s' "$input"
}

# --- namespace.yml -----------------------------------------------------------
NS_DESCRIPTION="$(json_get '.nsDescription' <<< "$STATE")"
GOVERNORS_BULLETS="$(fmt_bullets '.governors' '  ')"

ns_yml="$(apply_tokens \
    NS_DESCRIPTION "$NS_DESCRIPTION" \
    GOVERNORS_BULLETS "$GOVERNORS_BULLETS" \
    < "$TPL_DIR/namespace.yml.tmpl")"

# --- repos.yml conditional chunks -------------------------------------------
REPO_NAME="$(json_get '.repoName' <<< "$STATE")"
REPO_DESCRIPTION="$(json_get '.repoDescription' <<< "$STATE")"
VISIBILITY="$(json_get '.visibility' <<< "$STATE")"
OWNERS_BULLETS="$(fmt_bullets '.owners' '  ')"
TOPICS_BULLETS="$(fmt_bullets '.topics' '  ')"

SPONSORS_BLOCK=""
if (( $(json_len '.sponsors' <<< "$STATE") > 0 )); then
    sponsors_bullets="$(fmt_bullets '.sponsors' '  ')"
    SPONSORS_BLOCK="sponsors:"$'\n'"${sponsors_bullets}"$'\n'
fi

ALLOW_OVERRIDE_NAME_LINE=""
if json_truthy '.allowOverrideName' <<< "$STATE"; then
    ALLOW_OVERRIDE_NAME_LINE="allow-override-name: true"$'\n'
fi

# Permissions block
perm_lines=()
if json_truthy '.permissions' <<< "$STATE"; then
    if json_truthy '.permissions.ownersAsAdmins'    <<< "$STATE"; then
        perm_lines+=("  owners-as-admins: true")
    fi
    if json_truthy '.permissions.allowExtraMembers' <<< "$STATE"; then
        perm_lines+=("  allow-extra-members: true")
    fi
    for level in admin maintain write triage read; do
        count="$(json_len ".permissions.blocks.${level}" <<< "$STATE")"
        if (( count > 0 )); then
            perm_lines+=("  ${level}:")
            while IFS= read -r t; do
                [[ -n "$t" ]] && perm_lines+=("    - $t")
            done < <(json_get_lines ".permissions.blocks.${level}" <<< "$STATE")
        fi
    done
fi
PERMISSIONS_FLAGS_AND_TEAMS="$(printf '%s\n' "${perm_lines[@]:-}" | sed '/^$/d')"

repos_yml="$(apply_tokens \
    REPO_NAME "$REPO_NAME" \
    REPO_DESCRIPTION "$REPO_DESCRIPTION" \
    VISIBILITY "$VISIBILITY" \
    OWNERS_BULLETS "$OWNERS_BULLETS" \
    TOPICS_BULLETS "$TOPICS_BULLETS" \
    SPONSORS_BLOCK "$SPONSORS_BLOCK" \
    ALLOW_OVERRIDE_NAME_LINE "$ALLOW_OVERRIDE_NAME_LINE" \
    PERMISSIONS_FLAGS_AND_TEAMS "$PERMISSIONS_FLAGS_AND_TEAMS" \
    < "$TPL_DIR/repos.yml.tmpl")"

# --- teams.yml ---------------------------------------------------------------
teams_yml=""
teams_count="$(json_len '.teams' <<< "$STATE")"
if (( teams_count > 0 )); then
    entries=()
    i=0
    while (( i < teams_count )); do
        t_lines=()
        name="$(json_get  ".teams[$i].name" <<< "$STATE")"
        mode="$(json_get  ".teams[$i].mode" <<< "$STATE")"
        t_lines+=("- name: $name")

        case "$mode" in
            managed-by-1source)
                ad="$(json_get ".teams[$i].adGroup" <<< "$STATE")"
                t_lines+=("  ad-group: $ad")
                t_lines+=("  managed-by-1source: true")
                ;;
            external-ad-group)
                ad="$(json_get ".teams[$i].adGroup" <<< "$STATE")"
                t_lines+=("  ad-group: $ad")
                ;;
            members)
                : ;;
            *)
                echo "Unknown team mode '$mode' for team '$name' (expected: managed-by-1source | external-ad-group | members)" >&2
                exit 1
                ;;
        esac

        if (( $(json_len ".teams[$i].owners" <<< "$STATE") > 0 )); then
            t_lines+=("  owners:")
            while IFS= read -r o; do
                [[ -n "$o" ]] && t_lines+=("    - $o")
            done < <(json_get_lines ".teams[$i].owners" <<< "$STATE")
        fi

        if [[ "$mode" == "members" ]] && (( $(json_len ".teams[$i].members" <<< "$STATE") > 0 )); then
            t_lines+=("  members:")
            while IFS= read -r m; do
                [[ -n "$m" ]] && t_lines+=("    - $m")
            done < <(json_get_lines ".teams[$i].members" <<< "$STATE")
        fi

        if (( $(json_len ".teams[$i].organizations" <<< "$STATE") > 0 )); then
            t_lines+=("  organizations:")
            while IFS= read -r o; do
                [[ -n "$o" ]] && t_lines+=("    - $o")
            done < <(json_get_lines ".teams[$i].organizations" <<< "$STATE")
        fi

        entry="$(printf '%s\n' "${t_lines[@]}")"
        entries+=("$entry")
        i=$((i+1))
    done

    teams_body=""
    for ((k=0; k<${#entries[@]}; k++)); do
        if (( k > 0 )); then teams_body+=$'\n\n'; fi
        teams_body+="${entries[k]}"
    done

    teams_yml="$(apply_tokens TEAMS_BODY "$teams_body" < "$TPL_DIR/teams.yml.tmpl")"
fi

# --- Emit --------------------------------------------------------------------
json_obj namespaceYml "$ns_yml" reposYml "$repos_yml" teamsYml "$teams_yml"
