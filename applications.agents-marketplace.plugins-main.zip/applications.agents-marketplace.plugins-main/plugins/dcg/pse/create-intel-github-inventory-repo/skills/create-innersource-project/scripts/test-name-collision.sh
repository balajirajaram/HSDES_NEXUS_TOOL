#!/usr/bin/env bash
# Check whether a target project folder already exists upstream in inventory.
# Output: JSON {"exists": <bool>, "path": "<full relative path checked>"}
# Usage:
#   test-name-collision.sh --org <org> --parent-path <p/q> --project-name <name> --default-branch <branch>

set -uo pipefail
IFS=$'\n\t'

ORG=""; PARENT_PATH=""; PROJECT_NAME=""; DEFAULT_BRANCH=""
while [[ $# -gt 0 ]]; do
    case "$1" in
        --org) ORG="$2"; shift 2 ;;
        --parent-path) PARENT_PATH="$2"; shift 2 ;;
        --project-name) PROJECT_NAME="$2"; shift 2 ;;
        --default-branch) DEFAULT_BRANCH="$2"; shift 2 ;;
        -h|--help) sed -n '2,5p' "$0"; exit 0 ;;
        *) echo "Unknown arg: $1" >&2; exit 2 ;;
    esac
done

if [[ -z "$ORG" || -z "$PARENT_PATH" || -z "$PROJECT_NAME" || -z "$DEFAULT_BRANCH" ]]; then
    echo "Missing required arg(s)" >&2; exit 2
fi

path="organizations/${ORG}/repos/${PARENT_PATH}/${PROJECT_NAME}"

exists=false
if gh api "repos/intel-innersource/inventory/contents/${path}?ref=${DEFAULT_BRANCH}" >/dev/null 2>&1; then
    exists=true
fi

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=_json.sh
. "$SCRIPT_DIR/_json.sh"
json_obj :exists "$exists" path "$path"
