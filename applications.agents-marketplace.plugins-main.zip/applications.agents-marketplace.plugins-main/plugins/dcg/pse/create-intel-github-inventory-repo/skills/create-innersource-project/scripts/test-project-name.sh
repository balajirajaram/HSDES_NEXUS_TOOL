#!/usr/bin/env bash
# Validate a project / namespace component name against deterministic rules.
# Output: JSON {"ok": <bool>, "violations": [<string>, ...]}
# Empty violations + ok=true means the name passes deterministic checks.
# Suspect-acronym violations may still need a HITL override.
#
# Usage: test-project-name.sh --name <name>

set -euo pipefail
IFS=$'\n\t'

NAME=""
while [[ $# -gt 0 ]]; do
    case "$1" in
        --name) NAME="$2"; shift 2 ;;
        -h|--help) sed -n '2,7p' "$0"; exit 0 ;;
        *) echo "Unknown arg: $1" >&2; exit 2 ;;
    esac
done

if [[ -z "$NAME" ]]; then
    echo "Missing required --name" >&2
    exit 2
fi

violations=()
if (( ${#NAME} < 1 )); then
    violations+=("empty")
fi
if [[ ! "$NAME" =~ ^[a-z0-9-]+$ ]]; then
    violations+=("chars: only a-z 0-9 hyphen (no uppercase, underscore, dot, space)")
fi
if [[ "$NAME" == -* || "$NAME" == *- ]]; then
    violations+=("no leading/trailing hyphen")
fi
if [[ "$NAME" == *--* ]]; then
    violations+=("no consecutive hyphens")
fi

allowed=(ai bios ci cicd cpu efi fpga gpu hpc hr oa os pdk rfid rtl rtos ui vpu xpu)
is_allowed() {
    local t="$1"
    for a in "${allowed[@]}"; do [[ "$a" == "$t" ]] && return 0; done
    return 1
}

IFS='-' read -ra tokens <<< "$NAME"
for tok in "${tokens[@]}"; do
    len=${#tok}
    if (( len >= 2 && len <= 5 )) && [[ "$tok" =~ ^[a-z]+$ ]] && ! is_allowed "$tok"; then
        violations+=("suspect acronym token '$tok' - if it's a team/division/codename, spell it out")
    fi
done

ok=true
(( ${#violations[@]} > 0 )) && ok=false

. "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/_json.sh"
viol_json="$(printf '%s\n' "${violations[@]:-}" | json_lines_to_array)"
json_obj :ok "$ok" :violations "$viol_json"
