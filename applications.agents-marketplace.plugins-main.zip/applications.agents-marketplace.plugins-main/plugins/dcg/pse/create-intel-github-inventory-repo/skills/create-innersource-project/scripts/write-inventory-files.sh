#!/usr/bin/env bash
# Sync inventory clone with upstream, create the user branch, write the
# namespace.yml / repos.yml / (optional) teams yml files, stage, and commit.
# YAML content is supplied as fully-rendered files from the caller.
#
# Usage:
#   write-inventory-files.sh --inventory-path <dir> --default-branch <branch> --branch <branch> \
#                            --org <org> --parent-path <p/q> --project-name <name> \
#                            --namespace-yml-file <path> --repos-yml-file <path> \
#                            [--teams-yml-file <path>] \
#                            --commit-title <title> --commit-body <body>
#
# Output: JSON {branch, committed, filesWritten:[...]}

set -euo pipefail
IFS=$'\n\t'

INV=""; DEFAULT_BRANCH=""; BRANCH=""
ORG=""; PARENT_PATH=""; PROJECT_NAME=""
NS_FILE=""; REPOS_FILE=""; TEAMS_FILE=""
COMMIT_TITLE=""; COMMIT_BODY=""

while [[ $# -gt 0 ]]; do
    case "$1" in
        --inventory-path) INV="$2"; shift 2 ;;
        --default-branch) DEFAULT_BRANCH="$2"; shift 2 ;;
        --branch) BRANCH="$2"; shift 2 ;;
        --org) ORG="$2"; shift 2 ;;
        --parent-path) PARENT_PATH="$2"; shift 2 ;;
        --project-name) PROJECT_NAME="$2"; shift 2 ;;
        --namespace-yml-file) NS_FILE="$2"; shift 2 ;;
        --repos-yml-file) REPOS_FILE="$2"; shift 2 ;;
        --teams-yml-file) TEAMS_FILE="$2"; shift 2 ;;
        --commit-title) COMMIT_TITLE="$2"; shift 2 ;;
        --commit-body) COMMIT_BODY="$2"; shift 2 ;;
        -h|--help) sed -n '2,14p' "$0"; exit 0 ;;
        *) echo "Unknown arg: $1" >&2; exit 2 ;;
    esac
done

for v in INV DEFAULT_BRANCH BRANCH ORG PARENT_PATH PROJECT_NAME NS_FILE REPOS_FILE COMMIT_TITLE COMMIT_BODY; do
    if [[ -z "${!v}" ]]; then echo "Missing required argument (var: $v)" >&2; exit 2; fi
done

# shellcheck source=_json.sh
. "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/_json.sh"

cd "$INV"

git fetch upstream --quiet
git merge "upstream/$DEFAULT_BRANCH" --ff-only >/dev/null

if ! git checkout -b "$BRANCH" 2>/dev/null; then
    git checkout "$BRANCH" >/dev/null
fi

dest="$INV/organizations/$ORG/repos"
IFS='/' read -ra segs <<< "$PARENT_PATH"
for s in "${segs[@]}"; do
    [[ -n "$s" ]] && dest="$dest/$s"
done
dest="$dest/$PROJECT_NAME"
mkdir -p "$dest"

WRITTEN_FILE="$(mktemp)"
trap 'rm -f "$WRITTEN_FILE"' EXIT

write_no_newline() {
    local target="$1" src="$2"
    # Match the original PS behavior: write contents as-is, no trailing newline added.
    cp "$src" "$target"
    printf '%s\n' "$target" >> "$WRITTEN_FILE"
}

ns_target="$dest/namespace.yml"
repos_target="$dest/repos.yml"
write_no_newline "$ns_target" "$NS_FILE"
write_no_newline "$repos_target" "$REPOS_FILE"

if [[ -n "$TEAMS_FILE" ]]; then
    teams_dir="$INV/teams"
    mkdir -p "$teams_dir"
    teams_target="$teams_dir/${PROJECT_NAME}.yml"
    write_no_newline "$teams_target" "$TEAMS_FILE"
fi

git add -A
committed=true
if ! git commit -m "$COMMIT_TITLE" -m "$COMMIT_BODY" >/dev/null 2>&1; then
    committed=false
fi

files_arr="$(json_lines_to_array < "$WRITTEN_FILE")"

json_obj branch "$BRANCH" :committed "$committed" :filesWritten "$files_arr"
