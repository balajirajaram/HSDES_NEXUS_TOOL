# create-marketplace-plugin

Interactive scaffold for creating and publishing agent marketplace plugins, including metadata collection, asset import, CODEOWNERS update, and PR creation workflow.

## Version

**1.0.0**

## Skills

### 1. create-marketplace-plugin-skill

**Location:** [`skills/create-marketplace-plugin-skill/SKILL.md`](skills/create-marketplace-plugin-skill/SKILL.md)




## Installation

Installed via the marketplace. No manual installation steps required.

## Support

**Owners:**
- aviv.noah@intel.com
- idan.matan.porat@intel.com

**Repository:** https://github.com/intel-innersource/applications.agents-marketplace.plugins

## Changelog

### 1.0.0
- Initial release
