---
name: create-marketplace-plugin-skill
description: "Step-by-step, script-driven workflow that creates a new plugin in intel-innersource/applications.agents-marketplace.plugins (plugin.json + README.md + optional skills/, prompts/, agents/, MCP server) and opens a pull request against main. This is a runbook to EXECUTE in order (run the provided scripts) with a FAST PATH by default (batch independent prompts; compact review unless full preview is requested) - NOT reference material to summarize or mine for facts. Use when: a user wants to add a plugin to the agent plugin marketplace; create / scaffold / publish a marketplace plugin; onboard a new agent / skill / MCP server to the marketplace."
argument-hint: "[plugin-name]  (optional starting hint only; never auto-accepted)"
---

# Create Agent Marketplace Plugin (Orchestrator)

> ## IMPORTANT - Execution contract (read this first)
>
> **This is an executable workflow, NOT reference material.** When this skill is
> invoked you MUST run it as a runbook. Do not skim it for facts and improvise
> your own flow.
>
> - **Execute the phases in order: A -> B -> C -> D.** Never skip Phase A (auth,
>   prerequisites, fork + lazy clone). The clone Phase A creates is what every
>   later phase operates on - do not go looking for a pre-existing local copy.
> - **Run the provided scripts.** Do not reimplement, reorder, or substitute your
>   own steps for what a script already does.
> - **Default to FAST PATH.** Batch independent metadata questions in one turn,
>   then run one section-level HITL confirmation per phase. Keep per-field HITL
>   only when validation fails or the user asks to edit a specific field.
> - **Do not mine this file as a knowledge base** to shortcut or paraphrase the
>   flow.
> - **First action when invoked:** announce `Starting create-marketplace-plugin workflow - Phase A`, then begin at A1.

This file is a phase orchestrator. Reference material lives in [`./references/`](./references/) and is loaded only when its phase runs (keeps context lean).

## References (read on demand)

**At skill start (once):** [`agent-conventions.md`](references/agent-conventions.md), [`naming-rules.md`](references/naming-rules.md), [`plugin-anatomy.md`](references/plugin-anatomy.md).

**When the phase runs:** [`mcp-config.md`](references/mcp-config.md) (C5d) · [`pr-publish.md`](references/pr-publish.md) (D4) · [`failure-modes.md`](references/failure-modes.md) (on any error).

## When to Use

Triggers: "create a new marketplace plugin", "add a plugin to applications.agents-marketplace.plugins", "scaffold a new agent plugin", "publish a plugin to the agent marketplace", "onboard a new MCP server to the marketplace".

Flow: auth → fork+lazy-clone the marketplace repo → set org to `dcg` and pick destination group (`plugins/dcg/<group>/`) from live tree → collect metadata + import existing components (skills / prompts / agents / MCP server) from user-supplied source folders — with section-level HITL confirmations — → render `plugin.json` + `README.md`, copy component files verbatim → update `CODEOWNERS` → commit → push → open PR.

> **`marketplace.json` is NOT touched by this skill** — it is auto-updated by the upstream repo's automation.

## Operating Principles (apply to every step)

1. **Zero-leave-terminal.** Inline every reference the user might need (naming rules, MCP options, plugin anatomy) into the prompt that needs it.
2. **Auto-derive → HITL (fast).** Collect independent fields in one prompt when possible, validate, then confirm once per section. Never silently transform.
   2a. **Plugin-name safety.** Treat plugin name hints as weak suggestions only. Never derive or prefill plugin names from git branch names, PR titles, repository names, or unrelated prior task text.
3. **DCG org is fixed.** Org is always `dcg` for this marketplace flow; only group is selected from the upstream tree via `gh api`.
4. **Numbered defaults.** Selections are numbered with one default highlighted; Enter accepts it.
5. **Validate at the boundary.** Names hit the rules in [`naming-rules.md`](references/naming-rules.md) before any write; reject + re-prompt citing the violated rule.
6. **One PR per run.** One new plugin folder per skill invocation.
7. **Never edit `marketplace.json`.** The upstream automation regenerates it from `plugin.json` files.

> Helper scripts catalog and HITL rendering rules live in [`references/agent-conventions.md`](references/agent-conventions.md) (read at skill start).

## Performance Mode (default)

Use this mode unless the user explicitly asks for a fully guided step-by-step flow.

1. **Cache setup calls.** Run `gh auth status`, identity lookup, and default-branch lookup once and reuse values.
2. **Batch metadata input.** Ask for description, additional owners, IT exposure, and keywords in one combined prompt.
3. **Minimize non-critical gates.** Skip extra continue prompts after successful setup; proceed automatically and only stop on errors.
4. **Compact review by default.** Show a summary + changed file list. Show full file previews only if user asks.
5. **Single correction loop.** If validation fails, re-prompt only the failing field(s), not the whole section.

---

## Phase A — Setup (run before any content prompts)

### A0. Pick your shell

This skill ships two parallel sets of helpers:

- **Windows** uses the `.ps1` scripts in [`./scripts/`](./scripts/) and runs in the built-in Windows PowerShell (5.1) or PowerShell 7+.
- **Linux / macOS** uses the `.sh` scripts in the same folder and runs in `bash` 4+. No PowerShell install required.

Follow the matching code block for your OS in every step below. After cloning this skill, Linux/macOS users mark the scripts executable once:

```bash
chmod +x "$skillDir"/scripts/*.sh
```

### A1. Prerequisite binaries

```powershell
# Windows
git --version
gh --version
$PSVersionTable.PSEdition
$PSVersionTable.PSVersion
```

```bash
# Linux / macOS
git --version
gh --version
perl -MJSON::PP -e 'print "ok\n"'   # JSON::PP is core perl, preinstalled
curl --version | head -1
bash --version | head -1
```

If any prerequisite is missing, propose the relevant install command via HITL accept (`[a] install / [q] quit`) and run it on `[a]`:

On Windows:

```powershell
winget install --id Git.Git --silent --accept-package-agreements --accept-source-agreements
winget install --id GitHub.cli --silent --accept-package-agreements --accept-source-agreements
```

On Linux (Debian/Ubuntu):

```bash
sudo apt update && sudo apt install -y git gh curl
```

On Linux (RHEL/Fedora):

```bash
sudo dnf install -y git gh curl
```

On macOS:

```bash
brew install git gh curl
```

Re-check the versions before proceeding.

### A2. GitHub auth + Intel proxy

Set Intel proxy env vars for the current shell session (inherited by `gh` / `git`):

```powershell
# Windows
. (Join-Path $skillDir 'scripts/Set-IntelProxyEnv.ps1')
```

```bash
# Linux / macOS
. "$skillDir/scripts/set-intel-proxy-env.sh"
```

Then run `gh auth status`. If it reports not logged in, run `gh auth login --hostname github.com --git-protocol https --web` and wait for the user to finish the browser flow, then run `gh auth status` again. Keep re-prompting until the status check reports an authenticated session on `github.com`. Then capture the active identity:

```powershell
# Windows
$ghLogin = (gh api user --jq .login)
$ghEmail = (gh api user --jq .email)
$ghName  = (gh api user --jq .name)
```

```bash
# Linux / macOS
ghLogin="$(gh api user --jq .login)"
ghEmail="$(gh api user --jq .email)"
ghName="$(gh api user --jq .name)"
```

### A3. Verify marketplace reachability

```powershell
# Windows
$repoInfo = gh repo view intel-innersource/applications.agents-marketplace.plugins `
    --json name,defaultBranchRef --jq '{name: .name, defaultBranch: .defaultBranchRef.name}' | ConvertFrom-Json
$defaultBranch = $repoInfo.defaultBranch
```

```bash
# Linux / macOS
defaultBranch="$(gh repo view intel-innersource/applications.agents-marketplace.plugins \
    --json defaultBranchRef --jq '.defaultBranchRef.name')"
```

Must resolve `defaultBranch` to a non-null value (usually `main`).

### A4. Idsid (auto-derived, no HITL)

Derive `$idsid` silently from `$ghEmail` (local-part of the `@intel.com` address). Fall back to `$ghLogin` if the email isn't available. Surface the resolved value in one line so the user sees it but is not prompted:

```powershell
# Windows
$idsid = if ($ghEmail -match '^([^@]+)@intel\.com$') { $Matches[1] } else { $ghLogin }
Write-Host "idsid: $idsid" -ForegroundColor DarkGray
```

```bash
# Linux / macOS
if [[ "$ghEmail" =~ ^([^@]+)@intel\.com$ ]]; then
    idsid="${BASH_REMATCH[1]}"
else
    idsid="$ghLogin"
fi
printf 'idsid: %s\n' "$idsid"
```

The user can override later by re-running with a different `gh` active account; no in-skill prompt.

### A5. Fork + lazy sparse clone (fast — no full tree download)

Metadata-only clone now; sparse-fetch `plugins/` and `.github/` so the working tree only ever holds the directories we read or write.

```powershell
# Windows
$work = Join-Path ([Environment]::GetFolderPath('UserProfile')) 'gitwork'
$forkInfo = & "$skillDir\scripts\New-LazyMarketplaceFork.ps1" `
    -GhLogin $ghLogin -WorkDir $work -DefaultBranch $defaultBranch | ConvertFrom-Json
$mkt = $forkInfo.mkt
```

```bash
# Linux / macOS
work="$HOME/gitwork"
forkInfo="$("$skillDir/scripts/new-lazy-marketplace-fork.sh" \
    --gh-login "$ghLogin" --work-dir "$work" --default-branch "$defaultBranch")"
mkt="$(jq -r .mkt <<< "$forkInfo")"
```

`$mkt` is the local clone root. Surface it prominently and continue automatically in fast mode (no extra continue gate). If the user asks to inspect the clone first, pause here.

```powershell
# Windows
Write-Host ""
Write-Host "Marketplace cloned to: $mkt" -ForegroundColor Cyan
Write-Host ""
try {
  if ($IsWindows -or $PSVersionTable.PSEdition -eq 'Desktop') { Start-Process explorer.exe $mkt -ErrorAction Stop }
  elseif ($IsMacOS) { & open $mkt }
  elseif ($IsLinux) { & xdg-open $mkt 2>$null }
} catch { }
```

```bash
# Linux / macOS
printf '\nMarketplace cloned to: %s\n\n' "$mkt"
case "$(uname -s)" in
    Darwin) open "$mkt" >/dev/null 2>&1 || true ;;
    Linux)  xdg-open "$mkt" >/dev/null 2>&1 || true ;;
esac
```

Do not preload any files from `$mkt` into context — keep using live `gh api` calls until D3.

---

## Phase B — Pick destination under dcg (everything from live folder listings)

### B1. Set organization (fixed)

Set the org to `dcg` without prompting:

```powershell
# Windows
$org = 'dcg'
Write-Host "Org fixed to: $org" -ForegroundColor DarkGray
```

```bash
# Linux / macOS
org='dcg'
printf 'Org fixed to: %s\n' "$org"
```

### B2. Group picker (the team folder under `plugins/dcg/`)

```powershell
# Windows
$groups = & "$skillDir\scripts\Get-PluginGroupList.ps1" `
    -Org $org -DefaultBranch $defaultBranch | ConvertFrom-Json
```

```bash
# Linux / macOS
groups="$("$skillDir/scripts/get-plugin-group-list.sh" \
    --org "$org" --default-branch "$defaultBranch")"
```

Show the live list with `[+] Create a new group folder` as an extra option:

```
Which group under plugins/dcg/ owns this plugin?
  1. admabe
  2. dcee
  3. pse
  ...
  [+] Create a new group folder (will be created by this PR)
  [q] quit
> Select [<smart-default-from-idsid-or-hint>]:
```

If `[+]`, prompt for the new group name (same character rules as plugin name in B3), HITL-confirm, and proceed. Store as `$group`.

### B3. Plugin name

```
The plugin name is the new folder name under:
    plugins/dcg/<group>/

It also becomes the `name:` field in plugin.json.

Rules (must satisfy ALL):
  • lowercase a–z, digits 0–9, hyphens '-'
  • NO underscores, NO uppercase, NO dots, NO spaces
  • NO leading/trailing hyphen, NO consecutive hyphens
  • length 3–60 chars

Convention: end the name with '-plugin' if it bundles skills / agents / prompts,
or '-mcp-server' if it's purely an MCP server wrapper. Not enforced.

Examples:
  ✓ github-inventory-plugin
  ✓ redfish-mcp
  ✓ hygiene-session-summary-plugin
  ✗ AgentsMarketplace     (uppercase)
  ✗ my_plugin             (underscore)
  ✗ -leading-hyphen       (leading hyphen)

Plugin name?
>
```

Enforce with the deterministic validator BEFORE the HITL accept:

```powershell
# Windows
$check = & "$skillDir\scripts\Test-PluginName.ps1" -Name $pluginName | ConvertFrom-Json
if (-not $check.ok) {
    Write-Host "Rejected: $($check.violations -join '; ')" -ForegroundColor Yellow
    # re-prompt
}
```

```bash
# Linux / macOS
check="$("$skillDir/scripts/test-plugin-name.sh" --name "$pluginName")"
if [[ "$(jq -r .ok <<< "$check")" != "true" ]]; then
    echo "Rejected: $(jq -r '.violations|join("; ")' <<< "$check")"
    # re-prompt
fi
```

Then HITL-confirm. Check for collision against the live remote:

```powershell
# Windows
$collision = & "$skillDir\scripts\Test-PluginCollision.ps1" `
    -Org $org -Group $group -PluginName $pluginName `
    -DefaultBranch $defaultBranch | ConvertFrom-Json
if ($collision.exists) { <re-prompt: "That plugin folder already exists upstream. Pick a different name."> }
```

```bash
# Linux / macOS
collision="$("$skillDir/scripts/test-plugin-collision.sh" \
    --org "$org" --group "$group" --plugin-name "$pluginName" \
    --default-branch "$defaultBranch")"
if [[ "$(jq -r .exists <<< "$collision")" == "true" ]]; then
    : # re-prompt: "That plugin folder already exists upstream. Pick a different name."
fi
```

Store as `$pluginName`.

---

## Phase C — Content (interactive, fast-path section confirmations)

### C1. Metadata batch (fast path)

In fast mode, collect these fields in one prompt:

- one-line description
- additional owners (comma-separated)
- expose to IT marketplace (yes/no)
- keywords (comma-separated; optional to auto-suggest if omitted)

Validate each field, then re-prompt only invalid ones.

### C1a. One-line description

```
One-line description (≤ 200 chars) — what does this plugin DO and for WHOM?
Used in plugin.json:description, README hero, and the marketplace listing.

>
```

Store as `$description` and include it in the section confirmation.

### C2. Owners

```
Owners — Intel emails responsible for reviewing PRs that touch this plugin folder. Will be appended to .github/CODEOWNERS.

**At least two unique Intel owners are required (yourself plus at least one reviewer).**

Default owner (auto-added): your active GitHub Intel email from Phase A (`$ghEmail`) when it is a valid `@intel.com` address.

If `$ghEmail` is missing or not an Intel address, ask explicitly for the primary owner Intel email (do not synthesize from idsid/login).

Additional owners (single chat line, required): comma-separated Intel emails. You must provide at least one additional Intel email.

Example: first.last2@intel.com, first.last3@intel.com

>
```

Suggested collection flow (single-line add-more UX):

```powershell
# Windows
$primaryOwner = $null
if (-not ($ghEmail -match '^[a-z0-9._%+-]+@intel\.com$')) {
        $primaryOwner = Read-Host 'Primary owner Intel email (required because GitHub email is unavailable/non-Intel)'
}

$moreRaw = Read-Host 'Additional owners (comma-separated, required)'
$res     = & "$skillDir\scripts\Get-PluginOwners.ps1" `
    -GhEmail $ghEmail -PrimaryOwner $primaryOwner -Additional $moreRaw | ConvertFrom-Json
if (-not $res.ok) { Write-Host "Rejected: $($res.violations -join '; ')" -ForegroundColor Yellow; <re-prompt> }
$owners = $res.owners
Write-Host ("Default owner: {0}" -f $owners[0]) -ForegroundColor DarkGray
```

```bash
# Linux / macOS
primaryOwner=''
if [[ ! "$ghEmail" =~ ^[a-z0-9._%+-]+@intel\.com$ ]]; then
    read -r -p 'Primary owner Intel email (required because GitHub email is unavailable/non-Intel): ' primaryOwner
fi

read -r -p 'Additional owners (comma-separated, required): ' moreRaw
res="$("$skillDir/scripts/get-plugin-owners.sh" \
    --gh-email "$ghEmail" --primary-owner "$primaryOwner" --additional "$moreRaw")"
if [[ "$(jq -r .ok <<< "$res")" != "true" ]]; then
    echo "Rejected: $(jq -r '.violations|join("; ")' <<< "$res")"
    # re-prompt
fi
mapfile -t owners < <(jq -r '.owners[]' <<< "$res")
printf 'Default owner: %s\n' "${owners[0]}"
```

Store as `$owners[]` and include it in the section confirmation.

### C2.5. IT Marketplace Exposure

Prompt the user:

```
Would you like to expose this plugin to the Intel IT central marketplace (in addition to GENI)?
If yes, the plugin will be discoverable by all Intel employees in the IT marketplace.
```

If yes, add `"intel_global"` to the `tags` array in plugin.json. If no, omit it.

Store as `$exposeToITMarketplace` (boolean).

### C3. Keywords

```
Keywords — short topic tags (lowercase, hyphens allowed, NO spaces, NO underscores).
Used for marketplace search. 3–10 keywords recommended.

Suggested from your description:
  <auto-derived nouns from $description and $pluginName>

[a] accept   [e] edit (comma-separated)   [+] add   [-] remove   [q] quit
>
```

Store as `$keywords[]` and include it in the section confirmation.

### C4. Components

```
Which components does this plugin bundle? (multi-select)

  [ ] 1. skills/       — one or more SKILL.md workflows
  [ ] 2. prompts/      — *.prompt.md files for agent invocation
  [ ] 3. agents/       — *.md agent persona files
  [ ] 4. MCP server    — .mcp.json + server.json (HTTP or local-process)

At least one must be selected.
> Select (e.g. 1,3 or 1,4):
```

Store as `$components` (set of `skills|prompts|agents|mcp`). At least one required — re-prompt otherwise.

### C5. Per-component import (wrap existing artifacts — do NOT author here)

The skill assumes every selected component already exists on disk as a finished artifact. C5 only **imports + wraps** them into the plugin folder. Authoring SKILL.md / prompt / agent / MCP files is out of scope — build them in your own workspace first, then run this skill.

For each selected component, prompt for one source folder (or file, for MCP), verify it has the expected artifacts, and copy them verbatim. If the source is missing or empty, **reject and re-prompt** — never fall back to scaffolding.

#### C5a. skills/ (only if `skills ∈ $components`)

Before asking for a path, always ask the scaffolding gate:

```
Do you need to scaffold a new skill before importing?
    1. Yes, scaffold first
    2. No, import existing skill folder now
    [q] quit
> Select [2]:
```

If the user selects `1`, stop this run and instruct them to scaffold the skill first, then re-run this workflow to import it.

```
Path to your existing skill(s) source folder. Two accepted shapes:

  1. Single-skill folder — the path itself contains a SKILL.md.
     The folder is imported as one skill; its folder name (as-is) becomes
     plugins/<org>/<group>/<pluginName>/skills/<folder-name>/.

  2. Parent-of-skills folder — the path itself has NO SKILL.md, but each
     immediate subfolder contains a SKILL.md. Each subfolder is imported
     (recursively) into plugins/<org>/<group>/<pluginName>/skills/<sub>/.

>
```

Validate + load file contents into state (supports both shapes):

```powershell
# Windows
$res = & "$skillDir\scripts\Import-PluginAsset.ps1" -Kind skills -Path $skillsSrc | ConvertFrom-Json
$skillFiles = $res.files
$skillNames = $res.names
```

```bash
# Linux / macOS
res="$("$skillDir/scripts/import-plugin-asset.sh" --kind skills --path "$skillsSrc")"
skillFiles="$(jq -c '.files' <<< "$res")"
skillNames="$(jq -c '.names' <<< "$res")"
```

HITL-confirm the resolved `$skillNames` list before proceeding.

#### C5b. prompts/ (only if `prompts ∈ $components`)

```
Path to your existing prompts source. Two accepted shapes:

  1. Single file — a path ending in `.prompt.md` is imported as one prompt
     (filename preserved) into plugins/<org>/<group>/<pluginName>/prompts/.

  2. Folder — every `*.prompt.md` directly under it is copied into
     plugins/<org>/<group>/<pluginName>/prompts/.

>
```

```powershell
# Windows
$res = & "$skillDir\scripts\Import-PluginAsset.ps1" -Kind prompts -Path $promptsSrc | ConvertFrom-Json
$promptFiles = $res.files
```

```bash
# Linux / macOS
res="$("$skillDir/scripts/import-plugin-asset.sh" --kind prompts --path "$promptsSrc")"
promptFiles="$(jq -c '.files' <<< "$res")"
```

HITL-confirm the resolved filename list.

#### C5c. agents/ (only if `agents ∈ $components`)

```
Path to your existing agents source. Two accepted shapes:

  1. Single file — a path to a `.md` file is imported as one agent (filename
     preserved) into plugins/<org>/<group>/<pluginName>/agents/.

  2. Folder — every `*.md` directly under it is copied into
     plugins/<org>/<group>/<pluginName>/agents/.

>
```

```powershell
# Windows
$res = & "$skillDir\scripts\Import-PluginAsset.ps1" -Kind agents -Path $agentsSrc | ConvertFrom-Json
$agentFiles = $res.files
```

```bash
# Linux / macOS
res="$("$skillDir/scripts/import-plugin-asset.sh" --kind agents --path "$agentsSrc")"
agentFiles="$(jq -c '.files' <<< "$res")"
```

HITL-confirm the resolved filename list.

#### C5d. MCP server (only if `mcp ∈ $components`)

```
Path to your existing MCP server source. Two accepted shapes:

  1. Single file — a path to `.mcp.json` (HTTP or local). If a sibling
     `server.json` exists in the same folder, it is auto-copied too.

  2. Folder — must contain `.mcp.json`; if it also contains `server.json`,
     both are copied.

Advanced: you may still pass an explicit `$serverJsonPath` to override the
auto-detected sibling.

>
```

```powershell
# Windows
$res = & "$skillDir\scripts\Import-PluginAsset.ps1" `
    -Kind mcp -Path $mcpJsonPath -ServerJsonPath $serverJsonPath | ConvertFrom-Json
$mcpJson    = $res.mcpJson
$serverJson = $res.serverJson
```

```bash
# Linux / macOS
res="$("$skillDir/scripts/import-plugin-asset.sh" \
    --kind mcp --path "$mcpJsonPath" --server-json-path "$serverJsonPath")"
mcpJson="$(jq -r .mcpJson <<< "$res")"
serverJson="$(jq -r .serverJson <<< "$res")"
```

HITL-confirm the resolved file paths.

### C6. License + category

```
License (default 'MIT'):       [a] accept   [e] edit
Category (default 'developer-tools'):  [a] accept   [e] edit
```

Store as `$license`, `$category`.

---

## Phase D — Review, write, commit, push, PR

### D1. Compact summary (default) + optional full previews

Default in fast mode: render a compact summary (destination, owners, components, branch, PR title) plus the list of files to be written. Ask one confirmation gate.

Only render full file previews when the user explicitly asks for `full preview`.

```
─── Summary ───
Org / Group / Plugin:   plugins/<org>/<group>/<pluginName>
Description:            <description>
Owners:                 <list>
Keywords:               <list>
Components:             <list>
Skills imported:        <list of skill folder names>
Prompts imported:       <list of *.prompt.md filenames>
Agents imported:        <list of *.md filenames>
MCP server:             <none | http(<url>) | local(<command>)>
Branch:                 user/<ghLogin>/add-<pluginName>
PR title:               Add <pluginName> plugin (<org>/<group>)

Files to be written:
    - plugins/<org>/<group>/<pluginName>/plugin.json
    - plugins/<org>/<group>/<pluginName>/README.md
    - plugins/<org>/<group>/<pluginName>/.mcp.json       (only if mcp)
    - plugins/<org>/<group>/<pluginName>/server.json     (only if mcp)
    - plugins/<org>/<group>/<pluginName>/skills/<name>/SKILL.md  (per skill)
    - plugins/<org>/<group>/<pluginName>/prompts/<name>.prompt.md (per prompt)
    - plugins/<org>/<group>/<pluginName>/agents/<name>.md (per agent)

─── .github/CODEOWNERS  (appended line) ───
/plugins/<org>/<group>/<pluginName>/    <owners space-separated>

[a] accept and create the PR
[e] go back and edit a specific section
[q] quit without writing anything
>
```

If the user asks for `full preview`, print full contents for all generated/copied files before the final accept gate.

### D2. Render plugin files

The output files are rendered by `Render-PluginFiles.ps1` from a single state object. Templates live in [`./templates/`](./templates/): `plugin.json.tmpl`, `README.md.tmpl`. Component files (skills/prompts/agents and `.mcp.json`/`server.json`) are imported verbatim in Phase C5 — no template is applied to them.

Build the state object in the parent shell from the collected variables, hand it to the renderer as compact JSON. By C5 you already have `$skillFiles`, `$promptFiles`, `$agentFiles`, `$mcpJson`, `$serverJson` loaded with verbatim file contents — the renderer passes them through unchanged and only generates `plugin.json` + `README.md`:

```powershell
# Windows
$state = @{
    org             = $org
    group           = $group
    pluginName      = $pluginName
    description     = $description
    owners          = $owners
    keywords        = $keywords
    license         = $license
    category        = $category
    components      = $components             # subset of: 'skills','prompts','agents','mcp'
    # Pre-loaded component payloads (already-rendered file contents from C5):
    skillFiles      = $skillFiles             # @( @{relPath; content} ) — verbatim copies
    promptFiles     = $promptFiles            # @( @{relPath; content} )
    agentFiles      = $agentFiles             # @( @{relPath; content} )
    mcpJson         = $mcpJson                # verbatim .mcp.json content, '' when no MCP
    serverJson      = $serverJson             # verbatim server.json content, '' when absent
}

$rendered = & "$skillDir\scripts\Render-PluginFiles.ps1" `
    -StateJson ($state | ConvertTo-Json -Depth 6 -Compress) | ConvertFrom-Json

$pluginJson = $rendered.pluginJson
$readmeMd   = $rendered.readmeMd
# mcpJson / serverJson / skillFiles / promptFiles / agentFiles flow through C5 unchanged —
# the renderer only owns plugin.json + README.md generation.
```

```bash
# Linux / macOS
# Build the state JSON using jq. $owners is a bash array; $keywords likewise.
# $skillFiles / $promptFiles / $agentFiles already hold JSON arrays from C5.
stateJson="$(jq -cn \
    --arg org "$org" --arg group "$group" --arg pluginName "$pluginName" \
    --arg description "$description" --arg license "$license" --arg category "$category" \
    --argjson owners "$(printf '%s\n' "${owners[@]}" | jq -R . | jq -s -c .)" \
    --argjson keywords "$(printf '%s\n' "${keywords[@]}" | jq -R . | jq -s -c .)" \
    --argjson components "$(printf '%s\n' "${components[@]}" | jq -R . | jq -s -c .)" \
    --argjson skillFiles "${skillFiles:-[]}" \
    --argjson promptFiles "${promptFiles:-[]}" \
    --argjson agentFiles "${agentFiles:-[]}" \
    --arg mcpJson "${mcpJson:-}" --arg serverJson "${serverJson:-}" \
    --argjson exposeToITMarketplace "${exposeToITMarketplace:-false}" \
    '{org:$org,group:$group,pluginName:$pluginName,description:$description,
      owners:$owners,keywords:$keywords,license:$license,category:$category,
      components:$components,skillFiles:$skillFiles,promptFiles:$promptFiles,
      agentFiles:$agentFiles,mcpJson:$mcpJson,serverJson:$serverJson,
      exposeToITMarketplace:$exposeToITMarketplace}')"

rendered="$("$skillDir/scripts/render-plugin-files.sh" --state-json "$stateJson")"
pluginJson="$(jq -r .pluginJson <<< "$rendered")"
readmeMd="$(jq -r .readmeMd <<< "$rendered")"
# mcpJson / serverJson / skillFiles / promptFiles / agentFiles already in scope.
```

Files are written UTF-8 (no BOM), LF line endings, 2-space indent for JSON. Edit `.tmpl` files to change `plugin.json` / `README.md` shape; component files are copied verbatim from the user's source folders (no template applied).

### D3. Branch, write, commit

```powershell
# Windows
$branch      = "user/$ghLogin/add-$pluginName"
$commitTitle = "feat($org/$group): add $pluginName plugin"
$commitBody  = $description

$writeResult = & "$skillDir\scripts\Write-PluginFiles.ps1" `
    -MarketplacePath $mkt -DefaultBranch $defaultBranch -Branch $branch `
    -Org $org -Group $group -PluginName $pluginName `
    -Owners ($owners -join ' ') `
    -PluginJson $pluginJson -ReadmeMd $readmeMd `
    -McpJson $mcpJson -ServerJson $serverJson `
    -SkillFilesJson  ($skillFiles  | ConvertTo-Json -Depth 4 -Compress) `
    -PromptFilesJson ($promptFiles | ConvertTo-Json -Depth 4 -Compress) `
    -AgentFilesJson  ($agentFiles  | ConvertTo-Json -Depth 4 -Compress) `
    -CommitTitle $commitTitle -CommitBody $commitBody | ConvertFrom-Json
```

```bash
# Linux / macOS
branch="user/$ghLogin/add-$pluginName"
commitTitle="feat($org/$group): add $pluginName plugin"
commitBody="$description"

# Write large content into temp files so we never blow the arg list.
tmpPlugin="$(mktemp)"; printf '%s' "$pluginJson" > "$tmpPlugin"
tmpReadme="$(mktemp)"; printf '%s' "$readmeMd"   > "$tmpReadme"
mcpArgs=()
if [[ -n "${mcpJson:-}" ]]; then
    tmpMcp="$(mktemp)"; printf '%s' "$mcpJson" > "$tmpMcp"
    mcpArgs+=(--mcp-json-file "$tmpMcp")
fi
if [[ -n "${serverJson:-}" ]]; then
    tmpServer="$(mktemp)"; printf '%s' "$serverJson" > "$tmpServer"
    mcpArgs+=(--server-json-file "$tmpServer")
fi

ownersJoined="$(IFS=' '; echo "${owners[*]}")"

writeResult="$("$skillDir/scripts/write-plugin-files.sh" \
    --marketplace-path "$mkt" --default-branch "$defaultBranch" --branch "$branch" \
    --org "$org" --group "$group" --plugin-name "$pluginName" \
    --owners "$ownersJoined" \
    --plugin-json-file "$tmpPlugin" --readme-md-file "$tmpReadme" \
    "${mcpArgs[@]}" \
    --skill-files-json  "${skillFiles:-[]}" \
    --prompt-files-json "${promptFiles:-[]}" \
    --agent-files-json  "${agentFiles:-[]}" \
    --commit-title "$commitTitle" --commit-body "$commitBody")"
```

The writer:

1. `git fetch upstream` + `git merge --ff-only upstream/<defaultBranch>`
2. `git sparse-checkout add plugins/<org>/<group>` + `.github` (idempotent)
3. Creates branch `user/<idsid>/add-<pluginName>`
4. Writes all plugin files
5. **Appends only** the CODEOWNERS owner line while preserving the file's existing line endings and encoding (does NOT touch `marketplace.json`)
6. `git add -A` + `git commit`

### D4. Push + open PR

> Read [`references/pr-publish.md`](references/pr-publish.md) and follow its spec. Assemble `$prBody`, call the publish helper:

```powershell
# Windows
$publish = & "$skillDir\scripts\Publish-PluginPR.ps1" `
    -MarketplacePath $mkt -GhLogin $ghLogin -Branch $branch `
    -DefaultBranch $defaultBranch `
    -Title "Add $pluginName plugin ($org/$group)" `
    -Body  $prBody | ConvertFrom-Json
```

```bash
# Linux / macOS
tmpBody="$(mktemp)"; printf '%s' "$prBody" > "$tmpBody"
publish="$("$skillDir/scripts/publish-plugin-pr.sh" \
    --marketplace-path "$mkt" --gh-login "$ghLogin" --branch "$branch" \
    --default-branch "$defaultBranch" \
    --title "Add $pluginName plugin ($org/$group)" \
    --body-file "$tmpBody")"
prUrl="$(jq -r .prUrl <<< "$publish")"
prCreated="$(jq -r .prCreated <<< "$publish")"
fallbackUrl="$(jq -r .fallbackUrl <<< "$publish")"
```

On success print the PR URL (`prUrl`) and the closing instructions from `pr-publish.md`. On `prCreated=false` show `fallbackUrl`.
