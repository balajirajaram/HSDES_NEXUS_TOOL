# AGS Owner Entitlement (Phase C2.5)

Plugin reviewers must be members of the **`gb-agents-marketplace-plugins-readers`** AGS so they can read the upstream marketplace repo and review PRs touching their plugin folder. This skill helps the user submit those access requests manually via the AGS UI.

## Why manual instead of API

The IAM AGS Microservice supports automated requests, but only via a user-interactive OAuth flow (the AGS team confirmed this is not intended for headless / app-identity use). At Intel, that requires a dedicated public-client Azure app registration consented to `ags_access` on the target environment's AGS resource — a one-time onboarding step that varies per team and per AGS environment.

To keep the skill universally usable without per-user app-registration plumbing, Phase C2.5 instead opens the AGS UI in the user's default browser, copies the entitlement name to the clipboard, and walks them through a per-owner checklist. The user clicks the buttons; the skill enforces that no owner is silently skipped.

If you later want to automate this, the AGS environment table and credential paths are preserved in this file's [appendix](#appendix--for-future-automation).

## What Phase C2.5 does

1. Copies `gb-agents-marketplace-plugins-readers` to the clipboard.
2. Opens the AGS UI deep-link — the IdentityIQ "Submit Request For Self" quick link — overridable via `AGS_UI_URL`.
3. Runs an inline per-owner prompt loop (`[d]one / [s]kip / [o]pen-again / [c]opy-again / [q]uit`). No file is written until every owner is acknowledged or the user quits.
4. The per-owner status (`submitted` / `skipped`) is captured into the PR body under an "AGS onboarding status" block.

## Per-owner manual steps (what the user does in the browser)

1. Paste the entitlement name into the AGS search bar.
2. Select the matching entitlement (`gb-agents-marketplace-plugins-readers`).
3. Click "Request access" (or equivalent) and submit for the owner.
4. Return to the skill prompt and hit `[d]`.

## Environment overrides

| Variable     | Purpose | Default                                                                                                                                  |
| ------------ | ------- | ---------------------------------------------------------------------------------------------------------------------------------------- |
| `AGS_UI_URL` | AGS UI  | `https://ags.intel.com/identityiq/accessRequest/accessRequest.jsf#/accessRequestSelf/add?quickLink=Intel-QuickLink-SubmitRequestForSelf` |

The entitlement name and AGS UI URL are the only AGS-related values this version of the skill needs. No tokens, secrets, or env vars are required.

## Appendix — for future automation

If your team has (or wants to register) a public-client Azure app with `ags_access` consented, the automated path is straightforward. The relevant per-environment values from the official "IAM AGS Microservice: Environments" page (`https://goto.intel.com/iam-ags` → Environments):

| Env  | Base URL                        | Tenant ID                              | Scope                                                 |
| ---- | ------------------------------- | -------------------------------------- | ----------------------------------------------------- |
| `cd` | https://iam-ags-ms-cd.intel.com | `9889e411-4383-4500-8c2a-e8f095438f4f` | `api://6ee2691f-e017-4258-8c62-340752525d45/.default` |
| `pp` | https://iam-ags-ms-pp.intel.com | `24d2eec2-c04e-4c44-830d-f374a7b9559e` | `api://0bcbb1cd-2c2c-40bb-a39e-a909ea13cb07/.default` |
| `pr` | https://iam-ags-ms-pr.intel.com | `46c98d88-e344-4ed4-8496-4ed7712e255d` | `api://b56ab18f-6990-44d5-b1c4-993c5f4ee602/.default` |

Onboarding portal: <https://goto.intel.com/iam-ags-registration>. The app reg must enable public-client flows and (per the AGS team) be a user-interactive auth flow — not client_credentials. Once configured, a future `Request-OwnerAgsMembership.ps1` could POST to `{base-url}/AccessRequests` with `{requestee:{email}, requestItems:[{operation:'Add', access:{type:'Entitlement', displayName, application}, justification}]}`. The current skill does not ship that helper because the prerequisites vary per team.
