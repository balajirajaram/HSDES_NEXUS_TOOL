# Failure Modes

When a step errors, locate the symptom below and follow the recovery. If nothing matches, stop and ask the user before improvising — the skill is one-PR-per-run and partial state is easy to discard via `git restore`/`git checkout`.

| Symptom                                                 | Likely cause                          | Recovery                                                                                                                                                                                |
| ------------------------------------------------------- | ------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `gh: command not found`                                 | GitHub CLI missing                    | `winget install --id GitHub.cli --silent --accept-package-agreements --accept-source-agreements`                                                                                        |
| `gh auth status` says not logged in                     | Token missing / expired               | `gh auth login --hostname github.com --git-protocol https --web` — then re-run `gh auth status`                                                                                         |
| `wsarecv: An existing connection was forcibly closed`   | Intel proxy not set                   | Re-export `HTTP_PROXY` / `HTTPS_PROXY` / `NO_PROXY` (see Phase A2) in the **current** shell, then retry                                                                                 |
| `gh repo view` returns nothing for the marketplace repo | Network or auth                       | Confirm VPN/proxy + `gh auth status`; if still failing, the repo may have been renamed — verify in browser                                                                              |
| `gh repo fork` returns "already exists"                 | Fork exists from a prior run          | Safe — `New-LazyMarketplaceFork.ps1` is idempotent and uses the existing fork                                                                                                           |
| `Test-PluginName.ps1` returns `ok: false`               | Name violates rules                   | Show `violations[]` to the user verbatim, re-prompt                                                                                                                                     |
| `Test-PluginCollision.ps1` returns `exists: true`       | Plugin folder already exists upstream | Re-prompt for a different plugin name — this skill creates NEW plugins only                                                                                                             |
| `Write-PluginFiles.ps1` returns `committed: false`      | Nothing staged (no actual changes)    | Inspect `git status -s` in `$mkt` — likely the user picked a name identical to an unmerged local branch                                                                                 |
| `git merge --ff-only upstream/main` fails               | Local branch diverged from upstream   | Run `git fetch upstream && git reset --hard upstream/main` on the **local branch** (CONFIRM with user first)                                                                            |
| `Publish-PluginPR.ps1` returns `pushed: false`          | Push rejected / auth                  | Check `gh auth status`, re-export proxy vars, retry. If it still fails, push manually and re-run script                                                                                 |
| `gh pr create` fails after push                         | Network / API hiccup                  | Show `fallbackUrl` to the user — they open the PR via browser                                                                                                                           |
| Reviewer says "remove marketplace.json change"          | Skill incorrectly edited it           | This skill never writes marketplace.json. If a diff appears, it was a stale local edit — revert with `git checkout upstream/main -- .github/plugin/marketplace.json` then commit + push |

## Idempotency guarantees

All helper scripts are safe to re-run:

- `New-LazyMarketplaceFork.ps1` — `gh repo fork` is idempotent; clone is skipped if `.git` exists; remotes are added only when missing.
- `Write-PluginFiles.ps1` — uses `git checkout -b <branch> 2>$null` and falls back to `git checkout <branch>` if the branch already exists.
- `Publish-PluginPR.ps1` — re-running after a successful PR returns `prCreated: false` (gh refuses to open a duplicate PR) but does NOT corrupt anything.

## Discarding a botched run

```powershell
Set-Location $mkt
git checkout main
git branch -D user/<idsid>/add-<pluginName>
git push origin --delete user/<idsid>/add-<pluginName>   # only if it was pushed
```

The local clone stays valid for the next run.
