# MCP Server Configuration (Phase C5d)

Run this flow only when `mcp ∈ $components`. Collect the fields below; the renderer materializes `.mcp.json` + `server.json` from templates.

## Step 1 — Pick the transport type

```
MCP servers come in two flavours. Which one does your plugin ship?

  1. http   — A remote MCP server hosted somewhere (e.g. an internal Kubernetes
              service). The plugin only ships a URL; clients connect over HTTP.
              Example: geni-plugin (https://laas-aks-prod01.../genimcpserver/)

  2. local  — The plugin includes a launchable command (python script, node,
              binary). The client spawns the process locally.
              Example: redfish-mcp (python mcp_server.py)

> Select [1]:
```

Store as `$mcpType` ∈ {`http`, `local`}.

## Step 2 — Server name (both types)

```
Server name (key under "mcpServers" in .mcp.json). Free-form; pick something
descriptive — clients use it to identify the server in their config UI.

Suggested: <pluginName>

>
```

HITL-confirm. Store as `$mcpServerName`.

## Step 3a — HTTP-only fields

```
Server URL (full https:// URL the client should POST to):
>
```

Validate: starts with `https://`. HITL-confirm. Store as `$mcpUrl`.

Resulting `.mcp.json` shape:

```json
{
  "mcpServers": {
    "<server-name>": {
      "type": "http",
      "url": "<url>"
    }
  }
}
```

## Step 3b — Local-only fields

```
Command (the executable + args the client should spawn).
Format: one token per line, e.g.
  python
  mcp_server.py

>
```

Store as `$mcpCommand[]` (array of strings).

```
Environment variables to inject (KEY=VALUE per line, empty line to finish).
Leave empty if none.
Common entries:
  PYTHONIOENCODING=utf-8
  NO_PROXY=127.0.0.1,localhost,10.0.0.0/8

>
```

Store as `$mcpEnv{}` (hashtable). HITL-confirm both fields together. Resulting `.mcp.json` shape:

```json
{
  "mcpServers": {
    "<server-name>": {
      "type": "local",
      "command": ["python", "mcp_server.py"],
      "environment": {
        "PYTHONIOENCODING": "utf-8"
      }
    }
  }
}
```

## server.json (rendered for both types)

```json
{
  "$schema": "https://static.modelcontextprotocol.io/schemas/2025-09-29/server.schema.json",
  "name": "agents-marketplace/<plugin-name>",
  "title": "<derived title-case from plugin-name>",
  "description": "<plugin description from C1>",
  "repository": {
    "url": "https://github.com/intel-innersource/applications.agents-marketplace.plugins",
    "source": "github",
    "subfolder": "plugins/<org>/<group>/<plugin-name>"
  },
  "version": "1.0.0",
  "starters": [
    /* http: one entry mirroring .mcp.json; local: empty array [] */
  ]
}
```

## Hand-off back to SKILL.md

After Step 3 + HITL accept, set:

- `$mcpType`, `$mcpServerName`
- `$mcpUrl` (http) **or** `$mcpCommand[]` + `$mcpEnv{}` (local)

These values are surfaced in the Phase D1 summary. The actual `.mcp.json` / `server.json` files are imported verbatim from the user's source in Phase C5d — no template is applied.
