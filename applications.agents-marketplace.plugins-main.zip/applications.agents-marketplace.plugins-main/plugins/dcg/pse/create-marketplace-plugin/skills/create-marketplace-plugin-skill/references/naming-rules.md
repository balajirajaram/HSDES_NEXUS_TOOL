# Naming Rules

Applies to: plugin folder names, skill folder names, group folder names, prompt/agent basenames.

## Character rules (deterministic — enforced by `Test-PluginName.ps1`)

- Lowercase `a–z`, digits `0–9`, hyphens `-` only
- **No** uppercase, **no** underscores, **no** dots, **no** spaces
- **No** leading or trailing hyphen
- **No** consecutive hyphens
- Length: **3–60 characters**

## Conventions (not enforced — guide the user)

- End plugin name with `-plugin` when it bundles skills / agents / prompts (e.g. `hygiene-session-summary-plugin`)
- End plugin name with `-mcp-server` or `-mcp` when it is purely an MCP server wrapper (e.g. `redfish-mcp`, `trust-mcp-server`)
- Skill folder name should match what the skill _does_, not the plugin (e.g. plugin `geni-plugin` contains skill `acquire-tokens`)
- Prompt file basename: lowercase, words separated by `-` or `_` (existing repo uses both). The renderer adds the `.prompt.md` suffix.

## Owner email rule

- Each owner email must match `^[a-z0-9._%+-]+@intel\.com$` (case-insensitive)
- Minimum: 1 owner; recommended: 2+ for bus-factor

## Examples (live in the repo)

| Plugin                           | Pattern                   |
| -------------------------------- | ------------------------- |
| `geni-plugin`                    | skills + MCP server       |
| `redfish-mcp`                    | pure MCP server           |
| `hygiene-session-summary-plugin` | prompts + skill           |
| `create-gh-intel-project`        | skill-only (no MCP)       |
| `dmr-bios-expert`                | skill-only knowledge base |

Reject + re-prompt on any violation, citing the specific rule that failed (the validator returns a `violations[]` array).
