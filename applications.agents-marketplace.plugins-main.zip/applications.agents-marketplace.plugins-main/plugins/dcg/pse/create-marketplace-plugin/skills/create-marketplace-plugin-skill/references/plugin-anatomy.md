# Plugin Anatomy

A marketplace plugin is a folder under `plugins/<org>/<group>/<plugin-name>/`. Required + optional contents are documented below. The renderer in this skill writes only what was requested in Phase C4 (`$components`).

## Always written

| File          | Required | Purpose                                                                                                                                         |
| ------------- | -------- | ----------------------------------------------------------------------------------------------------------------------------------------------- |
| `plugin.json` | yes      | Manifest. `name`, `description`, `version`, `license`, `keywords`, `category`, `repository`, optional `skills`, `mcpServers`, `tags`.           |
| `README.md`   | yes      | Human-readable plugin documentation. Standard sections: Features, Skills, MCP Server, Installation, Usage, Troubleshooting, Support, Changelog. |

## Conditional — written only when the matching component is selected

| Path                           | Component | Contents                                                                                                                                                 |
| ------------------------------ | --------- | -------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `skills/<name>/SKILL.md`       | `skills`  | One folder per skill, copied **verbatim** from the user's source path in Phase C5a. The skill does not author SKILL.md — it must already exist.            |
| `prompts/<basename>.prompt.md` | `prompts` | Copied **verbatim** from the user's source folder in C5b. Must already exist.                                                                            |
| `agents/<basename>.md`         | `agents`  | Copied **verbatim** from the user's source folder in C5c. Must already exist.                                                                            |
| `.mcp.json`                    | `mcp`     | MCP server configuration. Either HTTP-type with `url`, or local-type with `command`+`environment`. See [`mcp-config.md`](mcp-config.md).                 |
| `server.json`                  | `mcp`     | MCP server descriptor (schema: `https://static.modelcontextprotocol.io/schemas/2025-09-29/server.schema.json`). Repository pointer + version + starters. |

## Always touched outside the plugin folder

| File                 | Change                                                                             |
| -------------------- | ---------------------------------------------------------------------------------- |
| `.github/CODEOWNERS` | Append one line: `/plugins/<org>/<group>/<plugin-name>/  <space-separated owners>` |

## Never touched

| File                                                                             | Why                                                                                                       |
| -------------------------------------------------------------------------------- | --------------------------------------------------------------------------------------------------------- |
| `.github/plugin/marketplace.json`                                                | Upstream automation regenerates it from each plugin's `plugin.json`. Hand-editing causes merge conflicts. |
| Anything outside `plugins/<org>/<group>/<plugin-name>/` and `.github/CODEOWNERS` | One-plugin-per-PR scope.                                                                                  |

## plugin.json schema (minimum viable)

```json
{
  "name": "<plugin-name>",
  "description": "<one-liner>",
  "version": "1.0.0",
  "license": "MIT",
  "keywords": ["<kw1>", "<kw2>"],
  "category": "developer-tools",
  "repository": "https://github.com/intel-innersource/applications.agents-marketplace.plugins",
  "homepage": "https://github.com/intel-innersource/applications.agents-marketplace.plugins/tree/main/plugins/<org>/<group>/<plugin-name>",
  "tags": ["intel_global"]
}
```

Add `"skills": "skills/"` when the plugin contains skills.
Add `"mcpServers": "./.mcp.json"` when the plugin contains an MCP server.
Add `"author": { "name": "<full name>", "email": "<intel-email>" }` when the primary maintainer wants attribution (optional).
