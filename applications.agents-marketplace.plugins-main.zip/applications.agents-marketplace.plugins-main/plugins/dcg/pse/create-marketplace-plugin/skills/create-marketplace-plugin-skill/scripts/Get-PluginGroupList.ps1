<#
.SYNOPSIS
  List child group directories under plugins/<org>/ via the GitHub Contents API.

.OUTPUT
  JSON array of group names sorted alphabetically.
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory)] [string] $Org,
    [Parameter(Mandatory)] [string] $DefaultBranch
)

$ErrorActionPreference = 'Stop'

. (Join-Path (Split-Path -Parent $PSCommandPath) 'Set-IntelProxyEnv.ps1')

$raw = gh api "repos/intel-innersource/applications.agents-marketplace.plugins/contents/plugins/$Org`?ref=$DefaultBranch"
$groups = ($raw | ConvertFrom-Json) |
          Where-Object { $_.type -eq 'dir' } |
          ForEach-Object { $_.name } |
          Sort-Object

,$groups | ConvertTo-Json -Compress
