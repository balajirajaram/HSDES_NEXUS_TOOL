<#
.SYNOPSIS
  List top-level org directories under plugins/ via the GitHub Contents API.

.OUTPUT
  JSON array of org names sorted alphabetically.
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory)] [string] $DefaultBranch
)

$ErrorActionPreference = 'Stop'

. (Join-Path (Split-Path -Parent $PSCommandPath) 'Set-IntelProxyEnv.ps1')

$raw = gh api "repos/intel-innersource/applications.agents-marketplace.plugins/contents/plugins?ref=$DefaultBranch"
$orgs = ($raw | ConvertFrom-Json) |
        Where-Object { $_.type -eq 'dir' } |
        ForEach-Object { $_.name } |
        Sort-Object

,$orgs | ConvertTo-Json -Compress
