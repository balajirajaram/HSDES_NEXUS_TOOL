<#
.SYNOPSIS
    Build the owners list for a new plugin: primary owner (from gh email or
    explicit input) plus optional additional comma-separated Intel emails.

.OUTPUT
  JSON: { "ok": <bool>, "owners": [<email>, ...], "violations": [<string>, ...] }
#>
[CmdletBinding()]
param(
    [string] $GhEmail,
    [string] $PrimaryOwner,
    [string] $Additional = ''
)

$ErrorActionPreference = 'Stop'

function Test-IntelEmail([string] $e) {
    return ($e -match '^[a-z0-9._%+-]+@intel\.com$')
}

$self = $null
$violations = @()

if ($PrimaryOwner) {
    $candidate = $PrimaryOwner.Trim().ToLowerInvariant()
    if (Test-IntelEmail $candidate) {
        $self = $candidate
    } else {
        $violations += "invalid Intel email for primary owner: $candidate"
    }
} elseif ($GhEmail -and (Test-IntelEmail $GhEmail.ToLowerInvariant())) {
    $self = $GhEmail.ToLowerInvariant()
} else {
    $violations += 'missing primary Intel owner email: active GitHub email is unavailable/non-Intel; provide PrimaryOwner explicitly'
}

$collected = @()
if ($self) { $collected += $self }
if (-not [string]::IsNullOrWhiteSpace($Additional)) {
    $collected += ($Additional -split ',' |
        ForEach-Object { $_.Trim().ToLowerInvariant() } |
        Where-Object { $_ })
}

$owners     = $collected | Select-Object -Unique
foreach ($o in $owners) {
    if (-not (Test-IntelEmail $o)) { $violations += "invalid Intel email: $o" }
}

# Require at least 2 unique owners
if (-not $owners -or $owners.Count -lt 2) { $violations += 'at least two unique Intel owners required (yourself plus at least one reviewer)' }

@{
    ok         = ($violations.Count -eq 0)
    owners     = @($owners)
    violations = $violations
} | ConvertTo-Json -Compress
