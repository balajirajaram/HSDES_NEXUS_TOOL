<#
.SYNOPSIS
  Validate + load plugin asset files from a user-supplied source path.
  Supports both single-file and folder-of-files shapes for each asset kind.

.PARAMETER Kind
  skills  | prompts | agents | mcp

.PARAMETER Path
  - skills : folder. Either contains SKILL.md itself (single-skill shape) OR
             contains subfolders each with SKILL.md (parent-of-skills shape).
  - prompts: single *.prompt.md file OR a folder containing *.prompt.md files.
  - agents : single *.md file OR a folder containing *.md files.
  - mcp    : single .mcp.json file OR a folder containing .mcp.json
             (server.json auto-detected as sibling).

.PARAMETER ServerJsonPath
  (mcp only) Optional explicit path to server.json. Overrides auto-detection.

.OUTPUT
  JSON shape depends on Kind:
    skills  : { files:[{relPath;content}], names:[<folder>] }
    prompts : { files:[{relPath;content}], names:[<filename>] }
    agents  : { files:[{relPath;content}], names:[<filename>] }
    mcp     : { mcpJson:<str>, serverJson:<str>, serverJsonPath:<str|null> }
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory)] [ValidateSet('skills','prompts','agents','mcp')] [string] $Kind,
    [Parameter(Mandatory)] [string] $Path,
    [string] $ServerJsonPath
)

$ErrorActionPreference = 'Stop'

if (-not (Test-Path -LiteralPath $Path)) {
    throw "Path not found: $Path"
}
$item   = Get-Item -LiteralPath $Path
$isLeaf = -not $item.PSIsContainer

function Read-Text([string] $p) { [System.IO.File]::ReadAllText($p) }

switch ($Kind) {

    'skills' {
        if ($isLeaf) { throw "skills source must be a folder, got file: $Path" }

        $roots = if (Test-Path (Join-Path $item.FullName 'SKILL.md')) {
            @($item)
        } else {
            $kids = Get-ChildItem -Path $item.FullName -Directory -ErrorAction Stop |
                Where-Object { Test-Path (Join-Path $_.FullName 'SKILL.md') }
            if (-not $kids) {
                throw "No SKILL.md found at '$Path' and no <subfolder>/SKILL.md found under it. Point at a single skill folder OR a folder whose immediate children are skill folders."
            }
            $kids
        }

        $files = @(); $names = @()
        foreach ($r in $roots) {
            $names += $r.Name
            foreach ($f in Get-ChildItem -Path $r.FullName -Recurse -File) {
                $rel = "skills/$($r.Name)/" + ($f.FullName.Substring($r.FullName.Length + 1) -replace '\\','/')
                $files += @{ relPath = $rel; content = (Read-Text $f.FullName) }
            }
        }
        @{ files = $files; names = $names } | ConvertTo-Json -Depth 5 -Compress
    }

    'prompts' {
        $files = @(); $names = @()
        if ($isLeaf) {
            if ($item.Name -notlike '*.prompt.md') {
                throw "File must end with '.prompt.md': $($item.FullName)"
            }
            $files += @{ relPath = "prompts/$($item.Name)"; content = (Read-Text $item.FullName) }
            $names += $item.Name
        } else {
            $hits = Get-ChildItem -Path $item.FullName -Filter '*.prompt.md' -File -ErrorAction Stop
            if (-not $hits) { throw "No *.prompt.md files found under $Path." }
            foreach ($f in $hits) {
                $files += @{ relPath = "prompts/$($f.Name)"; content = (Read-Text $f.FullName) }
                $names += $f.Name
            }
        }
        @{ files = $files; names = $names } | ConvertTo-Json -Depth 5 -Compress
    }

    'agents' {
        $files = @(); $names = @()
        if ($isLeaf) {
            if ($item.Extension -ne '.md') {
                throw "File must be a *.md agent definition: $($item.FullName)"
            }
            $files += @{ relPath = "agents/$($item.Name)"; content = (Read-Text $item.FullName) }
            $names += $item.Name
        } else {
            $hits = Get-ChildItem -Path $item.FullName -Filter '*.md' -File -ErrorAction Stop
            if (-not $hits) { throw "No *.md files found under $Path." }
            foreach ($f in $hits) {
                $files += @{ relPath = "agents/$($f.Name)"; content = (Read-Text $f.FullName) }
                $names += $f.Name
            }
        }
        @{ files = $files; names = $names } | ConvertTo-Json -Depth 5 -Compress
    }

    'mcp' {
        if (-not $isLeaf) {
            $mcpFile = Join-Path $item.FullName '.mcp.json'
            if (-not (Test-Path -LiteralPath $mcpFile)) {
                throw "No .mcp.json found in folder: $($item.FullName)"
            }
            $mcpJson = Read-Text $mcpFile
            if (-not $ServerJsonPath) {
                $auto = Join-Path $item.FullName 'server.json'
                if (Test-Path -LiteralPath $auto) { $ServerJsonPath = $auto }
            }
        } else {
            $mcpJson = Read-Text $item.FullName
            if (-not $ServerJsonPath) {
                $auto = Join-Path $item.DirectoryName 'server.json'
                if (Test-Path -LiteralPath $auto) { $ServerJsonPath = $auto }
            }
        }

        $serverJson = ''
        if ($ServerJsonPath) {
            if (-not (Test-Path -LiteralPath $ServerJsonPath)) {
                throw "$ServerJsonPath not found."
            }
            $serverJson = Read-Text $ServerJsonPath
        }

        @{
            mcpJson        = $mcpJson
            serverJson     = $serverJson
            serverJsonPath = $ServerJsonPath
        } | ConvertTo-Json -Depth 3 -Compress
    }
}
