<#
.SYNOPSIS
  Run the per-owner AGS membership-request prompt loop. Opens the AGS UI,
  copies the entitlement name to the clipboard, and asks the user to confirm
  submission for each owner.

.OUTPUT
  JSON: { "aborted": <bool>, "results": [ { "owner": <email>, "status": <string> }, ... ] }

  status ∈ submitted | skipped | aborted
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory)] [string[]] $Owners,
    [string] $AgsName  = 'AGENTS-MARKETPLACE-PLUGINS-OWNERS',
    [string] $AgsUiUrl = $(if ($env:AGS_UI_URL) { $env:AGS_UI_URL } else {
        "https://ags.intel.com/identityiq/accessRequest/accessRequest.jsf#/accessRequest/manageAccess/add?quickLink=Request%20Access&filterKeyword=$([uri]::EscapeDataString($AgsName))"
    })
)

$ErrorActionPreference = 'Stop'

function Open-Url([string] $Url) {
    try {
        if ($IsWindows -or $PSVersionTable.PSEdition -eq 'Desktop') {
            Start-Process $Url -ErrorAction Stop
        }
        elseif ($IsMacOS) {
            & open $Url
        }
        elseif ($IsLinux) {
            & xdg-open $Url 2>$null
        }
    }
    catch { }
}

function Set-ClipboardCompat([string] $Text) {
    try {
        if (Get-Command Set-Clipboard -ErrorAction SilentlyContinue) {
            Set-Clipboard -Value $Text -ErrorAction Stop
            return $true
        }
        if ($IsMacOS) {
            $Text | & pbcopy
            return $true
        }
        if ($IsLinux) {
            if (Get-Command xclip -ErrorAction SilentlyContinue) {
                $Text | & xclip -selection clipboard
                return $true
            }
            if (Get-Command wl-copy -ErrorAction SilentlyContinue) {
                $Text | & wl-copy
                return $true
            }
        }
    }
    catch { }

    return $false
}

$clipboardReady = Set-ClipboardCompat $AgsName
if (-not $clipboardReady) {
    Write-Host ("Clipboard unavailable. Entitlement: {0}" -f $AgsName) -ForegroundColor Yellow
}

Open-Url $AgsUiUrl

Write-Host ""
Write-Host "===== Manual AGS membership requests =====" -ForegroundColor Cyan
Write-Host ("AGS entitlement : {0}" -f $AgsName) -ForegroundColor Yellow
Write-Host ("AGS UI          : {0}" -f $AgsUiUrl)
if ($clipboardReady) {
    Write-Host "(entitlement name is on your clipboard - paste it into the AGS 'Add Access' search box)"
}
Write-Host ""
Write-Host "For each owner: paste the entitlement in AGS, set 'Requesting For' to that owner, submit, then press [d] here."
Write-Host ""

$results = @()
$aborted = $false
$i = 0
foreach ($owner in $Owners) {
    $i++
    $status = $null
    while (-not $status) {
        Write-Host ("[{0}/{1}] Owner: " -f $i, $Owners.Count) -ForegroundColor Cyan -NoNewline
        Write-Host $owner -ForegroundColor Yellow
        Write-Host "  [d] done   [s] skip   [o] open AGS again   [c] copy entitlement again   [q] quit"
        switch ((Read-Host '>').Trim().ToLowerInvariant()) {
            'd' { $status = 'submitted' }
            's' { $status = 'skipped' }
            'o' { Open-Url $AgsUiUrl }
            'c' {
                if (-not (Set-ClipboardCompat $AgsName)) {
                    Write-Host ("Clipboard unavailable. Entitlement: {0}" -f $AgsName) -ForegroundColor Yellow
                }
            }
            'q' { $aborted = $true; $status = 'aborted' }
            default { Write-Host "  -> answer d / s / o / c / q" -ForegroundColor Yellow }
        }
    }
    $results += [pscustomobject]@{ owner = $owner; status = $status }
    if ($aborted) { break }
}

@{
    aborted = $aborted
    results = $results
} | ConvertTo-Json -Depth 4 -Compress
