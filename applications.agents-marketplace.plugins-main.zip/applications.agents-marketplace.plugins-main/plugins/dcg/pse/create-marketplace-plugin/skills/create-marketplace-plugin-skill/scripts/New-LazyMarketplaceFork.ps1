<#
.SYNOPSIS
  Fork intel-innersource/applications.agents-marketplace.plugins (idempotent)
  and create a metadata-only sparse clone at $WorkDir\agents-marketplace-plugins.
  Wires upstream remote and initializes cone-mode sparse-checkout with the
  '.github' folder so CODEOWNERS / workflows are accessible; plugin folders
  are added on demand by Write-PluginFiles.ps1.

.OUTPUT
  JSON: { "mkt": "<absolute path to clone>", "defaultBranch": "<branch>" }
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory)] [string] $GhLogin,
    [Parameter(Mandatory)] [string] $WorkDir,
    [Parameter(Mandatory)] [string] $DefaultBranch
)

$ErrorActionPreference = 'Stop'

. (Join-Path (Split-Path -Parent $PSCommandPath) 'Set-IntelProxyEnv.ps1')

$repo = 'applications.agents-marketplace.plugins'

New-Item -ItemType Directory -Force -Path $WorkDir | Out-Null
Set-Location $WorkDir

# Idempotent fork.
gh repo fork "intel-innersource/$repo" --clone=false --remote=false | Out-Null

$mkt = Join-Path $WorkDir $repo

if (-not (Test-Path (Join-Path $mkt '.git'))) {
    git clone --filter=blob:none --no-checkout --depth=1 `
        "https://github.com/$GhLogin/$repo.git" $mkt | Out-Null
}

Set-Location $mkt

# Wire upstream (idempotent).
$existingRemotes = git remote
if ($existingRemotes -notcontains 'upstream') {
    git remote add upstream "https://github.com/intel-innersource/$repo.git" | Out-Null
}

git sparse-checkout init --cone | Out-Null
# Include .github so CODEOWNERS is available; plugin subtrees are added by
# Write-PluginFiles.ps1 once the target org/group is known.
git sparse-checkout set '.github' | Out-Null
git checkout $DefaultBranch --quiet

@{ mkt = $mkt; defaultBranch = $DefaultBranch } | ConvertTo-Json -Compress
