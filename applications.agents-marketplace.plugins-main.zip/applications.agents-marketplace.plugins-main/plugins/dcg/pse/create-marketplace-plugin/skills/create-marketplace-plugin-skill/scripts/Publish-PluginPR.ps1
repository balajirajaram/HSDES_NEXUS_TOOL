<#
.SYNOPSIS
  Push the user branch to the fork and open a PR against
  intel-innersource/applications.agents-marketplace.plugins:<DefaultBranch>.

.OUTPUT
  JSON: {
    pushed:      <bool>,
    prUrl:       "<url or empty>",
    prCreated:   <bool>,
    fallbackUrl: "<compare url to use if prCreated=false>"
  }
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory)] [string] $MarketplacePath,
    [Parameter(Mandatory)] [string] $GhLogin,
    [Parameter(Mandatory)] [string] $Branch,
    [Parameter(Mandatory)] [string] $DefaultBranch,
    [Parameter(Mandatory)] [string] $Title,
    [Parameter(Mandatory)] [string] $Body
)

$ErrorActionPreference = 'Continue'

. (Join-Path (Split-Path -Parent $PSCommandPath) 'Set-IntelProxyEnv.ps1')

$repo = 'applications.agents-marketplace.plugins'

Set-Location $MarketplacePath

git push -u origin $Branch
$pushed = ($LASTEXITCODE -eq 0)

$prUrl       = ''
$prCreated   = $false
$fallbackUrl = "https://github.com/intel-innersource/$repo/compare/$DefaultBranch...$($GhLogin):$Branch`?expand=1"

if ($pushed) {
    $head  = "$GhLogin`:$Branch"
    # Use --body-file via a temp file to avoid quoting hell on Windows.
    $tmp   = [System.IO.Path]::GetTempFileName()
    Set-Content -Path $tmp -Value $Body -Encoding utf8

    $prUrl = gh pr create `
        --repo "intel-innersource/$repo" `
        --base $DefaultBranch `
        --head $head `
        --title $Title `
        --body-file $tmp 2>$null
    $prCreated = ($LASTEXITCODE -eq 0 -and $prUrl)

    Remove-Item -Path $tmp -ErrorAction SilentlyContinue
}

if (-not $prUrl) { $prUrl = '' }

@{
    pushed      = $pushed
    prUrl       = "$prUrl".Trim()
    prCreated   = $prCreated
    fallbackUrl = $fallbackUrl
} | ConvertTo-Json -Compress
