<#
.SYNOPSIS
  Render plugin.json + README.md from the user's collected state. Component
  files (skills, prompts, agents, .mcp.json, server.json) are NOT generated
  here — the caller imports them verbatim in Phase C5 and passes them in.
  This script just echoes them back so Write-PluginFiles.ps1 can write a single
  consolidated file list.

.PARAMETER StateJson
  Compact JSON with fields described in SKILL.md Phase D2.

.OUTPUT
  JSON: {
    pluginJson, readmeMd,
    mcpJson, serverJson,         # echoed from state (verbatim user files)
    skillFiles, promptFiles, agentFiles   # echoed from state
  }
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory)] [string] $StateJson
)

$ErrorActionPreference = 'Stop'

$state = $StateJson | ConvertFrom-Json
$here  = Split-Path -Parent $PSCommandPath
$tmpl  = Join-Path (Split-Path $here -Parent) 'templates'

function Read-Tmpl([string]$name) { Get-Content -Raw (Join-Path $tmpl $name) }

function Replace-Tokens([string]$text, [hashtable]$map) {
    foreach ($k in $map.Keys) {
        $text = $text.Replace("{{$k}}", [string]$map[$k])
    }
    $text
}

# --- plugin.json --------------------------------------------------------------

$keywordsJson = ($state.keywords | ForEach-Object { '"' + $_ + '"' }) -join ', '
$skillsField  = if ($state.components -contains 'skills') { ',`n  "skills": "skills/"' } else { '' }
$mcpField     = if ($state.components -contains 'mcp')    { ',`n  "mcpServers": "./.mcp.json"' } else { '' }

# Conditional tags for IT marketplace exposure
$tagsList = @()
if ($state.PSObject.Properties.Name -contains 'exposeToITMarketplace' -and $state.exposeToITMarketplace) {
    $tagsList += '"intel_global"'
}
$tagsJson = $tagsList -join ', '

$pluginJson = Replace-Tokens (Read-Tmpl 'plugin.json.tmpl') @{
    NAME         = $state.pluginName
    DESCRIPTION  = ($state.description -replace '"','\"')
    LICENSE      = $state.license
    KEYWORDS     = $keywordsJson
    CATEGORY     = $state.category
    ORG          = $state.org
    GROUP        = $state.group
    SKILLS_FIELD = $skillsField
    MCP_FIELD    = $mcpField
    TAGS         = $tagsJson
}
# Convert literal backtick-n sequences back to real newlines (we used them above
# to keep the field-injection strings readable).
$pluginJson = $pluginJson -replace '`n',"`n"

# --- README.md ----------------------------------------------------------------

$ownersBullets = ($state.owners | ForEach-Object { "- $_" }) -join "`n"

# Derive skill names from imported skillFiles relPaths (skills/<name>/...).
$importedSkillNames = @()
if ($state.components -contains 'skills' -and $state.skillFiles) {
    $importedSkillNames = $state.skillFiles |
        ForEach-Object { ($_.relPath -split '/')[1] } |
        Select-Object -Unique
}

$skillsSection = ''
if ($importedSkillNames) {
    $sb = @('## Skills', '')
    $i = 0
    foreach ($n in $importedSkillNames) {
        $i++
        $sb += "### $i. $n"
        $sb += ''
        $sb += "**Location:** [``skills/$n/SKILL.md``](skills/$n/SKILL.md)"
        $sb += ''
    }
    $skillsSection = ($sb -join "`n")
}

$mcpSection = ''
if ($state.components -contains 'mcp') {
    $mcpSection = @"
## MCP Server

This plugin bundles an MCP server. Configuration lives in [``.mcp.json``](.mcp.json) and the server descriptor is in [``server.json``](server.json).
"@
}

$readmeMd = Replace-Tokens (Read-Tmpl 'README.md.tmpl') @{
    NAME            = $state.pluginName
    DESCRIPTION     = $state.description
    SKILLS_SECTION  = $skillsSection
    MCP_SECTION     = $mcpSection
    OWNERS_BULLETS  = $ownersBullets
}

# --- Component payloads (verbatim pass-through from state) --------------------
#
# C5 already loaded the actual file contents from the user's source folders;
# we just echo them back unchanged. No templates, no scaffolding.

$mcpJson     = if ($state.components -contains 'mcp')     { [string]$state.mcpJson     } else { '' }
$serverJson  = if ($state.components -contains 'mcp')     { [string]$state.serverJson  } else { '' }
$skillFiles  = if ($state.components -contains 'skills')  { @($state.skillFiles)  } else { @() }
$promptFiles = if ($state.components -contains 'prompts') { @($state.promptFiles) } else { @() }
$agentFiles  = if ($state.components -contains 'agents')  { @($state.agentFiles)  } else { @() }

# --- Emit ---------------------------------------------------------------------

@{
    pluginJson  = $pluginJson
    readmeMd    = $readmeMd
    mcpJson     = $mcpJson
    serverJson  = $serverJson
    skillFiles  = $skillFiles
    promptFiles = $promptFiles
    agentFiles  = $agentFiles
} | ConvertTo-Json -Depth 6 -Compress
