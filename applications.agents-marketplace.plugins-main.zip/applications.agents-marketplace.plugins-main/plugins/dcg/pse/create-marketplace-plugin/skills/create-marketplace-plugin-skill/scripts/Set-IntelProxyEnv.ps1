<#
.SYNOPSIS
  Ensure Intel proxy environment variables are set for the current process.

.DESCRIPTION
  This script is idempotent and can be dot-sourced from other helper scripts
  before running networked gh/git commands.
#>
# Cross-platform: works under pwsh on Windows / Linux / macOS.
[CmdletBinding()]
param()

$ErrorActionPreference = 'Stop'

$env:HTTP_PROXY  = 'http://proxy-chain.intel.com:911/'
$env:HTTPS_PROXY = 'http://proxy-chain.intel.com:911/'
$env:NO_PROXY    = 'localhost,127.0.0.1,.intel.com'
