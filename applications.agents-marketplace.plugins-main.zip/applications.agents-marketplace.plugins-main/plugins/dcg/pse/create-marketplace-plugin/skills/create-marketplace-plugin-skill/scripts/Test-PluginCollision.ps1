<#
.SYNOPSIS
  Check whether plugins/<Org>/<Group>/<PluginName> already exists upstream via
  the GitHub Contents API.

.OUTPUT
  JSON: { "exists": <bool>, "path": "<full path>" }
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory)] [string] $Org,
    [Parameter(Mandatory)] [string] $Group,
    [Parameter(Mandatory)] [string] $PluginName,
    [Parameter(Mandatory)] [string] $DefaultBranch
)

$ErrorActionPreference = 'Continue'

. (Join-Path (Split-Path -Parent $PSCommandPath) 'Set-IntelProxyEnv.ps1')

$path = "plugins/$Org/$Group/$PluginName"
$exists = $false

# Read parent directory listing and match folder name.
$parent = "plugins/$Org/$Group"
$query = "repos/intel-innersource/applications.agents-marketplace.plugins/contents/${parent}?ref=$DefaultBranch"
$prevErrorActionPreference = $ErrorActionPreference
$ErrorActionPreference = 'SilentlyContinue'
$raw = & gh api $query 2>$null
$ghExitCode = $LASTEXITCODE
$ErrorActionPreference = $prevErrorActionPreference

if ($ghExitCode -eq 0 -and $raw) {
  try {
    $items = $raw | ConvertFrom-Json
    if ($items -is [System.Array]) {
      foreach ($item in $items) {
        if ($item.type -eq 'dir' -and $item.name -eq $PluginName) {
          $exists = $true
          break
        }
      }
    }
  } catch {
    $exists = $false
  }
}
$global:LASTEXITCODE = 0

@{
    exists = $exists
    path   = $path
} | ConvertTo-Json -Compress
