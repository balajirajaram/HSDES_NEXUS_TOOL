<#
.SYNOPSIS
  Validate a plugin / skill / group folder name against deterministic rules.

.OUTPUT
  JSON: { "ok": <bool>, "violations": [<string>, ...] }
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory)] [string] $Name
)

$ErrorActionPreference = 'Stop'

$bad = New-Object System.Collections.Generic.List[string]

if ($Name.Length -lt 3 -or $Name.Length -gt 60)    { $bad.Add('length must be 3-60 characters') }
if ($Name -cnotmatch '^[a-z0-9-]+$')               { $bad.Add('chars: only a-z 0-9 hyphen (no uppercase, underscore, dot, space)') }
if ($Name -match '^-' -or $Name -match '-$')       { $bad.Add('no leading/trailing hyphen') }
if ($Name -match '--')                              { $bad.Add('no consecutive hyphens') }

@{
    ok         = ($bad.Count -eq 0)
    violations = $bad.ToArray()
} | ConvertTo-Json -Compress
