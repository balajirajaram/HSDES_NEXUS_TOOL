<#
.SYNOPSIS
  Sync the marketplace clone with upstream, ensure the target subtree is in the
  sparse-checkout cone, create the user branch, write all plugin files, append
  the CODEOWNERS line, stage and commit.

  This script NEVER touches .github/plugin/marketplace.json (upstream regenerates it).

.OUTPUT
  JSON: { "branch", "committed": <bool>, "filesWritten": [<path>, ...] }
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory)] [string] $MarketplacePath,
    [Parameter(Mandatory)] [string] $DefaultBranch,
    [Parameter(Mandatory)] [string] $Branch,
    [Parameter(Mandatory)] [string] $Org,
    [Parameter(Mandatory)] [string] $Group,
    [Parameter(Mandatory)] [string] $PluginName,
    [Parameter(Mandatory)] [string] $Owners,           # space-separated emails
    [Parameter(Mandatory)] [string] $PluginJson,
    [Parameter(Mandatory)] [string] $ReadmeMd,
    [Parameter()]          [string] $McpJson,
    [Parameter()]          [string] $ServerJson,
    [Parameter()]          [string] $SkillFilesJson,
    [Parameter()]          [string] $PromptFilesJson,
    [Parameter()]          [string] $AgentFilesJson,
    [Parameter(Mandatory)] [string] $CommitTitle,
    [Parameter(Mandatory)] [string] $CommitBody
)

$ErrorActionPreference = 'Stop'

Set-Location $MarketplacePath

function Invoke-GitQuiet {
    param(
        [Parameter(Mandatory)] [string[]] $Arguments,
        [switch] $AllowFailure
    )

    & git @Arguments 2>$null | Out-Null
    $exitCode = $LASTEXITCODE
    if (-not $AllowFailure -and $exitCode -ne 0) {
        throw "git $($Arguments -join ' ') failed with exit code $exitCode"
    }

    return $exitCode
}

function Get-FileEncoding {
    param([Parameter(Mandatory)] [string] $Path)

    if (-not (Test-Path $Path)) {
        return [System.Text.UTF8Encoding]::new($false)
    }

    $bytes = [System.IO.File]::ReadAllBytes($Path)
    if ($bytes.Length -ge 3 -and $bytes[0] -eq 0xEF -and $bytes[1] -eq 0xBB -and $bytes[2] -eq 0xBF) {
        return [System.Text.UTF8Encoding]::new($true)
    }

    if ($bytes.Length -ge 2 -and $bytes[0] -eq 0xFF -and $bytes[1] -eq 0xFE) {
        return [System.Text.UnicodeEncoding]::new($false, $true)
    }

    if ($bytes.Length -ge 2 -and $bytes[0] -eq 0xFE -and $bytes[1] -eq 0xFF) {
        return [System.Text.UnicodeEncoding]::new($true, $true)
    }

    return [System.Text.UTF8Encoding]::new($false)
}

function Get-LineEnding {
    param([string] $Text)

    if ($Text -match "`r`n") { return "`r`n" }
    if ($Text -match "`n") { return "`n" }
    return [System.Environment]::NewLine
}

# 1. Sync with upstream on the default branch.
Invoke-GitQuiet -Arguments @('switch', $DefaultBranch, '--quiet')
Invoke-GitQuiet -Arguments @('fetch', 'upstream', '--quiet')
Invoke-GitQuiet -Arguments @('merge', '--ff-only', '--quiet', "upstream/$DefaultBranch")

# 2. Ensure the target subtree is in the sparse cone (idempotent).
$sparseCheckoutEnabled = (& git config --bool --get core.sparseCheckout 2>$null)
if ($LASTEXITCODE -eq 0 -and $sparseCheckoutEnabled -eq 'true') {
    Invoke-GitQuiet -Arguments @('sparse-checkout', 'add', '.github', "plugins/$Org/$Group")
}

# 3. Create / switch to the user branch.
$switchExitCode = Invoke-GitQuiet -Arguments @('switch', '-c', $Branch, '--quiet') -AllowFailure
if ($switchExitCode -ne 0) {
    Invoke-GitQuiet -Arguments @('switch', $Branch, '--quiet')
}

# 4. Write plugin files.
$pluginDir = Join-Path $MarketplacePath (Join-Path 'plugins' (Join-Path $Org (Join-Path $Group $PluginName)))
New-Item -ItemType Directory -Force -Path $pluginDir | Out-Null

$written = New-Object System.Collections.Generic.List[string]

function Write-Utf8NoBom([string]$path, [string]$content) {
    $dir = Split-Path -Parent $path
    if ($dir -and -not (Test-Path $dir)) { New-Item -ItemType Directory -Force -Path $dir | Out-Null }
    # Use Set-Content with utf8 (PS 5.1: no BOM via UTF8Encoding($false) workaround)
    $bytes = [System.Text.UTF8Encoding]::new($false).GetBytes($content)
    [System.IO.File]::WriteAllBytes($path, $bytes)
    $written.Add($path)
}

Write-Utf8NoBom (Join-Path $pluginDir 'plugin.json') $PluginJson
Write-Utf8NoBom (Join-Path $pluginDir 'README.md')   $ReadmeMd

if ($McpJson)    { Write-Utf8NoBom (Join-Path $pluginDir '.mcp.json')   $McpJson }
if ($ServerJson) { Write-Utf8NoBom (Join-Path $pluginDir 'server.json') $ServerJson }

function Write-FileList([string]$json) {
    if (-not $json) { return }
    $items = $json | ConvertFrom-Json
    if (-not $items) { return }
    foreach ($it in $items) {
        $target = $pluginDir
        foreach ($segment in ($it.relPath -split '/')) {
            $target = Join-Path $target $segment
        }
        Write-Utf8NoBom $target $it.content
    }
}

Write-FileList $SkillFilesJson
Write-FileList $PromptFilesJson
Write-FileList $AgentFilesJson

# 5. Section-aware CODEOWNERS insert (idempotent).
#    - If entries for "/plugins/$Org/$Group/" already exist, insert after the last one.
#    - Else if a section header "# Plugin owners (<ORG> / <GROUP>...)" exists, insert under it.
#    - Else append a new section before the trailing "# Marketplace registry" block (or at EOF).
$codeownersPath = Join-Path $MarketplacePath (Join-Path '.github' 'CODEOWNERS')
$pathToken      = "/plugins/$Org/$Group/$PluginName/"
$groupPrefix    = "/plugins/$Org/$Group/"
$encoding       = Get-FileEncoding -Path $codeownersPath
$existing       = if (Test-Path $codeownersPath) { [System.IO.File]::ReadAllText($codeownersPath, $encoding) } else { "" }

if ($existing -notmatch [regex]::Escape($pathToken)) {
    $newline = Get-LineEnding -Text $existing
    $line    = ('{0,-47} {1}' -f $pathToken, $Owners)              # column-48 owners (upstream convention)
    $lines   = @($existing -split "`r?`n")
    if ($lines.Count -and -not $lines[-1]) { $lines = $lines[0..($lines.Count - 2)] }

    $hdrRx = "^#\s*Plugin owners\s*\(\s*$([regex]::Escape($Org.ToUpper()))\s*/\s*$([regex]::Escape($Group.ToUpper()))\b"
    $at = -1
    # (a) after last existing entry for this org/group
    for ($i = $lines.Count - 1; $i -ge 0 -and $at -lt 0; $i--) {
        if ($lines[$i].StartsWith($groupPrefix)) { $at = $i + 1 }
    }
    # (b) after the matching section header's contiguous /plugins/ block
    if ($at -lt 0) {
        for ($i = 0; $i -lt $lines.Count -and $at -lt 0; $i++) {
            if ($lines[$i] -imatch $hdrRx) {
                $at = $i + 1
                while ($at -lt $lines.Count -and $lines[$at].StartsWith('/plugins/')) { $at++ }
            }
        }
    }
    # (c) new section before "# Marketplace registry" (or at EOF)
    if ($at -lt 0) {
        $reg = ($lines | Select-String -Pattern '^#\s*Marketplace registry' | Select-Object -First 1).LineNumber
        $at  = if ($reg) { $reg - 1 } else { $lines.Count }
        $block = @('', "# Plugin owners ($($Org.ToUpper()) / $($Group.ToUpper()))", $line)
        if ($reg) { $block += '' }
        $lines = @($lines[0..([Math]::Max(-1,$at-1))] | Where-Object { $_ -ne $null }) + $block + @($lines[$at..($lines.Count-1)] | Where-Object { $_ -ne $null })
    }
    else {
        $lines = @($lines[0..($at-1)]) + @($line) + @($lines[$at..($lines.Count-1)])
    }

    [System.IO.File]::WriteAllText($codeownersPath, (($lines -join $newline) + $newline), $encoding)
    $written.Add($codeownersPath)
}

# 6. Stage + commit. Explicitly DO NOT add marketplace.json.
Invoke-GitQuiet -Arguments @('add', '.github/CODEOWNERS', "plugins/$Org/$Group/$PluginName")
& git commit -m $CommitTitle -m $CommitBody 2>$null | Out-Null
$committed = ($LASTEXITCODE -eq 0)

@{
    branch       = $Branch
    committed    = $committed
    filesWritten = $written.ToArray()
} | ConvertTo-Json -Compress
