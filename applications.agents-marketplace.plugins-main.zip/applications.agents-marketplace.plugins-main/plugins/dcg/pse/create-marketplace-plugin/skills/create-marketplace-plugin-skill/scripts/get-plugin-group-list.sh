#!/usr/bin/env bash
# List child group directories under plugins/<org>/ via the GitHub Contents API.
# Output: JSON array of group names sorted alphabetically.
# Usage: get-plugin-group-list.sh --org <org> --default-branch <branch>

set -euo pipefail
IFS=$'\n\t'

ORG=""
DEFAULT_BRANCH=""
while [[ $# -gt 0 ]]; do
    case "$1" in
        --org) ORG="$2"; shift 2 ;;
        --default-branch) DEFAULT_BRANCH="$2"; shift 2 ;;
        -h|--help) sed -n '2,4p' "$0"; exit 0 ;;
        *) echo "Unknown arg: $1" >&2; exit 2 ;;
    esac
done

if [[ -z "$ORG" || -z "$DEFAULT_BRANCH" ]]; then
    echo "Missing required --org and/or --default-branch" >&2
    exit 2
fi

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=set-intel-proxy-env.sh
. "$SCRIPT_DIR/set-intel-proxy-env.sh"
# shellcheck source=_json.sh
. "$SCRIPT_DIR/_json.sh"

gh api "repos/intel-innersource/applications.agents-marketplace.plugins/contents/plugins/${ORG}?ref=${DEFAULT_BRANCH}" \
    --jq '.[] | select(.type=="dir") | .name' \
    | sort | json_lines_to_array
