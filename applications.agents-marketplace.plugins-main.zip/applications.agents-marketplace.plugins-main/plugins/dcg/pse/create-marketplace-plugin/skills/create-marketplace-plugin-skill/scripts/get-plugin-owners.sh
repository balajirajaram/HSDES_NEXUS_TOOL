#!/usr/bin/env bash
# Build the owners list for a new plugin: primary owner plus optional additional emails.
# Output: JSON {"ok":bool, "owners":[...], "violations":[...]}
# Usage: get-plugin-owners.sh [--gh-email <email>] [--primary-owner <email>] [--additional "a@intel.com,b@intel.com"]

set -euo pipefail
IFS=$'\n\t'

GH_EMAIL=""; PRIMARY_OWNER=""; ADDITIONAL=""
while [[ $# -gt 0 ]]; do
    case "$1" in
        --gh-email) GH_EMAIL="$2"; shift 2 ;;
        --primary-owner) PRIMARY_OWNER="$2"; shift 2 ;;
        --additional) ADDITIONAL="$2"; shift 2 ;;
        -h|--help) sed -n '2,4p' "$0"; exit 0 ;;
        *) echo "Unknown arg: $1" >&2; exit 2 ;;
    esac
done

EMAIL_RE='^[a-z0-9._%+-]+@intel\.com$'

# Lowercase helper (bash 4+ ${var,,})
tolower() { printf '%s' "${1,,}"; }

self=""
if [[ -n "$PRIMARY_OWNER" ]]; then
    candidate="$(tolower "$PRIMARY_OWNER")"
    if [[ "$candidate" =~ $EMAIL_RE ]]; then
        self="$candidate"
    fi
fi
if [[ -z "$self" && -n "$GH_EMAIL" ]]; then
    candidate="$(tolower "$GH_EMAIL")"
    if [[ "$candidate" =~ $EMAIL_RE ]]; then
        self="$candidate"
    fi
fi

declare -a violations=()
if [[ -z "$self" ]]; then
    violations+=("missing primary Intel owner email: active GitHub email is unavailable/non-Intel; provide --primary-owner explicitly")
fi

# Build deduped, order-preserving list
declare -a owners=()
if [[ -n "$self" ]]; then
    owners+=("$self")
fi
if [[ -n "$ADDITIONAL" ]]; then
    IFS=',' read -ra extras <<< "$ADDITIONAL"
    for raw in "${extras[@]}"; do
        # trim whitespace
        trimmed="${raw#"${raw%%[![:space:]]*}"}"
        trimmed="${trimmed%"${trimmed##*[![:space:]]}"}"
        [[ -z "$trimmed" ]] && continue
        low="$(tolower "$trimmed")"
        # dedupe
        seen=0
        for existing in "${owners[@]}"; do
            if [[ "$existing" == "$low" ]]; then seen=1; break; fi
        done
        (( seen )) || owners+=("$low")
    done
fi

# Validate
for o in "${owners[@]}"; do
    if [[ ! "$o" =~ $EMAIL_RE ]]; then
        violations+=("invalid Intel email: $o")
    fi
done
if (( ${#owners[@]} < 2 )); then
    violations+=("at least two unique Intel owners required (yourself plus at least one reviewer)")
fi

ok=true
(( ${#violations[@]} > 0 )) && ok=false

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=_json.sh
. "$SCRIPT_DIR/_json.sh"

owners_json="$(printf '%s\n' "${owners[@]}" | json_lines_to_array)"
viol_json="$(printf '%s\n' "${violations[@]:-}" | json_lines_to_array)"
json_obj :ok "$ok" :owners "$owners_json" :violations "$viol_json"
