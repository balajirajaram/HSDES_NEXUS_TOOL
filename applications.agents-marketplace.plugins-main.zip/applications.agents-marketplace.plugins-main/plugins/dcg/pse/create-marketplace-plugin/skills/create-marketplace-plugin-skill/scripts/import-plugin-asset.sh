#!/usr/bin/env bash
# Validate + load plugin asset files from a user-supplied source path.
# Supports both single-file and folder-of-files shapes for each asset kind.
#
# Usage:
#   import-plugin-asset.sh --kind skills|prompts|agents|mcp --path <path> [--server-json-path <path>]
#
# Output JSON depends on --kind:
#   skills  : {files:[{relPath,content}], names:[<folder>]}
#   prompts : {files:[{relPath,content}], names:[<filename>]}
#   agents  : {files:[{relPath,content}], names:[<filename>]}
#   mcp     : {mcpJson, serverJson, serverJsonPath}

set -euo pipefail
IFS=$'\n\t'

KIND=""; SRC=""; SERVER_JSON_PATH=""
while [[ $# -gt 0 ]]; do
    case "$1" in
        --kind) KIND="$2"; shift 2 ;;
        --path) SRC="$2"; shift 2 ;;
        --server-json-path) SERVER_JSON_PATH="$2"; shift 2 ;;
        -h|--help) sed -n '2,10p' "$0"; exit 0 ;;
        *) echo "Unknown arg: $1" >&2; exit 2 ;;
    esac
done

if [[ -z "$KIND" || -z "$SRC" ]]; then
    echo "Missing required --kind and/or --path" >&2
    exit 2
fi
case "$KIND" in
    skills|prompts|agents|mcp) ;;
    *) echo "Invalid --kind: $KIND (must be skills|prompts|agents|mcp)" >&2; exit 2 ;;
esac
if [[ ! -e "$SRC" ]]; then
    echo "Path not found: $SRC" >&2; exit 1
fi

# shellcheck source=_json.sh
. "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/_json.sh"

# Walk files in a directory; emit one JSON object per line:
#   {"relPath": "<prefix>/<name>/<rel>", "content": "<text>"}
emit_files_under_root() {
    local root="$1"      # e.g. /tmp/skills/my-skill
    local prefix="$2"    # e.g. "skills/my-skill"
    while IFS= read -r -d '' f; do
        local rel="${f#"$root/"}"
        local content_json; content_json="$(json_string_from_file "$f")"
        json_obj relPath "${prefix}/${rel}" :content "$content_json"
        printf '\n'
    done < <(find "$root" -type f -print0)
}

emit_one_file() {
    local file="$1" relPath="$2"
    local content_json; content_json="$(json_string_from_file "$file")"
    json_obj relPath "$relPath" :content "$content_json"
    printf '\n'
}

case "$KIND" in

    skills)
        if [[ ! -d "$SRC" ]]; then
            echo "skills source must be a folder, got file: $SRC" >&2; exit 1
        fi
        # Roots: either $SRC itself (has SKILL.md) or its immediate subdirs that have SKILL.md.
        declare -a roots=()
        if [[ -f "$SRC/SKILL.md" ]]; then
            roots+=("$SRC")
        else
            while IFS= read -r -d '' d; do
                [[ -f "$d/SKILL.md" ]] && roots+=("$d")
            done < <(find "$SRC" -mindepth 1 -maxdepth 1 -type d -print0)
            if (( ${#roots[@]} == 0 )); then
                echo "No SKILL.md found at '$SRC' and no <subfolder>/SKILL.md found under it. Point at a single skill folder OR a folder whose immediate children are skill folders." >&2
                exit 1
            fi
        fi

        # Collect into temp files so we can pass as JSON arrays.
        files_jsonl="$(mktemp)"
        names_jsonl="$(mktemp)"
        trap 'rm -f "$files_jsonl" "$names_jsonl"' EXIT

        for r in "${roots[@]}"; do
            name="$(basename "$r")"
            printf '%s\n' "$name" >> "$names_jsonl"
            emit_files_under_root "$r" "skills/$name" >> "$files_jsonl"
        done

        files_arr="$(json_jsonl_to_array < "$files_jsonl")"
        names_arr="$(json_lines_to_array < "$names_jsonl")"
        json_obj :files "$files_arr" :names "$names_arr"
        ;;

    prompts|agents)
        files_jsonl="$(mktemp)"
        names_jsonl="$(mktemp)"
        trap 'rm -f "$files_jsonl" "$names_jsonl"' EXIT

        if [[ "$KIND" == "prompts" ]]; then
            pattern='*.prompt.md'
            ext_label='*.prompt.md'
        else
            pattern='*.md'
            ext_label='*.md'
        fi

        if [[ -f "$SRC" ]]; then
            base="$(basename "$SRC")"
            case "$KIND" in
                prompts)
                    if [[ "$base" != *.prompt.md ]]; then
                        echo "File must end with '.prompt.md': $SRC" >&2; exit 1
                    fi ;;
                agents)
                    if [[ "$base" != *.md ]]; then
                        echo "File must be a *.md agent definition: $SRC" >&2; exit 1
                    fi ;;
            esac
            emit_one_file "$SRC" "${KIND}/${base}" >> "$files_jsonl"
            printf '%s\n' "$base" >> "$names_jsonl"
        else
            hit_count=0
            while IFS= read -r -d '' f; do
                base="$(basename "$f")"
                emit_one_file "$f" "${KIND}/${base}" >> "$files_jsonl"
                printf '%s\n' "$base" >> "$names_jsonl"
                hit_count=$((hit_count+1))
            done < <(find "$SRC" -maxdepth 1 -type f -name "$pattern" -print0)
            if (( hit_count == 0 )); then
                echo "No $ext_label files found under $SRC." >&2; exit 1
            fi
        fi

        files_arr="$(json_jsonl_to_array < "$files_jsonl")"
        names_arr="$(json_lines_to_array < "$names_jsonl")"
        json_obj :files "$files_arr" :names "$names_arr"
        ;;

    mcp)
        if [[ -d "$SRC" ]]; then
            mcp_file="$SRC/.mcp.json"
            if [[ ! -f "$mcp_file" ]]; then
                echo "No .mcp.json found in folder: $SRC" >&2; exit 1
            fi
            if [[ -z "$SERVER_JSON_PATH" && -f "$SRC/server.json" ]]; then
                SERVER_JSON_PATH="$SRC/server.json"
            fi
        else
            mcp_file="$SRC"
            if [[ -z "$SERVER_JSON_PATH" ]]; then
                src_dir="$(dirname "$SRC")"
                [[ -f "$src_dir/server.json" ]] && SERVER_JSON_PATH="$src_dir/server.json"
            fi
        fi

        mcp_json="$(cat "$mcp_file")"
        server_json=""
        if [[ -n "$SERVER_JSON_PATH" ]]; then
            if [[ ! -f "$SERVER_JSON_PATH" ]]; then
                echo "$SERVER_JSON_PATH not found." >&2; exit 1
            fi
            server_json="$(cat "$SERVER_JSON_PATH")"
        fi

        if [[ -n "$SERVER_JSON_PATH" ]]; then
            serverPathArg="$SERVER_JSON_PATH"
        else
            serverPathArg=""
        fi
        if [[ -z "$serverPathArg" ]]; then
            json_obj mcpJson "$mcp_json" serverJson "$server_json" :serverJsonPath ''
        else
            json_obj mcpJson "$mcp_json" serverJson "$server_json" serverJsonPath "$serverPathArg"
        fi
        ;;
esac
