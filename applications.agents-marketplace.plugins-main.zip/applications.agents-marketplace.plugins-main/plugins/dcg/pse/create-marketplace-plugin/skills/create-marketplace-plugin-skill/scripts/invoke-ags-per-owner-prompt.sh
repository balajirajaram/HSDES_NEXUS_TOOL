#!/usr/bin/env bash
# Run the per-owner AGS membership-request prompt loop. Opens the AGS UI and
# asks the user to confirm submission for each owner.
#
# Usage:
#   invoke-ags-per-owner-prompt.sh --owners "a@intel.com,b@intel.com" \
#                                  [--ags-name <name>] [--ags-ui-url <url>]
#
# Output: JSON {aborted, results:[{owner,status}]}
# status in submitted | skipped | aborted

set -uo pipefail
IFS=$'\n\t'

OWNERS_CSV=""
AGS_NAME="${AGS_NAME:-AGENTS-MARKETPLACE-PLUGINS-OWNERS}"
AGS_UI_URL="${AGS_UI_URL:-}"

while [[ $# -gt 0 ]]; do
    case "$1" in
        --owners) OWNERS_CSV="$2"; shift 2 ;;
        --ags-name) AGS_NAME="$2"; shift 2 ;;
        --ags-ui-url) AGS_UI_URL="$2"; shift 2 ;;
        -h|--help) sed -n '2,10p' "$0"; exit 0 ;;
        *) echo "Unknown arg: $1" >&2; exit 2 ;;
    esac
done

if [[ -z "$OWNERS_CSV" ]]; then
    echo "Missing required --owners (comma-separated emails)" >&2; exit 2
fi

if [[ -z "$AGS_UI_URL" ]]; then
    # URL-encode AGS_NAME (alphanumerics + - _ . ~ stay; here it's all uppercase + hyphen so trivial)
    encoded="${AGS_NAME// /%20}"
    AGS_UI_URL="https://ags.intel.com/identityiq/accessRequest/accessRequest.jsf#/accessRequest/manageAccess/add?quickLink=Request%20Access&filterKeyword=${encoded}"
fi

open_url() {
    local url="$1"
    case "$(uname -s)" in
        Darwin) open "$url" >/dev/null 2>&1 || true ;;
        Linux)  xdg-open "$url" >/dev/null 2>&1 || true ;;
        CYGWIN*|MINGW*|MSYS*) start "" "$url" >/dev/null 2>&1 || true ;;
        *) : ;;
    esac
}

# Parse owners CSV into array
IFS=',' read -ra OWNERS <<< "$OWNERS_CSV"
declare -a OWNERS_TRIMMED=()
for o in "${OWNERS[@]}"; do
    t="${o#"${o%%[![:space:]]*}"}"
    t="${t%"${t##*[![:space:]]}"}"
    [[ -n "$t" ]] && OWNERS_TRIMMED+=("$t")
done

open_url "$AGS_UI_URL"

printf '\n'
printf '===== Manual AGS membership requests =====\n'
printf 'AGS entitlement : %s\n' "$AGS_NAME"
printf 'AGS UI          : %s\n' "$AGS_UI_URL"
printf '\n'
printf "For each owner: paste the entitlement in AGS, set 'Requesting For' to that owner, submit, then press [d] here.\n\n"

results_jsonl="$(mktemp)"
trap 'rm -f "$results_jsonl"' EXIT

# shellcheck source=_json.sh
. "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/_json.sh"

aborted=false
i=0
total=${#OWNERS_TRIMMED[@]}
for owner in "${OWNERS_TRIMMED[@]}"; do
    i=$((i+1))
    status=""
    while [[ -z "$status" ]]; do
        printf '[%d/%d] Owner: %s\n' "$i" "$total" "$owner"
        printf '  [d] done   [s] skip   [o] open AGS again   [q] quit\n'
        printf '> '
        IFS= read -r ans || ans=""
        ans="$(printf '%s' "$ans" | tr '[:upper:]' '[:lower:]' | tr -d '[:space:]')"
        case "$ans" in
            d) status='submitted' ;;
            s) status='skipped' ;;
            o) open_url "$AGS_UI_URL" ;;
            q) aborted=true; status='aborted' ;;
            *) printf '  -> answer d / s / o / q\n' ;;
        esac
    done
    json_obj owner "$owner" status "$status" >> "$results_jsonl"
    printf '\n' >> "$results_jsonl"
    $aborted && break
done

results_arr="$(json_jsonl_to_array < "$results_jsonl")"
json_obj :aborted "$aborted" :results "$results_arr"
