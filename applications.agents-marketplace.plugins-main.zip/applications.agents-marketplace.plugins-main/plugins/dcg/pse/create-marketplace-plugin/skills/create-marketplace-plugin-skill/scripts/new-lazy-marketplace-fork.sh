#!/usr/bin/env bash
# Fork intel-innersource/applications.agents-marketplace.plugins (idempotent)
# and create a metadata-only sparse clone at $WorkDir/applications.agents-marketplace.plugins.
# Wires upstream remote and initializes cone-mode sparse-checkout with '.github'.
#
# Usage: new-lazy-marketplace-fork.sh --gh-login <login> --work-dir <dir> --default-branch <branch>
# Output: JSON {"mkt": "<abs path>", "defaultBranch": "<branch>"}

set -euo pipefail
IFS=$'\n\t'

GH_LOGIN=""; WORK_DIR=""; DEFAULT_BRANCH=""
while [[ $# -gt 0 ]]; do
    case "$1" in
        --gh-login) GH_LOGIN="$2"; shift 2 ;;
        --work-dir) WORK_DIR="$2"; shift 2 ;;
        --default-branch) DEFAULT_BRANCH="$2"; shift 2 ;;
        -h|--help) sed -n '2,7p' "$0"; exit 0 ;;
        *) echo "Unknown arg: $1" >&2; exit 2 ;;
    esac
done

if [[ -z "$GH_LOGIN" || -z "$WORK_DIR" || -z "$DEFAULT_BRANCH" ]]; then
    echo "Missing required arg(s)" >&2; exit 2
fi

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=set-intel-proxy-env.sh
. "$SCRIPT_DIR/set-intel-proxy-env.sh"

repo='applications.agents-marketplace.plugins'

mkdir -p "$WORK_DIR"
cd "$WORK_DIR"

# Idempotent fork.
gh repo fork "intel-innersource/$repo" --clone=false --remote=false >/dev/null 2>&1 || true

mkt="$WORK_DIR/$repo"

if [[ ! -d "$mkt/.git" ]]; then
    git clone --filter=blob:none --no-checkout --depth=1 \
        "https://github.com/$GH_LOGIN/$repo.git" "$mkt" >/dev/null
fi

cd "$mkt"

# Wire upstream (idempotent).
if ! git remote | grep -qx upstream; then
    git remote add upstream "https://github.com/intel-innersource/$repo.git"
fi

git sparse-checkout init --cone >/dev/null
git sparse-checkout set '.github' >/dev/null
git checkout "$DEFAULT_BRANCH" --quiet

# shellcheck source=_json.sh
. "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/_json.sh"
json_obj mkt "$mkt" defaultBranch "$DEFAULT_BRANCH"
