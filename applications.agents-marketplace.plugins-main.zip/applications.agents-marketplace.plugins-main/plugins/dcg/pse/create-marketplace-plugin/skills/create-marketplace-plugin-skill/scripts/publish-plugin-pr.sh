#!/usr/bin/env bash
# Push the user branch to the fork and open a PR against
# intel-innersource/applications.agents-marketplace.plugins:<default-branch>.
#
# Usage:
#   publish-plugin-pr.sh --marketplace-path <dir> --gh-login <login> --branch <branch> \
#                        --default-branch <branch> --title <title> --body-file <path>
# Output: JSON {pushed, prUrl, prCreated, fallbackUrl}

set -uo pipefail
IFS=$'\n\t'

MKT=""; GH_LOGIN=""; BRANCH=""; DEFAULT_BRANCH=""; TITLE=""; BODY_FILE=""
while [[ $# -gt 0 ]]; do
    case "$1" in
        --marketplace-path) MKT="$2"; shift 2 ;;
        --gh-login) GH_LOGIN="$2"; shift 2 ;;
        --branch) BRANCH="$2"; shift 2 ;;
        --default-branch) DEFAULT_BRANCH="$2"; shift 2 ;;
        --title) TITLE="$2"; shift 2 ;;
        --body-file) BODY_FILE="$2"; shift 2 ;;
        -h|--help) sed -n '2,8p' "$0"; exit 0 ;;
        *) echo "Unknown arg: $1" >&2; exit 2 ;;
    esac
done

if [[ -z "$MKT" || -z "$GH_LOGIN" || -z "$BRANCH" || -z "$DEFAULT_BRANCH" || -z "$TITLE" || -z "$BODY_FILE" ]]; then
    echo "Missing required arg(s)" >&2; exit 2
fi
if [[ ! -f "$BODY_FILE" ]]; then
    echo "Body file not found: $BODY_FILE" >&2; exit 1
fi

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=set-intel-proxy-env.sh
. "$SCRIPT_DIR/set-intel-proxy-env.sh"

repo='applications.agents-marketplace.plugins'

cd "$MKT"

pushed=false
if git push -u origin "$BRANCH"; then
    pushed=true
fi

pr_url=""
pr_created=false
fallback_url="https://github.com/intel-innersource/${repo}/compare/${DEFAULT_BRANCH}...${GH_LOGIN}:${BRANCH}?expand=1"

if $pushed; then
    head_ref="${GH_LOGIN}:${BRANCH}"
    pr_url="$(gh pr create \
        --repo "intel-innersource/$repo" \
        --base "$DEFAULT_BRANCH" \
        --head "$head_ref" \
        --title "$TITLE" \
        --body-file "$BODY_FILE" 2>/dev/null || true)"
    pr_url="${pr_url%$'\n'}"
    if [[ -n "$pr_url" ]]; then
        pr_created=true
    fi
fi

# shellcheck source=_json.sh
. "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/_json.sh"
json_obj :pushed "$pushed" prUrl "$pr_url" :prCreated "$pr_created" fallbackUrl "$fallback_url"
