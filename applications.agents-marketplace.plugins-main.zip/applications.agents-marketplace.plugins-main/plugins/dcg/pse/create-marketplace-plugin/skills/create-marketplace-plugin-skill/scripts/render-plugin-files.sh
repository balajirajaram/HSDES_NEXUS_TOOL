#!/usr/bin/env bash
# Render plugin.json + README.md from collected state JSON.
# Echoes component file payloads (mcpJson/serverJson/skillFiles/promptFiles/agentFiles)
# back unchanged so Write-PluginFiles can write a single consolidated list.
#
# Usage: render-plugin-files.sh --state-json '<JSON>'
#   OR:  render-plugin-files.sh --state-file <path/to/state.json>
#
# Output: JSON {pluginJson, readmeMd, mcpJson, serverJson, skillFiles, promptFiles, agentFiles}

set -euo pipefail
IFS=$'\n\t'

STATE=""
while [[ $# -gt 0 ]]; do
    case "$1" in
        --state-json) STATE="$2"; shift 2 ;;
        --state-file) STATE="$(cat "$2")"; shift 2 ;;
        -h|--help) sed -n '2,9p' "$0"; exit 0 ;;
        *) echo "Unknown arg: $1" >&2; exit 2 ;;
    esac
done

if [[ -z "$STATE" ]]; then
    echo "Missing required --state-json or --state-file" >&2
    exit 2
fi

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TMPL_DIR="$(cd "$SCRIPT_DIR/../templates" && pwd)"
# shellcheck source=_json.sh
. "$SCRIPT_DIR/_json.sh"

# --- Pull fields out of state via perl helpers -------------------------------

get()      { json_get "$1" <<< "$STATE"; }
has_comp() { json_contains '.components' "$1" <<< "$STATE"; }

NAME="$(get '.pluginName')"
DESCRIPTION="$(get '.description')"
LICENSE="$(get '.license')"
CATEGORY="$(get '.category')"
ORG="$(get '.org')"
GROUP="$(get '.group')"

# Keywords: ["a","b"] -> "\"a\", \"b\""
KEYWORDS=""
first=1
while IFS= read -r kw; do
    [[ -z "$kw" ]] && continue
    if (( first )); then KEYWORDS="\"$kw\""; first=0
    else KEYWORDS="$KEYWORDS, \"$kw\""
    fi
done < <(json_get_lines '.keywords' <<< "$STATE")

SKILLS_FIELD=""
MCP_FIELD=""
has_comp skills && SKILLS_FIELD=$',\n  "skills": "skills/"'
has_comp mcp    && MCP_FIELD=$',\n  "mcpServers": "./.mcp.json"'

TAGS=""
if json_truthy '.exposeToITMarketplace' <<< "$STATE"; then
    TAGS='"intel_global"'
fi

# Escape description for JSON-in-template (double quotes only; template field
# is already inside a JSON string).
DESCRIPTION_JSON_ESC="${DESCRIPTION//\"/\\\"}"

# --- plugin.json -------------------------------------------------------------

plugin_json="$(cat "$TMPL_DIR/plugin.json.tmpl")"
plugin_json="${plugin_json//\{\{NAME\}\}/$NAME}"
plugin_json="${plugin_json//\{\{DESCRIPTION\}\}/$DESCRIPTION_JSON_ESC}"
plugin_json="${plugin_json//\{\{LICENSE\}\}/$LICENSE}"
plugin_json="${plugin_json//\{\{KEYWORDS\}\}/$KEYWORDS}"
plugin_json="${plugin_json//\{\{CATEGORY\}\}/$CATEGORY}"
plugin_json="${plugin_json//\{\{ORG\}\}/$ORG}"
plugin_json="${plugin_json//\{\{GROUP\}\}/$GROUP}"
plugin_json="${plugin_json//\{\{SKILLS_FIELD\}\}/$SKILLS_FIELD}"
plugin_json="${plugin_json//\{\{MCP_FIELD\}\}/$MCP_FIELD}"
plugin_json="${plugin_json//\{\{TAGS\}\}/$TAGS}"

# --- README.md ---------------------------------------------------------------

OWNERS_BULLETS=""
while IFS= read -r owner; do
    [[ -z "$owner" ]] && continue
    if [[ -z "$OWNERS_BULLETS" ]]; then OWNERS_BULLETS="- $owner"
    else OWNERS_BULLETS="${OWNERS_BULLETS}"$'\n'"- $owner"
    fi
done < <(json_get_lines '.owners' <<< "$STATE")

# Derive imported skill names (skills/<name>/...) unique-preserving-order
SKILL_NAMES=()
if has_comp skills; then
    declare -A _seen=()
    while IFS= read -r entry; do
        [[ -z "$entry" ]] && continue
        rel="$(printf '%s' "$entry" | perl -MJSON::PP -e 'local $/; my $j=decode_json(<STDIN>); print $j->{relPath} // "";')"
        name="${rel#*/}"; name="${name%%/*}"
        [[ -z "$name" ]] && continue
        if [[ -z "${_seen[$name]:-}" ]]; then
            SKILL_NAMES+=("$name"); _seen[$name]=1
        fi
    done < <(json_get_lines '.skillFiles' <<< "$STATE")
fi

SKILLS_SECTION=""
if (( ${#SKILL_NAMES[@]} > 0 )); then
    SKILLS_SECTION+="## Skills"$'\n\n'
    i=0
    for n in "${SKILL_NAMES[@]}"; do
        i=$((i+1))
        SKILLS_SECTION+="### ${i}. ${n}"$'\n\n'
        SKILLS_SECTION+="**Location:** [\`skills/${n}/SKILL.md\`](skills/${n}/SKILL.md)"$'\n\n'
    done
    # Trim trailing newlines
    SKILLS_SECTION="${SKILLS_SECTION%$'\n'}"
fi

MCP_SECTION=""
if has_comp mcp; then
    MCP_SECTION=$'## MCP Server\n\nThis plugin bundles an MCP server. Configuration lives in [`.mcp.json`](.mcp.json) and the server descriptor is in [`server.json`](server.json).'
fi

readme_md="$(cat "$TMPL_DIR/README.md.tmpl")"
readme_md="${readme_md//\{\{NAME\}\}/$NAME}"
readme_md="${readme_md//\{\{DESCRIPTION\}\}/$DESCRIPTION}"
readme_md="${readme_md//\{\{SKILLS_SECTION\}\}/$SKILLS_SECTION}"
readme_md="${readme_md//\{\{MCP_SECTION\}\}/$MCP_SECTION}"
readme_md="${readme_md//\{\{OWNERS_BULLETS\}\}/$OWNERS_BULLETS}"

# --- Echo component payloads verbatim ----------------------------------------

MCP_JSON=""
SERVER_JSON=""
if has_comp mcp; then
    MCP_JSON="$(json_get '.mcpJson' <<< "$STATE")"
    SERVER_JSON="$(json_get '.serverJson' <<< "$STATE")"
fi

SKILL_FILES='[]'
PROMPT_FILES='[]'
AGENT_FILES='[]'
has_comp skills  && SKILL_FILES="$(json_get  '.skillFiles'  <<< "$STATE")"
has_comp prompts && PROMPT_FILES="$(json_get '.promptFiles' <<< "$STATE")"
has_comp agents  && AGENT_FILES="$(json_get  '.agentFiles'  <<< "$STATE")"
# json_get returns empty string for missing arrays; restore to []
[[ -z "$SKILL_FILES"  ]] && SKILL_FILES='[]'
[[ -z "$PROMPT_FILES" ]] && PROMPT_FILES='[]'
[[ -z "$AGENT_FILES"  ]] && AGENT_FILES='[]'

# --- Emit final JSON ---------------------------------------------------------

json_obj \
    pluginJson  "$plugin_json" \
    readmeMd    "$readme_md" \
    mcpJson     "$MCP_JSON" \
    serverJson  "$SERVER_JSON" \
    :skillFiles  "$SKILL_FILES" \
    :promptFiles "$PROMPT_FILES" \
    :agentFiles  "$AGENT_FILES"
