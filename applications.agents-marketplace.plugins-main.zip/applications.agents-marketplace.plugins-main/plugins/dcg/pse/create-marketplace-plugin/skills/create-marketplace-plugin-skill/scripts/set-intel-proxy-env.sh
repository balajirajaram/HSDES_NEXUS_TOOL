#!/usr/bin/env bash
# Ensure Intel proxy environment variables are set for the current shell.
# Idempotent. Source (not execute) this file:
#   source scripts/set-intel-proxy-env.sh
# or:
#   . scripts/set-intel-proxy-env.sh

export HTTP_PROXY='http://proxy-chain.intel.com:911/'
export HTTPS_PROXY='http://proxy-chain.intel.com:911/'
export NO_PROXY='localhost,127.0.0.1,.intel.com'
# Lowercase variants for tools that look at them (curl honors both).
export http_proxy="$HTTP_PROXY"
export https_proxy="$HTTPS_PROXY"
export no_proxy="$NO_PROXY"
