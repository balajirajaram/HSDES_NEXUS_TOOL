#!/usr/bin/env bash
# Check whether plugins/<Org>/<Group>/<PluginName> already exists upstream.
# Output: JSON {"exists": <bool>, "path": "<full path>"}
# Usage: test-plugin-collision.sh --org <org> --group <group> --plugin-name <name> --default-branch <branch>

set -uo pipefail
IFS=$'\n\t'

ORG=""; GROUP=""; PLUGIN_NAME=""; DEFAULT_BRANCH=""
while [[ $# -gt 0 ]]; do
    case "$1" in
        --org) ORG="$2"; shift 2 ;;
        --group) GROUP="$2"; shift 2 ;;
        --plugin-name) PLUGIN_NAME="$2"; shift 2 ;;
        --default-branch) DEFAULT_BRANCH="$2"; shift 2 ;;
        -h|--help) sed -n '2,4p' "$0"; exit 0 ;;
        *) echo "Unknown arg: $1" >&2; exit 2 ;;
    esac
done

if [[ -z "$ORG" || -z "$GROUP" || -z "$PLUGIN_NAME" || -z "$DEFAULT_BRANCH" ]]; then
    echo "Missing required arg(s)" >&2
    exit 2
fi

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=set-intel-proxy-env.sh
. "$SCRIPT_DIR/set-intel-proxy-env.sh"
# shellcheck source=_json.sh
. "$SCRIPT_DIR/_json.sh"

path="plugins/${ORG}/${GROUP}/${PLUGIN_NAME}"
parent="plugins/${ORG}/${GROUP}"
query="repos/intel-innersource/applications.agents-marketplace.plugins/contents/${parent}?ref=${DEFAULT_BRANCH}"

exists=false
if raw="$(gh api "$query" 2>/dev/null)"; then
    match="$(perl -MJSON::PP -e '
        my $target = shift // "";
        local $/; my $raw = <STDIN> // "";
        my $ok = 0;
        eval {
            my $arr = decode_json($raw);
            if (ref $arr eq "ARRAY") {
                for my $e (@$arr) {
                    next unless ref $e eq "HASH";
                    my $type = $e->{type} // "";
                    my $name = $e->{name} // "";
                    if ($type eq "dir" && $name eq $target) { $ok = 1; last; }
                }
            }
        };
        print $ok ? "true" : "false";
    ' "$PLUGIN_NAME" <<< "$raw")"
    if [[ "$match" == "true" ]]; then
        exists=true
    fi
fi

json_obj :exists "$exists" path "$path"
