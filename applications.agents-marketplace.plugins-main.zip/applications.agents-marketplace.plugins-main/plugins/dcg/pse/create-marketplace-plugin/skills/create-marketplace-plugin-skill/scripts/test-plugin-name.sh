#!/usr/bin/env bash
# Validate a plugin / skill / group folder name against deterministic rules.
# Output: JSON {"ok": <bool>, "violations": [<string>, ...]}
# Usage: test-plugin-name.sh --name <name>

set -euo pipefail
IFS=$'\n\t'

NAME=""
while [[ $# -gt 0 ]]; do
    case "$1" in
        --name) NAME="$2"; shift 2 ;;
        -h|--help)
            sed -n '2,5p' "$0"; exit 0 ;;
        *) echo "Unknown arg: $1" >&2; exit 2 ;;
    esac
done

if [[ -z "$NAME" ]]; then
    echo "Missing required --name" >&2
    exit 2
fi

violations=()
len=${#NAME}
if (( len < 3 || len > 60 )); then
    violations+=("length must be 3-60 characters")
fi
if [[ ! "$NAME" =~ ^[a-z0-9-]+$ ]]; then
    violations+=("chars: only a-z 0-9 hyphen (no uppercase, underscore, dot, space)")
fi
if [[ "$NAME" == -* || "$NAME" == *- ]]; then
    violations+=("no leading/trailing hyphen")
fi
if [[ "$NAME" == *--* ]]; then
    violations+=("no consecutive hyphens")
fi

ok=true
if (( ${#violations[@]} > 0 )); then
    ok=false
fi

# Emit JSON via shared helper (perl + JSON::PP)
. "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/_json.sh"
viol_json="$(printf '%s\n' "${violations[@]:-}" | json_lines_to_array)"
json_obj :ok "$ok" :violations "$viol_json"
