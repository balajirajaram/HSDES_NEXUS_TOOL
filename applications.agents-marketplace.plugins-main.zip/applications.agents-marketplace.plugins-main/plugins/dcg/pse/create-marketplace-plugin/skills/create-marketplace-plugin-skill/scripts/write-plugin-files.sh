#!/usr/bin/env bash
# Sync the marketplace clone with upstream, ensure the target subtree is in the
# sparse-checkout cone, create the user branch, write all plugin files, append
# the CODEOWNERS line (section-aware, idempotent), stage and commit.
#
# NEVER touches .github/plugin/marketplace.json (upstream regenerates it).
#
# Usage:
#   write-plugin-files.sh \
#     --marketplace-path <dir> --default-branch <branch> --branch <branch> \
#     --org <org> --group <group> --plugin-name <name> \
#     --owners "<space-separated emails>" \
#     --plugin-json-file <path> --readme-md-file <path> \
#     [--mcp-json-file <path>] [--server-json-file <path>] \
#     [--skill-files-json <json|@file>] [--prompt-files-json <json|@file>] [--agent-files-json <json|@file>] \
#     --commit-title <title> --commit-body <body>
#
# Output: JSON {branch, committed, filesWritten:[...]}

set -euo pipefail
IFS=$'\n\t'

MKT=""; DEFAULT_BRANCH=""; BRANCH=""
ORG=""; GROUP=""; PLUGIN_NAME=""; OWNERS=""
PLUGIN_JSON_FILE=""; README_MD_FILE=""
MCP_JSON_FILE=""; SERVER_JSON_FILE=""
SKILL_FILES_JSON=""; PROMPT_FILES_JSON=""; AGENT_FILES_JSON=""
COMMIT_TITLE=""; COMMIT_BODY=""

read_json_arg() {
    # Accepts either raw JSON or '@<path>' to read from file. Echoes JSON.
    local v="$1"
    if [[ "${v:0:1}" == "@" ]]; then cat "${v:1}"; else printf '%s' "$v"; fi
}

while [[ $# -gt 0 ]]; do
    case "$1" in
        --marketplace-path) MKT="$2"; shift 2 ;;
        --default-branch) DEFAULT_BRANCH="$2"; shift 2 ;;
        --branch) BRANCH="$2"; shift 2 ;;
        --org) ORG="$2"; shift 2 ;;
        --group) GROUP="$2"; shift 2 ;;
        --plugin-name) PLUGIN_NAME="$2"; shift 2 ;;
        --owners) OWNERS="$2"; shift 2 ;;
        --plugin-json-file) PLUGIN_JSON_FILE="$2"; shift 2 ;;
        --readme-md-file) README_MD_FILE="$2"; shift 2 ;;
        --mcp-json-file) MCP_JSON_FILE="$2"; shift 2 ;;
        --server-json-file) SERVER_JSON_FILE="$2"; shift 2 ;;
        --skill-files-json) SKILL_FILES_JSON="$(read_json_arg "$2")"; shift 2 ;;
        --prompt-files-json) PROMPT_FILES_JSON="$(read_json_arg "$2")"; shift 2 ;;
        --agent-files-json) AGENT_FILES_JSON="$(read_json_arg "$2")"; shift 2 ;;
        --commit-title) COMMIT_TITLE="$2"; shift 2 ;;
        --commit-body) COMMIT_BODY="$2"; shift 2 ;;
        -h|--help) sed -n '2,20p' "$0"; exit 0 ;;
        *) echo "Unknown arg: $1" >&2; exit 2 ;;
    esac
done

for v in MKT DEFAULT_BRANCH BRANCH ORG GROUP PLUGIN_NAME OWNERS PLUGIN_JSON_FILE README_MD_FILE COMMIT_TITLE COMMIT_BODY; do
    if [[ -z "${!v}" ]]; then echo "Missing required --${v,,} (mapped from $v)" >&2; exit 2; fi
done

# shellcheck source=_json.sh
. "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/_json.sh"

cd "$MKT"

git_quiet() { git "$@" >/dev/null 2>&1; }

# 1. Sync with upstream on default branch
git switch "$DEFAULT_BRANCH" --quiet
git fetch upstream --quiet
git merge --ff-only --quiet "upstream/$DEFAULT_BRANCH"

# 2. Ensure target subtree is in sparse cone (idempotent, only if sparse-checkout enabled)
if [[ "$(git config --bool --get core.sparseCheckout 2>/dev/null || true)" == "true" ]]; then
    git sparse-checkout add '.github' "plugins/$ORG/$GROUP" >/dev/null
fi

# 3. Create / switch to user branch
if ! git_quiet switch -c "$BRANCH"; then
    git switch "$BRANCH" --quiet
fi

# 4. Write plugin files (UTF-8, no BOM, LF line endings - cp/cat write bytes as-is)
plugin_dir="$MKT/plugins/$ORG/$GROUP/$PLUGIN_NAME"
mkdir -p "$plugin_dir"

WRITTEN_FILE="$(mktemp)"
trap 'rm -f "$WRITTEN_FILE"' EXIT

write_file() {
    local target="$1" src_file="$2"
    mkdir -p "$(dirname "$target")"
    cp "$src_file" "$target"
    printf '%s\n' "$target" >> "$WRITTEN_FILE"
}

write_file_from_stdin() {
    local target="$1"
    mkdir -p "$(dirname "$target")"
    cat > "$target"
    printf '%s\n' "$target" >> "$WRITTEN_FILE"
}

write_file "$plugin_dir/plugin.json" "$PLUGIN_JSON_FILE"
write_file "$plugin_dir/README.md"   "$README_MD_FILE"
[[ -n "$MCP_JSON_FILE"    ]] && write_file "$plugin_dir/.mcp.json"   "$MCP_JSON_FILE"
[[ -n "$SERVER_JSON_FILE" ]] && write_file "$plugin_dir/server.json" "$SERVER_JSON_FILE"

# Write a JSON list of {relPath, content} entries into the plugin dir.
write_file_list() {
    local json="$1"
    [[ -z "$json" || "$json" == "null" ]] && return 0
    local count
    count="$(json_len . <<< "$json" 2>/dev/null || echo 0)"
    (( count == 0 )) && return 0
    local i=0
    while (( i < count )); do
        local rel content target
        rel="$(json_get ".[$i].relPath" <<< "$json")"
        content="$(json_get ".[$i].content" <<< "$json")"
        target="$plugin_dir/$rel"
        mkdir -p "$(dirname "$target")"
        printf '%s' "$content" > "$target"
        printf '%s\n' "$target" >> "$WRITTEN_FILE"
        i=$((i+1))
    done
}

write_file_list "$SKILL_FILES_JSON"
write_file_list "$PROMPT_FILES_JSON"
write_file_list "$AGENT_FILES_JSON"

# 5. Section-aware CODEOWNERS insert (idempotent)
codeowners="$MKT/.github/CODEOWNERS"
path_token="/plugins/$ORG/$GROUP/$PLUGIN_NAME/"
group_prefix="/plugins/$ORG/$GROUP/"

if [[ ! -f "$codeowners" ]]; then
    : > "$codeowners"
fi

if ! grep -qF "$path_token" "$codeowners"; then
    # Build the new entry. Upstream convention: path padded to 47 chars + space + owners.
    new_line="$(printf '%-47s %s' "$path_token" "$OWNERS")"

    # Use awk for section-aware insertion. Pass parameters via -v.
    org_upper="${ORG^^}"
    group_upper="${GROUP^^}"
    section_header="# Plugin owners ($org_upper / $group_upper)"

    tmp_out="$(mktemp)"
    awk -v new_line="$new_line" \
        -v group_prefix="$group_prefix" \
        -v section_header="$section_header" \
        -v hdr_org="$org_upper" \
        -v hdr_group="$group_upper" \
    '
    BEGIN { n=0 }
    { lines[n++] = $0 }
    END {
        # Strip trailing empty line (we will re-add)
        if (n>0 && lines[n-1]=="") n--

        # (a) last existing entry for this org/group?
        at = -1
        for (i = n-1; i >= 0 && at < 0; i--) {
            if (index(lines[i], group_prefix) == 1) at = i + 1
        }

        # (b) matching section header followed by /plugins/ block?
        if (at < 0) {
            # Regex: ^#\s*Plugin owners\s*\(\s*ORG\s*/\s*GROUP\b
            hdr_re = "^#[[:space:]]*Plugin owners[[:space:]]*\\([[:space:]]*" hdr_org "[[:space:]]*/[[:space:]]*" hdr_group "([^[:alnum:]_]|$)"
            for (i = 0; i < n && at < 0; i++) {
                if (lines[i] ~ hdr_re) {
                    j = i + 1
                    while (j < n && index(lines[j], "/plugins/") == 1) j++
                    at = j
                }
            }
        }

        if (at < 0) {
            # (c) new section before "# Marketplace registry" or at EOF
            reg_idx = -1
            for (i = 0; i < n; i++) {
                if (lines[i] ~ /^#[[:space:]]*Marketplace registry/) { reg_idx = i; break }
            }
            if (reg_idx >= 0) {
                # Emit lines[0..reg_idx-1], then blank + header + new_line + blank, then lines[reg_idx..n-1]
                for (i = 0; i < reg_idx; i++) print lines[i]
                print ""
                print section_header
                print new_line
                print ""
                for (i = reg_idx; i < n; i++) print lines[i]
            } else {
                # Append at EOF
                for (i = 0; i < n; i++) print lines[i]
                print ""
                print section_header
                print new_line
            }
        } else {
            # Insert new_line at index "at"
            for (i = 0; i < at; i++) print lines[i]
            print new_line
            for (i = at; i < n; i++) print lines[i]
        }
    }
    ' "$codeowners" > "$tmp_out"

    mv "$tmp_out" "$codeowners"
    printf '%s\n' "$codeowners" >> "$WRITTEN_FILE"
fi

# 6. Stage + commit (explicitly DO NOT add marketplace.json)
git add ".github/CODEOWNERS" "plugins/$ORG/$GROUP/$PLUGIN_NAME"
committed=true
if ! git commit -m "$COMMIT_TITLE" -m "$COMMIT_BODY" >/dev/null 2>&1; then
    committed=false
fi

# Build filesWritten JSON array
files_arr="$(json_lines_to_array < "$WRITTEN_FILE")"

json_obj branch "$BRANCH" :committed "$committed" :filesWritten "$files_arr"
