# deploy-static-website

Deploy static websites to GitHub Pages for intel-sandbox and intel-innersource repositories, with safety checks for publish path and Jekyll underscore handling.

## Version

**1.0.0**

## Features

- Enables GitHub Pages for `intel-sandbox` and `intel-innersource` repositories
- Scans repository content to locate the correct `index.html` publish path (`/` or `/docs`)
- Detects underscore-prefixed asset paths and applies `.nojekyll` when needed
- Supports creating new Intel GitHub teams in inventory
- Supports granting team permissions to repositories (inventory PR flow or direct API mode)

## Skills

### 1. deploy-static-website

**Purpose:** Publish a static site to GitHub Pages for an `intel-sandbox` or `intel-innersource` repository.

**Location:** [skills/deploy-static-website/SKILL.md](skills/deploy-static-website/SKILL.md)

### 2. create-intel-github-team

**Purpose:** Create a team entitlement in `intel-innersource/inventory` for both `intel-innersource` and `intel-sandbox`.

**Location:** [skills/create-intel-github-team/SKILL.md](skills/create-intel-github-team/SKILL.md)

### 3. add-team-repo-permission

**Purpose:** Add an existing team to repository permissions through inventory PR workflow or direct GitHub API.

**Location:** [skills/add-team-repo-permission/SKILL.md](skills/add-team-repo-permission/SKILL.md)

## Prerequisites

- Git installed and available in PATH
- GitHub CLI (`gh`) installed and authenticated
- Permission to access target repos in `intel-sandbox` or `intel-innersource` and, for inventory workflows, `intel-innersource/inventory`

## Usage examples

- deploy static website for repo `my-team-site`
- create github team `my-project-admins` with owners `user1@intel.com,user2@intel.com`
- add team `my-project-admins` read permission to repo `applications.agents-marketplace.plugins`

## Installation

Installed via the marketplace. No manual installation steps required.

## Support

**Repository:** https://github.com/intel-innersource/applications.agents-marketplace.plugins

## Changelog

### 1.0.0
- Initial release
- Added static website deployment skill for GitHub Pages
- Added Intel GitHub team creation skill
- Added team repository permission management skill
