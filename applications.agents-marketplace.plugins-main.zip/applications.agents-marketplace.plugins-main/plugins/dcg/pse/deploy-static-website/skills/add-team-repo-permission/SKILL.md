---
name: add-team-repo-permission
description: Add an existing team to repository permissions either through intel-innersource/inventory (PR flow) or directly via GitHub API (no inventory PR). Defaults to read permission, but allows choosing admin, maintain, write, triage, or read. USE FOR: add team reader, add team to repo permissions, give team read access, give team write access, update repos yml permissions, direct github api permission grant.
argument-hint: "[repo-name] [team-name] (optional hints; user confirmation is still required)"
disable-model-invocation: true
---

# Add Team to Repo Permissions (1Source Inventory)

Updates a repo definition in `intel-innersource/inventory` so a team is present under `permissions.<level>` in the repo's `repos.yml`.

Default permission level is `read`, but user can choose:

- `admin`
- `maintain`
- `write`
- `triage`
- `read`

## Workflow

### Step 0 -- Choose operation mode

Ask the user to choose one mode:

- `inventory-pr` (recommended): update `repos.yml` in `intel-innersource/inventory` and open PR.
- `direct-api` (no PR): call GitHub Team Repository API to grant permission immediately.

Show this warning when `direct-api` is selected:

```
Direct API mode does not update 1Source inventory. If your org uses inventory as source of truth,
automation may later drift or overwrite direct permission changes.
```

### Step 1 -- Prerequisites and auth mode

Run:

```powershell
git --version
gh --version
gh auth status
```

- `git` is required.
- `gh` is required.

If `gh` is missing, stop and ask the user to install GitHub CLI: https://cli.github.com/

If unauthenticated, run:

```powershell
gh auth login --hostname github.com --git-protocol https --web
```

Then re-run `gh auth status`.

### Step 1.1 -- Choose execution path

- Use **gh-assisted execution**.

### Step 2 -- Ask required inputs

Prompt for all of the following before any file edit:

1. Repo name (required for `inventory-pr`):

```
Enter the target repo name from repos.yml (example: applications.agents-marketplace.plugins):
```

2. Team name (required):

```
Enter team name to grant permission (example: ecas-team):
```

Validate with: `^[a-z0-9]+(?:-[a-z0-9]+)*$`

3. Permission level (required, default `read`):

```
Select permission level:
  1) read (default)
  2) triage
  3) write
  4) maintain
  5) admin
```

Store selected value as `$permissionLevel`.

4. For `direct-api`, also ask:

```
Enter GitHub organization (example: intel-innersource or intel-sandbox):
Enter GitHub repository slug (example: applications.agents-marketplace.plugins):
```

Store as `$targetOrg` and `$targetRepo`.

5. For `direct-api`, derive GitHub API permission mapping:

- `read` -> `pull`
- `triage` -> `triage`
- `write` -> `push`
- `maintain` -> `maintain`
- `admin` -> `admin`

Store mapped value as `$apiPermission`.

### Step 3 -- Resolve target repos.yml path

Skip this step when mode is `direct-api`.

Use GitHub code search first (fast, avoids full tree scanning):

```powershell
$repoNameEscaped = $repoName.Replace('"', '\"')
$query = "repo:intel-innersource/inventory path:organizations filename:repos.yml \"name: $repoNameEscaped\""
$matches = gh api search/code -f q="$query" --jq '.items[].path'
```

Handling:

- 0 matches: tell user repo was not found; ask them to provide the full `repos.yml` path manually.
- 1 match: use it as `$reposPath`.
- >1 matches: show numbered options, ask user to choose the correct path.

Manual path must end with `repos.yml` and start with `organizations/`.

### Step 4 -- Prepare working copy and branch

Skip this step when mode is `direct-api`.

#### Path A (gh-assisted)

```powershell
$ghLogin = gh api user --jq .login
$defaultBranch = gh repo view intel-innersource/inventory --json defaultBranchRef --jq .defaultBranchRef.name
$work = Join-Path $env:USERPROFILE "gitwork"
$repoPath = Join-Path $work "inventory-permissions"

if (Test-Path $repoPath) { Remove-Item -Recurse -Force $repoPath }
New-Item -ItemType Directory -Force -Path $work | Out-Null

gh repo fork intel-innersource/inventory --clone=false --remote=false | Out-Null
git clone --filter=blob:none --no-checkout "https://github.com/$ghLogin/inventory.git" $repoPath
Set-Location $repoPath

git remote add upstream https://github.com/intel-innersource/inventory.git 2>$null
git fetch upstream $defaultBranch
git checkout -B $defaultBranch "upstream/$defaultBranch"

git sparse-checkout init --cone
git sparse-checkout set $reposPath

$branch = "user/$ghLogin/add-team-permission-$teamName"
git checkout -B $branch
```

Regular git-only flow is not supported. `gh` is required.

### Step 5 -- Update `repos.yml` permissions safely

Skip this step when mode is `direct-api`.

Set local file path:

```powershell
$localReposFile = Join-Path (Get-Location) $reposPath
```

Ensure file exists; if not, stop and report error.

Parse and update YAML using PowerShell YAML cmdlets:

```powershell
$repoObj = Get-Content -Raw $localReposFile | ConvertFrom-Yaml

if (-not $repoObj.permissions) {
  $repoObj | Add-Member -NotePropertyName permissions -NotePropertyValue ([ordered]@{})
}

$levels = @('admin','maintain','write','triage','read')
foreach ($lvl in $levels) {
  if (-not $repoObj.permissions.$lvl) { continue }
  if ($repoObj.permissions.$lvl -contains $teamName -and $lvl -ne $permissionLevel) {
    Write-Error "Team '$teamName' already exists under permissions.$lvl. Stop and ask user whether to move it first."
    exit 2
  }
}

if (-not $repoObj.permissions.$permissionLevel) {
  $repoObj.permissions | Add-Member -NotePropertyName $permissionLevel -NotePropertyValue @()
}

if (-not ($repoObj.permissions.$permissionLevel -contains $teamName)) {
  $repoObj.permissions.$permissionLevel += $teamName
}

$yamlOut = $repoObj | ConvertTo-Yaml
Set-Content -Path $localReposFile -Value $yamlOut -NoNewline
```

If team already exists in the chosen level, keep file unchanged and tell user no update was needed.

### Step 6 -- Commit, push, and return PR URL

Skip this step when mode is `direct-api`.

```powershell
git add $reposPath
git commit -m "Grant $permissionLevel permission to $teamName for $repoName"
git push -u origin $branch
```

If nothing to commit, return:

```
No changes were needed. Team already had the requested permission.
```

#### Path A (gh-assisted): create PR

```powershell
$prTitle = "Grant $permissionLevel permission to $teamName for $repoName"
$prBody = @"
Updates repo permissions in inventory.

Repo:
- $repoName

Team:
- $teamName

Permission level:
- $permissionLevel

Updated file:
- $reposPath
"@

$prUrl = gh pr create `
  --repo intel-innersource/inventory `
  --base $defaultBranch `
  --head "$ghLogin`:$branch" `
  --title $prTitle `
  --body $prBody
```

Return:

```
PR created successfully: <pr-url>
```

If `gh pr create` fails, return compare URL fallback:

```
https://github.com/intel-innersource/inventory/compare/<default-branch>...<gh-login>:<branch>?expand=1
```

If needed, return compare URL fallback:

```text
https://github.com/intel-innersource/inventory/compare/<default-branch>...<gh-login>:<branch>?expand=1
```

### Step 7 -- Direct GitHub API mode (no inventory PR)

Run only when mode is `direct-api`.

Prerequisites:

- `gh` must be installed and authenticated.
- token must include scopes that allow team permission management (typically `read:org` and repo admin/write access as required by org policy).

Run:

```powershell
$teamSlug = $teamName
$endpoint = "/orgs/$targetOrg/teams/$teamSlug/repos/$targetOrg/$targetRepo"

gh api -X PUT $endpoint -f permission="$apiPermission" -i
```

Expected outcomes:

- `204 No Content`: permission applied successfully.
- `403/404`: team/repo not found, insufficient rights, or org policy restriction.

Return this success message:

```
Permission applied directly via GitHub API: <targetOrg>/<targetRepo> <- <teamName> (<permissionLevel>)
```

If API call fails, return the HTTP status and response details.

## Output Requirements

- Must ask for repo name and team name before editing files.
- Must ask for operation mode (`inventory-pr` or `direct-api`) before execution.
- Must offer permission choice with default `read`.
- Must require authenticated GitHub CLI (`gh`).
- In `inventory-pr` mode: must update the correct `repos.yml` permission level list.
- In `inventory-pr` mode: must not duplicate the same team in the selected permission list.
- In `inventory-pr` mode: must return a PR URL (direct PR URL or compare URL fallback).
- In `direct-api` mode: must call GitHub API to apply permission without creating inventory PR.
