---
name: create-intel-github-team
description: Create a new Intel GitHub team entitlement in intel-innersource/inventory under teams/, configured for both intel-innersource and intel-sandbox organizations, then return a pull-request link. GitHub CLI (gh) is required for auth, fork, and PR creation. USE FOR: create github team, create inventory team yml, add team entitlement, 1source team creation, intel-innersource team, intel-sandbox team.
argument-hint: "[team-name] (optional starting hint; user confirmation is still required)"
disable-model-invocation: true
---

# Create Intel GitHub Team in 1Source Inventory

Creates a new file in `intel-innersource/inventory` under `teams/<team-name>.yml`, scoped to both organizations:

- `intel-innersource`
- `intel-sandbox`

Reference docs:

- Team inventory location: https://github.com/intel-innersource/inventory/tree/master/teams
- Entitlement creation guidance: https://1source.intel.com/docs/getting_started/access_management#create-new-entitlements-automatically

## Workflow

### Step 1 -- Prerequisites and auth

Run:

```powershell
git --version
gh --version
gh auth status
```

- `git` is required.
- `gh` is required.

If `gh` is missing, stop and ask the user to install GitHub CLI: https://cli.github.com/

If `gh auth status` is not authenticated, run:

```powershell
gh auth login --hostname github.com --git-protocol https --web
```

Then re-run `gh auth status`.

### Step 2 -- Ask for team name (required)

Always ask the user for the team name, even if an argument hint was provided.

Prompt text:

```
Enter the new Intel GitHub team name to create in inventory (example: my-project-admins):
```

Validation rules:

- lowercase letters, digits, hyphen only: `^[a-z0-9]+(?:-[a-z0-9]+)*$`
- length 3-80 characters

If invalid, explain the rule and re-prompt.

### Step 2.1 -- Ask for owner emails (required, min 2)

Ask the user for team owner emails before any file creation.

Prompt text:

```
Enter team owner emails (comma- or newline-separated). Minimum 2 required:
```

Validation rules:

- at least 2 unique emails
- each email must match: `^[a-zA-Z0-9._%+-]+@intel\.com$`

Normalize every valid owner email to lowercase before storing it in `$owners` and writing the YAML.

If fewer than 2 valid emails are provided, explain the requirement and re-prompt.
Store as `$owners`.

### Step 3 -- Prepare inventory repo and branch

Get current GitHub identity:

```powershell
$ghLogin = gh api user --jq .login
$defaultBranch = gh repo view intel-innersource/inventory --json defaultBranchRef --jq .defaultBranchRef.name
```

Create a working clone if needed:

```powershell
$work = Join-Path $env:USERPROFILE "gitwork"
New-Item -ItemType Directory -Force -Path $work | Out-Null
Set-Location $work

if (-not (Test-Path (Join-Path $work "inventory\.git"))) {
  gh repo fork intel-innersource/inventory --clone=true
}

Set-Location (Join-Path $work "inventory")
git remote get-url upstream *> $null
if ($LASTEXITCODE -ne 0) {
  git remote add upstream https://github.com/intel-innersource/inventory.git
}

git fetch upstream
git checkout $defaultBranch
git pull --ff-only upstream $defaultBranch
```

Create branch:

```powershell
$branch = "user/$ghLogin/add-team-$teamName"
git checkout -B $branch
```

### Step 4 -- Create `teams/<team-name>.yml`

Target file path:

```powershell
$teamFile = Join-Path (Get-Location) "teams/$teamName.yml"
```

If `$teamFile` already exists, stop and tell the user the team file already exists.

Write this exact YAML:

```yaml
name: <team-name>
ad-group: <team-name>
managed-by-1source: true
owners:
  - <owner-email-1>
  - <owner-email-2>
organizations:
  - intel-innersource
  - intel-sandbox
```

Replace `<team-name>` with the validated user value.
Replace owner placeholders with the validated owner email list from `$owners`, after lowercasing each email.

### Step 5 -- Commit and push

Run:

```powershell
git add "teams/$teamName.yml"
git commit -m "Add team entitlement: $teamName (intel-innersource + intel-sandbox)"
git push -u origin $branch
```

If `git commit` reports nothing to commit, stop and tell the user no changes were created.

### Step 6 -- Open PR and return URL

Create PR:

```powershell
$prTitle = "Add team entitlement: $teamName"
$prBody = @"
Adds a new team entitlement in inventory for:
- intel-innersource
- intel-sandbox

Team file:
- teams/$teamName.yml

Reference:
- https://1source.intel.com/docs/getting_started/access_management#create-new-entitlements-automatically
"@

$prUrl = gh pr create `
  --repo intel-innersource/inventory `
  --base $defaultBranch `
  --head "$ghLogin`:$branch" `
  --title $prTitle `
  --body $prBody
```

Return this to the user:

```
PR created successfully: <pr-url>
```

If PR creation fails, return the compare URL as fallback:

```
https://github.com/intel-innersource/inventory/compare/<default-branch>...<gh-login>:<branch>?expand=1
```

## Output Requirements

- Must ask user for team name before file creation.
- Must ask user for owner emails before file creation (minimum 2 valid `@intel.com` emails).
- Must normalize owner emails to lowercase before writing them to the team yaml.
- Must include both organizations in the team yaml:
  - `intel-innersource`
  - `intel-sandbox`
- Must require authenticated GitHub CLI (`gh`).
- Must return a PR URL at the end:
  - direct PR URL when `gh pr create` succeeds, or
  - compare URL fallback when `gh pr create` fails.