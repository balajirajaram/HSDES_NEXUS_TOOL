---
name: deploy-static-website
description: Deploys a static website to GitHub Pages for repos under the intel-sandbox or intel-innersource organizations. Validates the repo is a supported GitHub repo, retrieves a GitHub bearer token, scans the repo for index.html (root or docs/) and underscore-prefixed asset paths, adds a .nojekyll marker when needed, and enables GitHub Pages via the API. USE FOR: deploy static website, enable github pages, publish static site, host static website, deploy index.html, deploy to github pages, intel-sandbox github pages, intel-innersource github pages.
disable-model-invocation: true
---

# Deploy Static Website to GitHub Pages

Deploys a static website from a local folder to GitHub Pages under `intel-sandbox` or `intel-innersource`.

## Workflow

### Step 1 -- Validate the folder is a valid supported GitHub repo

Run:
```bash
git remote get-url origin
```

- If the command fails or returns nothing -> tell the user: "This folder is not a Git repository. Please run this from a valid GitHub repo under intel-sandbox or intel-innersource (examples: https://github.com/intel-sandbox/test-github, https://github.com/intel-innersource/test-github)."
- If the remote URL does not contain `github.com/intel-sandbox/` or `github.com/intel-innersource/` -> tell the user: "This repo is not under a supported organization. It must match one of: https://github.com/intel-sandbox/<repo-name> or https://github.com/intel-innersource/<repo-name>."
- Extract `<org-name>` and `<repo-name>` from the remote URL for use in subsequent steps.

### Step 2 -- Get the GitHub bearer token

Run:
```bash
gh auth token
```

- If `gh` is not installed or the user is not logged in -> tell the user: "Please install the GitHub CLI (https://cli.github.com) and run `gh auth login` first."
- Store the token as `GITHUB_TOKEN` for subsequent API calls.

### Step 3 -- Scan the repo and locate index.html

Scan the repo to find `index.html` and decide which path to publish from. GitHub Pages can publish from `/` (root) or `/docs` on the selected branch -- nothing else. If the site lives in any other subfolder (for example `output/`, `build/`, `dist/`, `site/`, `public/`), it must be promoted before Pages can serve it.

1. **Find every `index.html` tracked by git** (ignore `node_modules`, `.git`, etc.):
   ```bash
   git ls-files "*index.html"
   ```
   - No results -> tell the user: "No index.html found in the repository. GitHub Pages requires an index.html. Please add one and commit it."
   - Untracked but present on disk (`ls index.html` succeeds, `git ls-files index.html` is empty) -> warn: "index.html exists locally but is not committed. Please commit and push it before enabling GitHub Pages."

2. **Pick the publish path** based on where `index.html` lives:
   - `index.html` -> publish path is `/`.
   - `docs/index.html` -> publish path is `/docs`.
   - Any other location (e.g. `output/index.html`, `build/index.html`, `dist/index.html`) -> the site is in a subfolder Pages cannot serve. Tell the user the exact subfolder found and ask whether to:
     - **(a)** move the contents to the repo root (recommended for simple static sites), or
     - **(b)** rename/move the folder to `docs/` so Pages can publish from `/docs`.
     Then perform the chosen move with `git mv`, commit, and push. Example for option (b):
     ```bash
     git mv output docs
     git commit -m "Move site into docs/ for GitHub Pages"
     git push
     ```
   - Multiple `index.html` candidates -> show the list and ask the user which one is the site entry point before continuing.

3. **Scan for underscore-prefixed paths referenced from HTML/CSS.** GitHub Pages runs Jekyll by default, which strips any file or folder whose name starts with `_` (for example `_static`, `_images`, `_next`, `_assets`). Sphinx, Next.js exports, and several doc generators rely on these. Detect them:
   ```bash
   # Find underscore-prefixed top-level folders inside the publish path
   ls -1a <publish-dir> | grep -E '^_'

   # Find HTML/CSS references to underscore-prefixed paths
   grep -RInE '(href|src|url\()\s*=?\s*["'\'']?(\.?/?_[A-Za-z0-9._-]+)' <publish-dir> \
     --include='*.html' --include='*.htm' --include='*.css' --include='*.js'
   ```
   If either command returns matches, the site **will appear broken on Pages** (missing CSS, images, JS). Fix by adding an empty `.nojekyll` marker file in the publish path so GitHub Pages serves files as-is:
   ```bash
   touch <publish-dir>/.nojekyll
   git add <publish-dir>/.nojekyll
   git commit -m "Add .nojekyll to disable Jekyll processing for GitHub Pages"
   git push
   ```
   Tell the user which underscore paths were detected and that `.nojekyll` was added to fix them. If no underscore paths are referenced, skip this fix.

4. **Sanity-check relative asset paths.** Quickly grep for absolute paths that won't resolve under the project Pages URL (`https://<org-name>.github.io/<repo-name>/`):
   ```bash
   grep -RInE '(href|src)\s*=\s*["'\'']/[A-Za-z0-9_.-]' <publish-dir> --include='*.html'
   ```
   If matches exist, warn the user: "Found absolute paths starting with `/` in HTML. On a project Pages site these resolve to `https://<org-name>.github.io/...` and will 404. Consider making them relative (e.g. `./assets/...`) or prefixing with `/<repo-name>/`." Do not block deployment on this -- it's a heads-up.

Record the chosen publish path (`/` or `/docs`) as `PAGES_PATH` for Step 4.

### Step 4 -- Enable GitHub Pages via the API

Run (substitute `<pages-path>` with `PAGES_PATH` from Step 3, either `/` or `/docs`):
```bash
curl -s -o response.json -w "%{http_code}" -X POST \
  -H "Authorization: Bearer $GITHUB_TOKEN" \
  -H "Accept: application/vnd.github+json" \
   https://api.github.com/repos/<org-name>/<repo-name>/pages \
  -d '{"source": {"branch": "main", "path": "<pages-path>"}}'
```

Handle the response:
- **201 Created** -> Success. Tell the user: "GitHub Pages enabled. Your site will be live at: https://<org-name>.github.io/<repo-name>/ (may take 1-2 minutes to deploy)."
- **409 Conflict** -> Pages already enabled. Tell the user: "GitHub Pages is already enabled for this repo. Your site is at: https://<org-name>.github.io/<repo-name>/"
- **404 Not Found** -> Tell the user: "Repo not found or your token doesn't have access. Make sure the repo exists and your token has the `repo` scope."
- **422 Unprocessable Entity** -> Tell the user: "Could not enable Pages. Make sure the `main` branch exists and has at least one commit."
- Any other error -> Show the response body and HTTP status to the user.

## Notes

- The default branch used is `main`. If the repo uses a different default branch, adjust the API call accordingly.
- GitHub Pages can only publish from `/` (root) or `/docs` on the chosen branch. Sites in any other subfolder (`output/`, `build/`, `dist/`, ...) must be moved before Pages will serve them.
- GitHub Pages runs Jekyll by default and ignores any file or folder whose name starts with `_`. Adding an empty `.nojekyll` file in the publish path disables Jekyll and serves the files as-is -- required for Sphinx (`_static`, `_images`), Next.js exports (`_next`), and similar generators.
- GitHub Pages URL format: `https://<org-name>.github.io/<repo-name>/`
- Token needs `repo` scope for private repos, `public_repo` for public repos.
