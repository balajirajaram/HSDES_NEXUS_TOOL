#!/usr/bin/env python3
"""
scan-secrets.py - Scans a directory for hardcoded passwords, secrets, and sensitive data.
Usage: python scan-secrets.py [path]   (defaults to current directory)
"""

import os
import re
import sys
from pathlib import Path

# Force UTF-8 output on Windows
if sys.platform == "win32":
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")

# Patterns
PATTERNS = [
    ("Password in code", r"(?i)(password|passwd|pwd)\\s*[=:]\\s*[\"']?[^\\s\"'<>{}\\[\\]]{4,}"),
    ("Secret key", r"(?i)(secret[_-]?key|client[_-]?secret|app[_-]?secret)\\s*[=:]\\s*[\"']?[^\\s\"'<>{}\\[\\]]{4,}"),
    ("API key", r"(?i)(api[_-]?key|apikey)\\s*[=:]\\s*[\"']?[^\\s\"'<>{}\\[\\]]{4,}"),
    ("Access token", r"(?i)(access[_-]?token|auth[_-]?token|bearer[_-]?token)\\s*[=:]\\s*[\"']?[^\\s\"'<>{}\\[\\]]{4,}"),
    ("Private key block", r"-----BEGIN (RSA |EC |DSA |OPENSSH )?PRIVATE KEY-----"),
    ("AWS Access Key ID", r"AKIA[0-9A-Z]{16}"),
    ("AWS Secret Access Key", r"(?i)aws[_-]?secret[_-]?access[_-]?key\\s*[=:]\\s*[\"']?[^\\s\"']{20,}"),
    ("Azure connection string", r"DefaultEndpointsProtocol=https;AccountName=[^;]+;AccountKey=[^;]+"),
    ("Azure SAS token", r"(?i)(sv|sig|se|sp|sr)=[A-Za-z0-9%+/=]{10,}"),
    ("GCP service account key", r"\"type\"\\s*:\\s*\"service_account\""),
    ("GitHub token", r"gh[pousr]_[A-Za-z0-9]{36,}"),
    ("Slack token", r"xox[baprs]-[0-9A-Za-z\\-]{10,}"),
    ("Stripe key", r"sk_(live|test)_[0-9a-zA-Z]{24,}"),
    ("SendGrid key", r"SG\\.[A-Za-z0-9_\\-]{22,}\\.[A-Za-z0-9_\\-]{43,}"),
    ("Twilio auth token", r"(?i)twilio.*[0-9a-f]{32}"),
    ("JWT token", r"eyJ[A-Za-z0-9_\\-]{10,}\\.[A-Za-z0-9_\\-]{10,}\\.[A-Za-z0-9_\\-]{10,}"),
    ("DB connection string", r"(?i)(mongodb|postgresql|mysql|mssql|redis|amqp)://[^\\s\"'<>]{8,}"),
    ("Generic URL with creds", r"[a-zA-Z][a-zA-Z0-9+\\-.]*://[^:\\s]+:[^@\\s]+@[^\\s]+"),
    ("Hardcoded .env value", r"(?i)^(SECRET|TOKEN|KEY|PASSWORD|PASS|API_KEY|AUTH)\\s*=\\s*.{4,}"),
]

SKIP_DIRS = {
    ".git", "node_modules", ".venv", "venv", "__pycache__",
    "dist", "build", ".next", ".nuxt", "vendor", ".cache",
    "coverage", ".pytest_cache", "eggs", ".eggs",
}

SKIP_EXTENSIONS = {
    ".png", ".jpg", ".jpeg", ".gif", ".svg", ".ico", ".webp",
    ".woff", ".woff2", ".ttf", ".eot", ".otf",
    ".pdf", ".zip", ".tar", ".gz", ".rar", ".7z",
    ".exe", ".dll", ".so", ".dylib", ".bin",
    ".lock", ".map", ".min.js", ".min.css",
}

SKIP_FILES = {
    "package-lock.json", "yarn.lock", "pnpm-lock.yaml",
    "poetry.lock", "Pipfile.lock", "composer.lock",
    "scan-secrets.py",
}

PLACEHOLDER_HINTS = [
    "example", "placeholder", "your-", "your_", "<your", "xxxx",
    "changeme", "replace", "todo", "fixme", "insert", "enter",
    "********", "######", "$$$$", "xxxxxxxx", "dummy", "sample",
    "test123", "password123", "secret123",
]

MAX_FILE_SIZE_MB = 5


def is_placeholder(line: str) -> bool:
    low = line.lower()
    return any(hint in low for hint in PLACEHOLDER_HINTS)


def scan_file(filepath: Path) -> list[dict]:
    if filepath.stat().st_size > MAX_FILE_SIZE_MB * 1024 * 1024:
        return []

    try:
        text = filepath.read_text(encoding="utf-8", errors="ignore")
    except Exception:
        return []

    findings = []
    for lineno, line in enumerate(text.splitlines(), start=1):
        if is_placeholder(line):
            continue
        for label, pattern in PATTERNS:
            if re.search(pattern, line):
                findings.append(
                    {
                        "file": str(filepath),
                        "line": lineno,
                        "type": label,
                        "preview": line.strip()[:120],
                    }
                )
                break
    return findings


def scan_directory(root: Path) -> list[dict]:
    all_findings = []
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in dirnames if d not in SKIP_DIRS]

        for filename in filenames:
            if filename in SKIP_FILES:
                continue
            ext = "".join(Path(filename).suffixes).lower()
            if ext in SKIP_EXTENSIONS or filename.endswith((".min.js", ".min.css")):
                continue
            filepath = Path(dirpath) / filename
            all_findings.extend(scan_file(filepath))

    return all_findings


def mask(text: str) -> str:
    if len(text) <= 20:
        return text[:4] + "***"
    return text[:30] + "  [... masked ...]"


def print_report(findings: list[dict], root: Path) -> None:
    reset = "\033[0m"
    red = "\033[91m"
    yellow = "\033[93m"
    green = "\033[92m"
    bold = "\033[1m"
    cyan = "\033[96m"

    print(f"\n{bold}Secret Scanner - {root}{reset}")
    print("-" * 70)

    if not findings:
        print(f"{green}[OK] No secrets or sensitive data detected.{reset}\n")
        return

    by_file: dict[str, list] = {}
    for finding in findings:
        by_file.setdefault(finding["file"], []).append(finding)

    for filepath, items in by_file.items():
        rel = os.path.relpath(filepath, root)
        print(f"\n{yellow}[FILE] {rel}{reset}")
        for item in items:
            print(f"   {red}Line {item['line']:>4}{reset}  [{cyan}{item['type']}{reset}]")
            print(f"            {mask(item['preview'])}")

    print("\n" + "-" * 70)
    print(f"{red}{bold}[WARNING] {len(findings)} potential secret(s) found in {len(by_file)} file(s).{reset}")
    print("\nNext steps:")
    print("  1. Review each finding above -- some may be false positives.")
    print("  2. Remove or rotate any real secrets immediately.")
    print("  3. Add sensitive files to .gitignore before committing.")
    print("  4. If already pushed, rotate the credentials -- git history is public.\n")


if __name__ == "__main__":
    root = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(".")
    root = root.resolve()

    if not root.exists():
        print(f"Error: path '{root}' does not exist.")
        sys.exit(1)

    print(f"Scanning: {root} ...")
    findings = scan_directory(root)
    print_report(findings, root)

    sys.exit(1 if findings else 0)
