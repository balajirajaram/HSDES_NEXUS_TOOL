---
name: easycomp-helper
description: 'Help users run EasyComp flows for CPU register collection, BIOS knobs, and RLM uploads across Silicon, Simics, and Emulation domains. Use when: user asks about EasyComp, register snapshots, RLM uploads, rdb-loader, BIOS knob collection, self-service topologies, or PythonSV register reading.'
---

# EasyComp Skills

This SKILLS file teaches an LLM how to help users of **EasyComp**, an Intel CPU validation platform that collects CPU register snapshots, BIOS knobs, and SUT (System Under Test) metadata, then uploads results to the **RLM** (Register Lifecycle Management) platform for comparison and analysis.

---

## 1. EasyComp vs RLM — Know the Difference

Users are often introduced to the entire solution as **"RLM"** and may not know that **EasyComp** is a separate tool. When a user says things like:

- *"I want to use RLM to compare registers"*
- *"How do I upload data to RLM?"*
- *"How do I get started with RLM?"*

They likely need **EasyComp first** — EasyComp is the data collection side, RLM is the viewing/comparison side.

| Component | Role |
|-----------|------|
| **EasyComp** | Collects register snapshots, BIOS knobs, and SUT metadata from the DUT |
| **rdb-loader** | Upload component invoked by EasyComp under the hood — interacts with RLM's API to push data. If a user asks about upload CLI commands or upload APIs, that's rdb-loader |
| **RLM** | Web UI and backend where users view, compare, and analyze the uploaded data |

**The workflow is:** EasyComp collects → rdb-loader uploads to RLM → user views/compares in RLM UI.

If a user asks about collecting data, guide them through EasyComp. If they ask about upload CLI commands or upload APIs, that's rdb-loader (invoked by EasyComp automatically). If they ask about viewing, comparing, or managing data already in the platform, that's the RLM UI side (not covered by this skills file).

---

## 2. What EasyComp Does

EasyComp automates this pipeline:

```
SUT (Silicon / Simics / Emulation)
  → Collect Metadata (CPU stepping, BIOS version, memory type, ...) — via BoardInfo
  → Collect BIOS Knobs (optional) — via XMLCLI
  → Read Registers (per-IP PythonSV reads)
  → Upload to RLM — via rdb-loader
```

---

## 3. What EasyComp Is NOT

To set expectations and route requests correctly:

| Not EasyComp | What It Is | Who Owns It |
|--------------|-----------|-------------|
| RLM UI, RLM backend, RLM CLI, data integrity, access/permissions | **RLM Team** infrastructure | RLM Team |
| rdb-loader CLI, upload API interactions | **rdb-loader** (invoked by EasyComp under the hood) | RLM Team |
| Register definitions, spec content, default values, field descriptions | **Architecture Spec** content | Arch Spec owners |
| PythonSV library, namespace resolution, ITP/DAL | **PythonSV** infrastructure | PythonSV Team |
| BoardInfo library, board metadata collection | **BoardInfo** infrastructure | BoardInfo Team |
| XMLCLI library, BIOS knob reading/writing | **XMLCLI** infrastructure | XMLCLI Team |
| BIOS knob definitions, BIOS behavior, IFWI images | **BIOS/FW** team deliverables | BIOS Team |
| Emulation environment (EMU_MODEL, WORKAREA, MODEL_ROOT) | **emurun** infrastructure | Emulation Team |

---

## 4. Supported Platforms

EasyComp auto-detects the platform from the connected DUT. If auto-detection fails, use `--product-family` to specify it manually (e.g. `--product-family ARL`). For unsupported platforms or new project enablement, use `--topology-file` with a [self-service topology](#self-service-topologies).

**To discover supported platforms**, check the `PROJECT_TO_SHORT_NAME` dictionary in the installed package:

```bash
python -c "from easycomp.utils import PROJECT_TO_SHORT_NAME; print(list(PROJECT_TO_SHORT_NAME.items()))"
```

Both the long name (e.g. `graniterapids`) and the short name (e.g. `GNR`) are accepted wherever a project or platform name is required.

### Discovering Available IPs

IP availability varies by platform. To see the full list of supported IPs and Tier1 IPs for a given platform:

```bash
# Option 1: Dedicated command
python -m easycomp print-rdb-ips --project <PROJECT_NAME>
```
---

## 5. Available Scripts & Commands

### Flow Scripts

These are the user-facing scripts in `easycomp.scripts`:

| Script | Domain | CLI Type |
|--------|--------|----------|
| `run_rdb_flow_silicon` | Silicon register collection | Click CLI |
| `run_rdb_flow_simics` | Simics register collection | Python function (called from Simics console) |
| `run_rdb_flow_emulation` | Emulation register collection | Click CLI |
| `collect_bios_knobs` | Silicon BIOS knob scan | Click CLI |
| `collect_bios_knobs_simics` | Simics BIOS knob scan | Python function (called from Simics console) |
| `identify_dynamic_registers` | Multi-cycle register comparison to find dynamic registers | Click CLI |

### Utility CLI Commands

These additional commands are available as `easycomp` subcommands (invoked as `python -m easycomp <command>`, not under `easycomp.scripts`):

| Command | Purpose | Example |
|---------|---------|--------|
| `print-rdb-ips` | List all supported and Tier1 IPs for a platform | `python -m easycomp print-rdb-ips -p <PROJECT>` |

> **Always recommend flow scripts first.** When a user wants to collect registers, ALWAYS guide them to the full flow scripts (`run_rdb_flow_silicon`, `run_rdb_flow_simics`, `run_rdb_flow_emulation`). These handle the complete pipeline: metadata + BIOS knobs + register read + upload. Do NOT recommend `pysv-read` as a starting point — it only reads registers without metadata, BIOS knobs, or upload, and the user will need to do extra manual work to get data into RLM.

---

## 6. Running EasyComp

> **MANDATORY FIRST STEP: check if the user's project is already supported.** Before doing ANYTHING else for a new user, you MUST determine whether their platform is already enabled. Ask the user to run:
> ```python
> python -c "from easycomp.utils import PROJECT_TO_SHORT_NAME; print(list(PROJECT_TO_SHORT_NAME.items()))"
> ```
> **Wait for the result.** Do NOT suggest self-service, namednodes, or topology files until you have confirmed the project is NOT in this list. If it IS supported, guide them to the standard flow — no topology file needed.

> **Discovering CLI options:** Follow this order:
> 1. **Understand what the user wants** — identify the option or behavior they're asking for.
> 2. **Run `--help`** on the relevant script to check if the option is listed.
> 3. **If not found in `--help`**, inspect the script source code for `@click.option` decorators — some options are hidden but fully functional (see [How to Find More Information](#how-to-find-more-information)).
>
> ```bash
> python -m easycomp.scripts.run_rdb_flow_silicon --help
> python -m easycomp.scripts.run_rdb_flow_emulation --help
> python -m easycomp.scripts.collect_bios_knobs --help
> python -m easycomp.scripts.identify_dynamic_registers --help
> ```
> For Simics flows (which are Python functions, not CLIs), inspect the function signature in the installed package.

> **About `--performance-recipe`:** This is how users label and separate different runs in RLM. Without it, uploading twice with the same metadata will **fail** (duplicate rejection by RLM). A `--force` flag exists to overwrite existing uploads, but it is intended for corner cases only. Always encourage users to provide a meaningful recipe name.

> **About `--rlm-token`:** The token is required on the **first run**. After a successful upload, EasyComp caches the token locally so subsequent runs reuse it automatically — you do not need to pass `--rlm-token` again. Only provide the token again if caching fails (e.g. token expired, cache cleared, or a permissions error occurs).
>
> Users generate this token from the RLM web UI. The token URL depends on the upload-type environment:
> - `prod` (default): https://rlm.laas.intel.com → token page
> - `test`: https://rlm-test.laas.intel.com → token page
> - `dev`: https://rlm-dev.laas.intel.com → token page
>
> Guide users to the token page matching their target environment. The token is required for all upload types except `none`.

### Silicon — Live Hardware DUT

**Entry point:** `python -m easycomp.scripts.run_rdb_flow_silicon`

**Prerequisites:** A working PythonSV installation must be available and accessible on the system for register reads.

Run on a host connected to a Silicon DUT via IPC/PythonSV. This is the primary production flow.

```bash
python -m easycomp.scripts.run_rdb_flow_silicon \
  --performance-recipe "my_recipe_name" \
  --rlm-token <TOKEN>
```

### Simics — Simulated Environment

**Entry point:** Call `run_rdb_flow_simics()` as a Python function inside a Simics window with PythonSV loaded.

**Prerequisites:** Simics must be loaded properly. Users should follow the steps in the EasyComp Wiki page for importing and running the Simics flow.

> **Important:** Simics flows are NOT CLI commands. They are called as Python functions from the Simics PythonSV console.

```python
from easycomp.scripts.run_rdb_flow_simics import run_rdb_flow_simics

run_rdb_flow_simics(
    performance_recipe='my_recipe_name',
    rlm_token='<TOKEN>'
)
```

### Emulation

**Entry point:** `python -m easycomp.scripts.run_rdb_flow_emulation`

**Prerequisites:** The user must provide a valid emurun command file. The required environment variables (`EMU_MODEL`, `WORKAREA`, `MODEL_ROOT`) must already be set up in the system before running the flow. EasyComp does **not** set these — they are emurun's requirements, not EasyComp's.

```bash
python -m easycomp.scripts.run_rdb_flow_emulation \
  --emu-command-file /path/to/emurun_cmd.txt \
  --performance-recipe "my_recipe_name" \
  --rlm-token <TOKEN>
```

---

## 7. BIOS Knob Collection

EasyComp uses **XMLCLI** under the hood to read BIOS knob values. BIOS knobs can be collected in two ways:

### 1. Automatically within a flow

By default, every EasyComp flow collects BIOS knobs. Skip with `--no-bios-knobs`.

### 2. Standalone script

Use the standalone script when you need to attach BIOS knobs to an existing register read.

**Silicon:**
```bash
python -m easycomp.scripts.collect_bios_knobs \
  --registers-uuid <UUID_FROM_REGISTER_READ> \
  --upload-type prod \
  --rlm-token <TOKEN>
```

**Simics** (Python function, not CLI):
```python
from easycomp.scripts.collect_bios_knobs_simics import collect_bios_knobs_simics

collect_bios_knobs_simics(
    registers_uuid='<UUID_FROM_REGISTER_READ>',
    upload_type='prod',
    rlm_token='<TOKEN>'
)
```

The `--registers-uuid` / `registers_uuid` (required) links the BIOS knobs to a previous register read. Find the UUID in the EasyComp `.log` file from the previous run — search for `uuid` in the JSON upload result block near the end of the log.

---

## 8. Self-Service Topologies

When the built-in platform topology doesn't cover your needs — or during a **new project enablement** — create a custom topology to define exactly which IPs and register components to read.

> **Suggest the test environment first.** For new users or new project enablements, recommend uploading to the test environment (`--upload-type test`) instead of production. Explain that this lets them validate the full flow (register read → upload → view in UI) without polluting production data. If the user explicitly states their intent is production, use `--upload-type prod`. Note: when using `--topology-file` (self-service), `--upload-type` is **mandatory** — omitting it raises a UsageError. It cannot be left to default.

> **Quick/sanity run: use a single IP.** If the user just wants to verify the flow works end-to-end (e.g. first-time setup, new topology, or troubleshooting), suggest limiting `IPs_dict` to only 1 IP. A full platform read can take a long time — a single IP keeps the sanity run fast while still exercising the complete pipeline (read → upload → view).

### Recommended: Python Topology (ISelfService)

Implement the `ISelfService` interface:

```python
from easycomp.self_service.self_service_interface import ISelfService

class MyTopology(ISelfService):

    @property
    def project_short_name(self) -> str:
        return 'arl'  # Platform short name

    @property
    def project_long_name(self) -> str:
        return 'arrowlake'  # Platform long name

    @property
    def IPs_dict(self) -> dict:
        # Replace with the actual IPs and PythonSV paths for your platform
        return {
            'mc': ['socket0.soc.north.mem.mc0', 'socket0.soc.north.mem.mc1'],
            'core': ['socket0.cpu.core0', 'socket0.cpu.core1'],
        }

    @property
    def Tier1_IPs(self) -> list:
        return ['mc', 'core']

    def disable_cstates(self):
        pass  # Consult PythonSV team or refer to existing topology examples for C-state disabling logic
```

Then run with:
```bash
python -m easycomp.scripts.run_rdb_flow_silicon \
  --topology-file my_topology.py \
  --upload-type test \
  --performance-recipe "my_recipe_name" \
  --rlm-token <TOKEN>
```

### Other Supported Formats

CSV (`.csv`) and Excel (`.xlsx`) testplan formats are also supported for specific use cases such as HSIO EV workflows. Use `--help` on the flow scripts for details on `--topology-file`, `--sheet-name`, and `--recipe-version` options.

### Generate a Template

Find `template.py` in the installed package's `self_service/` directory (use the package discovery method in "How to Find More Information" below to locate it). Copy it, rename the class, and fill in your IPs.

### Finding PythonSV Paths with Namednodes

Users creating a self-service topology sometimes don't know the exact PythonSV paths for the register components (IPs) they want to collect. For example:

- *"I want to collect PCIE registers"*
- *"I need CXL IP data"*
- *"How do I find the path for memory controller?"*
- *"What's the PythonSV path for DDR IO?"*

Any time a user asks about finding or discovering PythonSV paths — regardless of the IP, component, or register — use the **namednodes Python API** to search for paths, then incorporate results into the generated `ISelfService` topology code. **You MUST first read the namednodes skill files (described below) to learn the correct API usage before executing any namednodes commands.** Do NOT guess or improvise namednodes function calls.

#### Prerequisites

The `namednodes` package must be installed in the PythonSV environment. It is a standard Python package.

#### How to Use Namednodes Search

The namednodes package ships skill files with detailed instructions on searching for components, registers, and accesses. **Load the relevant skill file** from the installed package to learn the correct API usage:

```python
# Find the skills directory:
python -c "import namednodes._mcp.skills; import os; print(os.path.dirname(namednodes._mcp.skills.__file__))"
```

This will output a path like `<python_dir>/Lib/site-packages/namednodes/_mcp/skills/`. Read the `SKILL.md` file from the relevant folder for the task at hand.

These skill files teach you how to import and call the namednodes API. The folder contents may change over time — always discover them dynamically from the installed package path rather than hardcoding.

After reading the relevant skill file, **execute the namednodes Python commands directly in the terminal** to search for paths. Just import namednodes and use its API in any Python console.

When the user describes the IP or register component they want but doesn't know the PythonSV path:

1. **Read the relevant namednodes skill file** to learn the correct search API calls.

2. **Execute namednodes search commands** in the terminal with search queries (IP names, keywords like "pcie", "mc", "cxl", "ddrio", "core"). The API returns PythonSV namespace paths available on the connected DUT.

3. **Present the discovered paths** to the user for confirmation — there may be multiple instances (e.g., multiple memory controllers, multiple PCIe ports).

4. **Generate the `IPs_dict`** using the confirmed paths. For example, if the user wanted "PCIE" and namednodes returned paths like `socket0.imh0.pi6.pcieg6.pxp0` and `socket0.imh0.pi6.pcieg6.pxp1`, generate:

```python
@property
def IPs_dict(self) -> dict:
    return {
        'pcie': [
            'socket0.imh0.pi6.pcieg6.pxp0',
            'socket0.imh0.pi6.pcieg6.pxp1',
        ],
    }
```

#### Example Workflow

**User:** "I want to create a topology that collects PCIE and CXL registers on Arrow Lake."

**LLM actions:**
1. Read the namednodes skill file to learn the search API
2. Execute namednodes Python commands in the terminal to search for "pcie" paths → get results like `socket0.imh0.pi6.pcieg6.pxp0`, `socket0.imh0.pi6.pcieg6.pxp1`
3. Execute namednodes Python commands to search for "cxl" paths → get results like `socket0.imh0.pi6.pcieg6.pxp1.cxl`
4. Confirm the paths with the user
5. Generate the complete `ISelfService` class:

```python
from easycomp.self_service.self_service_interface import ISelfService

class PcieCxlTopology(ISelfService):

    @property
    def project_short_name(self) -> str:
        return 'arl'

    @property
    def project_long_name(self) -> str:
        return 'arrowlake'

    @property
    def IPs_dict(self) -> dict:
        return {
            'pcie': [
                'socket0.imh0.pi6.pcieg6.pxp0',
                'socket0.imh0.pi6.pcieg6.pxp1',
            ],
            'cxl': [
                'socket0.imh0.pi6.pcieg6.pxp1.cxl',
            ],
        }

    @property
    def Tier1_IPs(self) -> list:
        return ['pcie', 'cxl']

    def disable_cstates(self):
        pass
```

---

## 9. Output Files

Each run produces an output directory named `easycomp_output_<DATE_TIME>/` containing:

| File | Description |
|------|-------------|
| **`rdb_metadata.json`** | SUT metadata (product info, key attributes, run info). This is what RLM uses to identify and categorize the upload. |
| **`registers_read.csv`** | Register values: `IP, Path.Register.Field, Value, Access Type, Description, Reg Class, Reset Value, Consumer, Read Error Type`. Can be very large. |
| **`ip_instances.json`** | IP-to-instance mapping showing which PythonSV paths were resolved for each IP. |
| **`easycomp_bios_knobs_<DATE_TIME>.xml`** | BIOS knob values in XMLCLI format (skipped if `--no-bios-knobs`). |
| **`easycomp_<DATE_TIME>.log`** | Full execution log — the primary debugging artifact. See [Reading the Log File](#reading-the-log-file). |
| **`easycomp_artifacts_<DATE_TIME>.zip`** | Artifacts bundle uploaded to Artifactory. Silicon: log + metadata + BoardInfo. Simics: log + metadata. Emulation: log + metadata + `testbench.log` + `report.rpt`. |

---

## 10. Troubleshooting

### When Something Goes Wrong

If a flow fails or produces unexpected results:

1. **Locate the EasyComp `.log` file** from the run output directory
2. **Search for `ERROR` lines** — then trace **upwards** from the error. Earlier log entries (warnings, info messages about the stage or IP being processed) often reveal the root cause
3. **Check the exit code** — `0` means success, non-zero means something failed. The log file contains the details
4. **If the issue is unclear**, ask the user to file an HSD ticket to tool.RDB.Client - Easy Comp, include "easycomp_developer" in notify list with:
   - The exact command they ran
   - The system/platform they ran on (or the system to be used for reproduction and testing)
   - The full `.log` file attached

### Common Failure Scenarios

These are scenarios where the error message alone may not make the fix obvious:

| Scenario | What's Happening | Suggested Fix |
|----------|-----------------|---------------|
| Upload fails with 403 or token errors | RLM token expired or lacks write permissions | Generate a new token: https://rlm-docs.laas.intel.com/specs/token/overview/ |
| `Component instance not found` in a self-service topology | The PythonSV path in your `IPs_dict` does not exist on this DUT — this is a topology path error, not a missing-instance issue | Verify the paths in your topology file using namednodes search. Correct the `IPs_dict` entries to match valid paths on the connected DUT |
| `Namednodes initialization exception` | PythonSV cannot initialize — **not an EasyComp issue** | Ensure PythonSV is installed and `namednodes` can be initialized independently |
| `RunControl_Timeout` — timeout waiting for threads to halt | Metadata succeeded but register read failed because the target threads couldn't be halted — **not an EasyComp issue** | First restart the target and retry. If it persists, restart the host machine |
| BIOS knob scan hangs or fails | DUT in unexpected state or XMLCLI issue — **not an EasyComp issue** | Use `--no-bios-knobs` to skip, or run `collect_bios_knobs` separately later |
| Metadata fields show CLI fallback values | BoardInfo couldn't read the DUT (not halted, or unavailable) — **not an EasyComp issue** | Use `--non-intrusive` mode, or provide overrides: `--bios-version`, `--product-family`, etc. |
| Emulation `emurun command failed` | Missing env vars or invalid command file — **not an EasyComp issue** | Ensure `EMU_MODEL`, `WORKAREA`, `MODEL_ROOT` are set before running |
| Upload fails with duplicate/existing experiment | An upload with the same metadata combination (performance recipe + platform + stepping etc.) already exists in RLM | See [Upload Failures and Manual Retry](#upload-failures-and-manual-retry) below |

> **Missing required metadata — give the user ALL fields at once:** If the upload fails because required metadata fields are missing or have fallback/placeholder values, search the log for `Metadata Summary`. This table lists every metadata field, its value, and its source (BoardInfo / PythonSV / CLI fallback). Identify ALL fields that show fallback or empty values, and present the full list to the user in one shot so they can supply all overrides in a single re-run (e.g. `--bios-version X --product-family Y --stepping Z --qdf ABC ...`). Do NOT ask for fields one at a time.

### Upload Failures and Manual Retry

If the upload stage failed but the output files were generated successfully (`rdb_metadata.json` and `registers_read.csv` exist in the output directory), suggest the rdb-loader command directly so the user can retry without re-running the entire flow:

```bash
python -m rdb_loader load \
  --directory <output_dir> \
  --metadata-file <output_dir>/rdb_metadata.json \
  --env <prod|test> \
  --token <RLM_TOKEN>
```

Add `--biosknobs-file <output_dir>/easycomp_bios_knobs_*.xml` if BIOS knobs were collected. Add `--force` to overwrite an existing upload.

**Duplicate experiment name (most common upload failure):** If the error indicates the experiment already exists, give the user two options. Both use the manual upload command above — do NOT suggest re-running the entire flow since the register read already succeeded and the output files are ready:
1. **Force overwrite** — add `--force` to the manual upload command.
2. **Change the performance recipe** — edit `rdb_metadata.json`, find the `"recipe"` field under the run mode section (e.g. inside `"adhoc": { "recipe": "..." }`), change it to a unique value, then retry with the manual upload command above.

**How to confirm upload succeeded or failed:** Apply these rules IN ORDER:
1. **Search for `RDB upload failed`** — if this string appears ANYWHERE in the log, the upload FAILED. Full stop. Do NOT mark it as succeeded regardless of any other text you see.
2. **Search for `ERR` lines from `RDB_CLI_NEW`** — these are rdb-loader errors. A 422 status with "already an entry with name" means duplicate experiment. A 401/403 means token issue.
3. **Only if no upload error is found**, search for `config_url` — if present, the upload succeeded. Provide that link.
4. **If no `config_url` AND no explicit error** — the upload likely didn't run (e.g. `--upload-type none`).

**NEVER** mark upload as "✅ succeeded" if `RDB upload failed` or `ExitCode=1` appears in the log. **NEVER** fabricate or guess a config URL. If there's no config_url, say the upload failed and suggest the manual retry.

### Reading the Log File

The EasyComp `.log` file is the primary debugging artifact. It follows stages in order: `argument_validation` → `initialize` → `collect_metadata` → `collect_bios_knobs` → `register_read` → `upload` → `teardown`.

**Key things to search for in the log:**

1. **`config_url`** — the direct RLM UI link to view the uploaded data. Appears near the end in the JSON upload result block (e.g. `"config_url": "https://rlm-test.laas.intel.com/#/comparison-settings?SystemConfigUUID=..."`)
2. **`"uuid"`** — the upload identifier, needed for standalone BIOS knob collection. Appears in the same JSON block as `config_url`
3. **`"bios_knobs_uuid"`** — the BIOS knobs upload identifier, also in the JSON upload result
4. **`artifactory`** — the Artifactory backup URL. Search for `upload to artifactory successful` to find the full URL to the artifacts zip
5. **`ERROR`** — error messages with stack traces. During the `register_read` stage, these typically appear when individual IP instances fail to read (e.g. fuse-disabled or unreachable instances). The flow continues reading other IPs — check `ip_instances.json` to verify what was actually read
6. **`Metadata Summary`** — a table printed near the end showing where each metadata field came from (BoardInfo vs PythonSV vs CLI fallback) and whether any CLI overrides were ignored because BoardInfo succeeded
7. **`Failed to disable C-States`** — a WARNING that appears if C-state disabling failed. Data is still collected but may contain transient values
8. **`RDB_CLI_NEW`** — rdb-loader log lines prefixed with `INF`. These show upload progress: file chunking (`File chunk created`), per-chunk upload status (`Upload file: ... Done!`), and RLM load completion (`Uploaded dump is now present in RDB`)

> **Emulation debugging tip:** For emulation flow errors, download the artifacts zip from Artifactory. Inside it, look for `testbench.log` — this contains the emulation console output including logs from `pysv_read_project.py`, which is often the key to diagnosing register read failures in emulation.

---

## 11. How to Find More Information

### Inspect the installed package for deeper details

If `--help` is not enough — or the user asks for an option that doesn't appear in `--help` (some Click options are hidden) — find where EasyComp is installed and read the source to discover all options and their valid choices:

```python
python -c "import easycomp; print(easycomp.__file__)"
```

Once you have the install location, read the relevant source files there to understand parameters, flow logic, and implementation details. Key directories to explore:

| Area | Where to Look (under the installed `easycomp/` directory) |
|------|----------------------------------------------------------|
| Flow scripts (Silicon, Emulation) | `scripts/run_rdb_flow_silicon.py`, `scripts/run_rdb_flow_emulation.py` — look for `@click.option` decorators |
| Simics flow | `scripts/run_rdb_flow_simics.py` — plain function parameters, NOT Click decorators |
| BIOS knob scripts | `scripts/collect_bios_knobs.py` (Silicon), `scripts/collect_bios_knobs_simics.py` (Simics) |
| Dynamic register identification | `scripts/identify_dynamic_registers.py` |
| Self-service topology interface | `self_service/self_service_interface.py` for the `ISelfService` ABC |
| Self-service template | `self_service/template.py` for a working example |
| Flow stage sequence | `flows/base_flow.py` — the `run()` method defines the stage order |
