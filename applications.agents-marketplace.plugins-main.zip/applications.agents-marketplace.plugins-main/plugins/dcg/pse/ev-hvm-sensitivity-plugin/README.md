# EV-HVM Sensitivity Analysis Agent

**Version**: 1.0.1  
**Category**: Validation Tools  
**Authors**: Dr. Francisco Rangel, Edgar Vega

---

## Overview

The **EV-HVM Sensitivity Analysis Agent** performs HVM-to-EV correlation analysis for intelligent part selection in PCIe Gen6 post-silicon validation. It validates statistical correlations between HVM process data (IDV) and electrical performance metrics to recommend high-value silicon parts, replacing traditional FF/TT/SS selection with data-driven methodology.

### Key Features

✅ **Statistical Correlation Analysis**
- Validates IDV↔Electrical relationships using Pearson correlation (r, p-value)
- Applies rigorous thresholds: p < 0.05 (significance), |r| > 0.7 (strength)
- Generates Pareto charts (top 35 IDVs) and scatter plots (top 5 per metric)

✅ **Intelligent Part Selection**
- 8-step methodology replacing FF/TT/SS selection
- Success rate: 80-90% vs 40-60% traditional approach
- Volume-based fallback when correlation is weak

✅ **PCIe Gen6 Support**
- Endpoint-specific analysis (U1/U2 substructures)
- SIOU mapping: pxp1/3/4→U1, pxp9/11/12→U2
- Works with any recipe (not limited to specific products)

✅ **Wafer Spatial Mapping**
- Center/Donut/Edge distribution visualization
- Dual panel output for U1/U2
- Identifies process variation patterns

✅ **IPM Wiki Guidance**
- Applies documented process parameter limitations
- Core principle: "Volume > Coverage when correlation weak"
- Prevents misuse of IDV without statistical validation

---

## Quick Start

### Installation

1. **Via VS Code Command Palette:**
   ```
   Ctrl+Shift+P → "Chat: Install Agent Plugin" → "ev-hvm-sensitivity-plugin"
   ```

2. **Via Copilot Marketplace:**
   - Open Copilot marketplace
   - Search for "EV-HVM Sensitivity"
   - Click "Install"

### Prerequisites

- **Python 3.8+** installed
- **Required packages:**
  ```powershell
  pip install pandas numpy scipy matplotlib python-pptx
  ```

### Prepare Your Data

Place two CSV files in your workspace:

**1. HVM IDV Data (Process measurements)**
- Required columns: `VISUAL_ID`, `IDV_XXX` (e.g., `IDV_006`, `IDV_012`), `REGION` (Center/Donut/Edge), `VID`
- Example: `IDV SAMPLING DMR IMH - by VID_<dataset>.csv`

**2. Electrical Performance Data (EV measurements)**
- Required columns: `VISUAL_ID`, `tMarginMin`, `FBER`, `vocDH_MINmV`, `vocDM_MINmV`, `vocDL_MINmV`, SIOU endpoints
- Example: `PCIEreciperegressions_<recipe>_UPM_Gen6_<dataset>.csv`

### Invoke the Agent

In VS Code Copilot Chat:
```
@ev-hvm-sensitivity
```

The agent will display a welcome message with:
- Required data file specifications
- Quick start commands
- Core capabilities
- Analysis principles

---

## Commands

### Run Correlation Analysis
```
@ev-hvm-sensitivity run correlation analysis
```
Executes `run_hvm_electrical_correlation.py`:
- Generates Pareto charts (top 35 IDVs per metric)
- Creates scatter plots (top 5 per metric)
- Produces PowerPoint report (~100+ slides)
- Outputs `significant_correlations.csv`

### Create Wafer Maps
```
@ev-hvm-sensitivity create wafer maps
```
Executes `waffer_mapping.py`:
- Visualizes VISUAL_ID spatial distribution
- Shows Center/Donut/Edge regions for U1/U2
- Outputs `wafer_map_two_substructures.png`

### Explain Methodology
```
@ev-hvm-sensitivity explain the 8-step methodology
```
Reviews intelligent part selection process from skill documentation.

### Recommend Parts
```
@ev-hvm-sensitivity recommend high-priority parts from results
```
Analyzes `significant_correlations.csv` and applies selection criteria (p<0.05, |r|>0.7).

---

## Methodology

### 8-Step Intelligent Part Selection

1. **Run Correlation Analysis** — Validate IDV↔Electrical relationships
2. **Review Statistical Significance** — Apply p < 0.05, |r| > 0.7 thresholds
3. **Identify Strong Correlations** — Prioritize IDVs with robust relationships
4. **Analyze Spatial Distribution** — Consider wafer geography
5. **Check Endpoint Coverage** — Ensure U1/U2 representation
6. **Apply Volume-Based Fallback** — When correlation weak, prioritize volume
7. **Generate Selection Matrix** — Combine all criteria
8. **Submit HVM Request** — Using documented templates

### Core Principles

❌ **NEVER** select parts based solely on FF/TT/SS process skew  
✅ **ALWAYS** validate IDV↔Electrical correlation statistically before using IDV  
✅ **ALWAYS** prioritize volume over IDV coverage when correlation is weak

---

## Technical Details

### Statistical Thresholds
- **Significance**: p < 0.05
- **Strong correlation**: |r| > 0.7
- **Minimum samples per group**: 10

### SIOU-to-Substructure Mapping
```python
SIOU_TO_SUBSTRUCTURE = {
    "pxp1": "U1", "pxp3": "U1", "pxp4": "U1",
    "pxp9": "U2", "pxp11": "U2", "pxp12": "U2"
}
```

### Wafer Regions
- **Center**: Uniform process conditions
- **Donut**: Transition zone
- **Edge**: High variation

### Output Files
- `pooled_significant_correlations.csv` — Main results
- `chain_*.csv` — Multi-parameter analysis
- `*.pptx` — PowerPoint report
- `wafer_map_two_substructures.png` — Spatial visualization
- Pareto charts (PNG)
- Scatter plots (PNG)

---

## Success Metrics

**Part Selection Effectiveness**:
- IDV-based validated selection: **80-90%** success rate
- Traditional FF/TT/SS selection: **40-60%** success rate

**Correlation Validation**:
- Statistically rigorous (p<0.05, |r|>0.7)
- Volume prioritization when correlation weak (|r|<0.5)

---

## Documentation

### Included Skills

**SKILL: ev-hvm-sensitivity**
- Main skill file with complete methodology
- 8-step part selection process
- Templates for HVM requests
- Statistical analysis guidance
- IPM Wiki best practices

### Supporting Documentation

- **SKILL_idv_part_selection.md** — Detailed methodology with examples
- **SKILL_process_parameters_ipm.md** — IPM Wiki reference
- **SKILL_pcie_gen6_sensitivity_results.md** — Case study findings

### Python Scripts

- **run_hvm_electrical_correlation.py** (118 KB) — Main correlation analysis
- **waffer_mapping.py** (12 KB) — Wafer spatial visualization

---

## Use Cases

### Primary Use Case: PCIe Gen6 Post-Silicon Validation

**Scenario**: Select 10 high-value parts from HVM lot for electrical validation.

**Traditional Approach (FF/TT/SS)**:
- Select 3-4 Fast/Fast, 3-4 Typical/Typical, 3-4 Slow/Slow
- Success rate: 40-60%
- No statistical validation
- Assumes process skew correlates with electrical performance

**EV-HVM Agent Approach**:
1. Run correlation analysis with HVM IDV + EV electrical data
2. Identify IDVs with strong correlation (e.g., IDV_006 Leakage: r=0.82, p=0.001)
3. Select parts covering:
   - Strong correlation IDV range
   - Spatial diversity (Center/Donut/Edge)
   - Endpoint representation (U1/U2)
   - Volume considerations
4. Success rate: 80-90%

### Additional Use Cases

- **Recipe Comparison** — Validate correlation consistency across recipes
- **Endpoint Analysis** — Compare U1 vs U2 sensitivity patterns
- **Process Monitoring** — Track correlation trends over time
- **Failure Analysis** — Correlate field failures with HVM process data

---

## Troubleshooting

### Agent doesn't appear in suggestions
- Verify `.github/agents/ev-hvm-sensitivity.agent.md` exists in workspace
- Reload VS Code window (`Ctrl+Shift+P` → `Developer: Reload Window`)

### Python script fails
- Check dependencies: `pip list | grep -E "pandas|numpy|scipy|matplotlib|pptx"`
- Verify CSV files have required columns
- Ensure CSV files are in workspace root

### No significant correlations found
- Check sample size (minimum 10 per group)
- Verify data quality (no missing values in critical columns)
- Review SIOU endpoint mapping
- Consider recipe-specific effects

### Script execution is slow
- Large datasets (>100 parts) may take 5-10 minutes
- PowerPoint generation is memory-intensive
- Consider filtering to specific endpoints/metrics

---

## Support

**Primary Contact**: Dr. Francisco Rangel (francisco.rangel@intel.com)  
**Second Contact**: Edgar Vega (edgar.vega.ochoa@intel.com)  
**Organization**: Intel Corporation — Electrical Validation (DCG PSE)

**Resources**:
- IPM Wiki: https://wiki.ith.intel.com/spaces/IPMWiki/
- Plugin documentation: [SKILL.md](skills/ev-hvm-sensitivity/SKILL.md)
- Case study: SKILL_pcie_gen6_sensitivity_results.md

---

## Version History

### v1.0.1 (June 2026)
- Generalized for any PCIe Gen6 recipe
- Added required column specifications in welcome message
- Updated documentation
- Tested by several Intel Engineers

### v1.0.0 (June 2026)
- Initial release
- 8-step intelligent part selection methodology
- Statistical correlation analysis (p<0.05, |r|>0.7)
- Wafer spatial mapping
- IPM Wiki guidance integration
- Success rate: 80-90% vs 40-60% (FF/TT/SS)

---

## License

**Intel Internal Use Only**

This agent is an Intel internal tool for post-silicon validation workflows. The methodology is validated for PCIe Gen6 products across different recipes and datasets.

**Important**:
- Correlation results are recipe-specific and endpoint-specific
- Always validate findings with statistical rigor (p<0.05, |r|>0.7)
- Do NOT use IDV as sole indicator without correlation validation
- Prioritize volume over coverage when correlation is weak
- Consult IPM Wiki for process parameter limitations

---

**Ready to replace FF/TT/SS with data-driven part selection!** 🎯
