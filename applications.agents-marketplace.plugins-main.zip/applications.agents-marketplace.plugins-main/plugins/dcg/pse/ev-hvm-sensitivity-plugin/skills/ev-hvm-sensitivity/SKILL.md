# EV-HVM Sensitivity Analysis

**Intelligent part selection for PCIe Gen6 post-silicon validation using validated IDV↔Electrical correlations**

---

## Purpose

This skill enables HVM-to-EV correlation analysis and intelligent part selection for PCIe Gen6 post-silicon validation. It validates statistical correlations between HVM process data (IDV - Intra Die Variation) and electrical performance metrics (tMarginMin, FBER, VOC) to recommend high-value silicon parts, replacing traditional FF/TT/SS selection with data-driven methodology achieving 80-90% success rate vs 40-60% traditional approach.

---

## When to Use

Use this skill when:
- Selecting parts from HVM lot for post-silicon electrical validation
- Analyzing correlation between process parameters (IDV) and electrical performance
- Creating wafer spatial maps to understand process variation
- Validating part selection methodology with statistical rigor
- Replacing traditional FF/TT/SS selection with data-driven approach
- Interpreting PCIe Gen6 sensitivity analysis results
- Applying IPM Wiki guidance for process parameters

---

## Knowledge Base

This skill includes three comprehensive documentation files:

### 1. IDV Part Selection Methodology
**File**: `SKILL_idv_part_selection.md` (19.5 KB)

**Content**:
- **8-Step Methodology** — Complete process from correlation analysis to HVM request
- **Selection Matrix** — Priority levels and criteria
- **HVM Request Templates** — Formatted templates for submission
- **Success Metrics** — 80-90% effectiveness vs 40-60% FF/TT/SS
- **Comparison Tables** — IDV-based vs Traditional selection

**Key Sections**:
- Purpose and Context
- Key Concepts (IDV, FBER, VOC, SIOU mapping, wafer regions)
- 8-Step Methodology with examples
- Selection Matrix (High/Medium/Low priority)
- HVM Request Template
- Validation Workflow
- Comparison: Traditional vs IDV-Based Selection
- Tools Reference

### 2. Process Parameters (IPM Wiki Reference)
**File**: `SKILL_process_parameters_ipm.md` (16.9 KB)

**Content**:
- **Ring Oscillators** — IDV, SMP, UPM definitions and limitations
- **E-Test** — Electrical test parameters and usage guidelines
- **Wafer Location** — Center/Donut/Edge effects
- **APM (Analog Product Measurement)** — Process monitoring
- **Calibration Codes** — IBIAS, VREF guidance

**Critical Quotes**:
> "Volume of parts is more critical than IDV coverage when correlation is weak."

> "Do NOT use IDV as sole indicator for analog IP performance against process."

**Each Section Includes**:
- Description of parameter
- Limitations and constraints
- How to use in EV (Electrical Validation)

### 3. PCIe Gen6 Sensitivity Results (Case Study)
**File**: `SKILL_pcie_gen6_sensitivity_results.md` (8.3 KB)

**Content**:
- **Product Context** — PCIe Gen6 DMR (db1p2a recipe case study)
- **7 Key Observations** — Empirical findings from 17-part dataset
- **Implications for Part Selection** — 7 criteria categories
- **Agent Behavior Guidelines** — 4-phase workflow
- **Output Expectations** — 5 deliverable types

**Example Finding**:
- IDV 006 (Leakage) shows strong correlation (r>0.7, p<0.05) with tMarginMin
- Endpoint-specific patterns (U1 vs U2 different correlation)
- Wafer geography effects on correlation strength

---

## Analysis Scripts

### 1. Correlation Analysis Script
**File**: `scripts/run_hvm_electrical_correlation.py` (118 KB)

**Purpose**: Statistical correlation analysis and visualization

**Inputs**:
- HVM IDV Data CSV: `VISUAL_ID`, `IDV_XXX` tokens, `REGION`, `VID`
- Electrical Performance CSV: `VISUAL_ID`, `tMarginMin`, `FBER`, `vocDH_MINmV`, `vocDM_MINmV`, `vocDL_MINmV`

**Outputs**:
- `pooled_significant_correlations.csv` — Main results (p<0.05, |r|>0.7)
- Chain analysis CSVs — Multi-parameter correlations
- PowerPoint report — ~100+ slides with visualizations
- Pareto charts — Top 35 IDVs per metric
- Scatter plots — Top 5 per metric
- VOC analysis — 3 PAM4 eyes (DH, DM, DL)

**Key Parameters**:
```python
TOP_N_SCATTER = 5
TOP_N_PARETO = 35
MIN_GROUP_SAMPLES = 10
SIGNIFICANCE_THRESHOLD = 0.05
STRONG_CORRELATION_THRESHOLD = 0.7
```

**SIOU Mapping**:
```python
SIOU_TO_SUBSTRUCTURE = {
    "pxp1": "U1", "pxp3": "U1", "pxp4": "U1",
    "pxp9": "U2", "pxp11": "U2", "pxp12": "U2"
}
```

### 2. Wafer Mapping Script
**File**: `scripts/waffer_mapping.py` (12 KB)

**Purpose**: Spatial visualization of VISUAL_ID distribution

**Inputs**:
- HVM IDV Data CSV (same as above)

**Outputs**:
- `wafer_map_two_substructures.png` — Dual panel for U1/U2

**Wafer Regions**:
```python
REGION_COLORS = {
    "Center": "#7FBF7B",  # Green
    "Donut": "#FDB462",   # Orange
    "Edge": "#FB8072"     # Red
}
```

---

## Agent Commands

When invoking the `@ev-hvm-sensitivity` agent, use these commands:

### Run Correlation Analysis
```
@ev-hvm-sensitivity run correlation analysis
```
Executes `run_hvm_electrical_correlation.py` and generates all outputs.

### Create Wafer Maps
```
@ev-hvm-sensitivity create wafer maps
```
Executes `waffer_mapping.py` and visualizes spatial distribution.

### Explain Methodology
```
@ev-hvm-sensitivity explain the 8-step methodology
```
Reviews intelligent part selection process from SKILL_idv_part_selection.md.

### Recommend Parts
```
@ev-hvm-sensitivity recommend high-priority parts from results
```
Analyzes `significant_correlations.csv` and applies selection criteria.

---

## Core Methodology

### Statistical Validation

**Thresholds**:
- **p-value < 0.05** — Statistically significant (reject null hypothesis)
- **|r| > 0.7** — Strong correlation (Pearson coefficient)
- **Minimum 10 samples** — Per group for reliable statistics

**Interpretation**:
- **Strong (|r| > 0.7, p < 0.05)**: Use IDV for part selection with high confidence
- **Moderate (0.5 < |r| < 0.7, p < 0.05)**: Use IDV with volume validation
- **Weak (|r| < 0.5 or p > 0.05)**: Prioritize volume over IDV coverage

### 8-Step Process

1. **Run Correlation Analysis** — Execute `run_hvm_electrical_correlation.py`
2. **Review Significance** — Check `pooled_significant_correlations.csv` for p<0.05, |r|>0.7
3. **Identify Strong IDVs** — Prioritize IDVs with robust correlations
4. **Analyze Spatial Distribution** — Run wafer mapping, consider Center/Donut/Edge
5. **Check Endpoint Coverage** — Ensure U1 and U2 representation
6. **Apply Volume Fallback** — When correlation weak, prioritize volume
7. **Generate Selection Matrix** — Combine criteria (correlation + spatial + endpoint + volume)
8. **Submit HVM Request** — Use template from SKILL_idv_part_selection.md

### Selection Strategy

| Correlation Strength | Selection Strategy |
|---|---|
| Strong (|r| > 0.7, p < 0.05) | IDV-based selection (high confidence) |
| Moderate (0.5 < |r| < 0.7, p < 0.05) | IDV with volume validation |
| Weak (|r| < 0.5 or p > 0.05) | Volume-based selection (ignore IDV) |

---

## Core Principles

### Critical Constraints

❌ **NEVER** select parts based solely on FF/TT/SS process skew  
❌ **NEVER** use IDV as sole indicator without correlation validation  
✅ **ALWAYS** validate IDV↔Electrical correlation statistically first  
✅ **ALWAYS** prioritize volume over IDV coverage when correlation is weak  
✅ **ALWAYS** respect endpoint-specific patterns (U1 vs U2 may differ)

### IPM Wiki Guidance

> **"Volume of parts is more critical than IDV coverage."**  
> When correlation is weak (|r| < 0.5), prioritize getting more parts over spanning IDV range.

> **"Do NOT use IDV as sole indicator for analog IP."**  
> Always validate correlation with post-silicon electrical data before using IDV for selection.

### Endpoint Awareness

**SIOU-to-Substructure Mapping**:
- **U1**: pxp1, pxp3, pxp4
- **U2**: pxp9, pxp11, pxp12

**Implication**: Correlations may be **endpoint-dependent**. An IDV that correlates strongly with tMarginMin for U1 may show weak correlation for U2. Always analyze separately and check pooled results.

---

## Expected Outputs

### Correlation Analysis (`run_hvm_electrical_correlation.py`)

1. **CSV Files**:
   - `pooled_significant_correlations.csv` — Main results
   - `chain_VID_REGION_IDV.csv` — Multi-parameter analysis
   - Per-lane results (if applicable)

2. **Visualizations**:
   - Pareto charts (top 35 IDVs per metric)
   - Scatter plots (top 5 per metric)
   - VOC analysis charts (3 PAM4 eyes)

3. **PowerPoint Report**:
   - ~100+ slides
   - Pooled analysis
   - Per-lane analysis
   - Chain analysis
   - Visualization summary

### Wafer Mapping (`waffer_mapping.py`)

1. **Spatial Visualization**:
   - `wafer_map_two_substructures.png`
   - Dual panel (U1 left, U2 right)
   - Color-coded by region (Center/Donut/Edge)
   - VISUAL_ID labels for each part

---

## Troubleshooting

### No Significant Correlations Found

**Possible Causes**:
- Sample size too small (< 10 per group)
- Data quality issues (missing values, outliers)
- Recipe-specific effects (correlation may not exist for this recipe)
- Endpoint mismatch (SIOU mapping incorrect)

**Actions**:
1. Check sample size per group
2. Review data for missing values
3. Verify SIOU mapping matches your product
4. Consider recipe-specific correlation patterns
5. Apply volume-based fallback per IPM Wiki

### Script Execution Errors

**Common Issues**:
- Missing Python dependencies: `pip install pandas numpy scipy matplotlib python-pptx`
- CSV file format issues: Verify column names match requirements
- File path issues: Ensure CSVs are in workspace root
- Memory errors: Large datasets may require 16GB+ RAM for PowerPoint generation

### Correlation Interpretation

**Q**: IDV shows moderate correlation (r=0.6, p=0.02). Should I use it?  
**A**: Use with caution. Apply volume validation. Consider combining with other criteria (spatial, endpoint).

**Q**: Different endpoints show different correlation strengths. What to do?  
**A**: Analyze separately. Use strong correlation for that endpoint only. Pool only if both show strong correlation.

**Q**: Wafer edge shows stronger correlation than center. Why?  
**A**: Edge has higher process variation, amplifying IDV effects. This is expected. Consider spatial diversity in selection.

---

## Success Metrics

### Part Selection Effectiveness

**IDV-Based Validated Selection**: 80-90% success rate  
**Traditional FF/TT/SS Selection**: 40-60% success rate

**Success Definition**: Parts that reproduce the electrical performance range of interest (e.g., tMarginMin extremes, high FBER, VOC outliers).

### Correlation Validation

**Rigorous Thresholds**: p < 0.05, |r| > 0.7  
**Volume Priority**: When correlation weak (|r| < 0.5), volume > coverage

---

## Version History

**v1.0.1 (June 2026)**:
- Generalized for any PCIe Gen6 recipe
- Added required column specifications
- Updated documentation
- Tested by several Intel Engineers

**v1.0.0 (June 2026)**:
- Initial release
- 8-step methodology
- Statistical validation (p<0.05, |r|>0.7)
- Wafer spatial mapping
- IPM Wiki integration

---

## Support

**Primary Contact**: Dr. Francisco Rangel (francisco.rangel@intel.com)  
**Second Contact**: Edgar Vega (edgar.vega.ochoa@intel.com)  
**Organization**: Intel DCG PSE — Electrical Validation

**Resources**:
- IPM Wiki: https://wiki.ith.intel.com/spaces/IPMWiki/
- SKILL Documentation: This file and referenced SKILL_*.md files
- Python Scripts: `scripts/` directory

---

**Ready to replace guesswork with data-driven part selection!** 🎯
