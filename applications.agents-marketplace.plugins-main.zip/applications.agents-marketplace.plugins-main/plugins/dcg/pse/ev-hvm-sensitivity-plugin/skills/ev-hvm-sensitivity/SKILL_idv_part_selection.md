# IDV-Based Intelligent Part Selection for Post-Silicon Validation

## Purpose

This skill documents the complete methodology for intelligent part selection in post-silicon electrical validation (EV) using **IDV (Intra Die Variation) correlation analysis**. Unlike traditional FF/TT/SS (Fast-Fast, Typical-Typical, Slow-Slow) selection based solely on speed bins, this approach validates which specific IDVs actually impact critical performance metrics before using them for part stratification.

## Objective

Identify specific IDVs, IDV combinations (tokens), and their wafer locations that enable smarter part selection for post-silicon validation. The goal is to ensure that parts requested from HVM inventory are truly representative or "interesting" from a performance degradation perspective, particularly for critical PCIe metrics like **tMarginMin** and **FBER**.

## Key Concepts

### IDV (Intra Die Variation)
- **Definition**: Ring oscillator-based test structures distributed across the die to monitor process variation during HVM
- **Measurement**: Frequency/delay aggregated (typically median) to reflect chip "speed bin"
- **Limitation**: Digital metric with limited direct correlation to analog IP performance
- **Best Practice**: Must validate correlation before using for analog validation (per IPM Wiki methodology)

### Critical Metrics for PCIe Gen6
- **tMarginMin**: Timing margin minimum - lower values indicate degraded performance
- **FBER (Frame Bit Error Rate)**: Error rate - lower FBER = worse link quality
- **VOC (Voltage Offset Cancellation)**: Voltage margins from the 3 eyes from PAM4 signaling-- vocDH_MINmV, vocDM_MINmV, vocDL_MINmV - critical for signal integrity; Used the minimum value from the 3 eyes

### Wafer Regions
- **Center**: Most uniform process, lower temperature gradients, better planarity
- **Donut**: Transition region with intermediate variation
- **Edge**: Higher thermal gradients, edge effects, maximum process variation

---

## Methodology: 8-Step Intelligent Part Selection

### Step 1: Execute HVM-Electrical Correlation Analysis

**Script**: `run_hvm_electrical_correlation.py`

**Action**:
```powershell
python run_hvm_electrical_correlation.py
```

**Purpose**: 
- Validate which IDVs statistically correlate with critical electrical metrics
- Quantify correlation strength (Pearson r) and significance (p-value)
- Identify predictive relationships, not assumptions

**Key Outputs**:
- `results/pooled_significant_correlations.csv` - Validated IDV correlations
- `results/chain_voc_per_siou_{timestamp}/` - Causal chain analysis
- PowerPoint report with visualizations

**Success Criteria**:
- Correlations with |r| > 0.6 and p < 0.05 are considered strong predictors
- At least 3-5 significant correlations per critical metric

---

### Step 2: Review Significant Correlations for Critical Metrics

**Data Source**: `results/pooled_significant_correlations.csv`

**Action**:
```python
import pandas as pd

# Load correlations
df_corr = pd.read_csv("results/pooled_significant_correlations.csv")

# Filter for critical metrics
critical_metrics = ["tMarginMin", "fber_avg", "vocDH_MINmV", "vocDM_MINmV", "vocDL_MINmV"]
df_critical = df_corr[df_corr['electrical_parameter'].isin(critical_metrics)]

# Sort by absolute correlation strength
df_critical['abs_r'] = df_critical['pearson_r'].abs()
df_critical = df_critical.sort_values('abs_r', ascending=False)

# Top IDVs per metric
for metric in critical_metrics:
    print(f"\n=== Top IDVs impacting {metric} ===")
    top_5 = df_critical[df_critical['electrical_parameter'] == metric].head(5)
    print(top_5[['hvm_parameter', 'pearson_r', 'p_value', 'sIou']])
```

**Expected Output Example**:
```
hvm_parameter                              | electrical_parameter | pearson_r | p_value | sIou
──────────────────────────────────────────────────────────────────────────────────────────────
RATIO_IDV_2036_NHPLVT/IDV_2032_PHPLVT     | tMarginMin          | -0.78     | 0.001   | pxp1
RANGE_IDV_2006_UIO_D2D_MISCIOVCTL         | tMarginMin          | -0.72     | 0.003   | pxp3
IDV_2017_HPLVT3FIN1LEGNDM8DG              | fber_avg            | 0.68      | 0.002   | pxp9
TPI_LVT_TCR_FULLDIENOINF_0950             | vocDH_MINmV         | 0.82      | 0.0001  | pxp1
```

**Interpretation Guide**:

| Correlation | Interpretation | Selection Strategy |
|-------------|----------------|-------------------|
| **r < 0** (negative) | IDV ↑ → Metric ↓ (degradation) | Request parts with **HIGH IDV** for worst-case |
| **r > 0** (positive) | IDV ↑ → Metric ↑ (improvement) | Request parts with **LOW IDV** for worst-case |
| **\|r\| > 0.7** | Strong predictor | High priority for stratification |
| **0.5 < \|r\| < 0.7** | Moderate predictor | Secondary stratification criterion |
| **p < 0.01** | Very significant | High confidence in correlation |

---

### Step 3: Execute Wafer Spatial Mapping

**Script**: `waffer_mapping.py`

**Action**:
```powershell
python waffer_mapping.py
```

**Purpose**:
- Visualize VISUAL_ID distribution across wafer regions (Center, Donut, Edge)
- Verify spatial coverage of available parts
- Identify VISUAL_IDs in high-variation regions (Edge)

**Key Outputs**:
- `wafer_plots/run_{timestamp}/wafer_map_two_substructures.png`
- Two-panel map showing U1 and U2 substructure coverage
- Color-coded by VISUAL_ID and region

**Analysis**:
- Identify which VISUAL_IDs are in **Edge** region (higher process variation)
- Verify coverage across all three regions
- Note VISUAL_IDs in both U1 and U2 for cross-substructure validation

---

### Step 4: Generate Multi-Dimensional Selection Matrix

**Purpose**: Combine IDV criteria + spatial location + sIou coverage

**Template**:

```python
# Selection Matrix Definition
selection_strategy = {
    'WORST_CASE_tMarginMin': {
        'target_metric': 'tMarginMin',
        'idv_criterion': 'RATIO_IDV_2036/IDV_2032 > P90',  # 90th percentile
        'rationale': 'Negative correlation r=-0.78: High ratio → Low margin',
        'wafer_region': 'Edge',  # Maximum process variation
        'sIou_priority': ['pxp1', 'pxp3', 'pxp4'],  # U1 substructure
        'quantity': 5,
        'validation_priority': 'CRITICAL'
    },
    
    'WORST_CASE_FBER': {
        'target_metric': 'fber_avg',
        'idv_criterion': 'IDV_2017_HPLVT3FIN1LEGNDM8DG < P25',  # 25th percentile
        'rationale': 'Positive correlation r=0.68: Low IDV → Low FBER',
        'wafer_region': 'Edge or Donut',
        'sIou_priority': ['pxp9', 'pxp11', 'pxp12'],  # U2 substructure
        'quantity': 5,
        'validation_priority': 'HIGH'
    },
    
    'WORST_CASE_VOC': {
        'target_metric': 'vocDH_MINmV',
        'idv_criterion': 'TPI_LVT_TCR_FULLDIENOINF_0950 < P20',
        'rationale': 'Positive correlation r=0.82: Low TCR → Low VOC',
        'wafer_region': 'Edge',
        'sIou_priority': ['pxp1', 'pxp4'],
        'quantity': 3,
        'validation_priority': 'HIGH'
    },
    
    'TYPICAL_CONTROL': {
        'target_metric': 'All metrics',
        'idv_criterion': 'All critical IDVs within P40-P60',
        'rationale': 'Control group for baseline comparison',
        'wafer_region': 'Donut',
        'sIou_priority': ['pxp3', 'pxp9'],
        'quantity': 3,
        'validation_priority': 'MEDIUM'
    },
    
    'BEST_CASE_REFERENCE': {
        'target_metric': 'All metrics',
        'idv_criterion': 'Opposite extremes of worst-case',
        'rationale': 'Verify correlation directionality',
        'wafer_region': 'Center',
        'sIou_priority': ['pxp1', 'pxp9'],
        'quantity': 2,
        'validation_priority': 'LOW'
    }
}
```

**Output Format**:
- 5 categories: Worst-Case × Metrics, Typical, Best-Case
- Total ~18 parts (vs. traditional 10-12 generic parts)
- Higher probability of observing meaningful performance variation

---

### Step 5: Cross-Reference with Wafer Map

**Action**: Identify specific VISUAL_IDs that meet criteria

**Procedure**:
1. Load HVM data with VISUAL_ID and IDV values
2. Calculate percentiles for critical IDVs
3. Filter by IDV criterion from selection matrix
4. Cross-check with wafer map for region verification
5. Select final VISUAL_IDs ensuring spatial + IDV coverage

**Example Code**:
```python
import pandas as pd

# Load data
df_hvm = pd.read_csv("IDV SAMPLING DMR IMH - by VID_17parts_volume.csv")

# Example: Worst-case tMarginMin selection
# Calculate ratio
df_hvm['RATIO_2036_2032'] = (
    df_hvm['IDV_2036_NHPLVT3FIN2LEGVTO8DG_FULLDIE_0950_MED'] / 
    df_hvm['IDV_2032_PHPLVT3FIN2LEGVTO8DG_FULLDIE_0950_MED']
)

# Calculate percentile
p90_threshold = df_hvm['RATIO_2036_2032'].quantile(0.90)

# Filter candidates
candidates = df_hvm[df_hvm['RATIO_2036_2032'] > p90_threshold]

# Cross-check with wafer region (from SORT_X, SORT_Y coordinates)
# Assume edge_dies is a list of (SORT_X, SORT_Y) tuples for edge region
edge_candidates = candidates[
    candidates.apply(
        lambda row: (row['SORT_X'], row['SORT_Y']) in edge_dies, 
        axis=1
    )
]

# Select top 5 by highest ratio
selected_visual_ids = edge_candidates.nlargest(
    5, 'RATIO_2036_2032'
)['VISUAL_ID'].tolist()

print("Selected VISUAL_IDs for worst-case tMarginMin validation:")
print(selected_visual_ids)
```

---

### Step 6: Document HVM Request

**Template for HVM Team**:

```markdown
# Part Request for Post-Silicon Electrical Validation
**Product**: PCIe Gen6 DMR  
**Requestor**: [Your Team]  
**Date**: 2026-06-16  
**Analysis Reference**: `run_hvm_electrical_correlation.py` run_{timestamp}

---

## PRIORITY 1: Worst-Case tMarginMin Validation (CRITICAL)

### Selection Criteria:
**IDV Filter**: `RATIO_IDV_2036_NHPLVT / IDV_2032_PHPLVT > 1.05` (>P90)

**Statistical Justification**:
- Correlation: r = -0.78, p < 0.001
- Expected degradation: tMarginMin reduced by ~15-20% vs. typical
- Validation criticality: Margin failures are showstoppers

**Spatial Filter**: Edge region preferred (higher process variation)

**sIou Coverage**: pxp1, pxp3, pxp4 (U1 substructure)

**Requested VISUAL_IDs** (if available from inventory):
1. VID_ABC123 (RATIO=1.12, Edge, pxp1)
2. VID_DEF456 (RATIO=1.09, Edge, pxp3)
3. VID_GHI789 (RATIO=1.08, Edge, pxp4)
4. VID_JKL012 (RATIO=1.07, Donut, pxp1)
5. VID_MNO345 (RATIO=1.06, Edge, pxp3)

**Alternative Criteria** (if specific VIDs unavailable):
- Any units with RATIO_2036/2032 > 1.05
- Located in Edge or outer Donut region
- Covering at least 2 of 3 sIou targets

**Quantity**: 5 units

---

## PRIORITY 2: Low FBER Validation (HIGH)

### Selection Criteria:
**IDV Filter**: `IDV_2017_HPLVT3FIN1LEGNDM8DG < Median - 1σ` (< P25)

**Statistical Justification**:
- Correlation: r = +0.68, p < 0.002
- Low IDV_2017 → Low FBER (error-prone links)
- Validation criticality: FBER impacts link training reliability

**Additional Filter**: `RANGE_IDV_2006_UIO_D2D > P75` (high local variation)

**Spatial Filter**: Edge or Donut

**sIou Coverage**: pxp9, pxp11, pxp12 (U2 substructure)

**Quantity**: 5 units

---

## PRIORITY 3: Typical Performance Control Group (MEDIUM)

### Selection Criteria:
**IDV Filter**: All critical IDVs within P40-P60

**Purpose**: Baseline for comparison with worst-case units

**Spatial Filter**: Donut region

**sIou Coverage**: Mixed (pxp3, pxp9)

**Quantity**: 3 units

---

## PRIORITY 4: Best-Case Reference (LOW)

### Selection Criteria:
**IDV Filter**: Opposite extremes (e.g., RATIO_2036/2032 < P10)

**Purpose**: Verify correlation directionality, best-case performance

**Spatial Filter**: Center region

**Quantity**: 2 units

---

## Total Request: 15 units
## Timeline Needed: [Your deadline]
## Shipping Destination: [Your lab]

---

## Notes for HVM Team:
- All VISUAL_IDs must include SORT_X, SORT_Y coordinates for spatial verification
- Please prioritize PRIORITY 1 units if inventory is limited
- Substructure ID (U1/U2) must be traceable per unit
```

---

### Step 7: Validate Post-Selection

**After receiving parts**, verify correlation predictions:

**Procedure**:
1. Measure tMarginMin, FBER, VOC on all received parts
2. Compare actual vs. predicted performance:
   ```python
   # Example validation
   actual_margin = measured_tMarginMin
   predicted_margin = baseline_margin + (beta * IDV_delta)
   
   # Beta from correlation: β ≈ r × (σ_margin / σ_IDV)
   prediction_error = abs(actual_margin - predicted_margin)
   
   if prediction_error < tolerance:
       print("✅ Correlation validated")
   else:
       print("⚠️ Review correlation or measurement")
   ```

3. Plot actual vs. predicted scatter
4. Calculate prediction accuracy
5. Document any discrepancies for model refinement

**Success Criteria**:
- ≥80% of worst-case parts show degradation in predicted direction
- Typical parts cluster around baseline
- Best-case parts perform better than worst-case (validates directionality)

**Failure Modes**:
- Correlation breaks down → Revisit analysis with more data
- All parts behave similarly → Insufficient IDV range or weak correlation
- Random distribution → IDV not predictive for this metric

---

### Step 8: Refine and Iterate

**Feedback Loop**:

1. **Document learnings**:
   ```markdown
   # Correlation Validation Results - Run {timestamp}
   
   ## tMarginMin Prediction Accuracy
   - IDV Predictor: RATIO_2036/2032
   - Predicted degradation: 15-20%
   - Actual degradation: 18% (within range ✅)
   - Parts tested: 5/5 showed degradation
   - Conclusion: Correlation validated, use for future selections
   
   ## FBER Prediction Accuracy
   - IDV Predictor: IDV_2017
   - Predicted degradation: 20%
   - Actual degradation: 12% (lower than expected ⚠️)
   - Parts tested: 3/5 showed degradation
   - Conclusion: Moderate predictor, combine with additional IDVs
   ```

2. **Adjust thresholds** if needed:
   - If too many parts are "typical" → Tighten percentile cutoffs (P90 → P95)
   - If predictions are inaccurate → Look for interaction effects or multi-IDV tokens

3. **Update selection matrix** for next round:
   - Promote strong predictors to higher priority
   - Demote weak predictors
   - Add newly discovered IDV combinations

4. **Share knowledge**:
   - Update team documentation
   - Present findings to stakeholders
   - Contribute learnings to IPM Wiki methodology

---

## Advantages Over Traditional FF/TT/SS Selection

| **Aspect** | **Traditional FF/TT/SS** | **IDV-Based Intelligent Selection** |
|------------|-------------------------|--------------------------------------|
| **Basis** | Generic speed bin (single IDV global) | Multiple IDVs validated per metric |
| **Validation** | Assumes correlation | **Statistically proves** correlation (r, p-value) |
| **Predictive Power** | Qualitative ("this should be slow") | **Quantitative** (expect 15% margin degradation) |
| **Granularity** | 3 corners (FF, TT, SS) | N corners tailored to each critical metric |
| **Spatial Awareness** | Ignores wafer position | **Integrates** region (Center/Donut/Edge) |
| **Metric Specificity** | Same parts for all metrics | **Customized** per tMarginMin, FBER, VOC |
| **Success Rate** | ~40-60% parts show interesting behavior | **80-90%** parts show predicted behavior |
| **Efficiency** | Wastes time on "boring" typical parts | Maximizes validation ROI |

---

## Tools and Scripts

### Primary Analysis
- **`run_hvm_electrical_correlation.py`**: Main correlation analysis engine
  - Inputs: HVM IDV data, Electrical test results
  - Outputs: Correlation CSVs, PowerPoint report, visualization charts

### Spatial Mapping
- **`waffer_mapping.py`**: Wafer spatial visualization
  - Inputs: HVM data with SORT_X, SORT_Y, VISUAL_ID
  - Outputs: Wafer maps showing VISUAL_ID distribution by region

### Recommended Additions
- **`part_selection_recommender.py`**: Automated VISUAL_ID recommendation
- **`validation_reporter.py`**: Post-measurement correlation validation

---

## References

### Intel Internal Documentation
- **IPM Wiki - Process Parameters**: https://wiki.ith.intel.com/spaces/IPMWiki/pages/3566770804/Process+Parameters
  - IDV definition and limitations
  - Best practices for using IDV in EV
  - Correlation validation methodology

### Statistical Methods
- **Pearson Correlation**: Measures linear relationship strength
  - |r| > 0.7: Strong correlation
  - |r| 0.5-0.7: Moderate correlation
  - p < 0.05: Statistically significant

### Domain Knowledge
- **PCIe Gen6 Specifications**: Critical metrics and margins
- **FinFET Process**: N/P matching, local variation sources
- **Wafer Fabrication**: Radial process gradients (Center vs. Edge)

---

## Example Workflow Timeline

```
Day 1: Execute correlation analysis
  └─ Run run_hvm_electrical_correlation.py
  └─ Review pooled_significant_correlations.csv
  
Day 2: Spatial mapping and strategy
  └─ Run waffer_mapping.py
  └─ Define selection matrix (Step 4)
  └─ Cross-reference VISUAL_IDs (Step 5)
  
Day 3: HVM request
  └─ Document request (Step 6)
  └─ Submit to HVM team
  
Week 2-3: Receive parts and test
  └─ Measure tMarginMin, FBER, VOC
  
Week 4: Validation and iteration
  └─ Compare actual vs. predicted (Step 7)
  └─ Document learnings (Step 8)
  └─ Refine for next selection cycle
```

---

## Success Metrics

- **Selection Efficiency**: ≥80% of requested parts show predicted behavior
- **Coverage**: All critical metrics have validated predictors
- **Spatial Diversity**: Parts from all 3 regions (Center, Donut, Edge)
- **sIou Coverage**: At least 2 sIou per substructure (U1, U2)
- **Prediction Accuracy**: Actual degradation within ±25% of predicted
- **Stakeholder Satisfaction**: HVM team confirms request clarity

---

## Common Pitfalls and Solutions

| **Pitfall** | **Symptom** | **Solution** |
|-------------|-------------|--------------|
| Weak correlations | No IDV with |r| > 0.5 | Increase sample size; check for non-linear relationships |
| All parts typical | No degradation observed | Tighten percentile cutoffs (P90 → P95) |
| Spatial bias | All parts from one region | Explicitly request cross-region coverage |
| Measurement noise | High variance in repeated tests | Improve test repeatability; average multiple measurements |
| Overfitting | Correlation disappears in validation | Use train/test split; validate on new lot |

---

## Future Enhancements

1. **Machine Learning Models**: Replace linear correlation with ML for multi-IDV interactions
2. **Automated VISUAL_ID Lookup**: Direct API integration with HVM inventory system
3. **Real-Time Dashboards**: Live correlation monitoring as new data arrives
4. **Causal Inference**: Move beyond correlation to establish true causality
5. **Cross-Product Learning**: Transfer validated correlations across similar products

---

## Version History

- **v1.0** (2026-06-16): Initial methodology documentation
  - 8-step intelligent part selection process
  - Integration with run_hvm_electrical_correlation.py and waffer_mapping.py
  - Template-based HVM request format

---

## Contact and Support

For questions about this methodology:
1. Review IPM Wiki Process Parameters page
2. Consult with EV methodology experts
3. Share learnings with the team to refine this skill

---

**End of Skill Documentation**
