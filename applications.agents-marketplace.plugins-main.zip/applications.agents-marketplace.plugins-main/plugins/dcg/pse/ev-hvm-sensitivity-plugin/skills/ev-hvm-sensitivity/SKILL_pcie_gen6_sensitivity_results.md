# Skill: IDV-driven Electrical Sensitivity Knowledge (HVM ↔ EV)

## Purpose
Capture and reuse **observed relationships** between HVM IDVs and electrical behavior (margins, FBER, VOC) to guide intelligent part selection for post-silicon validation.

**This skill documents empirical findings** from PCIe Gen6 analysis. For methodology, see [SKILL_idv_part_selection.md](SKILL_idv_part_selection.md). For theory, see [SKILL_process_parameters_ipm.md](SKILL_process_parameters_ipm.md).

---

## Product Context
**Product**: PCIe Gen6 DMR (db1p2a recipe)  
**Dataset**: 17 parts volume from HVM sampling  
**Analysis Source**: "Electrical parameters sensitivity to HVM process_recipe_db1p2a.pptx" (100+ slides)

---

## Key Observations (from analysis)

### 1. Strong IDV ↔ Electrical Correlations Exist
- Certain IDVs show strong statistical association with:
  - **FBER** (Frame Bit Error Rate)
  - **VOC metrics** (vocDH_MINmV, vocDM_MINmV, vocDL_MINmV)
  - **Margins** (e.g., tMarginMin)
- **Example highlighted**:
  - **IDV 006** (Leakage) shows strong correlation across parts
  - Statistical significance: p < 0.05, |r| > 0.7 (from `run_hvm_electrical_correlation.py`)

---

### 2. Electrical Behavior is Endpoint-Dependent
- Correlation patterns vary across endpoints:
  - **U1 Substructure**: pxp1, pxp3, pxp4
  - **U2 Substructure**: pxp9, pxp11, pxp12
- Each endpoint shows:
  - Different Top-N IDV ↔ Electrical relationships
  - Different sensitivity profiles

**Implication**:
- Part selection must be endpoint-aware
- Cannot generalize findings from one endpoint to another

---

### 3. Pooled vs Per-Lane Differences are Critical
- **Pooled analysis** highlights:
  - Global trends
  - Dominant sensitivities
- **Per-lane analysis** reveals:
  - Local variability
  - Lane-specific degradation mechanisms

**Implication**:
- Both views are required to avoid missing corner cases
- Pooled alone may hide lane-specific failures

---

### 4. IDV → Electrical → VOC Chains Exist
- Clear multi-stage relationships observed:
  - **IDV** influences intermediate electrical parameters
  - These propagate to **VOC metrics** (final performance)
- Chain analysis is essential to understand:
  - Root cause vs observable degradation

**Implication**:
- Must trace indirect pathways, not just direct IDV↔VOC correlations

---

### 5. Wafer Location Matters (Spatial Effects)
- **Edge die behavior** is explicitly identified as important
- Die location must be considered alongside IDVs

**Implication**:
- Combine spatial (wafer map) + process (IDV) data for complete picture

---

### 6. Not All Parts Behave Equally (Outliers Exist)
- Some parts show:
  - Higher correlation strength
  - Larger variation vs population
- These parts require:
  - Explicit comparison against population baseline

**Implication**:
- Flagging outliers is as important as analyzing means

---

### 7. Substructure Context Affects Interpretation
- Need to differentiate:
  - **SUBSTRUCTURE_ID = U1** vs **U2**
- Same IDV may behave differently depending on structure

**Implication**:
- Analyze U1 and U2 separately, then compare

---

## Implications for Part Selection

**A part is considered "interesting" (high-priority for EV) if it satisfies ≥1 criteria:**

### IDV Criteria
- ✅ Exhibits **extreme values** in high-impact IDVs (e.g., IDV 006-like behavior)
- ✅ Lies in a **high-correlation region** (strong IDV ↔ electrical relationship, |r| > 0.7)

### Chain Criteria  
- ✅ Participates in strong **IDV → Electrical → VOC chains**

### Statistical Criteria
- ✅ Shows **abnormal behavior** compared to population (outlier detection)
- ✅ High **correlation strength** with degraded metrics (FBER, margins, VOC)

### Spatial Criteria
- ✅ Located in **critical wafer regions** (e.g., edge die, donut region)

### Endpoint Criteria
- ✅ Belongs to **sensitive endpoints** (based on endpoint-specific correlation analysis)

### Substructure Criteria
- ✅ Flagged behavior in **U1 or U2** substructure context

---

## Agent Behavior Guidelines

**When analyzing a new HVM↔Electrical dataset, execute this workflow:**

### Phase 1: Correlation Discovery
1. **Identify top correlated IDVs per endpoint**
   - Separate analysis for each endpoint (pxp1, pxp3, pxp4, pxp9, pxp11, pxp12)
   - Rank by correlation magnitude |r|
   - Filter by significance (p < 0.05)

2. **Compare pooled vs per-lane results**
   - Generate pooled correlation matrix
   - Generate per-lane correlation matrices
   - Identify discrepancies (global trend vs lane-specific)

### Phase 2: Chain & Pathway Analysis
3. **Detect strong IDV → electrical propagation chains**
   - Map IDV → Intermediate Electrical → VOC pathways
   - Quantify chain strength (multi-stage correlation)
   - Prioritize dominant pathways

### Phase 3: Part Flagging
4. **Flag high-priority parts** with:
   - High correlation strength (|r| > 0.7)
   - Outlier behavior (statistical deviation from population)
   - Extreme IDV values in validated high-impact parameters

### Phase 4: Context Integration
5. **Consider structure context**
   - Separate analysis for U1 vs U2 substructures
   - Cross-reference sIOu → SUBSTRUCTURE_ID mapping

6. **Include spatial (wafer) awareness** when available
   - Overlay wafer map data (Center/Donut/Edge)
   - Flag edge die or problematic wafer regions

---

## Output Expectations

**The agent should produce structured analysis deliverables:**

### 1. Key IDVs Report
**Format**: Ranked list per endpoint
```
Endpoint: pxp1 (U1)
Top IDVs:
  1. IDV_006 (Leakage) - r=0.85, p<0.001
  2. IDV_XXX (...) - r=0.78, p<0.002
  ...
```
- Highlight **recurring high-impact IDVs** across endpoints
- Note **endpoint-specific IDVs** (unique to one endpoint)

### 2. Critical Relationships Matrix
**Format**: Correlation heatmap or table
- Strong **HVM ↔ electrical links** (|r| > 0.7, p < 0.05)
- **Chain dependencies**: IDV → Electrical → VOC
  ```
  IDV_006 → Leakage → vocDH_MINmV (chain strength: 0.82)
  ```

### 3. High-Value Parts List
**Format**: Ranked candidate parts for EV
```
VISUAL_ID | Endpoint | IDV_006 | tMarginMin | FBER | Priority | Reason
----------|----------|---------|------------|------|----------|--------
VID_XXX   | pxp11    | 3.2σ    | -15mV      | 1e-6 | HIGH     | Edge die + extreme IDV_006
...
```
- Parts likely to degrade **margins**
- Parts likely to degrade **FBER**
- Parts with **extreme VOC** behavior

### 4. Interpretation Notes
**Format**: Structured summary
- **Endpoint-specific insights**
  - Which endpoints are most sensitive?
  - Which show unique correlation patterns?
- **Pooled vs Per-Lane Analysis**
  - Key differences identified
  - Corner cases revealed by per-lane analysis
- **Substructure Comparison**
  - U1 vs U2 behavioral differences
  - Recommendations for each substructure

### 5. Visualization Outputs
- **Pareto charts**: Top-N IDV correlations
- **Scatter plots**: IDV vs Electrical (top 5)
- **Wafer maps**: Spatial distribution of flagged parts
- **Chain diagrams**: IDV → Electrical → VOC pathways

---

## Key Takeaway

Electrical performance degradation in PCIe is strongly linked to specific IDVs, their interactions, and spatial/structural context—not just global skew categories. Effective post-silicon validation requires targeting these high-sensitivity regions in the HVM parameter space.

---

## Related Skills & Tools

### Skills
- **[SKILL_idv_part_selection.md](SKILL_idv_part_selection.md)**: 8-step methodology for implementing intelligent part selection
- **[SKILL_process_parameters_ipm.md](SKILL_process_parameters_ipm.md)**: IPM Wiki theory on why IDV correlation validation is critical

### Analysis Tools
- **run_hvm_electrical_correlation.py**: Generates correlation analysis (pooled, per-lane, chain, Pareto)
- **waffer_mapping.py**: Spatial visualization of VISUAL_ID across wafer regions

### Statistical Thresholds (from run_hvm_electrical_correlation.py)
- **Significance**: p < 0.05
- **Strong correlation**: |r| > 0.7
- **Min group samples**: 10
- **Top scatter plots**: 5
- **Top Pareto**: 35

---

## Document History
- **Created**: 2026-06-16 (with Copilot 365)
- **Source**: Electrical parameters sensitivity to HVM process_recipe_db1p2a.pptx
- **Last Updated**: 2026-06-16