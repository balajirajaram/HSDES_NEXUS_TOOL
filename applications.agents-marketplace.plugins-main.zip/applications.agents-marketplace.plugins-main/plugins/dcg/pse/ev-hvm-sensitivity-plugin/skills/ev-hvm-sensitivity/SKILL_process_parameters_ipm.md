# Process Parameters for Electrical Validation (IPM Wiki)

**Source**: Intel IPM Wiki - Process Parameters Documentation  
**Purpose**: Reference guide for understanding process parameters (IDV, E-Test, Wafer Location, APM, Calibration Codes) and their limitations for electrical validation (EV) of analog IPs.

---

## 🎯 Key Takeaway

**CRITICAL**: Currently for most IOs, there is **NOT** a single parameter or set of parameters you can identify up front, test, and guarantee adequate process coverage.

---

## 📋 Table of Contents

1. [Ring Oscillators (IDV, SMP, UPM)](#ring-oscillators)
2. [E-Test Structures](#e-test-structures)
3. [Wafer Location](#wafer-location)
4. [Analog Process Monitors (APM)](#analog-process-monitors)
5. [Calibration Codes](#calibration-codes)
6. [Unified Process Monitor (UPM)](#unified-process-monitor)
7. [General Recommendations](#general-recommendations)

---

## 1. Ring Oscillators (IDV, SMP, UPM) {#ring-oscillators}

### Description

**IDV (Intra Die Variation)**, **SMP (Speedmon-Plus)**, and similar process monitors are test structures containing **ring oscillators** that reflect the propagation speed of digital signals.

#### Architecture
- **Ring Oscillator**: Odd number of inverting CMOS logic gates in series, with output of last gate connected to first
- **Array Integration**: Multiple oscillators placed across die, outputs muxed to singular measurement point
- **Measurement Location**: Collected at SORT test (lot, wafer, die level)

#### Key Performance Metrics
- **Frequency** (or per-stage delay) - primary metric
- **Active Power** - usually scribeline only
- **Standby Power** - usually scribeline only

### Key Definitions

| Term | Definition | Example |
|------|------------|---------|
| **Oscillator** | Single ring oscillator structure made up of common stages or cells | - |
| **Aries Number** | Unique numerical identifier for an oscillator | "x104" oscillator in 10nm/7nm nodes |
| **Fublet** | Schematic circuit containing configuration of oscillators | SPR C0: 454MIF fublet had 46 ring oscillators |
| **Template** | Physical layout of a fublet (can have multiple template cells) | Horizontal vs. vertical IDV layout |
| **Instance** | Unique X,Y placement of a template in the die | Each dot in die diagram |
| **Chain** | Group of instances of template cells | SPR XCC: 1 chain (blue) = 4 instances, another (green) = 25 instances |

#### ⚠️ CRITICAL: Chain Aggregation Impact

**Only chain median value and standard deviation available in SORT databases.**

**Example from SPR DDR IDV Chain Analysis:**
- **MCDDRMEECH1**: 4 oscillators → Max range 1.6σ, Median 0.5σ
- **MCDDRMEECH2**: 14 oscillators → Max range 2.1σ, Median 0.9σ  
- **MCDDRMEECH3**: 27 oscillators → Max range 2.6σ, Median 1.1σ

**Implication**: A part reported as "1F part" (chain median) may have ring oscillator at 2.5F → **1.5σ error**  
⚠️ Calling a part "3F part" is an **over-generalization**.

### IDV FEM (Front End Metric)

**Purpose**: Provide more realistic reflection of all standard cells in technology

**Method**: Aggregates multiple ring oscillator frequencies into single metric
- **Nominal Target**: FEM = 1.0
- **Scaling**: Individual IDVs normalized by nominal targets, assigned weights
- **Example (PTL)**: 4 oscillators → INV 2leg, INV 4leg, NAND 2leg, NOR 2leg (each weighted 0.25)

### Limitations

#### ❌ 1. Correlation to Analog Performance

While IDV structures accurately reflect **digital switching behavior**, they are **inaccurate** for analog circuits due to:

1. **Calibration/Training Algorithms**: PHYs calibrate out process effects
2. **Layout Differences**: Critical devices in IO may not match ring oscillators
   - Number of fins (1-3 in IDV vs. "wide-z" layouts in analog)
   - Fill patterns and dummy cells (impact stress, dopant activation)
   - Parasitics (vias, interconnect width/spacing, gate extension)
3. **Local Variation**: Close-proximity mismatch between IDV and circuit transistors
4. **Aggregate Interaction**: IO margin = result of subcircuits + channel + endpoint device interaction

**Evidence from SPR PCIe HSPHY:**
- **Voltage Margin (PPV FOM) vs IDV**: NO strong correlation
- **SMV Calibration Code vs IDV**: STRONG correlation (expected - PHY calibrates out process)

#### ❌ 2. Variation and Aggregation

- **Ring Oscillator**: Averages delay across stages → **local variation averaged out**
- **SORT Data**: Reports **chain median** → **second level of aggregation**
- **Result**: Significant local variation hidden in reported values

### ✅ How to Use in EV

**⚠️ DO NOT use IDV as sole indicator for analog IP performance.**

**Recommended Methodology:**
1. **Collect Post-Silicon Data**: HVM, DV, EV measurements
2. **Statistical Correlation Analysis**: Look for correlations to performance metrics
3. **Conditional Selection**: Select units based on IDV **ONLY IF correlation found**
4. **Prioritize Volume**: **Volume of parts > IDV coverage**

**Key Quote from IPM Wiki:**
> "Volume of parts is more critical than IDV coverage."

---

## 2. E-Test Structures {#e-test-structures}

### Description

E-Test structures measure **fundamental transistor, passive, and interconnect characteristics**.

**Key Advantage over IDV**: Target individual transistors (not aggregated stages)  
**Relevance**: Directly correlate to circuit process sensitivities for analog designs

### E-Test Parameters

| Parameter | Description | Definition |
|-----------|-------------|------------|
| **V<sub>T</sub>** | **Threshold Voltage** - Gate voltage at transistor transition from "off" to "on" | Correlates to off-state leakage and on-state drive strength |
| **g<sub>m</sub>** | **Transconductance** - Transistor gain | ΔI<sub>DS</sub> / ΔV<sub>GS</sub> |
| **I<sub>DEFF</sub>** | **Effective Drive Current** - Switching strength | (I<sub>HI</sub> + I<sub>LO</sub>) / 2 |
| **I<sub>DSAT</sub>** | **Saturation Drive Current** | I<sub>DS</sub> @ V<sub>GS</sub>=VDD, V<sub>DS</sub>=VDD |
| **I<sub>DLIN</sub>** | **Linear Drive Current** | I<sub>DS</sub> @ V<sub>GS</sub>=VDD, V<sub>DS</sub>=50mV |
| **I<sub>OFF</sub>** | **Channel Leakage Current** - Off-state | I<sub>DS</sub> @ V<sub>GS</sub>=0, V<sub>DS</sub>=VDD |
| **R<sub>O</sub>** | **Output Resistance** - Intrinsic output impedance | ΔV<sub>DS</sub> / ΔI<sub>DS</sub> @ fixed V<sub>GS</sub> |

### Placement and Measurement

- **Location**: Scribeline between dies (destroyed when wafer is cut)
- **Coverage**: 1 E-test structure per reticle (reticle can contain 1 or multiple dies)
- **Measurement Sites**: 
  - Intel: 20 standard locations per wafer
  - External foundries: 9-13 locations per wafer
- **Limitation**: Subset of standard sites only (not full wafer)

### Limitations

#### ❌ 1. Proximity

- **Scribeline placement**: Distant from most IPs
- **One instance per reticle**: Limited area coverage
- **Multiple dies per reticle**: E-test may be far from specific die IP

**Rule**: E-test structures will **NOT be proximal to IP**

#### ❌ 2. Local Variation

**Layout Sensitivities:**
- **Fin Count**: E-test (1-3 fins) vs. Analog "wide-z" (many fins in parallel)
- **Transistor Stacking**: S/D connection sharing impacts stress effects
- **Topology Mismatch**: Scribeline topology ≠ die interior topology

**Result**: Layout and topology differences introduce **inaccuracy**

### ✅ How to Use in EV

**NOT recommended for part selection or process coverage metric** due to:
- Limited measurement structures
- Distance from PHY
- Layout sensitivity differences

**Recommended Uses:**
1. **Review TD Reports**: Monitor E-test data to assess process performance vs. expectations
2. **Post-Silicon Correlation (Low Success Rate)**: 
   - As HVM data collected, look for correlations
   - ⚠️ **Likelihood of success is LOW**
   - Must reduce analysis to die/PHY **closest to measured E-test locations**

---

## 3. Wafer Location {#wafer-location}

### Description

**Process variation across wafer is NOT uniform.**

**Typical Pattern:**
- **Center**: Fast process (spot in middle)
- **Edge**: Slowest process
- **Cause**: Wafer manufacturing processes create different signatures

### Limitations

#### ❌ Correlation to Analog Performance

**Same limitations as IDV section apply:**
- Die location influences process
- **Difficult to predict** if location impacts IO performance

### ✅ How to Use in EV

**⚠️ Cannot assume coverage from testing couple of wafer locations** - too much variation, especially with smaller dies.

**Recommended Methodology (Same as IDV):**
1. **Collect Post-Silicon Data**: HVM, DV, EV
2. **Look for Correlations**: Performance metrics vs. wafer location
3. **Conditional Selection**: Select units based on location **ONLY IF correlation found**
4. **Prioritize Volume**: **Volume of parts > wafer location coverage**

---

## 4. Analog Process Monitors (APM) {#analog-process-monitors}

### Description

**APMs introduced to address E-test and IDV shortfalls.**

**Key Goals:**
1. Monitor process shift/excursion impacts on **3 key analog parameters**: V<sub>t</sub>, G<sub>m</sub>, R<sub>out</sub>
2. **Within-IP measurement** for each die (addresses E-test proximity gap)
3. Enable better **simulation-to-silicon correlation** for debug

### Architecture

- **Sensors**: V<sub>t</sub>, G<sub>m</sub>, R<sub>out</sub> generate voltages
- **ADC**: Digitizes voltages into frequency read-out
- **Infrastructure**: Leverages legacy IDV test infrastructure
- **Measurement**: SORT test (frequency converted back to analog parameters post-test)

### Current Status

- **Placement**: Intel IPs only
- **Integration**: Starting 1278 process, can be part of UPM (no product requirement)
- **Data Maturity**: New technology - limited example data available

### Limitations

#### ❌ 1. Correlation to Analog Performance

**Despite better analog indication than IDV, still likely NO direct correlation** due to:

1. **Calibration/Training**: Adjusts for process dependency/sensitivity
2. **Layout Mismatch**: Critical IO devices may not match APM layout
3. **Local Variation**: Mismatch between APM transistors and circuit transistors
4. **Aggregate Interaction**: IO margin = subcircuits + channel + endpoint device

#### ❌ 2. Variation and Aggregation

**Same limitations as IDV:**
- Single value for chain reported
- Large variations possible within chain
- See IDV section for detailed examples

### ✅ How to Use in EV

**While APMs provide better analog metric, complexity still prevents single-parameter prediction.**

**Recommended Methodology (Same as IDV):**
1. **Collect Post-Silicon Data**: HVM, DV, EV
2. **Look for Correlations**: Performance metrics vs. APM parameters
3. **Conditional Selection**: Select units **ONLY IF correlation found**
4. **Prioritize Volume**: **Volume of parts > APM coverage**

---

## 5. Calibration Codes {#calibration-codes}

### Description

Modern IOs contain **calibration/adaptation circuits** for process, voltage, temperature, channel loss, etc.

**Common Example**: **RCOMP (Resistor Compensation)**
- **Goal**: Calibrate IO resistance block to target, removing PVT variations
- **Example**: Calibrate R<sub>term</sub> to 50Ω

**Note**: No standard - each PHY design has own calibration circuits

### Limitations

#### ❌ Correlation to Analog Performance

**In perfect world**: Calibration removes variation → **no performance impact**

**Reality**: 
- Complex IO design-to-process interactions
- Multiple calibrations/adaptations interact
- **Difficult to predict pre-silicon** which calibration to part-select on
- Only evident from **post-silicon data analysis**

### ✅ How to Use in EV

**Two Recommended Uses:**

#### 1. Correlation-Based Selection
- Look for correlations to performance metrics (HVM, DV, EV)
- Select units **ONLY IF correlation found**

#### 2. Calibration Limit Analysis
- Look for correlations between calibration codes and process parameters
- **IF correlation found**:
  - Analyze if calibration circuit **reaching limits** or **could reach limits** over POR process range
  - **IF risk identified**:
    - Test parts at these limits for EV impact
    - Work with design team to understand risk
  
**⚠️ Important**: Correlation to process ≠ need to select parts. Only test if **risk identified**.

---

## 6. Unified Process Monitor (UPM) {#unified-process-monitor}

### Description

**Transition from IDV and SMP to UPM.**

**Goal**: Single on-die monitor solution for internal and external processes

**Future Integration**: May integrate APMs (no current product intercept known)

### Guidance

**Refer to IDV/SMP section** for detailed methodology - same principles apply.

**Resources:**
- DTTC Paper: [SharePoint Link](https://intel.sharepoint.com/sites/DTTCJournal/_layouts/15/Embed.aspx?UniqueId=3ba52d55-5f51-4f69-ba8a-ba901d73c79d)
- UPM HAS: [Integration Guide](https://intel.sharepoint.com/:b:/r/sites/csgnovalake/Shared%20Documents/DFX/NVL%20PCD-S/Integration/NVL%20PCD-S/Integration/Integration%20Guide/RTL0p5/IDV/DFx_UPM_rev1p1_FV_HAS_16019628455_444.pdf)
- DFX Wiki: [https://wiki.ith.intel.com/display/DTEG/DFx_UPM](https://wiki.ith.intel.com/display/DTEG/DFx_UPM)

---

## 7. General Recommendations {#general-recommendations}

### ✅ Universal EV Methodology for Process Parameters

**ALL process parameters (IDV, E-Test, Wafer Location, APM, Calibration Codes) follow same guidance:**

#### Step 1: Collect Post-Silicon Data
- **Sources**: HVM (High Volume Manufacturing), DV (Design Validation), EV (Electrical Validation)
- **Volume**: Prioritize large sample sizes over targeted parameter coverage

#### Step 2: Statistical Correlation Analysis
- **Correlate**: Process parameters ↔ Electrical performance metrics
- **Statistical Rigor**: Use Pearson correlation, p-values, significance thresholds
- **Example Tools**: Python scripts like `run_hvm_electrical_correlation.py`

#### Step 3: Conditional Part Selection
- **IF correlation found (|r| > 0.7, p < 0.05)**: Select parts based on parameter
- **IF NO correlation**: Do NOT use parameter for selection

#### Step 4: Prioritize Volume
- **Volume of parts > Parameter coverage**
- **Traditional FF/TT/SS**: 40-60% effectiveness
- **Validated parameter-based**: 80-90% effectiveness (when correlation exists)

### ❌ What NOT to Do

1. **DO NOT use any single parameter as sole indicator** for analog IP performance
2. **DO NOT assume coverage** from limited sampling (e.g., few wafer locations, chain medians)
3. **DO NOT generalize parts** (e.g., "3F part" ignores local variation)
4. **DO NOT skip correlation validation** before part selection

### ⚠️ Key Limitations to Remember

#### Why Process Parameters ≠ Analog Performance

1. **Calibration/Training**: PHYs designed to calibrate out process effects
2. **Layout Differences**: Test structures ≠ actual circuit layouts
3. **Local Variation**: Averaging/aggregation hides critical variation
4. **Aggregate Interactions**: IO margin depends on multiple subcircuits + channel + endpoint

#### Data Aggregation Hiding Variation

- **Ring Oscillators**: Average delay across stages
- **Chains**: Median of multiple instances
- **Result**: Reported values may not reflect actual worst-case variation in die

### 📊 IPM Wiki Key Quote Summary

> **"The key takeaway from this section is that in general an IDV like parameter should not be used as a sole indicator for an analog IP's performance against process. There is just too much complexity and variation so if validation is based solely on IDV coverage (e.g., 3S and 3F) you will most likely miss issues."**

> **"Therefore, the recommended method for using IDV like parameters in EV is to look for correlations to performance metrics based on post-si data (HVM, DV, and EV) and then select units only if one is found. Volume of parts is more critical than IDV coverage."**

---

## 📚 Related Skills

- **SKILL_idv_part_selection.md**: 8-step intelligent part selection methodology using validated IDV correlations
- **run_hvm_electrical_correlation.py**: Statistical correlation validation script
- **waffer_mapping.py**: Spatial visualization of wafer geography

---

## 🔗 Additional Resources

- **E-Test UPF Coverage**: [SharePoint Presentation](https://intel.sharepoint.com/:p:/r/sites/IPM_WG/Shared%20Documents/Reference%20Documents/Unit%20Selection/E-test%20based%20UPF%20coverage.pptx)
- **Ring Oscillator Reference**: [Wikipedia - Ring Oscillator](https://en.wikipedia.org/wiki/Ring_oscillator)
- **Transistor Fundamentals**: [Prof. Lundstrom YouTube Series](https://www.youtube.com/playlist?list=PLtkeUZItwHK6F4a4OpCOaKXKmYBKGWcHi) (nanohubtechtalks)

---

**Last Updated**: 2026-06-16  
**Source Document**: Process Parameters_IPMwiki.doc (Confluence Export)  
**Maintained By**: Dr. Rangel - EV HVM Sensitivity Agent Project
