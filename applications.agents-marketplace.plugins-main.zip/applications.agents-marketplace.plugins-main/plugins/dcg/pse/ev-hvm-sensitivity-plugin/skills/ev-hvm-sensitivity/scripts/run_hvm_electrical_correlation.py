﻿# -*- coding: utf-8 -*-
import pandas as pd
import numpy as np
from scipy.stats import pearsonr
import os
import matplotlib.pyplot as plt
from datetime import datetime

# Plot controls (mirrors volume_analysis_margin_gen6.py style)
TOP_N_SCATTER = 5
TOP_N_PARETO = 35
SCATTER_DPI = 160
RUN_TS = datetime.now().strftime("%Y%m%d_%H%M%S")
GENERATE_POWERPOINT_REPORT = True
PPT_REPORT_NAME_TEMPLATE = "correlation_report_by_siou_{run_ts}.pptx"

# HVM feature selection mode:
# - "script": use the script-defined IDV list below
# - "csv": use all HVM columns from CSV whose name starts with "IDV"
HVM_PARAM_SOURCE = "script"

# Used when HVM_PARAM_SOURCE == "script"
SCRIPT_IDV_PREFIXES = [
    "IDV_2006_HPLVT3FIN2LEGNES8DG_FULLDIE_0950_MED",
    "IDV_2017_HPLVT3FIN1LEGNDM8DG_FULLDIE_0950_MED",
    "IDV_2018_HPLVT3FIN1LEGPDM8DG_FULLDIE_0950_MED",
    "IDV_2032_PHPLVT3FIN2LEGVTO8DG_FULLDIE_0950_MED",
    "IDV_2036_NHPLVT3FIN2LEGVTO8DG_FULLDIE_0950_MED",
    "IDV_2049_HPLVT3FIN8LEGPLK8DG_FULLDIE_0950_MED",
    "IDV_2051_HPLVT3FIN2LEGNLK8DG_FULLDIE_0950_MED",
]

# Per-group analysis controls
GROUP_COLS = ["Endpoint", "sIou", "nIouLane"]
MIN_GROUP_SAMPLES = 10           # need at least N rows in a group to compute corr
DEDUPE_CORR_THRESHOLD = 0.999    # cluster electrical cols whose |r| >= this
SIOU_TO_SUBSTRUCTURE = {
    "pxp1": "U1",
    "pxp3": "U1",
    "pxp4": "U1",
    "pxp9": "U2",
    "pxp11": "U2",
    "pxp12": "U2",
}

def find_col(df, prefix):
    cols = [c for c in df.columns if c.startswith(prefix)]
    if not cols:
        raise ValueError(f"Prefix not found: {prefix}")
    return cols[0]

def find_col_any(df, prefixes, feature_name):
    """Try prefixes in order and return the first match and matched prefix."""
    for p in prefixes:
        cols = [c for c in df.columns if c.startswith(p)]
        if cols:
            return cols[0], p
    pref_list = ", ".join(prefixes)
    raise ValueError(f"Required HVM feature '{feature_name}' not found. Tried prefixes: {pref_list}")


def select_direct_idv_columns(df_hvm, source_mode):
    """Select direct IDV columns based on configured source mode."""
    mode = str(source_mode).strip().lower()

    if mode == "script":
        cols = [find_col(df_hvm, p) for p in SCRIPT_IDV_PREFIXES]
        # Preserve order while removing duplicates
        cols = list(dict.fromkeys(cols))
        return cols

    if mode == "csv":
        cols = sorted(c for c in df_hvm.columns if str(c).startswith("IDV"))
        if not cols:
            raise ValueError("No HVM columns starting with 'IDV' were found.")
        return cols

    raise ValueError(
        f"Invalid HVM_PARAM_SOURCE='{source_mode}'. Use 'script' or 'csv'."
    )


def _extract_key(filename, prefix, suffix):
    if not filename.startswith(prefix) or not filename.endswith(suffix):
        return None
    return filename[len(prefix):-len(suffix)]


def _collect_ppt_assets(results_dir, run_ts):
    """Discover per-sIou image assets produced by this run."""
    dirs = {
        'pooled_pareto': os.path.join(results_dir, f"pooled_pareto_per_siou_{run_ts}"),
        'pooled_top10': os.path.join(results_dir, f"pooled_per_siou_top10_{run_ts}"),
        'pooled_voc': os.path.join(results_dir, f"pooled_voc_per_siou_{run_ts}"),
        'lane_voc': os.path.join(results_dir, f"voc_per_siou_{run_ts}"),
    }

    assets = {}

    def _ensure(siou_key):
        assets.setdefault(siou_key, {
            'pooled_pareto': None,
            'pooled_top10_part1': None,
            'pooled_top10_part2': None,
            'pooled_voc': None,
            'lane_voc': None,
            'chain_analysis': None,
        })
        return assets[siou_key]

    # pooled pareto: pooled_pareto_<siou>.png
    d = dirs['pooled_pareto']
    if os.path.isdir(d):
        for fn in os.listdir(d):
            key = _extract_key(fn, "pooled_pareto_", ".png")
            if key:
                _ensure(key)['pooled_pareto'] = os.path.join(d, fn)

    # pooled top10 parts: pooled_siou_top10_<siou>_part1.png / part2
    d = dirs['pooled_top10']
    if os.path.isdir(d):
        for fn in os.listdir(d):
            if not fn.endswith(".png"):
                continue
            stem = fn[:-4]
            prefix = "pooled_siou_top10_"
            if not stem.startswith(prefix) or "_part" not in stem:
                continue
            rhs = stem[len(prefix):]
            siou_key, part = rhs.rsplit("_part", 1)
            if part in ("1", "2"):
                _ensure(siou_key)[f'pooled_top10_part{part}'] = os.path.join(d, fn)

    # pooled voc: pooled_voc_<siou>.png
    d = dirs['pooled_voc']
    if os.path.isdir(d):
        for fn in os.listdir(d):
            key = _extract_key(fn, "pooled_voc_", ".png")
            if key:
                _ensure(key)['pooled_voc'] = os.path.join(d, fn)

    # per-lane voc: voc_<siou>.png
    d = dirs['lane_voc']
    if os.path.isdir(d):
        for fn in os.listdir(d):
            key = _extract_key(fn, "voc_", ".png")
            if key:
                _ensure(key)['lane_voc'] = os.path.join(d, fn)

    # chain analysis: chain_voc_<siou>.png
    chain_dir = os.path.join(results_dir, f"chain_voc_per_siou_{run_ts}")
    if os.path.isdir(chain_dir):
        for fn in os.listdir(chain_dir):
            key = _extract_key(fn, "chain_voc_", ".png")
            if key:
                _ensure(key)['chain_analysis'] = os.path.join(chain_dir, fn)

    return assets


def _read_siou_endpoint_context(results_dir, siou_keys):
    """Build display labels with original sIou text and endpoint list."""
    def _normalize_key(value):
        text = str(value)
        return ''.join(ch if ch.isalnum() else '_' for ch in text)

    context = {
        k: {
            'siou_display': k,
            'endpoint_display': 'N/A',
            'siou_endpoint_label': f"{k}: N/A",
        }
        for k in siou_keys
    }

    pooled_csv = os.path.join(results_dir, "pooled_significant_correlations.csv")
    if not os.path.isfile(pooled_csv):
        return context

    try:
        df = pd.read_csv(pooled_csv)
    except Exception:
        return context

    required = {'sIou', 'Endpoint'}
    if not required.issubset(df.columns):
        return context

    df = df[['sIou', 'Endpoint']].dropna().copy()
    if df.empty:
        return context

    df['siou_key'] = df['sIou'].astype(str).map(_normalize_key)
    df['siou_display'] = df['sIou'].astype(str)
    df['endpoint_display'] = df['Endpoint'].astype(str)

    for siou_key in siou_keys:
        sub = df[df['siou_key'] == siou_key]
        if sub.empty:
            continue

        siou_display = sub['siou_display'].value_counts().index[0]
        endpoints = sorted(sub['endpoint_display'].unique().tolist())
        endpoint_text = ", ".join(endpoints)
        if len(endpoint_text) > 70:
            endpoint_text = ", ".join(endpoints[:3]) + f", +{len(endpoints) - 3} more"

        context[siou_key] = {
            'siou_display': siou_display,
            'endpoint_display': endpoint_text,
            'siou_endpoint_label': f"{siou_display}: {endpoint_text}",
        }

    return context


def _ppt_add_section_slide(prs, siou_endpoint_label, run_ts):
    from pptx.util import Inches, Pt
    from pptx.enum.text import PP_ALIGN

    slide = prs.slides.add_slide(prs.slide_layouts[6])
    w = prs.slide_width

    title_box = slide.shapes.add_textbox(Inches(0.6), Inches(2.0), w - Inches(1.2), Inches(1.2))
    p = title_box.text_frame.paragraphs[0]
    p.text = f"sIou: Endpoint = {siou_endpoint_label}"
    p.font.size = Pt(36)
    p.font.bold = True
    p.alignment = PP_ALIGN.CENTER

    sub_box = slide.shapes.add_textbox(Inches(0.6), Inches(3.2), w - Inches(1.2), Inches(0.8))
    p2 = sub_box.text_frame.paragraphs[0]
    p2.text = f"Correlation Report Run: {run_ts}"
    p2.font.size = Pt(16)
    p2.alignment = PP_ALIGN.CENTER


def _ppt_add_image_slide(prs, title, image_path):
    from pptx.util import Inches, Pt

    slide = prs.slides.add_slide(prs.slide_layouts[6])
    slide_w = prs.slide_width
    slide_h = prs.slide_height

    # Title area
    title_box = slide.shapes.add_textbox(Inches(0.4), Inches(0.15), slide_w - Inches(0.8), Inches(0.55))
    p = title_box.text_frame.paragraphs[0]
    p.text = title
    p.font.size = Pt(20)
    p.font.bold = True

    # Image area (preserve aspect ratio)
    margin = Inches(0.35)
    top = Inches(0.85)
    max_w = slide_w - 2 * margin
    max_h = slide_h - top - margin

    pic = slide.shapes.add_picture(image_path, 0, 0)
    ratio = min(float(max_w) / pic.width, float(max_h) / pic.height)
    pic.width = int(pic.width * ratio)
    pic.height = int(pic.height * ratio)
    pic.left = int((slide_w - pic.width) / 2)
    pic.top = int(top + (max_h - pic.height) / 2)


def generate_siou_powerpoint_report(results_dir, run_ts):
    """Create integrated PowerPoint report with one section per sIou."""
    if not GENERATE_POWERPOINT_REPORT:
        print("PowerPoint report generation disabled by config.")
        return None

    try:
        from pptx import Presentation
    except Exception:
        print("PowerPoint report skipped: python-pptx is not installed.")
        print("Install with: pip install python-pptx")
        return None

    assets = _collect_ppt_assets(results_dir, run_ts)
    if not assets:
        print("PowerPoint report skipped: no matching per-sIou chart assets found.")
        return None

    prs = Presentation()
    siou_keys = sorted(assets.keys())
    siou_context = _read_siou_endpoint_context(results_dir, siou_keys)
    missing_summary = {}

    for siou_key in siou_keys:
        entry = assets[siou_key]
        ctx = siou_context[siou_key]
        siou_endpoint_label = ctx['siou_endpoint_label']
        missing = []

        _ppt_add_section_slide(prs, siou_endpoint_label, run_ts)

        # Required slides
        if entry['pooled_pareto']:
            _ppt_add_image_slide(
                prs,
                f"sIou: Endpoint = {siou_endpoint_label} | Pooled Pareto",
                entry['pooled_pareto']
            )
        else:
            missing.append('pooled_pareto')

        if entry['pooled_top10_part1']:
            _ppt_add_image_slide(
                prs,
                f"sIou: Endpoint = {siou_endpoint_label} | Pooled Top10 HVM-Electrical (Part 1)",
                entry['pooled_top10_part1']
            )
        else:
            missing.append('pooled_top10_part1')

        # Optional part2
        if entry['pooled_top10_part2']:
            _ppt_add_image_slide(
                prs,
                f"sIou: Endpoint = {siou_endpoint_label} | Pooled Top10 HVM-Electrical (Part 2)",
                entry['pooled_top10_part2']
            )

        if entry['pooled_voc']:
            _ppt_add_image_slide(
                prs,
                f"sIou: Endpoint = {siou_endpoint_label} | Pooled VOC Strongest HVM",
                entry['pooled_voc']
            )
        else:
            missing.append('pooled_voc')

        if entry['chain_analysis']:
            _ppt_add_image_slide(
                prs,
                f"sIou: Endpoint = {siou_endpoint_label} | IDV → Electrical → VOC Chain Analysis",
                entry['chain_analysis']
            )
        else:
            missing.append('chain_analysis')

        if entry['lane_voc']:
            _ppt_add_image_slide(
                prs,
                f"sIou: Endpoint = {siou_endpoint_label} | VOC Strongest HVM (Per-Lane Overlay)",
                entry['lane_voc']
            )
        else:
            missing.append('lane_voc')

        if missing:
            missing_summary[siou_key] = missing

    out_path = os.path.join(
        results_dir,
        PPT_REPORT_NAME_TEMPLATE.format(run_ts=run_ts)
    )
    prs.save(out_path)

    print("\nPowerPoint report generated.")
    print(f"  Path: {out_path}")
    print(f"  sIou sections: {len(siou_keys)}")
    print(f"  Slides total: {len(prs.slides)}")
    if missing_summary:
        print("  Missing assets by sIou (slides skipped):")
        for siou_key in sorted(missing_summary.keys()):
            print(f"    {siou_key}: {missing_summary[siou_key]}")

    return out_path


def generate_voc_chain_charts(results_dir, run_ts, df_hvm_elec_sig, df_ee_sig,
                              voc_params, top_n=20):
    """Build IDV → electrical → VOC chain charts per sIou.

    Chain strength S = |r_A| * |r_B| where:
      r_A = IDV  -> electrical intermediate (from df_hvm_elec_sig)
      r_B = electrical intermediate -> VOC  (from df_ee_sig)
    All IDV parameters compete with no physical prior filtering.
    """
    def _safe(s):
        return "".join(ch if ch.isalnum() or ch in ('-', '_') else '_' for ch in str(s))

    chain_dir = os.path.join(results_dir, f"chain_voc_per_siou_{run_ts}")
    os.makedirs(chain_dir, exist_ok=True)

    # Pre-filter: only keep rows where the electrical parameter IS a VOC param
    # for the r_B (elec->VOC) edge set
    voc_set = set(voc_params)

    # Helper: short label for long IDV names
    def _trim(s, n=28):
        return s if len(s) <= n else s[:n - 1] + u'\u2026'

    siou_values = df_hvm_elec_sig['sIou'].dropna().unique()

    for siou_p in siou_values:
        # Edge A: IDV -> any electrical (non-VOC intermediary) for this sIou
        edge_a = (
            df_hvm_elec_sig[
                (df_hvm_elec_sig['sIou'] == siou_p) &
                (~df_hvm_elec_sig['electrical_parameter'].isin(voc_set))
            ][['Endpoint', 'hvm_parameter', 'electrical_parameter', 'pearson_r']]
            .rename(columns={
                'electrical_parameter': 'intermediary',
                'pearson_r': 'r_A'
            })
            .copy()
        )

        # Edge B: electrical intermediary -> VOC for this sIou
        # Source: E-E significant correlations where one param is VOC
        # Build both directions: param_1=intermediary, param_2=VOC and vice-versa
        df_ee_siou = df_ee_sig[df_ee_sig['sIou'] == siou_p].copy()

        edge_b_fwd = (
            df_ee_siou[
                df_ee_siou['electrical_param_2'].isin(voc_set) &
                ~df_ee_siou['electrical_param_1'].isin(voc_set)
            ][['Endpoint', 'electrical_param_1', 'electrical_param_2', 'pearson_r']]
            .rename(columns={
                'electrical_param_1': 'intermediary',
                'electrical_param_2': 'voc_param',
                'pearson_r': 'r_B'
            })
        )
        edge_b_rev = (
            df_ee_siou[
                df_ee_siou['electrical_param_1'].isin(voc_set) &
                ~df_ee_siou['electrical_param_2'].isin(voc_set)
            ][['Endpoint', 'electrical_param_2', 'electrical_param_1', 'pearson_r']]
            .rename(columns={
                'electrical_param_2': 'intermediary',
                'electrical_param_1': 'voc_param',
                'pearson_r': 'r_B'
            })
        )
        edge_b = pd.concat([edge_b_fwd, edge_b_rev], ignore_index=True)

        if edge_a.empty or edge_b.empty:
            print(f"  Chain analysis: no data for sIou={siou_p}, skipping.")
            continue

        # Join edges on (Endpoint, intermediary) to form chains
        chains = edge_a.merge(edge_b, on=['Endpoint', 'intermediary'], how='inner')
        if chains.empty:
            print(f"  Chain analysis: no matching chains for sIou={siou_p}, skipping.")
            continue

        chains['abs_r_A'] = chains['r_A'].abs()
        chains['abs_r_B'] = chains['r_B'].abs()
        chains['chain_strength'] = chains['abs_r_A'] * chains['abs_r_B']
        chains['direction'] = np.sign(chains['r_A'] * chains['r_B'])
        chains['direction_label'] = chains['direction'].map(
            {1.0: '+', -1.0: '-', 0.0: '?'})

        # Keep top-N unique chains by strength
        chains = (
            chains
            .sort_values('chain_strength', ascending=False)
            .drop_duplicates(
                subset=['hvm_parameter', 'intermediary', 'voc_param'],
                keep='first'
            )
            .head(top_n)
            .reset_index(drop=True)
        )

        # Build chart: horizontal bar per chain, colored by voc_param
        voc_params_present = sorted(chains['voc_param'].unique())
        voc_cmap = plt.get_cmap('Set1', max(len(voc_params_present), 1))
        voc_colors = {v: voc_cmap(i) for i, v in enumerate(voc_params_present)}

        n_chains = len(chains)
        fig_h = max(7, 0.4 * n_chains + 2.5)
        fig, ax = plt.subplots(figsize=(14, fig_h))

        y_pos = np.arange(n_chains)
        bar_colors = [voc_colors[v] for v in chains['voc_param']]

        # Reverse so strongest chain is at top
        ax.barh(y_pos, chains['chain_strength'].values[::-1],
                color=bar_colors[::-1], edgecolor='k', linewidth=0.4, height=0.72)

        # Y-tick labels: IDV → intermediary → VOC  [dir]  (r_A=x, r_B=y)
        labels = [
            f"{_trim(row['hvm_parameter'])} \u2192 {_trim(row['intermediary'])} "
            f"\u2192 {row['voc_param']}  "
            f"[{row['direction_label']}]  "
            f"(r\u2090={row['r_A']:.2f}, r\u2099={row['r_B']:.2f})"
            for _, row in chains.iterrows()
        ]
        ax.set_yticks(y_pos)
        ax.set_yticklabels(labels[::-1], fontsize=7)

        ax.set_xlabel('Chain Strength  |r_A| \u00d7 |r_B|', fontsize=10)
        ax.set_xlim(0, 1.05)
        ax.grid(axis='x', alpha=0.3)

        # VOC legend
        from matplotlib.patches import Patch
        legend_handles = [
            Patch(facecolor=voc_colors[v], edgecolor='k', linewidth=0.5, label=v)
            for v in voc_params_present
        ]
        ax.legend(handles=legend_handles, title='VOC target',
                  fontsize=8, title_fontsize=8, loc='lower right', framealpha=0.85)

        fig.suptitle(
            f"[POOLED] IDV \u2192 Electrical \u2192 VOC Chain Analysis  |  sIou = {siou_p}\n"
            f"Top {n_chains} chains ranked by |r_A|\u00d7|r_B|  "
            f"(all IDV parameters, no physical priors, colored by VOC target)\n"
            f"[+] = IDV\u2191 \u2192 electrical\u2191 \u2192 VOC\u2191   "
            f"[-] = sign flip in chain   r\u2090=IDV\u2192elec  r\u2099=elec\u2192VOC",
            fontsize=10, fontweight='bold'
        )
        fig.tight_layout(rect=[0, 0, 1, 0.93])

        out_path = os.path.join(chain_dir, f"chain_voc_{_safe(siou_p)}.png")
        fig.savefig(out_path, dpi=SCATTER_DPI, bbox_inches='tight')
        plt.close(fig)
        print(f"  Saved: {os.path.basename(out_path)}")

        # Also save a CSV of all chains for this sIou
        chains.to_csv(
            os.path.join(chain_dir, f"chain_voc_{_safe(siou_p)}.csv"),
            index=False
        )

    print(f"VOC chain analysis charts folder: {chain_dir}")
    return chain_dir


def scatter_by_visualid(ax, sub_df, x_col, y_col, visualid_col,
                        marker_size=24, alpha=0.78, edge_width=0.3,
                        show_legend=False, legend_fontsize=7):
    """Scatter points grouped by VisualID so each ID has a distinct color."""
    from matplotlib.lines import Line2D

    plot_df = sub_df[[visualid_col, x_col, y_col]].dropna().copy()
    if plot_df.empty:
        return []

    ids = sorted(plot_df[visualid_col].astype(str).unique())
    cmap = plt.get_cmap('tab20', max(len(ids), 1))
    color_map = {vid: cmap(i) for i, vid in enumerate(ids)}

    for vid, g in plot_df.groupby(visualid_col, dropna=False):
        vid_str = str(vid)
        ax.scatter(
            g[x_col].to_numpy(),
            g[y_col].to_numpy(),
            s=marker_size,
            alpha=alpha,
            edgecolor='k',
            linewidth=edge_width,
            color=color_map[vid_str],
            zorder=3,
            label=vid_str,
        )

    if show_legend:
        max_items = 10
        shown = ids[:max_items]
        handles = [
            Line2D([0], [0], marker='o', linestyle='None',
                   markerfacecolor=color_map[v], markeredgecolor='k',
                   markeredgewidth=0.3, markersize=5, label=v)
            for v in shown
        ]
        if len(ids) > max_items:
            handles.append(
                Line2D([0], [0], linestyle='None', marker=None,
                       label=f"+{len(ids) - max_items} more IDs")
            )
        ax.legend(handles=handles, title='VisualID', fontsize=legend_fontsize,
                  title_fontsize=legend_fontsize, loc='best', framealpha=0.85)

    return ids

def main():
    try:
        df_hvm = pd.read_csv("IDV SAMPLING DMR IMH - by VID_17parts_volume.csv")
        df_elec = pd.read_csv("PCIEreciperegressions_db1p2a_UPM_Gen6_17parts.csv")

        # Mapping logic
        # hvm_map: feature_label -> matched_column_or_formula (audit string)
        # Feature labels mirror the underlying CSV column / parameter names
        # rather than generic hvm_NN tags.
        hvm_map = {}

        # ---- TPI LVT TCR (requested 0950*; fallback to 0650 if unavailable) ----
        c_tpi_lvt, p_tpi_lvt = find_col_any(
            df_hvm,
            [
                "TPI_IDV::IDV_X_SCREEN_K_START_X_X_X_X_FEM_CALC_IDV_FEM_1276P4_PDK1P1_LVT_TCR_FULLDIENOINF_0950",
                "TPI_IDV::IDV_X_SCREEN_K_START_X_X_X_X_FEM_CALC_IDV_FEM_1276P4_PDK1P1_LVT_TCR_FULLDIENOINF_0650",
            ],
            "TPI_LVT_TCR_FULLDIENOINF",
        )
        label_tpi_lvt = "TPI_LVT_TCR_FULLDIENOINF_0950" if p_tpi_lvt.endswith("0950") \
            else "TPI_LVT_TCR_FULLDIENOINF_0650"
        if not p_tpi_lvt.endswith("0950"):
            hvm_map[label_tpi_lvt] = f"{c_tpi_lvt} [fallback from requested 0950*]"
        else:
            hvm_map[label_tpi_lvt] = c_tpi_lvt
        df_hvm[label_tpi_lvt] = df_hvm[c_tpi_lvt]

        # ---- Ratio IDV_2036 / IDV_2032 ----
        c2036 = find_col(df_hvm, "IDV_2036_NHPLVT3FIN2LEGVTO8DG_FULLDIE_0950_MED")
        c2032 = find_col(df_hvm, "IDV_2032_PHPLVT3FIN2LEGVTO8DG_FULLDIE_0950_MED")
        label_ratio_2036_2032 = "RATIO_IDV_2036_NHPLVT3FIN2LEGVTO8DG_OVER_IDV_2032_PHPLVT3FIN2LEGVTO8DG_FULLDIE_0950_MED"
        df_hvm[label_ratio_2036_2032] = df_hvm[c2036] / df_hvm[c2032]
        hvm_map[label_ratio_2036_2032] = f"{c2036} / {c2032}"

        # ---- Range across UIO + D2D MISCIOVCTL columns of IDV_2006 ----
        uio_prefixes = [
            "IDV_2006_HPLVT3FIN2LEGNES8DG_UIO0MISCIOVCTL0_0950_MED",
            "IDV_2006_HPLVT3FIN2LEGNES8DG_UIO0MISCIOVCTL1_0950_MED",
            "IDV_2006_HPLVT3FIN2LEGNES8DG_UIO1MISCIOVCTL0_0950_MED",
            "IDV_2006_HPLVT3FIN2LEGNES8DG_UIO1MISCIOVCTL1_0950_MED",
            "IDV_2006_HPLVT3FIN2LEGNES8DG_UIO2MISCIOVCTL0_0950_MED",
            "IDV_2006_HPLVT3FIN2LEGNES8DG_UIO2MISCIOVCTL1_0950_MED",
            "IDV_2006_HPLVT3FIN2LEGNES8DG_D2D0MISCIOVCTL1_0950_MED",
            "IDV_2006_HPLVT3FIN2LEGNES8DG_D2D1MISCIOVCTL1_0950_MED",
        ]
        uio_cols = [find_col(df_hvm, p) for p in uio_prefixes]
        label_range_uio_d2d = "RANGE_IDV_2006_HPLVT3FIN2LEGNES8DG_UIO_D2D_MISCIOVCTL_0950_MED"
        df_hvm[label_range_uio_d2d] = df_hvm[uio_cols].max(axis=1) - df_hvm[uio_cols].min(axis=1)
        hvm_map[label_range_uio_d2d] = f"Range({', '.join(uio_cols)})"

        # ---- Ratio IDV_2017 / IDV_2018 ----
        c2017 = find_col(df_hvm, "IDV_2017_HPLVT3FIN1LEGNDM8DG_FULLDIE_0950_MED")
        c2018 = find_col(df_hvm, "IDV_2018_HPLVT3FIN1LEGPDM8DG_FULLDIE_0950_MED")
        label_ratio_2017_2018 = "RATIO_IDV_2017_HPLVT3FIN1LEGNDM8DG_OVER_IDV_2018_HPLVT3FIN1LEGPDM8DG_FULLDIE_0950_MED"
        df_hvm[label_ratio_2017_2018] = df_hvm[c2017] / df_hvm[c2018]
        hvm_map[label_ratio_2017_2018] = f"{c2017} / {c2018}"

        # ---- Direct-match IDV columns selected by source mode ----
        direct_idv_cols = select_direct_idv_columns(df_hvm, HVM_PARAM_SOURCE)
        for col in direct_idv_cols:
            hvm_map.setdefault(col, col)
        print(
            f"Included {len(direct_idv_cols)} direct IDV columns "
            f"(HVM_PARAM_SOURCE='{HVM_PARAM_SOURCE}')."
        )

        # ---- TPI SVT TCR (requested 0950*; fallback to 0650 if unavailable) ----
        c_tpi_svt, p_tpi_svt = find_col_any(
            df_hvm,
            [
                "TPI_IDV::IDV_X_SCREEN_K_START_X_X_X_X_FEM_CALC_IDV_FEM_1276P4_PDK1P1_SVT_TCR_FULLDIENOINF_0950",
                "TPI_IDV::IDV_X_SCREEN_K_START_X_X_X_X_FEM_CALC_IDV_FEM_1276P4_PDK1P1_SVT_TCR_FULLDIENOINF_0650",
            ],
            "TPI_SVT_TCR_FULLDIENOINF",
        )
        label_tpi_svt = "TPI_SVT_TCR_FULLDIENOINF_0950" if p_tpi_svt.endswith("0950") \
            else "TPI_SVT_TCR_FULLDIENOINF_0650"
        if not p_tpi_svt.endswith("0950"):
            hvm_map[label_tpi_svt] = f"{c_tpi_svt} [fallback from requested 0950*]"
        else:
            hvm_map[label_tpi_svt] = c_tpi_svt
        df_hvm[label_tpi_svt] = df_hvm[c_tpi_svt]

        hvm_features = list(hvm_map.keys())
                
        elec_cols_requested = "fom_avg,tMarginMin,atten,ctle_index_mean,ddfe,dfe1e_high,dfe2e,dfe3e,edfe2e,fom_raw_ac,fomIdx0,edfe3e,Q_avg,atten_mean,ctle_index,dco_cors,dco_iqc_pi,dco_slow_trim,dco_vgap,dco_vreg,fber_avg,vocDH_MINmV,vocDM_MINmV,vocDL_MINmV".split(',')
        elec_cols = [c.strip() for c in elec_cols_requested if c.strip() in df_elec.columns]
        missing_elec = [c.strip() for c in elec_cols_requested if c.strip() not in df_elec.columns]
        if missing_elec:
            print(f"Warning: Electrical columns not found: {missing_elec}")

        # ----------------------------------------------------------
        # Join HVM and electrical on VISUAL_ID == VisualID
        # (HVM is one row per unit; electrical is many rows per unit
        #  across Endpoint x sIou x nIouLane)
        # ----------------------------------------------------------
        hvm_join_key = "VISUAL_ID"
        elec_join_key = "VisualID"
        hvm_sub_key = "SUBSTRUCTURE_ID"
        if (hvm_join_key not in df_hvm.columns or
                elec_join_key not in df_elec.columns or
                hvm_sub_key not in df_hvm.columns):
            raise ValueError(
                f"Join keys missing: HVM has {hvm_join_key}? "
                f"{hvm_join_key in df_hvm.columns} | "
                f"HVM has {hvm_sub_key}? {hvm_sub_key in df_hvm.columns} | "
                f"Elec has {elec_join_key}? {elec_join_key in df_elec.columns}"
            )

        for gc in GROUP_COLS:
            if gc not in df_elec.columns:
                raise ValueError(f"Group column missing in electrical CSV: {gc}")

        # Map sIou -> required HVM SUBSTRUCTURE_ID and merge on both keys.
        df_hvm["_sub_key"] = df_hvm[hvm_sub_key].astype(str).str.strip().str.upper()
        df_elec["_siou_key"] = df_elec["sIou"].astype(str).str.strip().str.lower()
        df_elec["_sub_key"] = df_elec["_siou_key"].map(SIOU_TO_SUBSTRUCTURE)

        unmapped_siou = sorted(df_elec.loc[df_elec["_sub_key"].isna(), "_siou_key"].dropna().unique())
        if unmapped_siou:
            print(f"Warning: sIou values without U1/U2 mapping were dropped: {unmapped_siou}")
        elec_for_merge = df_elec[df_elec["_sub_key"].notna()].copy()

        hvm_keep = [hvm_join_key, "_sub_key"] + hvm_features
        elec_keep = [elec_join_key, "_sub_key"] + GROUP_COLS + elec_cols
        merged = elec_for_merge[elec_keep].merge(
            df_hvm[hvm_keep],
            left_on=[elec_join_key, "_sub_key"],
            right_on=[hvm_join_key, "_sub_key"],
            how="inner"
        )

        # Coerce numeric on feature columns
        for col in hvm_features + elec_cols:
            merged[col] = pd.to_numeric(merged[col], errors='coerce')
        merged.replace([np.inf, -np.inf], np.nan, inplace=True)

        print(f"Merged rows on VisualID + SUBSTRUCTURE_ID mapping: {len(merged)}")

        # ----------------------------------------------------------
        # Detect duplicate / redundant electrical metrics on the
        # full merged dataset and pick a representative per cluster.
        # ----------------------------------------------------------
        def dedupe_electrical(df_, cols, threshold=DEDUPE_CORR_THRESHOLD):
            sub = df_[cols].apply(pd.to_numeric, errors='coerce').dropna(how='any')
            if sub.empty or len(cols) < 2:
                return list(cols), {}
            # drop zero-variance cols up front
            keep_cols = [c for c in cols if sub[c].nunique() > 1]
            if len(keep_cols) < 2:
                return keep_cols, {}
            corr = sub[keep_cols].corr().abs()
            visited = set()
            reps = []
            clusters = {}
            for c in keep_cols:
                if c in visited:
                    continue
                # cluster = self + everything correlated >= threshold
                members = [m for m in keep_cols if corr.loc[c, m] >= threshold]
                rep = sorted(members, key=len)[0]  # shortest name as representative
                reps.append(rep)
                clusters[rep] = members
                visited.update(members)
            # preserve original ordering
            reps_ordered = [c for c in keep_cols if c in reps]
            return reps_ordered, clusters

        elec_cols_unique, elec_clusters = dedupe_electrical(merged, elec_cols)
        dropped = [c for c in elec_cols if c not in elec_cols_unique]
        if dropped:
            print(f"Deduped electrical columns (|r|>={DEDUPE_CORR_THRESHOLD}): "
                  f"kept {len(elec_cols_unique)}/{len(elec_cols)}; "
                  f"dropped {dropped}")

        # ----------------------------------------------------------
        # Per-group Pearson correlation
        # ----------------------------------------------------------
        results_dir = "results"
        os.makedirs(results_dir, exist_ok=True)
        per_group_dir = os.path.join(results_dir, f"per_group_{RUN_TS}")
        os.makedirs(per_group_dir, exist_ok=True)

        all_sig = []           # all significant rows across groups (for ranking + scatter)
        group_summary = []     # one row per group: counts of sig pairs, top pair

        grouped = merged.groupby(GROUP_COLS, dropna=False)
        n_groups_total = grouped.ngroups
        n_groups_used = 0

        def safe_name(s):
            return "".join(ch if ch.isalnum() or ch in ('-', '_') else '_'
                           for ch in str(s))

        for grp_key, gdf in grouped:
            ep, siou, lane = grp_key
            sub = gdf[hvm_features + elec_cols_unique].dropna()
            n = len(sub)
            if n < MIN_GROUP_SAMPLES:
                continue

            r_mat = pd.DataFrame(index=hvm_features, columns=elec_cols_unique, dtype=float)
            p_mat = pd.DataFrame(index=hvm_features, columns=elec_cols_unique, dtype=float)
            sig_rows = []
            for h in hvm_features:
                for e in elec_cols_unique:
                    if sub[h].nunique() <= 1 or sub[e].nunique() <= 1:
                        r, p = 0.0, 1.0
                    else:
                        r, p = pearsonr(sub[h], sub[e])
                    r_mat.loc[h, e] = r
                    p_mat.loc[h, e] = p
                    if p < 0.05:
                        sig_rows.append({
                            'Endpoint': ep, 'sIou': siou, 'nIouLane': lane,
                            'n_samples': n,
                            'hvm_parameter': h,
                            'electrical_parameter': e,
                            'pearson_r': r, 'p_value': p
                        })

            n_groups_used += 1
            tag = f"{safe_name(ep)}__{safe_name(siou)}__lane{safe_name(lane)}"
            r_mat.to_csv(os.path.join(per_group_dir, f"r_{tag}.csv"))
            p_mat.to_csv(os.path.join(per_group_dir, f"p_{tag}.csv"))

            top_in_group = None
            if sig_rows:
                top_in_group = max(sig_rows, key=lambda d: abs(d['pearson_r']))
            group_summary.append({
                'Endpoint': ep, 'sIou': siou, 'nIouLane': lane,
                'n_samples': n,
                'n_significant_pairs': len(sig_rows),
                'top_hvm': top_in_group['hvm_parameter'] if top_in_group else '',
                'top_electrical': top_in_group['electrical_parameter'] if top_in_group else '',
                'top_pearson_r': top_in_group['pearson_r'] if top_in_group else np.nan,
                'top_p_value': top_in_group['p_value'] if top_in_group else np.nan,
            })

            all_sig.extend(sig_rows)

        print(f"Groups: {n_groups_used}/{n_groups_total} met "
              f"min samples >= {MIN_GROUP_SAMPLES}")

        # Aggregated sig table sorted by |r|
        df_sig = pd.DataFrame(all_sig)
        if not df_sig.empty:
            df_sig['abs_r'] = df_sig['pearson_r'].abs()
            df_sig = df_sig.sort_values('abs_r', ascending=False).drop(columns=['abs_r'])
        df_sig.to_csv(os.path.join(results_dir, "significant_correlations.csv"), index=False)

        df_grp = pd.DataFrame(group_summary).sort_values(
            'top_pearson_r', key=lambda s: s.abs(), ascending=False, na_position='last'
        )
        df_grp.to_csv(os.path.join(results_dir, "group_summary.csv"), index=False)

        pd.DataFrame(
            list(hvm_map.items()),
            columns=['feature_name', 'matched_column_or_formula']
        ).to_csv(os.path.join(results_dir, "hvm_column_mapping.csv"), index=False)

        # Cluster mapping audit
        cluster_rows = []
        for rep, members in elec_clusters.items():
            cluster_rows.append({'representative': rep,
                                 'members': ", ".join(members),
                                 'cluster_size': len(members)})
        pd.DataFrame(cluster_rows).to_csv(
            os.path.join(results_dir, "electrical_dedupe_clusters.csv"), index=False
        )

        # Print summary
        print(f"Results saved to folder: {results_dir}")
        print(f"Per-group matrices in: {per_group_dir}")
        print("\nStrongest 15 Absolute Correlations (p < 0.05) across all groups:")
        if not df_sig.empty:
            print(df_sig.head(15).to_string(index=False))
        else:
            print("No significant correlations found.")

        # ----------------------------------------------------------
        # Scatter charts for the top-N correlations across all
        # groups. Each chart fixes (Endpoint, sIou, HVM, electrical)
        # and OVERLAYS all nIouLanes on the same axes (one color per
        # lane). Per-lane Pearson r is shown in the legend, and a
        # combined regression line uses the pooled data.
        # ----------------------------------------------------------
        if not df_sig.empty:
            scatter_dir = os.path.join(results_dir, f"scatter_top{TOP_N_SCATTER}_{RUN_TS}")
            os.makedirs(scatter_dir, exist_ok=True)

            # Pick top-N UNIQUE (Endpoint, sIou, hvm, electrical) tuples
            df_unique = (df_sig
                         .assign(_abs_r=lambda d: d['pearson_r'].abs())
                         .sort_values('_abs_r', ascending=False)
                         .drop_duplicates(
                             subset=['Endpoint', 'sIou',
                                     'hvm_parameter', 'electrical_parameter'],
                             keep='first')
                         .drop(columns='_abs_r')
                         .reset_index(drop=True))
            top_df = df_unique.head(TOP_N_SCATTER).reset_index(drop=True)
            n_top = len(top_df)

            # ---- Individual overlay PNGs ----
            for i, row in top_df.iterrows():
                h = row['hvm_parameter']
                e = row['electrical_parameter']
                ep = row['Endpoint']; siou = row['sIou']

                mask_es = ((merged['Endpoint'] == ep) &
                           (merged['sIou'] == siou))
                sub_es = merged.loc[mask_es, ['nIouLane', h, e]].dropna()
                if sub_es.empty:
                    continue

                lanes_present = sorted(sub_es['nIouLane'].dropna().unique())
                cmap = plt.get_cmap('tab20', max(len(lanes_present), 1))

                fig, ax = plt.subplots(figsize=(9, 6.5))

                # Per-lane scatter + per-lane Pearson + per-lane regression line
                for li, ln in enumerate(lanes_present):
                    sub_l = sub_es[sub_es['nIouLane'] == ln]
                    if len(sub_l) < 2:
                        continue
                    xl = sub_l[h].to_numpy(); yl = sub_l[e].to_numpy()
                    color = cmap(li)
                    if sub_l[h].nunique() <= 1 or sub_l[e].nunique() <= 1:
                        rl, pl = np.nan, np.nan
                    else:
                        rl, pl = pearsonr(xl, yl)

                    label = (f"L{ln} N={len(sub_l)} r={rl:.3f}"
                             if np.isfinite(rl) else f"L{ln} N={len(sub_l)}")
                    ax.scatter(xl, yl, s=22, alpha=0.7, edgecolor='k',
                               linewidth=0.3, color=color,
                               label=label, zorder=3)

                    # Per-lane regression line (color-matched)
                    if len(xl) >= 2 and np.std(xl) > 0:
                        slope, intercept = np.polyfit(xl, yl, 1)
                        xline = np.linspace(np.min(xl), np.max(xl), 50)
                        ax.plot(xline, slope * xline + intercept,
                                color=color, linewidth=1.8, alpha=0.9,
                                zorder=5)

                ax.set_xlabel(h, fontsize=9)
                ax.set_ylabel(e, fontsize=10)
                ax.set_title(
                    f"#{i+1}  {h}  vs  {e}\n"
                    f"Endpoint={ep}   sIou={siou}   "
                    f"(per-lane fits, all nIouLanes overlapped)",
                    fontsize=10, fontweight='bold'
                )
                ax.grid(True, alpha=0.25)
                ax.legend(fontsize=7, ncol=2, loc='best', framealpha=0.85)
                fig.tight_layout()

                fname = (f"scatter_{i+1:02d}_"
                         f"{safe_name(ep)}__{safe_name(siou)}__allLanes__"
                         f"{h}__{e}.png")
                out_path = os.path.join(scatter_dir, fname)
                fig.savefig(out_path, dpi=SCATTER_DPI, bbox_inches='tight')
                plt.close(fig)
                print(f"  Saved: {os.path.basename(out_path)}")

            # ---- Combined panel ----
            ncols = min(n_top, 3) if n_top > 0 else 1
            nrows = int(np.ceil(n_top / ncols)) if n_top > 0 else 1
            fig, axes = plt.subplots(nrows, ncols, figsize=(7 * ncols, 5.5 * nrows))
            axes = np.array(axes).reshape(-1)

            for i, row in top_df.iterrows():
                h = row['hvm_parameter']; e = row['electrical_parameter']
                ep = row['Endpoint']; siou = row['sIou']
                mask_es = ((merged['Endpoint'] == ep) &
                           (merged['sIou'] == siou))
                sub_es = merged.loc[mask_es, ['nIouLane', h, e]].dropna()
                ax = axes[i]
                if sub_es.empty:
                    ax.set_visible(False)
                    continue

                lanes_present = sorted(sub_es['nIouLane'].dropna().unique())
                cmap = plt.get_cmap('tab20', max(len(lanes_present), 1))
                for li, ln in enumerate(lanes_present):
                    sub_l = sub_es[sub_es['nIouLane'] == ln]
                    color = cmap(li)
                    if len(sub_l) >= 2 and sub_l[h].nunique() > 1 and sub_l[e].nunique() > 1:
                        rl, pl = pearsonr(sub_l[h].to_numpy(), sub_l[e].to_numpy())
                        lane_label = f"L{ln} r={rl:.3f} p={pl:.1e}"
                    else:
                        lane_label = f"L{ln} r=NA"
                    ax.scatter(sub_l[h], sub_l[e], s=14, alpha=0.65,
                               edgecolor='k', linewidth=0.2,
                               color=color, label=lane_label, zorder=3)
                    if len(sub_l) >= 2 and sub_l[h].nunique() > 1:
                        xl = sub_l[h].to_numpy(); yl = sub_l[e].to_numpy()
                        slope, intercept = np.polyfit(xl, yl, 1)
                        xline = np.linspace(np.min(xl), np.max(xl), 50)
                        ax.plot(xline, slope * xline + intercept,
                                color=color, linewidth=1.4, alpha=0.9, zorder=5)

                ax.set_xlabel(h, fontsize=7)
                ax.set_ylabel(e, fontsize=8)
                ax.set_title(
                    f"#{i+1}  {ep}/{siou}  (per-lane fits, all lanes)",
                    fontsize=8, fontweight='bold'
                )
                ax.grid(True, alpha=0.25)
                ax.tick_params(axis='both', labelsize=7)
                ax.legend(fontsize=6, ncol=4, loc='best', framealpha=0.8)

            for j in range(n_top, len(axes)):
                axes[j].set_visible(False)

            fig.suptitle(
                f"Top {n_top} HVM ? Electrical Correlations  "
                f"(per sIou/Endpoint, all nIouLanes overlapped)",
                fontsize=13, fontweight='bold'
            )
            fig.tight_layout(rect=[0, 0, 1, 0.95])
            panel_path = os.path.join(
                scatter_dir, f"scatter_top{TOP_N_SCATTER}_panel.png"
            )
            fig.savefig(panel_path, dpi=SCATTER_DPI, bbox_inches='tight')
            plt.close(fig)
            print(f"  Saved: {os.path.basename(panel_path)}")
            print(f"Scatter charts folder: {scatter_dir}")

            # ----------------------------------------------------------
            # Per-sIou top-10 figure: one figure per sIou with
            # subplots for the 10 strongest unique (Endpoint, HVM, electrical)
            # correlations within that sIou. All nIouLanes overlapped
            # in each subplot, with per-lane color-coded regression fits.
            # ----------------------------------------------------------
            TOP_N_PER_ENDPOINT = 10
            endpoint_dir = os.path.join(
                results_dir, f"per_siou_top{TOP_N_PER_ENDPOINT}_{RUN_TS}"
            )
            os.makedirs(endpoint_dir, exist_ok=True)

            df_unique_all = (df_sig
                             .assign(_abs_r=lambda d: d['pearson_r'].abs())
                             .sort_values('_abs_r', ascending=False)
                             .drop_duplicates(
                                 subset=['Endpoint', 'sIou',
                                         'hvm_parameter', 'electrical_parameter'],
                                 keep='first')
                             .drop(columns='_abs_r'))

            for siou, df_siou in df_unique_all.groupby('sIou'):
                top_siou = df_siou.head(TOP_N_PER_ENDPOINT).reset_index(drop=True)
                n_siou = len(top_siou)
                if n_siou == 0:
                    continue

                # Split top-N into chunks of 5 subplots per figure for readability
                CHUNK = 5
                n_chunks = int(np.ceil(n_siou / CHUNK))
                for chunk_idx in range(n_chunks):
                    start = chunk_idx * CHUNK
                    end = min(start + CHUNK, n_siou)
                    chunk_df = top_siou.iloc[start:end].reset_index(drop=True)
                    n_c = len(chunk_df)

                    ncols_ep = min(n_c, 3)
                    nrows_ep = int(np.ceil(n_c / ncols_ep))
                    fig, axes = plt.subplots(
                        nrows_ep, ncols_ep,
                        figsize=(7 * ncols_ep, 5.5 * nrows_ep)
                    )
                    axes = np.array(axes).reshape(-1)

                    for i, row in chunk_df.iterrows():
                        rank = start + i + 1  # global rank within sIou
                        h = row['hvm_parameter']; e = row['electrical_parameter']
                        ep = row['Endpoint']
                        mask_es = ((merged['Endpoint'] == ep) &
                                   (merged['sIou'] == siou))
                        sub_es = merged.loc[mask_es, ['nIouLane', h, e]].dropna()
                        ax = axes[i]
                        if sub_es.empty:
                            ax.set_visible(False)
                            continue

                        lanes_present = sorted(sub_es['nIouLane'].dropna().unique())
                        cmap = plt.get_cmap('tab20', max(len(lanes_present), 1))
                        for li, ln in enumerate(lanes_present):
                            sub_l = sub_es[sub_es['nIouLane'] == ln]
                            color = cmap(li)
                            if len(sub_l) >= 2 and sub_l[h].nunique() > 1 and sub_l[e].nunique() > 1:
                                rl, pl = pearsonr(sub_l[h].to_numpy(), sub_l[e].to_numpy())
                                lane_label = f"L{ln} r={rl:.3f} p={pl:.1e}"
                            else:
                                lane_label = f"L{ln} r=NA"
                            ax.scatter(sub_l[h], sub_l[e], s=14, alpha=0.65,
                                       edgecolor='k', linewidth=0.2,
                                       color=color, label=lane_label, zorder=3)
                            if len(sub_l) >= 2 and sub_l[h].nunique() > 1:
                                xl = sub_l[h].to_numpy(); yl = sub_l[e].to_numpy()
                                slope, intercept = np.polyfit(xl, yl, 1)
                                xline = np.linspace(np.min(xl), np.max(xl), 50)
                                ax.plot(xline, slope * xline + intercept,
                                        color=color, linewidth=1.4, alpha=0.9,
                                        zorder=5)

                        ax.set_xlabel(h, fontsize=7)
                        ax.set_ylabel(e, fontsize=8)
                        ax.set_title(
                            f"#{rank}  Endpoint={ep}   "
                            f"r={float(row['pearson_r']):.3f}  "
                            f"p={float(row['p_value']):.2e}",
                            fontsize=8, fontweight='bold'
                        )
                        ax.grid(True, alpha=0.25)
                        ax.tick_params(axis='both', labelsize=7)
                        ax.legend(fontsize=6, ncol=4, loc='best', framealpha=0.8)

                    for j in range(n_c, len(axes)):
                        axes[j].set_visible(False)

                    fig.suptitle(
                        f"sIou = {siou}   �   Top {n_siou} HVM ? Electrical "
                        f"Correlations  (part {chunk_idx + 1}/{n_chunks}: "
                        f"ranks {start + 1}-{end})",
                        fontsize=13, fontweight='bold'
                    )
                    fig.tight_layout(rect=[0, 0, 1, 0.96])
                    ep_path = os.path.join(
                        endpoint_dir,
                        f"siou_top{TOP_N_PER_ENDPOINT}_{safe_name(siou)}"
                        f"_part{chunk_idx + 1}.png"
                    )
                    fig.savefig(ep_path, dpi=SCATTER_DPI, bbox_inches='tight')
                    plt.close(fig)
                    print(f"  Saved: {os.path.basename(ep_path)}")
            print(f"Per-sIou charts folder: {endpoint_dir}")

            # ----------------------------------------------------------
            # VOC Parameters per sIou (per-lane overlay)
            # For each sIou, create a 3-subplot figure showing
            # vocDH_MINmV, vocDM_MINmV, vocDL_MINmV with their
            # strongest HVM correlations (per-lane analysis).
            # ----------------------------------------------------------
            VOC_PARAMS = ["vocDH_MINmV", "vocDM_MINmV", "vocDL_MINmV"]
            voc_dir = os.path.join(results_dir, f"voc_per_siou_{RUN_TS}")
            os.makedirs(voc_dir, exist_ok=True)

            for siou in merged['sIou'].dropna().unique():
                fig, axes = plt.subplots(1, 3, figsize=(21, 6))

                for subplot_idx, voc_param in enumerate(VOC_PARAMS):
                    ax = axes[subplot_idx]

                    # Find the strongest correlation for this VOC param and sIou
                    ep_voc_rows = df_sig[(df_sig['sIou'] == siou) &
                                         (df_sig['electrical_parameter'] == voc_param)]

                    if ep_voc_rows.empty:
                        ax.text(0.5, 0.5, f"No correlations found\nfor {voc_param}",
                               ha='center', va='center', transform=ax.transAxes,
                               fontsize=10)
                        continue

                    top_row = ep_voc_rows.loc[ep_voc_rows['pearson_r'].abs().idxmax()]
                    h = top_row['hvm_parameter']
                    ep = top_row['Endpoint']
                    r_val = float(top_row['pearson_r'])
                    p_val = float(top_row['p_value'])

                    # Get data for this sIou and strongest Endpoint
                    mask = ((merged['Endpoint'] == ep) & (merged['sIou'] == siou))
                    sub_es = merged.loc[mask, ['nIouLane', h, voc_param]].dropna()

                    if sub_es.empty:
                        ax.text(0.5, 0.5, f"No data for {voc_param}",
                               ha='center', va='center', transform=ax.transAxes,
                               fontsize=10)
                        continue

                    # Plot per-lane overlay
                    lanes_present = sorted(sub_es['nIouLane'].dropna().unique())
                    cmap = plt.get_cmap('tab20', max(len(lanes_present), 1))

                    for li, ln in enumerate(lanes_present):
                        sub_l = sub_es[sub_es['nIouLane'] == ln]
                        color = cmap(li)
                        if len(sub_l) >= 2 and sub_l[h].nunique() > 1 and sub_l[voc_param].nunique() > 1:
                            rl, pl = pearsonr(sub_l[h].to_numpy(), sub_l[voc_param].to_numpy())
                            lane_label = f"L{ln} r={rl:.3f}"
                        else:
                            lane_label = f"L{ln}"
                        ax.scatter(sub_l[h], sub_l[voc_param], s=14, alpha=0.65,
                                   edgecolor='k', linewidth=0.2,
                                   color=color, label=lane_label, zorder=3)
                        if len(sub_l) >= 2 and sub_l[h].nunique() > 1:
                            xl = sub_l[h].to_numpy(); yl = sub_l[voc_param].to_numpy()
                            slope, intercept = np.polyfit(xl, yl, 1)
                            xline = np.linspace(np.min(xl), np.max(xl), 50)
                            ax.plot(xline, slope * xline + intercept,
                                    color=color, linewidth=1.4, alpha=0.9, zorder=5)

                    ax.set_xlabel(h, fontsize=8)
                    ax.set_ylabel(voc_param, fontsize=9)
                    ax.set_title(
                        f"{voc_param} vs {h}\n"
                        f"sIou={siou}  Endpoint={ep}  "
                        f"r={r_val:.3f}  p={p_val:.2e}",
                        fontsize=9, fontweight='bold'
                    )
                    ax.grid(True, alpha=0.25)
                    ax.tick_params(axis='both', labelsize=7)
                    ax.legend(fontsize=6, ncol=2, loc='best', framealpha=0.8)

                fig.suptitle(
                    f"VOC Parameters by sIou = {siou}  �  Strongest HVM Correlations "
                    f"(per-lane overlay)",
                    fontsize=12, fontweight='bold'
                )
                fig.tight_layout(rect=[0, 0, 1, 0.96])
                voc_path = os.path.join(voc_dir, f"voc_{safe_name(siou)}.png")
                fig.savefig(voc_path, dpi=SCATTER_DPI, bbox_inches='tight')
                plt.close(fig)
                print(f"  Saved: {os.path.basename(voc_path)}")

            print(f"VOC per-sIou charts folder: {voc_dir}")

            # ----------------------------------------------------------
            # Pareto plot per sIou (per-lane analysis)
            # Ranks all unique (HVM, electrical) pairs within each
            # sIou by |pearson_r|, highest to lowest, with a
            # cumulative % overlay on a secondary y-axis.
            # Bars are color-coded by Endpoint.
            # ----------------------------------------------------------
            pareto_dir = os.path.join(results_dir, f"pareto_per_siou_{RUN_TS}")
            os.makedirs(pareto_dir, exist_ok=True)

            # Build a color map for Endpoint values
            all_endpoint = sorted(df_sig['Endpoint'].dropna().unique())
            endpoint_cmap = plt.get_cmap('tab10', max(len(all_endpoint), 1))
            endpoint_colors = {e: endpoint_cmap(i) for i, e in enumerate(all_endpoint)}

            for siou in df_sig['sIou'].dropna().unique():
                df_siou = (
                    df_sig[df_sig['sIou'] == siou]
                    .assign(_abs_r=lambda d: d['pearson_r'].abs())
                    .sort_values('_abs_r', ascending=False)
                    .drop_duplicates(
                        subset=['hvm_parameter', 'electrical_parameter'],
                        keep='first'
                    )
                    .head(TOP_N_PARETO)
                    .reset_index(drop=True)
                )
                if df_siou.empty:
                    continue

                n_pairs = len(df_siou)
                # Build short tick labels: "HVM_label | elec_label"
                # Truncate long HVM names for readability
                def _short(s, n=22):
                    return s if len(s) <= n else s[:n - 1] + u'\u2026'

                labels = [
                    f"{_short(row['hvm_parameter'])} | {row['electrical_parameter']}"
                    for _, row in df_siou.iterrows()
                ]
                abs_r = df_siou['_abs_r'].to_numpy()
                cum_pct = np.cumsum(abs_r) / abs_r.sum() * 100
                bar_colors = [endpoint_colors.get(e, 'gray') for e in df_siou['Endpoint']]

                fig_height = max(6, 0.35 * n_pairs + 2)
                fig, ax1 = plt.subplots(figsize=(13, fig_height))
                ax2 = ax1.twinx()

                y_pos = np.arange(n_pairs)
                # Horizontal bars (highest |r| at top)
                ax1.barh(y_pos, abs_r[::-1], color=bar_colors[::-1],
                         edgecolor='k', linewidth=0.4, height=0.7)
                ax2.plot(cum_pct[::-1], y_pos, color='black',
                         marker='o', markersize=4, linewidth=1.6,
                         zorder=5, label='Cumulative %')

                ax1.set_yticks(y_pos)
                ax1.set_yticklabels(labels[::-1], fontsize=7)
                ax1.set_xlabel('|Pearson r|', fontsize=10)
                ax1.set_xlim(0, 1.05)
                ax2.set_ylabel('Cumulative % of total |r|', fontsize=9)
                ax2.set_ylim(0, 110)
                ax2.yaxis.set_major_formatter(
                    plt.FuncFormatter(lambda v, _: f'{v:.0f}%')
                )

                # Endpoint legend
                from matplotlib.patches import Patch
                legend_handles = [
                    Patch(facecolor=endpoint_colors[e], edgecolor='k',
                          linewidth=0.5, label=e)
                    for e in all_endpoint if e in df_siou['Endpoint'].values
                ]
                ax1.legend(handles=legend_handles, title='Endpoint',
                           fontsize=8, title_fontsize=8,
                           loc='lower right', framealpha=0.85)

                ax1.grid(axis='x', alpha=0.3)
                fig.suptitle(
                    f"Pareto � HVM ? Electrical Correlations  |  sIou = {siou}\n"
                    f"({n_pairs} unique HVM�Elec pairs, sorted by |r|, colored by Endpoint)",
                    fontsize=11, fontweight='bold'
                )
                fig.tight_layout(rect=[0, 0, 1, 0.95])
                pareto_path = os.path.join(pareto_dir, f"pareto_{safe_name(siou)}.png")
                fig.savefig(pareto_path, dpi=SCATTER_DPI, bbox_inches='tight')
                plt.close(fig)
                print(f"  Saved: {os.path.basename(pareto_path)}")

            print(f"Pareto charts folder: {pareto_dir}")
        else:
            print("Skipping scatter plots: no significant correlations.")

        # ==========================================================
        # POOLED ANALYSIS
        # Average electrical parameters across nIouLane for each
        # (VisualID, Endpoint, sIou), then re-run correlation +
        # charts on this pooled dataset.
        # ==========================================================

        # Pool: mean of elec cols per (VisualID, sIou, Endpoint)
        pool_keys = [elec_join_key, "sIou", "Endpoint", "_sub_key"]
        elec_num_cols = elec_cols_unique  # already deduped
        pooled_elec = (
            elec_for_merge[[elec_join_key, "Endpoint", "sIou", "_sub_key"] + elec_num_cols]
            .copy()
        )
        for c in elec_num_cols:
            pooled_elec[c] = pd.to_numeric(pooled_elec[c], errors='coerce')
        pooled_elec = (
            pooled_elec.groupby(pool_keys, as_index=False)[elec_num_cols].mean()
        )

        # Join pooled electrical with HVM
        merged_pool = pooled_elec.merge(
            df_hvm[hvm_keep],
            left_on=[elec_join_key, "_sub_key"],
            right_on=[hvm_join_key, "_sub_key"],
            how="inner"
        )
        for col in hvm_features + elec_num_cols:
            merged_pool[col] = pd.to_numeric(merged_pool[col], errors='coerce')
        merged_pool.replace([np.inf, -np.inf], np.nan, inplace=True)
        print(f"\nPooled merged rows (mean across lanes per VisualID/sIou/Endpoint): {len(merged_pool)}")

        # Per-group (sIou x Endpoint) Pearson on pooled data
        # Use a lower threshold since lane-averaging reduces N considerably
        POOL_GROUP_COLS = ["sIou", "Endpoint"]
        POOL_MIN_SAMPLES = 5
        pool_sig_list = []
        pool_summary = []

        for grp_key, gdf in merged_pool.groupby(POOL_GROUP_COLS, dropna=False):
            siou_p, ep_p = grp_key
            sub = gdf[hvm_features + elec_num_cols].dropna()
            n = len(sub)
            if n < POOL_MIN_SAMPLES:
                continue

            pool_r_mat = pd.DataFrame(index=hvm_features, columns=elec_num_cols, dtype=float)
            pool_p_mat = pd.DataFrame(index=hvm_features, columns=elec_num_cols, dtype=float)
            for h in hvm_features:
                for e in elec_num_cols:
                    if sub[h].nunique() <= 1 or sub[e].nunique() <= 1:
                        r, p = 0.0, 1.0
                    else:
                        r, p = pearsonr(sub[h], sub[e])
                    pool_r_mat.loc[h, e] = r
                    pool_p_mat.loc[h, e] = p
                    if p < 0.05:
                        pool_sig_list.append({
                            'Endpoint': ep_p, 'sIou': siou_p,
                            'n_samples': n,
                            'hvm_parameter': h,
                            'electrical_parameter': e,
                            'pearson_r': r, 'p_value': p
                        })

            tag_p = f"{safe_name(ep_p)}__{safe_name(siou_p)}"
            pool_dir = os.path.join(results_dir, f"pooled_per_group_{RUN_TS}")
            os.makedirs(pool_dir, exist_ok=True)
            pool_r_mat.to_csv(os.path.join(pool_dir, f"r_{tag_p}.csv"))
            pool_p_mat.to_csv(os.path.join(pool_dir, f"p_{tag_p}.csv"))

            top_p = max(pool_sig_list[-len(pool_sig_list):],
                        key=lambda d: abs(d['pearson_r']), default=None) \
                if pool_sig_list else None
            pool_summary.append({
                'Endpoint': ep_p, 'sIou': siou_p,
                'n_samples': n,
                'n_significant_pairs': sum(
                    1 for d in pool_sig_list
                    if d['Endpoint'] == ep_p and d['sIou'] == siou_p
                ),
            })

        df_pool_sig = pd.DataFrame(pool_sig_list)
        if not df_pool_sig.empty:
            df_pool_sig['abs_r'] = df_pool_sig['pearson_r'].abs()
            df_pool_sig = df_pool_sig.sort_values(
                'abs_r', ascending=False).drop(columns=['abs_r'])
        df_pool_sig.to_csv(
            os.path.join(results_dir, "pooled_significant_correlations.csv"), index=False)
        pd.DataFrame(pool_summary).to_csv(
            os.path.join(results_dir, "pooled_group_summary.csv"), index=False)

        print("\nPooled � Strongest 15 Absolute Correlations (p < 0.05):")
        if not df_pool_sig.empty:
            print(df_pool_sig.head(15).to_string(index=False))
        else:
            print("No significant pooled correlations found.")

        # ---- Pooled scatter charts ----
        if not df_pool_sig.empty:
            pool_scatter_dir = os.path.join(
                results_dir, f"pooled_scatter_top{TOP_N_SCATTER}_{RUN_TS}")
            os.makedirs(pool_scatter_dir, exist_ok=True)

            df_pool_unique = (df_pool_sig
                              .assign(_abs_r=lambda d: d['pearson_r'].abs())
                              .sort_values('_abs_r', ascending=False)
                              .drop_duplicates(
                                  subset=['Endpoint', 'sIou',
                                          'hvm_parameter', 'electrical_parameter'],
                                  keep='first')
                              .drop(columns='_abs_r')
                              .reset_index(drop=True))
            top_pool = df_pool_unique.head(TOP_N_SCATTER).reset_index(drop=True)
            n_pool = len(top_pool)

            # Individual PNGs: scatter with fit line, one point per pooled unit
            for i, row in top_pool.iterrows():
                h = row['hvm_parameter']; e = row['electrical_parameter']
                ep_p = row['Endpoint']; siou_p = row['sIou']
                mask = ((merged_pool['Endpoint'] == ep_p) &
                        (merged_pool['sIou'] == siou_p))
                sub = merged_pool.loc[mask, [elec_join_key, h, e]].dropna()
                x = sub[h].to_numpy(); y = sub[e].to_numpy()
                n_pts = len(x)
                r_val = float(row['pearson_r']); p_val = float(row['p_value'])

                fig, ax = plt.subplots(figsize=(9, 6.5))
                ids_in_plot = scatter_by_visualid(
                    ax, sub, h, e, elec_join_key,
                    marker_size=32, alpha=0.75, edge_width=0.4,
                    show_legend=True, legend_fontsize=7
                )
                if n_pts >= 2 and np.std(x) > 0:
                    slope, intercept = np.polyfit(x, y, 1)
                    xline = np.linspace(np.min(x), np.max(x), 100)
                    ax.plot(xline, slope * xline + intercept,
                            color='red', linewidth=2.0, zorder=5,
                            label=f"fit: y = {slope:.4g}�x + {intercept:.4g}")
                    ax.legend(fontsize=8, loc='best')
                ax.set_xlabel(h, fontsize=9)
                ax.set_ylabel(e, fontsize=10)
                ax.set_title(
                    f"[POOLED] #{i+1}  {h}  vs  {e}\n"
                    f"Endpoint={ep_p}   sIou={siou_p}   "
                    f"(lane-averaged per VisualID; color=VisualID, IDs={len(ids_in_plot)})\n"
                    f"Pearson r = {r_val:.4f}   p = {p_val:.2e}   N = {n_pts}",
                    fontsize=10, fontweight='bold'
                )
                ax.grid(True, alpha=0.25)
                fig.tight_layout()
                fname = (f"pooled_scatter_{i+1:02d}_"
                         f"{safe_name(ep_p)}__{safe_name(siou_p)}__"
                         f"{h}__{e}.png")
                out_path = os.path.join(pool_scatter_dir, fname)
                fig.savefig(out_path, dpi=SCATTER_DPI, bbox_inches='tight')
                plt.close(fig)
                print(f"  Saved: {os.path.basename(out_path)}")

            # Combined panel
            ncols = min(n_pool, 3) if n_pool > 0 else 1
            nrows = int(np.ceil(n_pool / ncols)) if n_pool > 0 else 1
            fig, axes = plt.subplots(nrows, ncols,
                                     figsize=(7 * ncols, 5.5 * nrows))
            axes = np.array(axes).reshape(-1)
            for i, row in top_pool.iterrows():
                h = row['hvm_parameter']; e = row['electrical_parameter']
                ep_p = row['Endpoint']; siou_p = row['sIou']
                mask = ((merged_pool['Endpoint'] == ep_p) &
                        (merged_pool['sIou'] == siou_p))
                sub = merged_pool.loc[mask, [elec_join_key, h, e]].dropna()
                x = sub[h].to_numpy(); y = sub[e].to_numpy()
                ax = axes[i]
                scatter_by_visualid(
                    ax, sub, h, e, elec_join_key,
                    marker_size=22, alpha=0.75, edge_width=0.3,
                    show_legend=True, legend_fontsize=6
                )
                if len(x) >= 2 and np.std(x) > 0:
                    slope, intercept = np.polyfit(x, y, 1)
                    xline = np.linspace(np.min(x), np.max(x), 100)
                    ax.plot(xline, slope * xline + intercept,
                            color='red', linewidth=1.6, zorder=5)
                ax.set_xlabel(h, fontsize=7)
                ax.set_ylabel(e, fontsize=8)
                ax.set_title(
                    f"#{i+1}  {ep_p}/{siou_p}\n"
                    f"r={float(row['pearson_r']):.3f}  p={float(row['p_value']):.2e}",
                    fontsize=8, fontweight='bold'
                )
                ax.grid(True, alpha=0.25)
                ax.tick_params(axis='both', labelsize=7)
            for j in range(n_pool, len(axes)):
                axes[j].set_visible(False)
            fig.suptitle(
                f"[POOLED] Top {n_pool} HVM ? Electrical Correlations "
                f"(lane-averaged per VisualID/sIou/Endpoint)",
                fontsize=13, fontweight='bold'
            )
            fig.tight_layout(rect=[0, 0, 1, 0.95])
            pool_panel = os.path.join(
                pool_scatter_dir, f"pooled_scatter_top{TOP_N_SCATTER}_panel.png")
            fig.savefig(pool_panel, dpi=SCATTER_DPI, bbox_inches='tight')
            plt.close(fig)
            print(f"  Saved: {os.path.basename(pool_panel)}")

            # Per-sIou top-10 pooled charts (5 per figure)
            pool_ep_dir = os.path.join(
                results_dir, f"pooled_per_siou_top{TOP_N_PER_ENDPOINT}_{RUN_TS}")
            os.makedirs(pool_ep_dir, exist_ok=True)
            df_pool_unique_all = (df_pool_sig
                                  .assign(_abs_r=lambda d: d['pearson_r'].abs())
                                  .sort_values('_abs_r', ascending=False)
                                  .drop_duplicates(
                                      subset=['Endpoint', 'sIou',
                                              'hvm_parameter', 'electrical_parameter'],
                                      keep='first')
                                  .drop(columns='_abs_r'))
            for siou_p, df_siou_p in df_pool_unique_all.groupby('sIou'):
                top_siou_p = df_siou_p.head(TOP_N_PER_ENDPOINT).reset_index(drop=True)
                n_siou_p = len(top_siou_p)
                if n_siou_p == 0:
                    continue
                CHUNK = 5
                n_chunks = int(np.ceil(n_siou_p / CHUNK))
                for chunk_idx in range(n_chunks):
                    start = chunk_idx * CHUNK
                    end = min(start + CHUNK, n_siou_p)
                    chunk_df = top_siou_p.iloc[start:end].reset_index(drop=True)
                    n_c = len(chunk_df)
                    ncols_ep = min(n_c, 3)
                    nrows_ep = int(np.ceil(n_c / ncols_ep))
                    fig, axes = plt.subplots(
                        nrows_ep, ncols_ep,
                        figsize=(7 * ncols_ep, 5.5 * nrows_ep))
                    axes = np.array(axes).reshape(-1)
                    for i, row in chunk_df.iterrows():
                        rank = start + i + 1
                        h = row['hvm_parameter']; e = row['electrical_parameter']
                        ep_p = row['Endpoint']
                        mask = ((merged_pool['Endpoint'] == ep_p) &
                            (merged_pool['sIou'] == siou_p))
                        sub = merged_pool.loc[mask, [elec_join_key, h, e]].dropna()
                        x = sub[h].to_numpy(); y = sub[e].to_numpy()
                        ax = axes[i]
                        if len(sub) == 0:
                            ax.set_visible(False)
                            continue
                        scatter_by_visualid(
                            ax, sub, h, e, elec_join_key,
                            marker_size=22, alpha=0.75, edge_width=0.3,
                            show_legend=True, legend_fontsize=6
                        )
                        if len(x) >= 2 and np.std(x) > 0:
                            slope, intercept = np.polyfit(x, y, 1)
                            xline = np.linspace(np.min(x), np.max(x), 100)
                            ax.plot(xline, slope * xline + intercept,
                                    color='red', linewidth=1.6, zorder=5)
                        ax.set_xlabel(h, fontsize=7)
                        ax.set_ylabel(e, fontsize=8)
                        ax.set_title(
                            f"#{rank}  Endpoint={ep_p}   "
                            f"r={float(row['pearson_r']):.3f}  "
                            f"p={float(row['p_value']):.2e}  N={len(x)}",
                            fontsize=8, fontweight='bold'
                        )
                        ax.grid(True, alpha=0.25)
                        ax.tick_params(axis='both', labelsize=7)
                    for j in range(n_c, len(axes)):
                        axes[j].set_visible(False)
                    fig.suptitle(
                        f"[POOLED] sIou = {siou_p}   �   Top {n_siou_p} "
                        f"HVM ? Electrical Correlations  "
                        f"(part {chunk_idx + 1}/{n_chunks}: ranks {start+1}-{end})",
                        fontsize=13, fontweight='bold'
                    )
                    fig.tight_layout(rect=[0, 0, 1, 0.96])
                    ep_path = os.path.join(
                        pool_ep_dir,
                        f"pooled_siou_top{TOP_N_PER_ENDPOINT}_{safe_name(siou_p)}"
                        f"_part{chunk_idx + 1}.png"
                    )
                    fig.savefig(ep_path, dpi=SCATTER_DPI, bbox_inches='tight')
                    plt.close(fig)
                    print(f"  Saved: {os.path.basename(ep_path)}")
            print(f"Pooled per-sIou charts folder: {pool_ep_dir}")

            # ----------------------------------------------------------
            # POOLED VOC Parameters per sIou
            # For each sIou, create a 3-subplot figure showing
            # vocDH_MINmV, vocDM_MINmV, vocDL_MINmV with their
            # strongest HVM correlations (pooled data).
            # ----------------------------------------------------------
            pool_voc_dir = os.path.join(
                results_dir, f"pooled_voc_per_siou_{RUN_TS}")
            os.makedirs(pool_voc_dir, exist_ok=True)

            for siou_p in merged_pool['sIou'].dropna().unique():
                fig, axes = plt.subplots(1, 3, figsize=(21, 6))

                for subplot_idx, voc_param in enumerate(VOC_PARAMS):
                    ax = axes[subplot_idx]

                    # Find the strongest correlation for this VOC param and sIou in pooled data
                    ep_voc_rows = df_pool_sig[(df_pool_sig['sIou'] == siou_p) &
                                              (df_pool_sig['electrical_parameter'] == voc_param)]

                    if ep_voc_rows.empty:
                        ax.text(0.5, 0.5, f"No correlations found\nfor {voc_param}",
                               ha='center', va='center', transform=ax.transAxes,
                               fontsize=10)
                        continue

                    top_row = ep_voc_rows.loc[ep_voc_rows['pearson_r'].abs().idxmax()]
                    h = top_row['hvm_parameter']
                    ep_p = top_row['Endpoint']
                    r_val = float(top_row['pearson_r'])
                    p_val = float(top_row['p_value'])

                    # Get pooled data for this sIou at the strongest Endpoint
                    mask = ((merged_pool['Endpoint'] == ep_p) &
                            (merged_pool['sIou'] == siou_p))
                    sub = merged_pool.loc[mask, [elec_join_key, h, voc_param]].dropna()

                    if sub.empty:
                        ax.text(0.5, 0.5, f"No data for {voc_param}",
                               ha='center', va='center', transform=ax.transAxes,
                               fontsize=10)
                        continue

                    x = sub[h].to_numpy()
                    y = sub[voc_param].to_numpy()

                    ids_in_plot = scatter_by_visualid(
                        ax, sub, h, voc_param, elec_join_key,
                        marker_size=22, alpha=0.75, edge_width=0.3,
                        show_legend=(subplot_idx == 0), legend_fontsize=6
                    )
                    if len(x) >= 2 and np.std(x) > 0:
                        slope, intercept = np.polyfit(x, y, 1)
                        xline = np.linspace(np.min(x), np.max(x), 100)
                        ax.plot(xline, slope * xline + intercept,
                                color='red', linewidth=1.6, zorder=5)

                    ax.set_xlabel(h, fontsize=8)
                    ax.set_ylabel(voc_param, fontsize=9)
                    ax.set_title(
                        f"{voc_param} vs {h}\n"
                        f"sIou={siou_p}  Endpoint={ep_p}  "
                        f"IDs={len(ids_in_plot)}  "
                        f"r={r_val:.3f}  p={p_val:.2e}  N={len(x)}",
                        fontsize=9, fontweight='bold'
                    )
                    ax.grid(True, alpha=0.25)
                    ax.tick_params(axis='both', labelsize=7)

                fig.suptitle(
                    f"[POOLED] VOC Parameters by sIou = {siou_p}  �  "
                    f"Strongest HVM Correlations (lane-averaged)",
                    fontsize=12, fontweight='bold'
                )
                fig.tight_layout(rect=[0, 0, 1, 0.96])
                pool_voc_path = os.path.join(
                    pool_voc_dir, f"pooled_voc_{safe_name(siou_p)}.png")
                fig.savefig(pool_voc_path, dpi=SCATTER_DPI, bbox_inches='tight')
                plt.close(fig)
                print(f"  Saved: {os.path.basename(pool_voc_path)}")

            print(f"Pooled VOC per-sIou charts folder: {pool_voc_dir}")

            # ----------------------------------------------------------
            # Pareto plot per sIou (pooled analysis)
            # Same layout as per-lane Pareto but using pooled correlations.
            # Bars colored by Endpoint.
            # ----------------------------------------------------------
            pool_pareto_dir = os.path.join(
                results_dir, f"pooled_pareto_per_siou_{RUN_TS}")
            os.makedirs(pool_pareto_dir, exist_ok=True)

            all_endpoint_p = sorted(df_pool_sig['Endpoint'].dropna().unique())
            endpoint_cmap_p = plt.get_cmap('tab10', max(len(all_endpoint_p), 1))
            endpoint_colors_p = {e: endpoint_cmap_p(i) for i, e in enumerate(all_endpoint_p)}

            for siou_p in df_pool_sig['sIou'].dropna().unique():
                df_siou_p = (
                    df_pool_sig[df_pool_sig['sIou'] == siou_p]
                    .assign(_abs_r=lambda d: d['pearson_r'].abs())
                    .sort_values('_abs_r', ascending=False)
                    .drop_duplicates(
                        subset=['hvm_parameter', 'electrical_parameter'],
                        keep='first'
                    )
                    .head(TOP_N_PARETO)
                    .reset_index(drop=True)
                )
                if df_siou_p.empty:
                    continue

                n_pairs_p = len(df_siou_p)
                labels_p = [
                    f"{_short(row['hvm_parameter'])} | {row['electrical_parameter']}"
                    for _, row in df_siou_p.iterrows()
                ]
                abs_r_p = df_siou_p['_abs_r'].to_numpy()
                cum_pct_p = np.cumsum(abs_r_p) / abs_r_p.sum() * 100
                bar_colors_p = [endpoint_colors_p.get(e, 'gray') for e in df_siou_p['Endpoint']]

                fig_height_p = max(6, 0.35 * n_pairs_p + 2)
                fig, ax1 = plt.subplots(figsize=(13, fig_height_p))
                ax2 = ax1.twinx()

                y_pos_p = np.arange(n_pairs_p)
                ax1.barh(y_pos_p, abs_r_p[::-1], color=bar_colors_p[::-1],
                         edgecolor='k', linewidth=0.4, height=0.7)
                ax2.plot(cum_pct_p[::-1], y_pos_p, color='black',
                         marker='o', markersize=4, linewidth=1.6,
                         zorder=5)

                ax1.set_yticks(y_pos_p)
                ax1.set_yticklabels(labels_p[::-1], fontsize=7)
                ax1.set_xlabel('|Pearson r|', fontsize=10)
                ax1.set_xlim(0, 1.05)
                ax2.set_ylabel('Cumulative % of total |r|', fontsize=9)
                ax2.set_ylim(0, 110)
                ax2.yaxis.set_major_formatter(
                    plt.FuncFormatter(lambda v, _: f'{v:.0f}%')
                )

                from matplotlib.patches import Patch
                legend_handles_p = [
                    Patch(facecolor=endpoint_colors_p[e], edgecolor='k',
                          linewidth=0.5, label=e)
                    for e in all_endpoint_p if e in df_siou_p['Endpoint'].values
                ]
                ax1.legend(handles=legend_handles_p, title='Endpoint',
                           fontsize=8, title_fontsize=8,
                           loc='lower right', framealpha=0.85)

                ax1.grid(axis='x', alpha=0.3)
                fig.suptitle(
                    f"[POOLED] Pareto � HVM ? Electrical Correlations  |  sIou = {siou_p}\n"
                    f"({n_pairs_p} unique HVM�Elec pairs, lane-averaged, sorted by |r|, colored by Endpoint)",
                    fontsize=11, fontweight='bold'
                )
                fig.tight_layout(rect=[0, 0, 1, 0.95])
                pool_pareto_path = os.path.join(
                    pool_pareto_dir, f"pooled_pareto_{safe_name(siou_p)}.png")
                fig.savefig(pool_pareto_path, dpi=SCATTER_DPI, bbox_inches='tight')
                plt.close(fig)
                print(f"  Saved: {os.path.basename(pool_pareto_path)}")

            print(f"Pooled Pareto charts folder: {pool_pareto_dir}")

        # ==========================================================
        # ELECTRICAL-TO-ELECTRICAL CORRELATIONS
        # Correlate electrical parameters among themselves
        # across all groups, lanes, and combinations.
        # ==========================================================
        print("\n" + "="*60)
        print("ELECTRICAL-TO-ELECTRICAL CORRELATION ANALYSIS")
        print("="*60)

        # Per-group Pearson correlation of electrical parameters with each other
        elec_ee_all_sig = []
        elec_ee_group_summary = []

        grouped_ee = merged.groupby(GROUP_COLS, dropna=False)
        n_groups_ee_total = grouped_ee.ngroups
        n_groups_ee_used = 0

        ee_per_group_dir = os.path.join(results_dir, f"ee_per_group_{RUN_TS}")
        os.makedirs(ee_per_group_dir, exist_ok=True)

        for grp_key, gdf in grouped_ee:
            ep, siou, lane = grp_key
            sub = gdf[elec_cols_unique].dropna()
            n = len(sub)
            if n < MIN_GROUP_SAMPLES:
                continue

            n_groups_ee_used += 1
            tag = f"{safe_name(ep)}__{safe_name(siou)}__lane{safe_name(lane)}"
            
            # Compute all pairwise correlations within electrical parameters
            ee_r_mat = pd.DataFrame(index=elec_cols_unique, columns=elec_cols_unique, dtype=float)
            ee_p_mat = pd.DataFrame(index=elec_cols_unique, columns=elec_cols_unique, dtype=float)
            ee_sig_rows = []

            for i, e1 in enumerate(elec_cols_unique):
                for j, e2 in enumerate(elec_cols_unique):
                    if i >= j:  # Skip self-correlations and duplicates
                        continue
                    if sub[e1].nunique() <= 1 or sub[e2].nunique() <= 1:
                        r, p = 0.0, 1.0
                    else:
                        r, p = pearsonr(sub[e1], sub[e2])
                    ee_r_mat.loc[e1, e2] = r
                    ee_p_mat.loc[e1, e2] = p
                    if p < 0.05:
                        ee_sig_rows.append({
                            'Endpoint': ep, 'sIou': siou, 'nIouLane': lane,
                            'n_samples': n,
                            'electrical_param_1': e1,
                            'electrical_param_2': e2,
                            'pearson_r': r, 'p_value': p
                        })

            ee_r_mat.to_csv(os.path.join(ee_per_group_dir, f"ee_r_{tag}.csv"))
            ee_p_mat.to_csv(os.path.join(ee_per_group_dir, f"ee_p_{tag}.csv"))

            top_ee_in_group = None
            if ee_sig_rows:
                top_ee_in_group = max(ee_sig_rows, key=lambda d: abs(d['pearson_r']))
            elec_ee_group_summary.append({
                'Endpoint': ep, 'sIou': siou, 'nIouLane': lane,
                'n_samples': n,
                'n_significant_pairs': len(ee_sig_rows),
                'top_electrical_1': top_ee_in_group['electrical_param_1'] if top_ee_in_group else '',
                'top_electrical_2': top_ee_in_group['electrical_param_2'] if top_ee_in_group else '',
                'top_pearson_r': top_ee_in_group['pearson_r'] if top_ee_in_group else np.nan,
                'top_p_value': top_ee_in_group['p_value'] if top_ee_in_group else np.nan,
            })

            elec_ee_all_sig.extend(ee_sig_rows)

        print(f"Groups (E-E): {n_groups_ee_used}/{n_groups_ee_total} met "
              f"min samples >= {MIN_GROUP_SAMPLES}")

        # Aggregated E-E sig table sorted by |r|
        df_ee_sig = pd.DataFrame(elec_ee_all_sig)
        if not df_ee_sig.empty:
            df_ee_sig['abs_r'] = df_ee_sig['pearson_r'].abs()
            df_ee_sig = df_ee_sig.sort_values('abs_r', ascending=False).drop(columns=['abs_r'])
        df_ee_sig.to_csv(os.path.join(results_dir, "ee_significant_correlations.csv"), index=False)

        df_ee_grp = pd.DataFrame(elec_ee_group_summary).sort_values(
            'top_pearson_r', key=lambda s: s.abs(), ascending=False, na_position='last'
        )
        df_ee_grp.to_csv(os.path.join(results_dir, "ee_group_summary.csv"), index=False)

        print(f"Results saved to folder: {results_dir}")
        print(f"Per-group E-E matrices in: {ee_per_group_dir}")
        print("\nStrongest 15 Absolute E-E Correlations (p < 0.05) across all groups:")
        if not df_ee_sig.empty:
            print(df_ee_sig.head(15).to_string(index=False))
        else:
            print("No significant E-E correlations found.")

        # ----------------------------------------------------------
        # E-E Scatter charts for the top-N correlations across all groups
        # ----------------------------------------------------------
        if not df_ee_sig.empty:
            ee_scatter_dir = os.path.join(results_dir, f"ee_scatter_top{TOP_N_SCATTER}_{RUN_TS}")
            os.makedirs(ee_scatter_dir, exist_ok=True)

            # Pick top-N UNIQUE (Endpoint, sIou, elec1, elec2) tuples
            df_ee_unique = (df_ee_sig
                            .assign(_abs_r=lambda d: d['pearson_r'].abs())
                            .sort_values('_abs_r', ascending=False)
                            .drop_duplicates(
                                subset=['Endpoint', 'sIou',
                                        'electrical_param_1', 'electrical_param_2'],
                                keep='first')
                            .drop(columns='_abs_r')
                            .reset_index(drop=True))
            top_ee = df_ee_unique.head(TOP_N_SCATTER).reset_index(drop=True)
            n_top_ee = len(top_ee)

            # ---- Individual overlay PNGs ----
            for i, row in top_ee.iterrows():
                e1 = row['electrical_param_1']
                e2 = row['electrical_param_2']
                ep = row['Endpoint']; siou = row['sIou']

                mask_es = ((merged['Endpoint'] == ep) &
                           (merged['sIou'] == siou))
                sub_es = merged.loc[mask_es, ['nIouLane', e1, e2]].dropna()
                if sub_es.empty:
                    continue

                lanes_present = sorted(sub_es['nIouLane'].dropna().unique())
                cmap = plt.get_cmap('tab20', max(len(lanes_present), 1))

                fig, ax = plt.subplots(figsize=(9, 6.5))

                # Per-lane scatter + per-lane Pearson + per-lane regression line
                for li, ln in enumerate(lanes_present):
                    sub_l = sub_es[sub_es['nIouLane'] == ln]
                    if len(sub_l) < 2:
                        continue
                    xl = sub_l[e1].to_numpy(); yl = sub_l[e2].to_numpy()
                    color = cmap(li)
                    if sub_l[e1].nunique() <= 1 or sub_l[e2].nunique() <= 1:
                        rl, pl = np.nan, np.nan
                    else:
                        rl, pl = pearsonr(xl, yl)

                    label = (f"L{ln} N={len(sub_l)} r={rl:.3f}"
                             if np.isfinite(rl) else f"L{ln} N={len(sub_l)}")
                    ax.scatter(xl, yl, s=22, alpha=0.7, edgecolor='k',
                               linewidth=0.3, color=color,
                               label=label, zorder=3)

                    # Per-lane regression line (color-matched)
                    if len(xl) >= 2 and np.std(xl) > 0:
                        slope, intercept = np.polyfit(xl, yl, 1)
                        xline = np.linspace(np.min(xl), np.max(xl), 50)
                        ax.plot(xline, slope * xline + intercept,
                                color=color, linewidth=1.8, alpha=0.9,
                                zorder=5)

                ax.set_xlabel(e1, fontsize=9)
                ax.set_ylabel(e2, fontsize=10)
                ax.set_title(
                    f"#{i+1}  {e1}  vs  {e2}\n"
                    f"Endpoint={ep}   sIou={siou}   "
                    f"(per-lane fits, all nIouLanes overlapped)",
                    fontsize=10, fontweight='bold'
                )
                ax.grid(True, alpha=0.25)
                ax.legend(fontsize=7, ncol=2, loc='best', framealpha=0.85)
                fig.tight_layout()

                fname = (f"ee_scatter_{i+1:02d}_"
                         f"{safe_name(ep)}__{safe_name(siou)}__allLanes__"
                         f"{e1}__{e2}.png")
                out_path = os.path.join(ee_scatter_dir, fname)
                fig.savefig(out_path, dpi=SCATTER_DPI, bbox_inches='tight')
                plt.close(fig)
                print(f"  Saved: {os.path.basename(out_path)}")

            # ---- Combined panel ----
            ncols = min(n_top_ee, 3) if n_top_ee > 0 else 1
            nrows = int(np.ceil(n_top_ee / ncols)) if n_top_ee > 0 else 1
            fig, axes = plt.subplots(nrows, ncols, figsize=(7 * ncols, 5.5 * nrows))
            axes = np.array(axes).reshape(-1)

            for i, row in top_ee.iterrows():
                e1 = row['electrical_param_1']; e2 = row['electrical_param_2']
                ep = row['Endpoint']; siou = row['sIou']
                mask_es = ((merged['Endpoint'] == ep) &
                           (merged['sIou'] == siou))
                sub_es = merged.loc[mask_es, ['nIouLane', e1, e2]].dropna()
                ax = axes[i]
                if sub_es.empty:
                    ax.set_visible(False)
                    continue

                lanes_present = sorted(sub_es['nIouLane'].dropna().unique())
                cmap = plt.get_cmap('tab20', max(len(lanes_present), 1))
                for li, ln in enumerate(lanes_present):
                    sub_l = sub_es[sub_es['nIouLane'] == ln]
                    color = cmap(li)
                    if len(sub_l) >= 2 and sub_l[e1].nunique() > 1 and sub_l[e2].nunique() > 1:
                        rl, pl = pearsonr(sub_l[e1].to_numpy(), sub_l[e2].to_numpy())
                        lane_label = f"L{ln} r={rl:.3f} p={pl:.1e}"
                    else:
                        lane_label = f"L{ln} r=NA"
                    ax.scatter(sub_l[e1], sub_l[e2], s=14, alpha=0.65,
                               edgecolor='k', linewidth=0.2,
                               color=color, label=lane_label, zorder=3)
                    if len(sub_l) >= 2 and sub_l[e1].nunique() > 1:
                        xl = sub_l[e1].to_numpy(); yl = sub_l[e2].to_numpy()
                        slope, intercept = np.polyfit(xl, yl, 1)
                        xline = np.linspace(np.min(xl), np.max(xl), 50)
                        ax.plot(xline, slope * xline + intercept,
                                color=color, linewidth=1.4, alpha=0.9, zorder=5)

                ax.set_xlabel(e1, fontsize=7)
                ax.set_ylabel(e2, fontsize=8)
                ax.set_title(
                    f"#{i+1}  {ep}/{siou}  (per-lane fits, all lanes)",
                    fontsize=8, fontweight='bold'
                )
                ax.grid(True, alpha=0.25)
                ax.tick_params(axis='both', labelsize=7)
                ax.legend(fontsize=6, ncol=4, loc='best', framealpha=0.8)

            for j in range(n_top_ee, len(axes)):
                axes[j].set_visible(False)

            fig.suptitle(
                f"Top {n_top_ee} Electrical ↔ Electrical Correlations  "
                f"(per sIou/Endpoint, all nIouLanes overlapped)",
                fontsize=13, fontweight='bold'
            )
            fig.tight_layout(rect=[0, 0, 1, 0.95])
            ee_panel_path = os.path.join(
                ee_scatter_dir, f"ee_scatter_top{TOP_N_SCATTER}_panel.png"
            )
            fig.savefig(ee_panel_path, dpi=SCATTER_DPI, bbox_inches='tight')
            plt.close(fig)
            print(f"  Saved: {os.path.basename(ee_panel_path)}")
            print(f"E-E Scatter charts folder: {ee_scatter_dir}")

            # ----------------------------------------------------------
            # Per-sIou top-10 E-E figure
            # ----------------------------------------------------------
            ee_endpoint_dir = os.path.join(
                results_dir, f"ee_per_siou_top{TOP_N_PER_ENDPOINT}_{RUN_TS}"
            )
            os.makedirs(ee_endpoint_dir, exist_ok=True)

            df_ee_unique_all = (df_ee_sig
                                .assign(_abs_r=lambda d: d['pearson_r'].abs())
                                .sort_values('_abs_r', ascending=False)
                                .drop_duplicates(
                                    subset=['Endpoint', 'sIou',
                                            'electrical_param_1', 'electrical_param_2'],
                                    keep='first')
                                .drop(columns='_abs_r'))

            for siou, df_siou in df_ee_unique_all.groupby('sIou'):
                top_siou = df_siou.head(TOP_N_PER_ENDPOINT).reset_index(drop=True)
                n_siou = len(top_siou)
                if n_siou == 0:
                    continue

                CHUNK = 5
                n_chunks = int(np.ceil(n_siou / CHUNK))
                for chunk_idx in range(n_chunks):
                    start = chunk_idx * CHUNK
                    end = min(start + CHUNK, n_siou)
                    chunk_df = top_siou.iloc[start:end].reset_index(drop=True)
                    n_c = len(chunk_df)

                    ncols_ep = min(n_c, 3)
                    nrows_ep = int(np.ceil(n_c / ncols_ep))
                    fig, axes = plt.subplots(
                        nrows_ep, ncols_ep,
                        figsize=(7 * ncols_ep, 5.5 * nrows_ep)
                    )
                    axes = np.array(axes).reshape(-1)

                    for i, row in chunk_df.iterrows():
                        rank = start + i + 1
                        e1 = row['electrical_param_1']; e2 = row['electrical_param_2']
                        ep = row['Endpoint']
                        mask_es = ((merged['Endpoint'] == ep) &
                                   (merged['sIou'] == siou))
                        sub_es = merged.loc[mask_es, ['nIouLane', e1, e2]].dropna()
                        ax = axes[i]
                        if sub_es.empty:
                            ax.set_visible(False)
                            continue

                        lanes_present = sorted(sub_es['nIouLane'].dropna().unique())
                        cmap = plt.get_cmap('tab20', max(len(lanes_present), 1))
                        for li, ln in enumerate(lanes_present):
                            sub_l = sub_es[sub_es['nIouLane'] == ln]
                            color = cmap(li)
                            if len(sub_l) >= 2 and sub_l[e1].nunique() > 1 and sub_l[e2].nunique() > 1:
                                rl, pl = pearsonr(sub_l[e1].to_numpy(), sub_l[e2].to_numpy())
                                lane_label = f"L{ln} r={rl:.3f} p={pl:.1e}"
                            else:
                                lane_label = f"L{ln} r=NA"
                            ax.scatter(sub_l[e1], sub_l[e2], s=14, alpha=0.65,
                                       edgecolor='k', linewidth=0.2,
                                       color=color, label=lane_label, zorder=3)
                            if len(sub_l) >= 2 and sub_l[e1].nunique() > 1:
                                xl = sub_l[e1].to_numpy(); yl = sub_l[e2].to_numpy()
                                slope, intercept = np.polyfit(xl, yl, 1)
                                xline = np.linspace(np.min(xl), np.max(xl), 50)
                                ax.plot(xline, slope * xline + intercept,
                                        color=color, linewidth=1.4, alpha=0.9,
                                        zorder=5)

                        ax.set_xlabel(e1, fontsize=7)
                        ax.set_ylabel(e2, fontsize=8)
                        ax.set_title(
                            f"#{rank}  Endpoint={ep}   "
                            f"r={float(row['pearson_r']):.3f}  "
                            f"p={float(row['p_value']):.2e}",
                            fontsize=8, fontweight='bold'
                        )
                        ax.grid(True, alpha=0.25)
                        ax.tick_params(axis='both', labelsize=7)
                        ax.legend(fontsize=6, ncol=4, loc='best', framealpha=0.8)

                    for j in range(n_c, len(axes)):
                        axes[j].set_visible(False)

                    fig.suptitle(
                        f"sIou = {siou}   ·   Top {n_siou} Electrical ↔ Electrical "
                        f"Correlations  (part {chunk_idx + 1}/{n_chunks}: "
                        f"ranks {start + 1}-{end})",
                        fontsize=13, fontweight='bold'
                    )
                    fig.tight_layout(rect=[0, 0, 1, 0.96])
                    ee_ep_path = os.path.join(
                        ee_endpoint_dir,
                        f"ee_siou_top{TOP_N_PER_ENDPOINT}_{safe_name(siou)}"
                        f"_part{chunk_idx + 1}.png"
                    )
                    fig.savefig(ee_ep_path, dpi=SCATTER_DPI, bbox_inches='tight')
                    plt.close(fig)
                    print(f"  Saved: {os.path.basename(ee_ep_path)}")
            print(f"Per-sIou E-E charts folder: {ee_endpoint_dir}")

            # ----------------------------------------------------------
            # E-E Pareto plot per sIou
            # ----------------------------------------------------------
            ee_pareto_dir = os.path.join(results_dir, f"ee_pareto_per_siou_{RUN_TS}")
            os.makedirs(ee_pareto_dir, exist_ok=True)

            all_endpoint_ee = sorted(df_ee_sig['Endpoint'].dropna().unique())
            endpoint_cmap_ee = plt.get_cmap('tab10', max(len(all_endpoint_ee), 1))
            endpoint_colors_ee = {e: endpoint_cmap_ee(i) for i, e in enumerate(all_endpoint_ee)}

            for siou in df_ee_sig['sIou'].dropna().unique():
                df_siou = (
                    df_ee_sig[df_ee_sig['sIou'] == siou]
                    .assign(_abs_r=lambda d: d['pearson_r'].abs())
                    .sort_values('_abs_r', ascending=False)
                    .drop_duplicates(
                        subset=['electrical_param_1', 'electrical_param_2'],
                        keep='first'
                    )
                    .head(TOP_N_PARETO)
                    .reset_index(drop=True)
                )
                if df_siou.empty:
                    continue

                n_pairs = len(df_siou)
                labels = [
                    f"{_short(row['electrical_param_1'])} | {row['electrical_param_2']}"
                    for _, row in df_siou.iterrows()
                ]
                abs_r = df_siou['_abs_r'].to_numpy()
                cum_pct = np.cumsum(abs_r) / abs_r.sum() * 100
                bar_colors = [endpoint_colors_ee.get(e, 'gray') for e in df_siou['Endpoint']]

                fig_height = max(6, 0.35 * n_pairs + 2)
                fig, ax1 = plt.subplots(figsize=(13, fig_height))
                ax2 = ax1.twinx()

                y_pos = np.arange(n_pairs)
                ax1.barh(y_pos, abs_r[::-1], color=bar_colors[::-1],
                         edgecolor='k', linewidth=0.4, height=0.7)
                ax2.plot(cum_pct[::-1], y_pos, color='black',
                         marker='o', markersize=4, linewidth=1.6,
                         zorder=5, label='Cumulative %')

                ax1.set_yticks(y_pos)
                ax1.set_yticklabels(labels[::-1], fontsize=7)
                ax1.set_xlabel('|Pearson r|', fontsize=10)
                ax1.set_xlim(0, 1.05)
                ax2.set_ylabel('Cumulative % of total |r|', fontsize=9)
                ax2.set_ylim(0, 110)
                ax2.yaxis.set_major_formatter(
                    plt.FuncFormatter(lambda v, _: f'{v:.0f}%')
                )

                legend_handles = [
                    Patch(facecolor=endpoint_colors_ee[e], edgecolor='k',
                          linewidth=0.5, label=e)
                    for e in all_endpoint_ee if e in df_siou['Endpoint'].values
                ]
                ax1.legend(handles=legend_handles, title='Endpoint',
                           fontsize=8, title_fontsize=8,
                           loc='lower right', framealpha=0.85)

                ax1.grid(axis='x', alpha=0.3)
                fig.suptitle(
                    f"Pareto · Electrical ↔ Electrical Correlations  |  sIou = {siou}\n"
                    f"({n_pairs} unique Elec↔Elec pairs, sorted by |r|, colored by Endpoint)",
                    fontsize=11, fontweight='bold'
                )
                fig.tight_layout(rect=[0, 0, 1, 0.95])
                ee_pareto_path = os.path.join(ee_pareto_dir, f"ee_pareto_{safe_name(siou)}.png")
                fig.savefig(ee_pareto_path, dpi=SCATTER_DPI, bbox_inches='tight')
                plt.close(fig)
                print(f"  Saved: {os.path.basename(ee_pareto_path)}")

            print(f"E-E Pareto charts folder: {ee_pareto_dir}")
        else:
            print("Skipping E-E scatter plots: no significant correlations.")

        # ==========================================================
        # POOLED ELECTRICAL-TO-ELECTRICAL ANALYSIS
        # ==========================================================
        print("\n" + "="*60)
        print("POOLED ELECTRICAL-TO-ELECTRICAL ANALYSIS")
        print("="*60)

        # Per-group (Endpoint x sIou) Pearson on pooled E-E data
        ee_pool_sig_list = []
        ee_pool_summary = []

        for grp_key, gdf in merged_pool.groupby(POOL_GROUP_COLS, dropna=False):
            siou_p, ep_p = grp_key
            sub = gdf[elec_num_cols].dropna()
            n = len(sub)
            if n < POOL_MIN_SAMPLES:
                continue

            ee_pool_r_mat = pd.DataFrame(index=elec_num_cols, columns=elec_num_cols, dtype=float)
            ee_pool_p_mat = pd.DataFrame(index=elec_num_cols, columns=elec_num_cols, dtype=float)
            for i, e1 in enumerate(elec_num_cols):
                for j, e2 in enumerate(elec_num_cols):
                    if i >= j:
                        continue
                    if sub[e1].nunique() <= 1 or sub[e2].nunique() <= 1:
                        r, p = 0.0, 1.0
                    else:
                        r, p = pearsonr(sub[e1], sub[e2])
                    ee_pool_r_mat.loc[e1, e2] = r
                    ee_pool_p_mat.loc[e1, e2] = p
                    if p < 0.05:
                        ee_pool_sig_list.append({
                            'Endpoint': ep_p, 'sIou': siou_p,
                            'n_samples': n,
                            'electrical_param_1': e1,
                            'electrical_param_2': e2,
                            'pearson_r': r, 'p_value': p
                        })

            tag_p = f"{safe_name(ep_p)}__{safe_name(siou_p)}"
            ee_pool_dir = os.path.join(results_dir, f"ee_pooled_per_group_{RUN_TS}")
            os.makedirs(ee_pool_dir, exist_ok=True)
            ee_pool_r_mat.to_csv(os.path.join(ee_pool_dir, f"ee_r_{tag_p}.csv"))
            ee_pool_p_mat.to_csv(os.path.join(ee_pool_dir, f"ee_p_{tag_p}.csv"))

            ee_pool_summary.append({
                'Endpoint': ep_p, 'sIou': siou_p,
                'n_samples': n,
                'n_significant_pairs': sum(
                    1 for d in ee_pool_sig_list
                    if d['Endpoint'] == ep_p and d['sIou'] == siou_p
                ),
            })

        df_ee_pool_sig = pd.DataFrame(ee_pool_sig_list)
        if not df_ee_pool_sig.empty:
            df_ee_pool_sig['abs_r'] = df_ee_pool_sig['pearson_r'].abs()
            df_ee_pool_sig = df_ee_pool_sig.sort_values(
                'abs_r', ascending=False).drop(columns=['abs_r'])
        df_ee_pool_sig.to_csv(
            os.path.join(results_dir, "ee_pooled_significant_correlations.csv"), index=False)

        print("\nPooled E-E · Strongest 15 Absolute Correlations (p < 0.05):")
        if not df_ee_pool_sig.empty:
            print(df_ee_pool_sig.head(15).to_string(index=False))
        else:
            print("No significant pooled E-E correlations found.")

        # ---- Pooled E-E scatter charts ----
        if not df_ee_pool_sig.empty:
            ee_pool_scatter_dir = os.path.join(
                results_dir, f"ee_pooled_scatter_top{TOP_N_SCATTER}_{RUN_TS}")
            os.makedirs(ee_pool_scatter_dir, exist_ok=True)

            df_ee_pool_unique = (df_ee_pool_sig
                                 .assign(_abs_r=lambda d: d['pearson_r'].abs())
                                 .sort_values('_abs_r', ascending=False)
                                 .drop_duplicates(
                                     subset=['Endpoint', 'sIou',
                                             'electrical_param_1', 'electrical_param_2'],
                                     keep='first')
                                 .drop(columns='_abs_r')
                                 .reset_index(drop=True))
            top_ee_pool = df_ee_pool_unique.head(TOP_N_SCATTER).reset_index(drop=True)
            n_ee_pool = len(top_ee_pool)

            # Individual PNGs
            for i, row in top_ee_pool.iterrows():
                e1 = row['electrical_param_1']; e2 = row['electrical_param_2']
                ep_p = row['Endpoint']; siou_p = row['sIou']
                mask = ((merged_pool['Endpoint'] == ep_p) &
                        (merged_pool['sIou'] == siou_p))
                sub = merged_pool.loc[mask, [e1, e2]].dropna()
                x = sub[e1].to_numpy(); y = sub[e2].to_numpy()
                n_pts = len(x)
                r_val = float(row['pearson_r']); p_val = float(row['p_value'])

                fig, ax = plt.subplots(figsize=(9, 6.5))
                ax.scatter(x, y, s=32, alpha=0.75, edgecolor='k',
                           linewidth=0.4, color='#2ca02c', zorder=3)
                if n_pts >= 2 and np.std(x) > 0:
                    slope, intercept = np.polyfit(x, y, 1)
                    xline = np.linspace(np.min(x), np.max(x), 100)
                    ax.plot(xline, slope * xline + intercept,
                            color='red', linewidth=2.0, zorder=5,
                            label=f"fit: y = {slope:.4g}·x + {intercept:.4g}")
                    ax.legend(fontsize=8, loc='best')
                ax.set_xlabel(e1, fontsize=9)
                ax.set_ylabel(e2, fontsize=10)
                ax.set_title(
                    f"[POOLED] #{i+1}  {e1}  vs  {e2}\n"
                    f"Endpoint={ep_p}   sIou={siou_p}   "
                    f"(lane-averaged per VisualID)\n"
                    f"Pearson r = {r_val:.4f}   p = {p_val:.2e}   N = {n_pts}",
                    fontsize=10, fontweight='bold'
                )
                ax.grid(True, alpha=0.25)
                fig.tight_layout()
                fname = (f"ee_pooled_scatter_{i+1:02d}_"
                         f"{safe_name(ep_p)}__{safe_name(siou_p)}__"
                         f"{e1}__{e2}.png")
                out_path = os.path.join(ee_pool_scatter_dir, fname)
                fig.savefig(out_path, dpi=SCATTER_DPI, bbox_inches='tight')
                plt.close(fig)
                print(f"  Saved: {os.path.basename(out_path)}")

            # Combined panel
            ncols = min(n_ee_pool, 3) if n_ee_pool > 0 else 1
            nrows = int(np.ceil(n_ee_pool / ncols)) if n_ee_pool > 0 else 1
            fig, axes = plt.subplots(nrows, ncols, figsize=(7 * ncols, 5.5 * nrows))
            axes = np.array(axes).reshape(-1)
            for i, row in top_ee_pool.iterrows():
                e1 = row['electrical_param_1']; e2 = row['electrical_param_2']
                ep_p = row['Endpoint']; siou_p = row['sIou']
                mask = ((merged_pool['Endpoint'] == ep_p) &
                        (merged_pool['sIou'] == siou_p))
                sub = merged_pool.loc[mask, [e1, e2]].dropna()
                x = sub[e1].to_numpy(); y = sub[e2].to_numpy()
                ax = axes[i]
                ax.scatter(x, y, s=22, alpha=0.75, edgecolor='k',
                           linewidth=0.3, color='#2ca02c', zorder=3)
                if len(x) >= 2 and np.std(x) > 0:
                    slope, intercept = np.polyfit(x, y, 1)
                    xline = np.linspace(np.min(x), np.max(x), 100)
                    ax.plot(xline, slope * xline + intercept,
                            color='red', linewidth=1.6, zorder=5)
                ax.set_xlabel(e1, fontsize=7)
                ax.set_ylabel(e2, fontsize=8)
                ax.set_title(
                    f"#{i+1}  {ep_p}/{siou_p}\n"
                    f"r={float(row['pearson_r']):.3f}  p={float(row['p_value']):.2e}",
                    fontsize=8, fontweight='bold'
                )
                ax.grid(True, alpha=0.25)
                ax.tick_params(axis='both', labelsize=7)
            for j in range(n_ee_pool, len(axes)):
                axes[j].set_visible(False)
            fig.suptitle(
                f"[POOLED] Top {n_ee_pool} Electrical ↔ Electrical Correlations "
                f"(lane-averaged per VisualID/sIou/Endpoint)",
                fontsize=13, fontweight='bold'
            )
            fig.tight_layout(rect=[0, 0, 1, 0.95])
            ee_pool_panel = os.path.join(
                ee_pool_scatter_dir, f"ee_pooled_scatter_top{TOP_N_SCATTER}_panel.png")
            fig.savefig(ee_pool_panel, dpi=SCATTER_DPI, bbox_inches='tight')
            plt.close(fig)
            print(f"  Saved: {os.path.basename(ee_pool_panel)}")

            # Per-sIou top-10 pooled E-E charts
            ee_pool_ep_dir = os.path.join(
                results_dir, f"ee_pooled_per_siou_top{TOP_N_PER_ENDPOINT}_{RUN_TS}")
            os.makedirs(ee_pool_ep_dir, exist_ok=True)
            df_ee_pool_unique_all = (df_ee_pool_sig
                                     .assign(_abs_r=lambda d: d['pearson_r'].abs())
                                     .sort_values('_abs_r', ascending=False)
                                     .drop_duplicates(
                                         subset=['Endpoint', 'sIou',
                                                 'electrical_param_1', 'electrical_param_2'],
                                         keep='first')
                                     .drop(columns='_abs_r'))
            for siou_p, df_siou_p in df_ee_pool_unique_all.groupby('sIou'):
                top_siou_p = df_siou_p.head(TOP_N_PER_ENDPOINT).reset_index(drop=True)
                n_siou_p = len(top_siou_p)
                if n_siou_p == 0:
                    continue
                CHUNK = 5
                n_chunks = int(np.ceil(n_siou_p / CHUNK))
                for chunk_idx in range(n_chunks):
                    start = chunk_idx * CHUNK
                    end = min(start + CHUNK, n_siou_p)
                    chunk_df = top_siou_p.iloc[start:end].reset_index(drop=True)
                    n_c = len(chunk_df)
                    ncols_ep = min(n_c, 3)
                    nrows_ep = int(np.ceil(n_c / ncols_ep))
                    fig, axes = plt.subplots(
                        nrows_ep, ncols_ep,
                        figsize=(7 * ncols_ep, 5.5 * nrows_ep))
                    axes = np.array(axes).reshape(-1)
                    for i, row in chunk_df.iterrows():
                        rank = start + i + 1
                        e1 = row['electrical_param_1']; e2 = row['electrical_param_2']
                        ep_p = row['Endpoint']
                        mask = ((merged_pool['Endpoint'] == ep_p) &
                            (merged_pool['sIou'] == siou_p))
                        sub = merged_pool.loc[mask, [e1, e2]].dropna()
                        x = sub[e1].to_numpy(); y = sub[e2].to_numpy()
                        ax = axes[i]
                        if len(sub) == 0:
                            ax.set_visible(False)
                            continue
                        ax.scatter(x, y, s=22, alpha=0.75, edgecolor='k',
                                   linewidth=0.3, color='#2ca02c', zorder=3)
                        if len(x) >= 2 and np.std(x) > 0:
                            slope, intercept = np.polyfit(x, y, 1)
                            xline = np.linspace(np.min(x), np.max(x), 100)
                            ax.plot(xline, slope * xline + intercept,
                                    color='red', linewidth=1.6, zorder=5)
                        ax.set_xlabel(e1, fontsize=7)
                        ax.set_ylabel(e2, fontsize=8)
                        ax.set_title(
                            f"#{rank}  Endpoint={ep_p}   "
                            f"r={float(row['pearson_r']):.3f}  "
                            f"p={float(row['p_value']):.2e}  N={len(x)}",
                            fontsize=8, fontweight='bold'
                        )
                        ax.grid(True, alpha=0.25)
                        ax.tick_params(axis='both', labelsize=7)
                    for j in range(n_c, len(axes)):
                        axes[j].set_visible(False)
                    fig.suptitle(
                        f"[POOLED] sIou = {siou_p}   ·   Top {n_siou_p} "
                        f"Electrical ↔ Electrical Correlations  "
                        f"(part {chunk_idx + 1}/{n_chunks}: ranks {start+1}-{end})",
                        fontsize=13, fontweight='bold'
                    )
                    fig.tight_layout(rect=[0, 0, 1, 0.96])
                    ee_ep_path = os.path.join(
                        ee_pool_ep_dir,
                        f"ee_pooled_siou_top{TOP_N_PER_ENDPOINT}_{safe_name(siou_p)}"
                        f"_part{chunk_idx + 1}.png"
                    )
                    fig.savefig(ee_ep_path, dpi=SCATTER_DPI, bbox_inches='tight')
                    plt.close(fig)
                    print(f"  Saved: {os.path.basename(ee_ep_path)}")
            print(f"Pooled per-sIou E-E charts folder: {ee_pool_ep_dir}")

            # Pooled E-E Pareto plot per sIou
            ee_pool_pareto_dir = os.path.join(
                results_dir, f"ee_pooled_pareto_per_siou_{RUN_TS}")
            os.makedirs(ee_pool_pareto_dir, exist_ok=True)

            all_endpoint_p = sorted(df_ee_pool_sig['Endpoint'].dropna().unique())
            endpoint_cmap_p = plt.get_cmap('tab10', max(len(all_endpoint_p), 1))
            endpoint_colors_p = {e: endpoint_cmap_p(i) for i, e in enumerate(all_endpoint_p)}

            for siou_p in df_ee_pool_sig['sIou'].dropna().unique():
                df_siou_p = (
                    df_ee_pool_sig[df_ee_pool_sig['sIou'] == siou_p]
                    .assign(_abs_r=lambda d: d['pearson_r'].abs())
                    .sort_values('_abs_r', ascending=False)
                    .drop_duplicates(
                        subset=['electrical_param_1', 'electrical_param_2'],
                        keep='first'
                    )
                    .head(TOP_N_PARETO)
                    .reset_index(drop=True)
                )
                if df_siou_p.empty:
                    continue

                n_pairs_p = len(df_siou_p)
                labels_p = [
                    f"{_short(row['electrical_param_1'])} | {row['electrical_param_2']}"
                    for _, row in df_siou_p.iterrows()
                ]
                abs_r_p = df_siou_p['_abs_r'].to_numpy()
                cum_pct_p = np.cumsum(abs_r_p) / abs_r_p.sum() * 100
                bar_colors_p = [endpoint_colors_p.get(e, 'gray') for e in df_siou_p['Endpoint']]

                fig_height_p = max(6, 0.35 * n_pairs_p + 2)
                fig, ax1 = plt.subplots(figsize=(13, fig_height_p))
                ax2 = ax1.twinx()

                y_pos_p = np.arange(n_pairs_p)
                ax1.barh(y_pos_p, abs_r_p[::-1], color=bar_colors_p[::-1],
                         edgecolor='k', linewidth=0.4, height=0.7)
                ax2.plot(cum_pct_p[::-1], y_pos_p, color='black',
                         marker='o', markersize=4, linewidth=1.6,
                         zorder=5)

                ax1.set_yticks(y_pos_p)
                ax1.set_yticklabels(labels_p[::-1], fontsize=7)
                ax1.set_xlabel('|Pearson r|', fontsize=10)
                ax1.set_xlim(0, 1.05)
                ax2.set_ylabel('Cumulative % of total |r|', fontsize=9)
                ax2.set_ylim(0, 110)
                ax2.yaxis.set_major_formatter(
                    plt.FuncFormatter(lambda v, _: f'{v:.0f}%')
                )

                legend_handles_p = [
                    Patch(facecolor=endpoint_colors_p[e], edgecolor='k',
                          linewidth=0.5, label=e)
                    for e in all_endpoint_p if e in df_siou_p['Endpoint'].values
                ]
                ax1.legend(handles=legend_handles_p, title='Endpoint',
                           fontsize=8, title_fontsize=8,
                           loc='lower right', framealpha=0.85)

                ax1.grid(axis='x', alpha=0.3)
                fig.suptitle(
                    f"[POOLED] Pareto · Electrical ↔ Electrical Correlations  |  sIou = {siou_p}\n"
                    f"({n_pairs_p} unique Elec↔Elec pairs, lane-averaged, sorted by |r|, colored by Endpoint)",
                    fontsize=11, fontweight='bold'
                )
                fig.tight_layout(rect=[0, 0, 1, 0.95])
                ee_pool_pareto_path = os.path.join(
                    ee_pool_pareto_dir, f"ee_pooled_pareto_{safe_name(siou_p)}.png")
                fig.savefig(ee_pool_pareto_path, dpi=SCATTER_DPI, bbox_inches='tight')
                plt.close(fig)
                print(f"  Saved: {os.path.basename(ee_pool_pareto_path)}")

            print(f"Pooled E-E Pareto charts folder: {ee_pool_pareto_dir}")
        else:
            print("Skipping pooled E-E scatter plots: no significant correlations.")

        # ----------------------------------------------------------
        # VOC Chain Analysis per sIou
        # IDV -> electrical intermediate -> VOC
        # Chain strength = |r_A| * |r_B|; all IDV params compete.
        # Both df_pool_sig (HVM->elec) and df_ee_sig (elec->elec) are
        # available here — after all correlation tables are built.
        # ----------------------------------------------------------
        _df_ee_for_chain = df_ee_sig if not df_ee_sig.empty else pd.DataFrame()
        if not df_pool_sig.empty:
            generate_voc_chain_charts(
                results_dir, RUN_TS,
                df_hvm_elec_sig=df_pool_sig,
                df_ee_sig=_df_ee_for_chain,
                voc_params=VOC_PARAMS,
                top_n=20
            )
        else:
            print("Skipping chain analysis: no significant pooled correlations available.")

        # ----------------------------------------------------------
        # Integrated PowerPoint report by sIou
        # ----------------------------------------------------------
        generate_siou_powerpoint_report(results_dir, RUN_TS)

    except Exception as e:
        print(f"Error: {str(e)}")

if __name__ == "__main__":
    main()
