import pandas as pd
import matplotlib.pyplot as plt
import os
from datetime import datetime
import numpy as np
from io import StringIO
from matplotlib.patches import Rectangle, Patch, Circle

# =========================
# CONFIGURATION
# =========================
OUTPUT_DIR_BASE = "wafer_plots"

# Region colors
REGION_COLORS = {
    "Center": "#7FBF7B",   # soft green
    "Donut":  "#FDB462",   # soft orange
    "Edge":   "#FB8072"    # soft red
}

# Plot styling
FIGSIZE = (8, 8)
EDGE_COLOR = "black"
EDGE_LINEWIDTH = 0.6
WAFER_LINEWIDTH = 1.8
WAFER_MARGIN = 0.20

# ==========================================================
# DIE GEOMETRY FOR "REFERENCE IMAGE" LOOK
# ----------------------------------------------------------
# Raw X/Y data stays unchanged, but plotting coordinates are
# stretched more in Y than X so rectangles look tall/narrow.
# ==========================================================
X_PITCH = 1.00         # horizontal spacing between die centers
Y_PITCH = 1.65         # vertical spacing between die centers (taller look)

DIE_FILL_X = 0.96      # fraction of X pitch occupied by die width
DIE_FILL_Y = 0.96      # fraction of Y pitch occupied by die height

DIE_WIDTH = X_PITCH * DIE_FILL_X
DIE_HEIGHT = Y_PITCH * DIE_FILL_Y

# Display options
SHOW_AXES = False      # False makes it resemble the reference image more
SHOW_GRID = False
SHOW_COORD_LABELS = False   # label each die with (X,Y) if True

TITLE = "Wafer Map by Region"
CSV_INPUT_PATH = r"C:\Users\eavega\OneDrive - Intel Corporation\Documents\Projects\MicroServers\DMR\process coverage\Correlation_analysis\IDV SAMPLING DMR IMH - by VID_17parts_volume.csv"

# =========================
# RAW DATA (embedded)
# =========================
data_str = """
X    Y    Region
-11    -1    Edge
-11    0    Edge
-10    -2    Edge
-10    -1    Donut
-10    0    Donut
-10    1    Edge
-9    -2    Donut
-9    -1    Donut
-9    0    Donut
-9    1    Donut
-8    -3    Edge
-8    -2    Donut
-8    -1    Donut
-8    0    Donut
-8    1    Donut
-8    2    Edge
-7    -3    Donut
-7    -2    Donut
-7    -1    Donut
-7    0    Donut
-7    1    Donut
-7    2    Donut
-6    -3    Donut
-6    -2    Donut
-6    -1    Donut
-6    0    Donut
-6    1    Donut
-6    2    Donut
-5    -4    Edge
-5    -3    Donut
-5    -2    Donut
-5    -1    Center
-5    0    Center
-5    1    Donut
-5    2    Donut
-5    3    Edge
-4    -4    Edge
-4    -3    Donut
-4    -2    Donut
-4    -1    Center
-4    0    Center
-4    1    Donut
-4    2    Donut
-4    3    Edge
-3    -4    Edge
-3    -3    Donut
-3    -2    Center
-3    -1    Center
-3    0    Center
-3    1    Center
-3    2    Donut
-3    3    Edge
-2    -4    Edge
-2    -3    Donut
-2    -2    Center
-2    -1    Center
-2    0    Center
-2    1    Center
-2    2    Donut
-2    3    Edge
-1    -4    Edge
-1    -3    Donut
-1    -2    Center
-1    -1    Center
-1    0    Center
-1    1    Center
-1    2    Donut
-1    3    Edge
0    -4    Edge
0    -3    Donut
0    -2    Center
0    -1    Center
0    0    Center
0    1    Center
0    2    Donut
0    3    Edge
1    -4    Edge
1    -3    Donut
1    -2    Center
1    -1    Center
1    0    Center
1    1    Center
1    2    Donut
1    3    Edge
2    -4    Edge
2    -3    Donut
2    -2    Donut
2    -1    Center
2    0    Center
2    1    Donut
2    2    Donut
2    3    Edge
3    -4    Edge
3    -3    Donut
3    -2    Donut
3    -1    Center
3    0    Center
3    1    Donut
3    2    Donut
3    3    Edge
4    -4    Edge
4    -3    Donut
4    -2    Donut
4    -1    Donut
4    0    Donut
4    1    Donut
4    2    Donut
4    3    Edge
5    -3    Donut
5    -2    Donut
5    -1    Donut
5    0    Donut
5    1    Donut
5    2    Donut
6    -3    Donut
6    -2    Donut
6    -1    Donut
6    0    Donut
6    1    Donut
6    2    Donut
7    -3    Edge
7    -2    Donut
7    -1    Donut
7    0    Donut
7    1    Donut
7    2    Edge
8    -2    Donut
8    -1    Donut
8    0    Donut
8    1    Donut
9    -2    Edge
9    -1    Donut
9    0    Donut
9    1    Edge
10    -1    Edge
10    0    Edge
"""

# =========================
# LOAD DATA
# =========================
df = pd.read_csv(StringIO(data_str.strip()), sep=r"\s+", engine="python")
df.columns = df.columns.str.strip()


def resolve_required_columns(columns):
    """Map CSV column names to canonical names, tolerating spaces/colons/case."""
    normalized_to_original = {
        col.strip().upper().replace(":", ""): col for col in columns
    }

    required = {
        "VISUAL_ID": "VISUAL_ID",
        "SUBSTRUCTURE_ID": "SUBSTRUCTURE_ID",
        "SORT_X": "SORT_X",
        "SORT_Y": "SORT_Y",
    }

    missing = [key for key in required if key not in normalized_to_original]
    if missing:
        raise ValueError(
            "CSV is missing required columns: "
            + ", ".join(missing)
            + f". Found columns: {list(columns)}"
        )

    return {
        normalized_to_original["VISUAL_ID"]: "VISUAL_ID",
        normalized_to_original["SUBSTRUCTURE_ID"]: "SUBSTRUCTURE_ID",
        normalized_to_original["SORT_X"]: "SORT_X",
        normalized_to_original["SORT_Y"]: "SORT_Y",
    }


def build_visual_id_color_map(visual_ids):
    """Build a deterministic VISUAL_ID -> color mapping."""
    cmap = plt.get_cmap("tab20")
    visual_ids_sorted = sorted([str(v) for v in visual_ids])
    return {
        vid: cmap(i % cmap.N)
        for i, vid in enumerate(visual_ids_sorted)
    }

# =========================
# SANITY CHECK
# =========================
expected_regions = {"Center", "Donut", "Edge"}
found_regions = set(df["Region"].unique())

if not expected_regions.issuperset(found_regions):
    print(f"[WARNING] Unexpected regions detected: {found_regions - expected_regions}")

# ==========================================
# TRANSFORM RAW COORDINATES -> DISPLAY SPACE
# ==========================================
# This is the key change that gives the map
# the "tall narrow die" look like the reference image.
df["Xp"] = df["X"] * X_PITCH
df["Yp"] = df["Y"] * Y_PITCH

# =========================
# LOAD VISUAL_ID CSV
# =========================
if not os.path.exists(CSV_INPUT_PATH):
    raise FileNotFoundError(
        f"Input CSV not found at fixed path: {CSV_INPUT_PATH}"
    )

csv_df = pd.read_csv(CSV_INPUT_PATH)
rename_map = resolve_required_columns(csv_df.columns)
csv_df = csv_df.rename(columns=rename_map)

csv_df = csv_df[["VISUAL_ID", "SUBSTRUCTURE_ID", "SORT_X", "SORT_Y"]].copy()
csv_df["SORT_X"] = pd.to_numeric(csv_df["SORT_X"], errors="coerce")
csv_df["SORT_Y"] = pd.to_numeric(csv_df["SORT_Y"], errors="coerce")
csv_df = csv_df.dropna(subset=["VISUAL_ID", "SUBSTRUCTURE_ID", "SORT_X", "SORT_Y"])

if csv_df.empty:
    raise ValueError("Input CSV has no valid rows after cleaning required columns.")

csv_df["Xp"] = csv_df["SORT_X"] * X_PITCH
csv_df["Yp"] = csv_df["SORT_Y"] * Y_PITCH

substructure_ids = sorted(csv_df["SUBSTRUCTURE_ID"].astype(str).unique())
if len(substructure_ids) < 2:
    raise ValueError(
        "Expected two SUBSTRUCTURE_ID values in CSV, found: "
        + ", ".join(substructure_ids)
    )
if len(substructure_ids) > 2:
    print(
        "[WARNING] More than two SUBSTRUCTURE_ID values detected; "
        f"using first two: {substructure_ids[:2]}"
    )

substructure_ids = substructure_ids[:2]
visual_id_color_map = build_visual_id_color_map(csv_df["VISUAL_ID"].unique())

# =========================
# OUTPUT DIRECTORY
# =========================
timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
output_dir = os.path.join(OUTPUT_DIR_BASE, f"run_{timestamp}")
os.makedirs(output_dir, exist_ok=True)

# =========================
# CREATE FIGURE
# =========================
fig, axes = plt.subplots(1, 2, figsize=(FIGSIZE[0] * 2, FIGSIZE[1]))

# =========================
# WAFER BOUNDARY (corner-based)
# =========================
corner_radii = []
for _, row in df.iterrows():
    x = row["Xp"]
    y = row["Yp"]
    corners = [
        (x - DIE_WIDTH / 2, y - DIE_HEIGHT / 2),
        (x - DIE_WIDTH / 2, y + DIE_HEIGHT / 2),
        (x + DIE_WIDTH / 2, y - DIE_HEIGHT / 2),
        (x + DIE_WIDTH / 2, y + DIE_HEIGHT / 2),
    ]
    for cx, cy in corners:
        corner_radii.append(np.sqrt(cx**2 + cy**2))

radius = max(corner_radii) + WAFER_MARGIN

region_handles = [
    Patch(
        facecolor=color,
        edgecolor=EDGE_COLOR,
        alpha=0.45,
        label=f"{region} Region"
    )
    for region, color in REGION_COLORS.items()
]
visual_handles = [
    Patch(
        facecolor=visual_id_color_map[vid],
        edgecolor=EDGE_COLOR,
        label=f"VISUAL_ID {vid}"
    )
    for vid in sorted(visual_id_color_map.keys())
]
legend_handles = region_handles + visual_handles

# =========================
# DRAW TWO SUBPLOTS (one per SUBSTRUCTURE_ID)
# =========================
for ax, sub_id in zip(axes, substructure_ids):
    # Draw base wafer dies using soft region colors
    for _, row in df.iterrows():
        base_die = Rectangle(
            (row["Xp"] - DIE_WIDTH / 2, row["Yp"] - DIE_HEIGHT / 2),
            DIE_WIDTH,
            DIE_HEIGHT,
            facecolor=REGION_COLORS[row["Region"]],
            edgecolor=EDGE_COLOR,
            linewidth=0.35,
            alpha=0.45
        )
        ax.add_patch(base_die)

    # Highlight CSV dies with VISUAL_ID-specific colors
    sub_df = csv_df[csv_df["SUBSTRUCTURE_ID"].astype(str) == str(sub_id)]
    for _, row in sub_df.iterrows():
        vid = str(row["VISUAL_ID"])
        visual_die = Rectangle(
            (row["Xp"] - DIE_WIDTH / 2, row["Yp"] - DIE_HEIGHT / 2),
            DIE_WIDTH,
            DIE_HEIGHT,
            facecolor=visual_id_color_map[vid],
            edgecolor=EDGE_COLOR,
            linewidth=EDGE_LINEWIDTH
        )
        ax.add_patch(visual_die)

        if SHOW_COORD_LABELS:
            ax.text(
                row["Xp"], row["Yp"],
                f"{row['VISUAL_ID']}\n({int(row['SORT_X'])},{int(row['SORT_Y'])})",
                ha="center", va="center",
                fontsize=5, color="black"
            )

    wafer_circle = Circle(
        (0, 0),
        radius=radius,
        fill=False,
        linewidth=WAFER_LINEWIDTH,
        color="black"
    )
    ax.add_patch(wafer_circle)

    ax.set_aspect("equal", adjustable="box")
    ax.set_xlim(-radius - 0.5, radius + 0.5)
    ax.set_ylim(-radius - 0.5, radius + 0.5)
    ax.set_facecolor("#f2f2f2")

    ax.set_title(f"{TITLE} - SUBSTRUCTURE_ID {sub_id}")

    if SHOW_AXES:
        ax.set_xlabel("X Position")
        ax.set_ylabel("Y Position")

        unique_x = sorted(df["X"].unique())
        unique_y = sorted(df["Y"].unique())

        ax.set_xticks([x * X_PITCH for x in unique_x])
        ax.set_xticklabels([str(x) for x in unique_x])

        ax.set_yticks([y * Y_PITCH for y in unique_y])
        ax.set_yticklabels([str(y) for y in unique_y])

        if SHOW_GRID:
            ax.grid(True, linestyle="--", alpha=0.3)
    else:
        ax.set_xticks([])
        ax.set_yticks([])
        for spine in ax.spines.values():
            spine.set_visible(False)

fig.legend(
    handles=legend_handles,
    loc="lower center",
    bbox_to_anchor=(0.5, 0.01),
    frameon=True,
    ncol=4,
    fontsize=8
)

plt.tight_layout(rect=[0, 0.14, 1, 1])

# =========================
# SAVE OUTPUT
# =========================
output_file = os.path.join(output_dir, "wafer_map_two_substructures.png")
plt.savefig(output_file, dpi=300, bbox_inches="tight")
plt.close()

print(f"[INFO] Display pitch -> X: {X_PITCH:.2f}, Y: {Y_PITCH:.2f}")
print(f"[INFO] Die size      -> width: {DIE_WIDTH:.2f}, height: {DIE_HEIGHT:.2f}")
print(f"[INFO] Wafer radius  -> {radius:.2f}")
print(f"[INFO] CSV source    -> {CSV_INPUT_PATH}")
print(f"[INFO] Substructures -> {substructure_ids}")
print(f"[INFO] Plot saved to: {output_file}")
