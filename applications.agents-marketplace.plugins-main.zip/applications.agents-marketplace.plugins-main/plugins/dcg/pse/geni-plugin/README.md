# Geni Plugin

The Geni plugin exposes Intel internal engineering knowledge and tooling through the Geni MCP server, targeting Silicon Validation use cases. It enables querying the Axon validation database for test failures and hardware diagnostics, searching and retrieving HSD/HSDES tickets via SQL or semantic search, looking up internal Wiki documentation across 70+ spaces, generating pythonSV register programming recipes for Intel silicon, answering hardware specification and debug architecture questions, managing and querying GENI workspaces as RAG (Retrieval-Augmented Generation) stores (including file uploads), and submitting feedback on tool responses.

## Version

**1.1.0**

## Features

- **AxonTool** — Intelligent query interface for Intel's Axon validation database; explore test records, debug hardware failures, and analyze register/signal data in plain language
- **HSDTool** — HSDES-ES API agent supporting SQL-like queries, table schema lookup, ticket retrieval by ID, and saved query execution
- **HSDIndexTool** — Semantic search agent for finding HSD tickets by meaning or concept rather than exact field values
- **VeWikiTool** — Hybrid search over Intel internal Wiki documentation across 70+ supported Wiki spaces
- **CodeWithRegistersTool** — pythonSV register programming recipes and configuration code for Intel silicon products (e.g. DMR, PTL)
- **DebugAssistantAgentTool** — Hardware specification, debug concept, and system architecture Q&A using internal specification data
- **GeniFeedbackTool** — Submit like/dislike feedback on any Geni tool response
- **WorkspaceTool** — Manage and query GENI workspaces. A workspace acts as a RAG (Retrieval-Augmented Generation) store: upload your files, Geni indexes them, and you can query the content in natural language using `AskWorkspace`:
  - **AskWorkspace** — Chat with / query a workspace using an LLM
  - **WorkspaceCreate** — Create a new private or shared workspace
  - **WorkspaceGet** — Retrieve workspace details by ID or name
  - **WorkspaceUpdate** — Update workspace metadata (name, description, groups, wiki spaces, etc.)
  - **WorkspaceDelete** — Delete a workspace
  - **Upload / Delete / Status** — Upload files to a workspace, delete uploaded files, or check indexing status via direct EntityService calls (handled by the `upload-workspace-files` skill)

## Skills

### 1. acquire-tokens

**Purpose:** Acquire authentication tokens before calling AxonTool or HSDIndexTool.

**When to use:** Required before every call to `AxonTool` or `HSDIndexTool` from the Geni MCP server. Tokens expire after 30 minutes.

**Location:** [`skills/acquire-tokens/SKILL.md`](skills/acquire-tokens/SKILL.md)

**Key Features:**
- Fetches tokens using Kerberos credentials
- Caches tokens for 30 minutes
- Works on Windows (PowerShell) and Linux/macOS (Bash)
- Never transmits passwords

### 2. geni-response-footer

**Purpose:** Append a standard feedback footer after every response from any Intel Geni MCP tool or the `upload-workspace-files` skill.

**When to use:** Automatically applied after responses from `AxonTool`, `HSDTool`, `HSDIndexTool`, `VeWikiTool`, `CodeWithRegistersTool`, `DebugAssistantAgentTool`, `AskWorkspace`, Workspace CRUD tools, and `upload-workspace-files` helper scripts.

**Location:** [`skills/geni-response-footer/SKILL.md`](skills/geni-response-footer/SKILL.md)

**Key Features:**
- Consistently appends a feedback prompt after every Geni tool response
- Enables users to submit feedback via `/genifeedback`

### 3. genifeedback

**Purpose:** Handle the `/genifeedback` command — collect user feedback on a Geni tool response and submit it via `GeniFeedbackTool`.

**When to use:** When the user types `/genifeedback` or expresses positive/negative sentiment about a Geni tool response.

**Location:** [`skills/genifeedback/SKILL.md`](skills/genifeedback/SKILL.md)

**Key Features:**
- Collects free-text feedback from the user
- Classifies intent (like / dislike)
- Submits feedback via `GeniFeedbackTool`

### 4. hsd-preferences

**Purpose:** Manage user preference memory for HSD/HSDES queries so users don't need to repeat context (e.g. project, tenant, family) across sessions.

**When to use:** Load before every call to `HSDTool` or `HSDIndexTool`. Handles auto-answering of clarification questions using saved preferences and persists new preferences when the user provides them.

**Location:** [`skills/hsd-preferences/SKILL.md`](skills/hsd-preferences/SKILL.md)

**Key Features:**
- Reads saved preferences from user memory before HSD queries
- Auto-answers tool clarification questions using stored values
- Persists newly provided preferences for future sessions
- Never injects preferences into the initial tool call

### 5. upload-workspace-files

**Purpose:** Upload, delete, and check the status of files in a GENI workspace by calling EntityService endpoints directly (no MCP tools used).

**When to use:** When the user asks to upload files to a workspace, delete uploaded files, or check upload/indexing status.

**Location:** [`skills/upload-workspace-files/SKILL.md`](skills/upload-workspace-files/SKILL.md)

**Key Features:**
- Uploads files via `POST /api/UploadFile/uploadFileToWorkspace` (multipart)
- Deletes files via `DELETE /api/UploadFile/delete`
- Checks indexing status via `GET /api/Workspace/{id}/resources`
- Auto-detects environment (prod/dev/test) from `.mcp.json`; defaults to prod
- Tokens cached per environment

## MCP Server Configuration

### VS Code

The plugin uses the MCP server configuration in `.mcp.json`:

```json
{
  "mcpServers": {
    "Intel Geni (plugin)": {
      "type": "http",
      "url": "https://laas-aks-prod01.laas.icloud.intel.com/agentgateway/api/a2a/geni/genivalidationmcpserver/"
    }
  }
}
```

### Cursor

For Cursor IDE, use the configuration in `.cursor-mcp.json` (if available).

## Installation

The plugin is installed via the marketplace. No manual installation steps required.

## Usage

**Querying Axon or HSD**:
- The `acquire-tokens` skill runs automatically before each query
- Tokens are cached for 30 minutes
- Your Kerberos credentials are used (no password input needed)

## Troubleshooting

### Token acquisition fails

- **Cause:** Kerberos not configured or credentials expired
- **Solution:** Ensure you're logged in with valid Intel credentials

## Support

**Owners:**
- orly.abramovich@intel.com
- idan.matan.porat@intel.com

**Repository:** https://labasaservice.visualstudio.com/_git/ssl-marketplace

## Changelog

### 1.1.0
- Added `geni-response-footer` skill — standard feedback footer after every Geni tool response
- Added `genifeedback` skill — `/genifeedback` command to submit feedback via `GeniFeedbackTool`
- Added `hsd-preferences` skill — persistent user preference memory for HSD/HSDES queries
- Added `upload-workspace-files` skill — direct EntityService file management (upload/delete/status)

### 1.0.0
- Initial release
- `acquire-tokens` skill for Axon and HSD authentication
- HTTP MCP server support
