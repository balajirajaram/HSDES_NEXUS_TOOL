---
name: geni-response-footer
description: "Append a feedback footer after presenting results from any Intel Geni MCP tool, or from the upload-workspace-files skill (upload / delete / get-files-status helper scripts). Apply after every response from AxonTool, HSDTool, HSDIndexTool, VeWikiTool, CodeWithRegistersTool, DebugAssistantAgentTool, AskWorkspace, WorkspaceCompleteFileUploads, WorkspaceListFiles, WorkspaceDeleteFile, WorkspaceCreate, WorkspaceGet, WorkspaceUpdate, WorkspaceDelete, any other tool from the Intel Geni (prod) MCP server, or any helper script invoked via the upload-workspace-files skill."
---
# Geni Response Footer

## When This Skill Applies

Apply this skill after **every** response that includes output from any tool on the `Intel Geni (prod)` MCP server, **or** from the `upload-workspace-files` skill (direct EntityService helper scripts — upload, delete, get file status). This includes:

- `AxonTool`
- `HSDTool`
- `HSDIndexTool`
- `VeWikiTool`
- `CodeWithRegistersTool`
- `DebugAssistantAgentTool`
- `AskWorkspace`
- `WorkspaceCreate`
- `WorkspaceGet`
- `WorkspaceUpdate`
- `WorkspaceDelete`
- Any other tool provided by the Intel Geni MCP server
- The `upload-workspace-files` skill — specifically any output from `upload-files.ps1` / `upload-files.sh`, `delete-files.ps1` / `delete-files.sh`, or `get-files-status.ps1` / `get-files-status.sh`

## Procedure

After presenting the tool results to the user, always append the following footer **exactly as written below** — do NOT rephrase, reword, or modify it in any way, and do NOT add any emojis or extra text:

---


---

> 💬 **Was this helpful?** Type `/genifeedback` followed by your thoughts to send feedback to the Geni team

**IMPORTANT:** The footer text above must be copied **verbatim**. Strict rules:

- Do NOT substitute synonyms, do NOT add reaction prompts (e.g. 👍/👎), and do NOT alter punctuation or formatting.
- Do NOT add any links, hyperlinks, or markdown link syntax anywhere in the footer.
- Do NOT add any URLs — not even ones you believe to be the correct Geni URL, feedback portal, documentation site, or team page. **No URLs are allowed under any circumstances.**
- Do NOT linkify `/genifeedback`, "Geni team", or any other word in the footer.
- Do NOT append additional lines, references, citations, or "Learn more" style links after the footer.

If you are tempted to add a URL because it seems helpful or because you recall one, do not. Render the footer exactly as shown above and stop.
