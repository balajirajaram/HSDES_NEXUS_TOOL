---
name: genifeedback
description: "Handle /genifeedback command. Use when the user types /genifeedback or expresses feedback about a Geni tool response (positive, negative, thumbs up/down, helpful/not helpful, like/dislike). Collects feedback text, determines intent, and submits it via GeniFeedbackTool."
---

# Geni Feedback Skill

## When This Skill Applies

Load this skill when the user:
- Types `/genifeedback` (with or without additional text)
- Responds to the feedback footer prompt after a Geni tool response

## Procedure

### Step 1: Collect Feedback Text (if not already provided)

If the user typed `/genifeedback` with no additional text, ask:

```
What did you think of the last response? Feel free to share any comments.
```

Wait for their reply before proceeding.

### Step 2: Determine Intent

Analyze the user's feedback text and classify it as one of:

- **Like** — positive sentiment: satisfied, helpful, correct, good, thanks, 👍, etc.
- **Dislike** — negative sentiment: wrong, unhelpful, missing, confused, bad, 👎, etc.

If the sentiment is ambiguous or neutral, default to **Dislike** (erring toward capturing actionable feedback).

### Step 3: Identify the Last Geni MCP Tool Used

Look back through the conversation and identify the most recent tool call made to the `Intel Geni (prod)` MCP server. This will be one of:

- `AxonTool`
- `HSDTool`
- `HSDIndexTool`
- `VeWikiTool`
- `CodeWithRegistersTool`
- `DebugAssistantAgentTool`
- `AskWorkspace`
- `WorkspaceCreate`
- `WorkspaceGet`
- `WorkspaceUpdate`
- `WorkspaceDelete`

If no Geni tool was used in the conversation, use `"unknown"`.

### Step 4: Build the Interaction(s)

Extract up to the **3 most recent** Geni tool exchanges from the conversation — all values verbatim, no rephrasing or summarizing. Order them **chronologically: oldest first, most recent last**. Fewer than 3 is fine if the conversation has fewer Geni exchanges.

Each interaction has four fields:

1. **`userPrompt`** — The exact message the user typed that triggered the Geni tool call.

2. **`toolInput`** — The input actually passed to the Geni tool. Look at the tool call arguments in the conversation:
   - Always include the `message` argument (verbatim).
   - Also include any additional arguments such as IDs or other non-token fields — capture each as `<argName>: <value>`.
   - **Skip** any argument whose name contains or suggests a token, credential, key, auth, or secret.
   - Format as a multi-line string:
     ```
     message: <verbatim message argument value>
     <argName>: <argValue>   ← repeat for each additional non-token argument
     ```
   - If the tool has no `message` argument, capture the primary text input argument by name.

3. **`toolResponse`** — The full Geni tool response, verbatim.

4. **`focus`** — The Geni tool name identified in Step 3 (e.g. `AxonTool`), or `"unknown"`.

> ⚠️ **CRITICAL: `userPrompt`, `toolInput`, and `toolResponse` must be copied VERBATIM — exactly as they appear. Do NOT rephrase, summarize, truncate, or paraphrase any of them.**

### Step 5: Summarize the Entire Conversation

Write a concise summary (2–5 sentences) of the entire conversation, covering:
- What the user was trying to accomplish
- Which Geni tools were used and what they returned
- Any clarifications or follow-ups that occurred

### Step 6: Call GeniFeedbackTool

Call `GeniFeedbackTool` from the `Intel Geni (prod)` MCP server with the following arguments:

| Argument | Value |
|---|---|
| `type` | `Like` or `Dislike` (from Step 2) |
| `interactions` | Array of up to 3 interaction objects (from Step 4), ordered oldest first, most recent last. |
| `content` | The original, unmodified feedback string provided by the user |
| `conversationSummary` | Summary from Step 5 |

### Step 7: Confirm to the User

After a successful tool call, respond with:

> ✅ **Thank you for your feedback!** It has been submitted to the Geni team.

If the tool call fails, inform the user:

> ⚠️ Feedback could not be submitted at this time. Please try again later.
