---
name: hsd-preferences
description: "HSD query assistant — handles user preference memory for HSD/HSDES queries. USE BEFORE calling HSDTool or HSDIndexTool. Applies when the user asks about HSD tickets, sightings, bugs, or HSDES queries. Responsible for: auto-answering HSDTool clarification questions using saved preferences, and saving new preferences when the user answers new clarification questions."
---

# HSD Preferences Skill

## ⚠️ CRITICAL REQUIREMENT
**NEVER inject saved preferences into the initial HSDTool/HSDIndexTool call. Saved preferences are ONLY used to auto-answer clarification questions that the tool itself raises. The tool decides which fields are missing — not the agent.**

Injecting preferences upfront causes saved values to override what the user actually asked for, producing wrong results with no visible error.

## Purpose
Manage user preference memory for HSD/HSDES tool queries so users don't need to repeat context (e.g. project, component, tenant, family) across sessions.

## When This Skill Applies
Load this skill whenever the user asks anything involving:
- HSD, HSDES, HSD-ES tickets, sightings, bugs
- Queries using HSDTool or HSDIndexTool

## Step 1: Load Memory, Then Call Tool With Raw Query

Before calling HSDTool or HSDIndexTool, you MUST explicitly load `/memories/user-preferences.md` using the memory tool (`command: view`) in the current turn.

**Do NOT inject any saved preferences into the tool call.** Call HSDTool or HSDIndexTool with only the user's original query, exactly as stated. The tool itself will determine which fields are missing and ask for clarification.

## Step 2: MANDATORY WORKFLOW — Handle Clarifications

**WHENEVER HSDTool or HSDIndexTool returns a clarification question, follow this exact sequence:**

### 2a. Check Memory First
Look at the loaded `/memories/user-preferences.md` for a `HSD - {field}:` entry matching the clarification field.

**If a saved value exists for that field:**
- Auto-answer the clarification using the saved value
- Inform the user: e.g., *"Using your saved tenant: `sighting_central__sighting`"*
- Proceed directly to calling HSDTool/HSDIndexTool with that answer (skip to Step 2e)
- Do NOT ask the user to confirm the saved value

**If no saved value exists for that field:**
- Continue to Step 2b

### 2b. Present the Clarification to User
Display the tool's question and available options to the user. Wait for their response.

### 2c. User Provides Answer
User selects or types their answer (e.g., `sighting_central__sighting` for a tenant choice).

### 2d. Ask About Saving (REQUIRED — DO NOT SKIP)
Before proceeding, use `vscode_askQuestions` to ask:
```json
{
  "header": "Remember HSD Preference",
  "question": "💾 Would you like me to remember this for future HSD queries?",
  "options": [
    { "label": "Yes, remember it" },
    { "label": "No thanks" }
  ],
  "allowFreeformInput": false
}
```

If user selected **"Yes, remember it"**:
1. Use the `memory` tool to update `/memories/user-preferences.md`
2. **On first consent ever**: add the line `HSD-memory-consent: granted` (once only)
3. **Add the preference**: `HSD - {field}: {resolved value}`
   - Example: `HSD - tenant: sighting_central__sighting`
   - Example: `HSD - family: dmr`
4. Even if `HSD-memory-consent: granted` already exists, still ask before saving each new preference.

### 2e. Proceed With Results
Call HSDTool/HSDIndexTool with **both the user's original query AND the clarification answer** (saved or user-provided) combined. Never call the tool with only the clarification answer — the original query must always be included.

---

## Verification Checklist (Before Closing Your Response)

When a clarification occurred, verify:
- ✓ Did I call HSDTool/HSDIndexTool with the user's raw query (no memory injection)?
- ✓ Did I check memory before presenting the clarification to the user?
- ✓ If a saved value existed — did I auto-answer and inform the user?
- ✓ If no saved value — did I present the question and call `vscode_askQuestions` for save confirmation?
- ✓ Did I save the preference only if user consented?
- ✓ Did I then call HSDTool/HSDIndexTool with **both the original user query AND the resolved clarification answer**? (Not the answer alone)

If you answered "no" to any checkbox, you have not completed the workflow correctly.

## Concrete Examples

### Example 1: No Saved Tenant — First Session (Correct Workflow)
1. User: *"open DMR hsd tickets"*
2. Agent loads memory → no `HSD - tenant` found
3. Agent calls HSDTool with raw query `"open DMR hsd tickets"`
4. **HSDTool returns:** *"Which tenant? 1) sighting_central__sighting  2) server_platf__bug  ..."*
5. No saved tenant in memory → agent presents options to user
6. User: *"1"*
7. Agent calls `vscode_askQuestions` → *"Would you like me to remember this?"*
8. User: *"Yes, remember it"*
9. Agent saves to `/memories/user-preferences.md`:
   - `HSD-memory-consent: granted`
   - `HSD - tenant: sighting_central__sighting`
10. Agent calls HSDTool with `"open DMR hsd tickets"` + tenant `sighting_central__sighting`
11. Agent returns results

### Example 2: Saved Tenant — Subsequent Session (Auto-Answer)
1. User: *"open DMR hsd tickets"*
2. Agent loads memory → finds `HSD - tenant: sighting_central__sighting`
3. Agent calls HSDTool with raw query `"open DMR hsd tickets"`
4. **HSDTool returns:** *"Which tenant? ..."*
5. Saved tenant found → agent auto-answers with `sighting_central__sighting`
6. Agent informs user: *"Using your saved tenant: `sighting_central__sighting`"*
7. Agent calls HSDTool with `"open DMR hsd tickets"` + tenant `sighting_central__sighting`
8. Agent returns results immediately
9. **Result:** Zero friction, saved preference used

### Example 3: User Query Implies a Different Tenant
1. Memory contains: `HSD - tenant: sighting_central__sighting`
2. User: *"find tickets about BIOS boot failure in central firmware"*
3. Agent loads memory → finds `HSD - tenant: sighting_central__sighting`
4. Agent calls HSDTool with raw query `"find tickets about BIOS boot failure in central firmware"` (**no injection**)
5. HSDTool resolves "central firmware" as a tenant on its own — **no clarification needed for tenant**
6. Agent returns results scoped to `central firmware`
7. **Result:** Saved tenant never interferes — the tool handled it correctly

### Example 4: Clarification for a Different Field (After Consent Saved)
1. Memory contains: `HSD - tenant: sighting_central__sighting`
2. User: *"open DMR hsd tickets restricted to silicon and not mock"*
3. Agent calls HSDTool with raw query
4. **HSDTool returns clarification** for field `stepping` (not in memory)
5. No saved value for `stepping` → agent presents question to user
6. User answers
7. Agent calls `vscode_askQuestions` → *"Would you like me to remember this?"*
8. If user says "No thanks", agent does not write memory
9. Agent calls HSDTool with the stepping answer and returns results

### Example 5: INCORRECT — What NOT to Do
1. User: *"open DMR hsd tickets"*
2. Agent loads memory → finds `HSD - tenant: sighting_central__sighting`
3. ❌ **Agent injects `tenant: sighting_central__sighting` into the initial HSDTool call**
4. User later asks *"find tickets in central firmware"* — saved tenant overrides the intended tenant
5. **Result:** Wrong results, no visible error, user confused

---

## Rules
- Never save sensitive data (tokens, passwords).
- Only save factual preferences: project names, component names, owner IDs, family, tenant, etc.
- Always load `/memories/user-preferences.md` before each HSDTool/HSDIndexTool call — but only to prepare for clarification handling, never to inject into the initial call.
- Saved preferences auto-answer tool clarifications only — they never modify the initial query.
- Prior consent does not replace per-clarification save confirmation.
- The verification checklist is non-optional when clarifications occur.
