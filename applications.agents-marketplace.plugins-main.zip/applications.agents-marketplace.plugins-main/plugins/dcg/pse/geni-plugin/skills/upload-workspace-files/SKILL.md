---
name: upload-workspace-files
description: "Manage files in a GENI workspace by calling EntityService endpoints directly: upload (POST /api/UploadFile/uploadFileToWorkspace), delete (DELETE /api/UploadFile/delete), and get status (GET /api/Workspace/{id}/resources). Use when: user asks to upload files to a workspace, delete uploaded files, or check upload/indexing status. No MCP tools are used; HTTPS requests are issued directly to EntityService."
argument-hint: "<workspaceId> <file1> [file2 ...]"
---
# Workspace Files (Direct EntityService)

## When to use

Use this skill **whenever the user asks to upload, delete, or check the status of files in a GENI workspace**. This flow bypasses MCP entirely and talks to EntityService directly:

| Action | HTTP | Endpoint |
| --- | --- | --- |
| Upload | `POST`   | `{baseUrl}/api/UploadFile/uploadFileToWorkspace?workspaceId={id}` (multipart) |
| Delete | `DELETE` | `{baseUrl}/api/UploadFile/delete` (JSON `UploadFileDeleteDTO` body) |
| Status | `GET`    | `{baseUrl}/api/Workspace/{id}/resources` |

All three carry `Authorization: Bearer <user access token>`.

## Environments

The target environment (`prod` | `dev` | `test`) is normally **auto-detected** from the URL of the local `Intel Geni` MCP server entry in the nearest `.mcp.json` (walking up from the scripts directory). `localhost` / `127.0.0.1` URLs are treated as `dev`.

> **Fallback policy:** if auto-detection fails *for any reason* (no `.mcp.json` found, no MCP entry, URL doesn't match any hint, malformed JSON, missing helper, etc.), every script **always falls back to `prod`**. This is intentional and consistent across all scripts — production is the safe assumption when we can't be sure.

Only override (with `-Environment` on PowerShell or `-e` on bash) when the user explicitly says they want a different env from what's currently configured in `.mcp.json`.

All per-environment details (base URLs, Azure AD client ids, tenant, scopes, callback port, URL hints) live in [./scripts/environments.json](./scripts/environments.json) and are loaded by every script. You do not need to know or surface these values to the user.

Tokens are cached separately per environment, so signing into one does not affect the others.

Up to 500 files per call. Supported file types: `pdf, txt, docx, html, csv, xlsx, pptx, md, png, jpg, jpeg, webm, webp, json, xml`.

## Upload modes — Indexed vs Full perspective

Every upload uses **one of two modes**. You **must** make this choice explicit to the user before uploading (do not silently default), and you should recommend the mode that best fits the file type and how the user plans to query it.

| Mode | Flag | When to use | Best for |
| --- | --- | --- | --- |
| **Indexed** (default) | `skipIndex` omitted / `false` | Queries whose answer lives in a **specific section** or a limited set of sections of a larger document. The file is chunked and retrieved by semantic search. | Specifications, process flows, Excel (`xlsx`), `xml`, `json`, structured docs. |
| **Full perspective** (non-indexed) | `-SkipIndex` / `-s` (`skipIndex=true`) | Questions that require analyzing the **entire content** of a document rather than focusing on specific sections. The whole file is loaded as one perspective. | Log files (`txt`), code documentation, narrative reports — anything where whole-context understanding is critical. |

> **Important — descriptions are required for Full perspective uploads and must NOT be provided for Indexed uploads** (they are ignored). A good, detailed description is critical for a Full perspective file to appear in search results. If the user picks Full perspective without giving a description, ask for one before running the script.

### How to help the user choose

1. Ask the user how they plan to query the file(s):
   - *"Will you ask targeted questions about specific sections?"* → **Indexed**.
   - *"Do you need answers that consider the whole document at once (e.g. summarize this log)?"* → **Full perspective**.
2. If they're unsure, recommend based on file type using the table above (e.g. `.txt` log → Full perspective; `.xlsx` spec → Indexed).
3. State your recommendation explicitly and ask for confirmation, e.g.:
   > "I'll upload `server.log` as **Full perspective** (non-indexed) since it's a log file and questions usually need the whole context. Please give a short description of what this log contains — it's required for this mode. Reply `indexed` if you'd rather index it instead (no description needed)."
4. When uploading a mixed batch, group by mode and run the script twice (once per mode) so each file gets the right treatment.

## Authentication

A separate helper script handles Azure AD authentication using the OAuth2 Authorization Code + PKCE flow (public client). It mirrors the MSAL flow used by the GeniMCPProxy. There are two equivalent implementations:

- **Windows / PowerShell:** [./scripts/get-token.ps1](./scripts/get-token.ps1)
- **Linux / macOS (bash + curl + python3):** [./scripts/get-token.sh](./scripts/get-token.sh)

Shared parameters:

- **Per-environment config** (base URL, Azure AD client id, tenant, scopes, callback port): [./scripts/environments.json](./scripts/environments.json). All four scripts read it; nothing else needs to know these values.
- **Token cache (Windows):** `%LOCALAPPDATA%\Geni_EntityService\.token_cache_<env>.json`
- **Token cache (Linux/macOS):** `${XDG_DATA_HOME:-$HOME/.local/share}/Geni_EntityService/.token_cache_<env>.json`

First run opens the system browser; subsequent runs reuse the cached access token, and silently refresh via `refresh_token` when it is within 10 minutes of expiry (large uploads may run for a while). Falls back to interactive login if the refresh token is rejected. Flags: `-Environment prod|dev|test`, `-ForceRefresh`, `-ForceInteractive` on PowerShell; `-e prod|dev|test`, `--force-refresh`, `--force-interactive` on bash.

> The Linux/macOS helper requires `python3`, `curl`, `openssl`, and `base64` (all standard on every supported distro and macOS). On a headless host with no browser, set `GENI_TOKEN` from a workstation login instead.

## Procedure — Upload

1. **Determine the environment.** Normally **do not pass an environment flag** — the scripts auto-detect it from the MCP server URL in the nearest `.mcp.json`. Only pass `-Environment` / `-e` if the user explicitly asks for a different environment from the one currently configured.
2. **Determine the workspace.**

   - If the user gave a `workspaceId`, use it.
   - If the user gave a workspace name, resolve it to an id (e.g. ask the user, or use a workspace lookup tool that is already available in chat).
   - If neither is provided, ask the user (use `vscode_askQuestions`).
3. **Collect local file paths** from the user. Validate that each path exists. For each file whose extension is **not** in the supported list, check whether it is a plain-text file (e.g. `.log`, `.out`, `.cfg`, `.ini`, `.yaml`, `.yml`, `.toml`, `.conf`, `.nfo`, `.bat`, `.sh`, `.py`, `.ts`, `.js`, or any other human-readable text format). If it is, **rename it to use the `.txt` extension** before uploading (e.g. `server.log` → `server_log.txt`), and inform the user:
   > "`server.log` has an unsupported extension. I'll rename it to `server_log.txt` locally before uploading."

   If the file is **not** a text file (e.g. a binary, image, or archive) and its extension is unsupported, skip it and tell the user it cannot be uploaded.

   **Windows (PowerShell — rename example):**
   ```powershell
   Copy-Item 'C:\path\server.log' 'C:\path\server_log.txt'
   ```
   **Linux / macOS:**
   ```bash
   cp /path/server.log /path/server_log.txt
   ```
4. **Choose the upload mode** (see [Upload modes](#upload-modes--indexed-vs-full-perspective) above). Present both options to the user, recommend one based on file type and intended use, and get explicit confirmation. Group files by mode if the batch is mixed.
5. **Collect descriptions.** **Required** for Full perspective (`-SkipIndex` / `-s`) uploads — ask the user before proceeding if one is missing. **Do not pass descriptions for Indexed uploads** — they are ignored by the API. Pass one description per file (Full perspective only) in the same order as `-Files`.
6. **Resolve script paths** from this `SKILL.md` location:

   - Windows: `./scripts/upload-files.ps1` (acquires/refreshes the token automatically by invoking `./scripts/get-token.ps1`).
   - Linux/macOS: `./scripts/upload-files.sh` (acquires/refreshes the token automatically by invoking `./scripts/get-token.sh`, unless `-t` or `GENI_TOKEN` is set).
7. **Explain to the user before running**, then run the script. Make the target environment **and the chosen upload mode** clear in the message (e.g. "uploading 2 files to **PROD** as **Indexed**").

   For **Full perspective**, add `-SkipIndex` (PowerShell) or `-s` (bash) and always include `-Descriptions` / `-d`.

   > "I'm going to run a local script that POSTs the file bytes to the GENI EntityService `uploadFileToWorkspace` endpoint over HTTPS using your Azure AD bearer token. On the first call, a browser tab will open for you to sign in; after that the token is cached and silently refreshed."
   >

   **Windows (PowerShell):**

   ```powershell
   # Indexed (default mode), prod — NO descriptions
   powershell -ExecutionPolicy Bypass -File "<full-path>\scripts\upload-files.ps1" `
       -WorkspaceId <id> `
       -Files 'C:\path\spec.pdf','C:\path\data.xlsx'

   # Full perspective (non-indexed) — description REQUIRED
   powershell -ExecutionPolicy Bypass -File "<full-path>\scripts\upload-files.ps1" `
       -WorkspaceId <id> `
       -Files 'C:\path\server.log' `
       -Descriptions 'Production server log from 2026-05-28 covering boot failures' `
       -SkipIndex

   # Explicit dev / test environment
   powershell -ExecutionPolicy Bypass -File "<full-path>\scripts\upload-files.ps1" `
       -Environment dev -WorkspaceId <id> -Files 'C:\path\a.pdf'
   ```

   Optional parameters: `-SkipIndex` (= Full perspective), `-Descriptions 'desc a','desc b'` (Full perspective only), `-Token <token>` (advanced: skip auto-token-acquisition).

   **Linux / macOS (bash + curl):**

   ```bash
   # Indexed (default mode), prod — NO descriptions
   bash "<full-path>/scripts/upload-files.sh" \
       -w <id> \
       /path/spec.pdf /path/data.xlsx

   # Full perspective (non-indexed) — description REQUIRED
   bash "<full-path>/scripts/upload-files.sh" \
       -w <id> -s \
       -d "Production server log from 2026-05-28 covering boot failures" \
       /path/server.log

   # Explicit dev / test environment
   bash "<full-path>/scripts/upload-files.sh" -e dev -w <id> /path/a.pdf
   ```

   Optional flags: `-t <token>` (else cached/interactive via `get-token.sh`), `-s` (skipIndex = Full perspective), `-d "desc a|desc b"` (Full perspective only).
8. **Parse the JSON response** (an array of `UploadFileDTO`). For each entry report `id`, `name`, `status`, and `errorMessage`. Initial status is typically `Uploading` (indexing in progress) for Indexed uploads, or `Succeeded` for Full perspective (`skipIndex=true`) uploads.
9. **Status follow-up.** If — and only if — the user later asks for the latest status, use the *Get status* procedure below. Do **not** poll on your own.

## Procedure — Get file status

Use when the user asks things like *"are my files done indexing?"*, *"what's the status of file 42?"*, *"show me what's in this workspace"*.

1. Determine env + workspace (same as upload step 1–2).
2. (Optional) collect specific `fileIds` if the user is asking about particular files; otherwise return the whole workspace.
3. Run the helper script:

   **Windows (PowerShell):**

   ```powershell
   # All files in workspace (default prod)
   powershell -ExecutionPolicy Bypass -File "<full-path>\scripts\get-files-status.ps1" -WorkspaceId <id>

   # Specific files in dev
   powershell -ExecutionPolicy Bypass -File "<full-path>\scripts\get-files-status.ps1" `
       -Environment dev -WorkspaceId <id> -FileIds 42,43
   ```

   Optional: `-Raw` to emit the full `WorkspaceDTO` JSON unchanged.

   **Linux / macOS:**

   ```bash
   # All files in workspace
   bash "<full-path>/scripts/get-files-status.sh" -w <id>

   # Specific files in dev
   bash "<full-path>/scripts/get-files-status.sh" -e dev -w <id> 42 43
   ```

   Optional: `-r` for raw response.
4. The summary output is a JSON array of `{ id, name, status, errorMessage, size, createdBy, createdAt, description, skipIndex }`. Status values: `InProgress | Uploading | Indexing | Succeeded | Failed`. Report concisely to the user.

## Procedure — Delete files

Use when the user asks to delete uploaded files from a workspace.

1. Determine env + workspace.
2. **Always confirm with the user before deleting**, especially when no specific file ids are given (the no-ids form deletes *every* file the calling user uploaded into the workspace).
3. Run the helper script:

   **Windows (PowerShell):**

   ```powershell
   # Delete specific file ids
   powershell -ExecutionPolicy Bypass -File "<full-path>\scripts\delete-files.ps1" `
       -WorkspaceId <id> -FileIds 42,43

   # Delete ALL of MY uploads in this workspace (requires -Force)
   powershell -ExecutionPolicy Bypass -File "<full-path>\scripts\delete-files.ps1" `
       -WorkspaceId <id> -Force
   ```

   **Linux / macOS:**

   ```bash
   # Delete specific file ids
   bash "<full-path>/scripts/delete-files.sh" -w <id> 42 43

   # Delete ALL of MY uploads (requires -f)
   bash "<full-path>/scripts/delete-files.sh" -w <id> -f
   ```
4. The output is a JSON array, one entry per attempted delete, each with `{ workspaceId, fileId, httpStatus, success, body }`. Report failures (non-2xx) clearly. A 2xx is final — do not re-run delete unless the user explicitly asks.

## Acquiring a token manually (advanced)

If you need just the token (for example to script other EntityService calls):

```powershell
# Windows
$token = & "<full-path>\scripts\get-token.ps1"            # prod (default)
$token = & "<full-path>\scripts\get-token.ps1" -Environment dev
# add -ForceRefresh to bypass the cached access token
# add -ForceInteractive to re-do the browser login from scratch
```

```bash
# Linux / macOS
token="$(bash <full-path>/scripts/get-token.sh)"           # prod (default)
token="$(bash <full-path>/scripts/get-token.sh --env dev)"
# add --force-refresh / --force-interactive as needed
```

The token is written to stdout; all diagnostics go to stderr.

## Troubleshooting

| Symptom                                      | Likely cause                                                       | Action                                                                                |
| -------------------------------------------- | ------------------------------------------------------------------ | ------------------------------------------------------------------------------------- |
| Browser opens but never returns              | Port `5010` is blocked or already in use                         | Close any process using `5010`, then re-run.                                        |
| HTTP `401 Unauthorized` from EntityService | Cached access token expired and refresh failed                     | Re-run the token helper with `-ForceInteractive` (PowerShell) or `--force-interactive` (bash), or delete the cache file. |
| HTTP `403 Forbidden` from EntityService    | User lacks file-management permission on the workspace             | Ask the user for a workspace they own (or one with `AllCanManageFiles=true`). |
| HTTP `400` with file count / size error    | Workspace `SupportedFileCount` exceeded or unsupported extension | Suggest deleting old files, splitting the upload, or removing unsupported files. |
| Linux: `python3: command not found`        | Headless / minimal image                                           | Install python3 (`apt-get install -y python3`) or pass a token via `-t`/`GENI_TOKEN`. |

## Scripts

- Per-environment config: [./scripts/environments.json](./scripts/environments.json)
- Env auto-detect (Windows): [./scripts/detect-env.ps1](./scripts/detect-env.ps1)
- Env auto-detect (Linux/macOS): [./scripts/detect-env.sh](./scripts/detect-env.sh)
- Token helper (Windows): [./scripts/get-token.ps1](./scripts/get-token.ps1)
- Token helper (Linux/macOS): [./scripts/get-token.sh](./scripts/get-token.sh)
- Upload (Windows): [./scripts/upload-files.ps1](./scripts/upload-files.ps1)
- Upload (Linux/macOS): [./scripts/upload-files.sh](./scripts/upload-files.sh)
- Delete (Windows): [./scripts/delete-files.ps1](./scripts/delete-files.ps1)
- Delete (Linux/macOS): [./scripts/delete-files.sh](./scripts/delete-files.sh)
- Get status (Windows): [./scripts/get-files-status.ps1](./scripts/get-files-status.ps1)
- Get status (Linux/macOS): [./scripts/get-files-status.sh](./scripts/get-files-status.sh)
