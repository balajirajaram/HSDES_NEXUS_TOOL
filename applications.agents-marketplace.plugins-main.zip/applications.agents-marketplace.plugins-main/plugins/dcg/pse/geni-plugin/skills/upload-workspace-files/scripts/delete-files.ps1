<#
.SYNOPSIS
    Delete one, many, or all user-uploaded files from a GENI workspace via the
    EntityService /api/UploadFile/delete endpoint.

.DESCRIPTION
    Sends an HTTP DELETE with a JSON UploadFileDeleteDTO body. If FileIds is
    supplied, one DELETE call is sent per file id (the endpoint accepts a
    single FileId per request). If FileIds is omitted, a single DELETE is
    sent with no FileId, which removes ALL files in the workspace that were
    uploaded by the calling user.

    If no -Token is supplied, the script invokes get-token.ps1 (sibling)
    to acquire one.

.PARAMETER WorkspaceId
    Target workspace numeric id (required).

.PARAMETER FileIds
    Optional. One or more uploaded file ids to delete. If omitted, ALL files
    uploaded by the current user in this workspace are deleted (subject to
    a confirmation prompt unless -Force is supplied).

.PARAMETER Force
    Skip the confirmation prompt when deleting all user-uploaded files.

.PARAMETER Token
    Optional. Bearer access token. If omitted, get-token.ps1 is used.

.PARAMETER Environment
    Target GENI environment: prod (default), dev, or test.

.PARAMETER BaseUrl
    Optional. EntityService base URL. Overrides the URL derived from -Environment.

.EXAMPLE
    .\delete-files.ps1 -WorkspaceId 1234 -FileIds 42,43

.EXAMPLE
    .\delete-files.ps1 -Environment dev -WorkspaceId 1234 -Force
    # Deletes ALL files this user uploaded into workspace 1234 in DEV.
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)] [int]   $WorkspaceId,
    [int[]]    $FileIds,
    [switch]   $Force,
    [string]   $Token,
    [ValidateSet('prod','dev','test')]
    [string]   $Environment = 'prod',
    [string]   $BaseUrl
)

$ErrorActionPreference = 'Stop'

# Auto-detect environment from nearest .mcp.json if -Environment wasn't supplied.
# If detection fails for ANY reason, we always fall back to 'prod' (the default).
if (-not $PSBoundParameters.ContainsKey('Environment')) {
    $detectScript = Join-Path $PSScriptRoot 'detect-env.ps1'
    $detected = $null
    if (Test-Path -LiteralPath $detectScript) {
        try { $detected = & $detectScript } catch { [Console]::Error.WriteLine("[delete-files] env auto-detect failed: $_") }
    }
    if ($detected -and @('prod','dev','test') -contains $detected) {
        [Console]::Error.WriteLine("[delete-files] Auto-detected environment '$detected' from .mcp.json (override with -Environment).")
        $Environment = $detected
    } else {
        [Console]::Error.WriteLine("[delete-files] Could not auto-detect environment; falling back to default '$Environment' (prod).")
    }
}
[Console]::Error.WriteLine("[delete-files] Using environment '$Environment'.")

if (-not $BaseUrl) {
    $envFile = Join-Path $PSScriptRoot 'environments.json'
    if (-not (Test-Path -LiteralPath $envFile)) {
        throw "environments.json not found at: $envFile"
    }
    $envData = Get-Content -Raw -LiteralPath $envFile | ConvertFrom-Json
    if (-not $envData.environments.$Environment) {
        throw "Unknown environment '$Environment' (not present in environments.json)."
    }
    $BaseUrl = $envData.environments.$Environment.baseUrl
}

function Write-Info { param([string]$Message) [Console]::Error.WriteLine("[delete-files][$Environment] $Message") }

if (-not $Token) {
    $tokenScript = Join-Path $PSScriptRoot 'get-token.ps1'
    if (-not (Test-Path -LiteralPath $tokenScript)) {
        throw "Token not provided and helper not found at: $tokenScript"
    }
    Write-Info "No token supplied; invoking get-token.ps1 -Environment $Environment..."
    $Token = & $tokenScript -Environment $Environment
    if (-not $Token) { throw "get-token.ps1 returned no token." }
}

if (-not $FileIds -or $FileIds.Count -eq 0) {
    if (-not $Force) {
        Write-Info "About to delete ALL files YOU uploaded into workspace $WorkspaceId ($Environment). Re-run with -Force to confirm, or pass -FileIds <id,...> to scope the deletion."
        exit 2
    }
    $targets = @($null)  # single call with no FileId
} else {
    $targets = $FileIds
}

Add-Type -AssemblyName System.Net.Http
$client = New-Object System.Net.Http.HttpClient
$client.Timeout = [TimeSpan]::FromMinutes(5)

$results = New-Object System.Collections.Generic.List[object]
try {
    foreach ($fid in $targets) {
        $payload = [ordered]@{ WorkspaceId = $WorkspaceId }
        if ($null -ne $fid) { $payload.FileId = [int]$fid }
        $json = $payload | ConvertTo-Json -Compress

        $uri = "$BaseUrl/api/UploadFile/delete"
        $request = New-Object System.Net.Http.HttpRequestMessage([System.Net.Http.HttpMethod]::Delete, $uri)
        $request.Headers.Authorization = New-Object System.Net.Http.Headers.AuthenticationHeaderValue('Bearer', $Token)
        $request.Headers.Accept.Add([System.Net.Http.Headers.MediaTypeWithQualityHeaderValue]::Parse('application/json'))
        $request.Content = New-Object System.Net.Http.StringContent($json, [System.Text.Encoding]::UTF8, 'application/json')

        $label = if ($null -ne $fid) { "fileId=$fid" } else { 'ALL user files' }
        Write-Info "DELETE $uri  ($label)"
        $response = $client.SendAsync($request).GetAwaiter().GetResult()
        $body = $response.Content.ReadAsStringAsync().GetAwaiter().GetResult()
        $status = [int]$response.StatusCode

        $entry = [ordered]@{
            workspaceId = $WorkspaceId
            fileId      = $fid
            httpStatus  = $status
            success     = $response.IsSuccessStatusCode
            body        = $body
        }
        $results.Add([pscustomobject]$entry)

        if (-not $response.IsSuccessStatusCode) {
            Write-Info "HTTP $status $($response.ReasonPhrase): $body"
        } else {
            Write-Info "Deleted ($status)."
        }
    }
}
finally {
    try { $client.Dispose() } catch {}
}

Write-Output ($results | ConvertTo-Json -Depth 4)
$failed = @($results | Where-Object { -not $_.success })
if ($failed.Count -gt 0) { exit 1 }
