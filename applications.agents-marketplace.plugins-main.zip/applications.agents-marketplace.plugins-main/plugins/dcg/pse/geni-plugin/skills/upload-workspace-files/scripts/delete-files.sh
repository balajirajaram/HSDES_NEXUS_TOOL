#!/usr/bin/env bash
# Delete one, many, or all user-uploaded files from a GENI workspace via
# EntityService DELETE /api/UploadFile/delete (UploadFileDeleteDTO body).
#
# If no file ids are supplied, ALL files uploaded by the current user in
# the workspace are deleted (requires -f to confirm).
#
# Usage:
#   delete-files.sh -w WORKSPACE_ID [-e ENV] [-t TOKEN] [-f] [fileId ...]
#
# Options:
#   -w  Workspace id (required)
#   -e  Environment: prod (default), dev, test
#   -t  Bearer token (else GENI_TOKEN env, else get-token.sh)
#   -f  Force: when no file ids are supplied, allow deleting ALL user files
#   -u  Base URL (overrides URL derived from -e)

set -euo pipefail

ENVIRONMENT='prod'
ENV_EXPLICIT=0
BASE_URL=''
WORKSPACE_ID=""
TOKEN="${GENI_TOKEN:-}"
FORCE="false"

while getopts ":w:e:t:fu:" opt; do
    case "$opt" in
        w) WORKSPACE_ID="$OPTARG" ;;
        e) ENVIRONMENT="$OPTARG"; ENV_EXPLICIT=1 ;;
        t) TOKEN="$OPTARG" ;;
        f) FORCE="true" ;;
        u) BASE_URL="$OPTARG" ;;
        \?) echo "Unknown option: -$OPTARG" >&2; exit 2 ;;
        :)  echo "Option -$OPTARG requires an argument" >&2; exit 2 ;;
    esac
done
shift $((OPTIND - 1))

# Auto-detect environment from nearest .mcp.json if -e wasn't supplied.
# If detection fails for ANY reason, we always fall back to 'prod' (the default).
if [[ "$ENV_EXPLICIT" -eq 0 ]]; then
    _SD="$(cd "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
    _DETECTED=""
    if [[ -f "$_SD/detect-env.sh" ]]; then
        _DETECTED="$(bash "$_SD/detect-env.sh" 2>/dev/null || true)"
    fi
    case "$_DETECTED" in
        prod|dev|test)
            echo "[delete-files] Auto-detected environment '$_DETECTED' from .mcp.json (override with -e)." >&2
            ENVIRONMENT="$_DETECTED"
            ;;
        *)
            echo "[delete-files] Could not auto-detect environment; falling back to default '$ENVIRONMENT' (prod)." >&2
            ;;
    esac
fi
echo "[delete-files] Using environment '$ENVIRONMENT'." >&2

case "$ENVIRONMENT" in
    prod|dev|test) ;;
    *) echo "ERROR: -e must be prod, dev, or test (got: $ENVIRONMENT)" >&2; exit 2 ;;
esac

if [[ -z "$BASE_URL" ]]; then
    SCRIPT_DIR="$(cd "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
    ENV_FILE="${SCRIPT_DIR}/environments.json"
    if [[ ! -f "$ENV_FILE" ]]; then
        echo "ERROR: environments.json not found at: $ENV_FILE" >&2; exit 1
    fi
    if ! command -v python3 >/dev/null 2>&1; then
        echo "ERROR: python3 required to read environments.json (or pass -u <baseUrl>)" >&2; exit 1
    fi
    BASE_URL="$(ENV_FILE="$ENV_FILE" ENV_NAME="$ENVIRONMENT" python3 -c '
import json, os
print(json.load(open(os.environ["ENV_FILE"]))["environments"][os.environ["ENV_NAME"]]["baseUrl"])
')"
fi

if [[ -z "$WORKSPACE_ID" ]]; then echo "ERROR: -w WORKSPACE_ID is required" >&2; exit 2; fi

FILE_IDS=("$@")

if [[ ${#FILE_IDS[@]} -eq 0 && "$FORCE" != "true" ]]; then
    echo "[delete-files][$ENVIRONMENT] About to delete ALL files YOU uploaded into workspace $WORKSPACE_ID. Re-run with -f to confirm, or pass file ids." >&2
    exit 2
fi

if [[ -z "$TOKEN" ]]; then
    SCRIPT_DIR="$(cd "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
    TOKEN_SCRIPT="$SCRIPT_DIR/get-token.sh"
    if [[ ! -x "$TOKEN_SCRIPT" && -f "$TOKEN_SCRIPT" ]]; then chmod +x "$TOKEN_SCRIPT" || true; fi
    if [[ ! -f "$TOKEN_SCRIPT" ]]; then
        echo "ERROR: no token provided and helper not found: $TOKEN_SCRIPT" >&2; exit 2
    fi
    echo "[delete-files][$ENVIRONMENT] No token supplied; invoking get-token.sh --env $ENVIRONMENT..." >&2
    TOKEN="$("$TOKEN_SCRIPT" --env "$ENVIRONMENT")"
    if [[ -z "$TOKEN" ]]; then echo "ERROR: get-token.sh returned no token" >&2; exit 1; fi
fi

URL="${BASE_URL%/}/api/UploadFile/delete"

# Build list of payloads — one per call (endpoint accepts a single FileId per request)
if [[ ${#FILE_IDS[@]} -eq 0 ]]; then
    PAYLOADS=("{\"WorkspaceId\":${WORKSPACE_ID}}")
    LABELS=("ALL user files")
else
    PAYLOADS=()
    LABELS=()
    for fid in "${FILE_IDS[@]}"; do
        PAYLOADS+=("{\"WorkspaceId\":${WORKSPACE_ID},\"FileId\":${fid}}")
        LABELS+=("fileId=${fid}")
    done
fi

ANY_FAILED="false"
RESULTS_JSON="["
FIRST="true"
for i in "${!PAYLOADS[@]}"; do
    payload="${PAYLOADS[$i]}"
    label="${LABELS[$i]}"
    echo "[delete-files][$ENVIRONMENT] DELETE $URL  ($label)" >&2

    RESPONSE="$(curl -sS -X DELETE \
        -H "Authorization: Bearer $TOKEN" \
        -H "Content-Type: application/json" \
        -H "Accept: application/json" \
        -d "$payload" \
        -w "\n__HTTP_STATUS__:%{http_code}" \
        "$URL")"
    STATUS="${RESPONSE##*__HTTP_STATUS__:}"
    BODY="${RESPONSE%$'\n'__HTTP_STATUS__:*}"

    SUCCESS="true"
    if [[ "$STATUS" -lt 200 || "$STATUS" -ge 300 ]]; then
        SUCCESS="false"
        ANY_FAILED="true"
        echo "[delete-files][$ENVIRONMENT] HTTP $STATUS: $BODY" >&2
    else
        echo "[delete-files][$ENVIRONMENT] Deleted ($STATUS)." >&2
    fi

    # Escape body for embedding in JSON output
    ESCAPED_BODY="$(BODY="$BODY" python3 -c 'import json,os; print(json.dumps(os.environ["BODY"]))')"
    if [[ "$FIRST" == "true" ]]; then FIRST="false"; else RESULTS_JSON+=","; fi
    if [[ -n "${FILE_IDS[$i]:-}" ]]; then FID_JSON="${FILE_IDS[$i]}"; else FID_JSON="null"; fi
    RESULTS_JSON+="{\"workspaceId\":${WORKSPACE_ID},\"fileId\":${FID_JSON},\"httpStatus\":${STATUS},\"success\":${SUCCESS},\"body\":${ESCAPED_BODY}}"
done
RESULTS_JSON+="]"
echo "$RESULTS_JSON"

if [[ "$ANY_FAILED" == "true" ]]; then exit 1; fi
