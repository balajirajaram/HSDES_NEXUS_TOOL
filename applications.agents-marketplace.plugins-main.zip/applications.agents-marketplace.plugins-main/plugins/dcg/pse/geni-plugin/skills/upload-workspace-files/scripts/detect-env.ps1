<#
.SYNOPSIS
    Detect the GENI environment (prod | dev | test) by inspecting the URL
    of the local "Intel Geni" MCP server entry in the nearest .mcp.json
    walking up from this script directory.

.DESCRIPTION
    Reads url->env hints from sibling environments.json (mcpUrlHints array)
    and matches against any mcpServers[*].url found in the first .mcp.json
    encountered. Writes the detected env name to stdout. Writes diagnostics
    to stderr. Exits with code 0 on success, 1 on no match (and prints
    nothing to stdout).

    NOTE: This helper only *detects*. Callers are responsible for the
    fallback policy when detection fails. Across this skill, the agreed
    fallback is always **prod**.
#>
[CmdletBinding()]
param()

$ErrorActionPreference = 'Stop'

function Write-Info { param([string]$Message) [Console]::Error.WriteLine("[detect-env] $Message") }

$envFile = Join-Path $PSScriptRoot 'environments.json'
if (-not (Test-Path -LiteralPath $envFile)) {
    Write-Info "environments.json not found at: $envFile"
    exit 1
}
$envData = Get-Content -Raw -LiteralPath $envFile | ConvertFrom-Json
$hints = @($envData.mcpUrlHints)
if ($hints.Count -eq 0) { Write-Info "No mcpUrlHints in environments.json"; exit 1 }

$dir = $PSScriptRoot
for ($i = 0; $i -lt 10 -and $dir; $i++) {
    $mcpFile = Join-Path $dir '.mcp.json'
    if (Test-Path -LiteralPath $mcpFile) {
        try {
            $mcpData = Get-Content -Raw -LiteralPath $mcpFile | ConvertFrom-Json
            $servers = @()
            if ($mcpData.mcpServers) {
                $servers = @($mcpData.mcpServers.PSObject.Properties.Value)
            }
            foreach ($srv in $servers) {
                $url = $srv.url
                if (-not $url) { continue }
                foreach ($hint in $hints) {
                    if ($url.ToLower().Contains($hint.match.ToLower())) {
                        Write-Info "Matched '$($hint.match)' in $mcpFile (url=$url) -> $($hint.env)"
                        Write-Output $hint.env
                        exit 0
                    }
                }
            }
        } catch {
            Write-Info "Could not parse $mcpFile : $_"
        }
    }
    $parent = Split-Path -Parent $dir
    if ($parent -eq $dir) { break }
    $dir = $parent
}

Write-Info "No .mcp.json with a matching MCP server URL found."
exit 1
