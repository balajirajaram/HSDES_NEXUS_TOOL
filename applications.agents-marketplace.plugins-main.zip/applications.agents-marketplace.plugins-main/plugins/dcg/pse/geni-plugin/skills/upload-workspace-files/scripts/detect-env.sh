#!/usr/bin/env bash
# Detect the GENI environment (prod | dev | test) by inspecting the URL of the
# local "Intel Geni" MCP server entry in the nearest .mcp.json walking up from
# this script's directory.
#
# Reads url->env hints from sibling environments.json (mcpUrlHints array).
# Writes detected env name to stdout; diagnostics to stderr.
# Exit 0 on match, 1 otherwise.
#
# NOTE: This helper only *detects*. Callers are responsible for the fallback
# policy when detection fails. Across this skill, the agreed fallback is
# always **prod**.

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
ENV_FILE="${SCRIPT_DIR}/environments.json"

log() { echo "[detect-env] $*" >&2; }

if [[ ! -f "$ENV_FILE" ]]; then
    log "environments.json not found at: $ENV_FILE"
    exit 1
fi
if ! command -v python3 >/dev/null 2>&1; then
    log "python3 required"
    exit 1
fi

# Walk up to 10 levels looking for .mcp.json
dir="$SCRIPT_DIR"
for _ in 1 2 3 4 5 6 7 8 9 10; do
    if [[ -f "$dir/.mcp.json" ]]; then
        RESULT="$(ENV_FILE="$ENV_FILE" MCP_FILE="$dir/.mcp.json" python3 - <<'PY' 2>/dev/null || true
import json, os, sys
try:
    env_data = json.load(open(os.environ["ENV_FILE"]))
    mcp_data = json.load(open(os.environ["MCP_FILE"]))
except Exception as e:
    sys.exit(1)
hints = env_data.get("mcpUrlHints") or []
servers = (mcp_data.get("mcpServers") or {})
for _, srv in servers.items():
    url = (srv or {}).get("url") or ""
    if not url:
        continue
    url_l = url.lower()
    for h in hints:
        m = (h.get("match") or "").lower()
        if m and m in url_l:
            print(f"{h.get('env')}|{h.get('match')}|{url}")
            sys.exit(0)
sys.exit(1)
PY
)"
        if [[ -n "$RESULT" ]]; then
            IFS='|' read -r ENV_NAME MATCH URL <<< "$RESULT"
            log "Matched '$MATCH' in $dir/.mcp.json (url=$URL) -> $ENV_NAME"
            echo "$ENV_NAME"
            exit 0
        fi
    fi
    parent="$(dirname -- "$dir")"
    if [[ "$parent" == "$dir" ]]; then break; fi
    dir="$parent"
done

log "No .mcp.json with a matching MCP server URL found."
exit 1
