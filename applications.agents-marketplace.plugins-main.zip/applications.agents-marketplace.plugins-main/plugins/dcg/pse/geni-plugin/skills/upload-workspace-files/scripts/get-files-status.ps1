<#
.SYNOPSIS
    Get the status of files uploaded to a GENI workspace via the
    EntityService GET /api/Workspace/{id}/resources endpoint.

.DESCRIPTION
    Returns the workspace resources payload. By default emits only the
    relevant fields per uploaded file (id, name, status, errorMessage,
    size, createdBy, createdAt, description, skipIndex). Use -Raw to
    return the full WorkspaceDTO JSON unchanged.

    Optional -FileIds filters the output to a subset of file ids.

    UploadFileStatusDTO values: InProgress | Uploading | Indexing |
    Succeeded | Failed.

.PARAMETER WorkspaceId
    Target workspace numeric id (required).

.PARAMETER FileIds
    Optional. If supplied, only files whose id is in this list are returned.

.PARAMETER Raw
    If set, the full WorkspaceDTO response is emitted instead of the
    summarised uploadFiles array.

.PARAMETER Token
    Optional. Bearer access token. If omitted, get-token.ps1 is used.

.PARAMETER Environment
    Target GENI environment: prod (default), dev, or test.

.PARAMETER BaseUrl
    Optional. EntityService base URL. Overrides the URL derived from -Environment.

.EXAMPLE
    .\get-files-status.ps1 -WorkspaceId 1234
    # Summary of every uploaded file in the workspace.

.EXAMPLE
    .\get-files-status.ps1 -WorkspaceId 1234 -FileIds 42,43 -Environment dev
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)] [int] $WorkspaceId,
    [int[]]    $FileIds,
    [switch]   $Raw,
    [string]   $Token,
    [ValidateSet('prod','dev','test')]
    [string]   $Environment = 'prod',
    [string]   $BaseUrl
)

$ErrorActionPreference = 'Stop'

# Auto-detect environment from nearest .mcp.json if -Environment wasn't supplied.
# If detection fails for ANY reason, we always fall back to 'prod' (the default).
if (-not $PSBoundParameters.ContainsKey('Environment')) {
    $detectScript = Join-Path $PSScriptRoot 'detect-env.ps1'
    $detected = $null
    if (Test-Path -LiteralPath $detectScript) {
        try { $detected = & $detectScript } catch { [Console]::Error.WriteLine("[get-files-status] env auto-detect failed: $_") }
    }
    if ($detected -and @('prod','dev','test') -contains $detected) {
        [Console]::Error.WriteLine("[get-files-status] Auto-detected environment '$detected' from .mcp.json (override with -Environment).")
        $Environment = $detected
    } else {
        [Console]::Error.WriteLine("[get-files-status] Could not auto-detect environment; falling back to default '$Environment' (prod).")
    }
}
[Console]::Error.WriteLine("[get-files-status] Using environment '$Environment'.")

if (-not $BaseUrl) {
    $envFile = Join-Path $PSScriptRoot 'environments.json'
    if (-not (Test-Path -LiteralPath $envFile)) {
        throw "environments.json not found at: $envFile"
    }
    $envData = Get-Content -Raw -LiteralPath $envFile | ConvertFrom-Json
    if (-not $envData.environments.$Environment) {
        throw "Unknown environment '$Environment' (not present in environments.json)."
    }
    $BaseUrl = $envData.environments.$Environment.baseUrl
}

function Write-Info { param([string]$Message) [Console]::Error.WriteLine("[get-files-status][$Environment] $Message") }

if (-not $Token) {
    $tokenScript = Join-Path $PSScriptRoot 'get-token.ps1'
    if (-not (Test-Path -LiteralPath $tokenScript)) {
        throw "Token not provided and helper not found at: $tokenScript"
    }
    Write-Info "No token supplied; invoking get-token.ps1 -Environment $Environment..."
    $Token = & $tokenScript -Environment $Environment
    if (-not $Token) { throw "get-token.ps1 returned no token." }
}

Add-Type -AssemblyName System.Net.Http
$client = New-Object System.Net.Http.HttpClient
$client.Timeout = [TimeSpan]::FromMinutes(2)

try {
    $uri = "$BaseUrl/api/Workspace/$WorkspaceId/resources"
    $request = New-Object System.Net.Http.HttpRequestMessage([System.Net.Http.HttpMethod]::Get, $uri)
    $request.Headers.Authorization = New-Object System.Net.Http.Headers.AuthenticationHeaderValue('Bearer', $Token)
    $request.Headers.Accept.Add([System.Net.Http.Headers.MediaTypeWithQualityHeaderValue]::Parse('application/json'))

    Write-Info "GET $uri"
    $response = $client.SendAsync($request).GetAwaiter().GetResult()
    $body = $response.Content.ReadAsStringAsync().GetAwaiter().GetResult()

    if (-not $response.IsSuccessStatusCode) {
        Write-Info "HTTP $([int]$response.StatusCode) $($response.ReasonPhrase)"
        Write-Output $body
        exit 1
    }

    if ($Raw) { Write-Output $body; return }

    $parsed = $body | ConvertFrom-Json
    $files  = @()
    if ($parsed.resources -and $parsed.resources.uploadFiles) {
        $files = @($parsed.resources.uploadFiles)
    }

    if ($FileIds -and $FileIds.Count -gt 0) {
        $wanted = @{}
        foreach ($id in $FileIds) { $wanted[[int]$id] = $true }
        $files = @($files | Where-Object { $wanted.ContainsKey([int]$_.id) })
    }

    $summary = @($files | ForEach-Object {
        [ordered]@{
            id           = $_.id
            name         = $_.name
            status       = $_.status
            errorMessage = $_.errorMessage
            size         = $_.size
            createdBy    = $_.createdBy
            createdAt    = $_.createdAt
            description  = $_.description
            skipIndex    = $_.skipIndex
        }
    })

    Write-Info "Returned $($summary.Count) file(s)."
    Write-Output (ConvertTo-Json -InputObject $summary -Depth 4)
}
finally {
    try { $client.Dispose() } catch {}
}
