#!/usr/bin/env bash
# Get the status of files uploaded to a GENI workspace via
# EntityService GET /api/Workspace/{id}/resources.
#
# By default emits a summarised JSON array of uploadFiles (id, name, status,
# errorMessage, size, createdBy, createdAt, description, skipIndex).
# Use -r to emit the raw WorkspaceDTO unchanged.
#
# UploadFileStatusDTO values: InProgress | Uploading | Indexing | Succeeded | Failed.
#
# Usage:
#   get-files-status.sh -w WORKSPACE_ID [-e ENV] [-t TOKEN] [-r] [fileId ...]
#
# Options:
#   -w  Workspace id (required)
#   -e  Environment: prod (default), dev, test
#   -t  Bearer token (else GENI_TOKEN env, else get-token.sh)
#   -r  Raw: emit full WorkspaceDTO response unchanged (no filtering)
#   -u  Base URL (overrides URL derived from -e)

set -euo pipefail

ENVIRONMENT='prod'
ENV_EXPLICIT=0
BASE_URL=''
WORKSPACE_ID=""
TOKEN="${GENI_TOKEN:-}"
RAW="false"

while getopts ":w:e:t:ru:" opt; do
    case "$opt" in
        w) WORKSPACE_ID="$OPTARG" ;;
        e) ENVIRONMENT="$OPTARG"; ENV_EXPLICIT=1 ;;
        t) TOKEN="$OPTARG" ;;
        r) RAW="true" ;;
        u) BASE_URL="$OPTARG" ;;
        \?) echo "Unknown option: -$OPTARG" >&2; exit 2 ;;
        :)  echo "Option -$OPTARG requires an argument" >&2; exit 2 ;;
    esac
done
shift $((OPTIND - 1))

# Auto-detect environment from nearest .mcp.json if -e wasn't supplied.
# If detection fails for ANY reason, we always fall back to 'prod' (the default).
if [[ "$ENV_EXPLICIT" -eq 0 ]]; then
    _SD="$(cd "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
    _DETECTED=""
    if [[ -f "$_SD/detect-env.sh" ]]; then
        _DETECTED="$(bash "$_SD/detect-env.sh" 2>/dev/null || true)"
    fi
    case "$_DETECTED" in
        prod|dev|test)
            echo "[get-files-status] Auto-detected environment '$_DETECTED' from .mcp.json (override with -e)." >&2
            ENVIRONMENT="$_DETECTED"
            ;;
        *)
            echo "[get-files-status] Could not auto-detect environment; falling back to default '$ENVIRONMENT' (prod)." >&2
            ;;
    esac
fi
echo "[get-files-status] Using environment '$ENVIRONMENT'." >&2

case "$ENVIRONMENT" in
    prod|dev|test) ;;
    *) echo "ERROR: -e must be prod, dev, or test (got: $ENVIRONMENT)" >&2; exit 2 ;;
esac

if [[ -z "$BASE_URL" ]]; then
    SCRIPT_DIR="$(cd "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
    ENV_FILE="${SCRIPT_DIR}/environments.json"
    if [[ ! -f "$ENV_FILE" ]]; then
        echo "ERROR: environments.json not found at: $ENV_FILE" >&2; exit 1
    fi
    if ! command -v python3 >/dev/null 2>&1; then
        echo "ERROR: python3 required to read environments.json (or pass -u <baseUrl>)" >&2; exit 1
    fi
    BASE_URL="$(ENV_FILE="$ENV_FILE" ENV_NAME="$ENVIRONMENT" python3 -c '
import json, os
print(json.load(open(os.environ["ENV_FILE"]))["environments"][os.environ["ENV_NAME"]]["baseUrl"])
')"
fi

if [[ -z "$WORKSPACE_ID" ]]; then echo "ERROR: -w WORKSPACE_ID is required" >&2; exit 2; fi

FILTER_IDS=("$@")

if [[ -z "$TOKEN" ]]; then
    SCRIPT_DIR="$(cd "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
    TOKEN_SCRIPT="$SCRIPT_DIR/get-token.sh"
    if [[ ! -x "$TOKEN_SCRIPT" && -f "$TOKEN_SCRIPT" ]]; then chmod +x "$TOKEN_SCRIPT" || true; fi
    if [[ ! -f "$TOKEN_SCRIPT" ]]; then
        echo "ERROR: no token provided and helper not found: $TOKEN_SCRIPT" >&2; exit 2
    fi
    echo "[get-files-status][$ENVIRONMENT] No token supplied; invoking get-token.sh --env $ENVIRONMENT..." >&2
    TOKEN="$("$TOKEN_SCRIPT" --env "$ENVIRONMENT")"
    if [[ -z "$TOKEN" ]]; then echo "ERROR: get-token.sh returned no token" >&2; exit 1; fi
fi

URL="${BASE_URL%/}/api/Workspace/${WORKSPACE_ID}/resources"
echo "[get-files-status][$ENVIRONMENT] GET $URL" >&2

RESPONSE="$(curl -sS -X GET \
    -H "Authorization: Bearer $TOKEN" \
    -H "Accept: application/json" \
    -w "\n__HTTP_STATUS__:%{http_code}" \
    "$URL")"
STATUS="${RESPONSE##*__HTTP_STATUS__:}"
BODY="${RESPONSE%$'\n'__HTTP_STATUS__:*}"

if [[ "$STATUS" -lt 200 || "$STATUS" -ge 300 ]]; then
    echo "$BODY"
    echo "[get-files-status][$ENVIRONMENT] HTTP $STATUS" >&2
    exit 1
fi

if [[ "$RAW" == "true" ]]; then
    echo "$BODY"
    exit 0
fi

if ! command -v python3 >/dev/null 2>&1; then
    echo "ERROR: python3 required to summarise response (use -r for raw output)" >&2; exit 1
fi

# Filter list as space-separated string for python
FILTER_STR="${FILTER_IDS[*]:-}"

SUMMARY="$(BODY="$BODY" FILTER_STR="$FILTER_STR" python3 - <<'PY'
import json, os, sys
data = json.loads(os.environ["BODY"])
files = (data.get("resources") or {}).get("uploadFiles") or []
flt = os.environ.get("FILTER_STR", "").split()
if flt:
    wanted = {int(x) for x in flt}
    files = [f for f in files if int(f.get("id", -1)) in wanted]
keys = ["id", "name", "status", "errorMessage", "size",
        "createdBy", "createdAt", "description", "skipIndex"]
out = [{k: f.get(k) for k in keys} for f in files]
print(json.dumps(out, indent=2))
print(f"[summary] {len(out)} file(s)", file=sys.stderr)
PY
)"
echo "$SUMMARY"
