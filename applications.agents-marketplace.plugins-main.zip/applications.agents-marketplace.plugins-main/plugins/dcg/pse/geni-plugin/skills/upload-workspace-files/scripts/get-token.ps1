<#
.SYNOPSIS
    Acquire / refresh an Azure AD access token for the GENI EntityService.

.DESCRIPTION
    Implements an MSAL-equivalent OAuth2 Authorization Code flow with PKCE for
    a public client. On first run it opens a browser, on subsequent runs it
    silently refreshes (or reuses) the cached token.

    Token cache lives at:
        %LOCALAPPDATA%\Geni_EntityService\.token_cache_<env>.json

    On success the access token is printed to stdout as a single line.
    All diagnostic messages go to stderr so the stdout is safe to capture.

.PARAMETER Environment
    Target GENI environment: prod (default), dev, or test. Each environment
    has its own Azure AD client id, scope, and token cache file.

.PARAMETER ForceRefresh
    Ignore any cached access token and refresh using the refresh token
    (or fall back to interactive login if needed).

.PARAMETER ForceInteractive
    Ignore the entire cache and start a fresh browser login.

.EXAMPLE
    $token = & .\get-token.ps1
    Invoke-RestMethod -Uri ... -Headers @{ Authorization = "Bearer $token" }
#>
[CmdletBinding()]
param(
    [ValidateSet('prod','dev','test')]
    [string]$Environment = 'prod',
    [switch]$ForceRefresh,
    [switch]$ForceInteractive
)

$ErrorActionPreference = 'Stop'

# Auto-detect environment from nearest .mcp.json if -Environment wasn't supplied.
# If detection fails for ANY reason, we always fall back to 'prod' (the default).
if (-not $PSBoundParameters.ContainsKey('Environment')) {
    $detectScript = Join-Path $PSScriptRoot 'detect-env.ps1'
    $detected = $null
    if (Test-Path -LiteralPath $detectScript) {
        try { $detected = & $detectScript } catch { [Console]::Error.WriteLine("[get-token] env auto-detect failed: $_") }
    }
    if ($detected -and @('prod','dev','test') -contains $detected) {
        [Console]::Error.WriteLine("[get-token] Auto-detected environment '$detected' from .mcp.json (override with -Environment).")
        $Environment = $detected
    } else {
        [Console]::Error.WriteLine("[get-token] Could not auto-detect environment; falling back to default '$Environment' (prod).")
    }
}
[Console]::Error.WriteLine("[get-token] Using environment '$Environment'.")

# ---------------------------------------------------------------------------
# Load shared per-environment configuration (sibling environments.json)
# ---------------------------------------------------------------------------
$EnvFile = Join-Path $PSScriptRoot 'environments.json'
if (-not (Test-Path -LiteralPath $EnvFile)) {
    throw "environments.json not found at: $EnvFile"
}
$EnvData = Get-Content -Raw -LiteralPath $EnvFile | ConvertFrom-Json
if (-not $EnvData.environments.$Environment) {
    throw "Unknown environment '$Environment' (not present in environments.json)."
}

$TenantId      = $EnvData.tenant
$ClientId      = $EnvData.environments.$Environment.clientId
$Scopes        = @($EnvData.scopes | ForEach-Object { $_ -replace '\{clientId\}', $ClientId })
$CallbackPort  = [int]$EnvData.callbackPort
$CallbackRoute = $EnvData.callbackRoute
$RedirectUri   = "http://localhost:$CallbackPort/$CallbackRoute"
$Authority     = "https://login.microsoftonline.com/$TenantId"
$AuthEndpoint  = "$Authority/oauth2/v2.0/authorize"
$TokenEndpoint = "$Authority/oauth2/v2.0/token"

$CacheDir = Join-Path $env:LOCALAPPDATA 'Geni_EntityService'
if (-not (Test-Path $CacheDir)) {
    New-Item -ItemType Directory -Path $CacheDir -Force | Out-Null
}
$CacheFile = Join-Path $CacheDir ".token_cache_${Environment}.json"

function Write-Info { param([string]$Message) [Console]::Error.WriteLine("[get-token][$Environment] $Message") }

function New-CodeVerifier {
    $bytes = New-Object byte[] 64
    [System.Security.Cryptography.RandomNumberGenerator]::Create().GetBytes($bytes)
    return ([Convert]::ToBase64String($bytes)) -replace '\+','-' -replace '/','_' -replace '=',''
}

function ConvertTo-CodeChallenge {
    param([string]$Verifier)
    $sha = [System.Security.Cryptography.SHA256]::Create()
    $hash = $sha.ComputeHash([System.Text.Encoding]::ASCII.GetBytes($Verifier))
    return ([Convert]::ToBase64String($hash)) -replace '\+','-' -replace '/','_' -replace '=',''
}

function Read-Cache {
    if (-not (Test-Path $CacheFile)) { return $null }
    try {
        return Get-Content -Raw -Path $CacheFile | ConvertFrom-Json
    } catch {
        Write-Info "Cache unreadable, ignoring: $($_.Exception.Message)"
        return $null
    }
}

function Save-Cache {
    param($TokenPayload)
    $now = [DateTimeOffset]::UtcNow.ToUnixTimeSeconds()
    $cache = [ordered]@{
        access_token  = $TokenPayload.access_token
        refresh_token = $TokenPayload.refresh_token
        expires_at    = $now + [int]$TokenPayload.expires_in
        scope         = $TokenPayload.scope
        token_type    = $TokenPayload.token_type
    }
    $cache | ConvertTo-Json -Depth 4 | Set-Content -Path $CacheFile -Encoding UTF8
}

function Invoke-InteractiveLogin {
    Write-Info "Starting interactive browser login..."

    $verifier  = New-CodeVerifier
    $challenge = ConvertTo-CodeChallenge $verifier
    $state     = [Guid]::NewGuid().ToString('N')

    $queryParts = @(
        "client_id=$ClientId",
        "response_type=code",
        "redirect_uri=$([uri]::EscapeDataString($RedirectUri))",
        "response_mode=query",
        "scope=$([uri]::EscapeDataString(($Scopes -join ' ')))",
        "state=$state",
        "code_challenge=$challenge",
        "code_challenge_method=S256",
        "prompt=select_account"
    )
    $authUri = "$AuthEndpoint`?$([string]::Join('&', $queryParts))"

    $listener = New-Object System.Net.HttpListener
    $listener.Prefixes.Add("http://localhost:$CallbackPort/")
    $listener.Start()

    try {
        Write-Info "Opening browser..."
        Start-Process $authUri | Out-Null

        $contextTask = $listener.GetContextAsync()
        if (-not $contextTask.Wait([TimeSpan]::FromSeconds(180))) {
            throw "Timed out waiting for Azure AD callback after 180s."
        }
        $context = $contextTask.Result

        $query = [System.Web.HttpUtility]::ParseQueryString($context.Request.Url.Query)
        $code         = $query['code']
        $returnedState= $query['state']
        $err          = $query['error']
        $errDesc      = $query['error_description']

        $body = if ($err) {
            "<h3>Login failed: $err</h3><p>$errDesc</p>"
        } else {
            "<h3>Login successful. You can close this tab.</h3>"
        }
        $bytes = [System.Text.Encoding]::UTF8.GetBytes($body)
        $context.Response.ContentType = 'text/html'
        $context.Response.StatusCode  = 200
        $context.Response.OutputStream.Write($bytes, 0, $bytes.Length)
        $context.Response.OutputStream.Close()

        if ($err) { throw "Auth callback returned error: $err - $errDesc" }
        if (-not $code) { throw "Auth callback missing 'code' parameter." }
        if ($returnedState -ne $state) { throw "State mismatch in auth callback (possible CSRF)." }
    }
    finally {
        try { $listener.Stop() } catch {}
        try { $listener.Close() } catch {}
    }

    Write-Info "Exchanging auth code for tokens..."
    $tokenBody = @{
        client_id     = $ClientId
        grant_type    = 'authorization_code'
        code          = $code
        redirect_uri  = $RedirectUri
        code_verifier = $verifier
        scope         = ($Scopes -join ' ')
    }
    return Invoke-RestMethod -Method POST -Uri $TokenEndpoint -Body $tokenBody -ContentType 'application/x-www-form-urlencoded'
}

function Invoke-RefreshLogin {
    param([string]$RefreshToken)
    Write-Info "Refreshing access token using refresh_token..."
    $body = @{
        client_id     = $ClientId
        grant_type    = 'refresh_token'
        refresh_token = $RefreshToken
        scope         = ($Scopes -join ' ')
    }
    return Invoke-RestMethod -Method POST -Uri $TokenEndpoint -Body $body -ContentType 'application/x-www-form-urlencoded'
}

Add-Type -AssemblyName System.Web

$cache = if ($ForceInteractive) { $null } else { Read-Cache }
$now   = [DateTimeOffset]::UtcNow.ToUnixTimeSeconds()
$skewSeconds = 600  # refresh if <10 min remaining (large uploads may take a while)

$accessToken = $null

if ($cache -and -not $ForceRefresh -and $cache.access_token -and ($cache.expires_at - $now) -gt $skewSeconds) {
    Write-Info "Reusing cached access token (expires in $($cache.expires_at - $now)s)."
    $accessToken = $cache.access_token
}
elseif ($cache -and $cache.refresh_token -and -not $ForceInteractive) {
    try {
        $payload = Invoke-RefreshLogin -RefreshToken $cache.refresh_token
        Save-Cache $payload
        $accessToken = $payload.access_token
    } catch {
        Write-Info "Refresh failed ($($_.Exception.Message)); falling back to interactive login."
        $payload = Invoke-InteractiveLogin
        Save-Cache $payload
        $accessToken = $payload.access_token
    }
}
else {
    $payload = Invoke-InteractiveLogin
    Save-Cache $payload
    $accessToken = $payload.access_token
}

if (-not $accessToken) { throw "Failed to acquire access token." }

# stdout: token only
Write-Output $accessToken
