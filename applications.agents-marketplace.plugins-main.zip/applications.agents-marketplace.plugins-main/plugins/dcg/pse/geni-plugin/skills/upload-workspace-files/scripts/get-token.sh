#!/usr/bin/env bash
# Acquire / refresh an Azure AD access token for the GENI EntityService.
#
# Implements the OAuth2 Authorization Code + PKCE flow for a public client
# (same parameters as get-token.ps1). Uses python3 for the localhost callback
# listener — python3 is part of the base install on every supported Linux
# distro and macOS.
#
# Cache file:
#   ${XDG_DATA_HOME:-$HOME/.local/share}/Geni_EntityService/.token_cache_<env>.json
#
# On success the access token is printed to stdout as a single line.
# All diagnostics go to stderr so stdout is safe to capture.
#
# Flags:
#   -e ENV | --env ENV   Target GENI environment: prod (default), dev, or test
#   --force-refresh      ignore cached access token; use refresh_token
#   --force-interactive  ignore cache entirely; start fresh browser login

set -euo pipefail

ENVIRONMENT='prod'
ENV_EXPLICIT=0
FORCE_REFRESH=0
FORCE_INTERACTIVE=0
args=("$@")
i=0
while [[ $i -lt ${#args[@]} ]]; do
    arg="${args[$i]}"
    case "$arg" in
        -e|--env)
            i=$((i+1)); ENVIRONMENT="${args[$i]:-}"; ENV_EXPLICIT=1 ;;
        --env=*)         ENVIRONMENT="${arg#--env=}"; ENV_EXPLICIT=1 ;;
        --force-refresh) FORCE_REFRESH=1 ;;
        --force-interactive) FORCE_INTERACTIVE=1 ;;
        -h|--help)
            sed -n '2,19p' "$0" >&2
            exit 0
            ;;
        *) echo "[get-token] Unknown argument: $arg" >&2; exit 2 ;;
    esac
    i=$((i+1))
done

# Auto-detect environment from nearest .mcp.json if --env wasn't supplied.
# If detection fails for ANY reason, we always fall back to 'prod' (the default).
if [[ "$ENV_EXPLICIT" -eq 0 ]]; then
    _SD="$(cd "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
    _DETECTED=""
    if [[ -x "$_SD/detect-env.sh" || -f "$_SD/detect-env.sh" ]]; then
        _DETECTED="$(bash "$_SD/detect-env.sh" 2>/dev/null || true)"
    fi
    case "$_DETECTED" in
        prod|dev|test)
            echo "[get-token] Auto-detected environment '$_DETECTED' from .mcp.json (override with --env)." >&2
            ENVIRONMENT="$_DETECTED"
            ;;
        *)
            echo "[get-token] Could not auto-detect environment; falling back to default '$ENVIRONMENT' (prod)." >&2
            ;;
    esac
fi

case "$ENVIRONMENT" in
    prod|dev|test) ;;
    *) echo "[get-token] ERROR: -e/--env must be prod, dev, or test (got: $ENVIRONMENT)" >&2; exit 2 ;;
esac
echo "[get-token] Using environment '$ENVIRONMENT'." >&2

# Load shared per-environment config (sibling environments.json) via python3
SCRIPT_DIR="$(cd "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
ENV_FILE="${SCRIPT_DIR}/environments.json"
if [[ ! -f "$ENV_FILE" ]]; then
    echo "[get-token] ERROR: environments.json not found at: $ENV_FILE" >&2; exit 1
fi

read_env_field() {
    # $1 = JSON path (e.g. 'tenant' or 'environments.prod.clientId')
    ENV_FILE="$ENV_FILE" FIELD="$1" python3 - <<'PY'
import json, os, sys
data = json.load(open(os.environ["ENV_FILE"]))
for part in os.environ["FIELD"].split("."):
    data = data[part]
print(data)
PY
}

TENANT_ID="$(read_env_field tenant)"
CLIENT_ID="$(read_env_field "environments.${ENVIRONMENT}.clientId")"
CALLBACK_PORT="$(read_env_field callbackPort)"
CALLBACK_ROUTE="$(read_env_field callbackRoute)"

SCOPE_STR="$(ENV_FILE="$ENV_FILE" CLIENT_ID="$CLIENT_ID" python3 - <<'PY'
import json, os
scopes = json.load(open(os.environ["ENV_FILE"]))["scopes"]
print(" ".join(s.replace("{clientId}", os.environ["CLIENT_ID"]) for s in scopes))
PY
)"
REDIRECT_URI="http://localhost:${CALLBACK_PORT}/${CALLBACK_ROUTE}"
AUTHORITY="https://login.microsoftonline.com/${TENANT_ID}"
AUTH_ENDPOINT="${AUTHORITY}/oauth2/v2.0/authorize"
TOKEN_ENDPOINT="${AUTHORITY}/oauth2/v2.0/token"

CACHE_DIR="${XDG_DATA_HOME:-$HOME/.local/share}/Geni_EntityService"
CACHE_FILE="${CACHE_DIR}/.token_cache_${ENVIRONMENT}.json"
mkdir -p "$CACHE_DIR"

log() { echo "[get-token][$ENVIRONMENT] $*" >&2; }

require() {
    command -v "$1" >/dev/null 2>&1 || {
        echo "[get-token] ERROR: required command not found: $1" >&2
        exit 1
    }
}
require curl
require python3

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
b64url() { # base64url-encode stdin, no padding
    base64 | tr '+/' '-_' | tr -d '=\n'
}

new_verifier() {
    # 64 random bytes -> base64url => ~86-char verifier (RFC 7636 allows 43..128)
    head -c 64 /dev/urandom | b64url
}

to_challenge() {
    # SHA-256(verifier) -> base64url
    printf '%s' "$1" | openssl dgst -sha256 -binary | b64url
}

urlencode() {
    python3 -c 'import sys,urllib.parse;print(urllib.parse.quote(sys.argv[1], safe=""))' "$1"
}

open_browser() {
    local url="$1"
    if command -v xdg-open >/dev/null 2>&1; then xdg-open "$url" >/dev/null 2>&1 &
    elif command -v open    >/dev/null 2>&1; then open    "$url" >/dev/null 2>&1 &
    else log "Open this URL in your browser manually:"; log "$url"; fi
}

# Read a JSON string field from $CACHE_FILE; prints empty string if missing.
cache_get() {
    [[ -f "$CACHE_FILE" ]] || { echo ""; return; }
    python3 -c "
import json,sys
try:
    with open('$CACHE_FILE','r') as f: d=json.load(f)
    v=d.get('$1','')
    if v is None: v=''
    print(v)
except Exception:
    print('')
"
}

save_cache() {
    # $1 = token endpoint response JSON
    python3 - "$CACHE_FILE" <<'PY'
import json, sys, time
cache_file = sys.argv[1]
payload = json.load(sys.stdin)
out = {
    "access_token":  payload.get("access_token"),
    "refresh_token": payload.get("refresh_token"),
    "expires_at":    int(time.time()) + int(payload.get("expires_in", 0)),
    "scope":         payload.get("scope"),
    "token_type":    payload.get("token_type"),
}
with open(cache_file, "w") as f:
    json.dump(out, f, indent=2)
PY
}

# ---------------------------------------------------------------------------
# Callback listener (python3, single request, with timeout)
# ---------------------------------------------------------------------------
interactive_login() {
    local verifier challenge state auth_uri callback_json code returned_state err err_desc
    verifier="$(new_verifier)"
    challenge="$(to_challenge "$verifier")"
    state="$(head -c 16 /dev/urandom | b64url)"

    auth_uri="${AUTH_ENDPOINT}?client_id=${CLIENT_ID}"
    auth_uri+="&response_type=code"
    auth_uri+="&redirect_uri=$(urlencode "$REDIRECT_URI")"
    auth_uri+="&response_mode=query"
    auth_uri+="&scope=$(urlencode "$SCOPE_STR")"
    auth_uri+="&state=$(urlencode "$state")"
    auth_uri+="&code_challenge=${challenge}"
    auth_uri+="&code_challenge_method=S256"
    auth_uri+="&prompt=select_account"

    log "Starting interactive browser login..."
    log "Opening browser..."
    open_browser "$auth_uri"

    # Run a one-shot HTTP listener on localhost:$CALLBACK_PORT, /$CALLBACK_ROUTE.
    # Prints a single JSON line {"code":"...","state":"...","error":"...","error_description":"..."}
    callback_json="$(
        CALLBACK_PORT="$CALLBACK_PORT" CALLBACK_ROUTE="$CALLBACK_ROUTE" \
        python3 - <<'PY'
import json, os, sys
from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import urlparse, parse_qs

PORT  = int(os.environ["CALLBACK_PORT"])
ROUTE = "/" + os.environ["CALLBACK_ROUTE"]
RESULT = {}

class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        parsed = urlparse(self.path)
        if parsed.path == ROUTE:
            q = {k: v[0] for k, v in parse_qs(parsed.query).items()}
            RESULT.update(q)
            body = (b"<h3>Login failed: " + q.get("error","").encode() + b"</h3>"
                    if q.get("error")
                    else b"<h3>Login successful. You can close this tab.</h3>")
            self.send_response(200)
            self.send_header("Content-Type", "text/html")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
        else:
            self.send_response(404); self.end_headers()
    def log_message(self, *a, **k): pass

srv = HTTPServer(("localhost", PORT), Handler)
srv.timeout = 180  # seconds
srv.handle_request()
print(json.dumps(RESULT))
PY
    )"

    if [[ -z "$callback_json" || "$callback_json" == "{}" ]]; then
        echo "[get-token] ERROR: timed out waiting for Azure AD callback after 180s." >&2
        exit 1
    fi

    code="$(          printf '%s' "$callback_json" | python3 -c 'import json,sys;print(json.load(sys.stdin).get("code",""))')"
    returned_state="$(printf '%s' "$callback_json" | python3 -c 'import json,sys;print(json.load(sys.stdin).get("state",""))')"
    err="$(           printf '%s' "$callback_json" | python3 -c 'import json,sys;print(json.load(sys.stdin).get("error",""))')"
    err_desc="$(      printf '%s' "$callback_json" | python3 -c 'import json,sys;print(json.load(sys.stdin).get("error_description",""))')"

    if [[ -n "$err"  ]]; then echo "[get-token] ERROR: $err - $err_desc" >&2; exit 1; fi
    if [[ -z "$code" ]]; then echo "[get-token] ERROR: callback missing 'code'." >&2; exit 1; fi
    if [[ "$returned_state" != "$state" ]]; then
        echo "[get-token] ERROR: state mismatch in callback (possible CSRF)." >&2; exit 1
    fi

    log "Exchanging auth code for tokens..."
    curl -sS -X POST "$TOKEN_ENDPOINT" \
        --data-urlencode "client_id=${CLIENT_ID}" \
        --data-urlencode "grant_type=authorization_code" \
        --data-urlencode "code=${code}" \
        --data-urlencode "redirect_uri=${REDIRECT_URI}" \
        --data-urlencode "code_verifier=${verifier}" \
        --data-urlencode "scope=${SCOPE_STR}"
}

refresh_login() {
    local refresh_token="$1"
    log "Refreshing access token using refresh_token..."
    curl -sS -X POST "$TOKEN_ENDPOINT" \
        --data-urlencode "client_id=${CLIENT_ID}" \
        --data-urlencode "grant_type=refresh_token" \
        --data-urlencode "refresh_token=${refresh_token}" \
        --data-urlencode "scope=${SCOPE_STR}"
}

# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------
now=$(date +%s)
skew=600  # refresh if <10 min remaining (large uploads may take a while)

cached_access=""
cached_refresh=""
cached_expires=0
if [[ $FORCE_INTERACTIVE -eq 0 && -f "$CACHE_FILE" ]]; then
    cached_access="$( cache_get access_token )"
    cached_refresh="$(cache_get refresh_token)"
    exp_raw="$(cache_get expires_at)"
    [[ -n "$exp_raw" ]] && cached_expires="$exp_raw"
fi

token=""
if [[ $FORCE_REFRESH -eq 0 && $FORCE_INTERACTIVE -eq 0 \
      && -n "$cached_access" && $((cached_expires - now)) -gt $skew ]]; then
    log "Reusing cached access token (expires in $((cached_expires - now))s)."
    token="$cached_access"
elif [[ $FORCE_INTERACTIVE -eq 0 && -n "$cached_refresh" ]]; then
    if response="$(refresh_login "$cached_refresh")" \
       && new_token="$(printf '%s' "$response" | python3 -c 'import json,sys;d=json.load(sys.stdin);print(d.get("access_token","") or "")')" \
       && [[ -n "$new_token" ]]; then
        printf '%s' "$response" | save_cache
        token="$new_token"
    else
        log "Refresh failed; falling back to interactive login."
        response="$(interactive_login)"
        printf '%s' "$response" | save_cache
        token="$(printf '%s' "$response" | python3 -c 'import json,sys;print(json.load(sys.stdin).get("access_token",""))')"
    fi
else
    response="$(interactive_login)"
    printf '%s' "$response" | save_cache
    token="$(printf '%s' "$response" | python3 -c 'import json,sys;print(json.load(sys.stdin).get("access_token",""))')"
fi

if [[ -z "$token" ]]; then
    echo "[get-token] ERROR: failed to acquire access token." >&2
    exit 1
fi

printf '%s\n' "$token"
