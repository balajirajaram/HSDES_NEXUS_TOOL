<#
.SYNOPSIS
    Upload one or more local files directly to the GENI EntityService
    /api/UploadFile/uploadFileToWorkspace endpoint.

.DESCRIPTION
    Builds a multipart/form-data POST containing the file bytes plus a
    JSON "fileMetadata" part (one entry per file). If no -Token is supplied,
    the script invokes get-token.ps1 (sibling file) to acquire one.

    Supported file types (server-enforced):
        pdf, txt, docx, html, csv, xlsx, pptx, md, png, jpg, jpeg,
        webm, webp, json, xml

.PARAMETER WorkspaceId
    Target workspace numeric id.

.PARAMETER Files
    One or more local file paths.

.PARAMETER Descriptions
    Optional. Same length as Files; description for each file. Use $null/'' for none.

.PARAMETER SkipIndex
    Optional. If set, all files are uploaded with skipIndex=true.

.PARAMETER Token
    Optional. Bearer access token. If omitted, get-token.ps1 (sibling) is used.

.PARAMETER Environment
    Optional. Target GENI environment: prod (default), dev, or test.
    Determines both the EntityService base URL and the Azure AD client used
    by get-token.ps1. Ignored when -BaseUrl is supplied (but still passed to
    get-token.ps1 for cache selection).

.PARAMETER BaseUrl
    Optional. EntityService base URL. Overrides the URL derived from -Environment.

.EXAMPLE
    .\upload-files.ps1 -WorkspaceId 1234 -Files 'C:\a.pdf','C:\b.docx'
    # Uploads to PRODUCTION (default).

.EXAMPLE
    .\upload-files.ps1 -Environment dev -WorkspaceId 1234 -Files 'C:\a.pdf'
    # Explicitly upload to the dev environment.
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)] [int]      $WorkspaceId,
    [Parameter(Mandatory=$true)] [string[]] $Files,
    [string[]] $Descriptions,
    [switch]   $SkipIndex,
    [string]   $Token,
    [ValidateSet('prod','dev','test')]
    [string]   $Environment = 'prod',
    [string]   $BaseUrl
)

$ErrorActionPreference = 'Stop'

# Auto-detect environment from nearest .mcp.json if -Environment wasn't supplied.
# If detection fails for ANY reason, we always fall back to 'prod' (the default).
if (-not $PSBoundParameters.ContainsKey('Environment')) {
    $detectScript = Join-Path $PSScriptRoot 'detect-env.ps1'
    $detected = $null
    if (Test-Path -LiteralPath $detectScript) {
        try { $detected = & $detectScript } catch { [Console]::Error.WriteLine("[upload-files] env auto-detect failed: $_") }
    }
    if ($detected -and @('prod','dev','test') -contains $detected) {
        [Console]::Error.WriteLine("[upload-files] Auto-detected environment '$detected' from .mcp.json (override with -Environment).")
        $Environment = $detected
    } else {
        [Console]::Error.WriteLine("[upload-files] Could not auto-detect environment; falling back to default '$Environment' (prod).")
    }
}
[Console]::Error.WriteLine("[upload-files] Using environment '$Environment'.")

# Load per-environment base URL from the shared environments.json
if (-not $BaseUrl) {
    $envFile = Join-Path $PSScriptRoot 'environments.json'
    if (-not (Test-Path -LiteralPath $envFile)) {
        throw "environments.json not found at: $envFile"
    }
    $envData = Get-Content -Raw -LiteralPath $envFile | ConvertFrom-Json
    if (-not $envData.environments.$Environment) {
        throw "Unknown environment '$Environment' (not present in environments.json)."
    }
    $BaseUrl = $envData.environments.$Environment.baseUrl
}

function Write-Info { param([string]$Message) [Console]::Error.WriteLine("[upload-files][$Environment] $Message") }

# Resolve & validate files
$resolved = @()
foreach ($f in $Files) {
    if (-not (Test-Path -LiteralPath $f -PathType Leaf)) { throw "File not found: $f" }
    $resolved += (Resolve-Path -LiteralPath $f).Path
}

if ($Descriptions -and $Descriptions.Count -ne $resolved.Count) {
    throw "Descriptions count ($($Descriptions.Count)) must match Files count ($($resolved.Count))."
}

# Acquire token if not supplied
if (-not $Token) {
    $tokenScript = Join-Path $PSScriptRoot 'get-token.ps1'
    if (-not (Test-Path -LiteralPath $tokenScript)) {
        throw "Token not provided and helper not found at: $tokenScript"
    }
    Write-Info "No token supplied; invoking get-token.ps1 -Environment $Environment..."
    $Token = & $tokenScript -Environment $Environment
    if (-not $Token) { throw "get-token.ps1 returned no token." }
}

# Build multipart body manually (PowerShell 5.1 compatible)
Add-Type -AssemblyName System.Net.Http

$client = New-Object System.Net.Http.HttpClient
$client.Timeout = [TimeSpan]::FromMinutes(30)
$content = New-Object System.Net.Http.MultipartFormDataContent

try {
    $fileStreams = @()
    for ($i = 0; $i -lt $resolved.Count; $i++) {
        $path = $resolved[$i]
        $name = [System.IO.Path]::GetFileName($path)
        $stream = [System.IO.File]::OpenRead($path)
        $fileStreams += $stream
        $fileContent = New-Object System.Net.Http.StreamContent($stream)
        $fileContent.Headers.ContentType = [System.Net.Http.Headers.MediaTypeHeaderValue]::Parse('application/octet-stream')
        $content.Add($fileContent, 'files', $name)
    }

    # Each FileMetadataDto must be a separate "fileMetadata" form field encoded as JSON
    for ($i = 0; $i -lt $resolved.Count; $i++) {
        $name = [System.IO.Path]::GetFileName($resolved[$i])
        $desc = if ($Descriptions) { $Descriptions[$i] } else { $null }
        $meta = [ordered]@{
            name        = $name
            description = $desc
            skipIndex   = [bool]$SkipIndex
        }
        $json = $meta | ConvertTo-Json -Compress
        $metaContent = New-Object System.Net.Http.StringContent($json, [System.Text.Encoding]::UTF8, 'application/json')
        $content.Add($metaContent, 'fileMetadata')
    }

    $uri = "$BaseUrl/api/UploadFile/uploadFileToWorkspace?workspaceId=$WorkspaceId"
    $request = New-Object System.Net.Http.HttpRequestMessage([System.Net.Http.HttpMethod]::Post, $uri)
    $request.Headers.Authorization = New-Object System.Net.Http.Headers.AuthenticationHeaderValue('Bearer', $Token)
    $request.Headers.Accept.Add([System.Net.Http.Headers.MediaTypeWithQualityHeaderValue]::Parse('application/json'))
    $request.Content = $content

    Write-Info "POST $uri  ($($resolved.Count) file(s))"
    $response = $client.SendAsync($request).GetAwaiter().GetResult()
    $body = $response.Content.ReadAsStringAsync().GetAwaiter().GetResult()

    if (-not $response.IsSuccessStatusCode) {
        Write-Info "HTTP $([int]$response.StatusCode) $($response.ReasonPhrase)"
        Write-Output $body
        exit 1
    }

    Write-Info "Upload succeeded (HTTP $([int]$response.StatusCode))."
    Write-Output $body
}
finally {
    foreach ($s in $fileStreams) { try { $s.Dispose() } catch {} }
    try { $content.Dispose() } catch {}
    try { $client.Dispose() } catch {}
}
