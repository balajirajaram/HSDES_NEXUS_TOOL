#!/usr/bin/env bash
# Upload local file(s) to GENI EntityService /api/UploadFile/uploadFileToWorkspace.
#
# Authentication: if no token is supplied (via -t/--token or GENI_TOKEN env var)
# the script invokes the sibling get-token.sh to acquire one (OAuth2 auth-code
# + PKCE flow, browser-based, with cached refresh).
#
# Usage:
#   upload-files.sh -w WORKSPACE_ID [-e ENV] [-t BEARER_TOKEN] [-s] [-d "desc1|desc2|..."] file1 [file2 ...]
#
# Options:
#   -w  Workspace id (required)
#   -e  Environment: prod (default), dev, or test
#   -t  Bearer token (else GENI_TOKEN env, else get-token.sh)
#   -s  skipIndex=true for all files (default false)
#   -d  Pipe-separated descriptions, one per file (optional)
#   -u  Base URL (overrides the URL derived from -e)

set -euo pipefail

ENVIRONMENT='prod'
ENV_EXPLICIT=0
BASE_URL=''
WORKSPACE_ID=""
TOKEN="${GENI_TOKEN:-}"
SKIP_INDEX="false"
DESCS=""

while getopts ":w:e:t:su:d:" opt; do
    case "$opt" in
        w) WORKSPACE_ID="$OPTARG" ;;
        e) ENVIRONMENT="$OPTARG"; ENV_EXPLICIT=1 ;;
        t) TOKEN="$OPTARG" ;;
        s) SKIP_INDEX="true" ;;
        u) BASE_URL="$OPTARG" ;;
        d) DESCS="$OPTARG" ;;
        \?) echo "Unknown option: -$OPTARG" >&2; exit 2 ;;
        :)  echo "Option -$OPTARG requires an argument" >&2; exit 2 ;;
    esac
done
shift $((OPTIND - 1))

# Auto-detect environment from nearest .mcp.json if -e wasn't supplied.
# If detection fails for ANY reason, we always fall back to 'prod' (the default).
if [[ "$ENV_EXPLICIT" -eq 0 ]]; then
    _SD="$(cd "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
    _DETECTED=""
    if [[ -f "$_SD/detect-env.sh" ]]; then
        _DETECTED="$(bash "$_SD/detect-env.sh" 2>/dev/null || true)"
    fi
    case "$_DETECTED" in
        prod|dev|test)
            echo "[upload-files] Auto-detected environment '$_DETECTED' from .mcp.json (override with -e)." >&2
            ENVIRONMENT="$_DETECTED"
            ;;
        *)
            echo "[upload-files] Could not auto-detect environment; falling back to default '$ENVIRONMENT' (prod)." >&2
            ;;
    esac
fi
echo "[upload-files] Using environment '$ENVIRONMENT'." >&2

case "$ENVIRONMENT" in
    prod|dev|test) ;;
    *) echo "ERROR: -e must be prod, dev, or test (got: $ENVIRONMENT)" >&2; exit 2 ;;
esac

if [[ -z "$BASE_URL" ]]; then
    SCRIPT_DIR="$(cd "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
    ENV_FILE="${SCRIPT_DIR}/environments.json"
    if [[ ! -f "$ENV_FILE" ]]; then
        echo "ERROR: environments.json not found at: $ENV_FILE" >&2; exit 1
    fi
    if ! command -v python3 >/dev/null 2>&1; then
        echo "ERROR: python3 required to read environments.json (or pass -u <baseUrl>)" >&2; exit 1
    fi
    BASE_URL="$(ENV_FILE="$ENV_FILE" ENV_NAME="$ENVIRONMENT" python3 -c '
import json, os
print(json.load(open(os.environ["ENV_FILE"]))["environments"][os.environ["ENV_NAME"]]["baseUrl"])
')"
fi

if [[ -z "$WORKSPACE_ID" ]]; then echo "ERROR: -w WORKSPACE_ID is required" >&2; exit 2; fi
if [[ $# -lt 1           ]]; then echo "ERROR: at least one file path is required" >&2; exit 2; fi

if [[ -z "$TOKEN" ]]; then
    SCRIPT_DIR="$(cd "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
    TOKEN_SCRIPT="$SCRIPT_DIR/get-token.sh"
    if [[ ! -x "$TOKEN_SCRIPT" && -f "$TOKEN_SCRIPT" ]]; then chmod +x "$TOKEN_SCRIPT" || true; fi
    if [[ ! -f "$TOKEN_SCRIPT" ]]; then
        echo "ERROR: no token provided and helper not found: $TOKEN_SCRIPT" >&2; exit 2
    fi
    echo "[upload-files][$ENVIRONMENT] No token supplied; invoking get-token.sh --env $ENVIRONMENT..." >&2
    TOKEN="$("$TOKEN_SCRIPT" --env "$ENVIRONMENT")"
    if [[ -z "$TOKEN" ]]; then echo "ERROR: get-token.sh returned no token" >&2; exit 1; fi
fi

# Parse pipe-separated descriptions into an array (no descriptions if -d not given)
IFS='|' read -r -a DESC_ARR <<< "$DESCS"
if [[ -n "$DESCS" && ${#DESC_ARR[@]} -ne $# ]]; then
    echo "ERROR: -d must have the same number of entries as files (got ${#DESC_ARR[@]}, need $#)" >&2
    exit 2
fi

# JSON-escape a string for embedding in JSON
json_escape() {
    local s="$1"
    s="${s//\\/\\\\}"
    s="${s//\"/\\\"}"
    s="${s//$'\n'/\\n}"
    s="${s//$'\r'/\\r}"
    s="${s//$'\t'/\\t}"
    printf '%s' "$s"
}

CURL_ARGS=(
    -sS
    -X POST
    -H "Authorization: Bearer $TOKEN"
    -H "Accept: application/json"
    -w "\n__HTTP_STATUS__:%{http_code}"
)

i=0
for f in "$@"; do
    if [[ ! -f "$f" ]]; then echo "ERROR: file not found: $f" >&2; exit 1; fi
    CURL_ARGS+=(-F "files=@${f}")

    name="$(basename -- "$f")"
    desc=""
    if [[ -n "$DESCS" ]]; then desc="${DESC_ARR[$i]}"; fi

    if [[ -n "$desc" ]]; then
        meta="{\"name\":\"$(json_escape "$name")\",\"description\":\"$(json_escape "$desc")\",\"skipIndex\":${SKIP_INDEX}}"
    else
        meta="{\"name\":\"$(json_escape "$name")\",\"description\":null,\"skipIndex\":${SKIP_INDEX}}"
    fi
    CURL_ARGS+=(-F "fileMetadata=${meta};type=application/json")
    i=$((i + 1))
done

URL="${BASE_URL%/}/api/UploadFile/uploadFileToWorkspace?workspaceId=${WORKSPACE_ID}"
echo "[upload-files][$ENVIRONMENT] POST $URL ($# file(s))" >&2

RESPONSE="$(curl "${CURL_ARGS[@]}" "$URL")"
STATUS="${RESPONSE##*__HTTP_STATUS__:}"
BODY="${RESPONSE%$'\n'__HTTP_STATUS__:*}"

echo "$BODY"

if [[ "$STATUS" -lt 200 || "$STATUS" -ge 300 ]]; then
    echo "[upload-files][$ENVIRONMENT] HTTP $STATUS" >&2
    exit 1
fi

echo "[upload-files][$ENVIRONMENT] Upload succeeded (HTTP $STATUS)." >&2
