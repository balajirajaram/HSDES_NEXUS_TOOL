# gh-actions-logs

A **VS Code Copilot Chat skill** that teaches the assistant how to fetch GitHub Actions workflow logs surgically — pulling only the failing slice instead of the entire multi-megabyte archive.

The skill itself lives in [`gh-actions-logs/SKILL.md`](./gh-actions-logs/SKILL.md). Once installed, Copilot loads it automatically whenever you ask about a failed/stuck workflow run.

---

## Why this exists

A raw `gh run view <id> --log` on a non-trivial CI workflow can return multi-megabyte text — enough to overflow the 200k-token context window outright on the worst cases we measured. This skill teaches Copilot to pull JSON metadata first, then extract only the failing slice. See [Measured savings](#measured-savings) for the distribution.

### Measured savings

Three example builds from our 45-run sample, showing what one diagnosis costs at GitHub Copilot's Claude Opus 4.7 rate ($5.00 / 1M input tokens, [source](https://docs.github.com/en/copilot/reference/copilot-billing/models-and-pricing)):

| Build size | Raw log | Without skill | With skill |
|---|---:|---:|---:|
| **Small** (lint check, single error) | ~200 KB | ~50k tokens → **$0.25** | ~5k tokens → **$0.03** |
| **Medium** (typical firmware build) | ~1 MB | ~260k tokens → **$1.30** | ~10k tokens → **$0.05** |
| **Large** (release build, matrix) | ~2.7 MB | ~700k tokens → **$3.50** | ~12k tokens → **$0.06** |
| **Extra-large** (long matrix / verbose build) | ~10 MB | ~2.6M tokens → **$13.10** | ~20k tokens → **$0.10** |

What actually happens without the skill on the large end isn't "the request fails" — Copilot's terminal tool auto-truncates output around ~60 KB, or reads big files in chunks. So you usually *get an answer*, but:

- the truncation may **silently cut off the actual error** (especially in matrix builds where the failing leg is at the bottom)
- Copilot burns extra tokens re-reading file ranges to find what got cut
- the model wastes turns reasoning over Docker pulls and timestamps before reaching the relevant lines

With the skill, the model sees ~5–15 KB of pre-filtered failure context regardless of whether the underlying log is 50 KB or 6 MB.



## How it works

```mermaid
flowchart TD
    A[User: 'why did workflow X fail?'] --> B{Copilot loads SKILL.md<br/>via matching trigger phrase}
    B --> C[Step 1: gh run list --json<br/>~0.5 KB]
    C --> D[Step 2: gh run view --json jobs --jq<br/>filter to failed jobs/steps only<br/>~1-3 KB]
    D --> E{Escalation: how big / how targeted?}
    E -->|default| F1[Step 3a: gh run view --log-failed<br/>+ grep/Select-String -First 8]
    E -->|matrix leg or one specific job| F2[Step 3b: gh run view --job ID --log-failed<br/>+ filter]
    E -->|will need many slices| F3[Step 4: save once to TEMP<br/>then Select-String -Pattern -Context N,M -First K]
    E -->|truly surgical, skip zip| F4[Step 3c: gh api repos/.../jobs/ID/logs<br/>stream plain text]
    F1 --> G{Slice empty or too noisy?}
    F2 --> G
    F3 --> G
    F4 --> G
    G -->|good| H[Model receives ~2-50 KB<br/>of relevant lines only]
    G -->|miss| E
    H --> I[Diagnosis + recommended fix]
    I --> J[Step 5: cleanup temp files]
```

The escalation ladder — `--log-failed` → `--job ... --log-failed` → temp-file slicing → raw REST `/logs` — is the heart of the skill. Each rung pre-filters bytes **before** they reach the model. The assistant only ingests the raw multi-MB log if it has no other option, and even then never the whole thing.

---

## Installation

The skill lives in your **personal Copilot skills folder**, so it auto-loads in every VS Code workspace.

### Windows

Copy:

```powershell
$src = "C:\path\to\gh-actions-logs\gh-actions-logs"
$dst = "$env:USERPROFILE\.agents\skills\gh-actions-logs"
New-Item -ItemType Directory -Force -Path $dst | Out-Null
Copy-Item "$src\SKILL.md" $dst -Force
```

Or symlink (so future edits to the repo propagate):

```powershell
New-Item -ItemType SymbolicLink `
    -Path "$env:USERPROFILE\.agents\skills\gh-actions-logs" `
    -Target "C:\path\to\gh-actions-logs\gh-actions-logs"
```
(symlink creation may require an elevated PowerShell or Developer Mode enabled)

### macOS / Linux

```bash
mkdir -p ~/.agents/skills
ln -s /path/to/gh-actions-logs/gh-actions-logs ~/.agents/skills/gh-actions-logs
# or copy:
cp -r /path/to/gh-actions-logs/gh-actions-logs ~/.agents/skills/
```

### Verify

1. Restart VS Code (or reload the Copilot Chat panel).
2. In a new chat, the skill should appear in the assistant's available skill list — its `description` field is what Copilot uses to decide when to auto-invoke it.
3. Trigger it with any of the phrases below.

---

## Usage

The skill loads automatically when the assistant detects you're asking about GitHub Actions logs. **You don't invoke it manually** — you just speak naturally and Copilot picks it up.

### Trigger phrases

Any of these (and similar variations) will cause Copilot to read and apply the skill:

- *"why did the workflow fail?"*
- *"get the logs from this run: <URL>"*
- *"what failed in this build?"*
- *"show me the error from action X"*
- *"fetch failed step output"*
- *"gh run logs"*
- *"github actions logs"*

### Example interaction

> **You:** analyze this build https://github.com/myorg/myrepo/actions/runs/12345678

> **Copilot:** *(loads `SKILL.md`, then:)*
> 1. Calls `gh run view 12345678 --json databaseId,status,conclusion,name,displayTitle,event,headBranch,createdAt`
> 2. Calls `gh run view 12345678 --json jobs --jq '.jobs[] | select(.conclusion=="failure") | …'`
> 3. Saves `--log-failed` to `$env:TEMP\gh-run-12345678.log` (large)
> 4. Runs `Select-String -Pattern 'error|fail|exit code' -Context 2,5 -First 8` to extract real failure
> 5. Returns a diagnosis with a recommended fix
> 6. Cleans up the temp file

You see only the final answer. The skill enforces the discipline.

---

## Prerequisites

These must be satisfied on the machine running VS Code (the skill's commands run in your local terminal via Copilot):

- **`gh` CLI** installed and on `PATH` — verify with `gh --version`. Install: <https://cli.github.com/>.
- **Authenticated session** with `repo` + `workflow` scopes:
  ```bash
  gh auth status
  # if missing scopes:
  gh auth login -s repo,workflow
  ```
- **Run context:** either invoke from within the target repo's working tree, or include `-R <owner>/<repo>` on every `gh run …` call. The skill examples show both forms.
- **Shell:** PowerShell 5.1+ on Windows, or any POSIX shell (bash/zsh) with `grep`, `head`, `tail`, `mktemp`. Both variants are documented in the skill.
- **`jq` is NOT required.** All examples use `gh`'s built-in `--jq` flag, which has an embedded jq engine.

