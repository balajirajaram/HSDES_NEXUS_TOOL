---
name: gh-actions-logs
description: 'Fetch GitHub Actions workflow run logs via the gh CLI in a token-efficient way. Use when investigating a failed or stuck workflow run, debugging a specific job/step, comparing failing vs passing builds, or extracting error messages from cron/scheduled workflow runs. Triggers: "why did the workflow fail", "get the logs from this run", "what failed in this build", "show me the error from action X", "fetch failed step output", "gh run logs", "github actions logs".'
---

# GitHub Actions Logs (gh CLI) — Token-Efficient Fetching

## Prerequisites

Before running any command in this skill:

- **`gh` CLI** installed and on `PATH` (`gh --version`). The `--jq` flag uses an embedded jq engine — a standalone `jq` binary is **not** required for any example here.
- **Authenticated session** with at least `repo` and `workflow` scopes — verify with `gh auth status`. Re-auth with `gh auth login -s repo,workflow` if missing.
- **Run context**: execute inside the target repo's working tree, or pass `-R <owner>/<repo>` to every `gh run …` call.
- **Shell**: PowerShell 5.1+ on Windows (uses `Select-String`, `$env:TEMP`, backtick continuation) or any POSIX shell with `grep`, `head`, `tail`, `mktemp`.

## Goal

Get just enough of an Actions log into the model context to diagnose a problem — never the whole archive. Workflow logs routinely exceed 100k tokens; reading them directly will blow the context budget and slow the turn.

## Core Principle

**Filter at the source, not in the model.** Always pipe through `--log-failed`, `--jq`, `grep`/`Select-String`, `head`/`Select-Object` *before* the bytes ever reach the assistant. When in doubt, save once to a temp file and slice multiple times — re-running `gh` for every grep wastes API quota and time.

## Decision Flow

| Situation | Use |
|-----------|-----|
| Don't know which run failed | `gh run list --json …` (step 1) |
| Run failed, want only failure context | `gh run view <id> --log-failed` (step 3a) |
| Need a specific job (e.g. matrix leg) | `gh run view --job <job-id> --log` (step 3b) |
| Need full log for repeated slicing | Save to temp file, then grep/`Select-String` (step 4) |
| Single targeted lookup | Pipe directly, no temp file (step 3a/b) |

## Procedure

### 1. Identify the run (cheap, ~200 tokens)

Pull only the columns you need as JSON.

**PowerShell**
```powershell
gh run list `
  --workflow <workflow-file>.yml `
  --limit 5 `
  --json databaseId,status,conclusion,name,createdAt,headBranch
```

**Bash**
```bash
gh run list \
  --workflow <workflow-file>.yml \
  --limit 5 \
  --json databaseId,status,conclusion,name,createdAt,headBranch
```

For a single recent failure:

**PowerShell**
```powershell
gh run list --status failure --limit 1 --json databaseId,name,conclusion --jq '.[0]'
```

**Bash**
```bash
gh run list --status failure --limit 1 --json databaseId,name,conclusion --jq '.[0]'
```

### 2. Locate the failing jobs/steps (cheap, ~300 tokens)

Never call `--log` blind. First ask which jobs/steps failed:

**PowerShell**
```powershell
gh run view <run-id> --json jobs `
  --jq '.jobs[] | select(.conclusion=="failure") | {id: .databaseId, name, steps: [.steps[] | select(.conclusion=="failure") | .name]}'
```

**Bash**
```bash
gh run view <run-id> --json jobs \
  --jq '.jobs[] | select(.conclusion=="failure") | {id: .databaseId, name, steps: [.steps[] | select(.conclusion=="failure") | .name]}'
```

This returns a tiny structured summary you can act on.

### 3. Fetch only the failing slice

**3a. Failed-steps-only across the whole run** — usually the right default:

```powershell
gh run view <run-id> --log-failed
```
```bash
gh run view <run-id> --log-failed
```

**3b. One specific job** (matrix builds, or when `--log-failed` is still too large):

```powershell
gh run view --job <job-id> --log
# or
gh run view --job <job-id> --log-failed
```
```bash
gh run view --job <job-id> --log
# or
gh run view --job <job-id> --log-failed
```

For *truly* surgical extraction, hit the REST API — it skips the zip step and streams plain text:

```powershell
gh api repos/:owner/:repo/actions/jobs/<job-id>/logs
```
```bash
gh api repos/:owner/:repo/actions/jobs/<job-id>/logs
```

### 4. Save once, slice many (when you need >1 lookup)

If you expect to grep the same log multiple times, write it to a temp file first. This is strictly cheaper than re-running `gh` and far cheaper than loading the whole text into the model.

**PowerShell**
```powershell
$log = Join-Path $env:TEMP "gh-run-<run-id>.log"
gh run view <run-id> --log-failed > $log

# Extract just what you need into context:
Select-String -Path $log -Pattern 'error|fail|exception|traceback' -Context 2,5 |
    Select-Object -First 40
```

**Bash**
```bash
log=$(mktemp -t gh-run-XXXXXX.log)
gh run view <run-id> --log-failed > "$log"

# Extract just what you need into context:
grep -nEi -A 5 -B 2 'error|fail|exception|traceback' "$log" | head -n 200
```

Useful slicing patterns (each returns ~tens of lines, not thousands):

**PowerShell**
```powershell
# Tail of the log (last failing step's death rattle)
Get-Content $log -Tail 80

# A specific step's section (gh prefixes each line with "JobName\tStepName\tTimestamp\t…")
Select-String -Path $log -Pattern '^(?<j>[^\t]+)\t(?<s>Run pytest)\t' | Select-Object -First 200

# Lines around a known marker
Select-String -Path $log -Pattern 'Process completed with exit code' -Context 20,2
```

**Bash**
```bash
# Tail of the log (last failing step's death rattle)
tail -n 80 "$log"

# A specific step's section (gh prefixes lines with "JobName<TAB>StepName<TAB>Timestamp<TAB>…")
grep -nP '^[^\t]+\tRun pytest\t' "$log" | head -n 200

# Lines around a known marker
grep -n -B 20 -A 2 'Process completed with exit code' "$log"
```

### 5. Clean up

**PowerShell**
```powershell
Remove-Item $env:TEMP\gh-run-*.log -ErrorAction SilentlyContinue
```

**Bash**
```bash
rm -f /tmp/gh-run-*.log
```

## Anti-Patterns

- `gh run view <id> --log` piped *directly into the assistant* — dumps the whole archive (often >100k tokens).
- `gh run download` for log inspection — that command is for **artifacts**, not logs, and unpacks to disk.
- Re-running `gh run view --log` for each grep instead of saving once to a temp file.
- Asking for `--json jobs` without `--jq` — the raw JSON includes per-step metadata for every step and is needlessly large.
- Reading the temp file with `Get-Content $log` / `cat $log` (no filter) — defeats the entire point.

## Token Budget Cheat Sheet

| Command | Typical size |
|---------|--------------|
| `gh run list --json … --limit 5` | ~0.5 KB |
| `gh run view <id> --json jobs --jq …` (failed only) | ~1–3 KB |
| `gh run view <id> --log-failed` (small workflow) | ~5–50 KB |
| `gh run view <id> --log` (full) | **50 KB – several MB** — avoid loading directly |
| Filtered grep/`Select-String` slice (first 40 hits + context) | ~2–5 KB |

Aim to keep any single tool output the assistant ingests under ~10 KB.
