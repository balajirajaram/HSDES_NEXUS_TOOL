#!/usr/bin/env python3
"""
HSLE Run Analyzer - Single-pass unified log analysis.

Replaces separate milestone_extractor.py + reset_detector.py with ONE pass
through testbench.log that extracts everything simultaneously:
  - Stage 0-7 milestones (from flow.txt)
  - Reset triggers and type classification (from cold/warm/global_reset_flow.txt)
  - Reset stage markers (Stages 8-13)
  - Failure context (lines around the failure point)

Performance: ~30-60s for 1M-line log (single I/O pass, all regex compiled).
Token savings: Agent calls this script ONCE, reads JSON output, writes summary.
No manual grepping needed.

Usage:
    python3 hsle_analyzer.py <run_directory>
    python3 hsle_analyzer.py <run_directory> --json   # machine-readable
    python3 hsle_analyzer.py <run_directory> --summary # auto-generate summary file
"""

import re
import gzip
import os
import sys
import json
import time
from dataclasses import dataclass, field, asdict
from typing import List, Dict, Optional, Tuple
from datetime import datetime
from pathlib import Path

from output_paths import default_summary_output_path, ensure_parent_dir, extract_bios_id, extract_hsle_model, extract_os_image


# ===========================================================================
#  COMPILED PATTERN DEFINITIONS
#  Encodes knowledge from: flow.txt, bios_flow.txt, reset_phase_flow.txt,
#  cold_reset_flow.txt, warm_reset_flow.txt, global_reset_flow.txt
# ===========================================================================

# --- Stage 0-7: First boot milestones (from flow.txt) ---
STAGE_PATTERNS = {
    0: [
        ("spark_session", re.compile(r"spark_session\.log|SPARK.*[Ss]ession|SPARK Version:", re.I), True),
        ("zebu_config", re.compile(r"ZSE5_DMR_MCP|ZeBu.*[Cc]onfig|zRci.*init|designName", re.I), True),
    ],
    1: [
        ("emu_log_init", re.compile(r"\[emu\.devices[\ \]]|emu_log.*open|emulation.*init|determine_model\.py", re.I), True),
        ("zse5_device", re.compile(r"ZSE5.*device|zRci.*device|zRci_init|model_build_cfg|mcp_1s_ici", re.I), True),
    ],
    2: [
        ("model_init", re.compile(r"model.*loaded|IDI.*link|socket.*config|hsle.*model", re.I), True),
        ("idi_connect", re.compile(r"IDI.*connect|idi_mux|VP.*RTL", re.I), False),
    ],
    3: [
        ("zebu_compile", re.compile(r"Compilation.*complete|ZeBu.*compil|partition.*compil|ZSYN.*done|Hardware ready", re.I), True),
    ],
    4: [
        ("simics_run", re.compile(r"simics.*run|simulation.*start|Running.*sim|continue-alone", re.I), True),
        ("vp_create", re.compile(r"processor.*creat|VP.*creat|x86.*creat|cpu.*object", re.I), False),
    ],
    5: [
        ("reset_phase_1", re.compile(r"RESET_PHASE_1\b"), False),  # optional: absent in fmod runs
        ("reset_phase_3", re.compile(r"RESET_PHASE_3\b"), False),  # optional: absent in fmod runs
        ("reset_phase_6", re.compile(r"RESET_PHASE_6\b"), False),  # optional: absent in fmod runs
        ("idi_mux_enable", re.compile(r"IDI.*[Mm]ux.*enabl"), True),
    ],
    6: [
        ("bios_start", re.compile(r"BIOS.*[Ss]tart|SEC phase|debug_port.*0x000[1-9]"), False),
        ("early_pch_init", re.compile(r"EarlyPlatformPchInit"), False),
        ("start_mrc", re.compile(r"START_MRC_RUN"), False),
        ("pei_memory", re.compile(r"PeiInstallPeiMemory"), False),
        ("dxe_ipl", re.compile(r"DXE IPL Entry|Loading DXE CORE"), False),
        ("bds_boot", re.compile(r"\[Bds\]Boot"), False),
        ("exit_boot_svc", re.compile(r"ExitBootServices"), False),
        ("bios_aced", re.compile(r"BIOS_TAIL_ACED"), False),
    ],
    7: [
        ("os_kernel", re.compile(r"Linux version \d|SVOS.*[Bb]oot|CentOS|vmlinuz|Decompressing Linux"), False),
        ("ppr_test_done", re.compile(r"PPR_TEST_DONE"), True),
    ],
}

# --- Reset detection patterns (from cold/warm/global_reset_flow.txt) ---
RESET_PATTERNS = {
    # Stage 8: Trigger
    "ppr_test_done":      re.compile(r"PPR_TEST_DONE"),
    "ppr_got_cf9":        re.compile(r"PPR check: GOT RESET CF9\s+(\d+)"),
    "rst_tag_triggering": re.compile(r"RST_TAG:\s*triggering\s+(\S+)"),
    "cold_through":       re.compile(r"COLD_RESET\s+through\s+(.+?)(?:\s+triggered|$)"),
    "warm_through":       re.compile(r"WARM_RESET\s+through\s+(.+?)(?:\s+triggered|$)"),
    "global_through":     re.compile(r"GLOBAL_RESET\s+through\s+(.+?)(?:\s+triggered|$)"),
    "global_sequence":    re.compile(r"RST_TAG\s+Global\s+reset\s+sequence\s+will\s+be\s+called"),
    "agr_event":          re.compile(r"RST_TAG\s+AGR\s+event\s+triggered"),
    "awr_event":          re.compile(r"RST_TAG\s+AWR\s+event\s+triggered"),
    "swr_event":          re.compile(r"RST_TAG\s+Reset_BTN\s+event\s+triggered"),
    # Stage 9: Hardware entry
    "hsle_start_reset":   re.compile(r"RST_TAG\s+HSLE\s+starting\s+reset"),
    "cbb_event":          re.compile(r"RST_TAG\s+Creating\s+a\s+CBB\s+event\s+for\s+reset:\s*(\w+)"),
    "pltrst_sync":        re.compile(r"RST_TAG\s+waiting\s+for\s+PLTRST_SYNC"),
    "gbl_rst_warn":       re.compile(r"GBL_RST_WARN|RST_TAG.*[Gg]lobal.*[Rr]eset.*[Ww]arn"),
    "global_reset_n":     re.compile(r"GLOBAL_RESET_N.*(?:forced|assert)|RST_TAG.*GLOBAL_RESET_N"),
    "pwrgood_deassert":   re.compile(r"RST_TAG\s+Forced.*PWRGOOD.*to\s+0|PWRGOOD.*de-?assert"),
    "slp_assertion":      re.compile(r"SLP_S[345].*assert|RST_TAG.*SLP_S[345]"),
    "fuse_reload":        re.compile(r"fuse.*reload|FUSE.*RELOAD|reload_fuse"),
    "reset_n_assert":     re.compile(r"RST_TAG.*XX_RESET_N.*assert|RESET_N.*(?:forced|assert)"),
    "fake_go_rsp":        re.compile(r"Fake\s+GO\s+RSP|fake.*go.*rsp", re.I),
    "begin_reset_flow":   re.compile(r"BEGIN_RESET_FLOW"),
    "reset_triggered":    re.compile(r"RST_TAG\s+Reset\s+triggered"),
    # Stage 10: Second boot RTL
    "boot_fsm_start":     re.compile(r"BOOT_FSM(?:\s+state\s+0x0?1\b|_(?:SWITCH_RO_TO_XTAL|START_FUSE_SENSE|DFX_AGG_FUSE_PULL)\b)"),
    "boot_fsm_end":       re.compile(r"BOOT_FSM\s+state\s+0x(?:41|3c)\b"),
    "reset_phase_3_2nd":  re.compile(r"RESET_PHASE_3"),
    "reset_phase_6_2nd":  re.compile(r"RESET_PHASE_6"),
    "bios_first_fetch":   re.compile(r"RST_TAG\s+waiting\s+for\s+BIOS\s+first\s+fetch"),
    "icecode_reload":     re.compile(r"icecode_load|IceCode.*reload", re.I),
    "hwrs_complete":      re.compile(r"HWRS_RESET_COMPLETE|HWRS.*reset.*complete", re.I),
    # Stage 11: Second BIOS
    "idi_mux_2nd":        re.compile(r"IDI.*[Mm]ux.*enabl"),
    "bios_aced_2nd":      re.compile(r"BIOS_TAIL_ACED"),
    "reset_phase_7":      re.compile(r"RESET_PHASE_7"),
    # Stage 13: Termination
    "auto_exit":          re.compile(r"Auto exit triggered|RESET_TEST_COMPLETE"),
    "rca_check":          re.compile(r"rca_check_found:\s*(\d+)"),
    "primecode_state_die8": re.compile(r"imh primecode state (\S+) completed for socket \d+ die8"),
    "primecode_state_die9": re.compile(r"imh primecode state (\S+) completed for socket \d+ die9"),
}

# Lines to skip (noise from wait-for-log registrations, hap callbacks)
NOISE_RE = re.compile(r"wait-for-|Watching for|Expected.*pattern|hap_callback")

# FAST PRE-FILTER: Single regex of all critical keywords.
# Only lines matching this get expensive individual pattern checks.
# Skips ~95% of log lines, cutting runtime by 5-10x.
# FAST pre-filter: tuple of keywords for O(n) string 'in' check (10-50x faster than regex)
_PREFILTER_KEYWORDS = (
    'RST_TAG', 'PPR_TEST_DONE', 'RESET_PHASE', 'BOOT_FSM', 'BIOS_TAIL',
    'BEGIN_RESET', 'CF9', 'PWRGOOD', 'PWR_OK', 'SLP_S', 'PLTRST',
    'GBL_RST', 'GLOBAL_RESET_N', 'icecode', 'IceCode', 'fuse_reload',
    'FUSE_RELOAD', 'Fake GO', 'fake_go', 'rca_check', 'Auto exit',
    'RESET_TEST', 'PPR check', 'ExitBootServices', 'DXE IPL',
    'Loading DXE', 'PeiInstall', 'START_MRC', 'EarlyPlatformPch',
    'BIOS ID:', 'SVOS', 'CentOS', 'Linux version', 'Decompressing',
    'spark_session', 'SPARK', 'ZSE5_DMR', 'ZeBu', 'zRci',
    'emu.devices', 'emu_log', 'emulation', 'IDI', 'idi_mux',
    'Compilation', 'Hardware ready', 'ZSYN',
    'continue-alone', 'HWRS', 'primecode',
    'Reset_BTN', 'AGR event', 'AWR event', 'COLD_RESET',
    'WARM_RESET', 'GLOBAL_RESET', 'Bds', 'GRUB', 'ramdisk', 'vmlinuz',
    # MCA error indicators (Stage 6/7 hardware errors)
    'MCi_STATUS', 'MCA_STATUS', '[CpuRas]', 'IERR', 'MCERR',
    'emu_mca_mon', 'machine check', 'McBankErr', 'MSCOD', 'MCACOD',
    # IERR-specific: IMH force monitor result, RCA/CATERR signals
    'IERR Valid bit set', 'RCA fired', 'XX_CATERR_N', 'CATERR',
)



# ===========================================================================
#  DATA STRUCTURES
# ===========================================================================

@dataclass
class Milestone:
    stage: int
    substage: str
    line_number: int
    content: str

@dataclass
class StageResult:
    stage: int
    status: str  # PASS, PARTIAL, FAIL, NOT_REACHED
    milestones: List[Milestone] = field(default_factory=list)
    missing: List[str] = field(default_factory=list)

@dataclass
class ResetCycle:
    cycle_number: int
    reset_type: str = "UNKNOWN"
    trigger_source: str = "UNKNOWN"
    cf9_value: str = ""
    trigger_line: int = 0
    trigger_content: str = ""
    # Stage 9
    hsle_start_reset_line: int = 0
    cbb_event_line: int = 0
    cbb_event_type: str = ""
    pltrst_sync_line: int = 0
    gbl_rst_warn_line: int = 0
    global_reset_n_line: int = 0
    pwrgood_deassert_line: int = 0
    slp_assertion_line: int = 0
    fuse_reload_line: int = 0
    reset_n_assert_line: int = 0
    fake_go_rsp_line: int = 0
    begin_reset_flow_line: int = 0
    reset_triggered_line: int = 0
    # Stage 10
    primecode_start_line: int = 0
    primecode_end_line: int = 0
    reset_phase_3_line: int = 0
    reset_phase_6_line: int = 0
    bios_first_fetch_line: int = 0
    icecode_reload_line: int = 0
    hwrs_complete_line: int = 0
    # Stage 10 - primecode last-state tracking (die8=imh8, die9=imh9)
    last_primecode_imh8: str = ""
    last_primecode_imh8_line: int = 0
    last_primecode_imh9: str = ""
    last_primecode_imh9_line: int = 0
    # Stage 11
    idi_mux_line: int = 0
    bios_aced_line: int = 0
    reset_phase_7_line: int = 0
    # Stage 12
    ppr_test_done_line: int = 0
    # Stage 13
    auto_exit_line: int = 0
    # Evaluation
    status: str = "UNKNOWN"
    failing_stage: int = 0
    failing_substage: str = ""
    failure_detail: str = ""
    failure_context: List[str] = field(default_factory=list)
    # Flow validation (type-specific checks from *_reset_flow.txt)
    flow_checks: Dict[str, str] = field(default_factory=dict)


# ===========================================================================
#  SINGLE-PASS ANALYZER
# ===========================================================================

def analyze_run(run_dir, generate_summary=False, output_path=None):
    """
    Single-pass analysis of testbench.log.
    
    Returns dict with:
      - stages: Stage 0-7 results
      - reset_cycles: list of ResetCycle
      - summary: overall metrics (line count, PPR count, result, etc.)
      - failure_context: lines around first failure point
    """
    log_path = _find_log(run_dir)
    
    # State
    stage_found = {s: {} for s in STAGE_PATTERNS}
    reset_events = []
    ppr_lines = []
    rca_found = 0
    context_buf = []  # rolling buffer for failure context
    total_lines = 0
    
    # Track if we're past first reset trigger (for Stage 10+ pattern matching)
    first_trigger_line = 0
    
    # Single pass
    t_start = time.time()
    fh = _open_log(log_path)
    with fh:
        for line in fh:
            total_lines += 1
            
            # Skip short lines
            if len(line) < 5:
                continue
            # FAST PRE-FILTER: skip lines without any keyword
            if not any(kw in line for kw in _PREFILTER_KEYWORDS):
                continue
            # Skip noise (preserve primecode-state lines for Stage 10 evidence)
            if NOISE_RE.search(line) and "imh primecode state" not in line:
                continue
            
            stripped = line.strip()[:250]
            
            # Rolling context buffer (last 10 meaningful lines)
            if len(stripped) > 10:
                context_buf.append((total_lines, stripped))
                if len(context_buf) > 10:
                    context_buf.pop(0)
            
            # --- Stage 0-7 milestones (only before first reset trigger) ---
            if not first_trigger_line:
                for stage, patterns in STAGE_PATTERNS.items():
                    for name, regex, _ in patterns:
                        if name not in stage_found[stage]:
                            if regex.search(line):
                                stage_found[stage][name] = Milestone(
                                    stage=stage, substage=name,
                                    line_number=total_lines,
                                    content=stripped[:200]
                                )
            
            # --- Reset detection (always) ---
            # PPR_TEST_DONE
            if RESET_PATTERNS["ppr_test_done"].search(line):
                ppr_lines.append((total_lines, stripped[:200]))
            
            # RCA check
            m = RESET_PATTERNS["rca_check"].search(line)
            if m:
                rca_found = int(m.group(1))
            
            # Reset triggers
            triggered = False
            for pname in ("ppr_got_cf9", "rst_tag_triggering", "cold_through",
                          "warm_through", "global_through", "agr_event",
                          "awr_event", "swr_event"):
                m = RESET_PATTERNS[pname].search(line)
                if m:
                    reset_events.append((total_lines, pname, m.groups(),
                                        stripped, list(context_buf[-5:])))
                    if not first_trigger_line:
                        first_trigger_line = total_lines
                    triggered = True
                    break
            
            # Reset flow markers (post-trigger)
            if not triggered and first_trigger_line:
                for pname in ("hsle_start_reset", "cbb_event", "pltrst_sync", "global_sequence",
                              "gbl_rst_warn", "global_reset_n", "pwrgood_deassert",
                              "slp_assertion", "fuse_reload", "reset_n_assert",
                              "fake_go_rsp", "begin_reset_flow", "reset_triggered",
                              "boot_fsm_start", "boot_fsm_end",
                              "reset_phase_3_2nd", "reset_phase_6_2nd",
                              "bios_first_fetch", "icecode_reload", "hwrs_complete",
                              "idi_mux_2nd", "bios_aced_2nd", "reset_phase_7",
                              "auto_exit"):
                    m = RESET_PATTERNS[pname].search(line)
                    if m:
                        reset_events.append((total_lines, pname, m.groups(),
                                            stripped, list(context_buf[-5:])))
                        break

            # --- IMH Primecode state tracking (Stage 10 RTL phases) ---
            if first_trigger_line and 'imh primecode state' in line:
                m8 = RESET_PATTERNS["primecode_state_die8"].search(line)
                if m8:
                    reset_events.append((total_lines, "primecode_state_die8",
                                         (m8.group(1),), stripped, []))
                m9 = RESET_PATTERNS["primecode_state_die9"].search(line)
                if m9:
                    reset_events.append((total_lines, "primecode_state_die9",
                                         (m9.group(1),), stripped, []))
    
    # Build stage results
    stages = _build_stage_results(stage_found)
    _normalize_stage6_completion(stages)
    
    # Build reset cycles
    cycles = _assemble_cycles(reset_events, ppr_lines)
    
    # Classify origin
    origin = "NONE"
    if cycles:
        first_ppr_before_trigger = any(
            p[0] < cycles[0].trigger_line for p in ppr_lines
        )
        origin = "POST_OS_BOOT" if first_ppr_before_trigger else "BIOS_INITIATED"
    
    # Determine overall result
    if not cycles:
        result = _cold_boot_result(stages)
    else:
        result = _reset_result(stages, cycles, ppr_lines)
    
    # Check results.log
    results_log = _read_results_log(run_dir)
    
    summary_info = {
        "run_dir": run_dir,
        "total_lines": total_lines,
        "result": result,
        "scenario": "reset" if cycles else "cold_boot",
        "reset_origin": origin,
        "reset_cycle_count": len(cycles),
        "ppr_total_count": len(ppr_lines),
        "ppr_lines": [(l, c) for l, c in ppr_lines],
        "results_log": results_log,
        "rca_check_found": rca_found,
    }
    
    analysis = {
        "stages": stages,
        "reset_cycles": cycles,
        "summary": summary_info,
        "run_dir": run_dir,
        "log_path": log_path,
    }
    
    # Generate summary file if requested
    if generate_summary:
        out = _write_summary(analysis, output_path)
        summary_info["summary_file"] = out
    
    return analysis


# ===========================================================================
#  INTERNAL HELPERS
# ===========================================================================

def _find_log(run_dir):
    plain = os.path.join(run_dir, "testbench.log")
    gz = os.path.join(run_dir, "testbench.log.gz")
    if os.path.exists(plain):
        return plain
    elif os.path.exists(gz):
        return gz
    raise FileNotFoundError(f"No testbench.log in {run_dir}")


def _open_log(path):
    if path.endswith(".gz"):
        return gzip.open(path, "rt", errors="replace")
    return open(path, "r", errors="replace")


def _read_results_log(run_dir):
    p = os.path.join(run_dir, "test", "results.log")
    if os.path.exists(p):
        return open(p).read().strip()
    return None


def _build_stage_results(stage_found):
    results = {}
    for stage in sorted(STAGE_PATTERNS.keys()):
        pats = STAGE_PATTERNS[stage]
        found = stage_found[stage]
        required = [n for n, _, req in pats if req]
        missing = [n for n in required if n not in found]
        milestones = sorted(found.values(), key=lambda m: m.line_number)
        
        if not missing:
            status = "PASS"
        elif not found:
            prev = stage - 1
            if prev >= 0 and prev in results and results[prev].status in ("FAIL", "NOT_REACHED"):
                status = "NOT_REACHED"
            else:
                status = "FAIL"
        else:
            status = "PARTIAL"
        
        results[stage] = StageResult(stage=stage, status=status,
                                     milestones=milestones, missing=missing)
    return results


def _normalize_stage6_completion(stages):
    """Downgrade Stage 6 when BIOS completion markers were never observed."""
    s6 = stages.get(6)
    s7 = stages.get(7)
    if not s6 or s6.status != "PASS":
        return

    completion_markers = {"exit_boot_svc", "bios_aced"}
    has_bios_completion = any(m.substage in completion_markers for m in s6.milestones)

    # If BIOS completion was never observed and Stage 7 did not pass, Stage 6 is partial.
    if not has_bios_completion and (not s7 or s7.status != "PASS"):
        s6.status = "PARTIAL"
        if "bios_completion_marker" not in s6.missing:
            s6.missing.append("bios_completion_marker")


def _assemble_cycles(events, ppr_lines):
    """Build ResetCycle objects from event stream."""
    cycles = []
    current = None
    cycle_num = 0
    
    TRIGGERS = {"ppr_got_cf9", "rst_tag_triggering", "cold_through",
                "warm_through", "global_through", "agr_event",
                "awr_event", "swr_event"}
    
    for evt_line, evt_type, groups, content, ctx in events:
        if evt_type in TRIGGERS:
            # New trigger: close previous cycle if it has a reset start
            if current and current.hsle_start_reset_line > 0:
                cycles.append(current)
                current = None
            if current is None:
                cycle_num += 1
                current = ResetCycle(cycle_number=cycle_num)
                current.trigger_line = evt_line
                current.trigger_content = content
            _classify_trigger(current, evt_type, groups, content)
        elif current:
            _fill_marker(current, evt_type, groups, evt_line, ctx)
    
    if current:
        cycles.append(current)
    
    # Assign PPR_TEST_DONE to cycles
    _assign_ppr(cycles, ppr_lines)
    
    # Evaluate each cycle
    for c in cycles:
        _evaluate_cycle(c)
        _validate_flow_type(c)
    
    return cycles


def _classify_trigger(cycle, evt_type, groups, content):
    """Classify reset type and trigger source."""
    if evt_type == "ppr_got_cf9":
        val = int(groups[0]) if groups else 0
        cycle.cf9_value = hex(val)
        if val in (14, 0xE):
            cycle.reset_type = "COLD"
        elif val in (6, 0x6):
            if cycle.reset_type == "UNKNOWN":
                cycle.reset_type = "WARM"  # may become GLOBAL if gbl_etr3 set
        cycle.trigger_source = "CF9_WRITE"
    elif evt_type == "cold_through":
        cycle.reset_type = "COLD"
        src = groups[0] if groups else ""
        cycle.trigger_source = "OS_REBOOT" if "OS" in src.upper() or "reboot" in src.lower() else "SOLAR"
    elif evt_type == "warm_through":
        cycle.reset_type = "WARM"
        src = groups[0] if groups else ""
        cycle.trigger_source = "OS_REBOOT" if "OS" in src.upper() or "reboot" in src.lower() else "SOLAR"
    elif evt_type in ("global_through", "global_sequence"):
        cycle.reset_type = "GLOBAL"
        if not cycle.trigger_source or cycle.trigger_source == "CF9_WRITE":
            cycle.trigger_source = "CF9_WRITE"  # CF9 with gbl_etr3 = global
        else:
            cycle.trigger_source = "SOLAR"
    elif evt_type == "agr_event":
        cycle.reset_type = "GLOBAL"
        cycle.trigger_source = "AGR"
    elif evt_type == "awr_event":
        cycle.reset_type = "WARM"
        cycle.trigger_source = "AWR"
    elif evt_type == "swr_event":
        cycle.reset_type = "WARM"
        cycle.trigger_source = "SWR"
    elif evt_type == "rst_tag_triggering":
        name = groups[0].lower() if groups else ""
        if "cold" in name:
            cycle.reset_type = "COLD"; cycle.trigger_source = "OS_REBOOT"
        elif "warm" in name:
            cycle.reset_type = "WARM"; cycle.trigger_source = "OS_REBOOT"
        elif "global" in name:
            cycle.reset_type = "GLOBAL"; cycle.trigger_source = "SOLAR"
        elif "agr" in name:
            cycle.reset_type = "GLOBAL"; cycle.trigger_source = "AGR"
        elif "awr" in name:
            cycle.reset_type = "WARM"; cycle.trigger_source = "AWR"
        elif "swr" in name:
            cycle.reset_type = "WARM"; cycle.trigger_source = "SWR"


def _fill_marker(current, evt_type, groups, evt_line, ctx):
    """Fill stage markers into current cycle."""
    mapping = {
        "hsle_start_reset": "hsle_start_reset_line",
        "cbb_event": "cbb_event_line",
        "pltrst_sync": "pltrst_sync_line",
        "gbl_rst_warn": "gbl_rst_warn_line",
        "global_reset_n": "global_reset_n_line",
                    "global_sequence": None,  # just upgrade type
        "pwrgood_deassert": "pwrgood_deassert_line",
        "slp_assertion": "slp_assertion_line",
        "fuse_reload": "fuse_reload_line",
        "reset_n_assert": "reset_n_assert_line",
        "fake_go_rsp": "fake_go_rsp_line",
        "begin_reset_flow": "begin_reset_flow_line",
        "reset_triggered": "reset_triggered_line",
        "boot_fsm_start": "primecode_start_line",
        "boot_fsm_end": "primecode_end_line",
        "reset_phase_3_2nd": "reset_phase_3_line",
        "reset_phase_6_2nd": "reset_phase_6_line",
        "bios_first_fetch": "bios_first_fetch_line",
        "icecode_reload": "icecode_reload_line",
        "hwrs_complete": "hwrs_complete_line",
        "idi_mux_2nd": "idi_mux_line",
        "bios_aced_2nd": "bios_aced_line",
        "reset_phase_7": "reset_phase_7_line",
        "auto_exit": "auto_exit_line",
    }
    
    attr = mapping.get(evt_type)
    if not attr:
        # Special case: global_sequence upgrades cycle type to GLOBAL
        if evt_type == "global_sequence":
            current.reset_type = "GLOBAL"
        # Primecode state: track running last-state per die (IMH8/IMH9)
        if evt_type == "primecode_state_die8" and groups:
            current.last_primecode_imh8 = groups[0]
            current.last_primecode_imh8_line = evt_line
        elif evt_type == "primecode_state_die9" and groups:
            current.last_primecode_imh9 = groups[0]
            current.last_primecode_imh9_line = evt_line
        return
    
    # Only fill if not already set (first occurrence per cycle)
    if getattr(current, attr, 0) != 0:
        return
    
    # Stage 10+ markers: only after begin_reset_flow
    post_begin = {"primecode_start_line", "primecode_end_line",
                  "reset_phase_3_line", "reset_phase_6_line",
                  "bios_first_fetch_line", "icecode_reload_line",
                  "hwrs_complete_line", "idi_mux_line",
                  "bios_aced_line", "reset_phase_7_line"}
    if attr in post_begin and current.begin_reset_flow_line == 0:
        return
    
    # Stage 9 markers: only after hsle_start_reset
    stage9 = {"pltrst_sync_line", "gbl_rst_warn_line", "global_reset_n_line",
              "pwrgood_deassert_line", "slp_assertion_line", "fuse_reload_line",
              "reset_n_assert_line", "fake_go_rsp_line"}
    if attr in stage9 and current.hsle_start_reset_line == 0:
        return
    
    setattr(current, attr, evt_line)
    
    # Special: cbb_event also captures type
    if evt_type == "cbb_event" and groups:
        current.cbb_event_type = groups[0].upper()
        if current.reset_type == "UNKNOWN":
            current.reset_type = groups[0].upper()
    
    # Auto_exit: capture context
    if evt_type == "auto_exit":
        current.failure_context = [c[1] for c in ctx]


def _assign_ppr(cycles, ppr_lines):
    """Assign PPR_TEST_DONE occurrences to cycles by position."""
    if not ppr_lines or not cycles:
        return
    ppr_idx = 0
    for cycle in cycles:
        ref_line = cycle.begin_reset_flow_line or cycle.trigger_line
        while ppr_idx < len(ppr_lines) and ppr_lines[ppr_idx][0] <= ref_line:
            ppr_idx += 1
        if ppr_idx < len(ppr_lines):
            cycle.ppr_test_done_line = ppr_lines[ppr_idx][0]
            ppr_idx += 1


def _evaluate_cycle(cycle):
    """Determine pass/fail for a reset cycle."""
    if cycle.ppr_test_done_line > 0:
        cycle.status = "PASS"
        return
    if cycle.auto_exit_line > 0 and cycle.bios_aced_line > 0:
        cycle.status = "PASS"
        return
    
    # Walk through stages to find failure point
    if cycle.hsle_start_reset_line == 0:
        cycle.status = "FAIL"; cycle.failing_stage = 8
        cycle.failure_detail = "Reset trigger detected but HSLE reset never started"
    elif cycle.begin_reset_flow_line == 0:
        cycle.status = "FAIL"; cycle.failing_stage = 9
        if cycle.reset_triggered_line == 0:
            cycle.failure_detail = "HSLE started but RTL Reset triggered never seen"
        else:
            cycle.failure_detail = "RTL Reset triggered but BEGIN_RESET_FLOW missing"
    elif cycle.bios_first_fetch_line == 0:
        cycle.status = "FAIL"; cycle.failing_stage = 10
        if cycle.primecode_start_line == 0:
            cycle.failing_substage = "10.0"
            cycle.failure_detail = "BEGIN_RESET_FLOW but primecode never started"
        elif cycle.reset_phase_6_line == 0:
            cycle.failing_substage = "10.3"
            cycle.failure_detail = "Primecode started but RESET_PHASE_6 never completed"
        else:
            cycle.failing_substage = "10.4"
            cycle.failure_detail = "RESET_PHASE_6 done but BIOS first fetch never reached"
    elif cycle.bios_aced_line == 0:
        cycle.status = "FAIL"; cycle.failing_stage = 11
        cycle.failing_substage = "11.2"
        cycle.failure_detail = "BIOS first fetch wait seen but BIOS never completed (ACED missing)"
    else:
        cycle.status = "FAIL"; cycle.failing_stage = 12
        cycle.failure_detail = "BIOS completed but second PPR_TEST_DONE missing"


def _validate_flow_type(cycle):
    """
    Type-specific flow validation.
    Encodes rules from cold_reset_flow.txt / warm_reset_flow.txt / global_reset_flow.txt.
    """
    checks = {}
    if cycle.reset_type == "COLD":
        checks["pltrst_sync"] = "PASS" if cycle.pltrst_sync_line else "MISSING"
        checks["pwrgood_deassert"] = "PASS" if cycle.pwrgood_deassert_line else "WARN"
        checks["fuse_reload"] = "PASS" if cycle.fuse_reload_line else "WARN"
        if cycle.gbl_rst_warn_line:
            checks["gbl_rst_warn_unexpected"] = "UNEXPECTED"
        if cycle.fake_go_rsp_line:
            checks["fake_go_rsp_unexpected"] = "UNEXPECTED"
    elif cycle.reset_type == "WARM":
        checks["pltrst_sync"] = "PASS" if cycle.pltrst_sync_line else "WARN"
        checks["no_pwrgood_deassert"] = "PASS" if not cycle.pwrgood_deassert_line else "UNEXPECTED"
        checks["no_fuse_reload"] = "PASS" if not cycle.fuse_reload_line else "UNEXPECTED"
        checks["no_slp_assertion"] = "PASS" if not cycle.slp_assertion_line else "UNEXPECTED"
        checks["reset_n_only"] = "PASS" if cycle.reset_n_assert_line else "WARN"
    elif cycle.reset_type == "GLOBAL":
        checks["gbl_rst_warn"] = "PASS" if cycle.gbl_rst_warn_line else "MISSING"
        checks["pwrgood_deassert"] = "PASS" if cycle.pwrgood_deassert_line else "WARN"
        checks["global_reset_n"] = "PASS" if cycle.global_reset_n_line else "WARN"
        checks["fuse_reload"] = "PASS" if cycle.fuse_reload_line else "WARN"
        checks["fake_go_rsp"] = "PASS" if cycle.fake_go_rsp_line else "WARN"
        checks["icecode_reload"] = "PASS" if cycle.icecode_reload_line else "WARN"

    matrix = _load_reset_type_matrix().get(cycle.reset_type.lower(), {})
    observed = {
        "PLTRST_SYNC": bool(cycle.pltrst_sync_line),
        "GBL_RST_WARN": bool(cycle.gbl_rst_warn_line),
        "GLOBAL_RESET_N": bool(cycle.global_reset_n_line),
        "SLP_S5/S4/S3": bool(cycle.slp_assertion_line),
        "PWRGOOD-deassert": bool(cycle.pwrgood_deassert_line),
        "fuse-reload": bool(cycle.fuse_reload_line),
        "icecode-reload": bool(cycle.icecode_reload_line),
        "fake-go-rsp": bool(cycle.fake_go_rsp_line),
    }
    for feature in matrix.get("features", []):
        checks[f"matrix_expect_{feature}"] = "PASS" if observed.get(feature) else "WARN"
    for feature in matrix.get("no_features", []):
        checks[f"matrix_avoid_{feature}"] = "PASS" if not observed.get(feature) else "UNEXPECTED"

    cycle.flow_checks = checks


def _cold_boot_result(stages):
    """Overall result for normal cold boot."""
    # PASS OVERRIDE: PPR_TEST_DONE (Stage 7 PASS) = definitive run completion.
    # Handles fmod runs where Stage 0/1/5 RTL patterns are absent.
    if 7 in stages and stages[7].status == "PASS":
        return "PASS"
    for s in range(8):
        if s in stages and stages[s].status in ("FAIL", "NOT_REACHED"):
            return "FAIL"
        if s in stages and stages[s].status == "PARTIAL" and s < 6:
            return "FAIL"
    if 7 in stages and stages[7].status == "PASS":
        return "PASS"
    if 6 in stages and stages[6].status == "PARTIAL":
        return "FAIL"
    if 7 in stages and stages[7].status == "PARTIAL":
        return "FAIL"
    return "PASS"


def _reset_result(stages, cycles, ppr_lines):
    """Overall result for reset scenario."""
    for c in cycles:
        if c.status == "FAIL":
            return "FAIL"
    if len(ppr_lines) >= 2:
        return "PASS"
    if all(c.status == "PASS" for c in cycles):
        return "PASS"
    return "FAIL"


# ===========================================================================
#  SUMMARY OUTPUT
# ===========================================================================

def _write_summary(analysis, output_path=None):
    """Write structured summary file from template files in templates/ directory."""
    info = analysis["summary"]
    run_dir = info["run_dir"]

    if output_path is None:
        output_path = default_summary_output_path(run_dir)
    else:
        output_path = ensure_parent_dir(output_path)

    if analysis["reset_cycles"]:
        content = _render_reset_template(analysis)
    else:
        content = _render_cold_boot_template(analysis)

    with open(output_path, "w") as f:
        f.write(content)
    return output_path


def _templates_dir():
    return Path(__file__).resolve().parent.parent / "templates"


def _load_template(template_name):
    return (_templates_dir() / template_name).read_text(errors="replace")


def _stage_display(stages, stage_num):
    r = stages.get(stage_num)
    if not r:
        return "NOT REACHED"
    if r.milestones:
        last = r.milestones[-1]
        if r.missing:
            return f"{r.status} @ line {last.line_number} ({last.substage}) [MISSING: {', '.join(r.missing)}]"
        return f"{r.status} @ line {last.line_number} ({last.substage})"
    if r.missing:
        return f"{r.status} [MISSING: {', '.join(r.missing)}]"
    return r.status


def _cold_boot_failure(stages):
    for s in range(8):
        if s in stages and stages[s].status in ("FAIL", "PARTIAL"):
            r = stages[s]
            sub = r.milestones[-1].substage if r.milestones else "N/A"
            return s, sub
    return "NONE", "N/A"


def _extract_serconsole_text(log_path):
    if not log_path:
        return ""
    out = []
    with _open_log(log_path) as fh:
        for line in fh:
            m = re.search(r"serconsole\.con>\s?(.*)", line)
            if m:
                out.append(m.group(1).strip())
    return "\n".join(out)


def _run_bios_issue_analyzer(log_path):
    """Invoke bios-issue-analyzer decoder scripts for automatic BIOS analysis."""
    if not log_path:
        return "Log path unavailable; BIOS analysis not executed."

    serconsole_text = _extract_serconsole_text(log_path)
    if not serconsole_text.strip():
        return "No serconsole.con output found after BIOS stage; possible BIOS fetch/setup failure."

    scripts_dir = Path(__file__).resolve().parents[2] / "bios-issue-analyzer" / "scripts"
    if not scripts_dir.exists():
        return "bios-issue-analyzer scripts directory not found."

    try:
        sys.path.insert(0, str(scripts_dir))
        from decode_ewl import EWLDecoder  # type: ignore

        decoder = EWLDecoder(
            db_path=str(scripts_dir / "ewl_codes_database.json"),
            rc_db_path=str(scripts_dir / "rc_fatal_errors_database.json"),
        )
        codes = decoder.parse_log(serconsole_text)
        summary = decoder.generate_summary(codes).strip()
        if not codes:
            return (
                "Invoked bios-issue-analyzer decoder automatically.\n"
                "No EWL/IPSD/RC_FATAL signatures were found in serconsole output."
            )
        return "Invoked bios-issue-analyzer decoder automatically.\n" + summary
    except Exception as exc:
        return f"Automatic bios-issue-analyzer invocation failed: {str(exc)[:200]}"


def _cold_root_cause(stage):
    stage_name = _load_flow_stages().get(stage, "")
    stage_label = f" ({stage_name})" if stage_name else ""
    mapping = {
        6: f"  BIOS boot did not complete to ExitBootServices/BIOS_TAIL_ACED, indicating a BIOS-side stall in Stage 6{stage_label}.",
        7: f"  BIOS completed but OS/test workload did not reach PPR_TEST_DONE, indicating post-BIOS boot failure in Stage 7{stage_label}.",
    }
    return mapping.get(stage, "  Failure occurred before run completion; inspect stage markers and surrounding logs.")


def _cold_log_evidence(stages, failing_stage):
    if not isinstance(failing_stage, int):
        return "  - No failing stage identified."
    r = stages.get(failing_stage)
    if not r:
        return "  - Stage data unavailable."
    lines = []
    if r.milestones:
        last = r.milestones[-1]
        lines.append(f"  - Stage {failing_stage} last milestone at line {last.line_number}: {last.substage}")
        lines.append(f"  - Content: {last.content[:150]}")
    if r.missing:
        lines.append(f"  - Missing required markers: {', '.join(r.missing)}")
    if not lines:
        lines.append("  - No milestones captured for failing stage.")
    return "\n".join(lines)


def _read_dut_cfg_text(run_dir):
    plain = Path(run_dir) / "emurun.dut_cfg"
    gz = Path(run_dir) / "emurun.dut_cfg.gz"
    try:
        if plain.exists():
            return plain.read_text(errors="replace")
        if gz.exists():
            with gzip.open(gz, "rt", errors="replace") as fh:
                return fh.read()
    except Exception:
        return ""
    return ""


def _cfg_value_truthy(value):
    v = str(value).strip().strip('"').lower()
    return v in {"1", "true", "enable", "enabled", "yes", "on"}


def _scan_xtor_runtime_presence(log_path):
    if not log_path:
        return False, ""
    pat = re.compile(r"(cxl.*xtor|pcie.*xtor|xtor.*cxl|xtor.*pcie)", re.I)
    try:
        with _open_log(log_path) as fh:
            for lineno, line in enumerate(fh, 1):
                if pat.search(line):
                    return True, f"line {lineno}: {line.strip()[:140]}"
    except Exception:
        return False, ""
    return False, ""


def _analyze_io_xtor_consistency(run_dir, log_path):
    cfg_text = _read_dut_cfg_text(run_dir)
    if not cfg_text:
        return {"has_issue": False, "evidence": "", "recommendations": ""}

    cxl_requested = False
    pcie_requested = False
    cxl_xtor_enabled = False
    pcie_xtor_enabled = False
    pcie_disable_explicit = False

    disable_patterns = [
        re.compile(r"\bdisable_pcie\b\s*[=:]\s*(1|true|yes|on)\b", re.I),
        re.compile(r"\bsetenv\s+disable_pcie\s+1\b", re.I),
    ]

    for raw in cfg_text.splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        low = line.lower()

        # Only treat explicit disable knobs as disable intent.
        if any(p.search(low) for p in disable_patterns):
            pcie_disable_explicit = True

        if "=" not in line:
            continue
        key, value = [x.strip() for x in line.split("=", 1)]
        k = key.lower()
        v = value.lower()

        if "io_bifurcation" in k and "cxl" in v:
            cxl_requested = True
        if "io_bifurcation" in k and "pcie" in v:
            pcie_requested = True

        if "cxl_xtor" in k and _cfg_value_truthy(value):
            cxl_xtor_enabled = True
        if "pcie_xtor" in k and _cfg_value_truthy(value):
            pcie_xtor_enabled = True

    xtor_seen, xtor_line = _scan_xtor_runtime_presence(log_path)

    findings = []
    recs = []

    pcie_active = pcie_xtor_enabled or xtor_seen
    if pcie_disable_explicit and pcie_active:
        findings.append("  - Config contradiction: PCIe disabled via DISABLE_PCIE, but PCIe/CXL xtor is enabled in config/runtime.")
        recs.append("  - Harmonize run knobs: either keep DISABLE_PCIE=0 or disable PCIe/CXL xtors and related topology entries.")
    elif pcie_disable_explicit and (cxl_requested or pcie_requested):
        if cxl_requested:
            findings.append("  - Config mismatch: CXL endpoint/bifurcation requested while PCIe is explicitly disabled.")
            recs.append("  - Align config: if CXL device is present in io_bifurcation, do not disable PCIe fabric in run settings.")
        if pcie_requested:
            findings.append("  - Config mismatch: PCIe topology requested while PCIe is explicitly disabled.")
            recs.append("  - Remove DISABLE_PCIE override or update topology to match disabled PCIe mode.")

    if cxl_requested and not (cxl_xtor_enabled or pcie_xtor_enabled or xtor_seen):
        findings.append("  - Config mismatch: CXL requested but no CXL/PCIe xtor enable detected in config or runtime logs.")
        recs.append("  - Enable required transactors: CXL/PCIe xtor must be enabled when CXL topology is configured.")

    if findings and xtor_line:
        findings.append(f"  - Runtime xtor evidence present: {xtor_line}")

    return {
        "has_issue": bool(findings),
        "evidence": "\n".join(findings),
        "recommendations": "\n".join(recs),
    }


def _render_cold_boot_template(analysis):
    stages = analysis["stages"]
    info = analysis["summary"]
    run_dir = info["run_dir"]
    log_path = analysis.get("log_path")
    failing_stage, failing_substage = _cold_boot_failure(stages)

    stage8 = "PASS" if info["result"] == "PASS" else "NOT REACHED"

    last_console_line = "N/A"
    signature = "N/A"
    evidence = "  - N/A"
    recommendations = "  - No action required."
    root_cause = "  N/A"
    bios_analysis = "N/A"
    bios_substage = "N/A"
    if isinstance(failing_stage, int):
        r = stages[failing_stage]
        if r.milestones:
            last_console_line = r.milestones[-1].content[:150]
        signature = f"Stage {failing_stage} {r.status}"
        evidence = _cold_log_evidence(stages, failing_stage)
        root_cause = _cold_root_cause(failing_stage)
        recommendations = _cold_boot_recommendations(failing_stage)
        if failing_stage in (6, 7):
            bios_substage = _infer_bios_subphase(stages.get(6))
            bios_analysis = _run_bios_issue_analyzer(log_path)

        cfg_check = _analyze_io_xtor_consistency(run_dir, log_path)
        if cfg_check["has_issue"]:
            evidence = evidence + "\n" + cfg_check["evidence"]
            recommendations = recommendations + "\n" + cfg_check["recommendations"]
            root_cause = root_cause + " Configuration/run-setting mismatch detected for CXL/PCIe xtor enablement."

    placeholders = {
        "date": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "run_path": run_dir,
        "test_name": Path(run_dir).name,
        "hsle_model": extract_hsle_model(run_dir),
        "os_image": extract_os_image(run_dir),
        "log_file": log_path or "N/A",
        "log_lines": f"{info['total_lines']:,}",
        "bios_version": extract_bios_id(run_dir),
        "result": info["result"],
        "stage0": _stage_display(stages, 0),
        "stage1": _stage_display(stages, 1),
        "stage2": _stage_display(stages, 2),
        "stage3": _stage_display(stages, 3),
        "stage4": _stage_display(stages, 4),
        "stage5": _stage_display(stages, 5),
        "stage6": _stage_display(stages, 6),
        "stage7": _stage_display(stages, 7),
        "stage8": stage8,
        "failing_stage": str(failing_stage),
        "failing_substage": str(failing_substage),
        "bios_substage": bios_substage,
        "last_console_line": last_console_line,
        "last_post_code": "N/A",
        "last_cycle": "N/A",
        "timeout_cycle": "N/A",
        "silence_gap": "N/A",
        "signature": signature,
        "evidence": evidence,
        "primecode_states": "    N/A",
        "root_cause": root_cause,
        "bios_analysis": bios_analysis,
        "mca_analysis": "N/A",
        "recommendations": recommendations,
        "log_evidence": _cold_log_evidence(stages, failing_stage),
        "reference_usage": _reference_usage_block(info, stages),
    }

    return _load_template("summary_cold_boot.txt").format(**placeholders)


def _reset_failure(cycles):
    for c in cycles:
        if c.status == "FAIL":
            return c
    return None


def _render_additional_reset_cycles(cycles):
    blocks = []
    for c in cycles[1:]:
        blocks.append(
            "\n".join([
                f"  STAGE PROGRESS — RESET CYCLE {c.cycle_number}",
                "  -----------------------------------------------",
                f"  Stage 8  (Reset Trigger)        : {'PASS' if c.trigger_line else 'FAIL'}   Reset Type: {c.reset_type}",
                f"  Stage 9  (Reset Hardware Entry) : {'PASS' if c.begin_reset_flow_line else 'FAIL'}",
                f"  Stage 10 (Nth Boot RTL)         : {'PASS' if c.bios_first_fetch_line else 'FAIL'}",
                f"  Stage 11 (Nth BIOS Boot)        : {'PASS' if c.bios_aced_line else 'FAIL'}",
                f"  Stage 12 (Nth OS Boot)          : {'PASS' if c.ppr_test_done_line else 'FAIL'}",
                f"  Stage 13 (Test Termination)     : {'PASS' if c.auto_exit_line else 'NOT REACHED'}",
            ])
        )
    return "\n\n".join(blocks) if blocks else ""


def _render_reset_template(analysis):
    stages = analysis["stages"]
    cycles = analysis["reset_cycles"]
    info = analysis["summary"]
    run_dir = info["run_dir"]
    log_path = analysis.get("log_path")
    failing = _reset_failure(cycles)
    first_cycle = cycles[0]

    failing_stage = failing.failing_stage if failing else "NONE"
    failing_substage = failing.failing_substage if (failing and failing.failing_substage) else "N/A"
    signature = _cycle_signature(failing) if failing else "N/A"
    evidence = "\n".join(f"    {x}" for x in _cycle_evidence_lines(failing)) if failing else "    N/A"
    root_cause = _cycle_root_cause(failing) if failing else "  All reset cycles passed."
    recommendations = _reset_recommendations(failing) if failing else "  - No failure-specific recommendations."
    log_evidence = "\n".join(f"  - {x}" for x in _cycle_log_evidence(failing)) if failing else "  - No failing cycle."

    bios_analysis = "N/A"
    bios_substage = _infer_bios_subphase(stages.get(6)) if info.get("reset_origin") == "BIOS_INITIATED" else "N/A"
    if failing and failing.failing_stage in (6, 7, 11):
        bios_analysis = _run_bios_issue_analyzer(log_path)

    cfg_check = _analyze_io_xtor_consistency(run_dir, log_path)
    if cfg_check["has_issue"]:
        evidence = evidence + "\n" + cfg_check["evidence"]
        recommendations = recommendations + "\n" + cfg_check["recommendations"]
        root_cause = root_cause + " Configuration/run-setting mismatch detected for CXL/PCIe xtor enablement."

    placeholders = {
        "date": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "reset_type": first_cycle.reset_type,
        "run_path": run_dir,
        "test_name": Path(run_dir).name,
        "hsle_model": extract_hsle_model(run_dir),
        "os_image": extract_os_image(run_dir),
        "log_file": log_path or "N/A",
        "log_lines": f"{info['total_lines']:,}",
        "bios_version": extract_bios_id(run_dir),
        "result": info["result"],
        "reset_trigger": first_cycle.trigger_source,
        "post_setup_script": "N/A",
        "num_resets": str(len(cycles)),
        "reset_sequence": " -> ".join(f"{c.reset_type}({c.trigger_source})" for c in cycles),
        "stage0": _stage_display(stages, 0),
        "stage1": _stage_display(stages, 1),
        "stage2": _stage_display(stages, 2),
        "stage3": _stage_display(stages, 3),
        "stage4": _stage_display(stages, 4),
        "stage5": _stage_display(stages, 5),
        "stage6": _stage_display(stages, 6),
        "stage7": _stage_display(stages, 7),
        "reset_cycle_num": str(first_cycle.cycle_number),
        "stage8": "PASS" if first_cycle.trigger_line else "FAIL",
        "stage9": "PASS" if first_cycle.begin_reset_flow_line else "FAIL",
        "stage10": "PASS" if first_cycle.bios_first_fetch_line else "FAIL",
        "stage11": "PASS" if first_cycle.bios_aced_line else "FAIL",
        "stage12": "PASS" if first_cycle.ppr_test_done_line else "FAIL",
        "stage13": "PASS" if first_cycle.auto_exit_line else "NOT REACHED",
        "additional_reset_cycles": _render_additional_reset_cycles(cycles),
        "failing_stage": str(failing_stage),
        "failing_substage": str(failing_substage),
        "bios_substage": bios_substage,
        "reset_origin": info["reset_origin"],
        "first_boot_stage": _stage_display(stages, 6),
        "cf9_value": first_cycle.cf9_value or "N/A",
        "gbl_etr3": "N/A",
        "reset_class": first_cycle.reset_type,
        "vp_quiesce": "PASS" if first_cycle.hsle_start_reset_line else "FAIL",
        "cbb_event": "PASS" if first_cycle.cbb_event_line else "FAIL",
        "pltrst_or_gblrst": "PASS" if (first_cycle.pltrst_sync_line or first_cycle.gbl_rst_warn_line) else "FAIL",
        "power_signals": "PASS" if first_cycle.pwrgood_deassert_line else "N/A",
        "fuse_reload": "YES" if first_cycle.fuse_reload_line else "NO",
        "icecode_reload": "YES" if first_cycle.icecode_reload_line else "NO",
        "fake_go_rsp": "YES" if first_cycle.fake_go_rsp_line else "NO",
        "begin_reset_flow": "PASS" if first_cycle.begin_reset_flow_line else "FAIL",
        "expected_ppr_count": str(len(cycles) + 1),
        "actual_ppr_count": str(info["ppr_total_count"]),
        "last_console_line": _last_console_output(failing) if failing else "N/A",
        "last_post_code": "N/A",
        "last_cycle": str(first_cycle.trigger_line),
        "timeout_cycle": "N/A",
        "silence_gap": "N/A",
        "signature": signature,
        "evidence": evidence,
        "primecode_states": _primecode_states_block(failing),
        "root_cause": root_cause,
        "bios_analysis": bios_analysis,
        "mca_analysis": "N/A",
        "recommendations": recommendations,
        "log_evidence": log_evidence,
        "reference_usage": _reference_usage_block(info, stages, failing),
    }

    return _load_template("summary_reset_scenario.txt").format(**placeholders)


def _append_reset_template_sections(lines, cycles):
    sep = "=" * 80
    failing = next((cycle for cycle in cycles if cycle.status == "FAIL"), None)

    lines.append(sep)
    lines.append("  FAILURE ANALYSIS")
    lines.append(sep)
    lines.append("")
    if failing is None:
        lines.append("  No reset-cycle failure detected.")
        lines.append("")
    else:
        last_marker_label, last_marker_line = _last_reached_reset_marker(failing)
        lines.append("  Last Activity")
        lines.append("  -------------")
        lines.append(f"  Last console output  : {_last_console_output(failing)}")
        lines.append("  Last debug_port PC   : N/A")
        lines.append(f"  Emu cycle at last    : {last_marker_label} @ line {last_marker_line}")
        lines.append("  Timeout at           : N/A")
        lines.append("  Silence gap          : N/A")
        lines.append("")
        lines.append("  Failure Signature")
        lines.append("  -----------------")
        lines.append(f"  Signature    : {_cycle_signature(failing)}")
        lines.append("  Evidence     :")
        for evidence_line in _cycle_evidence_lines(failing):
            lines.append(f"    {evidence_line}")
        lines.append("")
        lines.append("  Root Cause")
        lines.append("  ----------")
        for root_line in _cycle_root_cause(failing).splitlines():
            lines.append(root_line)
        lines.append("")
        lines.append("  BIOS Issue Analysis (Stage 6/7/11 failures only)")
        lines.append("  -------------------------------------------------")
        if failing.failing_stage == 11:
            lines.append("  BIOS boot reached second-boot fetch but did not complete. BIOS decoder is auto-invoked for this scenario; review decoded output in this section.")
        else:
            lines.append("  N/A")
        lines.append("")

    lines.append(sep)
    lines.append("  RECOMMENDATIONS")
    lines.append(sep)
    lines.append("")
    if failing is None:
        lines.append("  - No failure-specific recommendations. All detected reset cycles passed.")
    else:
        for rec_line in _reset_recommendations(failing).splitlines():
            lines.append(rec_line)
    lines.append("")

    lines.append(sep)
    lines.append("  KEY LOG EVIDENCE")
    lines.append(sep)
    lines.append("")
    if failing is None:
        for cycle in cycles:
            lines.append(f"  - Cycle {cycle.cycle_number} trigger: line {cycle.trigger_line} | {cycle.trigger_content[:120]}")
    else:
        for evidence_line in _cycle_log_evidence(failing):
            lines.append(f"  - {evidence_line}")
    lines.append("")


def _last_console_output(cycle):
    if cycle.failure_context:
        return cycle.failure_context[-1]
    if cycle.trigger_content:
        return cycle.trigger_content[:150]
    return cycle.failure_detail or "N/A"


def _last_reached_reset_marker(cycle):
    markers = [
        ("AUTO_EXIT", cycle.auto_exit_line),
        ("PPR_TEST_DONE", cycle.ppr_test_done_line),
        ("BIOS_ACED", cycle.bios_aced_line),
        ("BIOS_FIRST_FETCH", cycle.bios_first_fetch_line),
        ("RESET_PHASE_6", cycle.reset_phase_6_line),
        ("PRIMECODE_START", cycle.primecode_start_line),
        ("BEGIN_RESET_FLOW", cycle.begin_reset_flow_line),
        ("RESET_TRIGGERED", cycle.reset_triggered_line),
        ("HSLE_START_RESET", cycle.hsle_start_reset_line),
        ("RESET_TRIGGER", cycle.trigger_line),
    ]
    for label, line in markers:
        if line:
            return label, line
    return "N/A", 0


def _cycle_signature(cycle):
    stage_text = f"Stage {cycle.failing_stage}"
    if cycle.failing_substage:
        stage_text += f".{cycle.failing_substage}"
    if cycle.failure_detail:
        return f"{stage_text}: {cycle.failure_detail}"
    return stage_text


def _cycle_root_cause(cycle):
    root_causes = {
        (10, "10.0"): "  Reset hardware entry reached BEGIN_RESET_FLOW, but second-boot primecode never started. This points to a stall in early reset-phase bring-up before BIOS first fetch.",
        (10, "10.3"): "  Primecode started but RESET_PHASE_6 never completed, which indicates the second-boot RTL reset sequence stalled before handoff to BIOS.",
        (10, "10.4"): "  RESET_PHASE_6 completed, but BIOS first fetch never occurred. The handoff from reset flow into BIOS execution did not complete.",
        (11, "11.2"): "  BIOS first fetch wait was reached, but the second BIOS boot never completed to ACED. This indicates a BIOS-side failure or hang during the second boot.",
        (12, ""): "  BIOS completed on the second boot, but the workload never reached the next PPR_TEST_DONE marker. The failure is after BIOS completion in OS or workload execution.",
    }
    return root_causes.get((cycle.failing_stage, cycle.failing_substage), f"  {cycle.failure_detail or 'Reset cycle failed before completion.'}")


def _cycle_evidence_lines(cycle):
    evidence = [f"Trigger line {cycle.trigger_line}: {cycle.trigger_content[:120]}"]
    label, line = _last_reached_reset_marker(cycle)
    if line:
        evidence.append(f"Last reached marker: {label} at line {line}")
    if cycle.failure_detail:
        evidence.append(f"Failure detail: {cycle.failure_detail}")
    for key, value in cycle.flow_checks.items():
        if value != "PASS":
            evidence.append(f"Flow check {key}: {value}")
    if cycle.failure_context:
        evidence.extend(cycle.failure_context[-3:])
    return evidence


def _load_primecode_states():
    cache = getattr(_load_primecode_states, "_cache", None)
    if cache is not None:
        return cache

    path = Path(__file__).resolve().parent.parent / "primecode_states.txt"
    ordered = []
    by_name = {}
    if path.exists():
        for raw in path.read_text(errors="replace").splitlines():
            line = raw.strip()
            m = re.match(r"^(0x[0-9a-fA-F]+)\s+([A-Z0-9_]+)$", line)
            if not m:
                continue
            hex_id = m.group(1).lower()
            name = m.group(2)
            by_name[name] = len(ordered)
            ordered.append((hex_id, name))

    cache = (ordered, by_name)
    _load_primecode_states._cache = cache
    return cache


def _primecode_state_meta(state_name):
    if not state_name:
        return None, None, None
    ordered, by_name = _load_primecode_states()
    idx = by_name.get(state_name)
    if idx is None:
        return None, None, None
    current_hex, _ = ordered[idx]
    next_item = ordered[idx + 1] if idx + 1 < len(ordered) else None
    return idx, current_hex, next_item


def _primecode_states_block(cycle):
    if not cycle or cycle.failing_stage != 10:
        return "    N/A"

    idx8, hex8, next8 = _primecode_state_meta(cycle.last_primecode_imh8)
    idx9, hex9, next9 = _primecode_state_meta(cycle.last_primecode_imh9)

    imh8 = (
        f"    IMH8 (die8): {cycle.last_primecode_imh8} [{hex8}] @ line {cycle.last_primecode_imh8_line}"
        if cycle.last_primecode_imh8 and hex8 else
        f"    IMH8 (die8): {cycle.last_primecode_imh8} @ line {cycle.last_primecode_imh8_line}"
        if cycle.last_primecode_imh8 else
        "    IMH8 (die8): N/A (not reached)"
    )
    imh9 = (
        f"    IMH9 (die9): {cycle.last_primecode_imh9} [{hex9}] @ line {cycle.last_primecode_imh9_line}"
        if cycle.last_primecode_imh9 and hex9 else
        f"    IMH9 (die9): {cycle.last_primecode_imh9} @ line {cycle.last_primecode_imh9_line}"
        if cycle.last_primecode_imh9 else
        "    IMH9 (die9): N/A (not reached)"
    )

    imh8_next = (
        f"    IMH8 next expected: {next8[1]} [{next8[0]}]"
        if next8 else "    IMH8 next expected: N/A"
    )
    imh9_next = (
        f"    IMH9 next expected: {next9[1]} [{next9[0]}]"
        if next9 else "    IMH9 next expected: N/A"
    )

    highest_sync = "    Highest synchronized state: N/A"
    asymmetry = "    Asymmetry: N/A"
    if idx8 is not None and idx9 is not None:
        sync_idx = min(idx8, idx9)
        ordered, _ = _load_primecode_states()
        sync_hex, sync_name = ordered[sync_idx]
        highest_sync = f"    Highest synchronized state: {sync_name} [{sync_hex}]"
        if idx8 == idx9:
            asymmetry = "    Asymmetry: none (both dies reached the same decoded state)"
        elif idx8 < idx9:
            asymmetry = f"    Asymmetry: IMH8 trails IMH9 by {idx9 - idx8} state(s)"
        else:
            asymmetry = f"    Asymmetry: IMH9 trails IMH8 by {idx8 - idx9} state(s)"

    return "\n".join([
        "    Reference: reset_phase_flow.txt + primecode_states.txt",
        imh8,
        imh8_next,
        imh9,
        imh9_next,
        highest_sync,
        asymmetry,
    ])



def _load_flow_stages():
    """Load stage names from flow.txt for reference."""
    cache = getattr(_load_flow_stages, "_cache", None)
    if cache is not None:
        return cache
    path = Path(__file__).resolve().parent.parent / "flow.txt"
    stages = {}
    if path.exists():
        for raw in path.read_text(errors="replace").splitlines():
            line = raw.strip()
            m = re.match(r"^STAGE\s+(\d+):\s+(.+?)\s*$", line)
            if m:
                stages[int(m.group(1))] = m.group(2)
    _load_flow_stages._cache = stages
    return stages


def _extract_reset_matrix_from_global_flow():
    """Parse the reset-type comparison table from global_reset_flow.txt."""
    cache = getattr(_extract_reset_matrix_from_global_flow, "_cache", None)
    if cache is not None:
        return cache

    path = Path(__file__).resolve().parent.parent / "global_reset_flow.txt"
    matrix = {"COLD": {}, "WARM": {}, "GLOBAL": {}}
    if path.exists():
        for raw in path.read_text(errors="replace").splitlines():
            m = re.match(r"^\|\s*([^|]+?)\s*\|\s*([^|]+?)\s*\|\s*([^|]+?)\s*\|\s*([^|]+?)\s*\|$", raw.strip())
            if not m:
                continue
            feature = m.group(1).strip()
            if feature.lower() == "feature" or feature.startswith("+"):
                continue
            matrix["COLD"][feature] = m.group(2).strip()
            matrix["WARM"][feature] = m.group(3).strip()
            matrix["GLOBAL"][feature] = m.group(4).strip()

    _extract_reset_matrix_from_global_flow._cache = matrix
    return matrix


def _load_reset_type_matrix():
    """Load reset-type expectations from cold/warm/global reset flow references."""
    cache = getattr(_load_reset_type_matrix, "_cache", None)
    if cache is not None:
        return cache

    matrix = _extract_reset_matrix_from_global_flow()
    compact = {
        "cold": {"cf9": "0xE", "features": [], "no_features": []},
        "warm": {"cf9": "0x6", "features": [], "no_features": []},
        "global": {"cf9": "0x6+etr3", "features": [], "no_features": []},
    }

    feature_map = [
        ("PLTRST_SYNC wait", "PLTRST_SYNC"),
        ("GBL_RST_WARN wait", "GBL_RST_WARN"),
        ("GLOBAL_RESET_N asserted", "GLOBAL_RESET_N"),
        ("SLP_S5/S4/S3 asserted", "SLP_S5/S4/S3"),
        ("XX_PWRGOOD de-asserted", "PWRGOOD-deassert"),
        ("Fuse reload", "fuse-reload"),
        ("IceCode reload", "icecode-reload"),
        ("Fake GO RSP W/A", "fake-go-rsp"),
    ]

    for key, bucket in (("COLD", compact["cold"]), ("WARM", compact["warm"]), ("GLOBAL", compact["global"])):
        for feature_name, label in feature_map:
            state = matrix.get(key, {}).get(feature_name, "").upper()
            if state.startswith("YES"):
                bucket["features"].append(label)
            elif state.startswith("NO"):
                bucket["no_features"].append(label)

    _load_reset_type_matrix._cache = compact
    return compact


def _parse_streams_from_reset_phase_flow():
    """Extract stream names from reset_phase_flow.txt for summary context."""
    cache = getattr(_parse_streams_from_reset_phase_flow, "_cache", None)
    if cache is not None:
        return cache

    path = Path(__file__).resolve().parent.parent / "reset_phase_flow.txt"
    streams = []
    if path.exists():
        for raw in path.read_text(errors="replace").splitlines():
            m = re.match(r"^STREAM\s+(\d+)\s*:\s*(.+)$", raw.strip())
            if m:
                streams.append(f"Stream {m.group(1)}: {m.group(2)}")
                continue
            m = re.match(r"^STREAM\s+(\d+)\s+--\s+(.+)$", raw.strip())
            if m:
                streams.append(f"Stream {m.group(1)}: {m.group(2)}")

    _parse_streams_from_reset_phase_flow._cache = streams[:3]
    return streams[:3]


def _load_bios_phases():
    """Load BIOS sub-phase names from bios_flow.txt."""
    cache = getattr(_load_bios_phases, "_cache", None)
    if cache is not None:
        return cache
    path = Path(__file__).resolve().parent.parent / "bios_flow.txt"
    phases = {}
    if path.exists():
        for raw in path.read_text(errors="replace").splitlines():
            line = raw.strip()
            m = re.match(r"^STAGE\s+6\.(\d)\s+--\s+(.+?)\s*$", line)
            if m:
                phases[int(m.group(1))] = m.group(2)
    if not phases:
        phases = {0: "SEC PHASE", 1: "PEI PRE-MEMORY", 2: "PEI POST-MEMORY", 3: "DXE IPL", 4: "DXE DRIVERS", 5: "BDS DRIVERS", 6: "BOOT OPTIONS"}
    _load_bios_phases._cache = phases
    return phases

def _cycle_log_evidence(cycle):
    evidence = [
        f"Cycle {cycle.cycle_number} trigger: line {cycle.trigger_line} | {cycle.trigger_content[:120]}",
        f"HSLE start reset: {'line ' + str(cycle.hsle_start_reset_line) if cycle.hsle_start_reset_line else 'NOT REACHED'}",
        f"BEGIN_RESET_FLOW: {'line ' + str(cycle.begin_reset_flow_line) if cycle.begin_reset_flow_line else 'NOT REACHED'}",
        f"Primecode start: {'line ' + str(cycle.primecode_start_line) if cycle.primecode_start_line else 'NOT REACHED'}",
        f"BIOS first fetch: {'line ' + str(cycle.bios_first_fetch_line) if cycle.bios_first_fetch_line else 'NOT REACHED'}",
        f"BIOS ACED: {'line ' + str(cycle.bios_aced_line) if cycle.bios_aced_line else 'NOT REACHED'}",
        f"PPR_TEST_DONE: {'line ' + str(cycle.ppr_test_done_line) if cycle.ppr_test_done_line else 'NOT REACHED'}",
    ]
    for key, value in cycle.flow_checks.items():
        evidence.append(f"Flow validation {key}: {'OK' if value == 'PASS' else value}")
    return evidence


def _cold_boot_recommendations(stage):
    recs = {
        0: "  - Check spark_session.log for launch errors\n  - Verify ZeBu hardware allocation",
        1: "  - Check emu_log for ZSE5 init errors\n  - Verify ZeBu board connectivity",
        2: "  - Check IDI link errors\n  - Verify model version compatibility",
        3: "  - Check ZeBu compilation log\n  - Verify RTL model path accessible",
        4: "  - Check Simics launch/license errors\n  - Verify VP creation logs",
        5: "  - See reset_phase_flow.txt for sub-phase analysis\n  - Check RESET_PHASE_1-6 progression\n  - Verify both imh8/imh9 symmetry",
        6: "  - Check for BIOS-initiated reset (CF9 write during BIOS)\n  - See bios_flow.txt for sub-phases 6.0-6.6\n  - Review auto-generated BIOS Issue Analysis section above",
        7: "  - Check serconsole for OS boot errors\n  - Verify PPR test workload config",
    }
    return recs.get(stage, "  - Inspect testbench.log around last milestone")


def _infer_bios_subphase(stage6_result):
    """Map Stage 6 milestones to bios_flow.txt sub-phases (best-effort)."""
    if not stage6_result or not stage6_result.milestones:
        return "N/A"

    rank = {
        "bios_start": 0,
        "early_pch_init": 1,
        "start_mrc": 2,
        "pei_memory": 3,
        "dxe_ipl": 4,
        "bds_boot": 5,
        "exit_boot_svc": 6,
        "bios_aced": 6,
    }
    seen = [rank[m.substage] for m in stage6_result.milestones if m.substage in rank]
    if not seen:
        return "N/A"

    idx = max(seen)
    phase_name = _load_bios_phases().get(idx, "")
    return f"6.{idx} {phase_name}".strip()


def _load_reset_flow_highlights():
    """Load key differentiators from cold/warm/global reset flow references."""
    cache = getattr(_load_reset_flow_highlights, "_cache", None)
    if cache is not None:
        return cache

    base = Path(__file__).resolve().parent.parent
    files = {
        "cold_reset_flow.txt": [r"CF9 register write 0xE", r"PLTRST_SYNC", r"fuse reload"],
        "warm_reset_flow.txt": [r"CF9 register value = 0x6", r"NO PWRGOOD de-assertion", r"NO fuse reload"],
        "global_reset_flow.txt": [r"gbl_etr3", r"GBL_RST_WARN", r"GLOBAL_RESET_N"],
    }

    highlights = {}
    for fname, patterns in files.items():
        path = base / fname
        picked = []
        if path.exists():
            lines = path.read_text(errors="replace").splitlines()
            for pat in patterns:
                rx = re.compile(pat, re.I)
                hit = next((ln.strip() for ln in lines if rx.search(ln)), "")
                if hit:
                    picked.append(hit[:120])
        highlights[fname] = picked

    _load_reset_flow_highlights._cache = highlights
    return highlights


def _load_scripts_readme_hints():
    """Load concise capability hints from scripts/README.txt."""
    cache = getattr(_load_scripts_readme_hints, "_cache", None)
    if cache is not None:
        return cache

    path = Path(__file__).resolve().parent / "README.txt"
    hints = []
    if path.exists():
        in_supported = False
        for raw in path.read_text(errors="replace").splitlines():
            line = raw.rstrip()
            if line.startswith("Supported Scenarios:"):
                in_supported = True
                continue
            if in_supported and line.startswith("Output:"):
                break
            if in_supported and line.strip().startswith("-"):
                hints.append(line.strip().lstrip("-").strip())

    _load_scripts_readme_hints._cache = hints[:3]
    return hints[:3]


def _reference_usage_block(info, stages, failing_cycle=None):
    """Render which reference .txt files were loaded and applied."""
    flow = _load_flow_stages()
    bios = _load_bios_phases()
    streams = _parse_streams_from_reset_phase_flow()
    matrix = _load_reset_type_matrix()
    readme_hints = _load_scripts_readme_hints()
    reset_highlights = _load_reset_flow_highlights()

    stage_list = ", ".join(f"{k}:{v}" for k, v in sorted(flow.items())[:8]) if flow else "N/A"
    bios_list = ", ".join(f"6.{k}:{v}" for k, v in sorted(bios.items())) if bios else "N/A"
    stream_text = " | ".join(streams) if streams else "N/A"

    lines = [
        "  - flow.txt: stage metadata loaded for summary context and stage naming.",
        f"    Loaded stages: {stage_list}",
        "  - bios_flow.txt: BIOS 6.0-6.6 phase map loaded for Stage 6/7/11 triage.",
        f"    Loaded BIOS phases: {bios_list}",
        "  - reset_phase_flow.txt: Stage 5/10 stream model loaded for symmetry guidance.",
        f"    Stream model: {stream_text}",
        "  - primecode_states.txt: IMH primecode state-id decode + next-state inference.",
        "  - cold_reset_flow.txt / warm_reset_flow.txt / global_reset_flow.txt: reset behavior matrix applied to flow checks.",
        f"    cold_reset_flow.txt highlights: {'; '.join(reset_highlights.get('cold_reset_flow.txt', [])) or 'N/A'}",
        f"    warm_reset_flow.txt highlights: {'; '.join(reset_highlights.get('warm_reset_flow.txt', [])) or 'N/A'}",
        f"    global_reset_flow.txt highlights: {'; '.join(reset_highlights.get('global_reset_flow.txt', [])) or 'N/A'}",
        f"  - scripts/README.txt: automation coverage hints loaded ({'; '.join(readme_hints) if readme_hints else 'N/A'}).",
    ]

    if info.get("scenario") == "reset" and failing_cycle:
        spec = matrix.get((failing_cycle.reset_type or "").lower(), {})
        if spec:
            lines.append(
                f"    Active reset profile ({failing_cycle.reset_type}): expect [{', '.join(spec.get('features', [])) or 'N/A'}], avoid [{', '.join(spec.get('no_features', [])) or 'N/A'}]"
            )

    return "\n".join(lines)


def _reset_recommendations(cycle):
    stage = cycle.failing_stage
    rtype = cycle.reset_type

    stage10_stuck = "BOOT_FSM stuck state unavailable"
    if stage == 10:
        states = []
        if cycle.last_primecode_imh8:
            _, hex8, _ = _primecode_state_meta(cycle.last_primecode_imh8)
            states.append(
                f"IMH8={cycle.last_primecode_imh8} [{hex8}] @ line {cycle.last_primecode_imh8_line}"
                if hex8 else f"IMH8={cycle.last_primecode_imh8} @ line {cycle.last_primecode_imh8_line}"
            )
        if cycle.last_primecode_imh9:
            _, hex9, _ = _primecode_state_meta(cycle.last_primecode_imh9)
            states.append(
                f"IMH9={cycle.last_primecode_imh9} [{hex9}] @ line {cycle.last_primecode_imh9_line}"
                if hex9 else f"IMH9={cycle.last_primecode_imh9} @ line {cycle.last_primecode_imh9_line}"
            )
        if states:
            stage10_stuck = " / ".join(states)

    recs = {
        8: "  - Verify post-setup script loaded\n  - Check os_reset_triggers.simics dispatch table",
        9: f"  - Check serconsole for errors before hardware entry\n  - Verify {'PLTRST_SYNC' if rtype != 'GLOBAL' else 'GBL_RST_WARN'} completion\n  - Check if VP quiesce succeeded",
        10: f"  - See reset_phase_flow.txt for HWRS sub-phase detail\n  - Check BOOT_FSM stuck state: {stage10_stuck}\n",
        11: "  - Check if IDI Mux was enabled after RESET_PHASE_6\n  - See bios_flow.txt for BIOS sub-phases\n  - Review auto-generated BIOS Issue Analysis section above\n  - Check for BIOS hang vs VP/RTL handoff issue",
        12: "  - Check serconsole for second OS boot errors\n  - Verify PPR workload starts on second boot\n  - Check for kernel panic or OOM",
    }
    return recs.get(stage, "  - Inspect testbench.log at failure point")


# ===========================================================================
#  CLI ENTRY POINT
# ===========================================================================

if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="HSLE Run Analyzer - Single-pass debug")
    parser.add_argument("run_dir", help="Path to HSLE run directory")
    parser.add_argument("--json", action="store_true", help="Output JSON to stdout")
    parser.add_argument("--summary", action="store_true", help="Generate summary file")
    parser.add_argument("--output", "-o", help="Override output file path")
    parser.add_argument("--verbose", "-v", action="store_true", help="Verbose output")
    args = parser.parse_args()
    
    run_dir = os.path.abspath(args.run_dir)
    if not os.path.isdir(run_dir):
        print(f"ERROR: {run_dir} not found", file=sys.stderr)
        sys.exit(1)
    
    start = time.time()
    
    analysis = analyze_run(run_dir, generate_summary=args.summary or not args.json,
                          output_path=args.output)
    
    elapsed = time.time() - start
    
    if args.json:
        # Machine-readable output for agent
        out = {
            "run_dir": run_dir,
            "elapsed_seconds": round(elapsed, 1),
            **analysis["summary"],
            "stages": {},
            "cycles": [],
        }
        for s in sorted(analysis["stages"]):
            r = analysis["stages"][s]
            out["stages"][str(s)] = {
                "status": r.status,
                "last_line": r.milestones[-1].line_number if r.milestones else 0,
                "missing": r.missing,
            }
        for c in analysis["reset_cycles"]:
            out["cycles"].append({
                "number": c.cycle_number,
                "type": c.reset_type,
                "source": c.trigger_source,
                "status": c.status,
                "trigger_line": c.trigger_line,
                "failing_stage": c.failing_stage if c.status == "FAIL" else None,
                "failure_detail": c.failure_detail if c.status == "FAIL" else None,
                "flow_checks": c.flow_checks,
            })
        # Remove non-serializable items
        out.pop("ppr_lines", None)
        print(json.dumps(out, indent=2))
    else:
        info = analysis["summary"]
        print(f"HSLE Run Analyzer")
        print(f"{'=' * 60}")
        print(f"Run: {run_dir}")
        print(f"Log: {info['total_lines']:,} lines | Elapsed: {elapsed:.1f}s")
        print(f"Result: {info['result']} | Scenario: {info['scenario']}")
        if analysis["reset_cycles"]:
            types = " -> ".join(f"{c.reset_type}({c.trigger_source})" for c in analysis["reset_cycles"])
            print(f"Resets: {len(analysis['reset_cycles'])} cycle(s): {types}")
            print(f"Origin: {info['reset_origin']}")
            for c in analysis["reset_cycles"]:
                status_mark = "PASS" if c.status == "PASS" else f"FAIL@Stage{c.failing_stage}"
                print(f"  Cycle {c.cycle_number}: {c.reset_type}({c.trigger_source}) -> {status_mark}")
                if c.status == "FAIL":
                    print(f"    {c.failure_detail}")
        print(f"PPR count: {info['ppr_total_count']} | results.log: {info['results_log'] or 'N/A'}")
        if "summary_file" in info:
            print(f"\nSummary: {info['summary_file']}")
