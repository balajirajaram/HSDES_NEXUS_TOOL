---
name: mca-log-analyzer
description: >
  Use when a log or HSDES comment contains MCi_STATUS hex values, MCA errors, or
  PythonSV output (nd_cbos_sum_mca_status CCF tables, Machine Check detected entries,
  Status HEXH format, debug.error.show_errors). Also use when decoding MSCOD/MCACOD
  pairs, understanding processor bank-specific errors (IFU, DCU, MLC, CCF, MCCHAN, UPI),
  or getting recommended recovery actions for machine check exceptions (MCE). Also
  triggers on: "IERR", "MCERR", "uncorrected error (UCE)", "machine check exception",
  "MCi_STATUS=", or "MCA bank" in ticket titles, descriptions, or logs.
---

# MCA Log Analyzer

Decode MCA (Machine Check Exception) status values from Intel processor logs. Extracts MSCOD/MCACOD from MCi_STATUS registers and maps codes to bank-specific decode, description, and action guidance using DMR MCA customer documentation.

## When to Use This Skill

- Analyzing HSDES logs or comments containing MCA errors
- Decoding MCi_STATUS register values (64-bit hex like 0xB200004000000005)
- Understanding processor bank-specific errors (IFU, DCU, MLC, CCF, MCCHAN, etc.)
- PythonSV output: `nd_cbos_sum_mca_status` CCF tables, `Machine Check detected` entries, `debug.error.show_errors` output
- Need to translate MSCOD/MCACOD pairs to customer-facing descriptions and recovery actions

## Capabilities

**MCA Status Decode:**
- Parses 64-bit MCi_STATUS values and extracts MSCOD (bits 31:16) and MCACOD (bits 15:0)
- Matches bank-specific entries from 440 MCA decode definitions
- Supports 16 processor banks (IFU, DCU, DTLB, MLC, CBB Punit, CCF, NCU, MCCHAN, etc.)

**Pattern Matching:**
- **Wildcard patterns** - Matches codes like `0x**00` (any value in wildcard positions)
- **Bit-based matching** - Matches specific MSCOD bits (e.g., "Bit 3")
- **"Don't care" fields** - Matches any value when MCACOD is marked as "Don't care"
- **Multiple values** - Handles comma/slash separated values (e.g., `0x0090, 0x0290`)

**Output Features:**
- Error class (C/UC/UCNA) and severity
- Bank-specific decode and description
- Recommended recovery actions
- Example context from logs
- Occurrence counts and grouping

## Workflow

1. **Parse input** — accept MCi_STATUS hex value, MSCOD/MCACOD pair, or full log text
2. **Extract fields** — split 64-bit status into MSCOD (bits 31:16) and MCACOD (bits 15:0)
3. **Identify bank** — determine processor bank from register path, context, or explicit bank number
4. **Match patterns** — look up MSCOD/MCACOD combination in bank-specific decode table (wildcard, bit-based, and don't-care matching)
5. **Return results** — error class, decode description, recommended action, and occurrence context

## Quick Start

### Decode a Single Status Value

```bash
cd scripts
python3 main.py decode-status 0xB200004000000005 0
```

**Output example:**
```
## MCA Status Decode

**Status:** `0xB200004000000005`
**Bank:** 0
**MSCOD:** 0x0000
**MCACOD:** 0x0005

**Matches:**
- **IFU** (IFU-DCU-DTLB-MLC)
  - **Error Class:** C/UC
  - **Decode:** Internal Parity Error - PRF parity
  - **Action:** [Standard Internal HW Error] Verify system has the latest 
    microcode. Possible Voltage, Noise, Clock Issue, or CPU defect...
```

### Decode Explicit MSCOD/MCACOD

```bash
python3 main.py decode-codes 0x0813 0x0080 19
```

Use this when you have MSCOD/MCACOD values already extracted.

### Analyze a Log

```bash
python3 main.py analyze-log "Bank 0 MCi_STATUS=0xB200004000000005"
# or pass a file path directly
python3 main.py analyze-log /path/to/pythonsv_PC6_check.txt
# or pipe via stdin
cat mce.log | python3 main.py analyze-log
```

Automatically extracts all MCi_STATUS values from logs and decodes them. Supports
standard Linux/BIOS formats as well as PythonSV `debug.error.show_errors()` output.

## Log Formats Supported

Automatically detects and parses:

1. **MCi_STATUS register dumps:**
   ```
   socket0.core0.mc0_status = 0xb200004000000005
   MCi_STATUS: 0xB200000000050115
   Bank 0 Status = 0xB200004000000005
   ```

2. **Register paths with bank context:**
   ```
   socket0.imh1.memss.mc3.subch0.mcdata.imc0_mc_status=0xec00000200a00090
   ```
   Automatically extracts bank from memory controller number (mc0-7 → banks 19-26)

3. **Explicit MSCOD/MCACOD fields:**
   ```
   MSCOD: 0x0000
   MCACOD: 0x0005
   ```

4. **Hex tokens in context:**
   - Searches for 64-bit `0x`-prefixed hex values in lines mentioning "MCA", "bank", "status"

5. **PythonSV verbose format** (`Machine Check detected` / `debug.error.show_errors` output):
   ```
   Machine Check detected in SOCKET0 MODULE36 MLC bank: MSCOD=THREE_STRIKE (E101H), MCACOD=INTERNAL_TIMER (0400H)
   Status (F2000000E1010400H)
   ```
   Parses symbolic-name + hex-in-parens format and H-suffix status values.

6. **PythonSV summary table:**
   ```
   socket0.module36.mlc  Machine Check detected in SOCKET0 MODULE36 MLC bank: MSCOD=0xE101, MCACOD=0x0400
   ```

7. **PythonSV CCF nd_cbos_sum_mca_status table:**
   ```
   ========= Ccf: nd_cbos_sum_mca_status =============
   │ IpName │ MCA │ Valid │ MCACOD (RRRR,TT) │ MSCOD │ ...
   │ socket0_cbb1_cbo5 │ Dec [Enc] │ Valid MC [1] │ GENERIC_ERR [0x110a] │ TOR_TIMEOUT_ERROR [0x4000] │
   ```
   Parses column-based CCF table rows and assigns bank 6 (CCF).

8. **Linux MCE format** (kernel `mce:` output, hex without `0x` prefix):
   ```
   mce: [Hardware Error]: CPU 0: Machine Check Exception: 5 Bank 4: be00000000010410
   ```
   Extracts bank number and 16-char hex status in one pass. Common in dmesg/kernel panic output.

9. **BIOS RAS multi-line format** (`[CpuRas]MC status` + `McBankErrorHandler`):
   ```
   [Mca]McBankErrorHandler: Skt = 0x0, McBank = 0x4, State = 0x2
   S0 D0 T0 M1 C0 T0
   [CpuRas]MC status 0xBE00000000010410, class FATAL
   ```
   Status is extracted from the `[CpuRas]` line; bank is resolved via lookback
   to the nearest `McBank = 0xN` line (up to 5 lines back).

## Bank Number Extraction

The decoder automatically extracts bank numbers from multiple formats:

- **Memory Controllers:** `mc0` → Bank 19, `mc1` → Bank 20, ..., `mc7` → Bank 26
- **Component paths:** `ccf`, `hamvf`, `hsf`, `sca`, `ioca`, `mse`, `iocache`, `uxi`
- **Legacy format:** `bank #N` or `bank N`
- **BIOS RAS format:** `McBank = 0xN` (hex) from `McBankErrorHandler` lines
- **Context-aware:** Distinguishes CBB vs IMH instances for D2D and Punit

**Example:**
```
socket0.imh1.memss.mc3.subch0.mcdata.imc0_mc_status=0xec00000200a00090
                    ^^^
                    mc3 → Bank 22 (MCCHAN3)
```

## MCA Banks Supported

Database covers 25 processor banks from DMR MCA documentation (currently 16 populated):

- **Core:** IFU, DCU, DTLB, MLC (Banks 0-3)
- **CBB:** Punit, NCU, CCF, D2D (Banks 4-7)
- **Root:** RASIP (CXL/PCIE) (Bank 10)
- **IMH:** Punit, HA/MVF, HSF, SCA, D2D, MSE, IOCache, UXI (Banks 11-18)
- **Memory:** MCCHAN0-7 (Banks 19-26)

**Bank Mapping:**
| Bank | Component | Location | Merged? |
|------|-----------|----------|---------|
| 0 | IFU | Core | No |
| 1 | DCU | Core | No |
| 2 | DTLB | Core | No |
| 3 | MLC | Module | No |
| 6 | CCF | Uncore | Yes (0-31) |
| 7 | D2D | CBB | Yes (0-7) |
| 12 | HA/MVF | IMH | Yes (0-15) |
| 13 | HSF | IMH | Yes (0-15) |
| 14 | SCA/IOCA | IMH | Yes (0-15) |
| 15 | D2D | IMH | Yes (0-11) |
| 16 | MSE | IMH | Yes (0-15) |
| 17 | IOCache | IMH | Yes (0-15) |
| 18 | UXI | IMH | Yes (0-3) |
| 19-26 | MCCHAN0-7 | Memory | Yes (0-1) |

## Database Source

- **Source:** `DMR_MCA_CUSTOMER_DOCUMENTATION.xlsx` (Intel DMR MCA customer documentation)
- **Entries:** 440 MCA decode definitions across 16 banks
- **Columns:** MSCOD, MCACOD, Error Class, Decode, Description, Action
- **Filters:** Only externally-approved entries; hidden/merged rows excluded

## Files

- **scripts/mca_decoder.py** - Core decoder with pattern matching and log parser
- **scripts/main.py** - Skill entrypoint (decode-status, decode-codes, analyze-log commands)
- **scripts/mca_codes_database.json** - 440 MCA decode entries (generated from XLSX)

## Updating Database

Regenerate from updated DMR MCA documentation:

```bash
# Place DMR_MCA_CUSTOMER_DOCUMENTATION.xlsx in scripts/ directory
python3 scripts/generate_db.py
```

The database is generated from the Excel file using the `generate_db.py` script.

## Boundaries

- Currently covers Diamond Rapids (DMR) MCA codes only — not applicable to earlier platforms (ICX, SPR, EMR)
- Database contains 440 entries across 16 populated banks; banks 8-9 are reserved/undefined
- MCCHAN banks (19-26) require `generate_db.py` to populate from the MCA customer documentation Excel
- Does not perform root-cause analysis — only decodes register values. Use `bios-source-analysis` for source-level tracing.
- Log format auto-detection may miss non-standard formats; use explicit `decode-status` or `decode-codes` commands as fallback

## Next Steps

After decode is complete, offer the user these options:

1. **Trace to source** — MCA bank and error code identified, need source-level analysis → invoke `bios-source-analysis`
2. **Done** — no further action needed
