#!/usr/bin/env python3
import sys
import json
import argparse
import re
from pathlib import Path
from openpyxl import load_workbook

DEFAULT_EXCEL = "DMR_MCA_CUSTOMER_DOCUMENTATION.xlsx"
OUTPUT_JSON = "mca_codes_database.json"

COL_PATTERNS = {
    "bank": [r"bank\s*#", r"^bank$"],
    "mscod": [r"mscod\s*\(external\)", r"^mscod$"],
    "mcacod": [r"mcacod\s*\(external\)", r"^mcacod$"],
    "error_class": [r"error\s*class\s*\(external\)", r"^error\s*class$"],
    "decode": [r"decode\s*\(external\)", r"^decode$"],
    "description": [r"description\s*\(external\)", r"^description$"],
    "action": [r"action\s*\(external\)", r"recommended\s*action", r"^action$"],
    "action_code": [r"action\s*code"],
    "notes": [r"notes", r"comment"],
    "port_name": [r"port"]
}

def normalize_cell(value):
    if value is None:
        return None
    return str(value).strip()

def find_column_indices(row_values):
    indices = {}
    header_map = {i: str(v).lower().strip() for i, v in enumerate(row_values) if v}
    
    for target_key, patterns in COL_PATTERNS.items():
        for pattern in patterns:
            regex = re.compile(pattern)
            match_found = False
            for i, header_val in header_map.items():
                if regex.search(header_val):
                    indices[target_key] = i
                    match_found = True
                    break
            if match_found:
                break
    return indices

def extract_sheet_data(sheet):
    data = []
    header_row_idx = None
    col_indices = {}
    
    # Iterate first 20 rows to find header
    for i, row in enumerate(sheet.iter_rows(min_row=1, max_row=20, values_only=True)):
        row_values = list(row)
        indices = find_column_indices(row_values)
        if "mscod" in indices and "mcacod" in indices:
            header_row_idx = i + 1
            col_indices = indices
            break
            
    if header_row_idx is None:
        print(f"Warning: Could not find header row in sheet '{sheet.title}'", file=sys.stderr)
        return []

    for row in sheet.iter_rows(min_row=header_row_idx + 1, values_only=True):
        entry = {"sheet": sheet.title}
        has_content = False
        
        for field, idx in col_indices.items():
            if idx < len(row):
                val = normalize_cell(row[idx])
                if val:
                    entry[field] = val
                    has_content = True
        
        if not has_content:
            continue
            
        # Basic validation
        mscod = entry.get("mscod")
        mcacod = entry.get("mcacod")
        
        if not mscod and not mcacod:
            continue
            
        # Skip description-like MSCODs
        if mscod and len(mscod) > 50 and " " in mscod:
            continue
            
        data.append(entry)
            
    return data

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("excel_file", nargs="?", default=DEFAULT_EXCEL)
    args = parser.parse_args()

    input_path = Path(args.excel_file)
    if not input_path.exists():
        print(f"Error: Input file '{input_path}' not found.", file=sys.stderr)
        sys.exit(1)

    try:
        wb = load_workbook(input_path, data_only=True)
    except Exception as e:
        print(f"Error loading workbook: {e}", file=sys.stderr)
        sys.exit(1)

    all_entries = []
    print(f"Processing sheets from {input_path}...")
    
    for sheet in wb.worksheets:
        if sheet.sheet_state != 'visible':
            continue
        if sheet.title in ["Revision History", "About", "Sources", "action"]:
            continue
            
        entries = extract_sheet_data(sheet)
        if entries:
            print(f"  - {sheet.title}: Found {len(entries)} entries")
            all_entries.extend(entries)

    output_path = Path(__file__).parent / OUTPUT_JSON
    print(f"Writing {len(all_entries)} entries to {output_path}")
    
    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(all_entries, f, indent=2)

if __name__ == "__main__":
    main()
