#!/usr/bin/env python3
"""
MCA Decoder SKILL - Decode MCA status values from logs or explicit codes.

Commands:
  decode-status <status> [bank]        Decode a single MCA status value
  decode-codes <mscod> <mcacod> [bank] Decode explicit MSCOD/MCACOD values
  analyze-log <text>                   Analyze full log text for MCA status values
  help                                 Show usage information
"""

import sys

from mca_decoder import MCADecoder, parse_code_value


def cmd_decode_status(args: list[str]) -> None:
    if not args:
        print("Usage: decode-status <status> [bank]")
        print("Example: decode-status 0xB200000000050115 0")
        return

    status_value = args[0]
    bank = int(args[1]) if len(args) > 1 else None

    decoder = MCADecoder()
    decoded = decoder.decode_status(status_value, bank)
    print(decoder.format_single_decode(decoded))


def cmd_decode_codes(args: list[str]) -> None:
    if len(args) < 2:
        print("Usage: decode-codes <mscod> <mcacod> [bank]")
        print("Example: decode-codes 0x0000 0x0005 0")
        return

    mscod = parse_code_value(args[0])
    mcacod = parse_code_value(args[1])
    if mscod is None or mcacod is None:
        print("Error: invalid MSCOD/MCACOD values")
        return

    bank = int(args[2]) if len(args) > 2 else None

    decoder = MCADecoder()
    matches = decoder.decode_codes(mscod, mcacod, bank)
    decoded = {
        "status": None,
        "bank": bank,
        "mscod": mscod,
        "mcacod": mcacod,
        "matches": matches,
    }
    print(decoder.format_single_decode(decoded))


def cmd_analyze_log(args: list[str]) -> None:
    if not args:
        if not sys.stdin.isatty():
            log_text = sys.stdin.read()
        else:
            print("Usage: analyze-log <log_text_or_file_path>")
            print("Or pipe log content via stdin")
            return
    else:
        import os
        first_arg = args[0]
        # If a single argument resolves to an existing file, read it.
        # This is an intentional local-tool capability (equivalent to piping through cat).
        # A 100 MB guard prevents accidental loading of huge binary files.
        _MAX_FILE_BYTES = 100 * 1024 * 1024  # 100 MB
        if len(args) == 1 and os.path.isfile(first_arg):
            file_size = os.path.getsize(first_arg)
            if file_size > _MAX_FILE_BYTES:
                print(f"Error: file too large ({file_size // (1024*1024)} MB > 100 MB limit). "
                      "Pipe a filtered subset via stdin instead.", file=sys.stderr)
                sys.exit(1)
            with open(first_arg, "r", encoding="utf-8", errors="replace") as fh:
                log_text = fh.read()
        else:
            log_text = " ".join(args)

    decoder = MCADecoder()
    records = decoder.parse_log(log_text)
    summary = decoder.generate_summary(records)
    print(summary)


def cmd_help() -> None:
    help_text = """
# MCA Decoder SKILL

Decode MCA (Machine Check Exception) status values and map MSCOD/MCACOD
pairs to customer-facing descriptions from the DMR MCA documentation.

## Commands

### decode-status <status> [bank]
Decode a single MCA status value (MCi_STATUS).

Examples:
  decode-status 0xB200000000050115 0
  decode-status b200000000050115

### decode-codes <mscod> <mcacod> [bank]
Decode explicit MSCOD/MCACOD values.

Examples:
  decode-codes 0x0000 0x0005 0
  decode-codes 0x0813 0x0080 19

### analyze-log <text>
Analyze full log text and decode all MCA status values.

Examples:
  analyze-log "Bank 0 MCi_STATUS=0xB200000000050115"
  cat mce.log | analyze-log
"""
    print(help_text)


def main() -> None:
    if len(sys.argv) < 2:
        cmd_help()
        sys.exit(1)

    command = sys.argv[1].lower()
    args = sys.argv[2:] if len(sys.argv) > 2 else []

    if command == "decode-status":
        cmd_decode_status(args)
    elif command == "decode-codes":
        cmd_decode_codes(args)
    elif command == "analyze-log":
        cmd_analyze_log(args)
    elif command == "help":
        cmd_help()
    else:
        print(f"Unknown command: {command}")
        print("Use 'help' for usage information")
        sys.exit(1)


if __name__ == "__main__":
    main()
