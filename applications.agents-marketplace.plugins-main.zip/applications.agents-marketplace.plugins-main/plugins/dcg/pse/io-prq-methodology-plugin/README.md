# IO PRQ Methodology Plugin

An AI agent plugin for Intel Electrical Validation (EV) engineers that provides instant access to I/O Product Requirements Qualification (PRQ) methodologies, validation processes, and technical specifications from Intel's internal knowledge bases.

## Version

**1.0.0**

## Purpose

Eliminate manual wiki searches for EV engineers by providing an AI agent that queries Intel's **I/O PRQ Methodology Index wiki page** in real-time. Engineers can ask methodology questions in natural language and get accurate, cited answers directly from this single authoritative source — making validation workflow documentation instantly accessible.

**Key Feature**: This agent is intentionally limited to **one specific wiki page** to ensure all information is traceable, accurate, and from a single authoritative source maintained by the I/O PRQ methodology team.

## Target Users

- **Electrical Validation Engineers** working on I/O interface validation
- **PRQ Engineers** executing Product Requirements Qualification processes
- **Hardware Validation Teams** needing methodology documentation for IPs and interfaces
- **Signal Integrity Engineers** requiring validation process specifications

## Features

### Core Capabilities

- **Single Authoritative Source**: Queries only the [I/O PRQ Methodology Index](https://wiki.ith.intel.com/spaces/IPMWiki/pages/1589916896/I+O+PRQ+Methodology+Index) wiki page in IPMWiki space
- **Real-time Wiki Access**: Always queries live content via VeWikiTool — never cached, always current
- **Natural Language Queries**: Ask methodology questions conversationally instead of navigating wiki manually
- **Cited Responses**: All answers include direct link to the source wiki page for verification
- **Traceable Information**: Every piece of information can be verified by visiting the single source wiki page

### Knowledge Source

**Wiki Page**: I/O PRQ Methodology Index  
**URL**: https://wiki.ith.intel.com/spaces/IPMWiki/pages/1589916896/I+O+PRQ+Methodology+Index  
**Wiki Space**: IPMWiki  
**Page ID**: 1589916896

This wiki page is actively maintained by the I/O PRQ methodology team and is frequently updated with new IPs, interfaces, and validation methods.

### Supported Query Types

1. **Methodology Overview**: "What is the IO PRQ methodology for PCIe Gen5?"
2. **Validation Procedures**: "Show me the validation steps for DDR5 interfaces"
3. **Requirements Lookup**: "What are the PRQ requirements for CXL 2.0?"
4. **Topic Search**: "Does the I/O PRQ Methodology Index cover USB4 validation?"
5. **Process Details**: "Explain the signal integrity requirements in IO PRQ methodology"

**Note**: This agent only provides information from the I/O PRQ Methodology Index wiki page. For HSD tickets, hardware specifications, or other documentation, please use the appropriate tools or contact relevant teams directly.

## Prerequisites

### Required Plugin

This plugin **depends on** the [geni-plugin](https://github.com/intel-innersource/applications.agents-marketplace.plugins/tree/main/plugins/dcg/pse/geni-plugin) (version ^1.1.0), which provides:

- **Geni MCP Server** connection for accessing Intel internal knowledge bases
- **VeWikiTool** for searching Intel internal wikis (specifically IPMWiki space for this agent)

**Installation**: If `geni-plugin` is not already installed, install it from the plugins marketplace before enabling this plugin.

### System Requirements

- **VS Code** with GitHub Copilot extension
- **Intel network or VPN** connection for accessing IPMWiki content

## Installation

### From Plugins Marketplace (Recommended)

1. **Install geni-plugin** (if not already installed):
   - Open VS Code Command Palette (`Ctrl+Shift+P` / `Cmd+Shift+P`)
   - Run: `Developer: Reload Window` to ensure marketplace is registered
   - Install `geni-plugin` from the marketplace

2. **Install io-prq-methodology-plugin**:
   - Search for "io-prq-methodology-plugin" in the marketplace
   - Click "Install" or enable the plugin
   - Reload VS Code window: `Developer: Reload Window`

3. **Verify Installation**:
   - Open GitHub Copilot Chat
   - Type `@` in the chat input — you should see "IO PRQ Methodology Expert" in the agent picker
   - The plugin's custom agent is now available

### Local Development Installation

For testing or contributing:

```bash
# Clone or copy the plugin to your local agent-plugins directory
cp -r io-prq-methodology-plugin ~/.vscode/agent-plugins/local/

# Add to VS Code settings.json (User settings):
{
  "chat.pluginLocations": [
    "~/.vscode/agent-plugins/local/io-prq-methodology-plugin"
  ]
}

# Reload window
# Developer: Reload Window
```

## Usage

### First Time Using the Agent?

**Try Invoking Without a Question First!**

When you invoke the agent without a specific technical question, it provides a comprehensive introduction with:
- What the agent can do for you
- The exact knowledge source (single wiki page URL)
- Example queries to get you started
- How the agent works (5-step process)
- Prerequisites (Geni MCP server and geni-plugin)

**To see the introduction, use any of these**:
```
@IO PRQ Methodology Expert
@IO PRQ Methodology Expert hello
@IO PRQ Methodology Expert what can you do?
@IO PRQ Methodology Expert help
```

The agent will recognize these as general invocations and provide its introduction instead of querying the wiki.

### Invoking the Agent

**Method 1: Agent Picker**
1. Open GitHub Copilot Chat
2. Type `@` to open the agent picker
3. Select **"IO PRQ Methodology Expert"**
4. Ask your methodology question (or just say "hello" to see the welcome message)

**Method 2: Direct Mention** (if supported by your Copilot version)
```
@io-prq-methodology What is the DDR5 PRQ validation flow?
```

**Method 3: Set as Default Agent** (if available in your VS Code version)
1. Look for "Set Agent" or similar option in the Copilot Chat UI
2. Select **"IO PRQ Methodology Expert"** as your default agent
3. All questions will go to this agent until you switch back
   
   **Note**: This feature requires `user-invocable: true` in the agent configuration (already enabled). If you don't see this option, it may not be available in your VS Code Copilot version yet.

### Example Queries

#### Methodology Overview
```
What is the IO PRQ methodology for PCIe Gen5?
```

**Agent behavior**:
- Queries VeWikiTool for "PCIe Gen5 I/O PRQ Methodology Index"
- Searches specifically in IPMWiki space, page ID 1589916896
- Extracts PCIe Gen5 methodology information from this wiki page only
- Provides structured answer with wiki page link
- If PCIe Gen5 is not documented on the page, clearly states information is not available

#### Validation Procedure Steps
```
Show me the validation steps for DDR5 interfaces
```

**Agent behavior**:
- Queries VeWikiTool for "DDR5 I/O PRQ Methodology Index validation steps"
- Extracts DDR5 validation procedure from the wiki page
- Returns numbered steps if documented that way on the page
- Cites the I/O PRQ Methodology Index wiki page
- If detailed steps are not on the page, provides whatever information is available

#### Requirements Lookup
```
What are the PRQ requirements for CXL 2.0?
```

**Agent behavior**:
- Queries VeWikiTool for "CXL 2.0 I/O PRQ Methodology Index requirements"
- Extracts CXL 2.0 requirements from the wiki page content
- Lists requirements as documented on the page
- Always cites source: https://wiki.ith.intel.com/spaces/IPMWiki/pages/1589916896/I+O+PRQ+Methodology+Index

#### Topic Coverage Check
```
Does the I/O PRQ Methodology Index cover USB4 validation?
```

**Agent behavior**:
- Queries VeWikiTool for "USB4 I/O PRQ Methodology Index"
- Checks if USB4 is mentioned/documented on the page
- If yes: provides available USB4 methodology information
- If no: clearly states "USB4 is not currently documented on the I/O PRQ Methodology Index wiki page"

### Response Format

Responses are structured for engineer efficiency:

1. **Direct Answer**: Methodology information from the I/O PRQ Methodology Index wiki page
2. **Procedure/Steps**: Numbered validation steps when documented on the page
3. **Requirements**: Technical requirements, constraints, tools as listed on the page
4. **Source**: Always includes link to https://wiki.ith.intel.com/spaces/IPMWiki/pages/1589916896/I+O+PRQ+Methodology+Index
5. **Limitations**: If information is not on the wiki page, this is clearly stated

### Expected Output Example

**Query**: "What is the PCIe Gen5 PRQ methodology?"

**Response**:
```
## PCIe Gen5 I/O PRQ Methodology

[Information extracted from the I/O PRQ Methodology Index wiki page]

The PCIe Gen5 Product Requirements Qualification methodology covers electrical 
validation of PCIe Gen5 interfaces as documented on the I/O PRQ Methodology Index...

### Validation Process
1. **Pre-silicon simulation**: Review design specifications
2. **Post-silicon electrical validation**: Signal integrity, jitter, eye diagram
3. **Interoperability testing**: Card compatibility matrix
4. **Compliance testing**: PCIe SIG specification adherence

### Requirements
- **Signal Integrity**: Eye height ≥ XXX mV, eye width ≥ YYY ps
- **Jitter Budget**: Total jitter < ZZZ ps
- **Link Training**: Gen5 speed negotiation in < AAA ms

### Source
I/O PRQ Methodology Index: https://wiki.ith.intel.com/spaces/IPMWiki/pages/1589916896/I+O+PRQ+Methodology+Index

**Note**: All information above is from the I/O PRQ Methodology Index wiki page. 
If you need HSD tickets or hardware specifications, please use appropriate tools.
```

## Tools Leveraged

The agent uses the following Geni MCP server tool (via `geni-plugin`):

| Tool | Purpose | Usage in Agent |
|------|---------|----------------|
| **VeWikiTool** | Search Intel internal wikis | Queries the I/O PRQ Methodology Index page (ID: 1589916896) in IPMWiki space exclusively |

## Workflow Details

### How the Agent Processes Queries

1. **Query Parsing**: Extracts topic (IP/interface), intent (overview/procedure/requirements)
2. **VeWikiTool Query**: Queries the I/O PRQ Methodology Index wiki page in IPMWiki space
   - Wiki Space: IPMWiki
   - Page: I/O PRQ Methodology Index (page ID 1589916896)
   - Search terms: User's query + "I/O PRQ Methodology Index"
3. **Information Extraction**: Extracts relevant content from the wiki page only
4. **Response Synthesis**: Structures information with wiki citation
5. **Gap Acknowledgment**: If information is not on the wiki page, clearly states so

### Single-Source Philosophy

The agent is intentionally restricted to ONE wiki page:
- **Benefit**: All information is traceable to a single, authoritative source
- **Benefit**: Engineers can verify every answer by visiting the cited wiki page
- **Limitation**: Cannot answer questions beyond what's documented on this page
- **Limitation**: Does not access HSD tickets, hardware specs, or other wikis

### Always-Current Data

The agent queries the **live wiki page** every time — no caching, no stale data. If the I/O PRQ Methodology Index is updated today, the agent reflects changes immediately on the next query.

## Troubleshooting

### Agent Not Appearing in Agent Picker

**Cause**: Plugin not loaded or VS Code window not reloaded after installation

**Solution**:
1. Run `Developer: Reload Window` in VS Code Command Palette
2. Check Copilot Chat output channel for plugin load errors
3. Verify `geni-plugin` is installed (this plugin depends on it)

### Connection or Access Errors

**Cause**: Cannot access IPMWiki content

**Solution**:
1. Ensure you're on **Intel network or VPN**
2. Verify `geni-plugin` is installed and active
3. Reload VS Code window: `Developer: Reload Window`

### "IPMWiki Space Not Found" or Empty Results

**Cause**: VeWikiTool cannot access the I/O PRQ Methodology Index wiki page

**Solution**:
- Verify you're on **Intel network or VPN**
- Check authentication (reload VS Code window to refresh tokens)
- Verify the wiki page exists by visiting it manually: https://wiki.ith.intel.com/spaces/IPMWiki/pages/1589916896/I+O+PRQ+Methodology+Index
- If page is inaccessible, contact IPMWiki administrators or the I/O PRQ methodology team

### Agent Provides "Information Not Available" Response

**Cause**: The requested information is not documented on the I/O PRQ Methodology Index wiki page

**This is expected behavior**: The agent is intentionally limited to this single wiki page. If the page doesn't contain information about a specific topic, the agent will honestly report this.

**Solution**:
- Verify the topic is actually covered on the wiki page by visiting it manually
- If the topic should be documented but isn't, contact the I/O PRQ methodology team to request documentation
- For information beyond this wiki page, use other tools (HSD search, hardware spec documentation, etc.)

## Support

### Plugin Owners

- Dr. Francisco Rangel - frangel@intel.com (primary contact)
- [Add additional owners after publication]

### Upstream Dependencies

This plugin relies on:
- **geni-plugin**: orly.abramovich@intel.com, idan.matan.porat@intel.com
- **Geni MCP Server**: Hosted by Intel LAAS (Lab as a Service)
- **IPMWiki**: Maintained by Intel I/O PRQ methodology team

### Issues and Feedback

- **Plugin issues**: Contact plugin owners above
- **Geni MCP tool issues**: Contact geni-plugin owners
- **Methodology content issues**: Update the wiki directly or contact wiki space owners

## Changelog

### 1.0.0 (2026-06-12)
- Initial release
- IO PRQ Methodology Expert agent with **single-source restriction** (VeWikiTool only)
- Queries exclusively the I/O PRQ Methodology Index wiki page (IPMWiki, page ID 1589916896)
- Real-time wiki querying for always-current methodology information
- Natural language methodology queries for EV engineers
- Cited responses with direct wiki page link for traceability
- Welcome message showing agent capabilities and prerequisites
- Honest gap acknowledgment when information not available on the wiki page

## Future Enhancements (Planned)

### v1.1
- **Update notification**: Track when methodologies change since last query
- **User preferences**: Configure default IP/platform scope per engineer
- **Methodology comparison**: Side-by-side comparison of methodology versions (e.g., Gen5 vs Gen6)

### v1.2
- **GENI workspace integration**: Upload validation reports for RAG queries against both wiki + user reports
- **Automated bookmarking**: Save frequently accessed methodology pages to user memory
- **Offline caching**: Cache critical methodology pages for offline access (with staleness warnings)

## Contributing

This plugin is part of the Intel agents marketplace. To contribute:

1. **Fork** the marketplace repository
2. **Create feature branch** under `plugins/dcg/pse/io-prq-methodology-plugin/`
3. **Test locally** using local development installation method
4. **Submit PR** with:
   - Updated `plugin.json` version (semantic versioning)
   - Updated `CHANGELOG` section in this README
   - Test verification (query examples that work)
5. **Tag owners** for review

## License

MIT License — see marketplace repository for full license text.

---

**For Electrical Validation Engineers**: Stop searching wikis manually. Ask the IO PRQ Methodology Expert agent, get cited methodology answers instantly, and focus on validation execution.
