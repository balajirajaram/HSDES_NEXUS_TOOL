# mermaid

MerlinX/xMon AI Debugger (MerMAID) — expert analysis, live hardware debug, and codebase navigation for Intel bare-metal validation systems using TTK, PythonSV, XmlCli, and XMon tools.

## Version

**1.0.0**

## Agents

### 1. mermaid-debugger

**Location:** [`agents/mermaid-debugger.agent.md`](agents/mermaid-debugger.agent.md)

Hands-on hardware debugging agent for MerlinX/xMon bare-metal validation systems — executes live debug operations on a System Under Test using TTK, PythonSV, XmlCli, and XMon tools.

### 2. mermaid-orchestrator

**Location:** [`agents/mermaid-orchestrator.agent.md`](agents/mermaid-orchestrator.agent.md)

Debug workflow coordinator — triages requests, delegates live hardware operations to the mermaid-debugger agent, and loads analysis skills for interpretation.

## Skills

### 1. dragon-debugger

**Location:** [`skills/dragon-debugger/SKILL.md`](skills/dragon-debugger/SKILL.md)

Expert knowledge of Dragon bare-metal and OS-based test content — debug Dragon failures, decode VVARs, interpret thread status codes, understand seed modes/naming, and configure Dragon test parameters.

### 2. hsd-helper

**Location:** [`skills/hsd-helper/SKILL.md`](skills/hsd-helper/SKILL.md)

Interact with Intel HSD-ES (HSDES) bug tracking system via REST API — query articles, create/update bugs, execute saved queries, manage attachments, lookup field values, and trace relationships.

### 3. mermaid-analyst

**Location:** [`skills/mermaid-analyst/SKILL.md`](skills/mermaid-analyst/SKILL.md)

Expert knowledge of MerMAID — analyze, explain, and debug MerlinX issues using UML sequence diagrams and technical specifications.

### 4. mermaid-debugger

**Location:** [`skills/mermaid-debugger/SKILL.md`](skills/mermaid-debugger/SKILL.md)

Hands-on hardware debugging for MerlinX/xMon bare-metal validation systems — runs directly on the debug host with access to TTK, PythonSV, XmlCli, and XMon tools.

### 5. mermaid-developer

**Location:** [`skills/mermaid-developer/SKILL.md`](skills/mermaid-developer/SKILL.md)

BIOS project retrieval and codebase navigation for Intel Client/Server BIOS — EdkRepo clone, IFWI tracing, multi-repo navigation, and EFI binary symbol lookup.

## Installation

Installed via the marketplace. No manual installation steps required.

## Support

**Repository:** https://github.com/intel-innersource/applications.agents-marketplace.plugins

## Changelog
