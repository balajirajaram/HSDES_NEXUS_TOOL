---
name: dragon-debugger
description: "Expert knowledge of Dragon bare-metal and OS-based (DoL/TSL) test content — debug Dragon failures, decode VVARs, interpret thread status codes, understand seed modes/naming, and configure Dragon test parameters. Use this skill whenever the user mentions Dragon seeds, Dragon VVARs, Dragon thread status, Dragon error codes, Dragon bucketer, Dragon error decode, seed naming conventions, SBFT seeds, PseudoSBFT, Dragon cache modes, Dragon APIC configuration, Dragon debug flags, Dragon runtime, Dragon thread mapping, or any Dragon content execution issue under MerlinX."
---

# Dragon Debugger: Dragon Content Analysis & Debug for MerlinX

**Debug Dragon bare-metal and OS-based test failures, decode VVARs and thread status, interpret error codes, and understand seed configuration.**

## Purpose

Dragon is a self-checking bare-metal (and ring-3 OS) test suite focused on x64 IA: cores, caches, MC. It targets speedpaths (CMV/HVCP) and DPM (PPV). This skill provides expert guidance on:

1. **Failure Triage** — Decode per-thread status codes, classify failure groups, identify root causes
2. **VVAR Interpretation** — Read and configure Dragon input/output VVARs (runtime, debug flags, thread count, MCE masks)
3. **Thread Status Decode** — Map status codes to failure categories (startup, CPUID, MCE, x86 fault, test algo)
4. **Error Decode & Bucketing** — Use Dragon Error Decode and Bucketer to classify failures
5. **Seed Understanding** — Interpret seed file names, modes (M/S/L/E/R), release info, and template/variant types
6. **Configuration** — Cache modes, APIC, TSC, RelGB, P-State, thread mapping, debug flags
7. **MerlinX Integration** — Dragon content execution under MerlinX bare-metal loader

## When I Activate

Automatically when you mention:

- "dragon", "dragon seed", "dragon content", "dragon test"
- "vvar", "vvars", "vv[", "vvar[", "dragon vvar"
- "thread status", "600d600d", "0x600d600d", "aced"
- "dragon error", "error decode", "dragon bucketer", "ouroboros"
- "dragon debug", "dragon failure", "dragon hang"
- "seed mode", "seed naming", "dragon file naming"
- "pseudosbft", "pseudo sbft", "pseudo-sbft"
- "dragon cache", "cache mode", "cache per thread"
- "dragon apic", "dragon tsc", "dragon relgb", "dragon runtime"
- "dragon thread", "thread mapping", "thread lookup"
- "vvdebug", "vvoutput", "vv_debug", "vv_output"
- "dragon interrupt", "dragon gp", "dragon mce"
- "dragon pmon", "dragon config", "dragon faq"
- "dol", "tsl", "test seed loader", "dragon on linux"

## Reference Documents

All reference documents are organized as markdown under `references/` (converted from original PDFs for direct tool access).

### Overview (`references/overview/`)

| File | Description |
|---|---|
| [000_Dragon.md](references/overview/000_Dragon.md) | Main Dragon homepage — overview, focus areas, properties, seed modes |
| [03_Dragon Presentations.md](references/overview/03_Dragon%20Presentations.md) | Index of Dragon training presentations by date |
| [05_Dragon Reference.md](references/overview/05_Dragon%20Reference.md) | General links hub for Dragon documentation |
| [054_Dragon FAQ.md](references/overview/054_Dragon%20FAQ.md) | Frequently asked questions — gotchas, seed age, delivery, compatibility |
| [055_Dragon FileNaming.md](references/overview/055_Dragon%20FileNaming.md) | Seed file naming conventions decoder ring |

### Debug (`references/debug/`)

| File | Description |
|---|---|
| [01_Dragon BasicDebug.md](references/debug/01_Dragon%20BasicDebug.md) | Initial debug steps with worked Blender example |
| [011_Dragon Bucketer.md](references/debug/011_Dragon%20Bucketer.md) | Python bucketer tool — decodes thread status into failure sub-buckets |
| [012_Dragon DebugInfo.md](references/debug/012_Dragon%20DebugInfo.md) | Debug output: memory dumps, unexpected interrupts, PMON support |
| [0121_Dragon Pre2593PMON.md](references/debug/0121_Dragon%20Pre2593PMON.md) | PMON support for Dragon revisions prior to 2593 |
| [013_Dragon Error Decode.md](references/debug/013_Dragon%20Error%20Decode.md) | Web-based per-thread error code decoder |
| [0131_Updating Dragon Error Decode.md](references/debug/0131_Updating%20Dragon%20Error%20Decode.md) | How to update the Dragon Error Decode tool |
| [015_Dragon Interrupt_Table.md](references/debug/015_Dragon%20Interrupt_Table.md) | x86 interrupt vector table with Dragon-specific fault reasons |
| [016_Dragon VerticalDebugGuide.md](references/debug/016_Dragon%20VerticalDebugGuide.md) | End-to-end debug guide for vertical product teams |
| [0a5_Dragon Thread Status.md](references/debug/0a5_Dragon%20Thread%20Status.md) | Comprehensive thread status code reference (all code groups 0x0–0xF) |
| [0ae_Dragon VVDEBUG Decoder.md](references/debug/0ae_Dragon%20VVDEBUG%20Decoder.md) | VV[0x03] debug flags bit-by-bit decoder |
| [0af_Dragon VVOUTPUT Decoder.md](references/debug/0af_Dragon%20VVOUTPUT%20Decoder.md) | VV[0x0A] output flags bit-by-bit decoder |

### Configuration (`references/configuration/`)

| File | Description |
|---|---|
| [051_Dragon Cache Modes.md](references/configuration/051_Dragon%20Cache%20Modes.md) | Cache topology and mode descriptions (M, S, L, E, R) |
| [0511_Dragon Cache Per Thread.md](references/configuration/0511_Dragon%20Cache%20Per%20Thread.md) | Per-thread cache behavior, R-mode mitigations, OS apps |
| [052_Dragon Config Interactions.md](references/configuration/052_Dragon%20Config%20Interactions.md) | TP/platform configuration interactions with Dragon |
| [0521_Dragon APIC.md](references/configuration/0521_Dragon%20APIC.md) | APIC/x2APIC configuration for Dragon |
| [0522_Dragon RelGB.md](references/configuration/0522_Dragon%20RelGB.md) | Reliability guardband (RelGB) testing guidance |
| [0523_Dragon TSC.md](references/configuration/0523_Dragon%20TSC.md) | TSC time control, skew fixes, outer loop timing |
| [0551_Dragon PState Range Decoder.md](references/configuration/0551_Dragon%20PState%20Range%20Decoder.md) | P-State range bitmask decoder for seed names |

### Runtime (`references/runtime/`)

| File | Description |
|---|---|
| [0a_Dragon VVARs.md](references/runtime/0a_Dragon%20VVARs.md) | **Master VVAR reference** — all input/output VVARs with bit-level detail |
| [0a1_Dragon PseudoSBFT.md](references/runtime/0a1_Dragon%20PseudoSBFT.md) | PseudoSBFT seed usage for tester and system |
| [0a2_Dragon RunTime.md](references/runtime/0a2_Dragon%20RunTime.md) | Default run times and DR1 scaler override |
| [0a3_Dragon Thread Lookup.md](references/runtime/0a3_Dragon%20Thread%20Lookup.md) | Thread counting, symbols, indexing, and status VVARs |
| [0a4_Dragon Thread Mapping.md](references/runtime/0a4_Dragon%20Thread%20Mapping.md) | Thread ID mapping, APIC overrides, multi-socket configuration |

## Key Concepts

### What is Dragon?

Dragon is a self-checking bare-metal test suite that:
- Generates **pre-generated seeds** (~30 targeted but randomized algorithms)
- Focuses on **x64 IA**: cores, caches, memory controller
- Targets **speedpaths** (CMV/HVCP) and **DPM** (PPV)
- Runs as binary `.obj` files under MerlinX (bare-metal) or DoL/TSL (OS-based)
- Seeds loop until a minimum time limit is reached

### Seed Modes

The seed mode is the **second character** of the seed name and defines memory footprint:

| Mode | Name | Description | Tester-Portable |
|---|---|---|---|
| **M** | MLC | Fits within MLC cache | Yes |
| **S** | Small LLC | Uses a portion of LLC | Yes |
| **L** | LLC | Uses full LLC | Yes |
| **E** | ELLC | Uses read/return DFX with way protection | Yes |
| **R** | RAM | Evictions go to DDR | **No** |

Example: `DR08-DittoMT-CG-9F1001DC.obj` — mode is **R** (RAM).

### Seed File Naming

Format: `D<mode><threads>-<template>-<variant>-<release><seed_number>.obj`

Example: `DR08-Frenzy-Y-9F100289.obj`
- Mode: R (RAM)
- Threads: 08
- Template: Frenzy
- Variant: Y
- Release: 0x9F
- Seed number: 100289

### Release Types

| Type | Purpose | Seed Count |
|---|---|---|
| **CMV** | Speedpath hunting | Thousands |
| **PPV** | DPM screening (100% coverage variants: FireC, FrenzyC, LeekC) | Hundreds |
| **THR** | Test Hole Reduction — tester-portable DPM seeds | Varies |

### Dragon Execution Under MerlinX

Dragon `.obj` files are executed by MerlinX as bare-metal content:
1. MerlinX loads Dragon `.obj` into memory at the content load address
2. Dragon startup code reads VVARs, configures threads via SIPI
3. All threads execute test algorithms for the configured runtime
4. Per-thread status is written to VVARs starting at VV[0x0C]
5. BSP aggregates pass/fail status

## VVAR Reference (Quick)

VVARs start at the address in the `DataDumpAddr_VVAR` symbol. Each VVAR is a DWORD (4 bytes).

### Key Input VVARs

| VVAR | Description |
|---|---|
| `VV[0x00]` | **Test runtime** — System: microseconds (e.g., 0x2DC6C0 = 3 sec); Tester: CPU cycles |
| `VV[0x01]` | **Runtime scaling factor** — 20-bit integer, 12-bit fractional. Top bit: bus freq (set) vs CPU HFM freq (clear) |
| `VV[0x02]` | **Thread count** — Format: `SE PD RRRR`. S=start package, E=expected packages, P=generated packages, D=log2(dies/pkg), R=running threads |
| `VV[0x03]` | **Debug flags** — See Debug Flags section below |
| `VV[0x04]` | Min APIC ID to use |
| `VV[0x05]` | Max APIC ID to use |
| `VV[0x08]` | Soft MCE check mask (per bank) |
| `VV[0x09]` | Soft MCE enable mask (per bank) |
| `VV[0x0B]` | SVN revision (>= r2624, BCD encoded — read hex as decimal) |

### Key Output VVARs

| VVAR | Description |
|---|---|
| `VV[0x02]` | (output) Thread count with generated packages and dies per package |
| `VV[0x0A]` | Output flags (>= r4558) — various runtime state indicators |
| `VV[0x0C]` to `VV[0x0C + threads - 1]` | **Per-thread status codes** — 0x600D600D = pass |
| `VV[last_thread + 1]` to `VV[last_thread + 2]` | CPU cycles run during passing test |
| `VV[last_thread + 3]` | Min loop count across all threads |
| `VV[last_thread + 4]` | Max loop count across all threads |

### Memory Layout

Default VVAR base address: `0x214C` (physical/linear)
- `VV[0x0]` = address `0x214C`
- `VV[0x1]` = address `0x2150`
- `VV[0xC]` = address `0x217C` (first per-thread status)

To dump VVARs via ITP:
```
itp.halt()
itp.threads[0].memdump("0x214Cp", 40, 4)
```

## Debug Flags — VV[0x03]

| Bit | Meaning |
|---|---|
| 2 | Ignore INIT flag — don't fail if INIT occurred |
| 3 | System only: skip all WBINVDs during test |
| 5 | SKIP SIPI — single thread mode or simulation |
| 7 | PROC_SPECIFIC_DFX — set during generation, do not modify |
| 8 | NO_SNOOP — skip startup cross-thread snoops (tester SBFT) |
| 9 | DFX SIPI — set for MLC/Slice mode on tester |
| 10 | Simulation flag (Archsim) |
| 11 | Tester mode — SBFT compliant startup flow |
| 12 | JMP-SELF in tester mode (JMP $ instead of halt) |
| 15 | Counter check — verify TSC is running (not for Archsim) |
| 16 | Disable power management (C-states, P-states, turbo) |
| 17 | Disable VMX functionality |
| 18 | Skip TLA trigger (OUT 0xF8) |
| 19 | Exit immediately on any failure |
| 20 | Skip RDRAND sparks and DRNG PBIST code |
| 21 | Skip HLE and RTM sparks |
| 22 | Reduce cycle cost of certain features (pre-silicon enabling) |
| 24 | APs skip jump to end after AP_halt (SBFT loader intercept) |
| 25 | Enable CMCI — interrupt on soft MCE threshold exceeded |
| 26 | Skip end-of-test P-State restore verification |
| 27 | Disable most PagingRights usages/restrictions |
| 28 | Utilize runtime lockstep WAs (e.g., half CPM count on SRF) |

## Thread Status Codes

Per-thread status is stored starting at `VV[0x0C]`. The top nibble indicates the code group:

| Top Nibble | Group | Description |
|---|---|---|
| `0x0` | Environment-specific | `0x00000000` = BM running/timeout; `0x0000aced` = BM DR0 pass; `0x00001040` = BM test started; `0x00000000` = OS/DoL pass |
| `0x1`, `0x2` | BM Startup | Issue during BM startup/teardown |
| `0x2` | DoL/TSL | `0x22###000` to `0x27###000` = test did not start cleanly |
| `0x4`, `0x5` | Missing feature | CPUID mismatch — expected feature not enabled |
| `0x6` | Pass | `0x600D600D` = BM thread passed |
| `0x7` | Thread counting | Unexpected thread count or ID corruption |
| `0xA`, `0xB` | MCE | Machine Check Exception (bit 26: hard=1, soft=0) |
| `0xC`, `0xD` | Special/x86 fault | Special error code or unexpected interrupt |
| `0xF` | Test algo failure | Test-specific failure (data miscompare, config mismatch) |

### Critical Status Codes

| Code | Meaning |
|---|---|
| `0x600D600D` | **PASS** (BM) |
| `0x0000aced` | **PASS** (BM DR0) |
| `0x00000000` | Thread still running/hung (BM), or PASS (OS/DoL) |
| `0x48232323` / `0x5B232323` | **Patch 2/3 not enabled** — needs CR writes via ITP after reset |
| `0x4Tyyyzzz` / `0x5Txxyyzz` | **CPUID mismatch** — feature not enabled (AES, AVX, etc.). T=total missing count |
| `0xAxmmmmii` / `0xBxmmmmii` | **MCE** — mmmm=MSR number, ii=bank index. `Ax000000` = sympathetic (real failure in another thread) |
| `0xFxxxxxxx` | **Test failure** — template-specific (data miscompare, etc.) |
| `0x203b154d` | WBINVD at end of test did not complete |
| `0x10000001`–`0x10000010` | Various BM startup configuration errors (thread count, APIC, topology) |
| `0x1000000F` | TSC/ACNT not incrementing |

### Interrupt Vector Quick Reference

| Vector | Mnemonic | Dragon Speedpath Reasons |
|---|---|---|
| `0x00` | #DE | Corrupted result/data/addr on DIV/IDIV |
| `0x06` | #UD | Branched to wrong addr, code corruption, patch2/3 not enabled, instruction fused off |
| `0x07` | #NM | XFD bit set preventing state access (e.g., AMX XTILEDATA) |
| `0x08` | #DF | Double fault — took 2 errors |
| `0x0D` | #GP | General protection — see Error Decode for sub-classification |
| `0x0E` | #PF | Page fault — address corruption or paging config issue |
| `0x12` | #MC | Machine check — decode via MC bank status registers |

## Debugging Workflow

### Step 1: Gather Information

- What product/stepping?
- What seed release? (Check release notes)
- What error codes were reported and which seeds?
- Retrieve VVARs: either from log file or via ITP memory dump at `0x214C`

### Step 2: Decode Thread Status

1. Find failing threads: `VV[0x0C]` through `VV[0x0C + num_threads - 1]`
2. Check `VV[0x02]` for thread count (low 16 bits = running threads)
3. Use top nibble to classify the failure group
4. For `0xF` codes: identify the template from the seed name, look up template-specific error codes
5. For MCE (`0xA`/`0xB`): check if sympathetic (`Ax000000`), find the real failing thread

### Step 3: Use Debug Tools

| Tool | Purpose |
|---|---|
| **Dragon Error Decode** (web) | Full decode of a single error code |
| **Dragon Bucketer** (Python) | Batch decode into failure sub-buckets |
| **Ouroboros** (Windows app) | Consume bulk logs into tables and graphs |
| **DANTA** | PPV Server Dragon VVARs charting and bucketing |

### Step 4: Classify and Escalate

Determine if the failure is:
- **Speedpath** — `0xF` test failure under stressed conditions, passes relaxed
- **Logic bug** — reproducible across conditions
- **Configuration issue** — patch2/3 not enabled, CPUID feature missing, thread count wrong
- **MCE** — hardware machine check, decode MC bank status registers
- **Infrastructure** — WBINVD timeout, SIPI issues, thread mapping errors

### Step 5: Triage with MerlinX Debugger

Use **mermaid-debugger** for live SUT operations:

| Action | Tool |
|---|---|
| Read Dragon VVARs from memory | `read_memory(0x214C, 160)` — 40 DWORDs |
| Check specific thread status | `read_memory(0x217C + thread_idx * 4, 4)` |
| Read Dragon debug flags | `read_memory(0x2158, 4)` — VV[0x03] |
| Check if Dragon is still running | `get_postcode()` + check VV[0x0C] for `0x00000000` |
| Decode MCE registers | `read_cpu_registers(thread_index)` → check MCi_STATUS/MCi_ADDR |
| Verify patch2/3 status | `check_patch23()` or `is_unlocked()` |
| Read Dragon SVN revision | `read_memory(0x2178, 4)` — VV[0x0B], BCD encoded |

### Worked Example: Blender Seed Failure

**Seed:** `DRG-R20-Blender-SY-39200041`, **Error:** `VV[0x17] = 0xF0000F01`

1. Release = 0x39 (from seed number), mode = R20 (RAM, 32 threads = DP)
2. Per-thread status starts at VV[0x0C]; VV[0x17] = thread 11 (0x17 - 0x0C = 0x0B = 11)
3. Top nibble `0xF` = test algo failure
4. Look up `.csv` file for thread 11 → FRM-MMulHSY algorithm
5. FRM error code `F0000F01` = test failure with QWORD 1 miscomparing
6. This is a data miscompare under stress → likely speedpath
7. Repeat under relaxed conditions — if passes, confirms speedpath

## Dragon Modes of Execution

### Bare-Metal (BM)

- Executed by MerlinX as content `.obj` files
- BSP sends SIPI to wake APs
- All threads run test algorithms
- Status in VVARs at physical address `0x214C`
- Pass = `0x600D600D`, tester DR0 pass = `0x0000aced`

### DoL/TSL (Dragon on Linux / Test Seed Loader)

- Same algorithms as BM with minor limitations, running under Linux/Windows
- Failure log includes per-thread FailMask in console/YAML output
- Status `0x00000000` = pass (OS convention), non-zero = fail
- `0x22###000` to `0x27###000` = test did not start cleanly

### PseudoSBFT

For tester portability of DPM-catching seeds:
- Clear tester flags, adjust runtime to system runtime
- Core products: run on the specific failing core
- SLM/AMT/GLM: seeds target random module, full coverage across release

## Cache Modes and Thread Configuration

### Cache Topology (`Core_Topo`)

`Core_Topo` describes thread-to-core/module/cache mapping for Atom and BigCore. Seeds are pre-generated with all cache assignments. Key modes:

- **Shared**: all threads share full cache
- **Per-thread**: each thread gets a partition
- **R-mode mitigations**: special handling for RAM-mode cache pressure

### APIC Configuration

- Dragon uses x2APIC for interrupt send/receive
- Product architectural x2APIC must be enabled
- VV[0x04]/VV[0x05] control Min/Max APIC ID range
- Thread mapping controlled via VV[0x02] and APIC VVARs

### TSC and Timing

- Dragon uses core ticks as per-thread time control
- Minimum time check at outer loop only
- TSC skew can cause threads to run for different durations
- `VV[0x03]` bit 15 enables TSC running verification

## Integration with MerMAID Skills

### From mermaid-analyst

When analyzing Dragon failures in serial logs or boot sequences:
1. Identify the Dragon content load phase in the boot flow
2. Check POST codes for Dragon execution status
3. Use this skill's VVAR decode to interpret failure codes from logs
4. Refer to thread status code tables for classification

### From mermaid-debugger

When performing live debug of Dragon failures:
1. Use `read_memory()` to dump VVARs directly from the SUT
2. Use `read_cpu_registers()` to check MCE bank status for `0xA`/`0xB` codes
3. Use `check_patch23()` for `0x48232323` patch2/3 failures
4. Use `read_asm_instructions()` to analyze `#UD`/`#GP` faulting opcodes
5. Use `is_unlocked()` to verify debug prerequisites

## Limitations

- Error codes are context-sensitive and may vary by SVN revision — always check VV[0x0B] for the correct VVAR version
- Dragon does not clearly expose what algorithms are running without consulting `.csv` seed info files
- Old seeds (> 3 months) may lack features; always verify with Dragon team for new steppings
- PDF references contain the authoritative detail (now converted to markdown under `references/` for direct tool access); this SKILL.md provides navigation and quick lookup

## Related Skills

- **mermaid-analyst** — For analyzing MerlinX boot flows, sequence diagrams, and log classification where Dragon content is being executed
- **mermaid-debugger** — For live hardware debug operations on the SUT (read VVARs via DCI, check MCE registers, verify patch status)
- **mermaid-developer** — For generating Mermaid diagrams that visualize Dragon execution flows
