# Dragon Cache Per Thread

> Source: 0511_Dragon Cache Per Thread.pdf

1 Basics
2 Additional Complexities
3 Guidelines
4 R Mode Under Exceed Mitigations
5 OS Apps
6 Incoming links
7 Contributors
Basics
Dragon seeds are pre-generated with all their data and addresses, and thus cannot dynamically fully adapt to certain changes in topology; such as major deltas in cache per thread/core/module.
Each thread in a Dragon seed uses a portion of the total seed dataspace (and some threads may share a portion of the dataspace).
If the thread isn't running, it isn't using its portion of the dataspace.
Fitting in vs exceeding particular caches defines whether many behaviors and HW are actually tested (and stressed) or not.
Leveraging the precise test configuration across QDFs is critical to screening effectiveness and cost/TTM.
In the past (SKX/CLX/CPX), Dragon tried generating separate seeds for different cache-per-thread topologies.
This was a mess for all teams and usages (Dragon, PPV/etc, TTR/THR).
Extra work, extra storage, wrong seeds used on wrong parts (silently deviating testing anyway), TTR/THR debug and closure complexities, etc.
Thus if the cache per thread/core/module differs greatly from how the obj was generated:
The 
 intents may no longer be fully (or even minimally) attained on some or all of the seeds.
Dragon Cache Modes
Too much cache per thread can prevent the seed from exceeding (or filling) an intended cache level (and thus limit coverage and stress for flows/interconnects/IPs at and above that level).
Too little cache per thread can cause the seed to exceed an unintended cache level (and thus limit coverage and stress for flows/interconnects/IPs at and below that level).
Additional Complexities
Dragon seeds built for a given topology and 
 share the same overall size target.
Dragon Cache Modes
But the actual generation of each seed randomizes the exact size and addresses that any specific usage receives.
It does so in a "fairly" slightly 
fair fashion; vaguely along the lines of some 
 algorithms, but valuing variation (within and across seeds) more than precise equity.
un
fair division
And certain Dragon algos have more constraints on dataspace size that others (large minimums, pow2, multiple chunks, etc).
And some cases, notably E/R seeds, are allowed to exceed the target, and some R (*C "complete" algos, etc) have a larger target.
Combining: Dragon generation complexities, Dragon bundles, hash/set/way fit, threads grouped together into cores/modules/LLCs/packages, and threads sharing dataspaces:
The range and probability of cache fit is variable and difficult to determine, especially across a range of topologies.
Thus the optimal range for full test behavior (quality) needs a buffer on both min and max generation vs operation range.
While it is possible to build R seeds slightly or even 
 bigger as a WA to "guarantee" exceeding LLC regardless of config, this is generally worse behavior overall.
much
The seeds end up much bigger.
This increases test cost (slightly) at PPV due increased load overhead on both BM Dragon and TSL Dragon; and in some cases longer minimum test time to iterate the extra data.
And this increases total storage size of both BM and TSL Dragon for TP and silo and customers.
TSL release size has long been the #1 TSL customer usage complaint, is already much worse for new products (much bigger caches), and this would make it yet worse.
Even much larger (3-4x target instead of 2x target) still only slightly increases the max range, still leaving a constraint or (silently) exposed SKUs.
Many seeds would then overflow caches 
and not ride the hit/miss boundary.
too much 
This introduces a new (silent) exposure on more normal SKUs.
Products and SKUs/customers have competing goals for cache sizes and agent counts.
Cache per thread, low thread but high cache, cache vs prior gen or competitors, etc.
Some WLs are very sensitive to certain minimum cache size thresholds.
Outstanding miss queues (distributed across cache agents) to maintain high mem BW utilization.
Marketing segmentation and waterfall prevention.
Products have constraints on cache agent enable/disable.
The tester and TSL objs include the full test address and dataspace in the obj.
BM system objs typically do 
 include all used addresses.
not
Write-first data is typically not included.
LittleFoot uses the multi-cast 
 to include 1 copy of the bundle data, and have the loader write it multiple address ranges (in the multi-cast record).
obj-ext
Guidelines
In general, Dragon usage naturally scales regardless of the # of running modules, 
:
so long as
The threads per core and cores per module match generation.
The L2 set/way=size per module matches generation.
The (L3 cache / module count) matches within a narrow range of generation.
In certain cases, as advised by the Dragon team, deviation may be acceptable.
e.g. HWLS for pure core/L1, certain debug/characterization, failures not sensitive to the cache mode behavior, etc
Fit cache modes (optimal intent):
M: L2 set/way=size per module should not be less than generated target.
Q from MLC: L2 set/way=size per module should not be less than generated target.
L: L3 Slice set/way=size per module should not be less than generated target, and the (LLC Slice count / module count) should not be less than generated target %.
Mixed cache modes (optimal intent):
S: L2 set/way=size per module should not be more than generated target.
Q from LLC: L2 set/way=size per module should not differ from generated target.
Dragon uses an L2 waymask, which can be overridden in vvars.  In some cases, "fixing" the waymask can maintain the intent.
H: L2 set/way=size per module should not be much more than generated target. <= ~1.25x.
L3 Slice set/way=size per module should not be much less than generated target, and the (LLC Slice count / module count) should not be much less than generated target %.  >= ~0.75x.
Exceed cache modes:
R (optimal intent):
This seeks to maintain optimal intent for nearly all R seeds, and where most include a mix of hits and misses (which is definitionally a narrow mathematical range).
average total used dataspace should [1.5x, 2.25x] cacheable size (which makes normal R seeds ~[1.25x - 2.5x] when using a nominal 2x target size).
Server 
: PP0 LLC Slices / PP0 modules = [0.75x, 1.5x]
approximation
This assumes the baseline is 1 LLC Slice per module and L2/L3 within ~2x of each other, and was applied from ICX-SP to GNR and SNR to (mostly) CWF.
ICX-D was special with roughly 2 modules per Slice in HW.
PPV/etc tests in PP0.  Sometimes the 
 from the customer (using soft-SKU infrastructure), but PPV/etc fuse overrides back on (does not require external soft-SKU 
SST-PP0 was hidden
enabling).
The 0.75x floor is to prevent over-exceeding, and to prevent H seeds from exceeding.
Client Si: In addition to Slice disable, Client does fuse way disables (though mostly for marketing segmentation) and Dragon syncs with marketing to maintain the expected avg sizes (min and max).
R (minimal intent):
This seeks to maintain optimal intent only on the largest R seeds, and depend on 
 and more optimally tested SKUs for overall quality targets.
mitigations
average big R total used dataspace should [1.5x, 2.25x] cacheable size (which makes normal R seeds ~[0.625x - 1.25x] when using a nominal 2x target size).
Server 
: PP0 LLC Slices / PP0 modules = [0.75x, 3x]
approximation
This assumes the baseline is 1 LLC Slice per module and L2/L3 within ~2x of each other, and is planned to be applied on DMR/DMR-HD and forward.
CWF PO-ES2 was also allowed up to 2.25x (to help yields and perf targets, and volume was low and max quality wasn't needed pre-production), and QS/PRQ TBD but may be 
allowed as well (mitigations and shifting goal mix).
Options and mitigation for DMR reviewed with Luis Rojas (Server PPV).
PPV/etc tests in PP0.  Sometimes the 
 from the customer (using soft-SKU infrastructure), but PPV/etc fuse overrides back on (does not require external soft-SKU 
SST-PP0 was hidden
enabling).
The 0.75x floor is to prevent over-exceeding, and to prevent H seeds from exceeding.
Client Si:
hybrid: asymmetric thread-per-module (TPM) and L2 sizes, plus bundle complexities (esp with Atom_LP).
On regular R seeds, one core type typically only slightly exceeds L2 while another typically greatly exceeds L2.  Mostly works out at LLC level, but overall perf profile is outside 
nominal range.
NVL: Dragon sizing LLC generation to avg(3 MB LLC, 12 MB bLLC)=7.5MB regardless of regular vs bLLC.
Normal R over exceeds on regular LLC and only slightly exceeds on full bLLC.
Big R greatly over exceeds on regular LLC and at the top of the optimal range on full bLLC.
R Mode Under Exceed Mitigations
big R seeds: Some Dragon seeds (*C "complete" algos, most EveGoogle) are much bigger and still fill LLC up to 4x Slice:module (up to 3x for optimal range overflow).
Some BM Dragon seeds have wbinvd (flushes cache to mem).
Some Dragon and non-Dragon have NT (goes direct to/from mem) or clflush/clwb (pushes to mem).
TSL Dragon quest (100-250ms) runs seeds very short.  Across seeds there is fast and frequent full LLC/MC (though with much less SDE checking and less hit/miss mix).
OS boot and testing, see below.
OS Apps
Aside from Dragon, PPV/HVCP/CMV OS boot itself and some OS apps.
Note SS/iMunch mostly use 
 datasets.
small
Memory Latency Checker (MLC)  properly configured to adjust for relative LLC.
if
Properly configured MLC has proven effective at Server LLC/MC DPM and certain marginalities.
Ocelot LOS-25WW41 and WOS-25ww50 GUPs/MLC release: now dynamically calculates data space size at runtime, based on enabled threads and associated caches.  In now scales automatically for: extreme off-
axis SKUs, enabled threads per module, off-lined threads, etc.  TODO: WOS release.
GUPs_L2 targets (sumL2).
MLC_Cache targets 90% (sumL2+sumL3).
MLC_Mem targets 2x (sumL2 + L3).
GUPs_Mem targets Pow2LE(2x (sumL2 + L3)).
Possibly some commercial apps such as linpack/mprime/stream may go to memory (or at least LLC).
Incoming links
 
Page: Dragon Cache Modes
 
Page: Dragon Config Interactions
 
Page: Dragon Diamond Rapids - DMR
 
Page: Dragon Nova Lake - NVL
 
Page: System Test Content Receiveables
Contributors
User
Edits
Comments
Labels
Valentine, Joshua H 
5
0
0
