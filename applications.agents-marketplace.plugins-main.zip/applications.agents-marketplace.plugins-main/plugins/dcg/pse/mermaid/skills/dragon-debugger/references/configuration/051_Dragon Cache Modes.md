# Dragon Cache Modes

> Source: 051_Dragon Cache Modes.pdf

1 Topo
2 Descriptions
3 Groupings
4 Modern System Usage
5 Incoming links
6 Contributors
Topo
Core_Topo describes thread to core/module/cache for Atom and BigCore.
Dragon seeds are pre-generated, the below behaviors occur when the cache-per-thread is matched (or very close) to the generated targets.
See 
 for the details on the ways to maintain the relationships, and the tradeoffs as the deviations increase.
Dragon Cache Per Thread
Descriptions
R - RAM: These seeds are twice the size of the cacheable space in the CPU to force lots of traffic between cache and RAM and the paths in between in order to test them.  Note that it is sized to the DUT(s), not the 
sum of sockets.
System only
Inclusive LLC: 2x LLCs
Non-inclusive LLC aka NI$: 2x (LLCs + L2s)
L2 only: 2x L2s
E - Exceeds cache: Generally built for tester only.  Uses read-return, way locking, and (in some configs) EDRAM to approximate R mode.
Tester "only"
Limited content and coverage as it rarely can perform data integrity check except MCEs.
H - Hybrid mode: Targeted to fit in NI$ caches while still reasonably exceeding MLC/L2 caches.  Targeted at core+L1+L2 and some L3.
System only
Replaces S mode on system for NI$ products.  Also replaces SKX system L seeds.
Seed size is the larger cache + 1/2 the smaller cache.
L - LLC/L3: size of LLC less any reserved ways.  Not commonly used except on SKX or sometimes tester.
System or tester, though large for tester
Server MOSBFT uses broadcast load in MOSBFT/FCSBFT which means only a single LLC Slice worth of data can be loaded instead of the sum of LLCs.
This massively restricts the dataset available and makes getting past the L2 exceedingly rare aside from cross-core sharing tests.
Usually R is used to test LLC and H/S to test the core+L1+L2.  But sometimes L is used as a stand-in for one or both.
SKX system used this in place of S mode due to the cache sizes.  But that usage has been super-ceded by H mode starting with CLX.
Q - "cQOS": Uses cQOS or DFX to reduce the MLC/L2 size to enable L2/L3 transactions in reasonable seed sizes.
Intended for tester only though system is theoretical possible.
Replaces S mode on tester for NI$ products, first use targeted at SNR.
Seed sized to 1/2 the LLC/L3 with expectation that MLC/L2 is artificially reduced to ~1/4 the seed size.
Desire is for different seeds/patterns to use different sub-sets of the MLC/L2 ways.
S - Small LLC: Sized to 2x the MLC/L2.  Targeted at core+L1+L2 and some L3.
System or Tester
For products with an inclusive LLC/L3.  This is super-ceded by Q mode on NI$ products.
SKX/CLX/CPX/ACF, ICX exception:
Tester overrode the MLC/L2 size from 1 MB back down to the legacy 256K to enable the traditional L2/L3 transactions w/o large seeds.  Thus traditional 512KB S seeds are provided.
M - MLC/L2: Sized to the MLC/L2.  Targeted at core+L1 and some L2.  Generally only used for products w/o LLC/L3, or (>= r7815, June'24) products with very large L2 and L3.
System or Tester
Less L2/IDI/coherency coverage than any other mode.  But least latency and uncore power; and tighter focus on core/L1.
See also: Dragon Testing Improvements - 2024 - r7815
Groupings
System: R, H, L, S, M
Tester: E, L, Q, S, M
Has LLC/L3
Inclusive: R, L, S
NI$: R, H, Q, (M >= r7815, June'24)
No LLC/L3
R, M
Modern System Usage
SKUs with NI$ LLC
core/L1/L2/IDI:
Primary: H
Secondary: (M >= r7815, June'24)
For PPVm/breadth this is considered "bonus", not part of the "required" minimum search list.  But seeds may be promoted based on program data or sensitivity.
Mainly intended for returns/rejects/debug/THR/CMV, to focus more heavily within the core module.
Secondary: R
There are some core behaviors, such as NT, that bypass caches.  Also, the extra code/data space provides additional randomization scope.
L3/ring/mesh/D2D/MSC:
Primary: R
Secondary: H
MC: R
Server: Multi-level memory: special R (non-DRAM)
Server: UPI/UXI multi-socket: special R Blender-*K
SKUs without NI$ LLC (e.g WCL 0+0+2)
core/L1/L2/IDI:
Primary: M
Secondary: R
There are some core behaviors, such as NT, that bypass caches.  Also, the extra code/data space provides additional randomization scope.
MSC: R
MC: R
Incoming links
 
Page: [ARL][FUN][CORE] 1.1 Content overview
 
Page: [MTL][FUN][CORE] 1.1 Content overview
 
Page: Dragon - IPTS
 
Page: Dragon 2018Release0x5D
 
Page: Dragon 2018Release0x5F
 
Page: Dragon 2024Release0x3F
 
Page: Dragon 2024Release0x40
 
Page: Dragon 2024Release0x41
 
Page: Dragon 2024Release0x42
 
Page: Dragon 2024Release0x44
 
Page: Dragon 2024Release0x4F
 
Page: Dragon 2025Release0x57
 
Page: Dragon 2025Release0x5A
 
Page: Dragon 2025Release0x5B
 
Page: Dragon 2025Release0x5C
 
Page: Dragon 2025Release0x5E
 
Page: Dragon 2025Release0x5F
 
Page: Dragon 2025Release0x63
 
Page: Dragon 2025Release0x64
 
Page: Dragon Cache Per Thread
 
Page: Dragon Content Mode Definition
 
Page: Dragon Diamond Rapids - DMR
 
Page: Dragon DoL Cross Product Usage
 
Page: Dragon DoL Seed Rotation
 
Page: Dragon FileNaming
 
Page: Dragon Nova Lake - NVL
 
Page: Dragon Reference
 
Page: Dragon RelGB
 
Page: Dragon Testing Improvements
 
Page: IA - Uncore - IPTS
Contributors
User
Edits
Comments
Labels
Valentine, Joshua H 
71
0
0
Porter, Benjamin M
1
0
0
Nunez, Katherine
0
0
1
