# Dragon APIC

> Source: 0521_Dragon APIC.pdf

1 Overview
2 Product Architectural x2APIC
3 Dragon x2APIC
4 Incoming links
5 Contributors
Overview
Advanced Programmable Interrupt Controller (APIC)
Used to send/receive interrupts with x86 threads.
Each thread has a unqiue APIC_ID.
APIC_ID bits are used to segment various topology boundaries (core/module/logical_die/logical_pkg, caches).
May not be contiguous, may not include ID 0.
BSP is typically the lowest APIC_ID, but not always (especially in hybrid core type products).
xAPIC
initial version, sometimes called x1APIC
MMIO based access
8-bit APIC_ID
x2APIC
later version (intro IVB?)
MSR based access
32-bit APIC_ID
Dragon
Used by BM Dragon (except iso-SBFT) to #SIPI all threads at the start of the test.
Used by BM System Dragon to #NMI all threads at end of passing test to coordinate wbinvd.
Used by BM System Dragon to #NMI threads to control Dragon PM requests.
Used by BM Dragon (except iso-SBFT) in 
 to aggress APIC issues (but does not actually take the int, and performs APIC reset to clear).
Eclipse
Product Architectural x2APIC
Product architectural x2APIC (physically no longer has xAPIC support).
Starting:
Client: NVL (PNC, ARW)
Server: DMR (PNC), DMR-HD/PMR (ARW)
arch x2APIC defines a 
 to clean the APIC state: patch3 cmd leaf 0x11, which requires patch2/3 enabled and the part unlocked.
standardized DFX mechanism
Dragon is arch x2APIC aware, but 
 test still needs to clean APIC state.  And Dragon recommends to use MerlinX to clean APIC state between Dragon seeds as well.
Eclipse
MerlinX usage:
Added in MerlinX release v8.20, fixes in 8.22.
In OTL mode (platform agnostic, command line mode):
new command line parameter (-x2ar) to insert an x2Apic reset between tests.
In CLI mode (boot directly to F6, platform-aware, no command line):
x2Apic reset is coded into the platform API in NovaLakePlatformDriver.
Dragon x2APIC
x2APIC loader support starting with these products (Dragon will transition to and exit in x2APIC, regardless if starting point is xAPIC)
Atom Devices: LKF, EHL/JSL
Atom uServer: GRR/SRF (APIC lockdown mid-late BKC), SNR
BigCore Client: ARL/LNL (APIC lockdown mid-late BKC), ADL
BigCore Server: ICX-SP (APIC lockdown late BKC)
Product APIC lockdown prevents resetting APIC state, but 
 (and MerlinX?) still needs to clean APIC state.
Eclipse
Prior 
, often requires a core stepping specific DFX WA to re-allow APIC reset.
Product Architectural x2APIC
Sometimes wasn't locked down in earlier steps, sometimes magic # sometimes moved or changed.
Use 
 or similar at the start of the Dragon node.
ulx.efi
ULX manager: Mark A Warye Jr
Incoming links
 
Page: Dragon 2025Release0x56
 
Page: Dragon 2025Release0x57
 
Page: Dragon 2025Release0x5A
 
Page: Dragon 2025Release0x5B
 
Page: Dragon 2025Release0x5D
 
Page: Dragon 2025Release0x5E
 
Page: Dragon 2025Release0x5F
 
Page: Dragon 2025Release0x63
 
Page: Dragon 2025Release0x64
 
Page: Dragon Diamond Rapids - DMR
 
Page: Dragon EclipseTest
 
Page: Dragon Nova Lake - NVL
 
Page: System Test Content Receiveables
Contributors
User
Edits
Comments
Labels
Valentine, Joshua H 
4
0
0
