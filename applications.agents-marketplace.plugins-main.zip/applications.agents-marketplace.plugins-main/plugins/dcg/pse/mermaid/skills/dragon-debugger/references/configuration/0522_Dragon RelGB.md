# Dragon RelGB

> Source: 0522_Dragon RelGB.pdf

1 Overview
2 Testing
2.1 Dragon Guidance
3 Incoming links
Overview
Reliability guardband (RelGB) is additional voltage beyond the nominally working setpoint, added to mitigate certain issues.
This is added because Si circuits degrade slightly during use (esp at high voltage and heat).
The GB mitigates against excessive product failure before (and often beyond) warrantied end of life (EOL).
For stuck-at (S@) defects, this is irrelevant, and testing with or without RelGB yields the same screening.
For "at-speed" (@S) defects tested at "time 0", this is basically "free" additional operating margin.  And thus it 
 issues with a slightly insufficient nominal setpoint (wholly or intermittently).
hides
resistive defects (these can actually be "worse" at 
 speed, relative to other issues), these are a common modal defect with multi-patterning Si processes.  And Intel 14nm/10nm (incl Intel 7 aka 10nm+++) 
low
are very exposed to these.
speedpaths and other marginalities (which can occur sensitively at 
 speed).
any
But certain types of issues actually only occur at 
voltages (voltage ceilings) and it's related effects (power/thermal/droop/ICC and di/dt impacts).
higher 
Esp issues with ratio grant, and anything related to "max" trips, as well as di/dt swing magnitude
Testing
Thus the 
Mfg defect testing (esp PPV) should be performed with this RelGB 
.
majority 
removed
But certain cases, while perhaps also useful with RelGB removed, 
 
be performed with RelGB 
.
must also 
included
There may be others, but the Dragon specific ones are listed below.
In 
to these general guidelines, product specific analysis and debug may yield specific combinations of (content, conditions, configuration) that need run.
addition 
Dragon Guidance
The general Dragon Guidance is to "split the difference".
Run 
 Dragon with RelGB 
.
TSL/DoL
removed
As part of overall "SHC" content run.
Run 
Dragon with RelGB 
.  This has uniquely exposed issues (vs RelGB removed).
BM 
included
This can be 
 run with RelGB 
.  This has uniquely exposed issues as well (vs RelGB included).
additionaly
removed
If there is need/indication to run 
 Dragon with RelGB 
, and unresolvable TT issues with running that 
...
BM
removed
in addition
The following tests (if applicable to the product) 
 be in a RelGB 
 run.  Any filename containing:
must also
included
Sanity
Specifically the PM grant verification ones (CST, PST, TF, TRB, UFS, etc), but should do all.  It’s short and speeds enabling/debug by making sure the node is matching configuration 
expectations.
Charyb
non-AMX PV
Scylla
non-AMX PDV
1
-V
CayleyO
AMX PV
Cayley-W
AMX PDV
Loki
Setpoint and WL bouncing
It is additionally advisable to have at least seeds of some other algos (esp: Ditto, Fireworx, Frenzy, LeekSpin, Yakko) in a RelGB 
 run.
included
Randomizations of these have been repeatedly found to trip various "max" limits.
Thus the general guidance of having 
 BM Dragon in a RelGB 
 run.
all
included
If splitting part of a BM Dragon release between RelGB included and RelGB removed (beyond the above listing which applies to all Dragon modes):
Guesstimate: Use non-R (H/L/S/M) in RelGB 
 and R in RelGB 
.
removed
included
Dragon Cache Modes
R mode brings the MC into play, but has 
 stress on the core.
lower
CLM stress is a toss-up between the R and non-R, different tradeoffs.  
Incoming links
 
Page: Dragon DoL PPV and CMV Usage
