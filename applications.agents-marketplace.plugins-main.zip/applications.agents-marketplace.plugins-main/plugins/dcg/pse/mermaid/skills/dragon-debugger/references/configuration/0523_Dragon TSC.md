# Dragon TSC

> Source: 0523_Dragon TSC.pdf

1 Overview
2 TSC Skew System Fix
3 Incoming links
4 Contributors
Overview
Dragon uses core ticks as its per-thread 
time control mechanism.
minimum 
Time check is only performed at outer loop boundaries.
As a consequence: If the thread checks the time very shortly before it reaches the target time, the thread will still go for another whole loop.
Time to perform the first loop (time target = 0) is the minimum time.
Note a very few algos force more than one loop before time check.
Note a very few algos (mostly some Sanity) do not loop.
"core ticks"
For BM System, TSL, FC/MO/RO SBFT, and some Slice/MLC SBFT: MSR TSC/IA32_TIME_STAMP_COUNTER/0x10
Read with rdtsc.
Advances at core max P1 frequency.
For some Slice/MLC SBFT: MSR ACNT/IA32_APERF/0xE8
Because TSC isn't accessible in isolation SBFT.
Still called Sanity_TSC, but actually uses ACNT not TSC.
Read with rdmsr.
Advances at current core frequency.
All BM Dragon
Writes the core tick counter to 
 tick target at the start of the test.
negative
All OS Dragon
Reads the current core tick counter, adds the tick target, and stores that to a mem address.
MerlinX
06/27/25: Reviewed MerlinX core tick counter with Jaycn Holden and Jeff Hoag.  No further material impact.
No writes (incl no save/restore).
No strict reads, though debug time prints (TSC) could be "wonky" with unfixed BM Dragon seeds in some circumstances.
core tick counters:
MSR 0x10: IA32_TIME_STAMP_COUNTER (aka TSC)
Writes to this MSR actually write the delta to IA32_TSC_ADJUST, not internal TSC itself.
Can also be read with rdtsc/rdtscp
MSR 0x3B: IA32_TSC_ADJUST
Writing this to 0 actually undoes writes to IA32_TIME_STAMP_COUNTER
MSR 0xE7 IA32_MPERF (aka MCNT)
MSR 0xE8 IA32_APERF (aka ACNT)
TSC Skew System Fix
>= r8142 "BUGFIX": BM Dragon writes TSC/IA32_TIME_STAMP_COUNTER/0x10 at start of test, and now writes IA32_TSC_ADJUST/0x3B=0 at end of test (added to existing system ACNT/MCNT=0 
"fixup").
For seeds < r8142, WA in TP.
Use an EFI app (Jaycn WIP) or PythonSV to do the same write after the BM Dragon nodes.
Note system reset will also clear this.
Dragon system (and some SBFT) writes IA32_TIME_STAMP_COUNTER/0x10 to a large negative value (crossing 0 is minimum time target for looping seeds), which actually writes IA32_TSC_ADJUST/0x3B with 
the delta.
Since the writes to TSC occur at different times on different threads, this introduces skew between the threads (which OS tends not to like).
This can accumulate across seeds.
If there is no reset between BM Dragon and something else (like OS), this can cause issues.  Thus the need to fixup (in seed or TP).
GNR TSL shared (FX/PE/SR) algos, intermittent "timeout" on a shared thread due to mismatch TSC vs Dragon target from other thread: HSD 14024838830: [GNR][2S][SP][AP] 10% of retest triggered by 
intermittent TSL failure in all chops
So clear the TSC delta from all threads by writing IA32_TSC_ADJUST/0x3B to 0, which also restores the TSC consistency across threads.  SDM Vol 3 Time-Stamp Counter Adjustment (TSC/etc Chapter).
This also means Dragon now exits with TSC advanced normally, instead of being "reset" on each Dragon seed.
Incoming links
 
Page: Dragon 2023Release0x09
 
Page: Dragon 2023Release0x0E
 
Page: Dragon 2023Release0x13
 
Page: Dragon 2023Release0x18
 
Page: Dragon 2023Release0x22
 
Page: Dragon 2023Release0x25
 
Page: Dragon 2023Release0x26
 
Page: Dragon 2024Release0x43
 
Page: Dragon 2024Release0x4D
 
Page: Dragon 2025Release0x57
 
Page: Dragon Nova Lake - NVL
 
Page: Dragon ReleaseNotes
 
Page: System Test Content Receiveables
Contributors
User
Edits
Comments
Labels
Valentine, Joshua H 
3
0
0
