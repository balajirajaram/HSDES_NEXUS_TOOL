# Dragon Config Interactions

> Source: 052_Dragon Config Interactions.pdf

1 Overview
2 Buslock Performance
3 Incoming links
4 Contributors
Overview
Page tree for TP/etc configuration interactions with Dragon.
   
Expand all
Collapse all
Items in other page trees:
Dragon Cache Per Thread
Dragon Clustering
DMR Fused 1-CPM
And hopefully future...
Buslock Performance
Since late in ICX Server and ADL Client, default IFWI/BKC deliberately jam ubox lock delay to the max.  Massively degrading the performance of splitlocks/buslocks (this is tradeoff vs their impact on the system).
As Dragon is actually trying to test these aggressively, this massively impacts the runtime and effectiveness of some Dragon algos.
Some Flipper (and Blender with Flipper) seeds that randomize splitlocks on.
In newer releases, "buslocks" is listed in the "Coherency" column in the CMV*.csv/PPV*.csv files in the Dragon release info folder.
To WA this tradeoff, Mfg (PPV/CMV/HVCP) must override the default setting (as we've been doing since ICX).
BM Dragon:
DMR/PMR: sv.sockets.imhs.ubox.ncevents.lockcontrol_cfg.lockdelay = 0x1
GNR/SRF/CWF/GRR, EMR/SPR: sv.sockets.uncore.ubox.ncevents.lockcontrol_cfg.lockdelay = 0x1
OS (mainly for some SS tests):
DMR/PMR: sv.sockets.imhs.ubox.ncevents.lockcontrol_cfg.lockdelay = 0x4
GNR/SRF/CWF/GRR, EMR/SPR: sv.sockets.uncore.ubox.ncevents.lockcontrol_cfg.lockdelay = 0x4
Incoming links
 
Page: Dragon Diamond Rapids - DMR
Contributors
User
Edits
Comments
Labels
Valentine, Joshua H 
6
0
0
