# Dragon PState Range Decoder

> Source: 0551_Dragon PState Range Decoder.pdf

Dragon Test Name:
Core Ratio bitmask:
none = 0
LFM/HFM low half = 1
LFM/HFM high half = 2
HFM to all-core turbo (P0n) = 4
all-core turbo (P0n) to single-core turbo (P01) = 8
odd = 0x10
even = 0x20
UFS Ratio bitmask:
none = 0
low half = 1
high half = 2
odd = 0x10
even = 0x20
