# Dragon Bucketer

> Source: 011_Dragon Bucketer.pdf

Purpose
Flow
Where To Get
Usage
API
Bucket Details
Incoming Links
Purpose
Decodes Dragon thread status error codes into (sub)buckets, this is distinct from and higher level than the fully detailed 
.
Error Decode
Flow
Other tool/script consumes logs/database results and extracts errorcode.
Pass errorcode (and more) to Dragon Bucketer script, which returns (sub)bucket (and more).
Specific cases can be modified/overwritten by the caller pre-processing the input and/or post-processing the output.
The calling tool/script uses/logs the Bucketer output as desired.
Where To Get
Find the master copy on GitHub:
https://github.com/intel-innersource/applications.manufacturing.system-test.dragon.dragon/blob/master/Tests/external/dragon_bucketing.py
Initial add in r7130 on 07/18/22
Download a copy by right-clicking the "Raw" button  Save Link As.
Get access to GitHub by following the 1Source onboarding portal:  https://1source.intel.com/onboard
Additionally, the Dragon team will keep up-to-date copies in these locations:
Dragon Utilities
trunkExternal\dragon_bucketing.py
Initial add in r7141 on 07/27/22
MPVC IA Debug Tools
import pysvtools.mpvc.toolbox.dragon_bucketing
Initial add in PyPi release 1.0.4645 and source 23285ad on 08/10/22
 v1.11.7185 on 08/24/22
Ouroboros
Usage
Here is some example Python that shows basic usage of the Bucketer:
>>> import dragon_bucketing
>>> dragon_bucketing.bucket('C001420D', 'ICX', 'DR04-Yakko-WsZ-AA000011.obj')
Bucket(main='PM_Flow', sub='PM: General flow', algo='Yakko', retest=True, priority=7, meta='Fully Parsed')
>>> dragon_bucketing.get_main_labels()
['Data_Miscompare', 'x86_Fault', 'DRNG', 'MCE_Hard', 'MCE_Soft', 'Config_Mismatch', 'PM_Flow', 'Test_Bug', 'Early_Termination', 'Unknown', 'Timeout', 
'Force_Fail', 'Pass']
>>> dragon_bucketing.get_algo('DR04-Yakko-WsZ-AA000011.obj')
'Yakko'
The Bucketer script also supports running from the command line:
C:\Users\valuser1> python .\dragon_bucketing.py bucket C001420D ICX "DR04-Yakko-WsZ-AA000011.obj"
Bucket(main='PM_Flow', sub='PM: General flow', algo='Yakko', retest=True, priority=7, meta='Fully Parsed')
C:\Users\valuser1> python .\dragon_bucketing.py get_main_labels
['Data_Miscompare', 'x86_Fault', 'DRNG', 'MCE_Hard', 'MCE_Soft', 'Config_Mismatch', 'PM_Flow', 'Test_Bug', 'Early_Termination', 'Unknown', 'Timeout', 
'Force_Fail', 'Pass']
C:\Users\valuser1> python .\dragon_bucketing.py get_algo "DR04-Yakko-WsZ-AA000011.obj"
Yakko
API
As of Dragon revision 7130
The script defines one class – 
 – which is a tuple type with these fields:
Bucket
main  – Label for the main bucket.
sub  – Label for the sub-bucket.
algo  – Name of the Dragon test algorithm as parsed from the seed name.
retest  – One of three values: 
 if the error suggests that re-testing (before counting as a failure) is *
*, 
 if the error suggests that re-testing is *
*, or 
 for not-
True
recommended
False
NOT recommended
None
applicable cases (such as Pass/Force_Fail).
priority  – A *
* priority value to use for DPM accounting, where 1 is the highest priority, 2 is next highest, etc.
recommended
meta  – Metadata about how successfully the values where parsed.
The script defines three functions:
def bucket(vvar, product=None, seed_name=None, is_os=False): 
Decodes a Dragon error status into a bucket.
Arguments:
vvar  – Value from the thread status VVAR
product  – (optional) Product acronym (e.g. ICX, SPR)
Used to determine MCE bank name, and in rare cases (with 
) for matching against Test_Bug.
seed_name
seed_name  – (optional) Name of the seed
Used to determine algo.  Which is used to determine some cases where 0xF codes aren't Data_Miscompare.
Used to determine release #.  Which is used in rare cases (with product) for matching against Test_Bug.
is_os  – Set to 
 if this is a DoL/TSL seed
True
Most but not quite all codes are shared between BM and OS with the same meaning.  A few codes are unique to one or the other.  Pass and TO codes have different meaning between BM 
and OS.
Returns a `
 tuple containing all information.
Bucket`
def get_main_labels(): 
Returns all main bucket labels in priority order.
def get_algo(seed_name): 
Parses the Dragon algorithm name from a seed name.
Arguments:
seed_name – Name of the seed
Returns a string containing the algorithm name, or 
 if it can't be determined.
None
Additionally, these constants are defined for common `
 values:
Bucket`
# Names for all main buckets
CONFIG_MISMATCH = "Config_Mismatch"
DATA_MISCOMPARE = "Data_Miscompare"
DRNG = "DRNG"
EARLY_TERMINATION = "Early_Termination"
FORCE_FAIL = "Force_Fail"
MCE_HARD = "MCE_Hard"
MCE_SOFT = "MCE_Soft"
PASS = "Pass"
PM_FLOW = "PM_Flow"
TEST_BUG = "Test_Bug"
TIMEOUT = "Timeout"
UNKNOWN = "Unknown"
X86_FAULT = "x86_Fault"
# Values for bucket meta information
BAD_ERRORCODE = "Failed to Parse Errorcode"
BAD_SEED_NAME = "Failed to Parse Seed Name"
BAD_PRODUCT = "Failed to Parse Product or Product Not Yet Supported"
MISSING_SEED_NAME = "Missing Seed Name"
MISSING_PRODUCT = "Missing Product"
FULLY_PARSED = "Fully Parsed"
Bucket Details
Detailed 
 attached, summary embedded below.
spreadsheet
Edit Document
Bucket
# Subs
Len
Min Sub
Max Sub
Priority
Retest
Data_Miscompare
3
15
23
40
1
No
x86_Fault
23
9
13
45
2
No*
DRNG
3
4
17
35
3
No*
MCE_Hard
3
8
15
22
4
No*
MCE_Soft
3
8
15
28
5
No*
Config_Mismatch
10
15
11
43
6
Yes
PM_Flow
12
7
16
41
7
Yes
Test_Bug
2
8
30
41
8
Yes*
Early_Termination 3
17
17
25
9
Yes
Unknown
3
7
7
29
10
Yes
Timeout
4
7
7
32
11
Yes
Force_Fail
2
10
29
45
12
N/A
Pass
1
4
4
4
13
N/A
Metrics
# Subs
Len
Min Sub
Max Sub
Total
72
Min
1
4
4
Max
23
17
45
Incoming Links
 
Page: Dragon
 
Page: Dragon - IPTS
 
Page: Dragon EnablingNewProducts
 
Page: Dragon IAMCE
 
Page: Dragon IAMCE 14nm to 32nm
 
Page: Dragon IAMCE i7 to 10nm
 
Page: Dragon Reference
 
Page: Dragon Thread Status
 
Page: Dragon VerticalDebugGuide
 
Page: MPVC IA Debug Tools
