# Dragon Pre2593PMON

> Source: 0121_Dragon Pre2593PMON.pdf

1 PMON support for DRG revs prior to 2593
1.1 Pmon Example
2 PMON support for DRG revs prior to 2029
2.1 PMON Support
2.2 Pmon Example
2.2.1 Dynamic counter - Instructions Retired
2.2.2 Fixed counter - Instructions retired
3 Incoming links
4 Contributors
PMON support for DRG revs prior to 2593
All threads will use the initial values specified in 6 PMON VVAR's. Logical ID 0 will overwrite the initial values with their individual final values. Pmons are discussed in PRM Vol 3B: Performance Monitoring and Appendix 
Performance Monitoring Events.
For input:
This is used to configure the variable PMC's
Non LRB
LRB/KNF
v[0x2c, 0x2e, 0x30]
v[0x8c, 0x0x8e, 0x0x90]
v[0x2d, 0x2f, 0x31]
v[0x8d, 0x8f, 0x91]
Which counter data
0 = Not used
1..32 = PMC (see 3B 
 and Appendix to select the event in the next vvar)
Layout of IA32_PERFEVTSELx MSRs
33..49 = Fixed function counters (see Volume 3B for details)
33 (0x21) - INST_RETIRED.ANY (Instructions Retired)
34 (0x22) - CPU_CLK_UNHALTED.CORE
35 (0x23) - CPU_CLK_UNHALTED.REF
On Output:
Non LRB
LRB
v[0x2c, 0x2d]
v[0x8c, 0x8d]
v[0x2e, 0x2f]
v[0x8e, 0x8f]
v[0x30, 0x31]
v[0x90, 0x91]
Caution: PMON overwrites the configuration, so it cannot be debugged with INIT.
Pmon Example
These two examples measure the same event and the result should be identical.
Both items return Instructions Retired
+++++++++++++++ Orion Configuration file +++++++++++++++
<?xml version="1.0" encoding="utf-8"?>
<FritsTestConfiguration xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
 <Vvars>
   <Vvar Number="0x2c" Value="0x21" COMMENT="FIXED COUNTER"/>
   <Vvar Number="0x2e" Value="0x1"  COMMENT="VARIABLE COUNTER Selection"/>  // This is picking counter 1 1
   <Vvar Number="0x2f" Value="0x4300C0"  COMMENT="PERFEVTSELx MSR VALUE"/>  // This, along with the above, is writing to PERFEVTSEL1
 </Vvars>
</FritsTestConfiguration>
PMON support for DRG revs prior to 2029
Non LRB
LRB
v[0x2C] .. v[0x3B]
v[0x0C] .. v[0x8B]
v[0x2C] .. v[0x3B] Loop Count
PMON Support
Each thread is allocated 6 PMON VVAR's. They start at 64+(6*Logical ID).(280 for LRB) For input:
This is used to configure the variable PMC's
Non LRB
LRB
vv[0x40, 0x42, 0x44]
vv[0x118, 0x0x11a, 0x0x11c]
vv[0x41, 0x43, 0x45]
vv[0x119, 0x0x11b, 0x0x11d]
Which counter data
0 = Not used
1..32 = PMC
33..49 = Fixed function counters (see Volume 3 for details)
33 (0x21) - INST_RETIRED.ANY (Instructions Retired)
34 (0x22) - CPU_CLK_UNHALTED.CORE
35 (0x23) - CPU_CLK_UNHALTED.REF
On Output:
Non LRB
LRB
vv[0x40, 0x41]
vv[0x118, 0x119]
vv[0x42, 0x43]
vv[0x11a, 0x11b]
vv[0x44, 0x45]
vv[0x11c, 0x11d]
Caution: PMON overwrites the configuration, so it cannot be debugged with INIT.
Pmon Example
These two examples measure the same event and the result should be identical.
Dynamic counter - Instructions Retired
<Var v="0x42" val="0x1" /> <Var v="0x43" val="0x4300C0" />
Fixed counter - Instructions retired
<Var v="0x40" val="0x21" />
Incoming links
 
Page: Dragon DebugInfo
 
Page: Dragon VVARs pre 2016 SVN 1 to 4958
Contributors
User
Edits
Comments
Labels
