# Dragon DebugInfo

> Source: 012_Dragon DebugInfo.pdf

1 Dragon Debug
2 Memory Data Dump
3 Unexpected interrupt
4 PMON support
4.1 INPUT
4.2 OUTPUT
5 Incoming links
6 Contributors
Dragon Debug
Results of a test run can be found in the 
 area in the 
.
Thread Status
VVARs
Memory Data Dump
More detailed, per thread information can be found with the Memory Data Dump that is saved along with every failure in Orion.
To parse the Data Dump, use the Console Memory Manipulator or GUI Object File Manipulator.  To use the Console Memory Manipulator, run the following command from a command prompt (without the quotes): "\\amr.corp.
intel.com\ec\proj\mpv\fm_mpv\Silo\Dragon\DragonUtils\ObjInterface\<version>\ConsoleMemoryManipulator.exe <test>MemoryDump.obj".
To use the GUI Object File Manipulator, double-click the executable at "\\amr.corp.intel.com\ec\proj\mpv\fm_mpv\Silo\Dragon\DragonUtils\ObjInterface\Gui<version>\GuiObjectFileManipulator.exe".  Click the Browse button to 
locate your file, then click the "Open File" button.  Click the Decode button to decode the binary.  For more info, enter "help" in the Console Command text entry field and press the Enter key.
Details of the Dragon Memory dump is as follows:
The Dragon Memory dump will be populated on test completion, regardless of pass/fail.
Symbols ( for location of Data Dump )
DataDumpAddr_ThreadData == Start of data dump section
DataDumpEnd_ThreadData == End of data dump section
Header area Each segment is dword sized, except where noted
Offset
SVN 4996 - Current
SVN 1 - 4996
00h
(free - 2 bytes)
Header symbol "0DEB0680h"
02h
Max Thread Block Set Identifier (2 bytes)
(header symbol, continued)
04h
Stack size, currently 300h
Stack size, currently 300h
08h
Total Size of debug area
Total Size of debug area
0Ch
Size of each slice of per thread are, currently 80h
Size of each slice of per thread area, currently 80h
10h
Number of per thread slices aka number of threads
Number of per thread slices aka number of threads
14h
Cstate memory offset
Cstate memory offset
18h
PMON CTRL msr
PMON CTRL msr
1Ch
Copy of PMON VVARs
Copy of PMON VVARs
Per thread slice ---As of SVN 3349, there is a 1 Cache line buffer between the TBH and TB!
Each segment is dword sized, except where noted
Offset
SVN 4996 - Current
SVN 1 - 4996
00h
4B APIC ID
APIC ID
04h
4B Logical ID
Logical ID
08h
4B Stack Pointer
Stack Pointer
0Ch
4B Status
Status Dword
10h
2B Thread Block Set Identifier (TBSID)
PMON space. Counters 0 - 2 (6 dwords)
12h
2B Thread Block Control bits
14h
1B coreType (>= SVN r6679, free before)
15h
2B Bundle ID (>= trunk SVN r6932, >= LF branch r6871, free before)
17h
2B Module ID (>= trunk SVN r7088, >= LF branch r7006, free before)
19h
2B Gen Thread ID (>= trunk SVN r7088, >= LF branch r7012, free before)
1Bh
free space
28h
8B Code pointer (upper 4B is a PT alias of 0)
Code pointer
30h
4B Pointer to GDT copy (< SVN 6913, free after)
Pointer to GDT copy
34h
4B Pointer to IDT copy (< SVN 6913, free after)
Pointer to IDT copy
38h
4B Loop Count
Loop Count
3Ch
4B Stack pointer of interrupt failure (FAIL_INFO)
Stack pointer of 
failure (FAIL_INFO)
interrupt 
40h
PMONS. PMON counters 0 - 7 + ACNT (can be up to 16 dwords).
Note: if all 8 PMON counters are reported, ACNT will not be reported because
there is not enough free space in the thread block.
(core only) Extra PMONS. PMON counters 3 - 7 + ACNT ( can be up to 10 dwords )
Unexpected interrupt
The initial handler will push the vector onto the stack and the appropriate number of dwords to ensure that all unexpected interrupts enter the standard handler at the same offset (accounting for errors codes and such). The 
standard handler also changes GSBAS to point to the respective per thread slice of the thread. See above for detailed contents.
Upon entry into the standard handler, the following are pushed in the following order: RAX, RBX, RCX, RDX
At this point, the handler will check if there is an existing stack pointer in the debug area (offset 3ch).
>= SVN r7033: The handler grabs the previous error code, sets bit 26 to indicate nested exception, and exits.
< SVN r7033: If there is one, the old stack pointer and a nested error symbol (SVN >= 2824: prior fault code with bit 26 set; SVN < 2824: 0x0fa110b4) will be pushed onto the stack. The new/current stack pointer will 
then be updated into the debug area (FAIL_INFO) and the handler will exit.
The remaining GPRs and other registers are then pushed in the following order:
RSI, RDI, RBP, R8, R9, R10, R11, R12, R13, R14, R15,
CR0, CR2, CR3, CR4,
DR0, DR1, DR2, DR3,
GSBAS, FSBAS
This is followed by:
the status dword which includes the failing vector
updating the failing stack pointer in the debug area
(Optional section) If the seed fails #MC i.e. unexpected interrupt 18, it will push an additional DWORD with the failing MCE register. This will be in the form 0xA8XXXXXX. Bit 26 is set to differentiate this signature from the 
soft MCE failure.
At this point, the handler will try to acquire the last 16 bytes pointed to by the RIP.
Should the RIP be invalid
>= SVN r7033: Pushes 16B of 0
< SVN r7033: Causes a nested error mentioned above (bit 26 set, bit 27 clear)
Valid RIP: Push contents of last 16 bytes pointed to by RIP of the failure
Push status dword with bit 27 set as an indicator that all failing information has been pushed on the stack
If there are additional processor specific code, the code would then execute before the failing stack pointer is then updated to the FAIL_INFO portion of the debug area.
PMON support
This section for DRG SVN greater than 2593. For Legacy PMON Support, prior to 2593, click here
PMON info can be found at http://perfmon.intel.com/
INPUT
There are 9 Input entries for PMONS. See 
 for current layout.
here
Entry 0 : TAGEC address ( aligned to 4K ) or Fixed PMON mask ( lower 7 bits)
TAGEC If any bits >= 12 are set, then this will be the address placed into the EAX prior to running Patch0 instruction for TAGEC PMON gathering. TAGEC wiki
Bits 0-7 are the Fixed Enable mask. E.G. Bit 0 = Fixed counter enable 0, Bit 1 = Fixed counter enable 1, etc
For CORE:
Bit 0 Enables INST_RETIRED.ANY
Bit 1 Enables CPU_CLK_UNHALTED.CORE
Bit 2 Enables CPU_CLK_UNHALTED.REF
Entry 1-8 are configurations for variable counters.
There are 8 configuration inputs.
Config input will be put directly into IA32_PERFEVTSELx
0-7: Event Mask
8-15: Uint Mask
Events can be found in SDM 3B Appendix A. More current versions of the SDM have separate Volume 3 chapters dedicated to Performance Monitoring.
PMON configurations vary based on the product as detailed below.
Core products post SNB
Entry 1: Thread 0 pmon configuration
Entry 2: Thread 0 pmon configuration
Entry 3: Thread 0 pmon configuration
Entry 4: Thread 0 pmon configuration
Entry 5: Thread 1 pmon configuration
Entry 6: Thread 1 pmon configuration
Entry 7: Thread 1 pmon configuration
Entry 8: Thread 1 pmon configuration
Atom products (with two threads per core)
Entry 1: Thread 0 pmon configuration
Entry 2: Thread 0 pmon configuration
Entry 3: Not used (Will GPF)
Entry 4: Not used (Will GPF)
Entry 5: Thread 1 pmon configuration
Entry 6: Thread 1 pmon configuration
Entry 7: Not used (Will GPF)
Entry 8: Not used (Will GPF)
Knights Ferry ( 2 entries per CORE! Only program/look at results via only 1 thread. )
Entry 1: Core pmon configuration
Entry 2: Core pmon configuration
Knights Corner
Entry 1: Thread 0 pmon configuration
Entry 2: Thread 0 pmon configuration
Entry 3: Thread 1 pmon configuration
Entry 4: Thread 1 pmon configuration
Entry 5: Thread 2 pmon configuration
Entry 6: Thread 2 pmon configuration
Entry 7: Thread 3 pmon configuration
Entry 8: Thread 3 pmon configuration
Orion Config Examples for SNB:
1.) Variable only
<Vvars>
  <Vvar Number="0x30" Value="0x0" COMMENT="No TAGEC, No Fixed"/>
  <Vvar Number="0x31" Value="0x43003C" COMMENT="T0: UNHALTED CORE CYCLES"/>
  <Vvar Number="0x32" Value="0x4300c0" COMMENT="T0: INSTRUCTIONS RETIRED"/>
  <Vvar Number="0x33" Value="0x43013C" COMMENT="T0: UNHALTED REFERENCE CYCLES"/>
  <Vvar Number="0x34" Value="0x43412e" COMMENT="T0: LLC MISSES"/>
  <Vvar Number="0x35" Value="0x438024" COMMENT="T1: L2_RQSTS.PREFETCH MISSES"/>
  <Vvar Number="0x36" Value="0x43aa24" COMMENT="T1: L2_RQSTS.MISS"/>
  <Vvar Number="0x37" Value="0x434f2e" COMMENT="T1: LLC REFERENCE"/>
  <Vvar Number="0x38" Value="0x43412e" COMMENT="T1: LLC MISSES"/>
</Vvars>
2.) Fixed counter 0 and 2.
<Vvars>
  <Vvar Number="0x30" Value="0x5" COMMENT="INST_RETIRED.ANY, CPU_CLK_UNHALTED.REF"/>
</Vvars>
3.) All Fixed and all counters
<Vvars>
  <Vvar Number="0x30" Value="0x7" COMMENT="INST_RETIRED.ANY, CPU_CLK_UNHALTED.CORE, CPU_CLK_UNHALTED.REF"/>
  <Vvar Number="0x31" Value="0x43003C" COMMENT="T0: UNHALTED CORE CYCLES"/>
  <Vvar Number="0x32" Value="0x4300c0" COMMENT="T0: INSTRCTIONS RETIRED"/>
  <Vvar Number="0x33" Value="0x43013C" COMMENT="T0: UNHALTED REFERECE CYCLES"/>
  <Vvar Number="0x34" Value="0x43412e" COMMENT="T0: LLC MISSES"/>
  <Vvar Number="0x35" Value="0x438024" COMMENT="T1: L2_RQSTS.PREFECH MISSES"/>
  <Vvar Number="0x36" Value="0x43aa24" COMMENT="T1: L2_RQSTS.MISS"/>
  <Vvar Number="0x37" Value="0x434f2e" COMMENT="T1: LLC REFERENCE"/>
  <Vvar Number="0x38" Value="0x43412e" COMMENT="T1: LLC MISSES"/>
</Vvars>
OUTPUT
6 VVARS are reused for PMON Counter outputs.  v[0x30] .. v[0x35] ( Core )
v[0x90] .. v[0x95] ( MIC )
This is space for only 3 counts (each count is 2 dwords)
The rest of the PMON counts can be seen in the debug data dump.
This is only first 3 counts from BSP.
Fixed counters preceed variable counters.
last output + 1 will contain ACNT of test
Example output from above input examples:
1.)
  <Vvar Number="0x30" Value="0x18712502" />  <-- T0: From Entry 0:  UNHALTED CORE CYCLES LOW DWORD
  <Vvar Number="0x31" Value="0x2" />         <-- T0: From Entry 0:  UNHALTED CORE CYCLES HIGH DWORD
  <Vvar Number="0x32" Value="0xB1B8BE2F" />  <-- T0: From Entry 1:  INSTRUCTIONS RETIRED LOW DWORD
  <Vvar Number="0x33" Value="0x1" />         <-- T0: From Entry 1:  INSTRUCTIONS RETIRED HIGH DWORD
  <Vvar Number="0x34" Value="0x1DCD659C" />  <-- T0: From Entry 2:  UNHALTED REFERENCE CYCLES LOW DWORD
  <Vvar Number="0x35" Value="0x0" />         <-- T0: From Entry 2:  UNHALTED REFERENCE CYCLES HIGH DWORD
                      *** REST OF DATA is in debug data dump!!! ***
  <Vvar Number="0x36" Value="0x43AA24" />    <-- No output
  <Vvar Number="0x37" Value="0x434F2E" />    <-- No output
  <Vvar Number="0x38" Value="0x43412E" />    <-- No output
2.)
  <Vvar Number="0x30" Value="0xB1A10C78" />  <-- T0: From Entry 0.bit 0:  INST_RETIRED.ANY  LOW DWORD
  <Vvar Number="0x31" Value="0x1" />         <-- T0: From Entry 0.bit 0:  INST_RETIRED.ANY  HIGH DWORD
  <Vvar Number="0x32" Value="0x18712660" />  <-- T0: From Entry 0.bit 2:  CPU_CLK_UNHALTED.REF LOW DWORD
  <Vvar Number="0x33" Value="0x2" />         <-- T0: From Entry 0.bit 2:  CPU_CLK_UNHALTED.REF HIGH DWORD
  <Vvar Number="0x34" Value="0x18718A04" />  <-- T0: ACNT LOW DWORD ( as only 2 out of 3 entries were used)
  <Vvar Number="0x35" Value="0x2" />         <-- T0: ACNT HIGH DWORD ( as only 2 out of 3 entries were used)
3.)
  <Vvar Number="0x30" Value="0xB1905157" />   <-- T0: From Entry 0.bit 0:  INST_RETIRED.ANY  LOW DWORD
  <Vvar Number="0x31" Value="0x1" />          <-- T0: From Entry 0.bit 0:  INST_RETIRED.ANY  HIGH DWORD
  <Vvar Number="0x32" Value="0x18712598" />   <-- T0: From Entry 0.bit 1:  CPU_CLK_UNHALTED.CORE LOW DWORD
  <Vvar Number="0x33" Value="0x2" />          <-- T0: From Entry 0.bit 1:  CPU_CLK_UNHALTED.CORE HIGH DWORD
  <Vvar Number="0x34" Value="0x18712598" />   <-- T0: From Entry 0.bit 2:  CPU_CLK_UNHALTED.REF LOW DWORD
  <Vvar Number="0x35" Value="0x2" />          <-- T0: From Entry 0.bit 2:  CPU_CLK_UNHALTED.REF HIGH DWORD
                      *** REST OF DATA is in debug data dump!!! ***
Max output PMONS ( for thread ) is 8 qword entries. 3 fixed PMON counts + 4 PMON variable counts + ACNT.
Segment offsets into debug table output for PMONS
PMON Offsets (SVN 4996 - Current)
PMON Offsets (SVN 2593 - 4996)
Count 0 Low
0x40
0x10
Count 0 High
0x44
0x14
Count 1 Low
0x48
0x18
Count 1 High
0x4C
0x1C
Count 2 Low
0x50
0x20
Count 2 High
0x54
0x24
Count 3 Low
0x58
0x40
Count 3 High
0x5C
0x44
Count 4 Low
0x60
0x48
Count 4 High
0x64
0x4C
Count 5 Low
0x68
0x50
Count 5 High
0x6C
0x54
Count 6 Low
0x70
0x58
Count 6 High
0x74
0x5C
Count 7 Low
0x78
0x60
Count 7 High
0x7C
0x68
Incoming links
 
Page: Dragon NUT
 
Page: Dragon Reference
 
Page: Dragon Thread Mapping
 
Page: Dragon VVARs
 
Page: Dragon VVARs 2016 SVN 4958 to 5266
 
Page: Dragon VVARs 2017 SVN 5266 to 5872
 
Page: Dragon VVARs 2018 SVN 5872 to 6207
 
Page: Dragon VVARs 2019 SVN 6207 to 6390
 
Page: Dragon VVARs 2020 SVN 6390 to 6752
 
Page: Dragon VVARs 2021 SVN 6752 to 7030
 
Page: Dragon VVARs 2022 SVN 7030 to 7218
 
Page: Dragon VVARs 2023 SVN 7218 to 7621
 
Page: Dragon VVARs 2024 SVN 7519 to 7810
 
Page: Dragon VVARs 2025 SVN 7810 to 8178
 
Page: Dragon VVARs pre 2016 SVN 1 to 4958
 
Page: Dragon VVARs Sandbox
 
Page: Ouroboros Documentation
Contributors
User
Edits
Comments
Labels
Valentine, Joshua H 
35
0
0
Calhoon, Brent
1
0
0
Mayhue, Mallory A
1
0
0
