# 1.

> Source: 0131_Updating Dragon Error Decode.pdf

a.  
2.  
a.  
b.  
c.  
d.  
e.  
f.  
3.  
a.  
b.  
c.  
i.  
ii.  
1.  
2.  
1.  
a.  
b.  
c.  
2.  
a.  
b.  
Updating Dragon Error Decode
Starting with SVN revision 5118, the code for the 
 script is controlled by source control and editable within Visual Studio.  Please make changes to the script there, check it into source control, and then 
Dragon Error Decode
copy it to the wiki.
Starting with SVN revision 7860, commits pushed to GitHub from the master branch will be automatically uploaded to the wiki from CI/CD (GitHub actions runner running on WEYR).
CI/CD
Instructions (Manual Update)
BKMs
Linting JavaScript
Adding New Dropdowns
CI/CD
A GitHub actions runner running on WEYR will update the 
 page with changes pushed to the Dragon master branch.
Dragon Error Decode
See 
 for information on how to configure it.  See the "
" folder within the Dragon code base for how it's currently configured.
Dragon SourceControl
.github/workflows
Instructions (Manual Update)
Not necessary if CI/CD is working.
Open up "Tests\external\errorDecoder.html" in Visual Studio.
Go to "Edit -> Select All" in the menu bar (or press CTRL+A).  Copy everything to the clipboard.
Open 
 for editing.
Dragon Error Decode
Right-click within the "HTML" macro and choose "Select All" (or press CTRL+A).
Press backspace to delete everything.  This will probably delete the HTML macro.
Select "Insert -> Other Macros" at the top of the page.
In the dialog window that pops up, type "HTML" into the input box in the upper-right.
Select the "HTML" macro.  Press "Insert".
Paste the copied code to the HTML macro.
Modify the 
 HTML element.
<script>
Locate the 
 HTML element at the bottom of the code.
<script>
Remove the `
` attribute.
src="errorDecoder.js"
Open up "Tests\external\errorDecoder.js" in Visual Studio.
Go to "Edit -> Select All" in the menu bar (or press CTRL+A).  Copy everything to the clipboard.
Paste the copied code between 
 and 
.
<script>
</script>
BKMs
Linting JavaScript
Lint in software refers to syntactic discrepancies.  Linters or lint checkers are tools that statically analyze code to find lint.  Visual Studio has a builtin lint checker called "ESLint".  A configuration file was added to the solution 
to add rules to ESLint to make it as close to StyleCop guidelines as possible.
ESLint will run on JavaScript files two ways:
Automatically every time you save the file while it is open within Visual Studio.
Right-click on "errorDecoder.js" in the Solution Explorer and choose "Run Web Code Analysis".
Both options require the "Error List" window in Visual Studio to already been open; Visual Studio will not automatically pop the window open (like it does for C# errors).
Adding New Dropdowns
Follow these steps to add a new dropdown to the error decode script:
Add the markup to "errorDecoder.html"
The format of the markdown must look like this:
<p class="hideMe" id="yourChoice">
        ...
</p>
Put this next to the other similarly formatted 
 elements.
<p>
The "class" attribute must be "hideMe" and the "id" attribute must be something unique to that <p> tag.
Modify "errorDecoder.js" to show/hide the dropdowns as appropriate.
Near the top of the function VVARSTATUS add this line of code for every dropdown on the page:
document.getElementById("yourChoice").className = "hideMe";
Then, in whatever appropriate if block where you would need to show the dropdown, add this line of code:
document.getElementById("yourChoice").className = "";
