# Dragon Error Decode

> Source: 013_Dragon Error Decode.pdf

Per thread status error code (ex: 203b154d): 
BM Dragon 4-byte per-thread error codes start at vvar[0xC] (phy/lin addr 0x217C).
TSL Dragon txt log has them in FailMask (T3, T2, T1, T0). TSL Dragon YAML log has them in the vvar entry of the lpu nodes.
Precise input and error details may vary by SVN rev.
