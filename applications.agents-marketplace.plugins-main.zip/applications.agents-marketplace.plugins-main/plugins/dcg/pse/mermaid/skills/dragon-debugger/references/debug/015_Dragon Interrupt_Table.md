# Dragon Interrupt_Table

> Source: 015_Dragon Interrupt_Table.pdf

Decoding Thread Status
See
for general information.
## Dragon Thread Status

Register DR0 should have a repeat of the error code. Register DR1 should have the address of the faulting instruction.
Dragon Error Decoders handle all the math and masking discussed below, and are an easier way to understand a particular error.
x86_Fault (unless in one of the various special sets:
,
,
## )

BM Special BM Barrier Special DoL/TSL Special
Vector in low byte.
bit 27: Failing information is on the thread's stack.
bit 26: A nested exception occurred.
bit 25: DoL/TSL >= 1.6.5.7: fault occurred outside the Dragon test in the DoL/TSL thread setup or teardown.
Interrupt Vector Table
## SDMs/PRMs:

See PRM Volume 3 Ch 6.15 for more detailed descriptions of interrupt/exception/fault vectors.  Basic vector info listed on this wiki page, with Dragon context.
## \\amr.corp.intel.com\ec\proj\mpv\fm_mpv\dev\Content\Doc\PRM

http://www.intel.com/content/www/us/en/processors/architectures-software-developer-manuals.html
Vector #
(hex)
(dec)
Mnemonic
Description
Source
Likely Dragon SP reasons
0
0
#DE
Divide Error
DIV and IDIV instructions.
Corrupted result/data/addr on div/idiv.
1
1
#DB
RESERVED
For Intel use only.
2
2
NMI
NMI Interrupt
Nonmaskable external interrupt
3
3
#BP
Breakpoint
INT 3 instruction.
4
4
#OF
Overflow
INTO instruction.
5
5
#BR
BOUND Range Exceeded
BOUND instruction.
6
6
#UD
Invalid Opcode
UD2 instruction or reserved opcode.
Branched to wrong addr. Code corruption. Depending on rev, patch2/patch3 not enabled or other instruction
type fused off.
7
7
#NM
Device Not Available (No Math
## Coprocessor)

Floating-point or WAIT/FWAIT Instruction.
Extended Feature Disable (XFD) bit set and
attempted state access.
e.g.  AMX XTILEDATA
8
8
#DF
## Double Fault

Any Instruction that can generate an exception, an
NMI, or an INTR.
Took 2 errors. Nested exception.
9
9
RSVD
Coprocessor Segment Overrun
(reserved)
Floating-point Instruction.
A
10
#TS
Invalid TSS
Task switch or TSS access.
B
11
#NP
## Segment Not Present

Loading segment registers or accessing system
segments.
C
12
#SS
Stack-Segment Fault
Stack operations and SS register loads.
D
13
#GP
## General Protection

Any memory reference and other protection checks.
Myriad. Corrupted addr among others. Also any unassigned vector, see
below.
Decoding #GP
E
14
#PF
Page Fault
Any memory reference. Address in CR2.
Corrupted addr or PT structure. See
decode below.
Page Fault
F
15
RSVD
Intel reserved. Do not use.
10
16
#MF
x87 FPU Floating-Point Error
## (Math Fault)

x87 FPU floating-point or WAIT/FWAIT Instruction.
Corrupted result/data/addr on x87 FP.  See
below.
FPU Status
11
17
#AC
Alignment Check
Any data reference in memory.
12
18
#MC
## Machine Check

Error codes (if any) and source are model dependent.
Myriad.
13
19
#XM
SIMD Floating Point Exception
SSE/AVX floating point instructions.
Corrupted result/data/addr on SSE/AVX FP. Data mismatch detected by checker (may or may not be FP).
See
below.
MXCSR
14
20
#VE
## Virtualization Exception

The processor detected an EPT violation in VMX non-
root operation.
Corrupted addr or EPT structure.
15
21
#CP
## Control Protection Exception

Control flow transfer attempt violated the CET
constraints.
16-1F
22 - 31
RSVD
Intel reserved. Do not use.
Dragon uses 0x16, 0x17, 0x18 anyway.
16
22
DRG Wake
Dragon CState Wakeup Interrupt
CState Handler APIC Timer.
Used to wake up the CState driving thread. Should not be a failure signature.
17
23
DRG PM
## Dragon PM/NMI Barrier Error

PM or NMI Init/Action/Finalize functions.
Thread not responding as expected to PM/NMI related commands. See
and
BM Dragon Barrier Codes
Drago
pages for details.
n Error Decoders
18
24
DRG CMCI
## Dragon CMCI Soft MCE handler

## Soft MCE threshold crossed when vv[3] bit[25] set

As error, Dragon reports MCE (series A/B) instead of int (series C/D).
20-FF
32 - 255
User Int
User Defined Interrupts
External interrupt or INT n instruction.
Dragon uses unassigned interrupt vectors for certain failures. See
below.
Decoding #GP
## Decoding GP

C#xxxx0D/D#xxxx0D - #GP can occur for a number of reasons.
General x86 #GP (which is itself can occur for many reasons).
## #GP for not having a handler for that interrupt vector

In this case, instead of the the interrupt number in the low byte, the #GP interrupt is triggered and the original interrupt vector is encoded with other information in the middle of the error code.  See
below.
Dragon intentionally pulls certain interrupt vectors for which we don't have handlers to indicate specific errors.  See
.
Dragon Special Codes
## Common unexpected interrupt bits

bit 27: failing information is on the stack
## bit 26: a nested exception occurred

bit 25: DoL/TSL >= 1.6.5.7: fault occurred outside the Dragon test in the DoL/TSL thread setup or teardown.
## #GP for interrupt without handler

## bits 18-11: vector that caused the exception

## Note that this is not hex aligned. Ex: C#07FA0D is (7FA >> 3) = FF

Dragon uses unassigned interrupt vectors for certain failures.  See
.
## Dragon Special Codes

Additionally, this may indicate unexpected APIC interrupt generated by a thread running
.
## Eclipse

bit 10: Only used when bit 9 is clear. If set, exception is LDT related. If clear, exception is GDT related.
bit 9: interrupt (exception is IDT related, most likely Dragon does not have a handler for that interrupt)
bit 8: external event (exception was external to the code flow)
## FPU Status

The middle 2 bytes of #MF.  Unfortunately, this only encodes flags, not masks.  So the code can't indicate which flag bits were allowed.  If Stack Fault isn't set, then the error must have been caused by one of the set Flags.
Bit
Name
Meaning
15
B
FPU Busy
14
C3
Condition Code 3
13:11
TOP
Top of Stack Pointer
10
C2
Condition Code 2
9
C1
Condition Code 1
8
C0
Condition Code 0
7
ES
Error Summary Status
6
SF
Stack Fault
5
PE
Precision Flag
4
UE
Underflow Flag
3
OE
Overflow Flag
2
ZE
Divide-by-Zero Flag
1
DE
Denormal Flag
0
IE
Invalid Operation Flag
## MXCSR

The middle 2 bytes of #XM. Mask = 0 and the corresponding flag = 1 indicates a failure. Most commonly, Dragon only sets the Precision Mask (in which case, all flags except PE are a failure).  But in some seeds, denormals
are allowed.  And a few algos mask everything.
Bit
Name
Meaning
15
FZ
Flush to Zero
14:13
RC
Rounding Control
12
PM
Precision Mask
11
UM
Underflow Mask
10
OM
Overflow Mask
9
ZM
Divide-by-Zero Mask
8
DM
Denormal Operation Mask
7
IM
Invalid Operation Mask
6
DAZ
Denormals Are Zeros
5
PE
Precision Flag
4
UE
Underflow Flag
3
OE
Overflow Flag
2
ZE
Divide-by-Zero Flag
1
DE
Denormal Flag
0
IE
Invalid Operation Flag
Rounding Control
Rounding Mode
RC
Field
Description
Round nearest (even)
## 00b

Rounded result is the closest to the infinitely precise result. If two values are equally close, the result is the even value (that is, the one with the least-significant bit of zero).
Default.
Round down (toward -
infinity)
## 01b

Rounded result is closest to but no greater than the infinitely precise result.
Round up (toward +infinity)
## 10b

Rounded result is closest to but no less than the infinitely precise result.
Round zero (truncate)
## 11b

Rounded result is closest to but no greater in absolute value than the infinitely precise result.
## Page Fault

The middle 2 bytes of #PF error code indicate the reason for the #PF.
Bit
Name
Meaning
0
## P

1 = The fault was caused by a page-level protection violation. 0 = The fault was caused by a non-present page.
1
## W/R

1 = The access causing the fault was a Write (W). 0 = The access causing the fault was a Read (R).
2
## U/S

1 = A User-mode (U) access caused the fault. 0 = A supervisor-mode (S) access caused the fault.
3
## RSVD

1 = The fault was caused by a reserved bit set to 1 in some paging-structure entry. 0 = The fault was NOT caused by reserved bit violation.
4
## I/D

1 = The fault was caused by an Instruction (I) fetch. 0 = The fault was caused by a Data (D) fetch.
5
## PK

1 = The fault was caused by a Protection Key (PK) violation. 0 = The fault was NOT caused by Protection Keys (PK).
6
## SS

1 = The fault was caused by a Shadow Stack (SS) access. 0 = The fault was NOT caused by a Shadow Stack (SS) access.
7
## HLAT

1 = The fault was caused by a Hypervisor Linear Address Translation (HLAT) access. 0 = The fault was NOT caused by a Hypervisor Linear Address Translation (HLAT) access.
8-15
## unused

Currently unused by x64, may be used in the future.
Incoming links

Page: Broxton_PO MIGRATED

Page: Dragon DoL

Page: Dragon Thread Status

Page: Dragon VVARs 2016 SVN 4958 to 5266

Page: Dragon VVARs 2017 SVN 5266 to 5872

Page: Dragon VVARs 2018 SVN 5872 to 6207

Page: Dragon VVARs 2019 SVN 6207 to 6390

Page: Dragon VVARs 2020 SVN 6390 to 6752

Page: Dragon VVARs 2021 SVN 6752 to 7030

Page: Dragon VVARs 2022 SVN 7030 to 7218

Page: Dragon VVARs pre 2016 SVN 1 to 4958

Page: Ouroboros Documentation
Contributors
User
Edits
Comments
Labels
Valentine, Joshua H
49
0
0
