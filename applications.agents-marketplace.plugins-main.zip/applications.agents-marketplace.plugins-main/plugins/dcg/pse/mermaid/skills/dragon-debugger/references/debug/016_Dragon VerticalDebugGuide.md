# Dragon VerticalDebugGuide

> Source: 016_Dragon VerticalDebugGuide.pdf

## Who Should Use This Guide

If you are on a vertical product team and need assistance in debugging a failure with Dragon content, you should use this guide. It will provide a quick background on Dragon, steps for first-level debug, and instructions to
escalate failures to the Dragon team for further analysis.
What is Dragon?
## Overview

In short, Dragon is a content type developed by the MPV IA Content team, primarily designed to find speedpaths. It was originally intended to find circuit issues, not logic, and focuses on areas of the silicon that are optimized
for speed, such as:
Core (primary focus)
CBO/LLC/Ring
EDRAM
## Memory Controller

More recently Dragon has been modified to participate in PPV screens for DPM, and to help close DPM buckets to tester.
## Modes of Dragon Seeds

There are a handful of different modes of Dragon seeds. The mode essentially defines the memory footprint, and the memory footprint generally defines whether the seed is tester-portable or not. The mode of a particular
seed can found by the second digit of a seed name. For instance:
D 08-DittoMT-CG-9F1001DC.obj
## R

The mode of this seed is " ," or RAM, which has the largest footprint of any mode and contains reads/writes that go out to DDR. These are the different modes of Dragon seeds:
R
Tester-Portable Modes
## M: MLC

S: Small LLC. Only uses a portion of the LLC.
L: LLC. Uses full LLC.
E: ELLC. Uses a read/return DFX returns arbitrary or random data from the memory controller when a read is serviced. Uses certain Dragon templates whose algorithms can operate with arbitrary data, generally
integer arithmetic operations only. Originally created to test products with EDRAM, the  seeds may be used on products which have the read/return DFX and a DFX which can protect specified cache ways from
## E

eviction. The way protection is needed so code and critical state data is not evicted.
## Not Tester-Portable via Direct Porting

R: RAM. Contains LLC evictions that will go out to DDR.
## Release Info

Dragon can generate seed targeted to run on either system or testers. The tester releases are limited to memory use which fits within the available caches without evictions. System releases includes  seeds whose memory
## R

footprint extends beyond the caches into DDR or EDRAM. The System releases also may contain certain instructions which cannot be run in the product tester environment.
## There are three types or Dragon system releases:

CMV: Standard release for speedpath hunting. Includes thousands of seeds. Architectural coverage is complete across the seed release, each seed covers only a portion of its targeted area.
PPV: A release for DPM screening. Includes hundreds of seeds. To reduce the number of seeds required to attain 100% coverage the PPV release includes " " coverage variants (FireC, FrenzyC, LeekC) in which a
## C

single seed contain 100% of the targeted coverage area for its respective template.
THR: "Test Hole Reduction" releases contain content which is more easily portable from system to tester. The THR team should run this release on DPM screened parts; if any of these seeds hit the same issue they
may be directly portable to tester. The THR release contain following types of seeds:
Pseudo SBFT: these seeds should be directly portable to tester. For core products they should be run on the core which displayed the DPM. On SLM, AMT, and GLM the seeds are randomized to target
one of the modules in the part, and across the release will run on all modules.
Broadside compliant: Seeds that are portable using broadside.
SimlessFT: seeds which may be portable using a simless tester conversion process.
If you would like more details, there are many good presentations here: Dragon Presentations
Dragon Output
## VVARs

So you've run a Dragon test, or perhaps a whole bunch of them. Great! How do you know what happened? Hopefully, your loader of choice (Orion, Merlin) told you whether the seed passed or failed. Outside of a general pass
/fail, Dragon has a section of memory that contains all sorts of good information for you, called VVARs. They are each identified with a unique hex number, and each one tells you something unique about the test that just ran.
Some can also be used as input for test setup. For instance, some of the more popular VVARs are:
## Input VVARs:

VV[0x00]: Target test run time. On the system, this is measured in microseconds. On the tester, this is measured in CPU cycles.
VV[0x01]: Target test run time scaling factor.
VV[0x03]: Debug bits to do things such as enable/disable tester mode, DFX SIPI, VMX, DRNG, RDRAND, etc.
A tool to help you check and set the bits within VV[0x3] is available at the
article.
## Dragon VVDEBUG Decoder

VV[0x08]: Soft MCE check mask. Enable/disables the checking of different MCE banks. Dragon will not report a soft MCE failure unless the appropriate bank bit is enabled (VV[0x09]
checked VV[0x08]).
## and

VV[0x09]: Soft MCE enable mask. Enable/disables soft MCEs on the particular bank.
## Output VVARs:

VV[0x02]: Number of threads that exist on the system.
VV[0x0A]: >= SVN r4558,
: Various flags indicating some aspects of generated and runtime state.
VV_Output
VV[0x0C] - 0xTT (product dependent): Per
. This will tell you the result of the test on a per-thread basis.
## Thread Status

## See next section: I Have a Failure. Now What?

VV[0xTT+1 - 0xTT+2]: Number of CPU cycles run during a passing test. Useful for porting seed to the tester to add appropriate cycle padding.
VV[0xTT+3]: Minimum loop count of all threads.
VV[0xTT+4]: Maximum loop count of all threads.
This is a very small subset of the VVARs that exist. A complete description of every VVAR can be found here:
. They have and will continue to change over time, so make sure you are looking under the proper
Dragon VVARs
SVN section for your seed.
## Finding the SVN Revision

>= SVN r2624, vv[0xB] contains the SVN revision (BCD encoded, so read the hex as literal instead of hex; vv[0xB]=0x2624 is SVN r2624).
Alternatively, to find the SVN revision of your particular seeds, you need to first find the release number of your seed. This can be found in the first 2 digits of the seed number. For example:
DR08-DittoMT-CG-
1001DC.obj
## 9F

## The release number for this particular seed is

## . Once you have this, you can look up the release number here:

. The SVN revision will be listed right next to the release number. In this case, for release
0x9F
Dragon Releases
0x9F, the SVN revision is
## . Use the SVN revision number to look up the proper VVAR descriptions on

. Again, in this case, I would have to look here for VVAR descriptions:
4588
Dragon VVARs
Dragon VVARs#SVN 4578-4602
I Have a Failure. Now What?
## Gathering Log Files

First things first, can you reproduce it? If not, are you running it in the same manner as the original failure? Voltages, ratios, temperature, etc.
What is the failing signature? VVARs 0x0C through (0xC + [number_of_active_CPU_threads - 1]) in the log file will report this on a per-thread basis. For instance, an 8-threaded CPU will have 8 VVARs worth of
status, from VV[0xC] to VV[0x13].
## There are tons of different

, and can also vary by seed template. A few of the most common ones are:
## signatures

0x0000 0000: Thread is still running, or has hung.
0x600D 600D: Thread passed test (GOOD GOOD).
0x4823 2323: Patch 2/3 instruction not enabled on system. Most of the time this can be enabled with the proper CR writes via ITP. This usually needs to be set after reset.
0xAzzz zzzz: Machine Check Error
Bit 26 = 1: Hard MCE occurred.
Bit 26 = 0: Soft MCE occurred.
0xFzzz zzzz: Test-specific failure occurred. You will need to look up the exact error code from here:
.
## Dragon TestDescriptions

A decoder tool is available for looking up any failing signature at the
article, as well as a higher level
.
Dragon Error Decode
Dragon Bucketer
The
tool can can directly consume
system log files.
Ouroboros
some
## Did a Machine Check Error occur?

If so, each product usually has its own ITP script to check for valid MC registers, dump the contents, and decode them into something more readable. This is an example of what an MCE dump will look like
## on BDW-H:

>> sys.path.append(r"\\hsw-tb\hsw\itp_scripts")
>> import BdwMCDump
>> BdwMCDump.DecodeAll()
Output:
...
...
Thread: BDW_C3_T0
BANK 8 ( CBO3 ) specified.
## MC8_STATUS 0xBE00000001001137

## Range      (Value)  Value Description         Bit Range Description

## -----      -------  -----------------         ---------------------

63:63        (0x1)  Valid                     (Indicates if the register is valid)
## 62:62        (0x0)  No Overflow               (Overflow indication)

## 61:61        (0x1)  Uncorrected               (Uncorrected Error Bit)

## 60:60        (0x1)  Enabled                   (Enable Bit)

## 59:59        (0x1)  MISC is valid             (MISCV Bit)

## 58:58        (0x1)  ADDR is valid             (ADDR Bit)

## 57:57        (0x1)  Corrupt                   (Processor Context Corrupt)

## 56:56        (0x0)  UCR not Signaling         (UCR error Signaled)

## 55:55        (0x0)  No Action Required        (UCR error Action Required)

## 54:53        (0x0)  No Tracking               (Threshold-based error status)

## 24:24        (0x1)  SAD_ERR_CORRUPTING_OTHER  (CBO/LLC Error)

## 15:11        (0x2)  Expect 0                  (Undefined MCACOD's)

## 12:12        (0x1)  Filtered                  (Correction Filtering Bit)

## 8:8        (0x1)  Cache Hierarchy Error     (Cache Hierarchy Error)

## 7:4        (0x3)  Data Read                 (Cache Hierarchy Error RRRR)

## 3:2        (0x1)  Data                      (Cache Hierarchy Error TT)

1:0        (0x3)  Generic LL                (Cache Hierarchy Error LL)
BANK 8 ( CBO3 ) specified.
## MC8_ADDR 0xAAA80

## Range      (Value)  Value Description         Bit Range Description

## -----      -------  -----------------         ---------------------

## 63:39        (0x0)  0                         (Availavble for Enhanced MCA)

38:0    (0xAAA80)  Address of access         (Address)
...
...
The MC8_STATUS register tells us that there is a SAD error and the MC8_ADDR tells us the error occurred when trying to access address 0xAAA80, which happens to be in the VGA memory space.
If, for some reason, a log file isn't produced, VVARs can also be accessed by doing a memory dump via ITP. VVARs are located at memory location 0x214C. To dump them out, open an ITP window and do the
following:
itp.halt()
itp.threads[0].memdump("0x214Cp",40,4)
## Which will output:

0x000000000000214CP: 002dc6c0 00bb8000 00000008 00000002
0x000000000000215CP: 00000000 0000ff00 00000000 00000000
0x000000000000216CP: ffffffff ffffffff 00000000 00004440
0x000000000000217CP: 600d600d 600d600d 600d600d 600d600d
0x000000000000218CP: 600d600d 600d600d 600d600d 600d600d
0x000000000000219CP: 00000000 00000000 00000000 00000000
0x00000000000021ACP: 00000000 00000000 00000000 00000000
0x00000000000021BCP: 00000000 00000000 00000000 00000000
0x00000000000021CCP: 00000000 00000000 00000000 00000000
0x00000000000021DCP: 00000000 00000000 00000000 00000000
Each VVAR is 4-bytes in length, and VVAR[0x00] starts at memory location 0x214C, so the value of:
VV[0x00] = 0x002dc6c = 3,000,000d. Therefore, this seed had a target time of 3-million microseconds, or 3 seconds.
VV[0x02] = 0x00000008, which means that 8 threads were running on the system.
VV[0x0C-0x13] = 0x600d600d, which is the signature for a passing test. All 8 threads passed.
Now that you have all the failing information and log files, you are ready to escalate the issue to the Dragon team! Woohoo!
## But my Failure is an R-Mode Seed!

R mode seeds, of course, cannot be ported to the tester since they have memory transactions that go off-chip. This is not allowed on the tester. If your failure is on an  mode seed, there are a few things you can try. First,
## R

you need to make note of the template and variant of the failing seed. This can be easily identified just from looking at the seed OBJ name. The first part of the highlighted portions below are the template names. The second
parts (after the "-") are the variant type.
DR08-
-9F100289.obj
Frenzy-Y
-- Template Name:
, Variant Type:
Frenzy
Y
DR08-
-9F1002BC.obj
FRM-AddSY
-- Template Name:
, Variant Type:
FRM
AddSY
DR08-
-9F1000B6.obj
Blender-A1
-- Template Name:
, Variant Type:
Blender
A1
## One thing to note is that the template

is an exception and not an actual test itself. It is a blend of different Dragon templates, rather. Instead of running one template on all threads, it mixes them up and can run
## Blender

multiple templates in one seed, a different one on each thread. You can identify which template is running on which thread by going to the release directory. There is a .csv file which will show this. Below is a path to an
## example .csv file:

\\amr.corp.intel.com\ec\proj\mpv\fm_mpv\silo\Dragon\OBJ\BDW\System\4588_0x9F_4C8T_Halo
_2015_01_06_13_54_19.csv
## \info\DR08-9F1\ThreadNames

If you open the .csv file, you can search for your seed of interest (1st col). The 2nd column contains the Test names in thread order. The 3rd column contains the Test-variant names in thread order.
DR08-Blender-A1-9F1000B6        Flipper:Flipper:FRM:Yakko:FRM:Aes:Flipper:Flipper        Flipper:Flipper:FRM-Tran8SY:Yakko-PdY:FRM-SqrtDY:Aes-X:Flipper:Flipper
Ok, so you have your failing template/variant of your  mode seed. Now what?
R
Does your seed release also have  or
## mode seeds? If so, run the  or

mode seeds of the same template/variant. Best case scenario, is one of these also fails, then you can port that to the tester instead.
S
M
S
## M

If this does not yield any failures, file a sighting in the MPV HSD (instructions below), and we can generate  mode seeds for a lot (but not all) templates. The caveat of these is that if the failing signature is a data
## E

mismatch, it likely won't reproduce with an  mode seed since it uses arbitrary data. If your failure is a machine check, these may work.
E
1.
2.
3.
4.
1.
2.
3.
4.
Depending on the product, there may be a chance that PSMI or broadside is supported.
What the Dragon Team Needs From You
## Information Required for an HSD Sighting

At the bare minimum, we need the following items in order to assist in debugging a failure:
Product
## Stepping

Environmental conditions failure is seen at.
Voltages
## Frequencies/ratios

Temperature, if there is any thermal control on the platform.
Name of failing seed(s).
Dragon log file(s), which should show VVAR information.
If using Orion, log file can be found on the host PC hard disk (Show Log Files button). File name will be same as failing seed name. Normally, only log files for failing tests are saved by Orion.
Orion also produces a MemoryDump OBJ file, which can be useful for complex debug.  Please include it!
If using MerlinEFI, log file can be found on target hard disk: DR-Testname.obj results in a DR-Testname.obj.var log file.
Note that this is only the last instance of running the test! If a test fails multiple times in different ways, you'll need to collect that file or its output each time – it is also printed to the console/serial
out.  Fusion will do this collection automatically and store it in the automation run log folder (the same folder with the HTML per-test result summary) for the cell (i.e. instead of on the target storage).
If the failure is easily reproducible, MerlinEFI can also produce a MemoryDump .dmp file if run with -df: merlin.efi -df -a testname.obj
## TBD: MerlinX pointers (likely the same folder in Fusion...)

Machine Check register dump, if failure results in a machine check or CatErr.
Remote system login information we can use to take a look at the failure.
If we do not receive all of the above, it makes debug more difficult and time-consuming. These will ensure we have all of the relevant information to proceed with debug. Once you have all of this information, you can proceed
to file an MPV HSD sighting.
## Getting MPV HSD Access

To request assistance with a Dragon failure, we require an HSD sighting be filed in the
.
## MPV HSD

If you do not have access to the MPV HSD, you need to:
## Go to

and request access to the group "amr\MPVHsd".
## IEM2

Once this is approved, use the Chrome web browser and go
to set up access.
## here

Either scroll down and locate, or type in the search bar, "mfg_platform_val.tenant".
Double-click on the icon, and if your access is in order, you should see the MPV HSD with queries down the left side of the browser, sightings down the middle column, and sighting details on the right.
## Filing an HSD Sighting

Once you have access, follow these steps to properly file an HSD sighting:
Open the
.
## MPV HSD

Click the "Create New Article" button in the top-left corner. It is the icon of a page with a + on it.
## Click "New mfg_platform_val.sighting"

Enter relevant info into the fields as necessary.
## HSD Fields Guide

Here is a guide to help you file an HSD sighting with the appropriate information. Please fill out all of these fields to the best of your knowledge to ensure proper attention.
Title - Prefix this with the product in square brackets. Ex: [HSW], [BXT], etc.
Description - Provide a meaningful description of the issue and the environmental conditions (voltages, ratios, temperature, etc) it is occurring at. This field cannot be edited after the HSD is submitted, so make sure
to be very detailed here.
Sighting Information
## component: Software

software_subcomponent (shows up when Software is selected above): Test Content
processor_chipset_affected
status: open
processor_chipset_stepping
priority
reason: new
env_found
market_segment
Content Specific Fields
## type

## content_area: Core (most likely, if a Dragon failure)

content_release_num (First 2 digits of seed #, as specified in
on this page)
Finding the SVN Revision
content_test_name
content_type: Dragon
vertical_owner: Your name
Analysis
visual_id (of failing unit)
release
## Attachments

Attach Dragon log and any other relevant files here.
## System to Tester

For failures on all types of Dragon releases (CMV, THR, DPM), the end-goal is usually to get the failure to the tester. To do this, you will have to work with your particular tester teams for the exact steps. They are typically the
ones who create the conversion scripts, and they can vary greatly between products.
The main requirement for a seed to be tester portable is simple: No reads/writes to DDR. All traffic stays on chip. By this definition, all modes of Dragon are tester-portable except  mode seeds. However, only in certain
## R

cases, typically 2-core client, is the physical seed run on system directly portable. Server in particular generally has a sharp divide between system and tester given the core counts.
Tester Test Modes
MLC Mode
Example: D
_Frenzy_Y_0020011A.obj
M02
Target Domain: Core, L1, most L2
Directly loaded into MLC.
Only lower ways of MLC are exercised, not full MLC.
Runs entirely in core.
Does not exercise path between Core and LLC.
S-Mode (Slice)
Example: D
_Frenzy_Y_0020011A.obj
S02
## Target Domains: Core, L1, L2, some LLC

Directly loaded into LLC. Same 2-threaded test is run on all cores.
Only lower ways of LLC are exercised, not full LLC.
No traffic on Ring. No core-to-core traffic.
S-Mode (Full Chip)
Example: D
_Frenzy_Y_0020011A.obj
## S08

Target Domains: Core, L1, L2, some LLC, Ring/Mesh
Directly loaded into LLC.
Only lower ways of LLC are exercised, not full LLC.
Exercises ring/mesh and can have core-to-core traffic.
L-Mode (Full Chip)
Example: D
_Frenzy_Y_0020011A.obj
## L08

## Target Domains: most LLC, Ring/Mesh; also Core, L1, L2

Same as S-Mode (Full Chip), but (mostly) full LLC is exercised.
These are typically only used for debug.
Test time and size is quite a bit longer than S-Mode (Full Chip) since there is more data to chunk through.
E-Mode (Full Chip)
Example: D
_Frenzy_Y_0020011A.obj
## E08

Target Domains: LLC, some eLLC (if EDRAM exists), Ring/Mesh, MC; will use Core, L1, L2 as well
Directly loaded into LLC.
Only a subset of Dragon tests are E-Mode capable.
Does not do any data checking due to using the Read Return DFX.
Can only be used for Machine Check detection.
Test time is quite a bit longer than S-Mode (Full Chip) since there is more data to chunk through.
## System to Tester Flow

When a failure is observed on the system, the typical goal is to be able to observe the same failure on the tester to create a screen for the class test program. In order to do this, there are several methods of porting the failing
content. These methods can differ greatly between different products, so there is not a one-size-fits-all solution.
## Direct Port

History: Dragon was designed to be easily ported to the tester. The first successful direct port was accomplished on the Nehalem-family. It was then the main method to close miscorrelations starting with
Sandy Bridge, when PSMI started being phased out.
How: To direct port a Dragon test to the tester, all that is required is the test.obj. This is where the methods vary by product, but for the client products, a template dummy pattern was generated by the tester
teams. This template contained all the necessary tester flows, such as reset, load, and check test result. During the direct port flow, the load vectors were replaced with the data/addresses from the test.obj,
while everything else in the template was the same. This made it easy and quick to directly port thousands of tests in a short period of time.
## Can be used for:

DRG-E - on products with Read/Return DFX.
DRG-L - on products with an L3.
DRG-S - (slice and FC) on products with an L3.
## DRG-M

## PSMI (Periodic System Management Interrupt)

History: This was the main method to port content to the tester back in the day. It required very expensive logic analyzers and probes. The last product to have successful probed PSMI in CMV was
Nehalem. It is still existent on current client products, but now in a probe-less variant, which eliminated the need for the extremely expensive logic analyzers and probes. It typically requires much more
enabling effort from the tester teams, each trace has to be emulated separately, and PSMI traces take up large amounts of tester memory. Because of these reasons, Direct Port is the preferred method.
PSMI patterns are typically only used as a last-ditch effort if direct porting tests does not close miscorrelations. They are also only used for tester debug instead of being included in a class test program for
the aforementioned reasons.
How: The PSMI handler was injected at a periodic interval, which essentially puts the CPU into a known state. The debugger would set up a trigger on the LA, typically OUT F8 for a failure on FTS/DRT
/DRG content. When the LA sees this transaction on the probed signals in the event of a failure, it would then capture a
of all the transactions that occurred since the last known good state (PSMI
## trace

handler). This trace would then be run through emulation to compare what
## happened in the CPU to what

have happened. If there was a difference in the two, this trace was considered a
actually
should
## div

trace, meaning that the CPU diverged from what should have happened under normal operating conditions. The "should have happened" portion was then run through TVPV vector flows to generate
erging
a tester pattern.
## Can be used for:

All modes of DRG, although there isn't much reason to use it on any Dragon content besides out-to-memory tests. PSMI has only been recently used to port failures to the debug tester (vs HVM
tester) for the Component Debug teams.
Broadside
[need info here]
Can be used for:
All modes of DRG.
Other Resources
Dragon VVARs
## Dragon VVDEBUG Decoder

A tool for checking or setting the individual bits of VV[0x3] (the debug bits vvar).
Dragon VVOUTPUT Decoder
Error Codes
## Dragon Error Decode

A tool for decoding a failing signature into a plain text description on what may have failed.
## Dragon Bucketer

Similar to the full decoder, but higher level and more integratable.
Ouroboros
Log parser and visualizer.
Dragon IP Test Strategy (IPTS)
Incoming links

Page: Dragon Content Shepherding

Page: Dragon Reference

Page: Dragon Shepherding Resources

Page: Dragon VerticalTeamTraining

Page: Ouroboros Documentation
Contributors
User
Edits
Comments
Labels
Valentine, Joshua H
23
0
0
Rawson, Justin J
2
0
0
Mayhue, Mallory A
1
0
0
Porter, Benjamin M
0
0
1
