# Dragon BasicDebug

> Source: 01_Dragon BasicDebug.pdf

1 Things to Know
2 Initial Debug
3 Blender Example
4 Incoming links
5 Contributors
Things to Know
What Product/Stepping are you using?
What seed release are you using and have you read the 
 notes?
release
What error codes were reported and which seeds reported them?
Dragon Error Decoders automate many (though not all) of the steps below.
If you seek help from a member of the Dragon team, they will want to know the answers.
Initial Debug
TBD
Blender Example
Product: JKT C0
Seed: DRG-R20-Blender-SY-39200041
Error: VVAR[0x17] = f0000f01
Blender seeds contain a mix of algorithm types, so you have to figure out which algorithm is failing. Normally Orion (CMV's automation software) will tell you, but if that information isn't available, we can check manually.
Goto 
 find release 0x39 (since the seed number is 0x
200041) and follow the link. The release page often has important information to be aware of. In this case it lets us know that the content has run clean 
Dragon Releases
39
in the past and where to find the original seeds (\\amr.corp.intel.com\ec\proj\mpv\fm_mpv\Silo\Dragon\xMan\JKT\C0-2648).
Note that as an R20 seed, this is a DP seed (JKT has 8 cores, hyperthreaded, so 16 threads per package. 0x20 threads = 32 threads, thus DP). Go into the DP directory and then the info directory. The file you want is DRG-
R20-Blender.csv.
Dragon VVARs give you information on how to decode the VVARs. In this case since per thread status starts at 0xC and your failure is on 0x17, we know thread 11 failed. Now if you go back to your .csv file and look at line 
1136 you will see that thread 11 is a FRM-MMulHSY algorithm. Alternatively, you could convert your .obj file to ascii and check the symbols at very end of the file and they will tell you the same thing (which is how Orion is 
supposed to know).
For VVAR[0x3] (the debug flags), the 
 page will help you translate the value of VVAR[0x3] and what debug flags were set.
Dragon VVDEBUG Decoder
Now that we know the algorithm that is failing we can go to 
 and take the link to FRM. On the FRM page under Error Codes we can see that f0000f01 means a test failure with QWORD 1 
Dragon TestDescriptions
miscomparing.
This tells you that the test did run normally (so no issues with something we need fused off or similar seed/platform incompatibility), but the test failed with a miscompare. Since we also know from others using the seeds 
without any logic issues (we read that on the release page) the seeds are good, it looks like you hit a speedpath. Repeat the test under relaxed environmental conditions and it should pass.
If your question is what is the speedpath? Then it is time for LCP or something like that. From the FRM algorithm description page you get “MMulHS: (Reference based) Performs a matrix multiply on in1[ij] and in2[i] and 
stores in per-thread out[i].” which may also help direct you, but it could just as easily be the store operations as the horizontal multiplies or something else completely.
Incoming links
 
Page: Debug Considerations
 
Page: Dragon
 
Page: Dragon - IPTS
 
Page: Dragon Reference
 
Page: DragonSecure
 
Page: STC Content Types
Contributors
User
Edits
Comments
Labels
Valentine, Joshua H 
22
0
0
Rawson, Justin J
1
0
0
