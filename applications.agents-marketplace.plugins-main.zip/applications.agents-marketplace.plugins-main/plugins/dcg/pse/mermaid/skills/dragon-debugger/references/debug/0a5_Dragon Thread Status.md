# Dragon Thread Status

> Source: 0a5_Dragon Thread Status.pdf

## Overview

The 32-bit per-thread status/error code is stored in per thread vvars.
## These codes are generally the same between BM Dragon and

Dragon, but there are a few exceptions noted.
## DoL/TSL

Codes are added to over time, and may be context sensitive.
Pass is 0x600D600D/0xaced on BM, and 0 on OS/DoL/TSL.
Any other code is failure or corruption of some sort.
## Decoders

Dragon team provides several tools capable of decoding these values.
Dragon Bucketer: Python script for (sub)bucketing failure types.
Dragon Error Decode: web-based full decode (1 code at time).
Ouroboros: Windows app for consuming bulk logs into tables and graphs (also embeds Bucketer and Decoder).
Additionally, in multi-team partnership, the PPV Server Dragon vvars are charted and bucketed on DANTA:
## goto/danta > Silent DANTA (upper right) > Vvars Analysis (mid left)

Access: AGS: DANTA-APPLICATION READ ONLY ACCESS
## Owners/Components

## TLO owner (visualization/manipulation, web): Josue Baltodano

PPV Server owner (data): Luis D Rojas Munoz
Dragon Bucketer integrated
3 default charts are pre-configured.
They can be adjusted and/or filtered on the web.
Change chart type to TSV to export.
Finding the Codes
## BM

The start of the per-thread error codes is vvar[0xc].
But it's safer to use _Status32_Summary_Addr (if present) as the starting addr in case this moves.
_Status32_Summary_End is the addr after the last thread.
## The

lists the per-product indexes.  Products are grouped into count "bands" to limit the vvar counts on smaller products.
## VVARs wiki

VVars outside this range are for other purposes and have different meanings and decodes.
vv[2].bits[15:0] indicates the # of running threads, and thus which of the status slots are in use (starting from the first status slot).
## Dragon Thread Lookup and

detail how to determine and control which test thread/algo ran on which HW thread.
Dragon Thread Mapping
Tester
DR0 contains the 32-bit code.
Note that, aside from Atom no_snoop L2 SBFT, the BSP thread aggregates the pass/fail status across the threads.
0x1040 is loaded into the BSP thread very early in the Dragon startup to indicate the test started.
0xaced (BSP) or 0x600D600D indicates test completed and passed.
Anything else indicates failure or corruption of some sort.
## DoL/TSL

On a fail, the log lists the per-thread status.
DoL Log Interface
## Console/txt log example:

Jun 22 11:20:55: FAILURE : DR02-BR-87400125.obj : Core 015 FailMask 0x2 (0xc000000E, 0x00000000) at (0x2205e03e, 0x00000000) for (0x2605abcd, 0x00000000) algo (LN, PE)
The first () after FailMask is the status code.  Thread 0 in the BigCore / Atom Module is on the right.
## Code Groups

The top nibble of the 32-bit code indicates which overall "group" it belongs to.
## But the actual failure

isn't strictly aligned with that (esp for "#GP").
bucket/priority
## Historical Status Priority

This section is preserved for historical purposes.
It has been superseded by the more thorough and maintained
.
## Dragon Bucketer

As of Build 3.9.16 Horizon Agent no longer reports failures in thread order. Instead, they are reported based on the following priority.
Version 1 indicated by Dragon symbol: _1_errorCodeVer
round1:
all tier 1 (1-5, 7)
## unique tier 2 (A-D, F)

## A-D: use the low byte (bank or vector) for uniqueness

## Soft and Sympth MCE are broken out into tier 3 and 4

F: all the rest of the bits (low 28) are compared for uniqueness
unique tier 3 (SoftMCE)
round2:
dup tier 2 (A-D, F)
dup tier 3 (SoftMCE)
all tier 4 (SympthMCE, 0)
Status Codes
Top Nibble
Code Group
Decode
0x0
decode is env specific
## 00000000

BM: Thread running/timeout, or thread not used.
OS/DoL/TSL: Thread passed.
00001040 - BM DR0: Test started.
0000aced - BM DR0: Thread passed.
0x1, 0x2
issue during BM startup/teardown
BM Dragon Startup Codes
0x2
## DoL/TSL: Test did not start

0x22###000 to 0x27###000 - DoL/TSL test did not start cleanly, no Dragon code executed.
0x3
not currently used
3####### - Not currently used.
0x4, 0x5
## missing feature

Dragon SVN r6207 switched from 0x5 series to 0x4 series to widen the cpuid index to support more registers.
## TSL >= 3.9.1 implements

and reports 0x4 series codes in the per thread status.
cpuid ISA checking
48232323 /
- PATCH2/3 is not enabled!!!
5B232323
## 4Tyyyzzz /

- CPUID Mismatch: Expected feature is not enabled on this part. i.e. AES, AVX, etc...
5Txxyyzz
See
for details.
CPUID Feature Codes
0x6
decode is env specific
600D600D - BM: Thread passed.
0x7
## BM thread counting issues

7000xxxx - Unexpected number of threads responding to SIPI. xxxx - thread logical ID of the extra thread.
7FFFFFFF - Corruption of thread ID.
0x8, 0x9
not currently used
8####### - Not currently used.
9####### - Not currently used.
0xA, 0xB
## BM logged MCE

## Axmmmmii/Bxmmmmii - Machine Check Exception (MCE) failure

bit 26: Hard/uncorrected MCE failure due to unexpected interrupt 18. If clear, soft/corrected MCE.
mmmm: MSR number in middle word.
ii: Bank index in low byte.
Ax000000 - This thread is a sympathetic MCE. The actual failure is in another thread.
Look for another thread that isn't all 0s in the m's of 0xAxmmmmii/0xBxmmmmii and decode that instead.
See
for 'unofficial' bank decode.
Dragon IAMCE
0xC, 0xD
## special error code or x86 interrupt

C#xxxx##/D#xxxx## - Special error code or unexpected interrupt/x86_Fault.
## Dragon Special Codes

Overloaded into "#GP" space by abusing unassigned handler behavior.
## BM Dragon Barrier Codes (mostly PM flows)

## DoL/TSL Special Codes (produced by app into thread status slot)

x86_Fault (unless one of the special error codes in the prev sections)
Vector in low byte.
0xE
not currently used
E####### - Not currently used.
0xF
## Test algo reported issue

F####### - Test algo reported issue (test result is in low 7 nibbles).
Details are on the individual test algo pages linked from
.
## Dragon Test Descriptions

Generally: Data_Miscompare, or in some cases Config_Mismatch.
## BM Dragon Startup Codes

10000001 - Extra threads reported in after thread sort. System threads is set below the actual number of threads in the system.
10000002 - System threads is not configured properly. System threads must not be empty with min and/or max APIC limits set, and it must equal running threads with no snoop and/or tester mode enabled.
10000003 - Total threads in the system is not equal to system threads.
10000004 - System threads/VVar2 running threads is not configured properly. System threads is less than VVar2 running threads.
10000005 - Desired VVar2 running threads is greater than the total generated number of threads in the seed.
10000006 - VVar5 (Max APIC ID) set to less than VVar4 (Min APIC ID).
10000007 - VVar2 running threads exceeds range of available APIC IDs (Max APIC ID - Min APIC ID + 1).
10000008 - VVar2 running threads is not an even multiple of the number of packages.
10000009 - Startup ran beyond end of thread table searching for free active thread block for current thread.
1000000A - The number of assigned, active thread blocks exceeds VVar2 running threads.
1000000B - VVar2 start package and/or expected system packages are not configured properly. The start package plus the number of packages generated for this seed exceeds the number of expected system
packages.
1000000C - Expected threads per core does not match the runtime threads per core.
1000000D - Expected threads per module does not match the runtime threads per module.
1000000E - VV_THREAD_ROTATE or VV_THREAD_SWAP_XOR incorrect.
VV_THREAD_ROTATE not in the range of +/- (VVar 2 running threads).
Single socket seeds: VV_THREAD_ROTATE is not a multiple of threads per core/module.
Multi socket seeds: VV_THREAD_ROTATE is not a multiple of threads per package.
Multi socket or multi die per socket seeds: VV_THREAD_SWAP_XOR is not allowed.
Multi die per socket seeds: VV_THREAD_ROTATE is not a multiple of threads per die.
1000000F - TSC/ACNT is not incrementing.
10000010 - Expected dies per package != runtime dies per package. Cpuid leaf 1F topology does not match that expected during seed generation.
203b154d - WBINVD at end of test initiated but did not complete.
20xx020x - INIT/Shutdown occurred during the test startup.
## Starting value:

, the 3 pieces of info below are added (NOT or'ed in).
## 20200202

Number of threads will be added to upper word.
Add 2 to low word if INIT occurred in PM64 mode.
Add 1 to low word if number of threads is valid.
20000001 - ERRCODE_BADSYMBOL: generation error, or a corrupted memory image.
CPUID Feature Codes
## 4Tyyyzzz /

- CPUID Mismatch: Expected feature is not enabled on this part. i.e. AES, AVX, etc...
## 5Txxyyzz

## T is the total missing feature count (for that seed on that system)

(yyy, zzz) or (xx, yy, zz) represent the lowest bit indices of the given register/register combination that are miscomparing.
FFFh is the default value
## 000-01F - CPUID1 ECX check

## 020-03F - CPUID1 EDX check, in order to decode subtract offset 20h

## 040-05F - CPUID80000001 ECX check, in order to decode subtract offset 40h

## 060-07F - CPUID80000001 EDX check, in order to decode subtract offset 60h

## 080-09F - CPUID7 subleaf 0 EBX check, in order to decode subtract offset 80h

## 0A0-0BF - CPUID7 subleaf 0 ECX check, in order to decode subtract offset A0h

## 0C0-0DF - CPUID7 subleaf 0 EDX check, in order to decode subtract offset C0h

## 0E0-0FF - CPUID80000008 EBX check, in order to decode subtract offset E0h

## 100-11F - CPUID7 subleaf 1 EAX check, in order to decode subtract offset 100h

## 120-13F - CPUID7 subleaf 1 EBX check, in order to decode subtract offset 120h

## 140-15F - CPUID7 subleaf 1 ECX check, in order to decode subtract offset 140h

160-17F - CPUID7 subleaf 1 EDX check, in order to decode subtract offset 160h
Examples:
## Example: 0x41FFF01E

T==1 only one mismatch; yyy==FFF; zzz==01E or bit 30 of ECX, so rdrand was expected but unavailable.
Example: 0x4400007D
## T==4 mismatches; only 2 visibly output

## yyy==000 first fail first bit cpuid1 bit 0 of ECX: SSE3 extensions

zzz==07D second fail cpuid80000001 bit 7Dh-60h=1Dh, bit 29 of EDX: Intel 64 Arch
## Example: 0x5100FF1E

T==1 only one mismatch; yy==FF, so ignore xx==00; zz==1E or bit-30 of ECX, so rdrand was expected but unavailable
Example: 0x54007d84
## T==4 mismatches; only 3 visibly output

## xx==00 first fail first bit cpuid1 bit 0 of ECX: SSE3 extensions

## yy==7d second fail cpuid80000001 bit 7dh-60h=1dh, bit 29 of EDX: Intel 64 Arch

zz==84 third fail cpuid7 84h-80h=04h, bit 4 of EBX: HLE
## See the CPUID instruction in the

(Vol 2 ISA, and separate ISE) for more info.
## public Software Developer Manuals

Unreleased feature bits won't be described in the public manuals however.
Dragon Special Codes
(Mostly BM) Dragon special error codes.
Overloaded into "#GP" space by abusing unassigned handler behavior.
## A few of these flows

be hacked into OS/DoL/TSL seeds, but are not produced by default.  They are sometimes forced on in Dragon dev regressions.
can
DRNG, testbench
C#01120D - DRNG: BIST failed.
C#01320D - Testbench: When testbench mode is enabled, certain tests will check each result and immediately exit with this int vector on fail for easier debug.
## C#01420D - PM state timeout: failure while trying to acquire the lock

C#01520D - VM exit: Unexpected VM Exit occurred while running under VMX mode.
C#01720D - DRNG: 2 consecutive numbers matched.
C#01A20D - PM state: failed to restore to original value.
C#01B20D - Spurious interrupt received during cstate wakeup flow.
C#01C20D - Turbo Ratio MSR did not contain requested core count.
C#01E20D - Failure attempting to communicate with the Bios OC Mailbox.
C#01F20D - Hardware P-States (HWP) are enabled. This breaks all Dragon PM flows.
C#02020D - MSR 0x199 core ratio request is not the same across all threads. This will cause inconsistent state restore.
C#02120D - MSR 0x620 UFS ratio range is not the same across all threads. This will cause inconsistent state restore.
C#02220D - PKRU/PKRS read did not match write.
C#02320D - A DUT/NUT mismatch occurred in a turbo or FACT config or setting.
C#02420D - A FACT (SST-TF) command failed.
C#02520D - Failure processing PCI segments.  SVN >= r7214.
## C#02620D - HPM- or TPMI-related failure.  Possible issues:

Out of bounds when accessing a TPMI table
HPM LTRL core count estimation failed
Turbo mask shift out of bounds
BM Dragon Barrier Codes
## BM Dragon PM/NMI barrier stages:

D#001017 - C-State init flow failed. Presume dropped NMI.
D#001117 - C-State sleep action flow failed. Presume dropped NMI.
D#001217 - C-State wake action flow failed. Presume thread failed to wake from mwait.
D#001317 - C-State finalize flow failed. Presume dropped NMI.
D#002017 - P-State init flow failed. Presume dropped NMI.
D#002117 - P-State action flow failed. Presume dropped NMI.
D#002217 - P-State finalize flow failed. Presume dropped NMI.
D#003017 - End-of-test WBINVD flow failed. Presume dropped NMI.
D#004017 - Turbo Init flow failed. Presume dropped NMI.
D#004117 - Turbo action flow failed. Presume dropped NMI.
D#004217 - Turbo post ratio verify flow failed. Presume dropped NMI.
D#004317 - Turbo action wake flow failed. Presume thread failed to wake from mwait
D#004417 - Turbo action sync flow failed. Presume dropped NMI.
D#004517 - Turbo finalize flow failed. Presume dropped NMI.
D#004617 - Turbo Init flow failed.  An Idle thread failed its PM domain topo init and did not respond to the driver thread (no NMI).
D#005117 - One or more UFS requestor threads failed to request uncore ratio.
D#005217 - One or more UFS verifier threads failed to verify uncore ratio.
D#005317 - One or more UFS requestor/verifier threads failed to enter ready state.
D#006017 - FACT (SST-TF) init flow failed. Presume dropped NMI.
D#006117 - FACT (SST-TF) action flow failed. Presume dropped NMI.
D#006217 - FACT (SST-TF) finalize flow failed. Presume dropped NMI.
D#007017 - Error occurred in Sanity-TF while in an indeterminate flow state (state = null).
D#007117 - Error occurred in Sanity-TF while in the driver init state.
D#007217 - Error occurred in Sanity-TF while in the requestor thread DUT/NUT mismatch check state.
D#007317 - Error occurred in Sanity-TF while in the requestor thread init state.
D#007417 - Error occurred in Sanity-TF while in the verifier thread init state.
D#007517 - Error occurred in Sanity-TF while in the requestor thread init state, part 2.
D#007617 - Error occurred in Sanity-TF while in the FACT min/max range-setting state.
D#007717 - Error occurred in Sanity-TF while in the request state.
D#007817 - Error occurred in Sanity-TF while in the verification state.
D#007917 - Error occurred in Sanity-TF while in the verification complete state.
D#007A17 - Error occurred in Sanity-TF while in the restore state.
D#007B17 - Error occurred in Sanity-TF while the driver was traversing PCI configuration space or initializing MMIO base addresses.  SVN >= r7214.
## DoL Special Codes

## DoL/TSL special error codes (produced by app into thread status slot):

0xC0FFC0FF - Error prevented test thread from starting.
0xDEAD0B0B - Test did not complete within expected time and thermal throttle events were detected.
0xDEADAB04 - Buffer overflow or heap corruption.
0xDEADBAB4 - LPU disabled (skipped thread execution).
0xDEADBEA7 - Unhandled interrupt occurred.
0xDEADBEEF - Test was process priority starved and spent little time actually running.
0xDEADDEAD - Test did not return within timeout.  Likely hung, in the weeds, or faulted badly.
0xDEADFADE - LPU process killed or shutdown.
Incoming links

Page: Dragon

Page: Dragon - IPTS

Page: Dragon BasicDebug

Page: Dragon DebugATest-Tutorial

Page: Dragon DebugInfo

Page: Dragon DoL

Page: Dragon DoL Interface

Page: Dragon DoL ISA Check

Page: Dragon DoL PPV and CMV Usage

Page: Dragon DoL Time Control

Page: Dragon Interrupt_Table

Page: Dragon Reference

Page: Dragon Sanity

Page: Dragon TesterDebug

Page: Dragon Thread Lookup

Page: Dragon Thread Mapping

Page: Dragon VerticalDebugGuide

Page: Dragon VVARs

Page: Dragon VVARs 2022 SVN 7030 to 7218

Page: Dragon VVARs 2023 SVN 7218 to 7621

Page: Dragon VVARs 2024 SVN 7519 to 7810

Page: Dragon VVARs 2025 SVN 7810 to 8178

Page: Dragon VVARs Sandbox

Page: Dragon ZSIM

Page: Ouroboros Documentation

Page: STC Content Types
