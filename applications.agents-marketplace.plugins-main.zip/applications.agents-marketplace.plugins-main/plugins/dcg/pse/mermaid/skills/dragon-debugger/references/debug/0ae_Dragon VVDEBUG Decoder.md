# 28

> Source: 0ae_Dragon VVDEBUG Decoder.pdf

27
26
25
24
23
22
21
20
19
18
17
16
15
14
13
12
11
10
9
8
7
6
5
3
2
Dragon VVDEBUG Decoder
Dragon VVAR 3 (Debug Flags) decoder:
 
 
Value for VV_DEBUG: 0x
Bit Meanings. Click to toggle.
Ignore INIT flag. Dont fail if this flag has been set.
System Only: All WBINVDs will be skipped during the test.
SKIP SIPI. Used for single thread mode or for simulation where other mechanism for waking up SIPI is used.
SVN r1330-r6912: Create the unique GDT and IDT for each thread that Eswift/Capsule requires.
PROC_SPECIFIC_DFX, set by Dragon during generation, do not modify unless directed to do so.
JKT enables WDAR mode
ANN enables code to remap 2nd BSP to an AP
NO_SNOOP: If set, skip startup accesses which create cross thread snoops; needed for compatibility for certain tester SBFT modes. Must be generated with this set because algorithm cross-thread snoops 
are only prevented at generation time, not runtime. Undefined or strange behavior on system. Do not modify unless directed to do so.
DFX SIPI: Set for MLC and Slice mode on tester.
Simulation Flag. Will be set if test is running on Archsim.
Tester Mode: Startup code flow will be SBFT compliant and run tester specific code.
JMP-SELF in Tester Mode: When set, all threads will end with a JMP $ instead of a halt.
<= SVN r7731: If set, prefetching cache will occur. Needs to be enabled in test as well.
<= SVN r7731: Disable prefetching. Currently only on SNB/IVB.
Counter check. Verifies that TSC is running. Don't use this with Archsim!
If set, power management functionality is turned off for seeds that have c-states or p-states enabled. Also useful for e-swift, esp since APIC is used.
If set, VMX functionality is turned off for seeds that have vmx enabled. Useful for debug.
If set, TLA trigger ( OUT 0xf8 ) will be skipped
If set, test will exit immediately on any failure.
If set, test will skip all RDRAND sparks and DRNG PBIST code
If set, test will skip all RTM sparks
If set, cycles expended for certain features are reduced. Intended for initial pre-silicon enabling.
SVN r4686-r5120: If set, test will skip all PCOMMIT code. Pcommit instruction was dropped prior to any product release. When running any SKX Dragon seeds between these 2 revs, set this bit. Newer 
Dragon seeds do not include pcommit and ignore this bit.
If set, APs in test will skip jump to end_test_case_start after AP_halt for SBFT Loader to intercept and handle.
If set, CMCI will be enabled. Instead of only checking for soft MCEs at the end of the test, when the Soft MCE Threshold vvar is exceeded, an interrupt will be triggered. Dragon will report the appropriate 
MCE failure code.
>= SVN r5154. If set, PM enabled seeds will skip the end of test PState restore verification.
>= SVN r6752. If set, disables most of the PagingRights usages and restrictions (except Atom module SBFT).
>= SVN r7027. If set, utilize runtime lockstep WAs (such as half CPM count on SRF).
Clear All
