# 16

> Source: 0af_Dragon VVOUTPUT Decoder.pdf

15
14
13
12
11
10
9
8
7
6
5
4
3
2
1
Dragon VVOUTPUT Decoder
Dragon VVAR 0xA (Output Flags) decoder:
 
 
Value for VV_OUTPUT: 0x
Bit Meanings. Click to toggle.
INIT/Test started flag. Used to detect shutdown where test may run 2nd time due to reset.
Flag for booted x2APIC; set by BSP only, checked by all
Flag for BSP x2APIC is active; set/checked by BSP only (prior to r4701, checked by all)
Flag for booted or forced to x2APIC; set by BSP only, checked by all. We exit the seed in x2Apic if forced to x2Apic.
Flag indicating automatic socket selection (automatic setting of min and max APIC ID for DUT selection)
Flag indicating automatic thread reduction (automatic setting of running threads less than generated threads)
SVN >= r5361: Flag indicating this was generated as a decap seed.
SVN >= r5361: Flag indicating this was generated as a VMX seed. VV_Debug VV[3].bit17 disables VMX at runtime.
SVN >= r5361: Flag indicating this was generated as a PM C-State seed. VV_Debug VV[3].bit16 disables PM at runtime.
SVN >= r5361: Flag indicating this was generated as a PM P-State seed. VV_Debug VV[3].bit16 disables PM at runtime.
SVN >= r5361: Flag indicating this was generated as a PM Turbo seed. VV_Debug VV[3].bit16 disables PM at runtime.
SVN >= r5872: Flag indicating this was generated as a User Level Wait seed. VV_Debug VV[3].bit16 disables PM/ULW at runtime.
SVN >= r5959: Flag indicating this was generated as a PM UFS seed (ignore if P-State/Turbo bits 10 and 11 are both clear). VV_Debug VV[3].bit16 disables PM/UFS at runtime.
SVN >= r6941: Flag indicating this was generated as a PM FACT seed. VV_Debug VV[3].bit16 disables PM at runtime.
SVN >= r7088: Flag indicating this was generated as a LittleFoot (LF) seed. This generates as a small bundle of threads, and then replicates them at runtime to scale to higher thread counts.
SVN >= r8251: Flag indicating at least one thread failed. This is only set if atomic locks are allowed (which they aren't in iso-SBFT, and Dragon doesn't do in RO/MO/RC SBFT either).
  
Clear All
