# Dragon

> Source: 000_Dragon.pdf

1 Overview
1.1 Focus
1.2 Properties
2 Customers
3 Developers
4 Incoming links
5 Contributors
Overview
Dragon is a self-checking bare metal (and ring3 OS) test suite owned and developed by MIT STC. It has been used across all market segments for CMV/tester since 2008 and PPV since 2013.  Dragon aims to generate 
effective test content and enable efficient development with a maintainable code base.  This is the homepage for the user focused information for Dragon and it and the pages under it are view-able Intel wide.
Dragon Presentations
Especially: 
 and 
2023 Quick Overview
2017 DTTC
Extracted subset: Dragon Thumbnail 2023
DoL/TSL User Guide Pres
More detailed training: 
 (updated slides) or 
2019 Dragon Overview
2016 August recordings
 Overclocking tool (released outside Intel for over-clocking SKUs)
Intel Performance Maximizer (IPM)
Underneath this used (a sampling of) bare-metal Dragon objs as the test content.e
EOL'ed in Q2'23, had been externally released with CFL/CML, RKL, and CLX (internal dev on SKX). 
Dragon OS Loader aka DoL (Dragon on Linux) aka TSL (Test Seed Loader): uses the same algorithms (with minor limitations) as BM Dragon, but running under Linux/Windows
Still NDA only for external use, part of Silicon Health Check (SHC) package
Focus
x64 IA: cores, caches, MC, etc
Speedpaths (CMV/HVCP)
DPM (PPV)
SBFT direct tester port
for class closure and debug (CD) of speedpaths and DPM
Though not a direct focus, Dragon has uniquely hit a variety of logic bugs across all market segments and been critical in their debug and resolution.
Testing Details:
Dragon - IPTS
Dragon Non-goals
Dragon Test Augmentations
Dragon Test Descriptions
Dragon Testing Improvements
Properties
Pre-generated seeds from ~30 targeted but randomized algorithms
~120-240 seeds for PPVm/TSL_breadth, ~1-2K seeds for CMV/THR/tester, ~5-7K seeds for TSL_depth+BR
Dragon team directly provides all content – external users do not develop or generate their own templates
Seeds are programmed to loop until a 
time limit
minimum 
Typically: 3 seconds for system, 100ms for TSL “Quest” mode, 1-10 million clocks for tester SBFT
Strong and moderately complex randomized test algorithms + general injected randomizations for efficient permutations and combinations
Uses and checks almost every non system/feature instruction in the x64 ISA with focus on vector instructions (esp FP)
BM Dragon has some system/feature instruction testing
x64 only aside from the snippet to get into x64
Code and data Generator in C# w/ our own c intrinsic/asm like interface
Algorithm verification using 
, 
 (replaced 
), and 
iasm/diasm zsim
Archsim
SDE
We’ve also filed and helped resolve numerous bugs and feature requests (and 
 too)
SDM
Bare-metal test environment – runs without an OS on system and is ideal for manufacturing-like environments (PPV, CMV, SBFT tester)
While not part of their validation suites, Dragon can run in other environments (e.g. FV, AV, ITG) if their automation/loader solution conforms to bare-metal content loader specifications for manufacturing 
 , or if they can leverage the manufacturing loader solutions
content
Partnered with DCG/DCAI starting in 2019 to additionally enable Intel and in-field OS based testing using ring-3 DoL/TSL based Dragon.
Customers
Check the 
 page and the pages directly under this homepage for most commonly used information.  If you need seeds or support for any reason, contact your Dragon Shepherd (see 
).
Reference
Dragon Public Contacts
Runtime input and output: Dragon VVARs
Dragon Thread Status
Dragon VVDEBUG Decoder
Dragon VVOUTPUT Decoder
Dragon TestDescriptions
Dragon Test Augmentations
Dragon Debug
Dragon Error Decode
Dragon Bucketer
Ouroboros
See also:
STC Wiki root
SRF listing of current 
.
Products Supported
Older versions of the org have their own product pages.
Developers
The 
 are in this wiki under the Secure heading and are restricted to users with PQV/MPV data access.
internal development pages
Incoming links
 
Page: [MTL][FUN][CORE] 1.1 Content overview
 
Page: APE
 
Page: APE Releases
 
Page: Content Repository By Target OS
 
Page: CW Migration efforts
 
Page: CWF-D Knowledge Brief
 
Page: Dragon
 
Page: Dragon - IPTS
 
Page: Dragon Content Delivery Process
 
Page: Dragon DoL
 
Page: Dragon FAQ
 
Page: Dragon Public Contacts
 
Page: Dragon Reference
 
Page: Dragon Reference Internal
 
Page: Dragon SharedDriveRenaming
 
Page: DragonSecure
 
Page: Glossary MIGRATED
 
Page: HowToUseAPE
 
Page: KNC MIGRATED
 
Page: Knight_Corner_Wiki MIGRATED
 
Page: Knights_Corner MIGRATED
 
Page: MIC Knights_Corner MIGRATED
 
Page: MPV Wiki list
 
Page: Old MPV Content Secure
 
Page: PTL FUN_ATOM SiRP
 
 > 
Comment: Dragon on Linux
Re: Dragon on Linux
 
Page: SCE CMV
 
Page: STC Content Types
 
Page: STC Training Materials - Full Catalog
 
Page: syl content
 
Page: Test MIGRATED
 
Page: Video Trainings
Contributors
User
Edits
Comments
Labels
Valentine, Joshua H
71
0
0
Rehman, Mohammed F
13
0
0
Mayhue, Mallory A
2
0
0
Franks, Steven C
1
0
0
Abu Talip, Muhammad Husni 
0
0
1
Ang, Ye Siang
0
0
1
Goh, Chee Hoo
0
0
1
Heagy, Stephen
0
0
1
Hidalgo Rojas, Andres
0
0
1
Kho, Jia Lin
0
0
1
Le, Christian
0
0
1
Lee, Boon Kooi
0
0
1
Livengood, Jason
0
0
1
Luyando, Jorel C
0
0
1
Ng, Ern Yik
0
0
1
Wan, Joey
0
0
1
Yong, Chee Min
0
0
1
