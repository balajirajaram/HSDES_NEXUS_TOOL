# Dragon Presentations

> Source: 03_Dragon Presentations.pdf

1 Dragon Presentations
1.1 Overviews
1.2 2024 November
1.3 2024 August
1.4 2024 April
1.5 2023 August
1.6 2022 DTTC
1.7 2022 April
1.8 2021 DTTC
1.9 2021 October
1.10 2021 February
1.11 2020 November
1.12 2020 October
1.13 2020 August
1.14 2020 January-March
1.15 2019 June
1.16 2019 April
1.17 2019 March
1.18 2019 February
1.19 2018 July
1.20 2018 June
1.21 2017 July
1.22 2016 August
1.23 2016 July
1.24 2015 May
1.25 2013 May
1.26 2013 January
1.27 2012 November
1.28 2012 October IDC F2F
1.29 2012 August DTTC Presentation
1.30 2012 June Penang F2F
1.31 2011
1.32 2010 April Penang F2F
1.33 Historical Presentations
2 Incoming links
3 Contributors
Dragon Presentations
This page contains links to current and historical presentations about Dragon the validation tool. The 
 is also a good resource for general questions.
Dragon FAQ
See also:
goto/DTTC
DTTC Search
Overviews
Dragon Presentations
Especially: 
 and 
2023 Quick Overview
2017 DTTC
Extracted subset: Dragon Thumbnail 2023
DoL/TSL User Guide Pres
More detailed training: 
 (updated slides) or 
2019 Dragon Overview
2016 August recordings
2024 November
 external v5.  DoL/TSL use external to Intel only cleared under NDA with certain key DCG customers under PRT direction.  Eventually intended to achieve general 
Dragon on Linux (DoL) External Users Guide
availability.  Not intended as a replacement of bare-metal Dragon.  Primarily intended for infield usage and associated correlation and closure.  Extended Mfg supplement.
Will try to kept the ppt version on the wiki updated when the external pdf is updated, but may become stale.  Best to use the externally linked "Dragon External Users Guide" pdf: https://cdrdv2.intel.com/v1/dl
/getContent/620322
Even better, check the user guide in the binary release for details on app cmds.
"Large" update in late 2021 from TSL to DoL, clarifications, new algos.  External pdf v3, wiki ppt v9.
Large update in external pdf v5, wiki ppt v10.  Fixed many technical and readability issues that had crept into ext v3 and ext v4 during unreviewed publishing steps.  Many updates in TSL app details and 
capabilities, some more minor Dragon updates and clarifications.
2024 August
Dragon_SHC_ww32'24.pptx
2024 April
: DMR, RRF/PMR, NVL: presented in SDE Squad ww16.5 (SoC v3) and ww17.5 (Core v4)
2025_PO.pptx
 presented in TLO Tech ww16.2
PPV_PM.pptx
2023 August
Dragon Quick Overview 2023
Extracted subset: Dragon Thumbnail 2023
Extracted subset: Dragon Tests 2023
Dragon EMB Team specifics
2022 DTTC
DTTC FC-SBFT with PEGA PM
Full title: FC-SBFT + PEGA content deployment for incoming DPM reduction on Xeon Products
Filename: DTTC_2022_Paper_FCSBFT PEGA_ v14_Final.pdf
poster ppt
Not by Dragon team, but partners, heavily referencing Dragon content
DTTC TSL Test Time Optimization
Full title: Data-driven Platform Quality Improvement by Test Time Optimization Features in Test Seed Loader
Filename: DTTC_2022_TSL_test_time_optimization_features.pdf
Not by Dragon team, but partners, heavily referencing Dragon content
2022 April
CMV Content Continuous Improvement.pptx
Presented in ww15.3'22 QRE/MPE Vmin GB Methodology WG
2021 DTTC
DTTC FC-SBFT Dragon on RKL
Full title: The Critical Role of SBFT Full-Chip Dragon Content in Rocket Lake
Filename: System_Health_Check SHC _DTTC_2021.pdf
Not by Dragon team, but partners, heavily referencing Dragon content
DTTC SHC
Full title: System Health Check (SHC)
Filename: DTTC_2022_TSL_test_time_optimization_features.pdf
Not by Dragon team, but partners, heavily referencing Dragon content
2021 October
Ouroboros Training in Weekly Training Dragon Debug Sync
Recording - Ouroboros Training
PSLE aka MVSLE IDC Presentation
Early HVM Dragon Content Enablement Catches Critical CCF Bug in ADL B0
PSLE2021_DragonFC_ADL_CCF_rev04.pdf
2021 February
DragonFSCE Sync - Dragon Debug
Foils - FSCEDragonDebug.pptx
Video Recording - here
Dragon Basic Training - training for teams new to Dragon
Foils -  Existing slides (links below in appropriate month):
Dragon Quick Overview (2018 June version)
Dragon Overview (2019 February version).
Part 1 - Jan 21
Dragon Quick Overview
Dragon Overview - Overview, What Dragon Validates, Test Targets
Part 2 - Jan 28
Dragon Overview - Releases, Templates, Execution (VVAR interface)
ADL target questions.
Part 3 - Feb 4
Dragon Overview - Content/TestModes, Dragon Execution, Debug.
Did not cover or lightly covered: System 2 Tester, THR, deeper aspects of Debug.
2020 November
DragonFSCE Sync - Dragon Deep Dive
Foils - FSCEDragonDeepDive.pptx
Video Recording - here
2020 October
DragonFSCE Sync - Manufacturing Focus & Intent
Foils - PQV_SCE_Val_Intents.pptx
Video Recording - here
2020 August
DragonFSCE Sync 
Foils - Dragon-SHC-Sync-v5.pptx
Video Recording - here
2020 January-March
Dragon DPM Capture Enhancements.pptx
Presented in FM MVE/iVE Technical Leadership Forum (part 1 WW04.4'20, part 2 WW9.04'20, part 3 WW11.4'20)
2019 June
See MD RM presentation for what was done and why as well as MDUT usage: Dragon multi-DUT RM v7.pptx
recording: MDUT Dragon Training
wiki page: Dragon Multi-DUT
2019 April
.  DoL use external to Intel only cleared under NDA with certain key DCG customers under PRT direction.  Eventually intended to achieve general availability.  Not 
Dragon on Linux (DoL) External Users Guide
intended as a replacement of bare-metal Dragon.  Primarily intended for infield usage and associated correlation and closure.  Possible extended Mfg supplement.
The ppt on the wiki may become stale (esp on app parameters).  Best to use the externally linked "Dragon External Users Guide" pdf: https://cdrdv2.intel.com/v1/dl/getContent/620322
"Large" update in late 2021 from TSL to DoL, clarifications, new algos.  External pdf v3, wiki ppt v9.
Large update in External pdf v5, wiki ppt v10.  Fixed many technical and readability issues that had crept into ext v3 and v4 during unreviewed publishing steps.  Many updates in TSL app details and 
capabilities, some more minor Dragon updates and clarifications.
2019 March
DTTC Shallow Water paper: Minimization and Closure of Externally Detected Unaligned Data Corruption
Full title: Minimization and Closure of Externally Detected Unaligned Data Corruption
Filename: DTTC_shallow_water_ww15.pdf
2019 February
Dragon Overview updated with Series 4 Error Code for CPUID and P23. Padlock test description also added.
2018 July
Dragon Overview updated with H and Q mode descriptions for NI$ products.
2018 June 
Dragon Quick Overview presented in MVP MVS HTS Tech.
MVSLE 2018 Poster Dragon S2T  As Accepted.  This poster shows how Dragon focuses its content and modes to fit different architectural IP and optimize for SBFT compliance and portability. Therefore maximizing 
its effectiveness on system and its portability to tester in order to close speedpath/vmin miscorrelations and even DPM to Tester.
MVSLE 2018 Poster Dragon S2T Updated  As Displayed with feedback from committee to go into Team Room.
2017 July 
DTTC_2017_Dragon_Paper_Final.pdf  DTTC paper which describes how Dragon is used effectively in Manufacturing Validation.
Full title: Dragon: IA Content for Manufacturing Validation
Filename: DTTC_2017_Dragon_Paper_Final.pdf
2016 
ust
Aug
Dragon_Overview_201608_rev1.pptx  Dragon overview and debug presented to High Volume Engineering (HVE).
Recording #1 - Dragon Overview
Recording #2 - Dragon Debug Overview
Recording #3 - Dragon Tools Morning Session
Recording #4 - Dragon Tools
2016 July
Dragon Thumbnail A super brief thumbnail of where Dragon fits in validation.
2015 May
Dragon Basic Training A basic overview of Dragon. (
)
Request access here
2013 May 
Dragon Overview May 2013.pptx Condensed revision of overview with HSX focus; gives a baseline of what Dragon is and how it works.
2013 January
Dragon Overview Jan 2013.pptx Condensed revision of overview with server focus; gives a baseline of what Dragon is and how it works. All Dragon users should be familiar with this material.
Dragon Debug Overview Jan 2013.pptx High level Dragon debug overview presented to SC team.
2012 November
Dragon Overview SC Nov 2012.pptx Condensed revision of overview with server focus; gives a baseline of what Dragon is and how it works. All Dragon users should be familiar with this material.
Dragon Debug Overview SC.pptx High level Dragon debug overview presented to SC team.
Dragon Overview 4debug Nov 2012.pptx Condensed revision of overview for debuggers; gives a baseline of what Dragon is and how it works. All Dragon users should be familiar with this material.
2012 
IDC F2F
October 
Dragon Lifecycle Oct 2012.pptx Second revision of how Dragon interacts with customers over the life cycle of a product. All Program Managers using Dragon should be familiar with this material.
2012 August DTTC Presentation
DTTC Dragon r12.1 (Final).pdf Dragon overview paper that was presented at the 2012 DTTC.
Full Title: Dragon: A Content Generator for Circuit Marginality Validation
Filename: DTTC Dragon r12.1 (Final).pdf
Dragon DTTC R2 (final R2).ppsx given at 2012 DTTC on Dragon
2012 June Penang F2F
Dragon Overview June 2012.pptx 5th revision of overview; gives a baseline of what Dragon is and how it works. All Dragon users should be familiar with this material.
Dragon Lifecycle June 2012.pptx Reviews how Dragon interacts with customers over the life cycle of a product. All Program Managers using Dragon should be familiar with this material.
Dragon Test Overview June 2012.pptx Gives a high level overview of the Dragon modes, templates and back-end randomizations.
Dragon Execution Overview June 2012.pptx Gives a high level overview of Dragon executing on a system and tester. Includes startup initialization, test run time, OBJ formats, and VVARs.
Dragon Debug Overview June 2012.pptx Reviews how to interpret Dragon fail signatures and how to decode MCEs. Also includes brief overview of tester enabling and debugging.
2011
PSLE2011 Dragon Final.pptx From PDE Sharing and Learning Event : May, 2011
Dragon System To Tester Debug Training : April, 2011
Dragon System to Tester Overview.pptx
Part 2: Porting:
 |
Dragon System to Tester Porting To Tester.pptx Dragon System To Tester Porting Part2 20110420.zip
Part 3: Tester Enabling and Debug:
 |
Dragon System to Tester Enabling and Debug.pptx Dragon System To Tester Part3.zip
State of Dragon Jan 2011.pptx From CMV F2F
2010 April Penang F2F
Dragon Overview Apr 2010.pptx
Dragon Debug.pptx
Dragon Execution Model.pptx
Dragon Futures.pptx
Dragon Test Philosophy.pptx
Historical Presentations
Dragon Overview Oct 2010.pptx From CMV Tech Forum
Dragon for MDG Ops Review Sept 2010.pptx
Dragon Overview Aug 2009.pptx
Dragon Update Sept 2008.ppt
Dragon Overview Mar 2008.ppt
Incoming links
 
Page: Dragon
 
Page: Dragon - IPTS
 
Page: Dragon DeveloperTraining
 
Page: Dragon DoL
 
Page: Dragon Reference
 
Page: Dragon VerticalDebugGuide
 
Page: Old MPV Content Secure
 
Page: SCE Training
 
Page: syl content
Contributors
User
Edits
Comments
Labels
Valentine, Joshua H 
80
0
0
Luyando, Jorel C
13
0
0
Gunturi, Ravi
9
0
1
Porter, Benjamin M
7
0
0
Courtney, Chad
4
0
0
Calhoon, Brent
1
0
0
Goh, Chee Hoo
0
0
1
