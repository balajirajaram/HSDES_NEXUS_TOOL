# Dragon FAQ

> Source: 054_Dragon FAQ.pdf

1 What is Dragon?
2 Where can I find some general overview information?
3 What are "seeds"?
4 Does Dragon support processor X? Will it?
5 How do I get Dragon content?
6 Are there any gotchas to using Dragon?
7 Is it ok to use "old" seeds?
8 What does Dragon deliver?
9 The seed file names seem to mean something, but what?
10 Will 2 thread content run on a 4 thread device?
11 Will 4 thread content run on a 2 thread device?
12 What is a VVAR?
13 How many seeds are needed for validation?
14 Incoming links
15 Contributors
First off a note: being a Wiki, this page is a living document. If you feel there is a question that should be in this FAQ, feel free to add it. The Wiki sends email notifying of page changes to anyone who requests them. You can 
also contact the 
.
Dragon Product Owner
What is Dragon?
Dragon is a validation content generator focused on circuit marginalities or speed path hunting for CMV. Dragon content is provided in the form of binary object files (containing code and associated data).  Since the 
MDO MPV reorg, it has been expanded into logic DPM for PPV, including IA PM.
Where can I find some general overview information?
Start with the 
 home page. The presentations linked from there are also suggested reading.
Dragon
What are "seeds"?
Dragon generates content in the form of binary object files. These are often referred to as "seeds", as each one is unique based off a starting random number generator seed.
Does Dragon support processor X? Will it?
Generally speaking: Dragon supports PPV, CMV, and tester port for all x64 cores in MPV products
Core (Client, Server), Atom, and MIC architectures.
Future product support is based off of the 
. Additional product support is possible with direct funding, normally in the form of head count.
MPV road map
How do I get Dragon content?
There are two main methods of acquiring Dragon content. First is make a 
 for purpose built seeds. The second is go to the 
 page and locate a suitable seed set. If you try the second, beware 
Seed Request
Releases
gotchas.
Are there any gotchas to using Dragon?
YES. Many.
Probably the worst is that Dragon really doesn't tell you what it is doing. Yes, it will tell you if it passed or failed, but if you don't really know what it is doing, then what just passed?!?
To combat this fundamental issue, it is always a good idea to talk with the 
 before using seeds if you haven't already. The conversation should cover what you are trying to do and why. 
Dragon Product Owner
Then someone on the Dragon side can ensure that what you execute will fit what you are trying to accomplish. This is crucial to maintaining validation quality.
Is it ok to use "old" seeds?
Normally no.
There are a few problems with using old seeds. The primary issue involves risking not doing something that should be done. Dragon is always evolving and improving, and old seeds often lack features contained in 
new releases.
Anything over 3 months may be too old. The Dragon team strongly recommends checking with them for new steppings to see if new seeds are warranted: A1, A2, B0, B1, etc. Using seeds from a prior product is 
particularly risky and not advised.
There are 2 exceptions, both related high-volume data.
PPV: PPV depends on volume units runs on larger monitor seeds sets to identity the DPM catching seeds for the shorter screen.
Testers doing impact analysis. When prior good patterns have been identified, it makes sense to keep them until new patterns are demonstrated as more effective. The key point being that substantial 
quantities of new patterns will be tried as well. Never settle for just using the old patterns.
What does Dragon deliver?
Binary object files and matching assembly source code. For more information see 
 on 
.
What We Deliver
Dragon SeedRequest
The seed file names seem to mean something, but what?
They sure do. Check the 
.
decoder ring
Will 2 thread content run on a 4 thread device?
It's 
.  This is really only for for debug.
complicated
Yes, but you need to set 
.
VV_MAX_APIC_ID
On system running on only 2 of 4 threads is very likely to reduce validation utility.
On tester the same is true unless core replication, lockstep, or something similar is employed so that all cores/threads become active. Note this only works if the seeds are generated to cover all threads for 1 
core (so 2 threads on HT parts).
Will 4 thread content run on a 2 thread device?
It's 
.
complicated
Dragon >= SVN r5035 
 "just works".  It's still advised not to drift too far (~ 1/2) from the generated intent.
generally
< SVN r5035, 
 no.  But there are vvars that work under some circumstances.
generally
What is a VVAR?
VVARs are a system used to pass values into a Dragon seed and get return values out. They can be very useful for first pass debugging as well as controlling some aspects of seed behavior, foremost timing. Check 
the 
 page for a full description.
VVAR
How many seeds are needed for validation?
This is an open unanswered question. Currently there is no known provable way to say how many is enough until you look backward. This leads to using generalizations instead. Generally either: "More is better" or 
"Stop when you run out of time".
There are some rules of thumb however based on considered variability within the generator based on 
. Depending on the product this leads to several hundred to a few thousand seeds for system. Tester 
template
seeds execute much faster making higher seeds counts more feasible.
CMV: 30 seeds per template bucket per mode is the standard, 10 per the preferred minimum, and 2 per template the absolute minimum
PPVm: 2 seeds per template bucket per mode is the standard
PPVs: as per PPVm data
Normally a project is best off explaining their constraints to the Dragon team and taking the recommended seed set.
Incoming links
 
Page: Dragon Presentations
 
Page: Dragon Reference
 
Page: STHI Software
Contributors
User
Edits
Comments
Labels
Valentine, Joshua H 
3
0
0
Bouzouina, Mehdi
0
0
1
Goh, Chee Hoo
0
0
1
