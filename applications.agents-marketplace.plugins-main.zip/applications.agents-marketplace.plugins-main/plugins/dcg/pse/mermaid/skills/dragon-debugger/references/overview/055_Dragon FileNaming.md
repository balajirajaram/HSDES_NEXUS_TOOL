# Dragon FileNaming

> Source: 055_Dragon FileNaming.pdf

1 Decoder Ring
1.1 Examples
1.2 Special builds
1.2.1 P-State Range Selection
1.2.2 basename aka user prefix
1.3 Enabling seeds
1.4 Subcombinations
2 Tester vs System
3 Incoming links
4 Contributors
Decoder Ring
D<mode><threads/turbo>-<testName>-<devName/variant>-seed.obj
( 1) "D" is fixed and always the same for quick identification of Dragon content
prior to r3891 this was "DRG-"
( 1) "<mode>" is a single character called "mode" representing the cache/etc level targeted by the Dragon seed, see 
 for descriptions
Dragon Cache Modes
ExceedsCache, ybrid, LC, 
LC, c OS, AM, mall LLC
H
L
M
Q
R
S
Roughly largest to smallest dataset: R, E, H, L, Q, S, M
( 3) "<threads/turbo>-" is either: the thread count in hex, or "t" followed by [0-9a-z] representing turbo on core 0-35; or "u" followed by [0-9a-z] representing core count of a universal (core movable) seed; both 
are followed by "-"
(11) "<testName>-<devName/variant>" is a maximum of 11 characters including the "-". See 
 for test lists and the appropriate sub-page for devName and variant descriptions.
Dragon TestDescriptions
( 9) "-seed" is a 8 digit base 16 seed number proceeded by "-". The first two digits of the seed number denote the 
. The third digit is the config number and is used to separate one configuration from 
release
another when multiple are built at the same time (for example S and R).
(25) There is a maximum of 25 characters in the filename plus 4 for .obj for a total of 29.
HSX tester limit: 25
SKL tester limit: 26
Examples
DR08-Frenzy-Y-360002FE.obj is a Dragon system RAM mode seed with 8 threads of execution based on the Y variant of Frenzy and seed 0x360002FE
DM02_Blender_EB_35200A0D.obj is a Dragon tester MLC seed with 2 threads of execution based on the EB variant of Blender and seed 0x35200A0D. 
 is a special case and worth reading the 
Dragon Blender
wiki page.
DS02_FRM_CvtFpY_351009ED.obj is a Dragon tester Small LLC seed with 2 threads of execution based on the Y variant of the CvtFp kernel of FRM and seed 0x35009ED
DMt7-Dppd-PsY-250002CE.obj is a Dragon system MLC turbo seed set to core 7 based on the PsY variant Dppd and seed 0x250002CE.
Special builds
P-State Range Selection
Some debug seeds, particularly early experimental 
 ones, may encode a P-State range selection override into the seed name.  See 
Loki
Dragon PState Range Decoder
basename aka user prefix
Occasionally a special build will contain an extra field for a user prefix. The generic file is then of the form:
current
D<mode><threads/turbo>-<userPrefix>-<testName>-<devName>-seed.obj
pre r3891
DRG-<userPrefix>-<mode><threads/turbo>-<testName>-<devName>-seed.obj
These seeds are created for experimental purposes and should not be used in production execution.
Enabling seeds
If the seed number begins 
 then those seeds are intended for enabling purposes. Just like special builds, those seeds should not be used for production execution. For more information see 
.
0xFF......
Dragon Release0xFF
Subcombinations
Certain components of the name are combined for use in folder names and other places.
Seed name: DR08-user-Frenzy-Y-360002FE.obj
Common portion: DR08-user-Frenzy-Y-360
Used to separate asms (and sometimes objs) into subfolders.
Config name: DR08-user-360
Essentially the common portion with the test name removed. Used to separate per-config files in the info folder.
"SeedBatch": 360
the top 3 hex of the 1st seed in a config: 2 for release # and 1 for config # (may wraparound)
Tester vs System
System seeds use dash (-) as a separator character. Seeds converted for tester use underscore (_).
Incoming links
 
Page: Dragon - IPTS
 
Page: Dragon Blender
 
Page: Dragon FAQ
 
Page: Dragon Reference
 
Page: Dragon Releases
 
Page: Dragon Releases Sandbox
 
Page: Dragon SeedReleaseFileStructure
 
Page: Dragon TestDescriptions
 
Page: Dragon TesterSeeds
 
Page: Dragon TestRequirements
 
Page: Ouroboros Documentation
Contributors
User
Edits
Comments
Labels
Valentine, Joshua H
2
0
0
Chodagiri, Seshasaisree 
0
0
1
