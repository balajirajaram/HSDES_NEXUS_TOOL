# Dragon Reference

> Source: 05_Dragon Reference.pdf

1 General Dragon Links
2 Seeds
3 VVARs and Debug
4 Scrum / JIRA Links
5 Misc
6 Incoming links
7 Contributors
General Dragon Links
Dragon - Main page
Product Dashboard and 
 - List of Products, talk to the 
 if you have support questions
Products Supported
Dragon PO
Generally speaking: Dragon supports PPV/THR, CMV/HVCP, and tester port for all x64 cores in MPE products.  And IPM and DoL/TSL/SHC external releases.
Dragon FAQ - General Dragon Frequently Asked Questions
Dragon IP Test Strategy (IPTS)
Dragon Presentations - All public presentations
Dragon DoL/TSL - Dragon OS Loader
STC PDLs
Seeds
Dragon Releases - Lists of all seed sets released to customers
Dragon SeedReleaseFileStructure - description of the files and structure of a Dragon release
Dragon SeedRequest - How to request seeds as a customer
Dragon TesterSeeds - Overview on Tester content
Dragon TesterEnablingStatus - (outdated) Information about the tester path on various products
VVARs and Debug
Test Details
Dragon FileNaming - Describes seed naming convention
Dragon TestDescriptions - List of all Dragon tests/templates and links to more information
Dragon Test Augmentations
Dragon Cache Modes
Dragon VVARs - Information about input & output VVars
Dragon VVDEBUG Decoder
Dragon VVOUTPUT Decoder
Dragon Thread Lookup
Dragon Thread Mapping
Dragon RunTime - Description of how seed run time is handled and controlled
Dragon PerThreadDelay - Description of how per thread timing may be skewed
Error Codes, see: Dragon Thread Status
Dragon Error Decode
Dragon Bucketer
Ouroboros
Dragon BasicDebug - A short tutorial on basic debug for system seeds
Dragon VerticalDebugGuide - A debug guide for vertical teams. Use this to help escalate issues to the Dragon team.
Dragon TesterDebug - Information for Debuggers porting and debugging on a tester
Dragon DebugInfo - Information for Debugging on a system
Dragon IAMCE - Machine Check Bank mappings
Misc Tools
DebugTools - Various tools to assist with content debugging.
Dragon iASM - How to use iASM with Dragon and where to get it
Dragon Utilities
Dragon 7z - Information about 7z the archive software used by Dragon
Scrum / JIRA Links
 - Rally holds the Dragon sprints and backlog (lists of current and future work)
Old MPV Content RallyTips
TODO: JIRA
Dragon is organized as a 
 team
Scrum
Misc
All Limiters Search
Incoming links
 
Page: CW Migration efforts
 
Page: Dragon
 
Page: Dragon TesterSubjects
 
Page: DragonSecure
 
Page: Old MPV Content Secure
 
Page: Old MPV Content Training
 
Page: STHI Software
Contributors
User
Edits
Comments
Labels
Valentine, Joshua H 
38
0
0
Franks, Steven C
1
0
0
