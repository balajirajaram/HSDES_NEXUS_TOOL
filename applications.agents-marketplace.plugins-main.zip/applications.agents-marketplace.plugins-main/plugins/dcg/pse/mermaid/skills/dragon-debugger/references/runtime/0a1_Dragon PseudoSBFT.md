# Dragon PseudoSBFT

> Source: 0a1_Dragon PseudoSBFT.pdf

1 PseudoSBFT seed usage for Dragon
1.1 Running a PseudoSBFT seed on tester
1.2 Running a PseudoSBFT seed on system
1.2.1 Clear Tester flags
1.2.2 Adjust Runtime to System Runtime
1.2.3 MCE bank checks
1.2.4 Other
2 Incoming links
3 Contributors
PseudoSBFT seed usage for Dragon
PseudoSBFT seeds are seeds generated to run on tester with the system memory map.  In this sense they don't offer complete coverage benefits of a system seed (constrained to tester target / tester data sizes) or a tester 
seed (constrained memory map - the entire physical address space is not utilized).
This target and corresponding content is most often used in THR/ST2 miscorrelation debug activity:
Having the exact same seed produce the miscorrelation on system vs tester environment eliminates potential challenges associated with porting a system to tester.  And avoids attempting to modulate data or 
randomizations in a test to reproduce issues visible in one environment on another
If system vs. tester target environments are suspected as one of the potential causes of the observed miscorrelation, it is useful to have a seeds which can run on system or tester.
Running a PseudoSBFT seed on tester
PseudoSBFT releases are generated for tester.
Running a PseudoSBFT seed on system
Starting with GRR/SRF (Atom only), LNL/ARL (Client), EMR (Big Core Server) tester releases produce binary seeds.  These can be run directly on system with a small modification to VV_DEBUG (VVAR 3) flags:
Clear Tester flags
Run MerlinX with: -d 3 0
WARNING: this clears ALL flags, if other flags are needed use that value instead of 0
vv[ ] (VV_DEBUG) tester related flags potentially set in generated obj: NO_SNOOP, DFX_SIPI, SKIP_SIPI, ON_TESTER
3
Adjust Runtime to System Runtime
By default, the seed is generated to run on tester, at tester runtimes. 
I.e., VVAR1.Bit 31 clear (no bus frequency scaling), and scale factor (VVAR 1[30:0]) typically set to 0x1000 (1x runtime specified in VVAR 0).
Read / save VV[0] default value for pseudoSBFT seed.
System runtimes are typically 1000x larger than tester. In many experiments, it is useful to run the pseudo SBFT seeds using a typical 
runtime.
system 
Steps to use wall-clock method to match system runtime:
Set VV_SCALE_VVAR (VV[1] usually) to adapt to frequency:
Set VVAR1.Bit31 to enable bus frequency scaling. VVAR1[30:0] is the scale factor.
Typical VV[1] system value is 0x80064000 - VV[0] clock cycles * 100 * bus clock frequency.
vv[1] = 0x80064000
For more details: Read description for VVAR 1 under 
.
Dragon VVARs
Set VV_RUNTIME (VV[0]) to desired runtime (3s):
3 sec = 3,000,000 us = 0x2DC6C0 (or whatever time desired, but this is the Dragon default for PPV/CMV system releases).
vv[0] = 0x2DC6C0
If PseudoSBFT hits on system at system runtime, can remove the vv[0]/vv[1] overrides and see if it hits at default tester runtime (1.5M core ticks).  And depending on those results, we can experiment as needed.
MCE bank checks
Tester seeds for different targets don't usually check all the MCE banks that Dragon system content is capable of checking, since the target's SBFT constraints require transactions to stay within the isolation domain 
of the target.
E.g., L2 SBFT and Slice SBFT seeds only check core MCE banks.
System can check more banks outside of Dragon test after running pseudoSBFT tests. The Dragon test can also be configured to check more banks by adjusting the MCG_CAP_OVERRIDE VVAR 
(IA32_MCG_CAP_MASK) in addition to the MCE check and enable VVARs (SOFT_MCE_ENABLE_MASK and SOFT_MCE_CHECK_MASK).
Other
PseudoSBFT releases for prior products will have a separate directory consisting of tester seeds converted to run on system - ascii seeds converted to binary, without tester VVAR flags set and appropriate runtime.
Incoming links
 
Page: Dragon 2024Release0x3E
 
Page: Dragon 2025Release0x55
 
Page: Dragon 2025Release0x56
 
Page: Dragon Shepherding Resources
Contributors
User
Edits
Comments
Labels
Gunturi, Ravi
8
0
0
Valentine, Joshua H 
1
0
0
