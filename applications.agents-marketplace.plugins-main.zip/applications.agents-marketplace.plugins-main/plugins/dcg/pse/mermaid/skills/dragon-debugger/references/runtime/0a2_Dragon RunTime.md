# Dragon RunTime

> Source: 0a2_Dragon RunTime.pdf

1 Default Dragon Run Time
2 How Dragon uses Run Time
3 Run Time Calculation
4 DR1 scaler override
5 Incoming links
6 Contributors
Default Dragon Run Time
The following run times have been identified as the most optimal via many time targeted, all limiter, regressions.
System : 3 Seconds
Tester : 1 Million CPU cycles.
Note:When dealing with testers, cycle count is usually discussed BCLKS! Be sure to do the proper conversion :CPU clocks = BCLKS * ratio.
How Dragon uses Run Time
The following CPU cycle timers are used to get wall-clock time.
System and full chip tester: Cpu Time Stamp Counter ( TSC )
Slice and MLC mode : ACNT ( Note this is effected by Geyserville. Running in this mode assumes we are running at max ratio. )
Dragon calculates the 
 by setting the the CPU timer to the complement of the desired CPU cycle count. The test, periodically checks the timer and when it goes from negative to a positive number, the test is 
targeted run time
complete and will start the exit code.
Note: The test 
 will always be larger than the 
. This is due to the granularity of period in which the test checks the timer and the fixed code that is run before and after the actual testing code.
actual run time
targeted run time
Run Time Calculation 
Dragon uses VVARs 0 and 1 to calculate the execution time. Please refer to the 
 page for details on the calculation.
Dragon VVARs
DR1 scaler override
If DR1 != 0 at the start of the test, its value will override VVAR 1. This SCALER override, that can be accessed via a CR register, creates a mechanism for on-target cycle count manipulation. This is particularly useful on the 
Tester where it can be used to search for optimum run time.
DR1 to CR register mappings can be found 
.
here
Incoming links
 
Page: Dragon Confluence Wiki Markup
 
Page: Dragon Reference
 
Page: Dragon TesterDebug
 
Page: Dragon TesterEnablingCheckList
 
Page: Dragon TesterSeeds
 
Page: Dragon VVARs
 
Page: Dragon VVARs 2016 SVN 4958 to 5266
 
Page: Dragon VVARs 2017 SVN 5266 to 5872
 
Page: Dragon VVARs 2018 SVN 5872 to 6207
 
Page: Dragon VVARs 2019 SVN 6207 to 6390
 
Page: Dragon VVARs 2020 SVN 6390 to 6752
 
Page: Dragon VVARs 2021 SVN 6752 to 7030
 
Page: Dragon VVARs 2022 SVN 7030 to 7218
 
Page: Dragon VVARs 2023 SVN 7218 to 7621
 
Page: Dragon VVARs 2024 SVN 7519 to 7810
 
Page: Dragon VVARs 2025 SVN 7810 to 8178
 
Page: Dragon VVARs pre 2016 SVN 1 to 4958
 
Page: Dragon VVARs Sandbox
 
Page: Tester_Debug DR1_cycle_scaling MIGRATED
 
Page: Tester_Debug MIGRATED
Contributors
User
Edits
Comments
Labels
Valentine, Joshua H
2
0
0
Salazar Paniagua, Alejandro 
0
0
1
