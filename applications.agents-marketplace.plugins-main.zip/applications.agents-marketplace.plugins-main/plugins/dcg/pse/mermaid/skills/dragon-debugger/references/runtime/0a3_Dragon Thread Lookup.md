# Dragon Thread Lookup

> Source: 0a3_Dragon Thread Lookup.pdf

Table of Contents
1 General
2 Thread Counting
3 Thread Symbols
4 Thread Indexing
5 Thread Status VVars
6 Incoming links
7 Contributors
General
This page explains how to lookup which thread went where (threadName, APIC ID, logical ID, TB, generated thread).
Thread Counting
Number of failing threads
Dragon designates one vvar per thread in the test to indicate status. This allows failure information to be reported per thread.
Count the failing threads (see below).
Total number of threads
Count of thread name symbols (see below).
Thread Symbols
Each thread can have a different algorithm in Blender seeds and the algorithm name for each thread is encoded in special symbols in the obj.
Symbols matching this pattern: _[a-z0-9_]+_thread_[0-9]+ name each thread
ignore casing
Deprecated, do not implement:
Lowercase thread is for 32-bit errorcodes per thread
Dragon only uses this (though both the 32-bit and 8-bit error codes are in the vvars for now).
Capital Thread is for 8-bit errorcode per thread
Dragon was going to use this and ended up not.  But Ape was using it.
The part after the 1st underscore is the name.  The part after the last underscore is the thread number in decimal.
Example: _Demo_thread_1
Demo is the name for thread 1.
Thread Indexing
>= 7089: Thread mapping has become increasing complex.  Added GENTHD32 vvars to simplify lookups and support 
.
LittleFoot
Complexities:  multi socket/die/DUT, hybrid core types, 
 balanced module reduction
LittleFoot
Created situations where generated vs runtime threads are neither contiguous nor in order.
GENTHD32 vvar table is now used for decoding which generated thread/algo maps to a vvar status (and APIC ID).
Algorithm:
Construct 
from GENTHD32 vvars:
id_table 
GENTHD32 is a table which stores (generated thread id, APIC ID) tuple indexed by logical thread id.  For 
 seeds, each table entry contains (bundle id, generated thread id, APIC 
LittleFoot
ID).
Table start address: _GenThd32_Summary_Addr, end Addr: _GenThd32_Summary_End.
Format of table entry (4 byte entry):
Entry is different for LittleFoot vs. non-LittleFoot seed.
LittleFoot entry: BB GG AA AA
G = Generated thread ID (byte 2)
A = Apic ID
B = Bundle ID
non-LittleFoot entry: GG GG AA AA
G = Generated thread ID (word 1 - bytes 2-3)
VV_OUTPUT (VVAR 0xA), bit 15 set indicates LittleFoot seed:
vv_debug_output_val = vvars[A]
LF_Seed = vv_debug_output_val & (1 << 15)
VV_GENTHD32_START = _GenThd32_Summary_Addr / 4
VV_GENTHD32_END = _GenThd32_Summary_End / 4
foreach run_thread in 0..running_threads-1:
genthd_entry = vvars[VV_GENTHD32_START + genThread]
if (LF_Seed):
id_table[run_thread] = (genthd_entry >> 16) & 0xFF
else:
id_table[run_thread] = (genthd_entry >> 16) 
Construct 
 from thread symbols:
threadName_table
foreach symbol in object that matches: _<threadName>_thread_<x>
threadName_table[ ] = 
x
threadName
Lookup thread name using tables:
foreach curThread in 0..running_threads - 1:
generated_thread = id_table[curThread]
threadName = threadName_table[generated_thread]
> 6697 and < 7089.  Updated reporting algo for Hybrid cores/products.
Thread blocks are generated per core type and assigned only to logical threads of matching core type.  This creates gaps in assignment of thread blocks.  Even module reduction now deciphers # running 
modules and removes/skips TBs per coretype. 
Generated threads used in a seed may not be continuous and this makes the generated thread/algo for a given running thread harder to find (gen thread id may not be logical thread id).
Algorithm:
Constructs the run_thd_table just as in the >= 6205 version.
Constructs two new tables:
core_type_running - tracks number of running threads per coretype (i.e., system/unit config).
core_type_generated - tracks number of generated threads per coretype (i.e. seed config)
Iterate through all running threads as in >r6205
For each running thread, calculate the appropriate generated thread index into the 
:
run_thd_table
Start with 
 = 0.
gen_thread
Track current core type, and current thread id in core type, 
If done with all threads in current coretype (cur thread in core type > core_type_running[current core type])
Apply offset to generated threads to process generated threads for next type.
gen_thread = 
 + (
 - 
)
gen_thread
core_type_generated[current core type]
core_type_generated[current core type]
ELSE (gen thread follows run thread within coretype).
gen_thread = 
 + 1
gen_thread
Print 
[
run_thd_algo gen_thread]
>= r6205 For 
 or 
 seeds with thread reduction, reporting of test names beyond the 1st partition is complex but do-able.
multi-socket
multi-DUT
Fusion HSD: https://hsdes.intel.com/appstore/article/#/1408850755
A sentinel symbol called "hasTBSIDMap" denotes that this object file contains the information required for the new reporting capability.
<
>_tbsid_ _thd_  which is generated for each thread.
threadName
x
y
x = TBSID,  = logical thread id.  
 = algo Name.
y
threadName
_
_generatedDie, where 
 = number of generated die.
<numDie>
numDie
Algorithm:
generatedDie = 
 extracted from symbol _<
_generatedDie in .obj
numDie
numDie>
running_tpd = num_threads / generatedDie
For num_threads, see < r6205 descrip below
max_tbsid = running_tpd - 1
run_thd_table = new table()
curThread = 0
foreach line in object that matches "<threadName>_tbsid_ _thd_ ": (assuming matching must be in ascending order of "y")
x
y
if  < max_tbsid, extract 
 from line:
x
threadName
run_thd_table[curThread] = threadName
curThread++
Print run_thd_table[
] for the 
curThread
threadName/algoName
< r6205 For 
, multi-threaded tests with thread reduction, reporting of test names is limited to tests on the DUT.  Test names are limited to threads with logical IDs < (number of running threads) / (number 
multi-socket
of packages).
Number of running threads: find the symbol matching the pattern: num_threads_running_[0-9]+.  The number at the end of the symbol is the number of bytes to read from the address of this symbol, to get 
the number of running threads.  For example, if the symbol is num_threads_running_2, and the address for this symbol is 0x2156, then to get the number of running threads, read 2 bytes from address 
0x2156.  Use this symbol instead of VVAR[2].low to insulate your code from potential changes to VVAR locations.
Number of packages: find the symbol matching the pattern: _[0-9]+_numSockets.  The number between the underscores is the number of generated packages for this seed.
For multi-socket, multi-threaded tests with thread reduction, report 
 instead of the test name for tests that fail on NUTs.
NUT
Thread Status VVars
The 32-bit per-thread error code is stored in 
 vvars.
Thread Status
Incoming links
 
Page: Dragon Multi-Socket
 
Page: Dragon NUT
 
Page: Dragon Reference
 
Page: Dragon Thread Mapping
 
Page: Dragon Thread Status
 
Page: Loader Interactions Dragon
Contributors
User
Edits
Comments
Labels
Valentine, Joshua H 
22
0
0
Gunturi, Ravi
6
0
0
