# Dragon Thread Mapping

> Source: 0a4_Dragon Thread Mapping.pdf

1 Overview
1.1 Thread IDs
1.2 General Limitations
2 When CPUID doesn't report the correct number of threads.
3 Running on fewer threads than the system has
3.1 Limitations
4 Running on fewer threads than the seed was generated for
4.1 Configuration
4.2 Limitations
4.3 Hardware Lockstep - HWLS
5 Thread rotating and swapping
6 Incoming links
7 Contributors
Overview
Dragon has some limited built in support for runtime running on differing numbers of threads than available in the system or seed.  Dragon can also runtime swap or rotate thread order.  These require inputting the correct 
 
vvar
values for the scenario.  These exist for certain specific scenarios and use should be restricted to those as defined by the Dragon team.  Otherwise, false fails or false passes may intermittently and/or silently occur.
Thread IDs
Dragon assigns it's generated threads in increasing order to the HW threads based on increasing apic ID order (of compatible threads).  A thread's position/# in the vvars, it's Dragon logical thread ID, selected Thread Block 
(TB), and apic ID are all correlated but not equal.  Further, apic ID #, PythonSV thread #, physical core #, and LLC slice # are not equal.  That mapping can be looked up in the rare cases proper documentation exists.  Fusing 
and core disabling may or may not alter that mapping.  Use of the thread mapping alteration capabilities enumerated here may of course further warp those various assignments.  The 
 "test" is not normally 
ReportApic
generated for releases, but it returns the apic ID of the thread in the status vvar (and thus the "test" always "fails").  See 
 for more details across revisions.
Dragon Thread Lookup
General Limitations
Prior to SVN r5035, there is essentially no error checking that the inputs are sensical or accomplish the intent.
Even after r5035, some of these checks are skipped under certain "debug style" inputs
false fails or false passes may intermittently and/or silently occur on incorrect inputs.
 particularly egregious errors in input may result in 1 or 7 series errorcodes in the 
 vvars.
Some
Thread Status
Only "down" scenarios are supported, not "up" scenarios.
DUT and NUTs must be symmetric (in thread mappings and ISA), that is a basic booting requirement and assumed by pretty much everything.
Do not use these capabilities to cross natural system unit boundaries unless expressly directed.
threads per core, cores per module, module per tile, cores/modules/tiles per CPU.
Only run HT generated seeds on HT parts, only run non-HT seeds on non-HT parts.
ADL fwd 
is somewhat an exception as "HT" seeds mostly "ignore" the HT.  See 
.
hybrid 
Dragon HyperThreading
Do not thread swap or rotate only part of a core/module/tile/CPU with another.
As of SVN r5035, on system (not tester), Dragon startup will check for these and return a 0x1000000C or 0x1000000D error on mismatch.
>= SVN r7030:  vv[5] VV_MAX_APIC_ID controls this check.  0 (default) performs the TPx check and 1 skips the TPx check.
< SVN r7030: This check is bypassed when setting min or max APIC to non-default values.  Doing so is assumed to be a debug scenario.
As of SVN r6390, the swap/rotate inputs are now separated along unit boundaries, preventing crossing.  Though, mix/max APIC ID can still cause us to cross boundaries.
Doing so may work "fine" in some cases but cause false fails or false passes in others.
For instance, the PV/Charyb and the PDV/Scylla often run only some threads in the core.  Running the HT seed on a non-HT part means some cores don't run the test.  And the other direction 
means the PV and PDV do not execute properly and thus under test.  Dragon's PM flows are also very specific to unit boundaries for PM coordination.
LittleFoot (LF) < r8200: threadsort breaks running odd # of modules when TPU mismatch, 0x10000009/#PF/corruption.
This is because Dragon is pre-generated, not dynamic based on the target.  It's one of the numerous trade-offs between pre-generated and runtime generated tests.
When CPUID doesn't report the correct number of threads.
>= SVN r5035:
Dragon waits until all system threads have checked in before working on the running thread set.  Dragon calculates the number of system threads by multiplying the run-time threads per package from CPUID
 times the number of expected packages (the number of generated packages, or the low nibble of the high byte of VV[2] if overridden). If CPUID doesn't report the correct 
(eax=0xB, ecx=1).EBX[15:0]
number of threads, the test will fail with error codes 10000001 - 10000005. (See the 
 or 
 wiki pages for error code details.)
Thread Status
Dragon Error Decode
The number of total threads in the system can be overridden by setting 
 when generating seeds.  There is a symbol in the .obj, 
 for the start of this 
config.totalSystemThreads
all_system_threads,
2 byte value.  However, unless vvar[2].lowWord is overridden, the run-time threads per package is still used to calculate auto thread reduction.  So manually set vvar[2].lowWord to the desired threads to run.
Running on fewer threads than the system has
Dragon "supports" a capability to run on fewer threads than available in the system.  This is accomplished by setting at least one of the apic 
 filters.  Set the minimum apic ID to run on through vv[4] and the maximum apic 
vvar
ID to run on through vv[5].  Prior to SVN r4558, min and max apic were both in vv[5].  Prior to SVN r3992, min apic could not be set, only max apic.
This is usually done for a few reasons:
Controlling which socket Dragon runs on in a multi-socket system.
As of SVN r5035, (if min=0 & max = 0xffffffff), Dragon will automatically determine the min and max apic ID from the vv[2] packages byte.
SVN >= r7030 doesn't count max[31] as that now controls TPx check.
Running turbo with less than all cores or working around cores suspected to have defects or other issues.
In general, this is better accomplished through fusing instead of vvars.  See limitations.
When CPUID doesn't report the correct number of threads.
Dragon calculates the number of threads running on the system by multiplying the number of expected packages (the number of generated packages, or the low nibble of the high byte of VV[2] if overridden) 
multiplied by the run-time threads per package from 
. Dragon waits until all running threads have checked in before working on the running thread set. If CPUID 
CPUID(eax=0xB, ecx=1).EBX[15:0]
doesn't report the correct number of threads, the test will fail with error codes 10000001 - 10000004. (See the 
 or 
 wiki pages for error code details.)
Thread Status
Dragon Error Decode
The number of total threads in the system can be overridden by hacking the 2 byte value at the symbol 
 in the .obj. Or, provide the Dragon PO with the correct number of system 
all_system_threads
threads, and ask him to generate seeds.
Debug
An attempt to isolate contributing cores.
Running a seed generated for another smaller core count on a larger core count configuration for certain data collection.
Limitations
See 
 in the 
 above.
General Limitations
Overview
min+max apic ID only allow a single block of threads to be specified, available threads within that range cannot be skipped.
SVN r4739 - r5034, setting min/max apic also requires setting VV_SYSTEM_THREADS in vv[2].high.  Prior to that, certain circumstances could cause (possibly silent) errors in Dragon's PM flows and other areas.
The ability for Dragon to error check the the inputs is extremely limited.  It depends on the user to input apic IDs or vv[2] packages byte matching the user intent.
Though functionally available, running Dragon on fewer threads than the DUT has is vehemently discouraged outside of very specific debug scenarios.
Doing so obviously leaves large chunks of the DUT untested.
Even aside from the non-running cores, there are various shared resources such as the LLC and MC that will be under tested.
Additionally, though minor, Dragon will be generated with a different LLC hashing than it is run on.
Even for the untested threads, Dragon must wake them up and perform some work on them before sending them to halt.
Even then they are 
 halted and may participate in some system actions such as wbinvd, snoops, PM (c-state, p-state), etc.
only
Running on fewer threads than the seed was generated for
For a long time, running Dragon on fewer threads than the seeds were generated for only worked in narrow circumstances and was never meant as a "real" usage scenario.  However, the 
 storage limitations of 
 
extreme
ASA
and the ever increasing # of differing core count SKUs on Server led to a major project to enable standard Dragon support for 
 thread reduction scenarios.
most
This is accomplished by setting the Thread Counts 
.  The precise inputs have been improved over time and as of SVN r5035, rarely require manual adjustment.  See the 
 section.
vvar 2
Configuration
For single-socket generated seeds and the DUT of multi-socket generated seeds, thread reduction runs the  (compatible) generated Dragon algorithms from 0 to n-1.  For NUTs of multi-socket seeds, the partners of the 
enabled DUT threads are enabled, which scrambles the 
 thread ordering from what was generated.  Not all Thread Blocks (TB) are active, for NUT's, the active TBs aren't even contiguous.  See 
 for 
NUT
Dragon DebugInfo
details on TB.
As of r6205, Dragon supports multiple DUT nodes with similar complications and limitations as multi-socket seeds using NUTs.  Thread reduction 
 a DUT is supported, but removal of entire DUTs is not.  See 
within
Dragon 
Multi-DUT
Both hybrid (different core types) and LittleFoot make following this 
 further complicated (even without thread reduction).
Thread Lookup
From the perspective of validation quality, it is generally advised not to drift too far from the generated thread configuration, due to the testing limitations enumerated below.  Please work with the Dragon PO and your product’
s Dragon POC to understand the impact to your program and the best tradeoff between # of seed releases and validation drift.  The Dragon team’s current general recommendation is to not drop below 50% of generated.  So 
a 28C seed is OK down to ~14C but below that can start drifting too much from generated test intention.
This keeps generated and running configurations reasonably close instead of running a 28C generated seed on a 2C part.  Obviously there are some trade-offs in fewer seed sets (less work, less space, more 
common correlation) vs testing quality (greater drift from generated intent).  Usage recommendations may change with data and experience from actual deployments and/or experiments.
With 
, that ~50% boundary is based on the 
 size, not the 
 size.  Thus a "28C" seed is actually a 5C bundle, so down to 2C is fine 
.
LittleFoot
bundle
total
Configuration
>= SVN r5035
System automatic thread reduction and system vv[2] only requires starting package and # of packages.
Both of the package inputs can be defaulted at generation time and are only needed for multi-socket anyway.
SVN r4740 - SVN r5034
Set VV_RUNNING_THREADS in vv[2].low to the number of threads to run Dragon on.  0 will load the number of threads the seed was generated for.  Set VV_SYSTEM_THREADS in vv[2].high to the total 
number of threads in the system.  0 will load the number of threads from vv[2].low into vv[2].high.
< SVN r4739
VV_SYSTEM_THREADS did not exist and, under certain circumstances, setting VV_RUNNING_THREADS to less than the number of threads in the system could cause errors in Dragon's PM flows and 
other areas.
Limitations
See 
 in the 
 above.
General Limitations
Overview
esp: HT must be the same, e.g., don't run an HT test on a non-HT part or vice versa
esp: This won't help with up-count, i.e., running a 2 thread seed on a part with 16 threads means 14 idle threads.  This only helps with down-count, i.e., running an 8 thread seed on a part with only 4 threads.
See Multi-socket Thread Reduction Limitations
Complications in Thread Lookup
The entire seed is stored and loaded into the target even if only a fraction of it is used.  This can be very inefficient if running higher core count seeds on much lower core count targets, especially if the loader 
interface is slow.
Accepted testing limitations
In order to support thread reduction, Eclipse thread pairing is now non-deterministic in all non cycle-deterministic cases.
DittoMT/Flipper/Twiddle/etc hit-M test intention is notably reduced if too many of the partners are inactive.  In the extreme case, only 1 thread of a set may exist, largely curtailing the purpose of the test.
LLC usage (and thus MC) may be less than designed or even more over committed than designed.  Also, Dragon will be generated with a different LLC hashing than it is run on.
i.e. R seeds may be somewhat more or less over-committed than the 2x target, but this effect should be minor.
i.e. L and MIC "S"/M seeds may be somewhat over-committed and go to RAM a bit instead of staying in cache.  This effect should be minor.
i.e. L and MIC "S"/M seeds may be somewhat under-committed and not use quite as much of the cache.  This effect should be minor and has always existed to some degree in normal 
circumstances anyway: randomizations, lack of complete request knowledge at allocation, and the 
.
Knapsack Problem
Normal true S seeds should be fine.
Proper support for thread reduction was enabled in pieces
Automation
Fusion does not yet support (and Orion won't) the 
 for handling thread reduction.
new loader interface
These older automation may count the extra threads as "still running" (0x0) and list them in the failure signature.
These older automation may list incorrect algorithms and thread numbers for threads beyond the current DUT.
BDX Orion
BDX Orion usually has a script running that writes min/max apic based on seed name.  Though the seeds remain thread reduction capable, this setting effectively disables 
 thread 
auto
reduction and the various r5035+ checks.
< SVN r5245:
The minimum loop count VVAR incorrectly reports 0 instead of the loop count minimum of all threads, when running on fewer threads than the seed was generated for.  The minimum loop count 
VVAR varies by SKU.  See 
 for the minimum loop count VVAR for your SKU.
Dragon VVARs
>= SVN r5035:
System automatic thread reduction and system vv[2] only requires starting package and # of packages.
Both of the package inputs can be defaulted at generation time and are only needed for multi-socket anyway.
System checks runtime threads per unit, VV_THREAD_ROTATE in vv[6], and VV_THREAD_SWAP_XOR in vv[7] against generated threads per unit and errors if mismatched.
System only and skipped unless APIC (min=0 & max = 0xffffffff).  Fixed APIC inputs are assumed to be a debug scenario.
SVN >= r7030 doesn't count max[31] as that now controls TPx check.  0 (default) performs the TPx check and 1 skips the TPx check.
PM thread reduction enabled (SVN r5034).
< SVN r5035:
Thread reduction for PM seeds is not supported.
Mainly turbo.
Thread reduction and vv[2,4,5] interface is manual.
vv[6,7] and runtime threads per unit unchecked.
< SVN r4996
Multi-socket thread reduction not explicitly supported.  DUT/NUT threads won't be assigned properly and the 
 testing intent will not be fully and correctly satisfied.
multi-socket
< SVN r4930
Multi-threaded tests were not supported for thread reduction.  Any seeds (including Blender) that included multi-threaded tests such as DittoMT (updated r4930) and Eclipse (updated r4919) would 
hang or error if only part of their set was cut off.
Hardware Lockstep - HWLS
Dragon does not directly set or detect Hardware Lockstep (HWLS).  To run BM Dragon in HWLS config, set the cores (all enabled ones) into HWLS prior to Dragon.
Use the normal seed release (e.g. 4 CPM seeds on 4 CPM in HWLS)
In theory, sub-module lockstep could use "matched" seeds (e.g. 2 CPM seeds on 4 CPM in HWLS) and not need the vvar bits for TPx mismatches.
But that requires extra releases and makes data collection for HWLS vs regular very problematic.
WARNING: LittleFoot (LF) < r8200: threadsort breaks running odd # of modules when TPU mismatch, 0x10000009/#PF/corruption.
For system sub-module lockstep (like SRF Atom), and set these 3 vvar bits:
vv[ ].bit[16]=1: Disable Dragon requested PM flows (as these don’t support TPx mismatch)
3
vv[ ].bit[28]=1: Runtime lockstep WAs (such as halving fused CPM count on SRF as cpuid doesn't update)
3
DMR system does actually seem to update cpuid and should NOT use this.
vv[ ].bit[31]=1: Skip TPx checks (since this is a deliberate mismatch)
5
The other bits of vv[5] are the max APIC ID, which defaults to 0x7FFFFFFF to run everything in the system.  So to skip TPx checks and run all detected threads, vv[5] = 0xFFFFFFFF.
For SBFT sub-module lockstep (like SRF Atom), set the below vvars as needed:
Note that Dragon SBFT seeds don't include PM, and so don't need to set the disable bit.
Atom no_snoop MLC SBFT seeds "work" without any of the above overrides.  As they already don't coordinate thread counts (due to no_snoop).
Other iso SBFT (MLC/Slice) have SKIP_SIPI and/or DFX_SIPI set, which also bypasses Dragon's auto-thread reduction flows (and the associated lockstep WA).
So set VV_RUNNING_THREADS in vv[2].low to the number of visible threads to run Dragon on (4 CPM in HWLS is 2 visible threads).
For RO/MO/FC SBFT:
vv[ ].bit[28]=1: Runtime lockstep WAs (such as halving fused CPM count on SRF as cpuid doesn't update)
3
vv[ ].bit[31]=1: Skip TPx checks (since this is a deliberate mismatch)
5
The other bits of vv[5] are the max APIC ID, which defaults to 0x7FFFFFFF to run everything in the system.  So to skip TPx checks and run all detected threads, vv[5] = 0xFFFFFFFF.
Thread rotating and swapping
For certain specific debug experiments (and some ASA usage), Dragon supports rotating or swapping thread assignments prior to executing the actual test code.  This is accomplished through VV_THREAD_ROTATE in vv[6] 
and VV_THREAD_SWAP_XOR in vv[7].  Prior to SVN r4558, both of these were single bytes in vv[5].  Both rotate and swap can be set at the same time.  Though using even one, much less both, can be a bit of a mind-
bender on thread mapping.
See 
 in the 
 above.
General Limitations
Overview
esp: even though you 
 rotate or swap 
 of a core/etc; 
can
part
don't!
As of SVN r5035, on system (not tester), Dragon startup will check for these and return a 0x1000000E error on mismatch.
System only and skipped unless APIC (min=0 & max = 0xffffffff).  Fixed APIC inputs are assumed to be a debug scenario.
esp: there is no error checking if this did what was intended
As of SVN r6390, the swap/rotate inputs are now separated along unit boundaries, preventing crossing.
Incoming links
 
Page: Dragon 2025Release0x5D
 
Page: Dragon 2025Release0x5E
 
Page: Dragon 2025Release0x60
 
Page: Dragon ABriefHistory
 
Page: Dragon FAQ
 
Page: Dragon HyperThreading
 
Page: Dragon Multi-DUT
 
Page: Dragon Multi-Socket
 
Page: Dragon Reference
 
Page: Dragon ReportApicTest
 
Page: Dragon TestDescriptions
 
Page: Dragon Thread Status
 
Page: Dragon VVARs
 
Page: Dragon VVARs 2016 SVN 4958 to 5266
 
Page: Dragon VVARs 2017 SVN 5266 to 5872
 
Page: Dragon VVARs 2018 SVN 5872 to 6207
 
Page: Dragon VVARs 2019 SVN 6207 to 6390
 
Page: Dragon VVARs 2020 SVN 6390 to 6752
 
Page: Dragon VVARs 2021 SVN 6752 to 7030
 
Page: Dragon VVARs 2022 SVN 7030 to 7218
 
Page: Dragon VVARs 2023 SVN 7218 to 7621
 
Page: Dragon VVARs 2024 SVN 7519 to 7810
 
Page: Dragon VVARs 2025 SVN 7810 to 8178
 
Page: Dragon VVARs pre 2016 SVN 1 to 4958
 
Page: Dragon VVARs Sandbox
Contributors
User
Edits
Comments
Labels
Valentine, Joshua H 
86
0
0
Gunturi, Ravi
6
0
0
Araya, Michael
2
0
0
