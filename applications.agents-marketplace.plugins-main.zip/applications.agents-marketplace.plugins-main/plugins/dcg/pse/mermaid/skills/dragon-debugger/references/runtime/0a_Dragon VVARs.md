# Dragon VVARs

> Source: 0a_Dragon VVARs.pdf

Overview
Old versions click here
Dragon VVars Changelog
Be 
 when using the 
 vvars: 2, 4, 5, 6, 7
careful
thread mapping
This wiki page is updated as part of a build process when building the Dragon code. Any changes done manually will be overwritten!
VVARs start at the address specified in the "DataDumpAddr_VVAR" symbol and end at the "DataDumpEnd_VVAR" symbol. Symbols are located at the end of the OBJ.
VVARS are DWORD offsets.
Example: Assume DataDumpAddr_VVAR is at 0x214C
VV[0x0] = 0x214C
VV[0x1] = 0x2150
...
VV[0xC] = 0x217C
Be sure to check your DRG SVN # to get the correct VVAR!!!
SVN 8251 - current
Old versions click here
Dragon VVars Changelog
VVAR
Description
VV[0x00]
Test runtime
Min execution time in CPU cycles (after bus translated to CPU HFM) = (VV[0x00]*VV[0x01])/212
Defaults
System: Microseconds
Ex: 3 sec = 3,000,000 us = 0x2DC6C0
Tester: CPU Cycles
VV[0x01]
32-bit fixed point value to scale VV[0x00] by: 2
 integer, 2
 fractional
20
12
Min execution time in CPU cycles (after bus translated to CPU HFM) = (VV[0x00]*VV[0x01])/212
If the top bit is clear, this vvar refers to CPU HFM freq in scaled MHz.
If the top bit is set on system (default), this vvar refers to bus freq in scaled MHz. This bit is ignored on non-system. Dragon's startup will clear this bit and multiply by the CPU HFM ratio to get to the 
CPU HFM freq in scaled MHz.
Defaults
System: Scale VV[0x00] by expected bus frequency in MHZ
ex: 0x80064000 (100 MHz bus * 2
)
12
System: Scale VV[0x00] by expected CPU HFM frequency in MHZ
ex: 0x00bb8000 (3000 MHz CPU HFM * 2
)
12
Tester: 0x1000 (don't scale VV[0x00])
VV[0x00] scaling factor examples
To be clear, these only scale VV[0x00] (time in microseconds), not the original test runtime. Test runtime is calculated from the VV[0x00] and VV[0x01] inputs.
0x800 - scale VV[0x00] down by 1/2
0x1000 - don't scale VV[0x00]
0x2000 - scale VV[0x00] up by 2x
0xA000 - scale VV[0x00] up by 10x
VV[0x02]
Thread Count VVar
VV[0x02] byte layout:
SE PD RR RR
Note: "package" means actual package except when running 1 die per package seeds on multiple die per package parts. In that case "package" means die.
S = start package (4 bits)
E = expected number of packages (4 bits)
P = (output only) generated packages (4 bits)
D = (output only) log2(generated dies per package), so 0 = 1 die, 1 = 2 die, 2 = 4 die, etc (4 bits)
R = running threads (16 bits)
word 0 This VVar is used to override the number of threads to run the Dragon test on.
If 0 (default): Dragon startup will use defaults:
System default: # of threads in package * # of sockets generated for
All other default (tester/archsim/etc): # of threads generated for
Override usefulness
For debug, to run Dragon on only some of threads in the unit. Requires setting min and max apic to discard the unwanted threads.
byte 2
nibble 0: D = (output only) log2(generated dies per package), so 0 = 1 die, 1 = 2 die, 2 = 4 die, etc (4 bits)
nibble 1: P = (output only) generated packages (4 bits)
byte 3
nibble 0: expected number of packages populated in the system
If 0: Dragon will use the # of packages it was generated for
Only useful for multi-socket systems (Xeon Servers)
If communicated up front, the Dragon team can generate this with your default configuration.
Otherwise, you will need to override this if the system has more packages than the seed was generated for.
WARNING: The other packages will NOT run any Dragon test code (just some startup code).
nibble 1: zero-based starting package to run Dragon on
Default: 0: run starting from package 0
VV[0x03]
Debug Flags - Decoder
bit 0
Not Defined
bit 1
Not Defined
bit 2
Ignore INIT flag. Dont fail if this flag has been set.
bit 3
System Only: All WBINVDs will be skipped during the test.
bit 4
Not Defined
bit 5
SKIP SIPI. Used for single thread mode or for simulation where other mechanism for waking up SIPI is used.
bit 6
Not Defined
bit 7
PROC_SPECIFIC_DFX, set by Dragon during generation, do not modify unless directed to do so.
ANN enables code to remap 2nd BSP to an AP
bit 8
NO_SNOOP: If set skip startup accesses which create cross thread snoops; needed for compatibility for certain tester SBFT modes.
Must be generated with this set because algorithm cross-thread snoops are only prevented at generation time, not runtime.
Undefined or strange behavior on system. Do not modify unless directed to do so.
bit 9
DFX SIPI: Set for MLC and Slice mode on tester.
bit 10
Simulation Flag. Will be set if test is running on Archsim.
bit 11
Tester Mode: Startup code flow will be SBFT compliant and run tester specific code.
bit 12
JMP-SELF in Tester Mode: When set, all threads will end with a JMP $ instead of a halt.
bit 13
Not Defined
bit 14
Not Defined
bit 15
Counter check. Verifies that TSC is running. Don't use this with Archsim!
bit 16
If set, power management functionality is turned off for seeds that have c-states or p-states or turbo or user-level wait enabled. Also useful for e-swift, esp since APIC is used.
bit 17
If set, VMX functionality is turned off for seeds that have vmx enabled. Useful for debug.
bit 18
If set, TLA trigger ( OUT 0xf8 ) will be skipped
bit 19
If set, test will exit immedately on any failure.
bit 20
If set, test will skip all RDRAND sparks and DRNG PBIST code
bit 21
If set, test will skip all HLE and RTM sparks
bit 22
If set cycles expended for certain features are reduced. Intended for initial pre-silicon enabling.
bit 23
SVN r4686-r5120: If set, test will skip all PCOMMIT code. Pcommit instruction was dropped prior to any product release. When running any SKX Dragon seeds between these 2 revs, set this bit. 
Newer Dragon seeds do not include pcommit and ignore this bit.
bit 24
If set, APs in test will skip jump to end_test_case_start after AP_halt for SBFT Loader to intercept and handle.
bit 25
If set, CMCI will be enabled. Instead of only checking for soft MCEs at the end of the test, when the Soft MCE Threshold vvar is exceeded, an interrupt will be triggered. Dragon will report the 
appropriate MCE failure code.
bit 26
If set, PM enabled seeds will skip the end of test PState restore verification.
bit 27
If set, disables most of the PagingRights usages and restrictions.
bit 28
If set, utilize runtime lockstep WAs (such as half CPM count on SRF).
VV[0x04]
VV_MIN_APIC_ID - Any thread < Min APIC ID will be immediately halted.
Used for running tests generated for x threads on a system with more than x threads.
VV[0x2] word 1 must be configured if this is non-zero
VV[0x05]
VV_MAX_APIC_ID - Any threads > Max APIC ID will be immediately halted. Default is 0x7FFFFFFF (no thread discards, perform TPx checks).
Used for running tests generated for x threads on a system with more than x threads.
VV[0x2] word 1 must be configured if bits[30:0] are not at default value.
Bit[31] Dragon is "stealing" this bit from the APIC ID space.
0: (default) perform thread per "x" (TPx) checks, such as TPC/TPM, as Dragon generally requires generated to match runtime.
1: skip TPx checks (only do at the direction of the Dragon team as mismatches only "work" correctly in narrow cases).
VV[0x06]
VV_THREAD_ROTATE - Contains rotate values to rotate logical ID within the system topology (package, die per package, modules per die, cores per module, threads per core).
Each logical thread id is broken down into its hierarchical components, and rotate is performed on each component using values specified in the VVAR.
Rotate is performed in order of thread, core, module, die, package.
Note: Each value is an unsigned positive forward rotate. Signed negative backwards rotates are not supported.
Note: Rotate performed and then swap performed on lowest topo level, then on each higher level.
VV[0x06] byte layout:
PD MM MM CT
P = Package rotate value (4 bits)
D = Die (within package) rotate package (4 bits)
M = Module (within die) rotate value (16 bits - 2 bytes)
C = Core (within module) rotate value (4 bits)
T = Thread (within core) rotate value (4 bits)
Example with VV_THREAD_ROTATE = 0x0000_0201 on a system with 2 threads per core, 1 core per module, 4 modules per die. (8 threads total)
0 (P0D0M0C0T0) ->  5 (P0D0M2C0T1)
1 (P0D0M0C0T1) ->  4 (P0D0M2C0T0)
2 (P0D0M1C0T0) ->  7 (P0D0M3C0T1)
3 (P0D0M1C0T1) ->  6 (P0D0M3C0T0)
4 (P0D0M2C0T0) ->  1 (P0D0M0C0T1)
5 (P0D0M2C0T1) ->  0 (P0D0M0C0T0)
6 (P0D0M3C0T0) ->  3 (P0D0M1C0T1)
7 (P0D0M3C0T1) ->  2 (P0D0M1C0T0)
VV[0x07]
VV_THREAD_SWAP_XOR - Contains swap values to swap logical ID within the system topology (package, die per package, modules per die, cores per module, threads per core).
Each logical thread id is broken down into its hierarchical components, and swap is performed on each component of the hierarchy using values specified in the VVAR.
Swap is performed in order of thread, core, module, die, package.
Note: Rotate performed and then swap performed on lowest topo level, then on each higher level.
VV[0x07] byte layout:
PD MM MM CT
P = Package rotate value (4 bits)
D = Die (within package) rotate package (4 bits)
M = Module (within die) rotate value (16 bits - 2 bytes)
C = Core (within module) rotate value (4 bits)
T = Thread (within core) rotate value (4 bits)
Example with VV_THREAD_SWAP_XOR = 0x0000_0101 on a system with 2 threads per core, 1 core per module, 4 modules per die. (8 threads total)
0 (P0D0M0C0T0) ->  3 (P0D0M1C0T1)
1 (P0D0M0C0T1) ->  2 (P0D0M1C0T0)
2 (P0D0M1C0T0) ->  1 (P0D0M0C0T1)
3 (P0D0M1C0T1) ->  0 (P0D0M0C0T0)
4 (P0D0M2C0T0) ->  7 (P0D0M3C0T1)
5 (P0D0M2C0T1) ->  6 (P0D0M3C0T0)
6 (P0D0M3C0T0) ->  5 (P0D0M2C0T1)
7 (P0D0M3C0T1) ->  4 (P0D0M2C0T0)
VV[0x08]
SOFT MCE CHECK MASK.
This is a check bit mask for each MC register.
This is as subset of VV_MC_ENABLE; Actual registers checked is VV_MC_ENABLE AND VV_MC_CHECK
Default is 0xFFFFFFFF, all MCEs checked.
e.g. bit 0 == check MC0, bit 1 == check MC1
See 
 for 'unofficial' bank decode.
Dragon IAMCE
VV[0x09]
SOFT MCE ENABLE MASK.
This is an enable bit mask for each MC register.
Default is 0xFFFFFFFF, all MCEs enabled.
e.g. bit 0 == set MC0, bit 1 == set MC1, etc
See 
 for 'unofficial' bank decode.
Dragon IAMCE
VV[0x0A]
Debug Output Flags - Decoder
bit 0
Not Defined
bit 1
INIT/Test started flag. Used to detect shutdown where test may run 2nd time due to reset.
bit 2
Flag for booted x2APIC; set by BSP only, checked by all
bit 3
Flag for BSP x2APIC is active; set/checked by BSP only (prior to r4701, checked by all)
bit 4
Flag for booted or forced to x2APIC; set by BSP only, checked by all. We exit the seed in x2Apic if forced to x2Apic.
bit 5
Flag indicating automatic socket selection (automatic setting of min and max APIC ID for DUT selection)
bit 6
Flag indicating automatic thread reduction (automatic setting of running threads less than generated threads)
bit 7
Flag indicating this was generated as a decap seed.
bit 8
Flag indicating this was generated as a VMX seed. VV_Output VV[3].bit17 disables VMX at runtime.
bit 9
Flag indicating this was generated as a PM C-State seed. VV_Output VV[3].bit16 disables PM at runtime.
bit 10
Flag indicating this was generated as a PM P-State seed. VV_Output VV[3].bit16 disables PM at runtime.
bit 11
Flag indicating this was generated as a PM Turbo seed. VV_Output VV[3].bit16 disables PM at runtime.
bit 12
Flag indicating this was generated as a User Level Wait seed. VV_Output VV[3].bit16 disables PM/ULW at runtime.
bit 13
Flag indicating this was generated as a PM UFS seed (ignore if P-State/Turbo bits 10 and 11 are both clear). VV_Output VV[3].bit16 disables PM at runtime.
bit 14
Flag indicating this was generated as a PM FACT seed. VV_Output VV[3].bit16 disables PM at runtime.
bit 15
Flag indicating this was generated as a LittleFoot (LF) seed. This generates as a small bundle of threads, and then replicates them at runtime to scale to higher thread counts.
bit 16
Flag indicating at least one thread failed. This is only set if atomic locks are allowed (which they aren't in iso-SBFT, and Dragon doesn't do in RO/MO/RC SBFT either).
VV[0x0B]
Dragon SVN Revision.
Default
ADL/RPL
/BTL
MTL
/ARLU
PMR
SPR
/EMRMCC
EMRXCC
GNR
SRF/CWF
DMR
VV
[0x0C0x4B]
VV
[0x0C0x2
B]
VV
[0x0C0x12B]
VV
[0x0C0x20B]
VV
[0x0C0x32B]
Per Thread Status
Dragon Error Decoders
See 
 for full details.
Dragon Thread Status
The top nibble of the 32-bit code indicates which overall "group" it belongs to.
But the actual failure 
 isn't strictly aligned with that (esp for "#GP").
bucket/priority
0x1, 0x2 - issue during startup/teardown
0x4, 0x5 - missing feature
600D600D - BM: Thread passed
0x7 - BM thread counting issues
0xA, 0xB - BM logged MCE
0xC, 0xD - special error code or x86 interrupt
0xF - Test algo reported issue
VV
[0x4C0x4D]
VV
[0x2C0x2
D]
VV
[0x12C0x12
D]
VV
[0x20C0x20
D]
VV
[0x32C0x32
D]
Number of CPU cycles the test ran during a passing run.
Note: ACNT not correct if 
 is used on tester in MLC or Slice mode (VV[0x03] bits 9 & 11 set).
DR1 cycle scaling
Dwor
d 0
ACNT Low. Low DWORD of the number of CPU cycles.
Dwor
d 1
ACNT High. High DWORD of the number of CPU cycles.
VV[0x4E]
VV[0x2E]
VV[0x12E]
VV[0x20E]
VV[0x32E]
Loop Count Minimum of all the threads. May not be min of all threads on early exit (thread 0 fail or VV_DEBUG_IMM_EXIT_ON_FAIL).
VV[0x4F]
VV[0x2F]
VV[0x12F]
VV[0x20F]
VV[0x32F]
Loop Count Maximum of all the threads. May not be max of all threads on early exit (thread 0 fail or VV_DEBUG_IMM_EXIT_ON_FAIL).
VV
[0x500x58]
VV
[0x300x38]
VV
[0x1300x13
8]
VV
[0x2100x21
8]
VV
[0x3300x33
8]
PMON Input (feeds to all threads) and Output (BSP Only).
VV[0x59]
VV[0x39]
VV[0x139]
VV[0x219]
VV[0x339]
Cumulative status for thread errors - multiple threads could write into this to report a thread error.
VV[0x5A]
VV[0x3A]
VV[0x13A]
VV[0x21A]
VV[0x33A]
SOFT MCE THRESHOLD BITS (Banks 0 to 7)
Used for Thresholding Soft MCE's. Failure when count is greater than or equal to threshold.
Each nibble contains the threshold for the corresponding bank.
The nibble value is translated to a power of two minus one threshold.
Default is 0x1, fail on one or more soft MCE's
e.g. 0x4 = 2  - 1 = 31 threshold
4
NOTE: Not all Banks are guaranteed to be enabled on all products, Check 
 for list of enabled banks on products
Dragon IAMCE
VV[0x5B]
VV[0x3B]
VV[0x13B]
VV[0x21B]
VV[0x33B]
SOFT MCE THRESHOLD BITS (Banks 8 to 15)
Used for Thresholding Soft MCE's. Failure when count is greater than or equal to threshold.
Each nibble contains the threshold for the corresponding bank.
The nibble value is translated to a power of two minus one threshold.
Default is 0x1, fail on one or more soft MCE's
e.g. 0x4 = 2  - 1 = 31 threshold
4
NOTE: Not all Banks are guaranteed to be enabled on all products, Check 
 for list of enabled banks on products
Dragon IAMCE
VV[0x5C]
VV[0x3C]
VV[0x13C]
VV[0x21C]
VV[0x33C]
SOFT MCE THRESHOLD BITS (Banks 16 to 23)
Used for Thresholding Soft MCE's. Failure when count is greater than or equal to threshold.
Each nibble contains the threshold for the corresponding bank.
The nibble value is translated to a power of two minus one threshold.
Default is 0x1, fail on one or more soft MCE's
e.g. 0x4 = 2  - 1 = 31 threshold
4
NOTE: Not all Banks are guaranteed to be enabled on all products, Check 
 for list of enabled banks on products
Dragon IAMCE
VV[0x5D]
VV[0x3D]
VV[0x13D]
VV[0x21D]
VV[0x33D]
SOFT MCE THRESHOLD BITS (Banks 24 to 31)
Used for Thresholding Soft MCE's. Failure when count is greater than or equal to threshold.
Each nibble contains the threshold for the corresponding bank.
The nibble value is translated to a power of two minus one threshold.
Default is 0x1, fail on one or more soft MCE's
e.g. 0x4 = 2  - 1 = 31 threshold
4
NOTE: Not all Banks are guaranteed to be enabled on all products, Check 
 for list of enabled banks on products
Dragon IAMCE
VV[0x5E]
VV[0x3E]
VV[0x13E]
VV[0x21E]
VV[0x33E]
IA32_MCG_CAP override
If value != 0xFFFFFFFF, then this will be used instead of doing a RDMSR(IA_MCG_CAP).
This is most likely used for Slice mode override where IA_MCG_CAP can not be read.
VV[0x5F]
VV[0x3F]
VV[0x13F]
VV[0x21F]
VV[0x33F]
Not LLC Way Mask
VV[0x60]
VV[0x40]
VV[0x140]
VV[0x220]
VV[0x340]
Wait/Exit VVAR
bit 0
VV_WAIT_BSP: When set BSP will WAIT early in bsp_init, well before sending SIPI to wake other threads. Clearing bit proceeds with startup.
bit 1
VV_WAIT_BSP_END_TEST: When set BSP will WAIT before jumping to end_test_case_start. Clearing bit proceeds with end_test_case_start.
bit 2
VV_WAIT_BSP_DR0: When set BSP will WAIT early in bsp_init, well before sending SIPI to wake other threads. Setting IA_CR_DR0 = 0xd05e3a17 proceeds with startup.
bit 3
VV_WAIT_ALL_SORT: When set (and !no_snoop) all threads will WAIT at top of pick_logical_id (thread sort). Clearing bit proceeds with startup.
bit 4
VV_WAIT_BSP_END_TEST_FAIL: When set (and test fails), BSP will WAIT before jumping to end_test_case_start. Clearing bit proceeds with end_test_case_start.
bit 5
VV_WAIT_ALL_LOCAL_FAIL:
When set (and thread fails), that thread will WAIT at start of "common" handler. Clearing bit proceeds with all threads.
WARNING: Soft/corrected MCE check normally isn't until after a thread is otherwise complete. If intending to WAIT on that type of failure, it is advised to set VV_DEBUG_CMCI as well, that will 
trigger fail (and WAIT) at the MCE occurence.
bit 6
VV_WAIT_ALL_AnyFail_TscExit:
When set (and any thread fails, and atomic lock allowed), all threads will WAIT at start Tsc.Exit(). Clearing bit proceeds with all threads. It can be helpful to set VV_WAIT_ALL_LOCAL_FAIL as 
well.
WARNING: By the time a thread fails, some threads may already be past Tsc.Exit() and possiblly all the way to hlt. Therefore, it is advised to set VV_WAIT_BSP_END_TEST_FAIL and/or 
VV_WAIT_ALL_TscExit as well.
WARNING: Soft/corrected MCE check normally isn't until after a thread is otherwise complete. If intending to WAIT on that type of failure, it is advised to set VV_DEBUG_CMCI as well, that will 
trigger fail at the MCE occurence.
WARNING: PM seeds: This may be BEFORE any WakeUpAllThreads()...PingLock() and some threads may be asleep! itp.halt() will generally wake them.
bit 7
VV_WAIT_ALL_TscExit:
When set, all threads will WAIT at start Tsc.Exit(). Clearing bit proceeds with all threads.
WARNING: PM seeds: This is BEFORE all WakeUpAllThreads()...PingLock() and some threads may be asleep! itp.halt() will generally wake them.
bit 8
VV_WAIT_ALL_THREADS: When set all threads will WAIT just before starting the test main payload. Clearing bit proceeds with test (all threads).
bit 9
VV_WAIT_ALL_THREADS_DR0: When set all threads will WAIT just before starting the test main payload. Setting IA_CR_DR0 = 0xd05e3a17 proceeds with test (per thread).
bit 10
VV_WAIT_ALL_AnyFail_TscCompareEarlyExit:
When set (and any thread fails, and atomic lock allowed), all threads will EXIT at top of Tsc.Compare(), even if runtime target not elapsed.
WARNING: Soft/corrected MCE check normally isn't until after a thread is otherwise complete. If intending to EXIT early on that type of failure, it is advised to set VV_DEBUG_CMCI as well, 
that will trigger fail at the MCE occurence.
VV[0x61]
VV[0x41]
VV[0x141]
VV[0x221]
VV[0x341]
Not MLC Way Mask
VV[0x62]
VV[0x42]
VV[0x142]
VV[0x222]
VV[0x342]
(output) Address of this seed's Dragon ThreadBlockHeader (TBH, aka DebugSpace) - provided for debug tool use
VV[0x63]
VV[0x43]
VV[0x143]
VV[0x223]
VV[0x343]
(output) Core type table consisting of a composite of bit(s) from CPUID Core Type and LLC cache fields.
This table contains the order in which thread block types are stored and processed in the seed.
Reverse ordered (relative to logical ID sequence):
byte 3 [31:24] is index 0 and contains the type ID value of the 1st core type
byte 2 [23:16] is index 1 and contains the type ID value of the (potential) 2nd core type
byte 1 [15:08] is index 2 and contains the type ID value of the (potential) 3rd core type
byte 0 [07:00] is index 3 and contains the type ID value of the (potential) 4th core type
4 type ID values are supported for now:
00 - Atom, subtype 0 (no LLC)
01 - Atom, subtype 1 (has LLC)
10 - Big Core, subtype 0 (no LLC)
11 - Big Core, subtype 1 (has LLC)
VV[0x64]
VV[0x44]
VV[0x144]
VV[0x224]
VV[0x344]
(output) Contains the threads per core (TPC) and cores per module (CPM) for each of the supported composite core type IDs (indexed by ID value).
Byte layout:
4 currently supported composite core type IDs (indexed by ID value) and 1 nibble per field (CPM or TPC).
CPM3 TPC3 CPM2 TPC2 CPM1 TPC1 CPM0 TPC0 where
CPM3: cores per module for type ID value 3 (4 bits)
TPC3: threads per core for type ID value 3 (4 bits)
...
CPM0: cores per module for type ID value 0 (4 bits)
TPC0: threads per core for type ID value 0 (4 bits)
VV
[0x650x66]
VV
[0x450x46]
VV
[0x1450x14
6]
VV
[0x2250x22
6]
VV
[0x3450x34
6]
(output) Contains the generated threads (1 word each), indexed by composite core type ID values 0-3.
VV
[0x670x68]
VV
[0x470x48]
VV
[0x1470x14
8]
VV
[0x2270x22
8]
VV
[0x3470x34
8]
(output) Hybrid seeds only: contains the runtime threads (1 word each), indexed by composite core type ID values 0-3. Non-hybrid is always 0.
VV
[0x690xA8]
VV
[0x490x68]
VV
[0x1490x26
8]
VV
[0x2290x42
8]
VV
[0x3490x66
8]
Per Thread Gen Thread Mapping - Output only
Per Thread VVAR (logical thread order) which indicates (Bundle ID, generated thread ID, and APIC ID).
Decoding the output varies depending upon whether LittleFoot scaling is enabled in the seed: VV[0xA].bit[15].
LittleFoot enabled
BB GG AA AA
B = Bundle ID (byte 3)
G = Generated thread ID (byte 2)
A = APIC ID (word 0 - bytes 0-1)
non-LittleFoot
GG GG AA AA
G = Generated thread ID (word 1 - bytes 2-3)
A = APIC ID (word 0 - bytes 0-1)
VV[0xA9]
VV[0x69]
VV[0x269]
VV[0x429]
VV[0x669]
(output) Control bundle ID - For varying which bundle does things like PM control thread, DRNG PBIST, etc. Defaulted to 0 for non-LittleFoot seeds.
VV[0xAA]
VV[0x6A]
VV[0x26A]
VV[0x42A]
VV[0x66A]
Skip MCi CTL Write Mask:
This is a per-MC bank mask to skip MCi CTL MSR writes in the MC enable phase in Dragon startup code. If set, SKIPS writing the MCi CTL MSR for the bank.
Default 0x0 - all MC banks (max value defined by IA32_MCG_CAP) are written if the MC enable flow is executed.
e.g., bit 1 = SKIP WRMSR to MSR 0x404 (MCi CTL MSR for bank 1).
VV[0xAB]
VV[0x6B]
VV[0x26B]
VV[0x42B]
VV[0x66B]
Skip MCi STATUS Write Mask:
This is a per-MC bank mask to skip MCi STATUS MSR writes in MC enable phase in Dragon startup code. If set, SKIPS clearing the MCi STATUS MSR for the bank.
Default 0x0 - all MC banks (max value defined by IA32_MCG_CAP) are written if the MC enable flow is executed.
e.g., bit 1 = SKIP WRMSR to MSR 0x405 (MCi STATUS MSR for bank 1).
VV
[0xAC0xA
D]
VV
[0x6C0x6
D]
VV
[0x26C0x26
D]
VV
[0x42C0x42
D]
VV
[0x66C0x66
D]
DRNG Config patch2/3 rax:
Defaulted to Dragon expected value for the generated product.
This vvar can be overridden if: that value is incorrect, or used on a product with a different port value, or set to 0 to bypass.
If 0, will skip Dragon DRNG BIST Config access (won't restart BIST), but leaves Dragon rdrand/rdseed testing enabled.
VV_DEBUG can be used to disable all Dragon DRNG testing.
Note this only changes the value for the primary Dragon threads. In products like MTL/ARL, the SoC die access value is not modified by this, but 0 still skips.
This also does not modify the upper port configuration value of SPR/EMR built seeds.
VV
[0xAE0xAF]
VV
[0x6E0x6F]
VV
[0x26E0x26
F]
VV
[0x42E0x42
F]
VV
[0x66E0x66
F]
DRNG Status patch2/3 rax:
Defaulted to Dragon expected value for the generated product.
This vvar can be overridden if: that value is incorrect, or used on a product with a different port value, or set to 0 to bypass.
If 0, will skip Dragon DRNG BIST Status access (won't check BIST), but leaves Dragon rdrand/rdseed testing enabled.
VV_DEBUG can be used to disable all Dragon DRNG testing.
Note this only changes the value for the primary Dragon threads. In products like MTL/ARL, the SoC die access value is not modified by this, but 0 still skips.
This also does not modify the upper port configuration value of SPR/EMR built seeds.
VV[0xB0]
VV[0x70]
VV[0x270]
VV[0x430]
VV[0x670]
PM Barrier Timeout in microseconds:
Defaulted to Dragon expected value for the generated product and test behavior.
This vvar can be overridden by direction of Dragon team if experiments determine:
It needs lengthened for a particular valid condition combination.
It needs shortened to tighten detection of incorrect delay.
Note too long a value may cause an automation timeout (if not also increased) instead of a "clean" PM barrier timeout errorcode.
VV[0xB1]
VV[0x71]
VV[0x271]
VV[0x431]
VV[0x671]
PM Finalize Ratio Restore Timeout in pause loops:
Defaulted to Dragon expected value for the generated product and test behavior.
This vvar can be overridden by direction of Dragon team if experiments determine:
It needs lengthened for a particular valid condition combination.
It needs shortened to tighten detection of incorrect delay.
Note too long a value may cause an automation timeout (if not also increased) instead of a "clean" PM ratio restore timeout errorcode.
SVN 8250 - 8251
Old versions click here
Dragon VVars Changelog
VVAR
Description
VV[0x00]
Test runtime
Min execution time in CPU cycles (after bus translated to CPU HFM) = (VV[0x00]*VV[0x01])/212
Defaults
System: Microseconds
Ex: 3 sec = 3,000,000 us = 0x2DC6C0
Tester: CPU Cycles
VV[0x01]
32-bit fixed point value to scale VV[0x00] by: 2
 integer, 2
 fractional
20
12
Min execution time in CPU cycles (after bus translated to CPU HFM) = (VV[0x00]*VV[0x01])/212
If the top bit is clear, this vvar refers to CPU HFM freq in scaled MHz.
If the top bit is set on system (default), this vvar refers to bus freq in scaled MHz. This bit is ignored on non-system. Dragon's startup will clear this bit and multiply by the CPU HFM ratio to get to the 
CPU HFM freq in scaled MHz.
Defaults
System: Scale VV[0x00] by expected bus frequency in MHZ
ex: 0x80064000 (100 MHz bus * 2
)
12
System: Scale VV[0x00] by expected CPU HFM frequency in MHZ
ex: 0x00bb8000 (3000 MHz CPU HFM * 2
)
12
Tester: 0x1000 (don't scale VV[0x00])
VV[0x00] scaling factor examples
To be clear, these only scale VV[0x00] (time in microseconds), not the original test runtime. Test runtime is calculated from the VV[0x00] and VV[0x01] inputs.
0x800 - scale VV[0x00] down by 1/2
0x1000 - don't scale VV[0x00]
0x2000 - scale VV[0x00] up by 2x
0xA000 - scale VV[0x00] up by 10x
VV[0x02]
Thread Count VVar
VV[0x02] byte layout:
SE PD RR RR
Note: "package" means actual package except when running 1 die per package seeds on multiple die per package parts. In that case "package" means die.
S = start package (4 bits)
E = expected number of packages (4 bits)
P = (output only) generated packages (4 bits)
D = (output only) log2(generated dies per package), so 0 = 1 die, 1 = 2 die, 2 = 4 die, etc (4 bits)
R = running threads (16 bits)
word 0 This VVar is used to override the number of threads to run the Dragon test on.
If 0 (default): Dragon startup will use defaults:
System default: # of threads in package * # of sockets generated for
All other default (tester/archsim/etc): # of threads generated for
Override usefulness
For debug, to run Dragon on only some of threads in the unit. Requires setting min and max apic to discard the unwanted threads.
byte 2
nibble 0: D = (output only) log2(generated dies per package), so 0 = 1 die, 1 = 2 die, 2 = 4 die, etc (4 bits)
nibble 1: P = (output only) generated packages (4 bits)
byte 3
nibble 0: expected number of packages populated in the system
If 0: Dragon will use the # of packages it was generated for
Only useful for multi-socket systems (Xeon Servers)
If communicated up front, the Dragon team can generate this with your default configuration.
Otherwise, you will need to override this if the system has more packages than the seed was generated for.
WARNING: The other packages will NOT run any Dragon test code (just some startup code).
nibble 1: zero-based starting package to run Dragon on
Default: 0: run starting from package 0
VV[0x03]
Debug Flags - Decoder
bit 0
Not Defined
bit 1
Not Defined
bit 2
Ignore INIT flag. Dont fail if this flag has been set.
bit 3
System Only: All WBINVDs will be skipped during the test.
bit 4
Not Defined
bit 5
SKIP SIPI. Used for single thread mode or for simulation where other mechanism for waking up SIPI is used.
bit 6
Not Defined
bit 7
PROC_SPECIFIC_DFX, set by Dragon during generation, do not modify unless directed to do so.
ANN enables code to remap 2nd BSP to an AP
bit 8
NO_SNOOP: If set skip startup accesses which create cross thread snoops; needed for compatibility for certain tester SBFT modes.
Must be generated with this set because algorithm cross-thread snoops are only prevented at generation time, not runtime.
Undefined or strange behavior on system. Do not modify unless directed to do so.
bit 9
DFX SIPI: Set for MLC and Slice mode on tester.
bit 10
Simulation Flag. Will be set if test is running on Archsim.
bit 11
Tester Mode: Startup code flow will be SBFT compliant and run tester specific code.
bit 12
JMP-SELF in Tester Mode: When set, all threads will end with a JMP $ instead of a halt.
bit 13
Not Defined
bit 14
Not Defined
bit 15
Counter check. Verifies that TSC is running. Don't use this with Archsim!
bit 16
If set, power management functionality is turned off for seeds that have c-states or p-states or turbo or user-level wait enabled. Also useful for e-swift, esp since APIC is used.
bit 17
If set, VMX functionality is turned off for seeds that have vmx enabled. Useful for debug.
bit 18
If set, TLA trigger ( OUT 0xf8 ) will be skipped
bit 19
If set, test will exit immedately on any failure.
bit 20
If set, test will skip all RDRAND sparks and DRNG PBIST code
bit 21
If set, test will skip all HLE and RTM sparks
bit 22
If set cycles expended for certain features are reduced. Intended for initial pre-silicon enabling.
bit 23
SVN r4686-r5120: If set, test will skip all PCOMMIT code. Pcommit instruction was dropped prior to any product release. When running any SKX Dragon seeds between these 2 revs, set this bit. 
Newer Dragon seeds do not include pcommit and ignore this bit.
bit 24
If set, APs in test will skip jump to end_test_case_start after AP_halt for SBFT Loader to intercept and handle.
bit 25
If set, CMCI will be enabled. Instead of only checking for soft MCEs at the end of the test, when the Soft MCE Threshold vvar is exceeded, an interrupt will be triggered. Dragon will report the 
appropriate MCE failure code.
bit 26
If set, PM enabled seeds will skip the end of test PState restore verification.
bit 27
If set, disables most of the PagingRights usages and restrictions.
bit 28
If set, utilize runtime lockstep WAs (such as half CPM count on SRF).
VV[0x04]
VV_MIN_APIC_ID - Any thread < Min APIC ID will be immediately halted.
Used for running tests generated for x threads on a system with more than x threads.
VV[0x2] word 1 must be configured if this is non-zero
VV[0x05]
VV_MAX_APIC_ID - Any threads > Max APIC ID will be immediately halted. Default is 0x7FFFFFFF (no thread discards, perform TPx checks).
Used for running tests generated for x threads on a system with more than x threads.
VV[0x2] word 1 must be configured if bits[30:0] are not at default value.
Bit[31] Dragon is "stealing" this bit from the APIC ID space.
0: (default) perform thread per "x" (TPx) checks, such as TPC/TPM, as Dragon generally requires generated to match runtime.
1: skip TPx checks (only do at the direction of the Dragon team as mismatches only "work" correctly in narrow cases).
VV[0x06]
VV_THREAD_ROTATE - Contains rotate values to rotate logical ID within the system topology (package, die per package, modules per die, cores per module, threads per core).
Each logical thread id is broken down into its hierarchical components, and rotate is performed on each component using values specified in the VVAR.
Rotate is performed in order of thread, core, module, die, package.
Note: Each value is an unsigned positive forward rotate. Signed negative backwards rotates are not supported.
Note: Rotate performed and then swap performed on lowest topo level, then on each higher level.
VV[0x06] byte layout:
PD MM MM CT
P = Package rotate value (4 bits)
D = Die (within package) rotate package (4 bits)
M = Module (within die) rotate value (16 bits - 2 bytes)
C = Core (within module) rotate value (4 bits)
T = Thread (within core) rotate value (4 bits)
Example with VV_THREAD_ROTATE = 0x0000_0201 on a system with 2 threads per core, 1 core per module, 4 modules per die. (8 threads total)
0 (P0D0M0C0T0) ->  5 (P0D0M2C0T1)
1 (P0D0M0C0T1) ->  4 (P0D0M2C0T0)
2 (P0D0M1C0T0) ->  7 (P0D0M3C0T1)
3 (P0D0M1C0T1) ->  6 (P0D0M3C0T0)
4 (P0D0M2C0T0) ->  1 (P0D0M0C0T1)
5 (P0D0M2C0T1) ->  0 (P0D0M0C0T0)
6 (P0D0M3C0T0) ->  3 (P0D0M1C0T1)
7 (P0D0M3C0T1) ->  2 (P0D0M1C0T0)
VV[0x07]
VV_THREAD_SWAP_XOR - Contains swap values to swap logical ID within the system topology (package, die per package, modules per die, cores per module, threads per core).
Each logical thread id is broken down into its hierarchical components, and swap is performed on each component of the hierarchy using values specified in the VVAR.
Swap is performed in order of thread, core, module, die, package.
Note: Rotate performed and then swap performed on lowest topo level, then on each higher level.
VV[0x07] byte layout:
PD MM MM CT
P = Package rotate value (4 bits)
D = Die (within package) rotate package (4 bits)
M = Module (within die) rotate value (16 bits - 2 bytes)
C = Core (within module) rotate value (4 bits)
T = Thread (within core) rotate value (4 bits)
Example with VV_THREAD_SWAP_XOR = 0x0000_0101 on a system with 2 threads per core, 1 core per module, 4 modules per die. (8 threads total)
0 (P0D0M0C0T0) ->  3 (P0D0M1C0T1)
1 (P0D0M0C0T1) ->  2 (P0D0M1C0T0)
2 (P0D0M1C0T0) ->  1 (P0D0M0C0T1)
3 (P0D0M1C0T1) ->  0 (P0D0M0C0T0)
4 (P0D0M2C0T0) ->  7 (P0D0M3C0T1)
5 (P0D0M2C0T1) ->  6 (P0D0M3C0T0)
6 (P0D0M3C0T0) ->  5 (P0D0M2C0T1)
7 (P0D0M3C0T1) ->  4 (P0D0M2C0T0)
VV[0x08]
SOFT MCE CHECK MASK.
This is a check bit mask for each MC register.
This is as subset of VV_MC_ENABLE; Actual registers checked is VV_MC_ENABLE AND VV_MC_CHECK
Default is 0xFFFFFFFF, all MCEs checked.
e.g. bit 0 == check MC0, bit 1 == check MC1
See 
 for 'unofficial' bank decode.
Dragon IAMCE
VV[0x09]
SOFT MCE ENABLE MASK.
This is an enable bit mask for each MC register.
Default is 0xFFFFFFFF, all MCEs enabled.
e.g. bit 0 == set MC0, bit 1 == set MC1, etc
See 
 for 'unofficial' bank decode.
Dragon IAMCE
VV[0x0A]
Debug Output Flags - Decoder
bit 0
Not Defined
bit 1
INIT/Test started flag. Used to detect shutdown where test may run 2nd time due to reset.
bit 2
Flag for booted x2APIC; set by BSP only, checked by all
bit 3
Flag for BSP x2APIC is active; set/checked by BSP only (prior to r4701, checked by all)
bit 4
Flag for booted or forced to x2APIC; set by BSP only, checked by all. We exit the seed in x2Apic if forced to x2Apic.
bit 5
Flag indicating automatic socket selection (automatic setting of min and max APIC ID for DUT selection)
bit 6
Flag indicating automatic thread reduction (automatic setting of running threads less than generated threads)
bit 7
Flag indicating this was generated as a decap seed.
bit 8
Flag indicating this was generated as a VMX seed. VV_Output VV[3].bit17 disables VMX at runtime.
bit 9
Flag indicating this was generated as a PM C-State seed. VV_Output VV[3].bit16 disables PM at runtime.
bit 10
Flag indicating this was generated as a PM P-State seed. VV_Output VV[3].bit16 disables PM at runtime.
bit 11
Flag indicating this was generated as a PM Turbo seed. VV_Output VV[3].bit16 disables PM at runtime.
bit 12
Flag indicating this was generated as a User Level Wait seed. VV_Output VV[3].bit16 disables PM/ULW at runtime.
bit 13
Flag indicating this was generated as a PM UFS seed (ignore if P-State/Turbo bits 10 and 11 are both clear). VV_Output VV[3].bit16 disables PM at runtime.
bit 14
Flag indicating this was generated as a PM FACT seed. VV_Output VV[3].bit16 disables PM at runtime.
bit 15
Flag indicating this was generated as a LittleFoot (LF) seed. This generates as a small bundle of threads, and then replicates them at runtime to scale to higher thread counts.
VV[0x0B]
Dragon SVN Revision.
Default
ADL/RPL
/BTL
MTL
/ARLU
PMR
SPR
/EMRMCC
EMRXCC
GNR
SRF/CWF
DMR
VV
[0x0C0x4B]
VV
[0x0C0x2
B]
VV
[0x0C0x12B]
VV
[0x0C0x20B]
VV
[0x0C0x32B]
Per Thread Status
Dragon Error Decoders
See 
 for full details.
Dragon Thread Status
The top nibble of the 32-bit code indicates which overall "group" it belongs to.
But the actual failure 
 isn't strictly aligned with that (esp for "#GP").
bucket/priority
0x1, 0x2 - issue during startup/teardown
0x4, 0x5 - missing feature
600D600D - BM: Thread passed
0x7 - BM thread counting issues
0xA, 0xB - BM logged MCE
0xC, 0xD - special error code or x86 interrupt
0xF - Test algo reported issue
VV
[0x4C0x4D]
VV
[0x2C0x2
D]
VV
[0x12C0x12
D]
VV
[0x20C0x20
D]
VV
[0x32C0x32
D]
Number of CPU cycles the test ran during a passing run.
Note: ACNT not correct if 
 is used on tester in MLC or Slice mode (VV[0x03] bits 9 & 11 set).
DR1 cycle scaling
Dwor
d 0
ACNT Low. Low DWORD of the number of CPU cycles.
Dwor
d 1
ACNT High. High DWORD of the number of CPU cycles.
VV[0x4E]
VV[0x2E]
VV[0x12E]
VV[0x20E]
VV[0x32E]
Loop Count Minimum of all the threads. May not be min of all threads on early exit (thread 0 fail or VV_DEBUG_IMM_EXIT_ON_FAIL).
VV[0x4F]
VV[0x2F]
VV[0x12F]
VV[0x20F]
VV[0x32F]
Loop Count Maximum of all the threads. May not be max of all threads on early exit (thread 0 fail or VV_DEBUG_IMM_EXIT_ON_FAIL).
VV
[0x500x58]
VV
[0x300x38]
VV
[0x1300x13
8]
VV
[0x2100x21
8]
VV
[0x3300x33
8]
PMON Input (feeds to all threads) and Output (BSP Only).
VV[0x59]
VV[0x39]
VV[0x139]
VV[0x219]
VV[0x339]
Cumulative status for thread errors - multiple threads could write into this to report a thread error.
VV[0x5A]
VV[0x3A]
VV[0x13A]
VV[0x21A]
VV[0x33A]
SOFT MCE THRESHOLD BITS (Banks 0 to 7)
Used for Thresholding Soft MCE's. Failure when count is greater than or equal to threshold.
Each nibble contains the threshold for the corresponding bank.
The nibble value is translated to a power of two minus one threshold.
Default is 0x1, fail on one or more soft MCE's
e.g. 0x4 = 2  - 1 = 31 threshold
4
NOTE: Not all Banks are guaranteed to be enabled on all products, Check 
 for list of enabled banks on products
Dragon IAMCE
VV[0x5B]
VV[0x3B]
VV[0x13B]
VV[0x21B]
VV[0x33B]
SOFT MCE THRESHOLD BITS (Banks 8 to 15)
Used for Thresholding Soft MCE's. Failure when count is greater than or equal to threshold.
Each nibble contains the threshold for the corresponding bank.
The nibble value is translated to a power of two minus one threshold.
Default is 0x1, fail on one or more soft MCE's
e.g. 0x4 = 2  - 1 = 31 threshold
4
NOTE: Not all Banks are guaranteed to be enabled on all products, Check 
 for list of enabled banks on products
Dragon IAMCE
VV[0x5C]
VV[0x3C]
VV[0x13C]
VV[0x21C]
VV[0x33C]
SOFT MCE THRESHOLD BITS (Banks 16 to 23)
Used for Thresholding Soft MCE's. Failure when count is greater than or equal to threshold.
Each nibble contains the threshold for the corresponding bank.
The nibble value is translated to a power of two minus one threshold.
Default is 0x1, fail on one or more soft MCE's
e.g. 0x4 = 2  - 1 = 31 threshold
4
NOTE: Not all Banks are guaranteed to be enabled on all products, Check 
 for list of enabled banks on products
Dragon IAMCE
VV[0x5D]
VV[0x3D]
VV[0x13D]
VV[0x21D]
VV[0x33D]
SOFT MCE THRESHOLD BITS (Banks 24 to 31)
Used for Thresholding Soft MCE's. Failure when count is greater than or equal to threshold.
Each nibble contains the threshold for the corresponding bank.
The nibble value is translated to a power of two minus one threshold.
Default is 0x1, fail on one or more soft MCE's
e.g. 0x4 = 2  - 1 = 31 threshold
4
NOTE: Not all Banks are guaranteed to be enabled on all products, Check 
 for list of enabled banks on products
Dragon IAMCE
VV[0x5E]
VV[0x3E]
VV[0x13E]
VV[0x21E]
VV[0x33E]
IA32_MCG_CAP override
If value != 0xFFFFFFFF, then this will be used instead of doing a RDMSR(IA_MCG_CAP).
This is most likely used for Slice mode override where IA_MCG_CAP can not be read.
VV[0x5F]
VV[0x3F]
VV[0x13F]
VV[0x21F]
VV[0x33F]
Not LLC Way Mask
VV[0x60]
VV[0x40]
VV[0x140]
VV[0x220]
VV[0x340]
Wait/Exit VVAR
bit 0
VV_WAIT_BSP: When set BSP will WAIT early in bsp_init, well before sending SIPI to wake other threads. Clearing bit proceeds with startup.
bit 1
VV_WAIT_BSP_END_TEST: When set BSP will WAIT before jumping to end_test_case_start. Clearing bit proceeds with end_test_case_start.
bit 2
VV_WAIT_BSP_DR0: When set BSP will WAIT early in bsp_init, well before sending SIPI to wake other threads. Setting IA_CR_DR0 = 0xd05e3a17 proceeds with startup.
bit 3
VV_WAIT_ALL_SORT: When set (and !no_snoop) all threads will WAIT at top of pick_logical_id (thread sort). Clearing bit proceeds with startup.
bit 4
VV_WAIT_BSP_END_TEST_FAIL: When set (and test fails), BSP will WAIT before jumping to end_test_case_start. Clearing bit proceeds with end_test_case_start.
bit 8
VV_WAIT_ALL_THREADS: When set all threads will WAIT just before starting the test main payload. Clearing bit proceeds with test (all threads).
bit 9
VV_WAIT_ALL_THREADS_DR0: When set all threads will WAIT just before starting the test main payload. Setting IA_CR_DR0 = 0xd05e3a17 proceeds with test (per thread).
VV[0x61]
VV[0x41]
VV[0x141]
VV[0x221]
VV[0x341]
Not MLC Way Mask
VV[0x62]
VV[0x42]
VV[0x142]
VV[0x222]
VV[0x342]
(output) Address of this seed's Dragon ThreadBlockHeader (TBH, aka DebugSpace) - provided for debug tool use
VV[0x63]
VV[0x43]
VV[0x143]
VV[0x223]
VV[0x343]
(output) Core type table consisting of a composite of bit(s) from CPUID Core Type and LLC cache fields.
This table contains the order in which thread block types are stored and processed in the seed.
Reverse ordered (relative to logical ID sequence):
byte 3 [31:24] is index 0 and contains the type ID value of the 1st core type
byte 2 [23:16] is index 1 and contains the type ID value of the (potential) 2nd core type
byte 1 [15:08] is index 2 and contains the type ID value of the (potential) 3rd core type
byte 0 [07:00] is index 3 and contains the type ID value of the (potential) 4th core type
4 type ID values are supported for now:
00 - Atom, subtype 0 (no LLC)
01 - Atom, subtype 1 (has LLC)
10 - Big Core, subtype 0 (no LLC)
11 - Big Core, subtype 1 (has LLC)
VV[0x64]
VV[0x44]
VV[0x144]
VV[0x224]
VV[0x344]
(output) Contains the threads per core (TPC) and cores per module (CPM) for each of the supported composite core type IDs (indexed by ID value).
Byte layout:
4 currently supported composite core type IDs (indexed by ID value) and 1 nibble per field (CPM or TPC).
CPM3 TPC3 CPM2 TPC2 CPM1 TPC1 CPM0 TPC0 where
CPM3: cores per module for type ID value 3 (4 bits)
TPC3: threads per core for type ID value 3 (4 bits)
...
CPM0: cores per module for type ID value 0 (4 bits)
TPC0: threads per core for type ID value 0 (4 bits)
VV
[0x650x66]
VV
[0x450x46]
VV
[0x1450x14
6]
VV
[0x2250x22
6]
VV
[0x3450x34
6]
(output) Contains the generated threads (1 word each), indexed by composite core type ID values 0-3.
VV
[0x670x68]
VV
[0x470x48]
VV
[0x1470x14
8]
VV
[0x2270x22
8]
VV
[0x3470x34
8]
(output) Hybrid seeds only: contains the runtime threads (1 word each), indexed by composite core type ID values 0-3. Non-hybrid is always 0.
VV
[0x690xA8]
VV
[0x490x68]
VV
[0x1490x26
8]
VV
[0x2290x42
8]
VV
[0x3490x66
8]
Per Thread Gen Thread Mapping - Output only
Per Thread VVAR (logical thread order) which indicates (Bundle ID, generated thread ID, and APIC ID).
Decoding the output varies depending upon whether LittleFoot scaling is enabled in the seed: VV[0xA].bit[15].
LittleFoot enabled
BB GG AA AA
B = Bundle ID (byte 3)
G = Generated thread ID (byte 2)
A = APIC ID (word 0 - bytes 0-1)
non-LittleFoot
GG GG AA AA
G = Generated thread ID (word 1 - bytes 2-3)
A = APIC ID (word 0 - bytes 0-1)
VV[0xA9]
VV[0x69]
VV[0x269]
VV[0x429]
VV[0x669]
(output) Control bundle ID - For varying which bundle does things like PM control thread, DRNG PBIST, etc. Defaulted to 0 for non-LittleFoot seeds.
VV[0xAA]
VV[0x6A]
VV[0x26A]
VV[0x42A]
VV[0x66A]
Skip MCi CTL Write Mask:
This is a per-MC bank mask to skip MCi CTL MSR writes in the MC enable phase in Dragon startup code. If set, SKIPS writing the MCi CTL MSR for the bank.
Default 0x0 - all MC banks (max value defined by IA32_MCG_CAP) are written if the MC enable flow is executed.
e.g., bit 1 = SKIP WRMSR to MSR 0x404 (MCi CTL MSR for bank 1).
VV[0xAB]
VV[0x6B]
VV[0x26B]
VV[0x42B]
VV[0x66B]
Skip MCi STATUS Write Mask:
This is a per-MC bank mask to skip MCi STATUS MSR writes in MC enable phase in Dragon startup code. If set, SKIPS clearing the MCi STATUS MSR for the bank.
Default 0x0 - all MC banks (max value defined by IA32_MCG_CAP) are written if the MC enable flow is executed.
e.g., bit 1 = SKIP WRMSR to MSR 0x405 (MCi STATUS MSR for bank 1).
VV
[0xAC0xA
D]
VV
[0x6C0x6
D]
VV
[0x26C0x26
D]
VV
[0x42C0x42
D]
VV
[0x66C0x66
D]
DRNG Config patch2/3 rax:
Defaulted to Dragon expected value for the generated product.
This vvar can be overridden if: that value is incorrect, or used on a product with a different port value, or set to 0 to bypass.
If 0, will skip Dragon DRNG BIST Config access (won't restart BIST), but leaves Dragon rdrand/rdseed testing enabled.
VV_DEBUG can be used to disable all Dragon DRNG testing.
Note this only changes the value for the primary Dragon threads. In products like MTL/ARL, the SoC die access value is not modified by this, but 0 still skips.
This also does not modify the upper port configuration value of SPR/EMR built seeds.
VV
[0xAE0xAF]
VV
[0x6E0x6F]
VV
[0x26E0x26
F]
VV
[0x42E0x42
F]
VV
[0x66E0x66
F]
DRNG Status patch2/3 rax:
Defaulted to Dragon expected value for the generated product.
This vvar can be overridden if: that value is incorrect, or used on a product with a different port value, or set to 0 to bypass.
If 0, will skip Dragon DRNG BIST Status access (won't check BIST), but leaves Dragon rdrand/rdseed testing enabled.
VV_DEBUG can be used to disable all Dragon DRNG testing.
Note this only changes the value for the primary Dragon threads. In products like MTL/ARL, the SoC die access value is not modified by this, but 0 still skips.
This also does not modify the upper port configuration value of SPR/EMR built seeds.
VV[0xB0]
VV[0x70]
VV[0x270]
VV[0x430]
VV[0x670]
PM Barrier Timeout in microseconds:
Defaulted to Dragon expected value for the generated product and test behavior.
This vvar can be overridden by direction of Dragon team if experiments determine:
It needs lengthened for a particular valid condition combination.
It needs shortened to tighten detection of incorrect delay.
Note too long a value may cause an automation timeout (if not also increased) instead of a "clean" PM barrier timeout errorcode.
VV[0xB1]
VV[0x71]
VV[0x271]
VV[0x431]
VV[0x671]
PM Finalize Ratio Restore Timeout in pause loops:
Defaulted to Dragon expected value for the generated product and test behavior.
This vvar can be overridden by direction of Dragon team if experiments determine:
It needs lengthened for a particular valid condition combination.
It needs shortened to tighten detection of incorrect delay.
Note too long a value may cause an automation timeout (if not also increased) instead of a "clean" PM ratio restore timeout errorcode.
SVN 8178 - 8250
Old versions click here
Dragon VVars Changelog
VVAR
Description
VV[0x00]
Test runtime
Min execution time in CPU cycles (after bus translated to CPU HFM) = (VV[0x00]*VV[0x01])/212
Defaults
System: Microseconds
Ex: 3 sec = 3,000,000 us = 0x2DC6C0
Tester: CPU Cycles
VV[0x01]
32-bit fixed point value to scale VV[0x00] by: 2
 integer, 2
 fractional
20
12
Min execution time in CPU cycles (after bus translated to CPU HFM) = (VV[0x00]*VV[0x01])/212
If the top bit is clear, this vvar refers to CPU HFM freq in scaled MHz.
If the top bit is set on system (default), this vvar refers to bus freq in scaled MHz. This bit is ignored on non-system. Dragon's startup will clear this bit and multiply by the CPU HFM ratio to get to the 
CPU HFM freq in scaled MHz.
Defaults
System: Scale VV[0x00] by expected bus frequency in MHZ
ex: 0x80064000 (100 MHz bus * 2
)
12
System: Scale VV[0x00] by expected CPU HFM frequency in MHZ
ex: 0x00bb8000 (3000 MHz CPU HFM * 2
)
12
Tester: 0x1000 (don't scale VV[0x00])
VV[0x00] scaling factor examples
To be clear, these only scale VV[0x00] (time in microseconds), not the original test runtime. Test runtime is calculated from the VV[0x00] and VV[0x01] inputs.
0x800 - scale VV[0x00] down by 1/2
0x1000 - don't scale VV[0x00]
0x2000 - scale VV[0x00] up by 2x
0xA000 - scale VV[0x00] up by 10x
VV[0x02]
Thread Count VVar
VV[0x02] byte layout:
SE PD RR RR
Note: "package" means actual package except when running 1 die per package seeds on multiple die per package parts. In that case "package" means die.
S = start package (4 bits)
E = expected number of packages (4 bits)
P = (output only) generated packages (4 bits)
D = (output only) log2(generated dies per package), so 0 = 1 die, 1 = 2 die, 2 = 4 die, etc (4 bits)
R = running threads (16 bits)
word 0 This VVar is used to override the number of threads to run the Dragon test on.
If 0 (default): Dragon startup will use defaults:
System default: # of threads in package * # of sockets generated for
All other default (tester/archsim/etc): # of threads generated for
Override usefulness
For debug, to run Dragon on only some of threads in the unit. Requires setting min and max apic to discard the unwanted threads.
byte 2
nibble 0: D = (output only) log2(generated dies per package), so 0 = 1 die, 1 = 2 die, 2 = 4 die, etc (4 bits)
nibble 1: P = (output only) generated packages (4 bits)
byte 3
nibble 0: expected number of packages populated in the system
If 0: Dragon will use the # of packages it was generated for
Only useful for multi-socket systems (Xeon Servers)
If communicated up front, the Dragon team can generate this with your default configuration.
Otherwise, you will need to override this if the system has more packages than the seed was generated for.
WARNING: The other packages will NOT run any Dragon test code (just some startup code).
nibble 1: zero-based starting package to run Dragon on
Default: 0: run starting from package 0
VV[0x03]
Debug Flags - Decoder
bit 0
Not Defined
bit 1
Not Defined
bit 2
Ignore INIT flag. Dont fail if this flag has been set.
bit 3
System Only: All WBINVDs will be skipped during the test.
bit 4
Not Defined
bit 5
SKIP SIPI. Used for single thread mode or for simulation where other mechanism for waking up SIPI is used.
bit 6
Not Defined
bit 7
PROC_SPECIFIC_DFX, set by Dragon during generation, do not modify unless directed to do so.
ANN enables code to remap 2nd BSP to an AP
bit 8
NO_SNOOP: If set skip startup accesses which create cross thread snoops; needed for compatibility for certain tester SBFT modes.
Must be generated with this set because algorithm cross-thread snoops are only prevented at generation time, not runtime.
Undefined or strange behavior on system. Do not modify unless directed to do so.
bit 9
DFX SIPI: Set for MLC and Slice mode on tester.
bit 10
Simulation Flag. Will be set if test is running on Archsim.
bit 11
Tester Mode: Startup code flow will be SBFT compliant and run tester specific code.
bit 12
JMP-SELF in Tester Mode: When set, all threads will end with a JMP $ instead of a halt.
bit 13
Not Defined
bit 14
Not Defined
bit 15
Counter check. Verifies that TSC is running. Don't use this with Archsim!
bit 16
If set, power management functionality is turned off for seeds that have c-states or p-states or turbo or user-level wait enabled. Also useful for e-swift, esp since APIC is used.
bit 17
If set, VMX functionality is turned off for seeds that have vmx enabled. Useful for debug.
bit 18
If set, TLA trigger ( OUT 0xf8 ) will be skipped
bit 19
If set, test will exit immedately on any failure.
bit 20
If set, test will skip all RDRAND sparks and DRNG PBIST code
bit 21
If set, test will skip all HLE and RTM sparks
bit 22
If set cycles expended for certain features are reduced. Intended for initial pre-silicon enabling.
bit 23
SVN r4686-r5120: If set, test will skip all PCOMMIT code. Pcommit instruction was dropped prior to any product release. When running any SKX Dragon seeds between these 2 revs, set this bit. 
Newer Dragon seeds do not include pcommit and ignore this bit.
bit 24
If set, APs in test will skip jump to end_test_case_start after AP_halt for SBFT Loader to intercept and handle.
bit 25
If set, CMCI will be enabled. Instead of only checking for soft MCEs at the end of the test, when the Soft MCE Threshold vvar is exceeded, an interrupt will be triggered. Dragon will report the 
appropriate MCE failure code.
bit 26
If set, PM enabled seeds will skip the end of test PState restore verification.
bit 27
If set, disables most of the PagingRights usages and restrictions.
bit 28
If set, utilize runtime lockstep WAs (such as half CPM count on SRF).
VV[0x04]
VV_MIN_APIC_ID - Any thread < Min APIC ID will be immediately halted.
Used for running tests generated for x threads on a system with more than x threads.
VV[0x2] word 1 must be configured if this is non-zero
VV[0x05]
VV_MAX_APIC_ID - Any threads > Max APIC ID will be immediately halted. Default is 0x7FFFFFFF (no thread discards, perform TPx checks).
Used for running tests generated for x threads on a system with more than x threads.
VV[0x2] word 1 must be configured if bits[30:0] are not at default value.
Bit[31] Dragon is "stealing" this bit from the APIC ID space.
0: (default) perform thread per "x" (TPx) checks, such as TPC/TPM, as Dragon generally requires generated to match runtime.
1: skip TPx checks (only do at the direction of the Dragon team as mismatches only "work" correctly in narrow cases).
VV[0x06]
VV_THREAD_ROTATE - Contains rotate values to rotate logical ID within the system topology (package, die per package, modules per die, cores per module, threads per core).
Each logical thread id is broken down into its hierarchical components, and rotate is performed on each component using values specified in the VVAR.
Rotate is performed in order of thread, core, module, die, package.
Note: Each value is an unsigned positive forward rotate. Signed negative backwards rotates are not supported.
Note: Rotate performed and then swap performed on lowest topo level, then on each higher level.
VV[0x06] byte layout:
PD MM MM CT
P = Package rotate value (4 bits)
D = Die (within package) rotate package (4 bits)
M = Module (within die) rotate value (16 bits - 2 bytes)
C = Core (within module) rotate value (4 bits)
T = Thread (within core) rotate value (4 bits)
Example with VV_THREAD_ROTATE = 0x0000_0201 on a system with 2 threads per core, 1 core per module, 4 modules per die. (8 threads total)
0 (P0D0M0C0T0) ->  5 (P0D0M2C0T1)
1 (P0D0M0C0T1) ->  4 (P0D0M2C0T0)
2 (P0D0M1C0T0) ->  7 (P0D0M3C0T1)
3 (P0D0M1C0T1) ->  6 (P0D0M3C0T0)
4 (P0D0M2C0T0) ->  1 (P0D0M0C0T1)
5 (P0D0M2C0T1) ->  0 (P0D0M0C0T0)
6 (P0D0M3C0T0) ->  3 (P0D0M1C0T1)
7 (P0D0M3C0T1) ->  2 (P0D0M1C0T0)
VV[0x07]
VV_THREAD_SWAP_XOR - Contains swap values to swap logical ID within the system topology (package, die per package, modules per die, cores per module, threads per core).
Each logical thread id is broken down into its hierarchical components, and swap is performed on each component of the hierarchy using values specified in the VVAR.
Swap is performed in order of thread, core, module, die, package.
Note: Rotate performed and then swap performed on lowest topo level, then on each higher level.
VV[0x07] byte layout:
PD MM MM CT
P = Package rotate value (4 bits)
D = Die (within package) rotate package (4 bits)
M = Module (within die) rotate value (16 bits - 2 bytes)
C = Core (within module) rotate value (4 bits)
T = Thread (within core) rotate value (4 bits)
Example with VV_THREAD_SWAP_XOR = 0x0000_0101 on a system with 2 threads per core, 1 core per module, 4 modules per die. (8 threads total)
0 (P0D0M0C0T0) ->  3 (P0D0M1C0T1)
1 (P0D0M0C0T1) ->  2 (P0D0M1C0T0)
2 (P0D0M1C0T0) ->  1 (P0D0M0C0T1)
3 (P0D0M1C0T1) ->  0 (P0D0M0C0T0)
4 (P0D0M2C0T0) ->  7 (P0D0M3C0T1)
5 (P0D0M2C0T1) ->  6 (P0D0M3C0T0)
6 (P0D0M3C0T0) ->  5 (P0D0M2C0T1)
7 (P0D0M3C0T1) ->  4 (P0D0M2C0T0)
VV[0x08]
SOFT MCE CHECK MASK.
This is a check bit mask for each MC register.
This is as subset of VV_MC_ENABLE; Actual registers checked is VV_MC_ENABLE AND VV_MC_CHECK
Default is 0xFFFFFFFF, all MCEs checked.
e.g. bit 0 == check MC0, bit 1 == check MC1
See 
 for 'unofficial' bank decode.
Dragon IAMCE
VV[0x09]
SOFT MCE ENABLE MASK.
This is an enable bit mask for each MC register.
Default is 0xFFFFFFFF, all MCEs enabled.
e.g. bit 0 == set MC0, bit 1 == set MC1, etc
See 
 for 'unofficial' bank decode.
Dragon IAMCE
VV[0x0A]
Debug Output Flags - Decoder
bit 0
Not Defined
bit 1
INIT/Test started flag. Used to detect shutdown where test may run 2nd time due to reset.
bit 2
Flag for booted x2APIC; set by BSP only, checked by all
bit 3
Flag for BSP x2APIC is active; set/checked by BSP only (prior to r4701, checked by all)
bit 4
Flag for booted or forced to x2APIC; set by BSP only, checked by all. We exit the seed in x2Apic if forced to x2Apic.
bit 5
Flag indicating automatic socket selection (automatic setting of min and max APIC ID for DUT selection)
bit 6
Flag indicating automatic thread reduction (automatic setting of running threads less than generated threads)
bit 7
Flag indicating this was generated as a decap seed.
bit 8
Flag indicating this was generated as a VMX seed. VV_Output VV[3].bit17 disables VMX at runtime.
bit 9
Flag indicating this was generated as a PM C-State seed. VV_Output VV[3].bit16 disables PM at runtime.
bit 10
Flag indicating this was generated as a PM P-State seed. VV_Output VV[3].bit16 disables PM at runtime.
bit 11
Flag indicating this was generated as a PM Turbo seed. VV_Output VV[3].bit16 disables PM at runtime.
bit 12
Flag indicating this was generated as a User Level Wait seed. VV_Output VV[3].bit16 disables PM/ULW at runtime.
bit 13
Flag indicating this was generated as a PM UFS seed (ignore if P-State/Turbo bits 10 and 11 are both clear). VV_Output VV[3].bit16 disables PM at runtime.
bit 14
Flag indicating this was generated as a PM FACT seed. VV_Output VV[3].bit16 disables PM at runtime.
bit 15
Flag indicating this was generated as a LittleFoot (LF) seed. This generates as a small bundle of threads, and then replicates them at runtime to scale to higher thread counts.
VV[0x0B]
Dragon SVN Revision.
Default
ADL/RPL
/BTL
MTL
/ARLU
PMR
SPR
/EMRMCC
EMRXCC
GNR
SRF/CWF
DMR
VV
[0x0C0x4B]
VV
[0x0C0x2
B]
VV
[0x0C0x12B]
VV
[0x0C0x20B]
VV
[0x0C0x32B]
Per Thread Status
Dragon Error Decoders
See 
 for full details.
Dragon Thread Status
The top nibble of the 32-bit code indicates which overall "group" it belongs to.
But the actual failure 
 isn't strictly aligned with that (esp for "#GP").
bucket/priority
0x1, 0x2 - issue during startup/teardown
0x4, 0x5 - missing feature
600D600D - BM: Thread passed
0x7 - BM thread counting issues
0xA, 0xB - BM logged MCE
0xC, 0xD - special error code or x86 interrupt
0xF - Test algo reported issue
VV
[0x4C0x4D]
VV
[0x2C0x2
D]
VV
[0x12C0x12
D]
VV
[0x20C0x20
D]
VV
[0x32C0x32
D]
Number of CPU cycles the test ran during a passing run.
Note: ACNT not correct if 
 is used on tester in MLC or Slice mode (VV[0x03] bits 9 & 11 set).
DR1 cycle scaling
Dwor
d 0
ACNT Low. Low DWORD of the number of CPU cycles.
Dwor
d 1
ACNT High. High DWORD of the number of CPU cycles.
VV[0x4E]
VV[0x2E]
VV[0x12E]
VV[0x20E]
VV[0x32E]
Loop Count Minimum of all the threads. May not be min of all threads on early exit (thread 0 fail or VV_DEBUG_IMM_EXIT_ON_FAIL).
VV[0x4F]
VV[0x2F]
VV[0x12F]
VV[0x20F]
VV[0x32F]
Loop Count Maximum of all the threads. May not be max of all threads on early exit (thread 0 fail or VV_DEBUG_IMM_EXIT_ON_FAIL).
VV
[0x500x58]
VV
[0x300x38]
VV
[0x1300x13
8]
VV
[0x2100x21
8]
VV
[0x3300x33
8]
PMON Input (feeds to all threads) and Output (BSP Only).
VV[0x59]
VV[0x39]
VV[0x139]
VV[0x219]
VV[0x339]
Cumulative status for thread errors - multiple threads could write into this to report a thread error.
VV[0x5A]
VV[0x3A]
VV[0x13A]
VV[0x21A]
VV[0x33A]
SOFT MCE THRESHOLD BITS (Banks 0 to 7)
Used for Thresholding Soft MCE's. Failure when count is greater than or equal to threshold.
Each nibble contains the threshold for the corresponding bank.
The nibble value is translated to a power of two minus one threshold.
Default is 0x1, fail on one or more soft MCE's
e.g. 0x4 = 2  - 1 = 31 threshold
4
NOTE: Not all Banks are guaranteed to be enabled on all products, Check 
 for list of enabled banks on products
Dragon IAMCE
VV[0x5B]
VV[0x3B]
VV[0x13B]
VV[0x21B]
VV[0x33B]
SOFT MCE THRESHOLD BITS (Banks 8 to 15)
Used for Thresholding Soft MCE's. Failure when count is greater than or equal to threshold.
Each nibble contains the threshold for the corresponding bank.
The nibble value is translated to a power of two minus one threshold.
Default is 0x1, fail on one or more soft MCE's
e.g. 0x4 = 2  - 1 = 31 threshold
4
NOTE: Not all Banks are guaranteed to be enabled on all products, Check 
 for list of enabled banks on products
Dragon IAMCE
VV[0x5C]
VV[0x3C]
VV[0x13C]
VV[0x21C]
VV[0x33C]
SOFT MCE THRESHOLD BITS (Banks 16 to 23)
Used for Thresholding Soft MCE's. Failure when count is greater than or equal to threshold.
Each nibble contains the threshold for the corresponding bank.
The nibble value is translated to a power of two minus one threshold.
Default is 0x1, fail on one or more soft MCE's
e.g. 0x4 = 2  - 1 = 31 threshold
4
NOTE: Not all Banks are guaranteed to be enabled on all products, Check 
 for list of enabled banks on products
Dragon IAMCE
VV[0x5D]
VV[0x3D]
VV[0x13D]
VV[0x21D]
VV[0x33D]
SOFT MCE THRESHOLD BITS (Banks 24 to 31)
Used for Thresholding Soft MCE's. Failure when count is greater than or equal to threshold.
Each nibble contains the threshold for the corresponding bank.
The nibble value is translated to a power of two minus one threshold.
Default is 0x1, fail on one or more soft MCE's
e.g. 0x4 = 2  - 1 = 31 threshold
4
NOTE: Not all Banks are guaranteed to be enabled on all products, Check 
 for list of enabled banks on products
Dragon IAMCE
VV[0x5E]
VV[0x3E]
VV[0x13E]
VV[0x21E]
VV[0x33E]
IA32_MCG_CAP override
If value != 0xFFFFFFFF, then this will be used instead of doing a RDMSR(IA_MCG_CAP).
This is most likely used for Slice mode override where IA_MCG_CAP can not be read.
VV[0x5F]
VV[0x3F]
VV[0x13F]
VV[0x21F]
VV[0x33F]
Not LLC Way Mask
VV[0x60]
VV[0x40]
VV[0x140]
VV[0x220]
VV[0x340]
Wait/Exit VVAR
bit 0
VV_WAIT_BSP: When set BSP will WAIT early in bsp_init, well before sending SIPI to wake other threads. Clearing bit proceeds with startup.
bit 1
VV_WAIT_BSP_END_TEST: When set BSP will WAIT before jumping to end_test_case_start. Clearing bit proceeds with end_test_case_start.
bit 2
VV_WAIT_BSP_DR0: When set BSP will WAIT early in bsp_init, well before sending SIPI to wake other threads. Setting IA_CR_DR0 = 0xd05e3a17 proceeds with startup.
bit 3
VV_WAIT_AP_DR0:
When set AP will WAIT early in lm_init, somewhat before pick_logical_id (thread sort). Setting IA_CR_DR0 = 0xd05e3a17 proceeds with startup (per thread).
WARNING: This usage is mostly broken because BSP proceeds to pick_logical_id and tends to timeout because the APs are waiting on this bit/DR0.
bit 4
VV_WAIT_BSP_END_TEST_FAIL: When set (and test fails), BSP will WAIT before jumping to end_test_case_start. Clearing bit proceeds with end_test_case_start.
bit 8
VV_WAIT_ALL_THREADS:
When set all threads will WAIT just before starting the test main payload. Clearing bit proceeds with test (all threads).
WARNING: This is AFTER negtsc_done, which means waiting here is "consuming" test loop runtime.
VV[0x61]
VV[0x41]
VV[0x141]
VV[0x221]
VV[0x341]
Not MLC Way Mask
VV[0x62]
VV[0x42]
VV[0x142]
VV[0x222]
VV[0x342]
(output) Address of this seed's Dragon ThreadBlockHeader (TBH, aka DebugSpace) - provided for debug tool use
VV[0x63]
VV[0x43]
VV[0x143]
VV[0x223]
VV[0x343]
(output) Core type table consisting of a composite of bit(s) from CPUID Core Type and LLC cache fields.
This table contains the order in which thread block types are stored and processed in the seed.
Reverse ordered (relative to logical ID sequence):
byte 3 [31:24] is index 0 and contains the type ID value of the 1st core type
byte 2 [23:16] is index 1 and contains the type ID value of the (potential) 2nd core type
byte 1 [15:08] is index 2 and contains the type ID value of the (potential) 3rd core type
byte 0 [07:00] is index 3 and contains the type ID value of the (potential) 4th core type
4 type ID values are supported for now:
00 - Atom, subtype 0 (no LLC)
01 - Atom, subtype 1 (has LLC)
10 - Big Core, subtype 0 (no LLC)
11 - Big Core, subtype 1 (has LLC)
VV[0x64]
VV[0x44]
VV[0x144]
VV[0x224]
VV[0x344]
(output) Contains the threads per core (TPC) and cores per module (CPM) for each of the supported composite core type IDs (indexed by ID value).
Byte layout:
4 currently supported composite core type IDs (indexed by ID value) and 1 nibble per field (CPM or TPC).
CPM3 TPC3 CPM2 TPC2 CPM1 TPC1 CPM0 TPC0 where
CPM3: cores per module for type ID value 3 (4 bits)
TPC3: threads per core for type ID value 3 (4 bits)
...
CPM0: cores per module for type ID value 0 (4 bits)
TPC0: threads per core for type ID value 0 (4 bits)
VV
[0x650x66]
VV
[0x450x46]
VV
[0x1450x14
6]
VV
[0x2250x22
6]
VV
[0x3450x34
6]
(output) Contains the generated threads (1 word each), indexed by composite core type ID values 0-3.
VV
[0x670x68]
VV
[0x470x48]
VV
[0x1470x14
8]
VV
[0x2270x22
8]
VV
[0x3470x34
8]
(output) Hybrid seeds only: contains the runtime threads (1 word each), indexed by composite core type ID values 0-3. Non-hybrid is always 0.
VV
[0x690xA8]
VV
[0x490x68]
VV
[0x1490x26
8]
VV
[0x2290x42
8]
VV
[0x3490x66
8]
Per Thread Gen Thread Mapping - Output only
Per Thread VVAR (logical thread order) which indicates (Bundle ID, generated thread ID, and APIC ID).
Decoding the output varies depending upon whether LittleFoot scaling is enabled in the seed: VV[0xA].bit[15].
LittleFoot enabled
BB GG AA AA
B = Bundle ID (byte 3)
G = Generated thread ID (byte 2)
A = APIC ID (word 0 - bytes 0-1)
non-LittleFoot
GG GG AA AA
G = Generated thread ID (word 1 - bytes 2-3)
A = APIC ID (word 0 - bytes 0-1)
VV[0xA9]
VV[0x69]
VV[0x269]
VV[0x429]
VV[0x669]
(output) Control bundle ID - For varying which bundle does things like PM control thread, DRNG PBIST, etc. Defaulted to 0 for non-LittleFoot seeds.
VV[0xAA]
VV[0x6A]
VV[0x26A]
VV[0x42A]
VV[0x66A]
Skip MCi CTL Write Mask:
This is a per-MC bank mask to skip MCi CTL MSR writes in the MC enable phase in Dragon startup code. If set, SKIPS writing the MCi CTL MSR for the bank.
Default 0x0 - all MC banks (max value defined by IA32_MCG_CAP) are written if the MC enable flow is executed.
e.g., bit 1 = SKIP WRMSR to MSR 0x404 (MCi CTL MSR for bank 1).
VV[0xAB]
VV[0x6B]
VV[0x26B]
VV[0x42B]
VV[0x66B]
Skip MCi STATUS Write Mask:
This is a per-MC bank mask to skip MCi STATUS MSR writes in MC enable phase in Dragon startup code. If set, SKIPS clearing the MCi STATUS MSR for the bank.
Default 0x0 - all MC banks (max value defined by IA32_MCG_CAP) are written if the MC enable flow is executed.
e.g., bit 1 = SKIP WRMSR to MSR 0x405 (MCi STATUS MSR for bank 1).
VV
[0xAC0xA
D]
VV
[0x6C0x6
D]
VV
[0x26C0x26
D]
VV
[0x42C0x42
D]
VV
[0x66C0x66
D]
DRNG Config patch2/3 rax:
Defaulted to Dragon expected value for the generated product.
This vvar can be overridden if: that value is incorrect, or used on a product with a different port value, or set to 0 to bypass.
If 0, will skip Dragon DRNG BIST Config access (won't restart BIST), but leaves Dragon rdrand/rdseed testing enabled.
VV_DEBUG can be used to disable all Dragon DRNG testing.
Note this only changes the value for the primary Dragon threads. In products like MTL/ARL, the SoC die access value is not modified by this, but 0 still skips.
This also does not modify the upper port configuration value of SPR/EMR built seeds.
VV
[0xAE0xAF]
VV
[0x6E0x6F]
VV
[0x26E0x26
F]
VV
[0x42E0x42
F]
VV
[0x66E0x66
F]
DRNG Status patch2/3 rax:
Defaulted to Dragon expected value for the generated product.
This vvar can be overridden if: that value is incorrect, or used on a product with a different port value, or set to 0 to bypass.
If 0, will skip Dragon DRNG BIST Status access (won't check BIST), but leaves Dragon rdrand/rdseed testing enabled.
VV_DEBUG can be used to disable all Dragon DRNG testing.
Note this only changes the value for the primary Dragon threads. In products like MTL/ARL, the SoC die access value is not modified by this, but 0 still skips.
This also does not modify the upper port configuration value of SPR/EMR built seeds.
VV[0xB0]
VV[0x70]
VV[0x270]
VV[0x430]
VV[0x670]
PM Barrier Timeout in microseconds:
Defaulted to Dragon expected value for the generated product and test behavior.
This vvar can be overridden by direction of Dragon team if experiments determine:
It needs lengthened for a particular valid condition combination.
It needs shortened to tighten detection of incorrect delay.
Note too long a value may cause an automation timeout (if not also increased) instead of a "clean" PM barrier timeout errorcode.
VV[0xB1]
VV[0x71]
VV[0x271]
VV[0x431]
VV[0x671]
PM Finalize Ratio Restore Timeout in pause loops:
Defaulted to Dragon expected value for the generated product and test behavior.
This vvar can be overridden by direction of Dragon team if experiments determine:
It needs lengthened for a particular valid condition combination.
It needs shortened to tighten detection of incorrect delay.
Note too long a value may cause an automation timeout (if not also increased) instead of a "clean" PM ratio restore timeout errorcode.
Incoming links
 
Page: APE debug tips
 
Page: APE Releases
 
Page: Dragon
 
Page: Dragon - IPTS
 
Page: Dragon 2013Release0x21 MIGRATED
 
Page: Dragon 2014Release0x87 MIGRATED
 
Page: Dragon 2025Release0x5D
 
Page: Dragon 2025Release0x5E
 
Page: Dragon BasicDebug
 
Page: Dragon Confluence Wiki Markup
 
Page: Dragon DebugInfo
 
Page: Dragon DirectToTesterBKMs
 
Page: Dragon FAQ
 
Page: Dragon PseudoSBFT
 
Page: Dragon Reference
 
Page: Dragon Release0x33 MIGRATED
 
Page: Dragon Release0x53 MIGRATED
 
Page: Dragon Release0x55 MIGRATED
 
Page: Dragon Release0x68 MIGRATED
 
Page: Dragon Release0x7A MIGRATED
 
Page: Dragon Release0xDC MIGRATED
 
Page: Dragon RunTime
 
Page: Dragon SBFTGENSignatureException
 
Page: Dragon SeedReleaseFileStructure
 
Page: Dragon Silvermont
 
Page: Dragon TesterDebug
 
Page: Dragon TesterSeeds
 
Page: Dragon TestRequirements
 
Page: Dragon Thread Mapping
 
Page: Dragon Thread Status
 
Page: Dragon VerticalDebugGuide
 
Page: Dragon VVARBrainstorm
 
Page: Dragon VVARs 2016 SVN 4958 to 5266
 
Page: Dragon VVARs pre 2016 SVN 1 to 4958
 
Page: Dragon VVARs Sandbox
 
Page: Dragon VVARXMLFormat
 
Page: DragonSecure
 
Page: Guide to running Dragon content on pre-silicon models
 
Page: Horizon Development Training WW44'13
 
Page: Horizon Development Training WW44'13+WW45'13+WW47'13
 
Page: Links
 
Page: Loader Interactions Dragon
 
Page: Loader Interactions SV
 
Page: Old MPV Content Secure
 
Page: Ouroboros Documentation
 
Page: Ouroboros Pre-Alpha Brainstorming
 
Page: Space VVARs
 
Page: STC Content Types
 
Page: Tangier
 
Page: Tangier MIGRATED
 
Page: Tester_Debug MIGRATED
Old Versions
SVN ranges are an inclusive start and an exclusive end. If your SVN is on the edge, be sure to choose the section that's on top.
1 Overview
2 SVN 8251 - current
3 SVN 8250 - 8251
4 SVN 8178 - 8250
5 Incoming links
6 Old Versions
Dragon VVars Changelog
Dragon VVARs 2025 SVN 7810 to 8178
Dragon VVARs 2024 SVN 7519 to 7810
Dragon VVARs 2023 SVN 7218 to 7621
Dragon VVARs 2022 SVN 7030 to 7218
Dragon VVARs 2021 SVN 6752 to 7030
Dragon VVARs 2020 SVN 6390 to 6752
Dragon VVARs 2019 SVN 6207 to 6390
Dragon VVARs 2018 SVN 5872 to 6207
Dragon VVARs 2017 SVN 5266 to 5872
Dragon VVARs 2016 SVN 4958 to 5266
Dragon VVARs pre 2016 SVN 1 to 4958
