---
name: hsd-helper
description: "Interact with Intel HSD-ES (HSDES) bug tracking system via REST API — query articles, create/update bugs, execute saved queries, manage attachments, lookup field values, and trace relationships. Use this skill whenever the user mentions HSDES, HSD, HSD-ES, bug tracking, sighting, filing a bug, query execution, article lookup, HSDES query, HSDES article, bug update, attachment upload, trace links, component lookup, release lookup, viewport execution, EQL query, or any interaction with https://hsdes.intel.com — even if they just say 'look up that bug' or 'file a sighting'."
---

# HSD-ES Interaction Skill

**Programmatic access to Intel's HSD-ES (High-Speed Defect/Enhancement System) via REST API**

## When I Activate

- User wants to query, create, update, or read HSDES articles (bugs, issues, test cases, etc.)
- User needs to execute a saved HSDES query or run an EQL/XML query
- User wants to look up field values (releases, components, families)
- User needs to manage attachments (upload, download, info)
- User wants to trace relationships between articles (parent-child, links)
- User asks about article history, changesets, or status transitions
- User needs to clone or bulk-create articles
- User wants to search for similar articles

## Base URL & Authentication

```
Base URL: https://hsdes-api.intel.com/rest
```

### Authentication Options

| Method | Header | Description |
|--------|--------|-------------|
| API Key | `api_key` | Registered app key from client registration |
| Token (Basic Auth) | `Authorization: Basic <base64(idsid:token)>` | Personal token from `/token/basicauth` |
| Impersonation | `impersonation_key` | For acting on behalf of another user |

### Common Headers

| Header | Required | Description |
|--------|----------|-------------|
| `api_key` | Recommended | Your registered application key |
| `APP` | Optional | Your application name for tracking |

### Getting a Token

```python
import requests

# Create a new token (one-time, via browser basic auth):
# GET https://hsdes-api.intel.com/rest/token/basicauth
# Then use: Authorization: Basic base64(idsid:token)

# Or retrieve existing token:
resp = requests.get("https://hsdes-api.intel.com/rest/token",
                    headers={"Authorization": "Basic <base64_creds>"})
```

## Core API Operations

### 1. Article (Bug/Issue) Operations

#### Get Article by ID

```python
import requests

BASE = "https://hsdes-api.intel.com/rest"
HEADERS = {"api_key": "<your_key>"}

# Get article with specific fields
resp = requests.get(f"{BASE}/article/{article_id}",
    headers=HEADERS,
    params={
        "fields": "id,title,owner,status,description,component,release_affected",
        "tenant": "server",        # optional
        "subject": "bugeco"        # optional
    })
article = resp.json()
```

#### Create New Article

```python
body = {
    "tenant": "server",
    "subject": "bugeco",
    "fieldValues": [
        {"title": "Memory RAS failure on OakStream"},
        {"owner": "sys_hsdes"},
        {"component": "memory_ras"},
        {"description": "Detailed description here"},
        {"send_mail": "false"}
    ]
}
resp = requests.post(f"{BASE}/article",
    headers=HEADERS,
    json=body,
    params={"fetch": True})
```

#### Update Article

```python
body = {
    "tenant": "server",
    "subject": "bugeco",
    "fieldValues": [
        {"status": "resolved"},
        {"description": "Updated description"}
    ]
}
resp = requests.put(f"{BASE}/article/{article_id}",
    headers=HEADERS,
    json=body,
    params={"rev": current_rev, "fetch": True})
```

#### Get Article History

```python
resp = requests.get(f"{BASE}/article/{article_id}/history",
    headers=HEADERS,
    params={"fields": "id,title,status,owner", "showChangedFields": "Y"})
```

#### Get Article Children (Comments, Attachments)

```python
resp = requests.get(f"{BASE}/article/{article_id}/children",
    headers=HEADERS,
    params={
        "child_subject": "comment",  # comment, ar, approval, attachment
        "fields": "id,rev,owner,description"
    })
```

#### Get Related Links

```python
resp = requests.get(f"{BASE}/article/{article_id}/links",
    headers=HEADERS,
    params={
        "fields": "id,subject,tenant,title,owner,status,relationship",
        "showHidden": "N"
    })
```

#### Clone Article

```python
clone_body = {
    "destTenant": "server",
    "destSubject": "bugeco",
    "sendmail": "false",
    "copy_attachment": "false",
    "copy_comment": "false",
    "fieldValues": [
        {"description": "Cloned from original"}
    ]
}
resp = requests.post(f"{BASE}/article/{article_id}/clone",
    headers=HEADERS, json=clone_body)
```

#### Bulk Create Articles

```python
articles = [
    [{"title": "Bug 1"}, {"owner": "user1"}],
    [{"title": "Bug 2"}, {"owner": "user2"}]
]
resp = requests.post(f"{BASE}/article/bulk/{tenant}/{subject}",
    headers=HEADERS,
    json=articles,
    params={"send_mail": False})
```

#### Bulk Update Articles

```python
updates = [
    {"rowNum": 0, "id": 16030004215, "rev": 0,
     "fieldValues": [{"status": "resolved"}]},
    {"rowNum": 1, "id": 16030004222, "rev": 1,
     "fieldValues": [{"status": "closed"}]}
]
resp = requests.put(f"{BASE}/article/bulk/sync/{tenant}/{subject}",
    headers=HEADERS,
    json=updates,
    params={"fetch": True, "send_mail": False})
```

#### Add Link Between Articles

```python
resp = requests.post(f"{BASE}/article/{source_id}/links/{target_id}",
    headers=HEADERS)

# Or bulk add links:
link_body = {"childIDList": "16030004222,16030004223", "linkType": "parent-child"}
resp = requests.post(f"{BASE}/article/{source_id}/links",
    headers=HEADERS, json=link_body)
```

#### Status Transition History

```python
resp = requests.get(f"{BASE}/article/{article_id}/statustransition",
    headers=HEADERS)
```

### 2. Query Operations

#### Execute Saved Query by ID

```python
resp = requests.get(f"{BASE}/query/execution/{query_id}",
    headers=HEADERS,
    params={
        "start_at": 1,
        "max_results": 50,
        "fields": "id,title,owner,status,component"
    })
results = resp.json()
```

#### Execute Query by ID with Search Filter

```python
body = {
    "search": "status in ('open','in_progress')"
}
resp = requests.post(f"{BASE}/query/execution/{query_id}",
    headers=HEADERS,
    json=body,
    params={"start_at": 1, "max_results": 100})
```

#### Execute Query by EQL

```python
body = {
    "eql": "select id, title, owner, status from server.bugeco where status = 'open' and component = 'memory_ras'"
}
resp = requests.post(f"{BASE}/query/execution/eql",
    headers=HEADERS,
    json=body,
    params={"start_at": 1, "max_results": 100})
```

#### Execute General Query

```python
body = {
    "queryType": "eql",      # queryId, cypherId, or eql
    "query": "select id, title from server.bugeco where owner = 'myidsid'",
    "filter": "",
    "param": {}
}
resp = requests.post(f"{BASE}/query/execution/general",
    headers=HEADERS,
    json=body,
    params={"start_at": 1, "max_results": 50})
```

#### Execute Query by XML

```python
body = {
    "queryXml": '<Query xmlns="https://hsdes.intel.com/schemas/2012/Query"><Filter/><SortOrder><SortField Order="ASC" Shortname="title"/></SortOrder></Query>',
    "search": "status = 'open'"
}
resp = requests.post(f"{BASE}/query/execution",
    headers=HEADERS,
    json=body,
    params={"start_at": 1, "max_results": 50, "fields": "id,title,status"})
```

#### Get Query Metadata

```python
resp = requests.get(f"{BASE}/query/MetaData",
    headers=HEADERS,
    params={"owner": "myidsid", "category": "private"})
```

### 3. Attachment (Binary) Operations

#### Upload Attachment

```python
with open("report.pdf", "rb") as f:
    resp = requests.post(f"{BASE}/binary/upload/{parent_article_id}",
        headers=HEADERS,
        files={"file": f},
        data={
            "title": "Test Report",
            "file_name": "report.pdf",
            "send_mail": "false"
        })
```

#### Download Attachment

```python
resp = requests.get(f"{BASE}/binary/{attachment_id}",
    headers=HEADERS)
with open("downloaded_file", "wb") as f:
    f.write(resp.content)
```

#### Get Attachment Info

```python
resp = requests.get(f"{BASE}/binary/{attachment_id}/info",
    headers=HEADERS)
# Returns: title, filename, fileType, fileSize
```

### 4. Lookup Operations

#### Get Releases for Tenant/Subject

```python
resp = requests.get(f"{BASE}/lookup/release/{tenant}/{subject}",
    headers=HEADERS,
    params={"family": "10nm Server Chassis CTE"})  # optional filter
```

#### Get Components

```python
resp = requests.get(f"{BASE}/lookup/component/{tenant}/tree_local",
    headers=HEADERS,
    params={"subject": "bugeco", "release_affected": "GNR-AP A0"})
```

#### Get Families

```python
resp = requests.get(f"{BASE}/lookup/family/{tenant}/{subject}",
    headers=HEADERS)
```

#### Get Lookup Field Values

```python
body = {"search": "memory", "dynamicFilterParameters": ""}
resp = requests.post(f"{BASE}/lookup/component.name",
    headers=HEADERS,
    json=body,
    params={"subject": "bugeco", "tenantlist": "server"})
```

### 5. Trace (Relationship Graph) Operations

#### Trace Linked Records

```python
# All test_case_definitions linked to features
resp = requests.get(f"{BASE}/trace/linked/test_case_definition/feature",
    headers=HEADERS,
    params={"fields": "id,title,status", "count": False})
```

#### Get Tree of Children

```python
resp = requests.get(f"{BASE}/trace/tree/children/{article_id}/{subject}",
    headers=HEADERS,
    params={
        "labelFilter": "+test_case|-test_case_definition",
        "fields": "id,title,status",
        "maxLevel": 3
    })
```

#### Get Tree of Parents

```python
resp = requests.get(f"{BASE}/trace/tree/parents/{article_id}/{subject}",
    headers=HEADERS,
    params={
        "labelFilter": "+bugeco",
        "fields": "id,title,status"
    })
```

### 6. User & Directory Operations

#### Who Am I

```python
resp = requests.get(f"{BASE}/user",
    headers=HEADERS,
    params={"expand": "personal"})
```

#### Get User by IDSID

```python
resp = requests.get(f"{BASE}/user/{idsid}",
    headers=HEADERS,
    params={"expand": "personal"})
```

#### Active Directory Search

```python
resp = requests.get(f"{BASE}/directory",
    headers=HEADERS,
    params={"search": "john.doe", "exact": True})
```

### 7. Viewport Operations

#### Execute Viewport

```python
resp = requests.get(f"{BASE}/viewport/{viewport_name}",
    headers=HEADERS,
    params={
        "search_text": "status in ('open')",
        "start_at": 1,
        "max_results": 50,
        "fields": "id,title,owner,status"
    })
```

### 8. Similarity Search

#### Find Similar Articles

```python
resp = requests.get(f"{BASE}/similarity/similar/{article_id}",
    headers=HEADERS,
    params={
        "searchsubjects": "bugeco",
        "searchtenants": "server"
    })
```

#### Text-Based Similarity Search

```python
body = {"configValue": "memory RAS uncorrectable error"}
resp = requests.post(f"{BASE}/similarity/query/{tenant}/{subject}/elastic",
    headers=HEADERS, json=body)
```

## Quick Reference: Endpoint Summary

| Operation | Method | Endpoint |
|-----------|--------|----------|
| Get article | GET | `/article/{id}` |
| Create article | POST | `/article` |
| Update article | PUT | `/article/{id}` |
| Article history | GET | `/article/{id}/history` |
| Article children | GET | `/article/{id}/children` |
| Article links | GET | `/article/{id}/links` |
| Add link | POST | `/article/{id}/links/{targetID}` |
| Clone article | POST | `/article/{id}/clone` |
| Bulk create | POST | `/article/bulk/{tenant}/{subject}` |
| Bulk update | PUT | `/article/bulk/sync/{tenant}/{subject}` |
| Status transitions | GET | `/article/{id}/statustransition` |
| Execute query (ID) | GET | `/query/execution/{id}` |
| Execute query (EQL) | POST | `/query/execution/eql` |
| Execute query (XML) | POST | `/query/execution` |
| General query | POST | `/query/execution/general` |
| Query metadata | GET | `/query/MetaData` |
| Upload attachment | POST | `/binary/upload/{parent_id}` |
| Download attachment | GET | `/binary/{id}` |
| Attachment info | GET | `/binary/{id}/info` |
| Get releases | GET | `/lookup/release/{tenant}/{subject}` |
| Get components | GET | `/lookup/component/{tenant}/{status}` |
| Get families | GET | `/lookup/family/{tenant}/{subject}` |
| Trace linked | GET | `/trace/linked/{path}` |
| Tree children | GET | `/trace/tree/children/{id}/{subject}` |
| Tree parents | GET | `/trace/tree/parents/{id}/{subject}` |
| Who am I | GET | `/user` |
| User info | GET | `/user/{idsid}` |
| Execute viewport | GET | `/viewport/{viewportName}` |
| Find similar | GET | `/similarity/similar/{id}` |

## Common Patterns

### Pagination

All list endpoints support pagination:
```python
params = {"start_at": 1, "max_results": 50}
```

### Field Selection

Most endpoints accept a `fields` parameter (comma-separated):
```python
params = {"fields": "id,title,owner,status,component,release_affected"}
```

### Search/Filter Syntax

```python
# Simple field match
"status in ('open','in_progress')"

# Combined conditions
"status = 'open' and component = 'memory_ras'"

# XML-based filter (for query execution)
'<Query xmlns="https://hsdes.intel.com/schemas/2012/Query"><Filter/></Query>'
```

### Error Handling

| Code | Meaning |
|------|---------|
| 200 | Success |
| 400 | Bad Request (invalid params) |
| 401 | Unauthorized (check auth headers) |
| 503 | Service Unavailable |

## Important Notes

- **Rate Limiting**: Register your application via `/clientregistration` to get an API key for production use
- **Token Expiry**: Tokens expire — use `PUT /token/{operation}` with `operation=renew` to extend
- **Optimistic Locking**: Always pass `rev` when updating to prevent conflicts
- **Email Control**: Set `send_mail=false` for bulk operations to avoid notification storms
- **Field Names**: Use fully-qualified field names (e.g., `server.bugeco.component`) for ambiguous fields
- **Text Fields**: Set `include_text_fields=Y` to get description/rich-text fields in query results

## Related Tools

- `mcp_intel_geni_pr_HSDTool` — Alternative HSD access via GenI MCP
- `mcp_intel_geni_pr_HSDIndexTool` — HSD index search via GenI MCP
- `mcp_askdme_get_hsd_ticket` — Get HSD ticket via AskDME MCP
- `mcp_askdme_search_hsd_tickets` — Search HSD tickets via AskDME MCP
- `mcp_askdme_execute_hsdes_query` — Execute HSDES query via AskDME MCP
