---
name: mermaid-analyst
description: "Expert knowledge of MerlinX/xMon AI Debugger (MerMAID) - analyze, explain, and debug MerlinX issues using UML sequence diagrams and technical specifications. Use this skill whenever the user mentions MerlinX, xMon, boot flows, BIOS API, platform configuration XML, xMon commands, sequence diagrams, post codes, serial log errors, boot hangs, bare-metal validation, context initialization, or asks about any SV BIOS execution sequence — even if they don't explicitly ask for 'analysis'."
---

# MerMAID: MerlinX/xMon AI Debugger

**Expert analysis and debugging of MerlinX issues using sequence diagrams and specifications.**

## Purpose

This skill provides expert guidance on:

1. **Boot Flow Analysis** - Understanding MerlinX initialization and library loading sequences
2. **Platform Configuration** - Analyzing PlatformConfig.xml element generation
3. **BIOS API** - Understanding test runtime interfaces and calling conventions
4. **xMon Commands** - Debugging test execution and xMon tool usage
5. **Sequence Diagram Interpretation** - Reading and explaining UML flow diagrams

## When I Activate

Automatically when you mention:

- "merlinx", "xmon", "mermaid"
- "boot flow", "initialization sequence"
- "platform config", "pcxml", "platformconfig.xml"
- "bios api", "biosapi", "test runtime"
- "sequence diagram", "uml diagram", ".wsd file"
- "sv bios", "bare metal", "content execution"
- "context init", "module exec", "merlinx table"

## Quick Reference

### Available Resources

#### Sequence Diagrams (`.wsd` files)

**Boot Flow Sequences:**
- `boot.wsd` - Main MerlinX boot sequence orchestrator
- `boot_ContextInitLib*.wsd` - Context initialization flows
- `boot_MerlinLib.wsd` - MerlinX library initialization (CLI mode stub; see `boot_MerlinLib_OTL.wsd` for OTL)
- `boot_MerlinLib_OTL.wsd` - **OTL-specific** MerlinLib flow (file load, ParseFileTable, CopyTestToMemory, JumpToTest)
- `boot_CreateBiosApi.wsd` - BIOS API creation (CLI/XML modes only)
- `boot_HostInterfaceLib.wsd` - Host interface setup
- `boot_PlatformConfigXmlLib.wsd` - Platform configuration XML generation
- `CliDxeEntryPoint*.wsd` - CLI DXE entry point flows (CLI mode only)
- `CliMain.wsd` - CLI main execution flow (CLI mode only)

**Platform Config XML (PCXML) Sequences:**
- `pcxml_*.wsd` - Various XML element generation flows including:
  - ACPI tables, BIOS API, Board info
  - CPU/Memory references
  - Package/Core/Thread enumeration
  - PCI devices, IO blocks, memory maps
  - Platform drivers and system elements

**Runtime Sequences (CLI mode only — do NOT reference for OTL logs):**
- `run_scatterobjectfile.wsd` - CLI scatter OBJ parsing (xMon SCATTER command)
- `run_advancedscatter.wsd` - CLI advanced scatter with compression/patching (xMon ADVANCED_SCATTER command)
- `run_FakedInit.wsd` - CLI FakedInit thunk (xMon FAKED_INIT command)

> **WARNING:** These `run_*.wsd` diagrams document the **CLI/xMon mailbox** code path.
> They are NOT used in OTL mode (`-otl`). OTL has its own load/parse/execute path
> in `boot_MerlinLib_OTL.wsd`. Always detect the execution mode before selecting diagrams.

**Participants:**
- `participants.wsd` - Common actors and components used across diagrams

#### Technical Specifications

The following technical specifications and reference guides are available:

- BIOS API and runtime interface specifications
- xMon user guides and command references
- CLI protocol specifications
- SV BIOS architecture documentation
- Object format specifications (SCATTER_OBJ, ADVANCED_SCATTER_OBJ, etc.)
- Interface specifications (Content Interface, Kishon driver, mailbox protocols)
- Flow examples and configuration guides
- Latest updates and revisions

### Key Components (Participants)

```
XMon         - eXtensible test Monitor (host-side execution tool)
VSMB         - Virtual Shared Memory Block (communication channel)
MerlinXContext - Runtime context and state
MerlinX      - SV BIOS execution framework
PostCode     - Debug output via post codes
Serial Port  - Debug output via serial
Content      - Test content/workload
```

## How to Use This Skill

Detailed walkthroughs for each use case are in the `examples/` folder. Read the relevant file when a user's request matches.

| Use Case | File |
|---|---|
| Analyzing boot issues | [examples/analyzing-boot-issues.md](examples/analyzing-boot-issues.md) |
| Understanding PlatformConfig.xml generation | [examples/platform-config-xml.md](examples/platform-config-xml.md) |
| Debugging BIOS API issues | [examples/debugging-bios-api.md](examples/debugging-bios-api.md) |
| Analyzing xMon execution issues | [examples/analyzing-xmon-execution.md](examples/analyzing-xmon-execution.md) |
| Classifying BIOS vs MerlinX log output | [examples/log-classification.md](examples/log-classification.md) |
| **OTL vs CLI mode — diagram & flow selection** | [examples/otl-dragon-vs-cafe.md](examples/otl-dragon-vs-cafe.md) |

### Reading Sequence Diagrams

**Understanding .wsd diagram syntax:**

```
participant "Name" as alias      - Define an actor/component
-> or -->                        - Synchronous call
--> or ->>                       - Asynchronous message
opt condition                    - Optional flow
group name                       - Grouped operations
== Section Name ==               - Section separator
!include file.wsd                - Include another diagram
```

**Common patterns in MerlinX diagrams:**
- `merlinx -> serial:` - Debug output to serial port
- `merlinx -> merlinx:` - Internal function call
- `opt CONDITION` - Conditional compilation or execution
- `!include boot_*.wsd` - Module execution delegation

### Bucketization — Quick Definition

> **"Bucketize"** means: scan to the end of the log (or to the last error), identify the **final failure bucket** — the single phase label where the last failure or final event appears — and report it in this format:
>
> ```
> Final Failure Bucket: <bucket name>
> Last observable event: <exact log line or event>
> Rationale: <one sentence>
> Next step: <what is needed, or "none" if conclusive>
> ```
>
> Do NOT produce a full phase breakdown as the bucketization answer. See [examples/analysis-workflow.md](examples/analysis-workflow.md) for the full bucket table and [examples/otl-dragon-vs-cafe.md](examples/otl-dragon-vs-cafe.md) for OTL vs CLI bucket labels.

### Troubleshooting Workflow

Use this systematic approach for MerlinX issues:

1. **Gather Symptoms** — Serial output errors, post codes, hang/crash location
2. **Bucketize** — Assign the single final failure bucket (see definition above and [examples/analysis-workflow.md](examples/analysis-workflow.md))
3. **Form Hypothesis** — Locate relevant diagrams and specs, develop a *candidate* root cause
4. **Verify on SUT** — Confirm the hypothesis with live SUT evidence (see below)
5. **Identify Root Cause** — Only conclude after verification data supports the hypothesis
6. **Propose Solution** — Reference spec requirements, provide code examples, suggest debug steps

For detailed root cause investigation areas and recommended live debug actions per area, see [examples/analysis-workflow.md](examples/analysis-workflow.md).

> **CRITICAL: Never conclude a root cause from register dumps or log patterns alone.**
> Pattern-matching register values (e.g., RAX near APIC base, RCX = 0x1B) can be misleading.
> Always verify by reading the actual faulting instruction and relevant MSR/CR state on the SUT
> before stating a root cause. Live verification (disassembly at faulting RIP + MSR/CR reads) is required before stating root cause.

> **MANDATORY: Label as hypothesis and request live verification.**
> When analyzing logs/serial output without live SUT access, you MUST:
> 1. **Label the analysis as a "Hypothesis (unverified)"** — never present pattern-matched conclusions as a definitive root cause.
> 2. **Ask the user whether a live SUT is available** for verification before concluding.
> 3. **List the specific verification steps** needed on the SUT to confirm or refute the hypothesis.
>
> Only after live verification data confirms the hypothesis may it be promoted to "Root Cause".

#### Mandatory Verification Steps for CPU Exceptions

Before concluding any `#GP`, `#UD`, `#PF`, or other CPU exception root cause:

| Step | Action | Tool |
|---|---|---|
| 1. Disassemble at faulting RIP | Confirm the actual faulting opcode | `read_asm_instructions(rip)` |
| 2. Read relevant MSRs/CRs | Verify the CPU state that caused the fault | `thread.msr()` or `read_cpu_register()` |
| 3. Check platform prerequisites | Unlock state, ucode version, feature locks | `is_unlocked()`, `read_microcode_version()` |
| 4. Correlate all evidence | Only then state the root cause with confidence | — |

If the SUT is not available for live verification, clearly state that the analysis is
a **hypothesis based on pattern matching** and list what verification steps are needed.

## Specifications Reference

The `specifications/` folder contains detailed technical documents organized by topic. See [examples/specifications-reference.md](examples/specifications-reference.md) for the full file-by-file index with "when to consult" guidance.

## Key Concepts

### MerlinX Boot Phases

1. **Context Initialization** - Set up MerlinX runtime context
2. **Module Execution** - Execute MerlinXTable modules in sequence
3. **Library Loading** - Initialize platform-specific libraries
4. **BIOS API Creation** - Build runtime test interface
5. **Platform Config Generation** - Create PlatformConfig.xml
6. **CLI Loop** - Enter command line interface (if enabled)

### MerlinX Modes

- `MERLINX_MODE_ON_TARGET_LOADER` - On-target boot loader mode
- `MERLINX_MODE_GEN_XML` - Generate PlatformConfig.xml mode
- `MERLINX_MODE_RUN_CLI_LOOP` - CLI interactive mode
- `SV_COMMON_SUPPORT` - SV common feature support flag

### OTL vs CLI Mode — Critical Differences

**Always detect the execution mode BEFORE selecting diagrams or code paths.**
For the full side-by-side comparison, log pattern detection table, and diagram selection cheat sheet, see [examples/otl-dragon-vs-cafe.md](examples/otl-dragon-vs-cafe.md).

| Aspect | OTL (`-otl`) | CLI (`-cli` / default DXE) |
|---|---|---|
| **Flag** | `MERLINX_MODE_ON_TARGET_LOADER` (BIT5) | `MERLINX_MODE_RUN_CLI_LOOP` (BIT4) |
| **Launch** | UEFI Shell command: `merlinx -otl -a <file.obj>` | DXE driver loads → boots to F6 → xMon connects |
| **OBJ Load** | `ShellReadFile()` → `ParseFileTable()` → `CopyTestToMemory()` | xMon SCATTER/ADVANCED_SCATTER over mailbox → `ScatterObjectFile()` |
| **Test Entry** | `JumpToTest()` → `AsmPrepareAndThunk16()` | xMon FAKED_INIT command → `cli_FakedInit()` → `AsmThunk16()` |
| **CLI Loop / F6** | Never entered — runs test and returns to shell | Enters CLI loop, posts 0xF6, waits for xMon |
| **Key Diagram** | `boot_MerlinLib_OTL.wsd` | `run_scatterobjectfile.wsd`, `run_advancedscatter.wsd`, `run_FakedInit.wsd` |

### BIOS API Calling Requirements

- **Processor Mode:** 64-bit with identity mapping
- **Paging:** Identity-mapped paging table
- **Stack:** Minimum `BIOS_API_MIN_STACK_SPACE`
- **VM State:** Must execute VmExit before calling API
- **Location:** Defined in PlatformConfig.xml at `/SYSTEM/biosapi/APITable_Address`
- **Validation:** Check function pointer != 0 before calling

### PlatformConfig.xml Structure

Key elements generated by MerlinX:
- ACPI tables
- BIOS API location and stack size
- Board information
- CPU topology (package/core/thread)
- Memory maps and references
- PCI devices
- IO blocks
- Platform drivers
- System configuration

### Host Interface Cards Reference

For detailed Kfir/Dishon/LCBE VID/DID tables and quick diagnosis steps, see [examples/no-host-interface.md](examples/no-host-interface.md).

## Common Debugging Scenarios

Detailed investigation steps for each scenario are in the `examples/` folder. Read the relevant file when a user's issue matches.

| Scenario | File |
|---|---|
| Boot hangs during library initialization | [examples/boot-hang-library-init.md](examples/boot-hang-library-init.md) |
| Missing XML elements in PlatformConfig.xml | [examples/missing-xml-elements.md](examples/missing-xml-elements.md) |
| Test content crashes on BIOS API call | [examples/bios-api-crash.md](examples/bios-api-crash.md) |
| xMon command fails | [examples/xmon-command-failure.md](examples/xmon-command-failure.md) |
| Mailbox communication issues | [examples/mailbox-communication.md](examples/mailbox-communication.md) |
| No host interface selected (Kfir/Dishon not found) | [examples/no-host-interface.md](examples/no-host-interface.md) |
| #GP/#UD during FAKED_INIT (APIC, patch opcodes, x2APIC lock) | [examples/patch-opcode-ud-exception.md](examples/patch-opcode-ud-exception.md) |
| Wrong DCI type string ("Cannot communicate with the BIOS") | [examples/dci-type-string-mismatch.md](examples/dci-type-string-mismatch.md) |
| OTL test hang/fail (no xMon, UEFI Shell execution) | [examples/otl-dragon-vs-cafe.md](examples/otl-dragon-vs-cafe.md) |

## Best Practices & Advanced Usage

See [examples/best-practices.md](examples/best-practices.md) for detailed guidelines on analyzing sequences, debugging, providing solutions, viewing diagrams, combining diagrams, and correlating logs.

## Limitations

- Diagrams represent design intent; actual execution may vary with compilation flags, platform capabilities, runtime mode, and BIOS version
- Not all error paths are documented; some flows are platform-dependent
- Always consult the latest specifications and documentation
- **Analysis from logs/register dumps alone is hypothesis, not diagnosis** — register values can match multiple root causes. Always verify on the SUT before concluding.
- **NEVER assume the platform from the test content file path.** A path like `FS1:\contents\ptl_dragon\` is just a content storage directory — it does NOT indicate the actual silicon platform the test ran on. To determine the actual platform, require one of: `$IBIOSI$` BIOS version string, CPUID family/model/stepping, XmlCli `GetBiosVersion` output, or PlatformConfig.xml CPU reference section. If none are present, state "Platform: Unknown — not determinable from this log".

## Getting Help

When this skill doesn't have the answer:

1. **Check specification document versions** - Ensure you have latest revision
2. **Review release notes** - Check for known issues or changes
3. **Consult key contacts** - Reach out to xMon/MerlinX developers listed in specs
4. **Search HSDeS** - Look for related bug reports or feature requests
5. **Request diagram updates** - If flow has changed, request new .wsd files
