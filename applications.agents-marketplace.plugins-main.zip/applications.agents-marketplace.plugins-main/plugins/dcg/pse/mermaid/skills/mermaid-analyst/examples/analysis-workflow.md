# Analysis Workflow: Failure Triage

When analyzing a MerlinX failure, follow these steps after gathering symptoms and fetching relevant specs.

## Step 1: Bucketize the Failure

> **Definition:** "Bucketize" means assign a **single final failure bucket** — the phase bucket where the **last failure or significant event** appears in the log. It is NOT a full phase breakdown; it is a one-line verdict of where the log ends or where the last error occurs.

First detect the execution mode (OTL vs CLI) — see [otl-dragon-vs-cafe.md](otl-dragon-vs-cafe.md) for the full detection and bucketization guide. Then assign one bucket:

### CLI / DXE Mode

| Bucket | Description | Key indicator |
|---|---|---|
| **Pre-F6** | Failure during MerlinX init before CLI loop | Error/hang before `MerlinX booted to 0xf6` |
| **F6** | CLI loop active but xMon cannot connect | `MerlinX booted to 0xf6` present; Heartbeat = `0x00000000` |
| **Post-F6** | Failure during OBJ delivery or test dispatch | Error in `ScatterObjectFile` / `cli_FakedInit` after F6 |
| **Running Test** | Failure inside test content | Error/hang after `AsmThunk16` entered |
| **Running Test (not observable)** | Log ends at dispatch with no prior error — failure not captured | Last line is dispatch entry; no in-test serial |

### OTL Mode

> F6 never applies to OTL. Use these equivalent buckets:

| Bucket | Description | Key indicator |
|---|---|---|
| **Pre-test** | Failure during OTL init (file load → CopyTestToMemory → symbol resolution) | Error/hang before `Running Test` |
| **Running Test** | Failure inside test content | Error/hang after `Running Test` line |
| **Running Test (hang)** | BSP entered real mode and hung — test started but no further output | `RealContext.RealModeBuffer` before `Running Test`, then `CurProcessorNumber value = 0` is the last line |
| **Running Test (not observable)** | Log ends at dispatch with no in-test output at all — failure not captured | `Running Test` alone is the last line; no `CurProcessorNumber value = 0` follows |
| **Post-test** | Return from thunk, result visible | PASS/FAIL line present after `Running Test` |

### Required Bucketization Output Format

When asked to bucketize, always produce exactly this:

```
Final Failure Bucket: <bucket name>
Last observable event: <exact log line or event>
Rationale: <one sentence tying the bucket to the log evidence>
Next step: <what additional data is needed, or "none" if conclusive>
```

Do **not** produce a full phase breakdown as the bucketization answer. The bucket table above is a reference; the answer is a single bucket.

## Step 2: Extract Key Evidence

From the serial log or xMon output, extract:

- **Error messages** — exact text of any `[error]`, `fail`, `assert`, or exception strings
- **Register / CPU state** — values such as `RIP`, `RSP`, `CR0/CR3/CR4`, `RFLAGS` if a crash occurred
- **Memory / buffer addresses** — addresses reported in error context (e.g., buffer base, BIOS API table address, VSMB entries)
- **Error codes** — numeric status codes (EFI status, mailbox status, MRC status) and their decoded meaning
- **POST codes** — the last POSTCODE seen before failure; correlate with the MerlinX postcode map
- **Surrounding context** — 5–10 lines before and after the error to capture what triggered it

## Step 3: Map to Root Cause Investigation Area

| Area | When to suspect it | Key indicators |
|---|---|---|
| **Scatter / Upload** | Test content fails before entry point | `scatter`, `upload`, OBJ transfer errors, VSMB buffer mismatch, compressed OBJ address wrong |
| **Test Entry / Handoff** | Crash immediately at content start | Bad `RIP`, wrong calling convention, identity-map not set, `CR3` wrong, stack misaligned |
| **Memory Mapping** | Fault accessing buffers or DMA regions | Page fault `RIP`, `CR2` (fault address), MTRR mismatch, HOB map vs actual layout |
| **OBJ / EFI Image Issues** | Content loads but won't execute or corrupts | Bad PE relocations, wrong image base, EFI hand-off protocol failure, `RUN_EFI_COMMAND` error |
| **Context Transition** | Crash on SMM entry/exit or VM exit | `VMCS` error, `SMBASE` conflict, NMI during transition, `RSP` corruption across boundary |
| **Host Interface / DCI** | F6 reached but xMon cannot connect | `DCI_INTERFACE_TYPE_UNDEFINED`, Kfir/Dishon not enumerated, Heartbeat `0x00000000` |
| **BIOS Firmware (Pre-MerlinX)** | Hang or error before `MerlinX [info] Start` | MRC failure, TXT ACM mismatch, VR mailbox error, P2SB sideband failure, FSP error postcode |
| **Mailbox / CLI Protocol** | xMon command sends but no response | Request/response buffer signature wrong, VSMB entry missing, CLI timeout |
| **PlatformConfig.xml Generation** | XML element missing or device count wrong | `[PlatformConfigMerlinXTable]::` error, PCI scan count mismatch, ACPI table not found |
| **MMCFG Address Truncation** | #GP during PCI BAR enumeration on platforms with MMCFG > 4GB | Garbage in RDI/R8, #GP in `BusDeviceFunctionMemoryMapElemement`, `(UINT32)` cast on MMCFG address. See [mmcfg-truncation-gp.md](mmcfg-truncation-gp.md) |
| **BIOS API Calling Convention** | HeartBeat or any API call crashes | Not in 64-bit mode, identity mapping missing, VmExit not called, stack < `BIOS_API_MIN_STACK_SPACE` |

State the **most likely area** first, give a **one-sentence rationale** tied directly to the log evidence, then list **concrete next steps** (e.g., which register to check, which spec section to read, which xMon command to run).

## Step 4: Prescribe Live Debug Actions

Based on the root cause area, recommend specific hardware debug steps:

| Root cause area | Recommended live debug actions |
|---|---|
| **Test Entry / Handoff** | Read `RIP`, `RSP`, `CR0`, `CR3`, `CR4`, `RFLAGS` at crash point; verify identity-mapping by reading page table at `CR3`; check stack pointer alignment (must be 16-byte aligned) |
| **Memory Mapping** | Read `CR2` (fault address); dump MTRRs; compare UEFI memory map (from HOB) against physical layout; check SMRAM overlap |
| **Scatter / Upload** | Read VSMB OBJ Load buffer address and size from BIOS API table; verify first 8 bytes of buffer for OBJ signature; confirm no overlap with MerlinX own memory |
| **OBJ / EFI Image Issues** | Read PE header at load base; verify `MZ`/`PE` signatures; check relocation base vs actual load address; read entry point offset |
| **Context Transition** | Read `VMCS` control fields (if VM); read `SMBASE` register; verify NMI routing; dump stack around `RSP` to check corruption markers |
| **Host Interface / DCI** | Read PCI config space at Kfir/Dishon BDF; verify BAR assignment; check Heartbeat register at BIOS API `HeartBeat` offset |
| **BIOS Firmware (Pre-MerlinX)** | Read relevant MSRs (e.g., `IA32_MCG_STATUS` for MCA); read MMIO registers cited in error (e.g., VR mailbox, P2SB); dump MRC save data from HOB |
| **Mailbox / CLI Protocol** | Read VSMB entry table at BIOS API base; verify request/response buffer signatures (`0xCA11AB1E` / `0xCA11B0B0`); read CLI mailbox header fields |
| **PlatformConfig.xml** | Read PlatformConfig.xml from VSMB (entry 3 at offset `0x61C04F1C`); search for the missing element; check PCI scan count in log vs actual `lspci` output |
| **BIOS API Calling Convention** | Symbol-map the crashing `RIP` to a function name; read `CR0` bit 31 (paging), bit 0 (protected mode); read `EFER.LMA` for 64-bit mode |

**Symbol mapping:** If the crashing `RIP` is inside MerlinX.efi, subtract the MerlinX load base (from `Loading driver at 0x...` in the log) from `RIP` to get the file offset, then look up the symbol in the `.map` or `.pdb` file.

## Step 5: Hand Off to Debugger

Always ask the user:

> "Do you have the target system (SUT) connected and accessible right now? If yes, I can hand off to the **mermaid-debugger** to run the live register reads, memory dumps, and xMon commands recommended above directly on the hardware."

- If connected → invoke the **mermaid-debugger** skill with the specific debug commands needed
- If not connected → summarize the full debug checklist as a saved reference
