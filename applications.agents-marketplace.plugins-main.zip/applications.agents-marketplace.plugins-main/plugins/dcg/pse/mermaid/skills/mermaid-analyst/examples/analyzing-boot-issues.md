# How To: Analyzing Boot Issues

When investigating MerlinX boot problems:

**Step 1:** Identify the boot phase
- Review serial output for "MerlinX [info] Start" and version info
- Locate where the boot sequence fails

**Step 2:** Find relevant sequence diagram
- Use `boot.wsd` for overall flow
- Check specific library diagrams (e.g., `boot_ContextInitLib_2.wsd`, `boot_MerlinLib.wsd`)

**Example Query:**
```
"Why is ContextInitLib failing during boot? Show me the sequence."
```
