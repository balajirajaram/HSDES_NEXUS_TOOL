# Best Practices & Advanced Usage

## When Analyzing Sequences

1. **Start with boot.wsd** - Understand overall orchestration
2. **Follow includes** - Trace `!include` directives to detailed flows
3. **Note conditionals** - Pay attention to `opt` blocks and flags
4. **Track participants** - Keep participants.wsd handy for actor definitions
5. **Cross-reference** - Verify understanding against specifications

## When Debugging

1. **Collect evidence first** - Serial output, post codes, logs
2. **Use diagrams for flow** - Understand expected sequence
3. **Consult specifications** - Verify interface requirements
4. **Form hypothesis** - Develop a candidate root cause from evidence and specs
5. **Verify on SUT before concluding** - Use **mermaid-debugger** to disassemble at faulting RIP, read relevant MSRs/CRs, and confirm the hypothesis with live hardware evidence. **Never state a root cause based solely on register pattern matching.**
6. **Test incrementally** - Isolate problematic phase
7. **Document findings** - Note deviations from expected flow

> **Lesson learned:** Register values that match a known pattern (e.g., RAX near APIC base)
> can have multiple root causes. In one case, a #GP during FAKED_INIT was initially attributed
> to a missing patch3 unlock based on register patterns, but SUT verification showed the
> faulting instruction was WRMSR (not patch3) and the actual cause was an x2APIC lock.

## When Providing Solutions

1. **Reference specifications** - Quote relevant specifications
2. **Show diagram context** - Explain where in sequence the issue occurs
3. **Cite documentation** - Reference applicable specification documents
4. **Provide code examples** - Use examples from specifications
5. **Suggest validation steps** - How to verify the fix
6. **Consider side effects** - Impact on other components

## Viewing Sequence Diagrams

**Option 1: PlantUML Preview (VS Code)**
- Install PlantUML extension → Open `.wsd` file → Press `Alt+D` to preview

**Option 2: PlantUML Online**
- Paste to http://www.plantuml.com/plantuml/uml/

**Option 3: Command Line**
```powershell
java -jar plantuml.jar boot.wsd
```

Use the `renderMermaidDiagram` tool (if available) to convert PlantUML to visual format for inline display.

## Advanced Usage

### Combining Multiple Diagrams

To trace end-to-end flow:
1. Start with main diagram (`boot.wsd`, `CliMain.wsd`)
2. Follow each `!include` statement
3. Build mental model of complete sequence
4. Note dependencies and prerequisites

### Correlating Logs with Diagrams

First classify each log line as BIOS or MerlinX output — see [log-classification.md](log-classification.md) for the full pattern tables and checklist.

Match serial output to diagram steps:
- "MerlinX [info] Start" → Start of boot.wsd
- "MerlinX Version" → Version reporting section
- Library names → Corresponding `boot_*Lib.wsd` diagrams
- Element generation → Corresponding `pcxml_*.wsd` diagrams
- `HostInterfaceLib: [N]VendorDeviceId = XXXXXXXX` → PCI scan loop in `boot_HostInterfaceLib.wsd`; compare against **Host Interface Cards Reference** in SKILL.md
- `No Host Interface was selected` → `HostInterfaceCount == 0` path; see [no-host-interface.md](no-host-interface.md)

### Creating Custom Analysis

Use specifications and diagrams to:
- Generate timing diagrams
- Calculate boot time metrics
- Identify optimization opportunities
- Document custom flows
- Create debugging checklists
