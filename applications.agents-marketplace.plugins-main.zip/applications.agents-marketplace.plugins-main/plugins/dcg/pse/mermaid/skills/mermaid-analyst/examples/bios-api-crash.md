# Scenario: Test Content Crashes on BIOS API Call

**Investigation Steps:**
1. Review BIOS API specifications
2. Verify calling environment (64-bit, identity mapping, stack)
3. Check function pointer validity (non-zero)
4. Ensure VmExit was executed
5. Review `boot_CreateBiosApi.wsd` for initialization
