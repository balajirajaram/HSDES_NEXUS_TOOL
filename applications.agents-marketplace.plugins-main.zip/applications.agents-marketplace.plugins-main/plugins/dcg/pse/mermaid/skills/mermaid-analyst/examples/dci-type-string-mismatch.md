# Scenario: Wrong DCI Type String — "Cannot communicate with the BIOS"

**Symptoms:**
- xMon `target tgt $CLSID_CDCIDMA` connects to DCIDMA successfully
- `CSymBuffer` is pushed
- Error: `Cannot communicate with the BIOS`
- MerlinX serial log shows `MerlinX booted to 0xf6` (boot succeeded)

## Root Cause

MerlinX was launched with the wrong `-dci <type>` argument, causing it to initialize the DCI scratchpad registers (emb0/emb1/emb2) at the **wrong P2SB port ID and MMIO offsets**. xMon reads the correct offsets for the actual platform but finds nothing there.

Each DCI type string maps to a specific P2SB sideband port that hosts the EXI emb registers. Using the wrong type means MerlinX writes the VSMB base address, control, and data to a completely different physical address than xMon expects.

## Key Gotcha: DCI Sideband Loop `[FALSE]` Is Normal

> **IMPORTANT:** `DCI sideband loop [FALSE]` is **normal for DCI-based platforms** and appears
> in both working and failing logs. Do NOT treat `DCI sideband loop [FALSE]` as a root cause
> for xMon communication failures. The sideband loop is a separate feature and is not required
> for standard DCIDMA connectivity.

## DCI Type Strings — Complete Reference

Source: `MerlinX/SvRestricted/Core/MerlinX/Library/PlatformFeaturesLib/PlatformFeaturesLib.c`
Constants: `MerlinX/SvRestricted/Core/MerlinX/Include/Library/MerlinXContext.h`

Each type string selects a different P2SB port ID for the emb register MMIO base, and optionally overrides the host interface type:

| DCI Type | Alias | Platform | P2SB Port / Register Source | InterfaceType | HIF Override |
|---|---|---|---|---|---|
| `cfl` | `gen1` | SKL, KBL, CFL | MCHBAR + `0x5428/542C/5430` | `DCI_INTERFACE_TYPE_CFL` | — |
| `whl` | `gen2` | WHL | NPK BAR0 + `0xEC` (control), MCHBAR (data/mb) | `DCI_INTERFACE_TYPE_WHL` | — |
| `cnl` | `gen3` | CNL | PCI CF8 BAR + `0xDC` (control), MCHBAR (data/mb) | `DCI_INTERFACE_TYPE_CNL` | — |
| `icl` | `gen4` | ICL | P2SB port `PID_DCI` | `DCI_INTERFACE_TYPE_ICL` | — |
| `mtl` | — | MTL (U/H client) | P2SB port **`0xCF`** (SOC south EXI-IP ISOF-SB) | `DCI_INTERFACE_TYPE_MTL` | — |
| `mtls` | — | MTL-S / ARL-S | P2SB port **`0xB8`** (PCH die) | `DCI_INTERFACE_TYPE_MTL` | **`HIType_Dbc64`** |
| — | `gen6` | LNL | P2SB 16-bit port `0xF35C` | `DCI_INTERFACE_TYPE_LNL` | — |
| `ptl` | `gen7` | PTL | P2SB 16-bit port `0xF28E` | `DCI_INTERFACE_TYPE_PTL` | `HIType_Dbc64` (gen7 only) |
| `nvl` | `gen8` | NVL | Platform `GetDciMailboxAddr()` | `DCI_INTERFACE_TYPE_NVL` | `HIType_Dbc64` (gen8 only) |

### `mtl` vs `mtls` — The Critical Difference

```c
// MTL (U/H client) — emb registers on SOC south die, port 0xCF
// MMIO evaluates to 0xE0CF0030 (/34/38)
// PythonSV: sv.socket0.soc.south.exi.exi.emb0 (/1/2)
DciInterface.Control      = GetPchPcrAddress64(..., 0xCF, pch_exi_pvt_emb0);
DciInterface.Data         = GetPchPcrAddress64(..., 0xCF, pch_exi_pvt_emb1);
DciInterface.SharedMailbox = GetPchPcrAddress64(..., 0xCF, pch_exi_pvt_emb2);
InterfaceType = DCI_INTERFACE_TYPE_MTL;

// MTLS/ARLS — emb registers on PCH die, port 0xB8
// MMIO evaluates to P2sbRegBar(0x5FF0000000) | 0xB8 << 16 | offset
// PythonSV: sv.pch0.exi.exi.emb0 (/1/2)
DciInterface.Control      = GetPchPcrAddress64(..., 0xB8, pch_exi_pvt_emb0);
DciInterface.Data         = GetPchPcrAddress64(..., 0xB8, pch_exi_pvt_emb1);
DciInterface.SharedMailbox = GetPchPcrAddress64(..., 0xB8, pch_exi_pvt_emb2);
InterfaceType = DCI_INTERFACE_TYPE_MTL;
ActiveHostInterfaceType = HIType_Dbc64;  // ← mtl does NOT do this
```

| Aspect | `mtl` | `mtls` |
|---|---|---|
| P2SB Port ID | `0xCF` (SOC south die) | `0xB8` (PCH die) |
| PythonSV path | `soc.south.exi.exi.emb*` | `pch0.exi.exi.emb*` |
| Host interface override | none | `HIType_Dbc64` (DbC 64-bit) |
| Platforms | MTL-U, MTL-H | MTL-S, ARL-S |

Using `-dci mtl` on an ARL-S system writes to port `0xCF` (SOC south) which does not host the emb registers on that platform. xMon reads port `0xB8` (PCH) and finds zeroes → "Cannot communicate with the BIOS".

Additionally, the `HIType_Dbc64` override is required for xMon's `$CLSID_CDCIDMA` to use the correct DbC 64-bit protocol on ARL-S. Without it, even if the addresses were somehow correct, the protocol handshake would fail.

## Diagnosis

Compare these three serial log fields between a known-good log and the failing log:

```
MerlinX [info] DCI loading interface        [True]       ← must be True
MerlinX [info] DCI sideband loop            [FALSE]      ← FALSE is normal, ignore this
MerlinX [info] DCI type string              [???]        ← must match the platform
```

If `DCI type string` differs between working and failing, that is the root cause.

### CPUID Cross-Check

The CPUID family/model/stepping from the log can confirm the platform:

| CPUID (EAX from Leaf 1) | Platform | Expected DCI Type |
|---|---|---|
| `000C06xx` | Arrow Lake-S (ARL-S) | `mtls` |
| `000A06xx` | Meteor Lake (MTL-U/H) | `mtl` |

## Investigation Steps

1. Check `DCI type string` in the serial log — compare against good log or expected value for platform
2. Cross-reference CPUID `EAX` from `CPUID_VERSION_INFO (Leaf 00000001)` to confirm the platform variant
3. Verify the MerlinX launch command — the `-dci` argument must match the platform
4. **Do NOT** suspect `DCI sideband loop [FALSE]` — this is normal
5. If you have PythonSV access, verify: on ARL-S read `sv.pch0.exi.exi.emb2` (should be VSMB base); on MTL-U/H read `sv.socket0.soc.south.exi.exi.emb2`

## Fix

Change the `-dci` argument to match the platform:

```diff
- MerlinX.efi -cli -genxml -dci mtl  -objlsz 200
+ MerlinX.efi -cli -genxml -dci mtls -objlsz 200
```

## Case Study Reference

**CaseStudy4:** ARL-S platform (CPUID `000C0662`) launched with `-dci mtl` instead of `-dci mtls`. MerlinX booted to F6 without errors, but xMon `target tgt $CLSID_CDCIDMA` failed with "Cannot communicate with the BIOS" because the VSMB address was written to P2SB port `0xCF` (SOC south) while xMon was reading port `0xB8` (PCH). The missing `HIType_Dbc64` override also prevented the correct DbC 64-bit protocol handshake.
