# How To: Debugging BIOS API Issues

When troubleshooting test runtime interface problems:

**Step 1:** Understand the interface
- Review BIOS API and runtime interface specifications
- Verify calling convention (64-bit, identity mapping, stack requirements)

**Step 2:** Check creation sequence
- Review `boot_CreateBiosApi.wsd` for BIOS API initialization
- Verify memory location in PlatformConfig.xml

**Step 3:** Validate usage in test content
- Ensure proper calling environment (64-bit, identity mapping, VM exit)
- Verify function pointer usage

**Example Query:**
```
"My test content crashes when calling HeartBeat function. What's the correct way to use BIOS API?"
```
