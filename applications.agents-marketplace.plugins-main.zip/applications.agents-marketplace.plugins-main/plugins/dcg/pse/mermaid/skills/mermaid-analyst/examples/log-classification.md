# Differentiating BIOS Output vs MerlinX Output in a Log

When a user sends a large combined serial log, the output contains two fundamentally different sources: the **BIOS firmware** (SEC/PEI/DXE phases) and **MerlinX** (a DXE driver loaded late in the boot). Knowing which phase produced a line is critical to correct diagnosis.

---

## Phase Boundary Markers

| Boundary | Log signature | Meaning |
|---|---|---|
| **Start of MerlinX** | `Loading driver at 0x... MerlinX.efi` followed by `MerlinX [info] Start` | MerlinX.efi was just loaded by DXE dispatcher |
| **End of MerlinX boot** | `MerlinX booted to 0xf6` | MerlinX finished init, CLI loop is now active |
| **Start of BIOS** | `Serial reg: IER:...` / `FSP-T: CAR Init` | Very first lines; SEC/Cache-As-RAM phase |

Everything **before** `MerlinX [info] Start` = **BIOS output**.
Everything **from** `MerlinX [info] Start` onward = **MerlinX output**.

---

## BIOS Output — Recognizable Patterns

These line patterns are produced exclusively by the BIOS firmware:

| Pattern | Phase | Example |
|---|---|---|
| `Serial reg:` / `FSP-T:` / `FSP-M` | SEC | `Serial reg: IER:00 IIR:01` |
| `Loading PEIM ... .efi` | PEI | `Loading PEIM at 0x000FFE70BC0 EntryPoint=... PcdPeim.efi` |
| `Install PPI:` / `Register PPI Notify:` | PEI | `Install PPI: 8C8CE578-8A3D-4F1C-...` |
| `PROGRESS CODE: V...` | PEI/DXE | `PROGRESS CODE: V03020002 I0` |
| `Port80 forward FSP POSTCODE=<...>` / `POSTCODE = <...>` | FSP-M/FSP-S | `Port80 forward FSP POSTCODE=<DC00>` |
| `MRC task -- ... -- Started.` / `SUCCEEDED` | MRC (memory training) | `MRC task -- SPD PROCESSING STATIC -- Started.` |
| `GREEN MRC task --` | Green MRC (UC microcode) | `GREEN MRC task DUnit Config -- SUCCEEDED` |
| `Loading driver at 0x... .efi` | DXE | `Loading driver at 0x00066472000 EntryPoint=... SomeDxe.efi` |
| `InstallProtocolInterface:` | DXE | Protocol installation during DXE |
| `TXTPEI::` | TXT module | `TXTPEI::TXT failed reported by S-ACM` |
| `[HECI Access]` / `[HECI Transport]` / `[HECI Control PEI]` | ME/HECI | CSME interface init |
| `[GPIOV2][PEI]:` | GPIO | GPIO PPI initialization |
| `P2SB: MSG failed` | Sideband messaging | `P2SB: MSG failed PID:76, Resp:1` |
| `SmbusPeiEntryPoint` / `PcdPwrm:` / `PCH DID:` | PCH early init | PCH detection |

**BIOS POST code range:** `0xDB00` – `0xDEFF` (FSP-M/S codes), `0x9C**`, `0xDA**`, `0xDC**`, `0xDD**`

---

## MerlinX Output — Recognizable Patterns

These line patterns are produced exclusively by MerlinX:

| Pattern | Phase | Example |
|---|---|---|
| `MerlinX [info] ...` | All MerlinX phases | `MerlinX [info] Start` / `MerlinX [info] ContextInitLib Start` |
| `MerlinX Version` | Init | `MerlinX Version [8.21]` |
| `[MerlinXTable]::...()` | Module execution | `[MerlinXTable]::HostInterfaceLib(): Initializing host interface` |
| `[PlatformConfigMerlinXTable]::...()` | XML generation | `[PlatformConfigMerlinXTable]::PackageCoreThreadElement(): <Package/Cores>` |
| `HostInterfaceLib: [N]VendorDeviceId =` | Host interface scan | `HostInterfaceLib: [0]VendorDeviceId = 0x82A210B5` |
| `No Host Interface was selected` | Host interface error | Kfir/Dishon not found on PCIe |
| `CleanupLib(): MerlinX cleanup:` | Init cleanup | Memory/resource cleanup |
| `MerlinX [info] - SaveApicConfiguration` | Late init | Just before CLI loop |
| `MerlinX [info] -Disable NMI` | Late init | Just before CLI loop |
| `MerlinX booted to 0xf6` | **CLI loop entry** | System ready for xMon connection |
| `MerlinXPlatformDriverEntrypoint` | Platform driver | Platform-specific init |
| `0x00000008    MerlinXMajor` / `0x0000000F    MerlinXApiMinor` | BIOS API dump | Register/field dump from CLI |
| `GbtMerlinXVersionElement():` | XML gen | `<MERLINX>` element creation |
| `InterfaceType = DCI_INTERFACE_TYPE_UNDEFINED` | DCI issue | DCI not detected |

**MerlinX POST code:** Final value is always `0xF6` when booted successfully (CLI mode). OTL mode does not post `0xF6`. For OTL-specific log patterns and diagram selection, see [otl-dragon-vs-cafe.md](otl-dragon-vs-cafe.md).

---

## Quick Classification Checklist

When given a log, apply these steps in order:

1. **Find the BIOS/MerlinX boundary** — search for `MerlinX [info] Start`. All lines before = BIOS, all after = MerlinX.
2. **Determine which phase has the problem** — is the suspicious line before or after that boundary?
3. **For BIOS errors** — identify the PEIM/module name from the nearest `Loading PEIM` or `Loading driver` line above the error.
4. **For MerlinX errors** — identify the library from the nearest `[MerlinXTable]::LibName()` line above the error.
5. **Check the last POSTCODE** — the final `POSTCODE = <...>` before the error points to the exact FSP/MRC step that was executing.
