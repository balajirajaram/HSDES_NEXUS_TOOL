# Scenario: Mailbox Communication Issues

**Investigation Steps:**
1. Identify mailbox type (shared, CLI, BIOS info)
2. Review corresponding mailbox specification
3. Check VSMB initialization in sequences
4. Verify signature and structure format
5. Review `participants.wsd` for communication flow
