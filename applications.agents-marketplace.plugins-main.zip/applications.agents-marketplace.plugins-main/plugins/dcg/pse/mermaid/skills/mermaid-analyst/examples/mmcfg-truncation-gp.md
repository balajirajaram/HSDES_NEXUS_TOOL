# Known Pattern: MMCFG Address Truncation → #GP in PlatformConfig.xml Generation

## Trigger

- `#GP` (Exception Type 0D) during `PlatformDriver_BusDeviceFunctionMemoryMapElemement()`
- Occurs with `-genxml`, `save_gbt`, or `save_platformconfig` in xMon
- Platform has `PcdPciExpressBaseAddress > 0xFFFFFFFF` (MMCFG above 4GB)

## Signature (from register dump)

| Indicator | What to look for |
|---|---|
| Faulting function | `PlatformDriver_BusDeviceFunctionMemoryMapElemement` in serial output |
| ExceptionData | `0x0000000000000000` (not segment-related) |
| RDI, R8 | Garbage 64-bit values (random DRAM data, e.g., `6501C111E33C3AC0`) |
| RIP | Inside NovaLakePlatformDriver*.efi address range |
| PCIEX_BASE | Above 4GB (e.g., `0x4120000000` for NovaLake) |

## Root Cause

`SvMmPciRead64.c` contains a `(UINT32)` cast that truncates the MMCFG address:

```c
// BUG: (UINT32) truncates address when PcdPciExpressBaseAddress > 4GB
return MmioRead64 ((UINT32)SV_MEM_MAPPED_PCI_ADDRESS (Bus, Dev, Func, Reg));
```

The truncated address points into DRAM, which returns garbage. That garbage is used as a BAR base address for subsequent `MmioRead64()` calls → non-canonical address → `#GP`.

## Affected Code Path

```
PlatformDriver_BusDeviceFunctionMemoryMapElemement()
  → MemoryMapping[1] = {Bus=0, Dev=2, Func=0, Offset=0x10}  (iGPU GTTMMADR)
    → SvMmPciRead64(0, 2, 0, 0x10)   ← size=8 path
      → MmioRead64((UINT32)(0x4120000000 + 0x10010))
      → MmioRead64(0x20010010)        ← WRONG! reads DRAM garbage
    → Address = (garbage & ~0xF) + register_offset
    → MmioRead64(non_canonical_address)  ← #GP!
```

## Fix

In `SvRestricted/Platform/NovaLakeSvRestrictedPkg/Dxe/MerlinXPlatformDriver/SvMmPciRead64.c`:

```c
// FIXED: Remove (UINT32) cast to preserve full 64-bit MMCFG address
return MmioRead64 (SV_MEM_MAPPED_PCI_ADDRESS (Bus, Dev, Func, Reg));
```

## Workaround

Comment out the iGPU entry in `MemoryMapping[]` table in `MissingElements.c`:

```c
CONST MEMPRTY_MAPPING MemoryMapping [] = {
  { 0, 0, 0, 0,    (MEMORY_MAP_REGS *)MemoryMapRegs_0_0_0 },
  // { 0, 2, 0, 0x10, (MEMORY_MAP_REGS *)MemoryMapRegs_0_2_0 }  // COMMENTED OUT: triggers SvMmPciRead64 truncation
};
```

## How to Diagnose Similar Issues in Future

1. **Check PCIEX_BASE_ADDRESS** — Is it above 4GB? (NovaLake = `0x4120000000`)
2. **Grep for `(UINT32)` casts** on any expression involving `PcdPciExpressBaseAddress` or `SV_MEM_MAPPED_PCI_ADDRESS`
3. **Look at register dump** — Garbage in GP registers (non-zero upper 32 bits that don't look like valid addresses) during PCI enumeration functions = likely truncation
4. **Confirm with memory map** — Cross-reference `Memory Begin` entries to see if MMCFG is above 4GB

## Platforms Affected

Any platform where `PcdPciExpressBaseAddress` exceeds `0xFFFFFFFF`:
- NovaLake: `0x4120000000`
- (Add future platforms as discovered)
