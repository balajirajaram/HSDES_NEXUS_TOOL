# Scenario: No Host Interface Selected

**Symptoms:**
- Serial log: `No Host Interface was selected`
- Serial log: `HostInterfaceLib: Attempting to recover Kfir using SMBus`
- POSTCODE `A0CA` has unusually high TSC (seconds vs. microseconds for other modules)
- F6 CLI loop reached but xMon cannot connect — Heartbeat stays `0x00000000`

## Host Interface Cards Reference

Sourced from `HostInterfaceLibInternal.h` (via `headerfile/HostInterfaceLibInternal.h.txt`).

During `HostInterfaceLib` execution (POSTCODE `0xA0CA`), MerlinX scans all PCI devices and prints:
```
HostInterfaceLib: [N]VendorDeviceId = XXXXXXXX
```
The DWORD format is `DID[31:16] | VID[15:0]` (printed as a single 32-bit hex value).

### Kfir (PLX/Rambus PCIe card) — VID `0x10B5`

| Constant | VID | DID | VEND_DEV_ID (log value) | Notes |
|---|---|---|---|---|
| `KFIR_BRG_VEND_DEV_ID` | `0x10B5` | `0x81A2` | `0x81A210B5` | Kfir Bridge |
| `KFIRKTC_VEND_DEV_ID` | `0x10B5` | `0x82A2` | `0x82A210B5` | Kfir KTC ← primary match |
| `KFIR_NT_VEND_DEV_ID` | `0x10B5` | `0x86A0` | `0x86A010B5` | Kfir NT Bridge |

xMon class ID: `$CLSID_CKfir`

### Dishon (NetChip NET228x USB card) — VID `0x17CC`

| Constant | VID | DID | VEND_DEV_ID (log value) | Notes |
|---|---|---|---|---|
| `NET2280_VEND_DEV_ID` | `0x17CC` | `0x2280` | `0x228017CC` | NET2280 |
| `NET2282_VEND_DEV_ID` | `0x17CC` | `0x2282` | `0x228217CC` | NET2282 ← primary match |

xMon class ID: `$CLSID_CNet2280`

### LCBE (Low-Cost Board Emulator — SPI-based)
- VID/DID is **configurable** via `-lcbe VIDDID FIFO-offset` argument at MerlinX startup
- Detected independently of the Kfir/NET228x switch — separate `if` check against `MerlinXContext->LcbeVidDid`
- `InitLcbeHostInterface: Found SPI Flash Controller` appears in log when detected

### Quick Diagnosis
- If **none** of the above VID/DID values appear in the scan → `HostInterfaceCount == 0` → `"No Host Interface was selected"`
- Recovery: `RecoverKfirUsingSMBus()` finds Kfir via SMBus I²C, triggers system reset for PCIe re-enumeration
- If reset is suppressed by `NullPlatformResetSystem` → system proceeds to F6 **without** a host interface → xMon cannot connect (Heartbeat stays `0x00000000`)

## Investigation Steps

**Investigation Steps:**
1. Scan serial log for `HostInterfaceLib: [N]VendorDeviceId =` lines — compare against the tables above
2. If none of `0x82A210B5` / `0x81A210B5` / `0x86A010B5` / `0x228217CC` / `0x228017CC` appear → Kfir/Dishon not enumerated on PCIe
3. Check if `RecoverKfirUsingSMBus` found the card — `Kfir found on SMBus reseting switch` confirms physical presence but PCIe-invisible
4. Check if `NullPlatformResetSystem was called to skip resets` appears — recovery reset was suppressed
5. Check `CpuSvBootMode` BIOS knob to confirm the intended interface:
   - `CpuSvBootMode=0x2` → Kfir (PCIe)
   - `CpuSvBootMode=0x4` → DCI (USB)
   - **Gotcha:** `CpuSvBootMode` is a hidden/test knob — it only appears in Knobs.xml when `EnableTestMenu=0x1`. If `EnableTestMenu=0x0` (default), `get_knob_value("CpuSvBootMode")` raises `KeyError`.
6. If Kfir card is physically present but not enumerated, verify it is in a **BIOS-enumerated PCIe slot** — some slots may be disabled in BIOS or routed to a CPU root port that is fused off. Try moving the card to a different PCIe slot
7. Fix options: reseat/replace Kfir card in PCIe slot, or rebuild without `NullPlatformReset` override to allow recovery reset
7. Reference `boot_HostInterfaceLib.wsd` for the full detection and recovery flow
