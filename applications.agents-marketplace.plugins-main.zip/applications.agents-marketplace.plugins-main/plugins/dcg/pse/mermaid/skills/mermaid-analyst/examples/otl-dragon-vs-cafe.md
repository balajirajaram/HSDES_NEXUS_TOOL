# OTL vs CLI Mode — Detection, Diagram Selection & Failure Bucketization

Use this file whenever you need to:
- Detect which execution mode a log was produced in
- Select the correct sequence diagram for the code path in question
- Apply the correct phase taxonomy when bucketizing a failure

---

## Step 1: Detect Execution Mode from the Log

**Primary method — look for the keyword on the UEFI Shell command line:**

- `-otl` present → **OTL mode**
- `-cli` present → **CLI mode**
- No shell command visible (DXE driver auto-launched) → **CLI/DXE mode**

This is sufficient in the vast majority of logs. The command line is always near the top of an OTL log (e.g., `merlinx -otl -a DM40-....obj -x2ar -f 3`).

**Fallback — if the command line is missing or the log is a fragment:**

| Fallback signature | Mode |
|---|---|
| `Loading File <name>.obj` / `ParseFileTable` / `CopyTestToMemory` | OTL |
| `Running Test` + `CurProcessorNumber value = 0` | OTL |
| `MerlinX booted to 0xf6` | CLI |
| `ScatterObjectFile` / `cli_FakedInit` / `AsmThunk16` | CLI |

---

## Step 2: Select the Correct Sequence Diagram

### OTL Mode → use these diagrams

| Phase | Diagram | What it covers |
|---|---|---|
| Full OTL flow | `boot_MerlinLib_OTL.wsd` | **Primary reference** — ShellReadFile → ParseFileTable → CopyTestToMemory → JumpToTest → AsmPrepareAndThunk16 |
| MerlinX boot orchestrator | `boot.wsd` | Top-level module dispatch; covers ContextInitLib, HostInterfaceLib etc. before MerlinLib |
| Context init | `boot_ContextInitLib*.wsd` | Context setup phases |

> **Do NOT use** `run_scatterobjectfile.wsd`, `run_advancedscatter.wsd`, or `run_FakedInit.wsd` for OTL logs. Those are CLI/xMon mailbox paths only.

### CLI / DXE Mode → use these diagrams

| Phase | Diagram | What it covers |
|---|---|---|
| DXE entry | `CliDxeEntryPoint*.wsd` | CLI DXE driver load and entry |
| CLI main loop | `CliMain.wsd` | CLI loop, F6, mailbox poll |
| SCATTER OBJ delivery | `run_scatterobjectfile.wsd` | xMon SCATTER command → ScatterObjectFile() |
| ADVANCED_SCATTER | `run_advancedscatter.wsd` | Compressed/patched OBJ delivery |
| Test dispatch | `run_FakedInit.wsd` | FAKED_INIT → cli_FakedInit() → AsmThunk16() |
| BIOS API creation | `boot_CreateBiosApi.wsd` | BIOS API table setup (CLI/XML only) |
| PlatformConfig.xml gen | `boot_PlatformConfigXmlLib.wsd` + `pcxml_*.wsd` | XML element generation |

---

## Step 3: Apply the Correct Failure Phase Taxonomy

### OTL Phase Taxonomy

> F6 **never applies** in OTL mode. Never label OTL phases as "Pre-F6" or "Post-F6".

| Phase | Description | How to detect in log |
|---|---|---|
| **Pre-test** | All OTL init: file load → ParseFileTable → CopyTestToMemory → symbol resolution → memory broadcasts | Everything before `Running Test` |
| **Test dispatch** | JumpToTest → AsmPrepareAndThunk16 → real-mode thunk entry | `Running Test` + `CurProcessorNumber value = 0` (last lines) |
| **In-test execution** | Real-mode test content running (BSP + APs) | Any serial output from within test code after dispatch |
| **Post-test / Return** | Return from thunk → PASS/FAIL result reported | PASS/FAIL/result line after `Running Test` |

#### OTL Bucketization Rules
- If the log ends at `Running Test` + `CurProcessorNumber value = 0` with **no error before it**, AND `RealContext.RealModeBuffer` appears in the lines immediately before `Running Test` → bucket as **Running Test (hang)**. `CurProcessorNumber value = 0` is the BSP's first in-test serial output from inside real mode; the log ending there means the test entered and then hung with no further output.
- If the log ends at `Running Test` alone (no `CurProcessorNumber value = 0` following it) with **no error before it** → bucket as **Running Test (not observable)**; dispatch occurred but no in-test output was captured.
- If the log shows an error or hang **before** `Running Test` → bucket as **Pre-test failure**; identify which sub-step failed (file load, ParseFileTable, symbol resolution, memory broadcast).
- If the log ends **abruptly before** `Running Test` → bucket as **Pre-test hang**; last completed line identifies the stall point.

### CLI / DXE Phase Taxonomy

| Phase | Description | How to detect in log |
|---|---|---|
| **Pre-F6** | MerlinX init: ContextInitLib, HostInterfaceLib, CreateBiosApi, PlatformConfigXml generation | `MerlinX [info] Start` through library init lines; **absence** of `MerlinX booted to 0xf6` |
| **F6** | CLI loop active, waiting for xMon connection | `MerlinX booted to 0xf6` present; Heartbeat register = `0x00000000` |
| **Post-F6** | xMon connected, SCATTER/ADVANCED_SCATTER, FAKED_INIT dispatch | `ScatterObjectFile`, `cli_FakedInit` in log |
| **In-test** | Real-mode test content running | Serial output from test code |
| **Post-test** | Return from thunk, PASS/FAIL | Result line after dispatch |

---

## Step 3b: Bucketize — Assign the Final Failure Bucket

> **Bucketize = identify the single bucket where the last failure or final event appears.** Scan to the end of the log (or the last error), pick one label from the table below, and report it using the output format in [analysis-workflow.md](analysis-workflow.md).

After detecting mode and locating the last clean line in the log, assign **one** of these bucket labels.

### CLI / DXE Mode

| What the log shows | Final Failure Bucket |
|---|---|
| Error or hang before `MerlinX booted to 0xf6` | **Pre-F6** |
| `MerlinX booted to 0xf6` present, xMon cannot connect (Heartbeat = 0) | **F6** |
| Error during `ScatterObjectFile` / `ADVANCED_SCATTER` / `cli_FakedInit` (after F6, before content runs) | **Post-F6** |
| Error or hang after test dispatch (`AsmThunk16` entered), inside test content | **Running Test** |
| Log ends cleanly at dispatch, no error — failure not visible in this capture | **Running Test (not observable)** |

### OTL Mode

> F6 **never applies** to OTL. Map to the equivalent OTL bucket below.

| What the log shows | Final Failure Bucket | OTL equivalent of... |
|---|---|---|
| Error or hang before `Running Test` | **Pre-test** | Pre-F6 |
| `Running Test` alone is the last line, no prior error, no `CurProcessorNumber value = 0` | **Running Test (not observable)** | Post-F6 / in-test |
| `RealContext.RealModeBuffer` before `Running Test`, then `CurProcessorNumber value = 0` is the last line — BSP entered real mode but no further output | **Running Test (hang)** | Running Test (hang) |
| Error or hang after `Running Test` (in-test serial output present) | **Running Test** | Running Test |
| PASS/FAIL result line visible | **Post-test** | Post-test |

---

## Step 4: OTL Log Sub-Stage Reference

Within the **Pre-test** phase of an OTL log, these sub-stages appear in order:

| Sub-stage | Key log line(s) | Failure indicators |
|---|---|---|
| UEFI Shell launch | `merlinx -otl -a <file>.obj ...` | Wrong path / file not found |
| MerlinX version / processor detection | `MerlinX Version [x.xx]`, `NumberOfProcessors [N]` | Unexpected processor count |
| FileTable allocation | `AllocatePool for File Table`, `FileTable located at ...` | Memory allocation failure |
| OBJ file load | `Loading File <name>.obj`, `Filesize = ...` | File not found, wrong size |
| Data section placement (`CopyTestToMemory`) | `data section N goes at <addr>` (one line per section) | Address collision, bad section |
| Multi-broadcast memory setup | `MULTI-BROADCAST MEMORY: Broadcasting to address at ...` | Wrong target count, bad address |
| DataDump collection (thread stacks) | `DataDumpAddr_Stack<N>` / `DataDumpEnd_Stack<N>` | Missing dump, size mismatch |
| Symbol resolution | `String Received = <symbol>  Address is <addr>` (×N) | Symbol not found, wrong address |
| VVAR / startupData / Regen dumps | `DataDumpAddr_VVAR`, `DataDumpAddr_startupData`, `DataDumpAddr_Regen` | Dump missing or wrong size |
| Regen config parse | `_M_mode`, `_cpuName`, `_svnRev`, `hasTBSIDMap`, thread TBSID entries | All-same address (0xA07F) is normal for tail zero-size labels |
| Thunk setup | `ThunkCodeData`, `Regs.E.Cs`, `RealContext.RealModeBuffer` | Wrong code/data placement |
| Test execution handoff | `Running Test` + `CurProcessorNumber value = 0` | `CurProcessorNumber value = 0` is the BSP's first in-test serial output; if this is the **last line** in the log (preceded by `RealContext.RealModeBuffer`), treat as **Running Test (hang)**, not normal dispatch |

---

## Side-by-Side Comparison

| Aspect | OTL (`-otl`) | CLI (`-cli` / DXE) |
|---|---|---|
| **Launch trigger** | Explicit UEFI Shell command | DXE dispatcher (automatic) |
| **OBJ delivery** | `ShellReadFile()` → `ParseFileTable()` → `CopyTestToMemory()` | xMon SCATTER / ADVANCED_SCATTER over mailbox |
| **Test dispatch** | `JumpToTest()` → `AsmPrepareAndThunk16()` | FAKED_INIT → `cli_FakedInit()` → `AsmThunk16()` |
| **F6 / CLI loop** | **Never entered** | Always entered; posts `0xF6`; waits for xMon |
| **xMon required** | No | Yes |
| **Phase taxonomy** | Pre-test / Dispatch / In-test / Post-test | Pre-F6 / F6 / Post-F6 / In-test / Post-test |
| **Primary diagram** | `boot_MerlinLib_OTL.wsd` | `run_scatterobjectfile.wsd` + `run_FakedInit.wsd` |
| **Result reporting** | Serial output (PASS/FAIL) + return to UEFI Shell | xMon reads VSMB result entry |

---

## Step 5: Test Family vs. Platform — Do NOT Confuse "Dragon" with a Platform Name

**"Dragon" is the test content family (test suite name), not the platform or CPU.**

In OTL logs the word "Dragon" appears in two places:
1. The UEFI Shell directory path: `Dragon\<svnRev>_<stepping>_<steppingLabel>\<cpuName_variant>\`
2. The Regen metadata block (`Address:A07F` entries) as a standalone label

Neither of these is the platform. The actual CPU/platform identity comes from:

| Source | Field | Example |
|---|---|---|
| Regen metadata | `_<cpuName>_cpuName` | `_NVL16B32A4_cpuName` → CPU = NVL16B32A4 |
| Directory path 3rd segment | `<cpuName_variant>` | `NVL16B32A4_M` |
| MerlinX init line | `MerlinX [info] NumberOfProcessors` | processor count only |

**Correct reporting format:**

```
Test family:  Dragon
Test name:    DM40 (Dragon Mode 40-thread), from _0Demo_______testName_devName
CPU/Platform: NVL16B32A4_M  ← from _NVL16B32A4_cpuName
Stepping:     PPV (0x57)     ← from directory path segment
```

> Common mistake (confirmed across multiple sessions): listing "Platform: Dragon / NVL16B32A4".
> Always separate the test family label from the CPU/platform label.

### Step 5b: Verify OBJ Target Platform from Binary

When an OBJ file is available on disk, **always check the binary metadata** to confirm which platform it was built for — do NOT rely on directory names alone.

Use `debug_actions/merlinx/obj_metadata.py` to extract the platform tag (e.g., `PTLB4C` = Panther Lake B-step). This avoids misattributing failures to "platform mismatch" based on folder names that may be mislabeled or shared staging areas.

---

## Step 6: Silence After "Running Test" — Bucket Correctly

When an OTL log ends exactly at:
```
Running Test
CurProcessorNumber value = 0
```
with **no prior error**, the correct bucket is:

**`Running Test — Hang/Failure`** — treat silence as a failure, not as a clean dispatch.

> **Why:** A test that runs to completion always produces a PASS/FAIL result line on return from the thunk. Silence means the test did not return — this is a hang or silent failure, not a truncated capture.

### Root Cause Investigation (ranked)

| Rank | Area | Rationale |
|---|---|---|
| 1 | **Test content hang** | Deadlock among threads, infinite loop, or unhandled exception inside test — most common after clean pre-test |
| 2 | **Thunk / Mode transition failure** | Triple fault → silent reset; `-x2ar` can trigger `#GP` if the APIC lock is active on the stepping under test |
| 3 | **AP rendezvous failure** | INIT/SIPI failure for one or more APs causes BSP to deadlock at rendezvous barrier waiting for `num_threads_running` |
| 4 | **Serial log truncation** | Test completed but output was lost — lowest probability since PASS/FAIL is written very early on thunk return |

### Verification Steps (live SUT, in order)

1. **Read POST code** — if frozen for extended time, system is hung; if cycling, test may still be running
2. **Read RIP on BSP** — if stuck inside thunked region (address < 0x100000), confirms in-test hang
3. **Check AP states** — read RIP on all logical processors; halted at `ap_halt` address = AP reached halt normally; stuck elsewhere = AP hang
4. **Read CMOS 0x0E/0x0F** — OTL writes pass/fail result to CMOS on thunk return; if unwritten, thunk never returned
5. **Check x2APIC lock** — with `-x2ar`, verify MSR `0x1B` (APIC_BASE) bit 10 (x2APIC enable) and whether the platform locks this MSR on the stepping under test
