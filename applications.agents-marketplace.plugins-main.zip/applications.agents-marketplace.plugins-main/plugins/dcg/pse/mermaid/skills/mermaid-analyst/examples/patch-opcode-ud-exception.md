# Scenario: #GP/#UD During FAKED_INIT (APIC Reset, Patch Opcodes, x2APIC Lock)

This document covers CPU exceptions (`#GP`, `#UD`) that occur during `FAKED_INIT` and `ResetApicController`, including patchable opcode failures and x2APIC lock violations.

> **CRITICAL: Do not conclude root cause from register patterns alone.**
> A `#GP` during `FAKED_INIT` with RAX near `0xFEE00xxx` and RCX = `0x1B` can be caused by
> multiple distinct issues (patch3 unlock missing, x2APIC lock engaged, invalid APIC mode
> transition). Always **disassemble at the faulting RIP** and **read the relevant MSRs** on the SUT
> before concluding. See [Mandatory Verification Steps](#mandatory-verification-steps) below.

## What Are patch2/patch3?

These are **debug-mode patchable instruction placeholders** used in place of `RDMSR`/`WRMSR` in some UEFI tools (e.g., ULX). Debug microcode is expected to intercept these opcodes at runtime and execute the corresponding MSR operation. They appear in MSR access wrapper functions:

```asm
; RDMSR wrapper pattern
patch2              ; 0F 0E — replaced by RDMSR at runtime
lfence
mov rax, rdx
ret

; WRMSR wrapper pattern
mov rax, rcx        ; set up arguments
mov rcx, rdx
mov rdx, r8
patch3              ; 0F 0F — replaced by WRMSR at runtime
lfence
ret
```

## Prerequisites

All must be satisfied for patch opcodes to work:

| Prerequisite | How to Check | Tool |
|---|---|---|
| Debug microcode loaded | MSR 0x8B bits [63:32], bit 31 = 1 → debug | `read_microcode_version()` |
| SUT unlocked | `itp.isunlocked()` returns `True` | `is_unlocked()` |
| Patch3 unlocked (recent cores) | ULX tool run before test execution | ULX |

If debug ucode is missing, the CPU treats `0F 0E` / `0F 0F` as undefined opcodes → `#UD`.  
If the SUT is locked or patch3 support is not unlocked, `#GP` may occur instead.

## x2APIC Lock (#GP on WRMSR to IA32_APIC_BASE)

On recent cores, the microcode supports an **x2APIC lock** that prevents software from transitioning out of x2APIC mode once entered. When the lock is engaged, any `WRMSR` to `IA32_APIC_BASE` (MSR `0x1B`) that clears the EXTD bit (bit 10) or EN bit (bit 11) causes `#GP(0)`.

### Relevant MSRs

| MSR | Address | Key Bit | Meaning |
|---|---|---|---|
| `MSR_ARCH_CAPABILITIES` | `0x10A` | Bit 21 | ucode supports x2APIC lock |
| `MSR_IA32_X2APIC_LOCK` | `0xBD` | Bit 0 | x2APIC lock is engaged |
| `IA32_APIC_BASE` | `0x1B` | Bits 11:10 | APIC mode (11 = x2APIC) |
| `XAPIC_LOCK_DISABLE_CR` | FSCR `0xE6E` | Bit 10 | Setting disables the lock |

### How This Manifests in FAKED_INIT

During `CallToRealMode` with `mThunkContextInitFlag == 0` (first call), MerlinX calls `ResetApicController`. If the reset code uses a plain `WRMSR` to `IA32_APIC_BASE` to reconfigure the APIC, and:
- `MSR_ARCH_CAPABILITIES` bit 21 = 1 (lock supported)
- `MSR_IA32_X2APIC_LOCK` bit 0 = 1 (lock engaged)
- `IA32_APIC_BASE` bits 11:10 = `11` (currently in x2APIC mode)

Then the `WRMSR` faults with `#GP(0)` because it attempts to leave x2APIC mode while locked.

### Telltale Signs (Requires Verification)

These register patterns **suggest** x2APIC lock but must be verified:
- Exception: `#GP (0D)`, error code `0`
- RCX = `0x1B` (IA32_APIC_BASE MSR)
- RAX near `0xFEE00100` (APIC base with EN cleared or EXTD cleared)
- Faulting instruction disassembles to `WRMSR` (`0F 30`) — **not** `patch3` (`0F 0F`)

### Fix

The `ResetApicController` code must disable the x2APIC lock before writing `IA32_APIC_BASE`:
1. Check `MSR_ARCH_CAPABILITIES` bit 21 — if x2APIC lock is supported
2. Check `MSR_IA32_X2APIC_LOCK` bit 0 — if lock is engaged
3. Set FSCR `0xE6E` bit 10 to disable the lock before the `WRMSR`

Alternatively, ULX or platform init should disable the x2APIC lock prior to `FAKED_INIT`.

## Patch3 APIC State Reset (Recent Cores)

On recent CPU cores, `ResetApicControllerPatch2` uses a **patch3 command with RCX command 0x11** to write to the MLC register `ML3_CR_PIC_THREAD_CONFIG[CLEAR_APIC_STATE]`. This write requires appropriate pre- and post-serialization.

The **ULX tool** is responsible for performing the patch3 unlock on these cores. If ULX has not been run prior to `FAKED_INIT`, the patch3 instruction will fault:
- `#GP` (General Protection) if debug ucode is present but the unlock was not performed
- `#UD` (Invalid Opcode) if debug ucode is absent entirely

## Investigation Steps

> **Always verify on SUT. Do not skip to conclusions from register patterns.**

1. **Disassemble at faulting RIP** — use `read_asm_instructions(rip_address)` to identify the actual faulting instruction:
   - `patch2` (`0F 0E`) or `patch3` (`0F 0F`)  → patchable opcode issue (see Prerequisites above)
   - `WRMSR` (`0F 30`) with RCX = `0x1B` → likely x2APIC lock (see x2APIC Lock section above)
   - Something else → investigate further (corrupt code, different MSR, etc.)
2. **Check microcode version** — use `read_microcode_version()` to verify debug ucode is loaded (version bit 31 set)
3. **Check SUT unlock** — use `is_unlocked()` to verify the part is unlocked
4. **Read x2APIC lock MSRs** (if faulting instruction is `WRMSR` to `IA32_APIC_BASE`):
   - `thread.msr(0x10A)` → check bit 21 (x2APIC lock support)
   - `thread.msr(0xBD)` → check bit 0 (lock engaged)
   - `thread.msr(0x1B)` → check bits 11:10 (current APIC mode)
5. **Correlate all evidence** — only then state the root cause

## Distinguishing #GP/#UD Causes During FAKED_INIT

| Cause | Faulting Opcode | RCX | Key MSR Check | Typical Scenario |
|---|---|---|---|---|
| patch2/patch3 — no debug ucode | `0F 0E` / `0F 0F` | N/A | MSR 0x8B bit 31 = 0 | `#UD` — debug tools using patchable MSR stubs |
| patch3 — unlock not performed | `0F 0F` | 0x11 | ULX not run | `#GP` — patch3 present but not unlocked |
| x2APIC lock engaged | `0F 30` (WRMSR) | 0x1B | MSR 0xBD bit 0 = 1 | `#GP` — WRMSR to IA32_APIC_BASE blocked by lock |
| Invalid APIC mode transition | `0F 30` (WRMSR) | 0x1B | Bits 11:10 of 0x1B | `#GP` — x2APIC → xAPIC without disable sequence |
| Unsupported instruction on A0 silicon | Varies | Varies | — | Silicon errata, new ISA extension |
| Missing CR4 feature bit | XSAVE-family, VMX, etc. | — | CR4 | Feature requires `CR4.OSXSAVE`, `CR4.VMXE`, etc. |
| Corrupt code fetch | Random bytes | Random | — | Memory corruption, bad DMA, stale cache |

**The key differentiator is always disassembly.** Register patterns alone can match multiple root causes.

## Mandatory Verification Steps

This section is referenced by the main SKILL.md. For **any** `#GP` or `#UD` during `FAKED_INIT`:

```
Step 1: read_asm_instructions(RIP, 8, thread_index)
        → What is the actual faulting opcode?

Step 2: read_microcode_version(thread_index)
        → Is debug ucode loaded? (bit 31 of version)

Step 3: is_unlocked()
        → Is the SUT red-unlocked?

Step 4: thread.msr(0x10A), thread.msr(0xBD), thread.msr(0x1B)
        → If WRMSR to 0x1B: is x2APIC lock engaged?

Only after all four steps produce consistent evidence → state root cause.
If any step is unavailable → clearly mark analysis as "hypothesis, not verified."
```

### Lesson Learned: Why This Matters

In a real debug session, a `#GP(0)` during `FAKED_INIT` with `mThunkContextInitFlag=0`, RAX=`0xFEE00100`, and RCX=`0x1B` was initially diagnosed as a **patch3 unlock issue** based on pattern matching against known register signatures. Live verification on the SUT revealed:

- The faulting instruction was `WRMSR` (`0F 30`), **not** `patch3` (`0F 0F`)
- The actual root cause was an **engaged x2APIC lock** (MSR 0xBD bit 0 = 1)
- The fix was completely different: disable x2APIC lock via FSCR 0xE6E, not run ULX

**Pattern matching picks the most common cause. Verification finds the actual one.**
