# Specifications Reference

The `specifications/` folder contains detailed technical documents. Consult the appropriate file based on the topic.

## Architecture & Core Specs
| File | When to consult |
|---|---|
| `SV BIOS External Architecture Specification (EAS) Revision 0.8.0.docx` | Overall SV BIOS architecture, high-level design questions |
| `BIOS_API (Test runtime interfaces) Version 2.0.md` | BIOS API function signatures, calling conventions, interface details |
| `BIOS_API.xlsx` | BIOS API tabular data (function tables, parameter lists) |
| `BIOS Spec 0.8 - Spec update delta (0.4).docx` | Changes between spec revisions |

## Object & Data Formats
| File | When to consult |
|---|---|
| `Object format spec Rev 2.0.md` | General object format specification |
| `SCATTER_OBJ.md` | Scatter object structure and usage |
| `ADVANCED_SCATTER_OBJ.md` | Advanced scatter object extensions |
| `FAKED_INIT.md` | Faked initialization object format |
| `RUN_EFI_COMMAND.md` | EFI command execution object format |

## Communication & Mailbox Protocols
| File | When to consult |
|---|---|
| `Shared mailbox.md` | Shared mailbox protocol between host and target |
| `sharedmailbox_table.xlsx` | Mailbox field definitions (tabular) |
| `BIOS info mailbox.md` | BIOS information mailbox structure |
| `CLI mailbox.md` | CLI command mailbox protocol |
| `CLI_table.xlsx` | CLI mailbox field definitions (tabular) |
| `Command line interface protocol.md` | Full CLI protocol specification |

## Interfaces & Drivers
| File | When to consult |
|---|---|
| `64-bit MerlinX Content Interface.docx` | 64-bit content interface calling conventions |
| `Driver to Kishon interface specification.md` | Driver-to-Kishon interface details |
| `xMon to Kishon driver interface.md` | xMon-to-Kishon communication |

## xMon & Tools
| File | When to consult |
|---|---|
| `xmon User Guide.docx` | Full xMon user guide (comprehensive) |
| `xMon user guide.md` | xMon user guide (markdown version) |
| `xMon4 SAS.md` | xMon4 Software Architecture Specification |
| `MegaBlock user guide Rev 2.md` | MegaBlock tool usage |

## Workflows & Examples
| File | When to consult |
|---|---|
| `Bare metal flow example.md` | End-to-end bare-metal execution example |
| `Cafe reset flow.md` | Cafe test reset flow details |
| `Enabling PXE boot.md` | PXE boot configuration |
| `baremetal_table.xlsx` | Bare-metal flow tabular reference |
