# Scenario: xMon Command Fails

**Investigation Steps:**
1. Review xMon command syntax
2. Verify package was imported (`pa re <package>`)
3. Confirm target was created (`target tgt`)
4. Review appropriate host interface class ID
5. Check extension DLL availability
