---
name: mermaid-debugger
description: "Hands-on hardware debugging for MerlinX/xMon bare-metal validation systems — runs directly on the debug host with access to TTK, PythonSV (ipccli/namednodes), XmlCli, and XMon tools. Use this skill whenever the user wants to read/write memory via DCI, check POST codes, verify F6 boot status, download PlatformConfig.xml (GBT), power-cycle the SUT via TTK, read BIOS knobs via XmlCli, send xMon commands, or perform any live debug operation on a System Under Test — even if they just say 'check the system' or 'grab the post code'."
---

# MerMAID Debugger: Live Hardware Debug on the Debug Host

**Direct, hands-on debug operations on a System Under Test (SUT) using TTK, PythonSV, XmlCli, and XMon — no server/client mode required.**

## Purpose

This skill runs directly on the debug host machine that is physically connected to the SUT. It provides live hardware debug capabilities through Python scripts in the `debug_actions/` folder, leveraging:

- **TTK** (TTK2/TTK3) — POST code reading and power control
- **PythonSV** (`ipccli` / `namednodes`) — DCI-based memory read/write and register access
- **XmlCli** — BIOS knob inspection and microcode version retrieval
- **XMon** — Platform interface discovery, GBT download, and xMon command execution
- **MerlinX tools** (`merlinx/`) — VSMB table parsing, PlatformConfig.xml download, F6 check, version reading

Because this skill operates directly on the debug host, there is no server/client architecture — all tool invocations execute locally against the hardware.

## When I Activate

Automatically when you mention:

- "post code", "postcode", "port 80", "port80"
- "f6", "f6 check", "boot status", "emb0"
- "read memory", "write memory", "mem read", "mem write", "dci", "dma"
- "merlinx base", "merlinx.efi", "image base", "find merlinx", "pe header"
- "power on", "power off", "power cycle", "ttk"
- "download gbt", "save gbt", "platformconfig", "platform config download"
- "bios knobs", "xmlcli", "knob value", "microcode version"
- "xmon command", "xmon connect", "viewpoint", "host interface"
- "vsmb", "shared mailbox", "signature address"
- "debug sut", "connect sut", "live debug"
- "debug host", "run on host", "direct debug"
- "serial log", "serial port", "serial capture", "com port", "serial console", "serial output"
- "unlock", "unlocked", "isunlocked", "is unlocked"
- "patch2", "patch3", "patch23", "check patch", "debug mode", "sv_global_enable", "pic_cr_debug_modes"
- "pci scan", "pcie scan", "pci tree", "pci device", "pci config", "config space", "bus scan", "enumerate pci", "find device", "vendor id", "device id", "kfir", "pci bridge", "BDF", "CF8", "CFC"

## Architecture

```
Debug Host (this machine)
├── debug_actions/
│   ├── ttk_operations.py        — TTK POST code reading
│   ├── pci_operations.py        — PCI config space scan & read via dport (IO CF8/CFC)
│   ├── pythonsv_operations.py   — DCI memory read/write, F6 check via namednodes
│   ├── xmlcli_operations.py     — BIOS knob & microcode queries (bridge over XmlCliHelper)
│   ├── xmon_operations.py       — xMon commands & GBT download (bridge over XMonHelper)
│   ├── serial_operations.py     — Serial log capture, classification, F6 wait
│   ├── merlinx/                 — MerlinX debug tool scripts
│   │   ├── find_merlinx_base.py — Locate MerlinX.efi PE image in physical memory
│   │   ├── vsmb.py              — VSMB signature constants & table parsing
│   │   ├── host_interface.py    — DCI host interface detection (emb1/emb2)
│   │   ├── gen_platcap.py       — PlatformConfig.xml (GBT) download via DCI
│   │   ├── check_f6.py          — F6 boot status check (TTK or DCI)
│   │   └── merlinx_version.py   — MerlinX firmware version reading
│   └── helpers/
│       ├── TTKControl.py        — TTK2/TTK3 power control and POST code interface
│       ├── XmlCliHelper.py      — BIOS knob and microcode queries
│       ├── XMonHelper.py        — xMon client, platform interface, GBT via xMon
│       ├── SerialHelper.py      — Serial port communication, log capture & classification
│       └── Utilities.py         — Path helpers, DMA detection, platcap validation
└── Hardware connection (DCI USB / TTK USB / Serial COM) ──► SUT
```

## Tool Selection: Use the Lightest Tool for the Job

PythonSV initialization takes **60–90+ seconds**. Before reaching for PythonSV, check whether a lighter tool can answer the question:

| Task | Use This (fast) | NOT This (slow) |
|---|---|---|
| Detect host interface type | **XmlCli** `get_knob_value("CpuSvBootMode")` — maps directly to interface (0x02=Kfir/PCIe, 0x04=DCI/JTAG) | ~~PythonSV `get_dci_host_interface()`~~ |
| Read BIOS knob values | **XmlCli** `get_knob_value()` | ~~PythonSV + manual register reads~~ |
| Read POST code | **TTK** `get_postcode()` | ~~PythonSV emb0 read~~ |
| Download PlatformConfig.xml | **XMon** `gen_platcap_via_xmon()` | ~~PythonSV `gen_platcap_via_dci()`~~ (use DCI only if xMon unavailable) |
| BIOS version / microcode | **XmlCli** `get_bios_version()` / `get_ucode_versions()` | ~~PythonSV MSR reads~~ |

**Only use PythonSV when the task genuinely requires it:**
- DCI DMA memory reads/writes (`read_memory`, `write_memory`)
- CPU register reads/writes (`read_cpu_register`, `read_cpu_registers`)
- PCI config space scans (`scan_pci_bus`, `scan_pci_tree`, `find_device_by_id`)
- Disassembly (`read_asm_instructions`)
- BSP identification (`find_bsp`)
- Unlock / patch2/patch3 checks (`is_unlocked`, `check_patch23`)
- F6 check via DCI when TTK is unavailable (`check_f6_via_dci`)
- MerlinX base address search (`find_merlinx_base`)

> **Rule: Do NOT start the PythonSV REPL until you have confirmed the task requires a PythonSV-only operation.** If XMon, XmlCli, or TTK can answer the question, use them instead.

## Use Existing Scripts Before Writing Custom Ones

**Always check `debug_actions/` for an existing script that covers the task before writing a new one.** The existing scripts are battle-tested with proper error handling (e.g., `BaseException` for PythonSV teardown), checkpointed `write_result()` calls for partial progress capture, and additional features like MAP file symbol resolution.

| Task | Existing Script | Output File |
|---|---|---|
| Find current execution location (RIP + source symbol) | `find_current_execution.py` | `current_execution_result.txt` |
| Find MerlinX.efi base address | `merlinx/find_merlinx_base.py` | (returns dict) |
| Check F6 boot status | `merlinx/check_f6.py` | (returns value) |
| Download PlatformConfig.xml via DCI | `merlinx/gen_platcap.py` | (saves XML file) |
| Read MerlinX version | `merlinx/merlinx_version.py` | (returns dict) |

> **Rule: Only create a custom script when no existing script covers the specific need.** Duplicating logic (e.g., BSP finding, register reading, disassembly) that already exists in `find_current_execution.py` wastes time and misses features like symbol resolution.

## Session Initialization (PythonSV Operations Only)

`sv.refresh()` and `ipccli.baseaccess()` are extremely slow to initialize, so they must only run once per session. **Before the first PythonSV operation** in a conversation, launch a persistent Python REPL as a background terminal:

```
cd <skill_dir>/debug_actions
python -i -c "from pythonsv_operations import *; print('PythonSV session ready. itp/sv loaded.')"
```

- Run with `isBackground=true` so it stays alive across multiple tool calls.
- Wait for the `PythonSV session ready.` message before sending any commands.
- For all subsequent PythonSV operations, send commands to this existing REPL terminal instead of spawning new `python -c` processes.
- If the REPL terminal is no longer available (e.g., after VS Code restart), re-launch it before proceeding.
- **Only start this REPL when a PythonSV operation is actually needed.** TTK-only or XMon-only operations do not require it.

**Do NOT** run `python -c "..."` one-shot commands for PythonSV operations — each invocation re-runs `sv.refresh()` and wastes significant time.

### Critical: PythonSV Terminal Pitfalls

PythonSV initialization produces **100+ lines** of verbose diagnostic output (TAP detection, collateral loading, FSM enums, MBIST/Scandump nodes, etc.). This creates several terminal interaction problems that **must** be avoided:

#### 1. NEVER use inline multi-line `python -c "..."` for PythonSV scripts

PowerShell's PSReadLine crashes with `ArgumentOutOfRangeException` ("value must be greater than zero and less than the console's buffer size") when a multi-line `python -c` command exceeds the terminal buffer. This is a hard crash — the command never executes.

**Instead:** Write the script to a `.py` file and run `python script.py`.

#### 2. NEVER run multiple PythonSV instances concurrently

PythonSV uses RocksDB for namednodes collateral, which acquires exclusive file locks. A second PythonSV instance will deadlock on `filelock.acquire()` with a `KeyboardInterrupt` — it will never initialize.

**Rule:** Kill ALL existing PythonSV terminals/processes before starting a new one. Only one PythonSV session may exist at a time.

#### 3. PythonSV init output WILL truncate your results

The 100+ lines of init output (TAP detection, collateral warnings, etc.) consume the terminal's captured output buffer. If you `print()` results after init, they may be invisible due to truncation.

**Instead:** Write results to a **file** and read the file afterward. Example pattern:

```python
RESULT_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'result.txt')
# ... do work, collect lines ...
with open(RESULT_FILE, 'w') as f:
    f.write('\n'.join(lines))
```

#### 4. Background terminals start in the WORKSPACE ROOT, not `debug_actions/`

Running `isBackground=true` spawns a new shell with CWD set to the workspace folder. `from pythonsv_operations import ...` will fail with `ModuleNotFoundError` unless you `cd` to `debug_actions/` first in the same command.

**Always** prefix with: `cd <skill_dir>/debug_actions; python ...`

#### 5. Recommended pattern for PythonSV one-shot operations

```python
# save as debug_actions/my_task.py
import os, traceback
RESULT_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'my_task_result.txt')
try:
    from pythonsv_operations import itp  # triggers 60-90s init
    lines = []
    itp.halt()
    # ... do reads ...
    itp.go()
except Exception as e:
    lines = [f'ERROR: {e}', traceback.format_exc()]
with open(RESULT_FILE, 'w') as f:
    f.write('\n'.join(lines))
```

Then run: `cd <skill_dir>/debug_actions; python my_task.py`
Then read: the result file for clean output.

#### 6. PythonSV init warnings are NORMAL — do not treat as errors

The following are expected on every init and should be ignored:
- `some atomcore options are missing in pysv_config.ini`
- `Cannot find pcuram/dmuram collateral`
- `Cannot find VISA collateral`
- `Failed to load CDIE Coresight registers`
- `Failed to load SOC enums` / `Enum load failed!`
- `Couldn't add compute0.taps.coreN tap_name`
- `You are adding to a component something that already has a parent`
- `Found N TAP devices. Cannot find M devices`

These are collateral-version mismatches and optional features — PythonSV is still fully functional for DCI debug.

#### 7. Threading cleanup error on exit is harmless

After a PythonSV script finishes, you may see:
```
Exception ignored in: <module 'threading' from '...'>
KeyboardInterrupt
```
This is a normal teardown race in PythonSV's background threads — the script completed successfully.

## Available Operations

### TTK Operations (`debug_actions/ttk_operations.py`)

| Function | Description |
|---|---|
| `get_postcode()` | Read the current POST code from Port 80 via TTK |

The underlying `TTKControl` class also provides:

| Method | Description |
|---|---|
| `power_on()` | Turn on all TTK power ports |
| `power_off()` | Turn off all TTK power ports |
| `port80_get_postcode()` | Low-level Port 80 read (TTK2 or TTK3 auto-detected) |
| `detect_ttk_version()` | Auto-detect whether TTK2 or TTK3 hardware is connected |

### Serial Operations (`debug_actions/serial_operations.py`)

| Function | Description |
|---|---|
| `list_serial_ports()` | List available COM ports on the debug host |
| `capture_serial_log(port, duration, baudrate, filepath)` | Capture serial console output to a file for a given duration |
| `wait_for_f6(port, timeout, baudrate)` | Monitor serial output until MerlinX boots to F6 |
| `parse_serial_log(filepath)` | Parse a log file into BIOS vs MerlinX sections |
| `get_last_postcode_from_log(filepath)` | Extract the last POST code from a serial log |
| `classify_log_line(line)` | Classify a single line as 'BIOS', 'MerlinX', or 'Unknown' |
| `send_serial_command(port, command, wait, baudrate)` | Send a CLI command to the serial console and return the response |

The underlying `SerialHelper` class (`helpers/SerialHelper.py`) also provides:

| Method | Description |
|---|---|
| `open()` / `close()` | Open/close the serial port connection |
| `read_line()` | Read a single line from serial |
| `read_until_marker(marker, timeout)` | Read until a specific string appears |
| `start_background_capture(filepath)` | Start a background thread capturing to file |
| `stop_background_capture()` | Stop the background capture thread |
| `send(data)` | Send raw data to the serial port |
| `send_command(command, wait, flush_first)` | Send a CLI command, wait for response, return decoded text |

### PythonSV Operations (`debug_actions/pythonsv_operations.py`)

| Function | Description |
|---|---|
| `check_f6_via_dci()` | Read `sv.pch0.exi.exi.emb0` to check if F6 is reached |
| `read_memory(address, size)` | Read `size` bytes from physical `address` via DCI DMA, returned as hex string |
| `write_memory(address, size, value)` | Write `value` to physical `address` via DCI DMA, returns readback |
| `find_bsp()` | Identify the BSP (Boot Strap Processor) core by reading `IA32_APIC_BASE` MSR (0x1B) bit 8 on each thread. Halts target, scans all threads, resumes. Returns dict with `thread_index`, `thread`, `apic_base_msr` |
| `is_unlocked()` | Check whether the SUT is unlocked via `itp.isunlocked()`. Returns `True` if unlocked, `False` otherwise |
| `read_cpu_registers(thread_index)` | Read all CPU registers for the given thread via `itp.threads[thread_index].regs()`. Halts target, reads registers, resumes. Returns string of register values. **NOTE:** Output uses 32-bit names (`eip`, `eax`, `esp`) even in long mode |
| `read_cpu_register(register_name, thread_index)` | Read a single CPU register by parsing `regs()` output. Accepts both 32-bit and 64-bit names (`rip` matches `eip`, `rax` matches `eax`). Halts target, reads register, resumes. Returns dict `{name: hex_value}` |
| `read_asm_instructions(address, count, thread_index)` | Disassemble `count` instructions at `address` using `itp.threads[thread_index].asm()`. Halts target, reads instructions, resumes. Returns disassembly string |
| `read_microcode_version(thread_index)` | Read microcode version from `IA32_BIOS_SIGN_ID` (MSR 0x8B). Halts target, reads MSR, resumes. Returns dict with `version`, `is_debug`, and `raw_msr` |
| `check_patch23()` | Check patch2/patch3 debug mode status by searching for `sv_global_enable` nodes under `sv.socket0` with `pic_cr_debug_modes`. Returns `"enabled"`, `"disabled"`, `"not_found"`, or `None` |

### PCI Operations (`debug_actions/pci_operations.py`)

Scans the SUT's PCI config space via `itp.threads[0].dport()` (IO ports CF8/CFC over DCI). All functions halt the target before scanning and resume afterward.

| Function | Description |
|---|---|
| `scan_pci_bus(start_bus, end_bus)` | Scan a range of PCI buses (default 0–5). Returns list of device dicts with BDF, VID:DID, class code, bridge info, etc. |
| `scan_pci_tree()` | Recursively scan the full PCI hierarchy starting at bus 0, following all bridges. Returns all devices found. |
| `read_pci_config(bus, dev, func, offset)` | Read a single 32-bit PCI config register. Returns `{bdf, offset, value}`. |
| `find_device_by_id(vendor_id, device_id, start_bus, end_bus)` | Search for devices by vendor ID and optional device ID across a bus range (default 0–255). Returns matching devices. |
| `get_pci_bridges(start_bus, end_bus)` | Find all PCI-to-PCI bridges and their secondary/subordinate bus assignments. |
| `pci_config_read(bus, dev, func, offset)` | Low-level: read 32-bit config register (no halt/go, caller must manage). |
| `pci_config_write(bus, dev, func, offset, value)` | Low-level: write 32-bit config register with readback (no halt/go, caller must manage). |

**Note:** Uses `dport()` (not `port()`) to access the SUT's IO space. `port()` accesses the debug host's IO space.

### MerlinX Tools (`debug_actions/merlinx/`)

| Module | Function | Description |
|---|---|---|
| `vsmb.py` | `get_vsmb_table()` | Parse the Validation Shared Mailbox (VSMB) signature table |
| `vsmb.py` | `get_address_from_signature(vsmb_table, sig)` | Look up a buffer address by its VSMB signature constant |
| `host_interface.py` | `get_dci_host_interface()` | Detect the DCI host interface and read emb1/emb2 registers |
| `gen_platcap.py` | `gen_platcap_via_dci()` | Download PlatformConfig.xml (GBT) from the SUT via DCI |
| `check_f6.py` | `check_f6()` | Check F6 status using TTK POST code or DCI emb0 register |
| `merlinx_version.py` | `get_merlinx_version()` | Read the MerlinX firmware version from the BIOS info buffer |
| `find_merlinx_base.py` | `find_merlinx_base()` | Locate MerlinX.efi PE image base address in physical memory. Returns dict with `base`, `size_of_image`, `image_end`, `vsmb_base`, `bios_api_addr` |

### XmlCli Operations (`debug_actions/xmlcli_operations.py`)

| Function | Description |
|---|---|
| `get_bios_version()` | Return the BIOS version string from the knobs XML |
| `get_knob_value(knob_name)` | Read a specific BIOS knob's current value |
| `check_knob_values(expected)` | Verify a dict of `{knob: value}` matches actual values |
| `get_ucode_versions()` | Return a dict of `{CpuId: ucode_version}` |

The underlying `XmlCliHelper` class (`helpers/XmlCliHelper.py`) is instantiated once at import time and cached. The expensive `itp.halt()` / XmlCli enable check / XML parse cycle runs only once per session.

> **IMPORTANT — Hidden Knobs & `EnableTestMenu`:**
> Some BIOS knobs (e.g., `CpuSvBootMode`) are **hidden/test knobs** that only appear
> in Knobs.xml when `EnableTestMenu=0x1` is set. If `EnableTestMenu` is 0x0 (default),
> these knobs will be missing from the XML and `get_knob_value()` will raise `KeyError`.
> Always check `get_knob_value("EnableTestMenu")` first.

### XMon Operations (`debug_actions/xmon_operations.py`)

The `XMON_PACKAGE` environment variable controls the project package name (defaults to `"arrowlake"`).

| Function | Description |
|---|---|
| `send_command(command)` | Send a command string to xMon and return `(status, message)` |
| `get_host_interface()` | Auto-detect platform interface (KFIR, DCI, JTAG, etc.) |
| `gen_platcap_via_xmon()` | Download GBT via xMon's `get_gbt_str` command |
| `is_viewpt_exist()` | Check if a target viewpoint is configured |
| `is_xmon_ready()` | Ping the xMon server to verify the connection is alive |

The underlying `XMonHelper` class (`helpers/XMonHelper.py`) auto-initializes the xMon client and connects to the server on first use.

## VSMB Signature Constants

The Validation Shared Mailbox uses these signatures to locate runtime buffers:

| Signature | Value | Buffer |
|---|---|---|
| `VSMB_SIG_SHARED_MAILBOX` | `0xBA5EBA11` | Mailbox base |
| `VSMB_SIG_BIOS_INFO` | `0x5A7ECAFE` | BIOS information |
| `VSMB_SIG_BIOS_API` | `0x3554A458` | BIOS API table |
| `VSMB_SIG_PCXML_BUFFER` | `0x61C04F1C` | PlatformConfig.xml |
| `VSMB_SIG_CLI_REQ_BUFFER` | `0xCA11AB1E` | CLI request buffer |
| `VSMB_SIG_CLI_RSP_BUFFER` | `0xCA11B0B0` | CLI response buffer |
| `VSMB_SIG_CLI_OBJ_BUFFER` | `0x0B76A6EA` | CLI object buffer |
| `VSMB_SIG_END_OF_TABLE` | `0xDEADBEA7` | End marker |

## Workflow: Common Debug Sequences

### Check Boot Status

```
1. get_postcode()              — Read POST code via TTK
2. check_f6_via_dci()          — Verify emb0 register shows F6
3. If not F6, report the POST code and suggest investigation
```

### Download PlatformConfig.xml

```
1. Verify F6 status first (is_f6)
2. gen_platcap_via_dci()       — Uses VSMB to locate GBT buffer, saves via DMA
   OR gen_platcap_via_xmon()   — Uses xMon get_gbt_str command
3. Validate the generated file contains <SYSTEM> element
```

### Inspect BIOS Configuration

```
1. get_bios_version()                  — Read BIOS version (auto-generates XML on first call)
2. get_knob_value("EnableTestMenu")    — Check if test/hidden knobs are visible (must be 0x1)
3. get_knob_value("KnobName")          — Query individual knob values
   NOTE: CpuSvBootMode and other hidden knobs only exist when EnableTestMenu=0x1.
4. get_ucode_versions()                — Check microcode patch levels
```

### Power Cycle the SUT

```
1. TTKControl.power_off()      — Cut power to all TTK ports
2. (wait)
3. TTKControl.power_on()       — Restore power to all TTK ports
4. Monitor POST codes to confirm boot progress
```

### Scan PCI Devices

> **IMPORTANT — Desktop Client (Meteor Lake and later):**
> `scan_pci_tree()` follows PCI-to-PCI bridges from bus 0, but on all desktop
> client platforms from Meteor Lake onward (MTL, ARL-S, PTL, etc.), **bus 0x80
> (IOE die / PCH bus) is NOT behind any Type 1 bridge on bus 0**. BIOS assigns
> it directly via IOE internal routing. You MUST also scan bus 0x80 explicitly
> to find PCH devices (USB, SATA, HDA, SMBus, Ethernet, I2C, CSME HECI, etc.).

```
1. scan_pci_tree()             — Recursively enumerate all PCI devices, following bridges
   + scan_pci_bus(0x80, 0x80)  — ALSO scan IOE/PCH bus on desktop client (MTL+)
   OR scan_pci_bus(0, 5)       — Scan specific bus range
2. find_device_by_id(0x8086)   — Search for devices by vendor/device ID
3. get_pci_bridges()           — List all bridges and their secondary/subordinate buses
4. read_pci_config(bus, dev, func, offset) — Read individual config registers
```

### Read/Write Memory

```
1. read_memory(address, size)  — DCI DMA read, returns hex string
2. write_memory(address, size, value) — DCI DMA write with readback verification
```

### Find MerlinX.efi Base Address

```
1. Read emb1/emb2 registers   — Obtain the VSMB base address
2. Walk the VSMB table         — Locate the BIOS_API entry (signature 0x3554A458)
3. Extract code pointers       — Read 32-bit function pointers from the BIOS_API table
4. Bulk DMA read (8 MB)        — Read physical memory around the first valid pointer
5. Scan for PE header          — Check page-aligned offsets for MZ + PE\0\0 signature
6. Verify containment          — Return the PE image whose range includes the pointer
```

**Script:** `debug_actions/merlinx/find_merlinx_base.py`

```python
from merlinx.find_merlinx_base import find_merlinx_base
info = find_merlinx_base()
print(f"MerlinX.efi base = 0x{info['base']:08X}")
print(f"SizeOfImage      = 0x{info['size_of_image']:X}")
print(f"Image range      = 0x{info['base']:08X} – 0x{info['image_end']:08X}")
```

## Verification Requirements

> **CRITICAL: Never state a root cause without live SUT verification.**
> For CPU exceptions: ALWAYS disassemble at faulting RIP first.
> Read relevant MSRs/CRs to confirm the CPU state that caused the fault.
> Do NOT conclude root cause from register dumps or log patterns alone —
> pattern matching picks common causes; verification finds the actual one.
> If the SUT is unavailable, clearly label the analysis as a "hypothesis" and list
> the verification steps that are needed before it can be confirmed.

### Scenario: Find Current Execution Location (EIP/RIP to Source Code)

Determines exactly where in the source code the SUT is currently executing. Uses MAP files from the build output to resolve addresses to function names and source files.

```
1. itp.halt()                    — Halt all CPU threads
2. find_bsp()                    — Identify BSP via IA32_APIC_BASE MSR bit 8
3. itp.threads[bsp].regs()       — Read registers (NOTE: returns eip not rip, even in long mode)
4. Parse eip/rip from regs output
5. Read emb1/emb2                — Get VSMB base address
6. Walk VSMB table               — Find BIOS_API entry (sig 0x3554A458)
7. Extract code pointers          — Read 32-bit function pointers from BIOS_API
8. DMA scan for PE images         — 8 MB scan around first code pointer
9. Match EIP to PE image range    — Determine which module contains the EIP
10. Parse MAP file                — Binary search for nearest symbol at/before the RVA
11. itp.go()                     — Resume execution
```

MAP files are located at: `Build/DEBUG_VS2019/X64/<Module>/<Module>/DEBUG/<Module>.map`

Available modules: MerlinX, ulx, ValSharedMailbox, vsmb, Shell, XmlWriter

**Normal F6 idle state:** When MerlinX is at F6 waiting for commands, the BSP will be inside `WaitForCommand()` in `CommandLineInterfaceLib/CliMain.c` — a `while(1)` loop polling the CLI request buffer. This is **not** a hang; it is the expected idle behavior.

**Script:** `debug_actions/find_current_execution.py` (writes results to `current_execution_result.txt`)

### Scenario: SUT Stuck at Unknown POST Code

1. `get_postcode()` — read current POST code via TTK
2. `check_f6_via_dci()` — check whether F6 was reached
3. If F6 reached: `gen_platcap_via_dci()` — download GBT to check platform state
4. The POST code should be mapped to a boot flow phase to suggest next steps

### Scenario: Validate BIOS API Table

1. `check_f6_via_dci()` — confirm system reached F6
2. Read VSMB to locate BIOS API buffer (`get_address_from_signature(VSMB_SIG_BIOS_API)`)
3. `read_memory(api_addr, size)` — dump the API table
4. The table structure should be verified against the BIOS API specification

### Scenario: Verify CPU Topology in PlatformConfig.xml

1. `gen_platcap_via_dci()` or `gen_platcap_via_xmon()` — download GBT
2. The `<PackageCoreThread>` elements should be compared against expected topology from the `pcxml_PackageCoreThreadElement.wsd` sequence diagram

### Scenario: Full System Health Check

1. `get_postcode()` — confirm POST code progress
2. `check_f6_via_dci()` — confirm F6
3. `XmlCliHelper.get_bios_version_from_xml()` — verify BIOS version
4. `XmlCliHelper.get_ucode_versions_from_xml()` — check microcode levels
5. `gen_platcap_via_dci()` — download and validate GBT contains `<SYSTEM>` element
6. Report summary of system state

For detailed case studies with real debug output, see the `examples/` folder.

| Case Study | File |
|---|---|
| ULX #UD on patch2/patch3 opcodes (ARL-S A0) | [examples/ulx-patch-opcode-ud.md](examples/ulx-patch-opcode-ud.md) |
| FAKED_INIT #GP during ResetApicControllerPatch2 (patch3 unlock) | [examples/ulx-patch-opcode-ud.md](examples/ulx-patch-opcode-ud.md) |

## Prerequisites

This skill expects to run on a debug host with:

- **TTK2 or TTK3** hardware connected via USB, with APIs at `C:\SVSHARE\user_apps\TTK2` or `TTK3`
- **PythonSV** environment with `ipccli` and `namednodes` packages available
- **DCI** connection to the SUT (USB DMA)
- **XMon** installed at `C:\Program Files\Intel\XMon` (for xMon operations)
- **XmlCli** Python package (for BIOS knob operations)
- **pyserial** Python package (for serial port operations — `pip install pyserial`)

## Important Notes

- All operations run **locally on the debug host** — there is no remote server/client protocol involved.
- `itp.halt()` / `itp.go()` are used by some operations (XmlCli, memory reads via mem path). Be aware that halting the SUT temporarily freezes execution on the target.
- DMA-based operations (`dci_usb_dma0`) do not require halting the SUT and are preferred when available.
- TTK version is auto-detected; TTK2 and TTK3 APIs differ slightly but are abstracted by `TTKControl`.
- PlatformConfig.xml validity is checked by searching for the `<SYSTEM>` element in the downloaded file.

## Operational Notes: PythonSV Pitfalls

### API Gotchas (Verified on Arrow Lake / PythonSV 4.25)

| What | Reality | Workaround |
|---|---|---|
| `itp.devs[str(thread)]` | **Fails** — `itp.devs` requires **integer index**, not string | Use `itp.threads[idx]` methods directly |
| `itp.devs[idx].arch_register()` | **Fails** — returns `MTP_ICC_Node` which has no `arch_register` | Use `itp.threads[idx].regs()` + parse output |
| `itp.threads[idx].ip` | **Fails** — `ARL_Node` has no `.ip` attribute | Use `regs()` and parse for `eip=` or `rip=` |
| `regs()` register names | Returns **32-bit names** (`eip`, `eax`, `esp`) even in 64-bit CS=0x38 mode | Always match both `eip` and `rip` when parsing |
| `sys.exit()` in `try/except BaseException` | `SystemExit` inherits from `BaseException` and gets caught | Avoid `sys.exit()` in PythonSV scripts; use return + file write instead |

### Reinitialization Cost

Every `python -c "..."` one-shot command re-runs `sv.refresh()` and `ipccli.baseaccess()`, which takes **60–90+ seconds** of collateral loading. Always prefer the persistent REPL approach described in "Session Initialization" above. If the REPL is not usable for a particular task (e.g., output capture is unreliable), write a standalone `.py` script that saves results to a file, then read the file afterward.

### Timeout Guidance

PythonSV operations are slow. Use these minimum timeouts:

| Operation | Recommended Timeout |
|---|---|
| Script with PythonSV init (`sv.refresh()`) | **180–300 seconds** |
| `find_bsp()` (halts all threads, scans MSRs) | **120 seconds** (after init) |
| `read_cpu_register()` / `read_cpu_registers()` | **60 seconds** (after init) |
| DMA read/write | **30 seconds** (after init) |
| TTK-only operations (POST code, power) | **30 seconds** |

When running a one-shot script that includes PythonSV init, use `timeout=300000` (5 min) to avoid premature termination.

### Output Verbosity and Truncation

PythonSV initialization produces **150+ lines** of collateral loading messages (TAP detection, fuse definitions, MBIST nodes, etc.). This frequently causes terminal output to be **truncated**, hiding the actual results at the end.

**Workarounds** (in order of preference):

1. **Persistent REPL** — Init noise only appears once; subsequent commands produce clean output.
2. **Write results to a file** — Have the script write to a `_tmp_result.txt` file, then read it separately:
   ```python
   with open('_tmp_result.txt', 'w') as f:
       f.write(f"RIP: {hex(value)}\n")
   ```
3. **Background execution with file capture** — Run as `isBackground=true` with stdout/stderr redirected to files, then poll for completion:
   ```
   python script.py >_tmp_stdout.txt 2>_tmp_stderr.txt; echo "DONE" >> _tmp_stdout.txt
   ```
   Check completion with `Select-String "DONE" "_tmp_stdout.txt"`, then read results.

**Always clean up** temporary files (`_tmp_*.txt`, `_tmp_*.py`) after reading results.
