"""
Simplified script to find current SUT execution location.
Writes results to a file since PythonSV init floods stdout.
Uses BaseException to catch PythonSV KeyboardInterrupt on exit.
"""
import os
import sys
import struct
import re
import traceback

RESULT_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'current_execution_result.txt')
BUILD_DIR = os.path.normpath(os.path.join(
    os.path.dirname(os.path.abspath(__file__)),
    '..', '..', '..', '..', 'MerlinX', 'MerlinX', 'Build', 'DEBUG_VS2019', 'X64'
))

MAP_FILES = {
    'MerlinX': os.path.join(BUILD_DIR, 'MerlinX', 'MerlinX', 'DEBUG', 'MerlinX.map'),
    'ulx': os.path.join(BUILD_DIR, 'ulx', 'ulx', 'DEBUG', 'ulx.map'),
    'ValSharedMailbox': os.path.join(BUILD_DIR, 'ValSharedMailbox', 'ValSharedMailbox', 'DEBUG', 'ValSharedMailbox.map'),
    'Shell': os.path.join(BUILD_DIR, 'ShellPkg', 'Application', 'Shell', 'Shell', 'DEBUG', 'Shell.map'),
}

VSMB_SIG_BIOS_API = 0x3554A458
VSMB_TABLE_SIZE = 0xA0
BIOS_API_READ_SIZE = 256
PAGE_SIZE = 0x1000
PE_SIG = 0x00004550
PTR_LOW = 0x01000000
PTR_HIGH = 0x80000000
SCAN_RANGE = 8 * 1024 * 1024


def write_result(text):
    with open(RESULT_FILE, 'w') as f:
        f.write(text)


def parse_map_file(map_path):
    symbols = []
    if not os.path.exists(map_path):
        return symbols
    pattern = re.compile(
        r'^\s*[0-9a-fA-F]+:[0-9a-fA-F]+\s+(\S+)\s+([0-9a-fA-F]+)\s+[f ]?\s*(.*)$'
    )
    with open(map_path, 'r') as f:
        for line in f:
            m = pattern.match(line)
            if m:
                rva = int(m.group(2), 16)
                if rva > 0:
                    symbols.append((rva, m.group(1), m.group(3).strip()))
    symbols.sort(key=lambda x: x[0])
    return symbols


def lookup_symbol(symbols, rva):
    lo, hi = 0, len(symbols) - 1
    result = None
    while lo <= hi:
        mid = (lo + hi) // 2
        if symbols[mid][0] <= rva:
            result = symbols[mid]
            lo = mid + 1
        else:
            hi = mid - 1
    return result


lines = []

try:
    lines.append("=== Step 1: Import PythonSV ===")
    write_result('\n'.join(lines))  # checkpoint

    import ipccli
    from namednodes import sv
    itp = ipccli.baseaccess()
    try:
        _ = sv.pch0
    except BaseException:
        sv.refresh()
    lines.append("PythonSV initialized OK")
    write_result('\n'.join(lines))  # checkpoint

    # Step 2: Halt and find BSP
    lines.append("")
    lines.append("=== Step 2: Halt CPU and find BSP ===")
    itp.halt()
    lines.append("CPU halted")
    write_result('\n'.join(lines))  # checkpoint

    bsp_idx = None
    IA32_APIC_BASE = 0x1B
    BSP_FLAG = 1 << 8
    for i, thread in enumerate(itp.threads):
        try:
            apic_base = thread.msr(IA32_APIC_BASE)
            if apic_base & BSP_FLAG:
                bsp_idx = i
                lines.append(f"BSP = thread[{i}] = {thread}")
                break
        except BaseException as e:
            lines.append(f"  thread[{i}] MSR read failed: {e}")

    if bsp_idx is None:
        lines.append("ERROR: Could not find BSP")
        itp.go()
        write_result('\n'.join(lines))
        # Don't sys.exit — write result and stop

    write_result('\n'.join(lines))  # checkpoint

    # Step 3: Read RIP
    lines.append("")
    lines.append("=== Step 3: Read RIP from BSP ===")
    rip = None

    # Method A: regs() + parse (handles both rip and eip)
    try:
        regs = str(itp.threads[bsp_idx].regs())
        lines.append(f"regs() output:\n{regs}")
        for rline in regs.split('\n'):
            # Match rip=xxx or eip=xxx
            match = re.search(r'(?:r|e)ip\s*[=:]\s*(?:0x)?([0-9a-fA-F]+)', rline, re.IGNORECASE)
            if match:
                rip = int(match.group(1), 16)
                break
    except BaseException as e:
        lines.append(f"regs() failed: {e}")
        lines.append(traceback.format_exc())

    # Method C: devs[int_index]
    if rip is None:
        try:
            dev = itp.devs[bsp_idx]
            rip = int(dev.arch_register('rip'))
            lines.append(f"devs[{bsp_idx}].arch_register = 0x{rip:016X}")
        except BaseException as e:
            lines.append(f"devs[{bsp_idx}] failed: {e}")

    write_result('\n'.join(lines))  # checkpoint

    if rip is None:
        lines.append("ERROR: Could not read RIP/EIP from any method")
        itp.go()
        write_result('\n'.join(lines))
        # Don't sys.exit — write result and return

    lines.append(f"")
    lines.append(f">>> RIP = 0x{rip:016X}")

    # Step 4: Disassemble at RIP
    lines.append("")
    lines.append("=== Step 4: Disassembly at RIP ===")
    try:
        asm = itp.threads[bsp_idx].asm(hex(rip), 10)
        lines.append(str(asm))
    except BaseException as e:
        lines.append(f"Disassembly failed: {e}")

    write_result('\n'.join(lines))  # checkpoint

    # Step 5: Read emb registers
    lines.append("")
    lines.append("=== Step 5: EMB registers (VSMB) ===")
    vsmb_base = 0
    try:
        emb0 = int(sv.pch0.exi.exi.emb0)
        emb1 = int(sv.pch0.exi.exi.emb1)
        emb2 = int(sv.pch0.exi.exi.emb2)
        lines.append(f"emb0 = 0x{emb0:08X}")
        lines.append(f"emb1 = 0x{emb1:08X}")
        lines.append(f"emb2 = 0x{emb2:08X}")
        vsmb_base = emb1 if emb1 != 0 else emb2
        lines.append(f"VSMB base = 0x{vsmb_base:08X}")
    except BaseException as e:
        lines.append(f"EMB read failed: {e}")

    write_result('\n'.join(lines))  # checkpoint

    # Step 6: Find PE images and resolve RIP to source
    if vsmb_base != 0:
        lines.append("")
        lines.append("=== Step 6: Module discovery via VSMB ===")
        try:
            dma = itp.devs.dci_usb_dma0
            vsmb_data = dma.dma(f"{vsmb_base}P", VSMB_TABLE_SIZE)

            bios_api_addr = None
            for offset in range(0x20, VSMB_TABLE_SIZE, 0x10):
                sig = struct.unpack_from("<I", vsmb_data, offset)[0]
                addr = struct.unpack_from("<I", vsmb_data, offset + 4)[0]
                if sig == 0xDEADBEA7:
                    break
                if sig == VSMB_SIG_BIOS_API:
                    bios_api_addr = addr
                    lines.append(f"BIOS_API found at 0x{addr:08X}")

            if bios_api_addr:
                api_data = dma.dma(f"{bios_api_addr}P", BIOS_API_READ_SIZE)
                pointers = []
                for i in range(8, len(api_data), 4):
                    val = struct.unpack_from("<I", api_data, i)[0]
                    if PTR_LOW < val < PTR_HIGH and (val & 0x3) == 0:
                        pointers.append(val)

                if pointers:
                    ptr = pointers[0]
                    lines.append(f"First code pointer: 0x{ptr:08X}")
                    scan_start = max(0, (ptr & ~(PAGE_SIZE - 1)) - SCAN_RANGE + PAGE_SIZE)
                    scan_size = (ptr & ~(PAGE_SIZE - 1)) - scan_start + PAGE_SIZE
                    bulk = dma.dma(f"{scan_start}P", scan_size)

                    pe_images = []
                    for off in range(0, len(bulk), PAGE_SIZE):
                        if bulk[off:off+2] != b'MZ':
                            continue
                        e_lfanew = struct.unpack_from("<I", bulk, off + 0x3C)[0]
                        if e_lfanew == 0 or e_lfanew >= PAGE_SIZE:
                            continue
                        if off + e_lfanew + 0x54 > len(bulk):
                            continue
                        pe_sig = struct.unpack_from("<I", bulk, off + e_lfanew)[0]
                        if pe_sig != PE_SIG:
                            continue
                        size_of_image = struct.unpack_from("<I", bulk, off + e_lfanew + 0x50)[0]
                        img_base = scan_start + off
                        pe_images.append((img_base, size_of_image))

                    lines.append(f"Found {len(pe_images)} PE images in scan region")
                    rip_module_base = None
                    for base, size in pe_images:
                        end = base + size
                        contains_rip = base <= rip < end
                        marker = " *** RIP IS HERE ***" if contains_rip else ""
                        lines.append(f"  PE @ 0x{base:08X} - 0x{end:08X} (0x{size:X}){marker}")
                        if contains_rip:
                            rip_module_base = base

                    # Step 7: Symbol resolution
                    lines.append("")
                    lines.append("=== Step 7: Symbol resolution ===")
                    if rip_module_base is not None:
                        rva = rip - rip_module_base
                        lines.append(f"RIP at RVA 0x{rva:X} in module @ 0x{rip_module_base:08X}")

                        for mod_name, map_path in MAP_FILES.items():
                            symbols = parse_map_file(map_path)
                            if not symbols:
                                continue
                            sym = lookup_symbol(symbols, rva)
                            if sym and sym[0] > 0:
                                sym_rva, sym_name, lib_obj = sym
                                offset_in_func = rva - sym_rva
                                if offset_in_func < 0x10000:
                                    lines.append(f"")
                                    lines.append(f"  {mod_name}.map match:")
                                    lines.append(f"    Function: {sym_name}")
                                    lines.append(f"    Symbol RVA: 0x{sym_rva:X}")
                                    lines.append(f"    Offset: +0x{offset_in_func:X}")
                                    lines.append(f"    Source: {lib_obj}")
                                    idx = symbols.index(sym)
                                    if idx > 0:
                                        p = symbols[idx-1]
                                        lines.append(f"    Prev: {p[1]} @ 0x{p[0]:X} [{p[2]}]")
                                    if idx + 1 < len(symbols):
                                        n = symbols[idx+1]
                                        lines.append(f"    Next: {n[1]} @ 0x{n[0]:X} [{n[2]}]")
                    else:
                        lines.append(f"RIP 0x{rip:016X} NOT in any discovered PE image")

        except BaseException as e:
            lines.append(f"Module discovery error: {e}")
            lines.append(traceback.format_exc())

    itp.go()
    lines.append("")
    lines.append("=== Done ===")

except BaseException as e:
    lines.append(f"FATAL: {e}")
    lines.append(traceback.format_exc())
    try:
        itp.go()
    except BaseException:
        pass

write_result('\n'.join(lines))
print("Results written to", RESULT_FILE)
