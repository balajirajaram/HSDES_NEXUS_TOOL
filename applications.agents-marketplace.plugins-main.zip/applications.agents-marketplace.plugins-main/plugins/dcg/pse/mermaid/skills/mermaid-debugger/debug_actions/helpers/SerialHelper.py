__all__ = ["SerialHelper"]

import os
import re
import sys
import time
import logging
import traceback
import threading

try:
    import serial
    import serial.tools.list_ports
except ImportError:
    print("Failed to import pyserial — install with: pip install pyserial")


def _get_serial_output_dir():
    _skill_dir = os.path.dirname(os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..")))
    return os.path.join(_skill_dir, "tmp", "emb", "Output")


# Log classification markers (from log-classification reference)
_MERLINX_BOUNDARY = "MerlinX [info] Start"
_MERLINX_BOOTED = "MerlinX booted to 0xf6"

_BIOS_PATTERNS = [
    re.compile(r"^Serial reg:"),
    re.compile(r"^FSP-[TMS]"),
    re.compile(r"^Loading PEIM"),
    re.compile(r"^Install PPI:"),
    re.compile(r"^Register PPI Notify:"),
    re.compile(r"^PROGRESS CODE:"),
    re.compile(r"^Port80 forward FSP POSTCODE="),
    re.compile(r"^POSTCODE\s*=\s*<"),
    re.compile(r"^MRC task --"),
    re.compile(r"^GREEN MRC task"),
    re.compile(r"^Loading driver at"),
    re.compile(r"^InstallProtocolInterface:"),
    re.compile(r"^TXTPEI::"),
    re.compile(r"^\[HECI"),
    re.compile(r"^\[GPIOV2\]"),
    re.compile(r"^P2SB:"),
    re.compile(r"^SmbusPeiEntryPoint"),
]

_MERLINX_PATTERNS = [
    re.compile(r"^MerlinX \[info\]"),
    re.compile(r"^MerlinX Version"),
    re.compile(r"^\[MerlinXTable\]::"),
    re.compile(r"^\[PlatformConfigMerlinXTable\]::"),
    re.compile(r"^HostInterfaceLib:"),
    re.compile(r"^No Host Interface was selected"),
    re.compile(r"^CleanupLib\(\):"),
    re.compile(r"^MerlinXPlatformDriverEntrypoint"),
    re.compile(r"^InterfaceType = DCI_INTERFACE_TYPE"),
    re.compile(r"^GbtMerlinXVersionElement"),
]


class SerialHelper:
    """
    SerialHelper provides serial port communication for capturing and
    classifying SUT console output.

    Attributes
    ----------
    port : str
        COM port name (e.g. 'COM3').
    baudrate : int
        Baud rate for serial communication.
    timeout : float
        Read timeout in seconds.

    Methods
    -------
    list_ports()
        List available serial/COM ports on the system.
    open()
        Open the serial port connection.
    close()
        Close the serial port connection.
    read_line()
        Read a single line from the serial port.
    read_until_marker(marker, timeout)
        Read lines until a marker string is found or timeout.
    capture_log(duration, filepath)
        Capture serial output to a file for a given duration.
    start_background_capture(filepath)
        Start capturing serial output in a background thread.
    stop_background_capture()
        Stop the background capture thread.
    classify_line(line)
        Classify a log line as 'BIOS', 'MerlinX', or 'Unknown'.
    parse_log(filepath)
        Parse a captured log file and return classified sections.
    get_last_postcode(filepath)
        Extract the last POST code from a captured log file.
    wait_for_f6(timeout)
        Wait for MerlinX to boot to F6 by monitoring serial output.
    """

    DEFAULT_BAUDRATE = 115200
    DEFAULT_TIMEOUT = 1.0

    def __init__(self, port=None, baudrate=DEFAULT_BAUDRATE, timeout=DEFAULT_TIMEOUT):
        self.logger = logging.getLogger(__name__)
        self.port = port
        self.baudrate = baudrate
        self.timeout = timeout
        self._serial = None
        self._capture_thread = None
        self._capture_stop = threading.Event()
        self._output_dir = _get_serial_output_dir()

        if not os.path.exists(self._output_dir):
            os.makedirs(self._output_dir)

    @staticmethod
    def list_ports():
        """List available serial/COM ports on the system.

        Returns
        -------
        list of dict
            Each dict contains 'device', 'description', and 'hwid'.
        """
        ports = serial.tools.list_ports.comports()
        return [{"device": p.device, "description": p.description, "hwid": p.hwid} for p in ports]

    def open(self):
        """Open the serial port connection.

        Returns
        -------
        bool
            True if opened successfully, False otherwise.
        """
        if self._serial and self._serial.is_open:
            self.logger.info(f"[{__name__}] Port {self.port} already open.")
            return True

        if not self.port:
            self.logger.error(f"[{__name__}] No port specified.")
            return False

        try:
            self._serial = serial.Serial(
                port=self.port,
                baudrate=self.baudrate,
                timeout=self.timeout,
                bytesize=serial.EIGHTBITS,
                parity=serial.PARITY_NONE,
                stopbits=serial.STOPBITS_ONE,
            )
            self.logger.info(f"[{__name__}] Opened {self.port} at {self.baudrate} baud.")
            return True
        except serial.SerialException:
            self.logger.error(f"[{__name__}] Failed to open {self.port}.")
            print(traceback.format_exc())
            return False

    def close(self):
        """Close the serial port connection."""
        self.stop_background_capture()
        if self._serial and self._serial.is_open:
            self._serial.close()
            self.logger.info(f"[{__name__}] Closed {self.port}.")

    def read_line(self):
        """Read a single line from the serial port.

        Returns
        -------
        str or None
            Decoded line (stripped), or None on timeout/error.
        """
        if not self._serial or not self._serial.is_open:
            return None
        try:
            raw = self._serial.readline()
            if raw:
                return raw.decode("utf-8", errors="replace").strip()
        except serial.SerialException:
            self.logger.error(f"[{__name__}] Read error on {self.port}.")
            print(traceback.format_exc())
        return None

    def read_until_marker(self, marker, timeout=60):
        """Read lines until a marker string is found or timeout expires.

        Parameters
        ----------
        marker : str
            Substring to search for in each line.
        timeout : float
            Maximum seconds to wait.

        Returns
        -------
        tuple (list of str, bool)
            Lines read and whether the marker was found.
        """
        lines = []
        found = False
        start = time.time()

        while (time.time() - start) < timeout:
            line = self.read_line()
            if line is not None:
                lines.append(line)
                if marker in line:
                    found = True
                    break

        return lines, found

    def capture_log(self, duration=30, filepath=None):
        """Capture serial output to a file for a given duration.

        Parameters
        ----------
        duration : float
            Seconds to capture.
        filepath : str, optional
            Output file path. Defaults to <output_dir>/serial_capture.log.

        Returns
        -------
        str
            Path to the captured log file.
        """
        if filepath is None:
            filepath = os.path.join(self._output_dir, "serial_capture.log")

        lines = []
        start = time.time()

        while (time.time() - start) < duration:
            line = self.read_line()
            if line is not None:
                lines.append(line)

        with open(filepath, "w", encoding="utf-8") as f:
            f.write("\n".join(lines))

        self.logger.info(f"[{__name__}] Captured {len(lines)} lines to {filepath}")
        return filepath

    def start_background_capture(self, filepath=None):
        """Start capturing serial output in a background thread.

        Parameters
        ----------
        filepath : str, optional
            Output file path. Defaults to <output_dir>/serial_capture.log.

        Returns
        -------
        bool
            True if capture started, False if already running or port not open.
        """
        if self._capture_thread and self._capture_thread.is_alive():
            self.logger.warning(f"[{__name__}] Background capture already running.")
            return False

        if not self._serial or not self._serial.is_open:
            self.logger.error(f"[{__name__}] Port not open. Call open() first.")
            return False

        if filepath is None:
            filepath = os.path.join(self._output_dir, "serial_capture.log")

        self._capture_stop.clear()
        self._capture_thread = threading.Thread(
            target=self._background_capture_loop,
            args=(filepath,),
            daemon=True,
        )
        self._capture_thread.start()
        self.logger.info(f"[{__name__}] Background capture started -> {filepath}")
        return True

    def _background_capture_loop(self, filepath):
        with open(filepath, "w", encoding="utf-8") as f:
            while not self._capture_stop.is_set():
                line = self.read_line()
                if line is not None:
                    f.write(line + "\n")
                    f.flush()

    def stop_background_capture(self):
        """Stop the background capture thread.

        Returns
        -------
        bool
            True if stopped, False if not running.
        """
        if not self._capture_thread or not self._capture_thread.is_alive():
            return False

        self._capture_stop.set()
        self._capture_thread.join(timeout=5)
        self.logger.info(f"[{__name__}] Background capture stopped.")
        return True

    @staticmethod
    def classify_line(line):
        """Classify a single log line as BIOS, MerlinX, or Unknown.

        Parameters
        ----------
        line : str
            A single line from a serial log.

        Returns
        -------
        str
            'BIOS', 'MerlinX', or 'Unknown'.
        """
        stripped = line.strip()
        for pattern in _MERLINX_PATTERNS:
            if pattern.search(stripped):
                return "MerlinX"
        for pattern in _BIOS_PATTERNS:
            if pattern.search(stripped):
                return "BIOS"
        return "Unknown"

    @staticmethod
    def parse_log(filepath):
        """Parse a captured log file and return classified sections.

        Parameters
        ----------
        filepath : str
            Path to a serial log file.

        Returns
        -------
        dict
            Keys: 'bios_lines', 'merlinx_lines', 'unknown_lines',
                  'merlinx_boundary_found', 'merlinx_booted'.
        """
        result = {
            "bios_lines": [],
            "merlinx_lines": [],
            "unknown_lines": [],
            "merlinx_boundary_found": False,
            "merlinx_booted": False,
        }

        in_merlinx = False

        with open(filepath, "r", encoding="utf-8", errors="replace") as f:
            for line in f:
                line = line.rstrip("\n")

                if _MERLINX_BOUNDARY in line:
                    in_merlinx = True
                    result["merlinx_boundary_found"] = True

                if _MERLINX_BOOTED in line:
                    result["merlinx_booted"] = True

                if in_merlinx:
                    result["merlinx_lines"].append(line)
                else:
                    classification = SerialHelper.classify_line(line)
                    if classification == "BIOS":
                        result["bios_lines"].append(line)
                    else:
                        result["unknown_lines"].append(line)

        return result

    @staticmethod
    def get_last_postcode(filepath):
        """Extract the last POST code from a captured log file.

        Parameters
        ----------
        filepath : str
            Path to a serial log file.

        Returns
        -------
        str or None
            The last POST code value found, or None.
        """
        postcode_re = re.compile(r"POSTCODE\s*=?\s*<?([0-9A-Fa-f]{4,})>?")
        last = None

        with open(filepath, "r", encoding="utf-8", errors="replace") as f:
            for line in f:
                m = postcode_re.search(line)
                if m:
                    last = m.group(1)

        return last

    def wait_for_f6(self, timeout=300):
        """Wait for MerlinX to boot to F6 by monitoring serial output.

        Parameters
        ----------
        timeout : float
            Maximum seconds to wait for F6. Default 5 minutes.

        Returns
        -------
        tuple (list of str, bool)
            All lines captured and whether F6 was reached.
        """
        return self.read_until_marker(_MERLINX_BOOTED, timeout=timeout)

    def send(self, data):
        """Send raw data to the serial port.

        Parameters
        ----------
        data : str or bytes
            Data to send. Strings are encoded to UTF-8.

        Returns
        -------
        int or None
            Number of bytes written, or None on error.
        """
        if not self._serial or not self._serial.is_open:
            self.logger.error(f"[{__name__}] Port not open.")
            return None

        try:
            if isinstance(data, str):
                data = data.encode("utf-8")
            return self._serial.write(data)
        except serial.SerialException:
            self.logger.error(f"[{__name__}] Write error on {self.port}.")
            print(traceback.format_exc())
            return None

    def send_command(self, command, wait=3.0, flush_first=True):
        """Send a CLI command to the serial console and capture the response.

        Sends an Enter keystroke first to get a prompt, flushes stale data,
        then sends the command and waits for the response.

        Parameters
        ----------
        command : str
            The command to send (e.g. 'memmap', 'smbiosview').
        wait : float
            Seconds to wait for the response after sending the command.
            Default 3.0.
        flush_first : bool
            If True, send an Enter and flush stale input before the command.

        Returns
        -------
        str or None
            Decoded response text, or None on error.
        """
        if not self._serial or not self._serial.is_open:
            self.logger.error(f"[{__name__}] Port not open.")
            return None

        try:
            if flush_first:
                self._serial.write(b"\r\n")
                time.sleep(0.5)
                self._serial.read(self._serial.in_waiting)

            self._serial.write(f"{command}\r\n".encode("utf-8"))
            time.sleep(wait)

            pending = self._serial.in_waiting or 4096
            output = self._serial.read(pending)
            return output.decode("utf-8", errors="replace")
        except serial.SerialException:
            self.logger.error(f"[{__name__}] send_command() error on {self.port}.")
            print(traceback.format_exc())
            return None
