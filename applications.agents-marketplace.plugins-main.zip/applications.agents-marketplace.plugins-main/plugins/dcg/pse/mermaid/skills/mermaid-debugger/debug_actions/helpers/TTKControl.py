import sys
import traceback

try:
    try:
        # import TTK2 API packages
        sys.path.insert(0, r"C:\SVSHARE\user_apps\TTK2")
        sys.path.insert(0, r"C:\SVSHARE\user_apps\TTK2\API\Python")
        # from TTK2_ConfigManager import *
        from TTK2_Port_80 import Port_80
        from TtkDevice import TTK_Device_API
        from TTK2_PowerControl import Power_Control
    except Exception:
        print("Failed to import TTK2 API")

    try:
        # import TTK3 API packages
        sys.path.insert(0, r"C:\SVSHARE\user_apps\TTK3")
        sys.path.insert(0, r"C:\SVSHARE\user_apps\TTK3\API\Python")
        from Port80 import Port80
        from TtkDevice import TTK_Device_API
        from PowerControl import PowerControl
    except Exception:
        print("Failed to import TTK3 API")

except Exception:
    print(traceback.format_exc())
    exit(-1)


class TTKControl:
    def __init__(self):
        #        print("[TTKControl] Init...")
        self.ttkDeviceApi = TTK_Device_API()
        self.ttk_version = self.detect_ttk_version()
        self.pInterface = self.initialize_interface()
        self.isInterfaceOpen = False

    def __getstate__(self):
        state = self.__dict__.copy()
        # Remove the unpicklable entries.
        if "pInterface" in state:
            del state["pInterface"]
        return state

    def __setstate__(self, state):
        self.__dict__.update(state)
        # Recreate the unpicklable entries.
        self.pInterface = self.initialize_interface()

    def detect_ttk_version(self):
        #  TTK2
        if self.ttkDeviceApi.IsTtk2DeviceConnectedAndDriverInstalled():
            return "2"
        # TTK3
        if self.ttkDeviceApi.IsTtk3DeviceConnectedAndDriverInstalled():
            return "3"
        return None

    def initialize_interface(self):
        if self.ttk_version == "2":
            return Power_Control()
        elif self.ttk_version == "3":
            return PowerControl()

    def open_interface(self):
        if not self.isInterfaceOpen:
            self.pInterface.OpenPowerControl()
            self.isInterfaceOpen = True

    def close_interface(self):
        if self.isInterfaceOpen:
            self.pInterface.Close()
            self.isInterfaceOpen = False

    def power_off(self, open_close=True):
        print("Powering off system")

        if open_close:
            self.open_interface()

        numPorts = self.pInterface.GetNumPorts()
        self.pInterface.AllPortsOff()
        states = self.pInterface.GetStateAllPorts()
        print("Port states: ")
        for i in range(0, numPorts):
            print("port " + str(i) + " " + str(states[i]))

        if open_close:
            self.close_interface()

    def power_on(self, open_close=True):
        print("Powering on system")
        if open_close:
            self.open_interface()

        print("Turning on all ports..")
        self.pInterface.AllPortsOn()
        states = self.pInterface.GetStateAllPorts()
        numPorts = self.pInterface.GetNumPorts()

        print("Port states: ")
        for i in range(0, numPorts):
            print("port " + str(i) + " " + str(states[i]))

        if open_close:
            self.close_interface()

    def port80_get_postcode(self):
        try:
            value = None
            if self.ttk_version == "2":
                #                print(
                #                    "TTK2 USB device is connected and driver installed: "
                #                    + str(self.ttkDeviceApi.IsTtk2DeviceConnectedAndDriverInstalled())
                #                )
                port_80_interface = Port_80()
                port_80_interface.OpenPort80Interface()
                p = port_80_interface.Read()
                value = "%x %x" % ((p[0].Result[1]), (p[0].Result[0]))
                #                print("Reading postcode : {} ".format(value))
                port_80_interface.Close()
                return value

            if self.ttk_version == "3":
                #               print(
                #                   "TTK3 USB device is connected and driver installed: "
                #                   + str(self.ttkDeviceApi.IsTtk3DeviceConnectedAndDriverInstalled())
                #               )
                port_80 = Port80()  # TODO study how does port80 works
                port_80.Open()
                value = port_80.Read()  # value = '00F6'
                # value1 = p[:2]
                # value2 = p[-2:]
                #                print("Reading postcode : {}".format(value))
                port_80.Close()
                return value
        except Exception:
            print(traceback.format_exc())

        return value
