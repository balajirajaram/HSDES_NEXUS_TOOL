__all__ = ["XMonHelper"]

import sys
import time
import traceback
import subprocess
import os

try:
    p = subprocess.Popen(
        [
            r"C:\Program Files\Intel\XMon\bin\XMon.exe",
            r"/q",
            r"/s",
            r"C:\Program Files\Intel\XMon\scripts\Contents\All.tcl",
            r"/s",
            r"C:\Program Files\Intel\XMon\scripts\remote\testrunner.tcl",
        ]
    )
except Exception:
    print(traceback.format_exc())
    exit(-1)

HOST_INTERFACE = {
    "KFIR": "$CLSID_CKfir",
    "DISHON": "$CLSID_CNet2280",
    "DCIDMA": "$CLSID_CDCIDMA",
    "DCI": "$CLSID_CDCI",
    "JTAG": "$CLSID_CXDP",
    "DCIGEN4": "$CLSID_CDCIGen4",
}


def _get_emb_output_dir():
    _skill_dir = os.path.dirname(os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..")))
    return os.path.join(_skill_dir, "tmp", "emb", "Output")


def _is_platcap_valid(path):
    try:
        with open(path, "r") as f:
            if "<SYSTEM>" in f.read():
                return True
            else:
                os.remove(path)
    except FileNotFoundError:
        print(f"Error: File not found - {path}")
        return False


class XMonHelper:
    """
    XMonHelper is the base class interact with the XMon client via python.

    Attributes
    ----------
    result_template : str
        The template in which the string returns are expected from this class.
    xmon_install_dir : str
        Directory where xmon is installed on the host.

    Methods
    -------
    initialize_xmon_client
        Import and instantiate the testrunner_client object.
    connect_to_xmon_server
        Connect to the XMonServer.
    is_xmon_ready
        Ping the XMon server to see if the connection is set up.
    disconnect_from_xmon_server
        Disconnect from the XMon server and close the server.
    send_command
        Connects to xmon server, sends a command to Xmon.
    get_host_interface
        Get platform interface with all the possible target commands in xmon.
    gen_platcap_via_xmon
        Generate platform config through Xmon.
    """

    def __init__(self, package):
        self.runner = None
        self.result_template = "Status:{0}, Message:{1}"
        self.xmon_install_dir = r"C:\Program Files\Intel\XMon\scripts\remote"
        self.platcap_path = None
        self.is_xmon_client_initialize = False
        self.is_xmon_server_connected = False
        self.package = package
        self.path = os.path.join(os.getcwd(), "PlatformConfig.xml")
        self.xmon_log_path = os.path.join(_get_emb_output_dir(), "Xmon.log")

        if os.path.exists(self.path):
            os.remove(self.path)

        if not os.path.exists(_get_emb_output_dir()):
            os.makedirs(_get_emb_output_dir())

    def initialize_xmon_client(self):
        """
        Imports the xmon client script from the Xmon installed directory.

        Returns
        -------
        str
            Returns a formatted string with status and message received from the xmon client.
            Returns -1 if the path does not exist or if an exception occurs.
        """
        if not os.path.exists(r"C:\Program Files\Intel\XMon"):
            print("Path : C:\Program Files\Intel\XMon does not exists...exiting")
            return -1
        else:
            if self.xmon_install_dir not in sys.path:
                sys.path.append(self.xmon_install_dir)
            import testrunner_client

            try:
                self.runner = testrunner_client.TestrunnerClient()
                self.is_xmon_client_initialize = True
                return self.result_template.format("0", "")
            except Exception:
                print(traceback.format_exc())
                return -1

    def connect_to_xmon_server(self):
        """
        Set up xmon to prepare for communication.

        Returns
        -------
        str
            Returns a formatted string with status returned from the xmon client
            on executing the command. Returns -1 if an exception occurs.
        """
        try:
            time.sleep(3)
            print("Connecting to XMON server")
            self.runner.connect()
            self.is_xmon_server_connected = True
            return self.result_template.format("0", "")
        except Exception:
            print(traceback.format_exc())
            return -1

    def is_xmon_ready(self):
        """
        Verifies if xmon is ready to accept commands.

        Returns
        -------
        bool
            Returns True if xmon is ready to accept commands, or
            False if the ping command fails.

        Notes
        -----
        is_xmon_ready pings the xmon server and returns True if
        the ping status is successful; otherwise, it returns False.
        """
        try:
            return self.runner.send_command("ping")[0] == 0
        except Exception:
            return False

    def disconnect_from_xmon_server(self):
        """
        Safely close xmon connection and disconnect client.

        Returns
        -------
        str
            Returns a formatted string with status returned from the xmon client
            on executing the command. Returns -1 if an exception occurs.
        """
        try:
            print("Disconnecting from XMON")
            self.runner.disconnect()
            self.is_xmon_server_connected = False
            return self.result_template.format("0", "")
        except Exception:
            print(traceback.format_exc())
            return -1

    def send_command(self, command):
        """
        Connects to the xmon server, sends a command to xmon,
        and returns the result. The xmon log will be saved to a specified file.

        Parameters
        ----------
        command : str
            The command to be sent to the xmon server.

        Returns
        -------
        tuple
            A tuple containing the status and the message returned from the xmon client
            on executing the command. Returns -1 if an exception occurs.
        """
        try:
            # Open log
            self.runner.send_command(f"log open {self.xmon_log_path}")
            xmon_return_value = self.runner.send_command(command)
            # Close log
            self.runner.send_command("log close")
            return xmon_return_value[0], xmon_return_value[1]
        except Exception:
            print("Xmon command {0} execution failed".format(command))
            print(traceback.format_exc())
            return -1

    def is_viewpt_exist(self):
        """
        Checks if the target viewpoint exists by sending a command to the platform.

        If the xmon client is not initialized or the xmon server is not connected,
        it initializes the xmon client and connects to the xmon server before
        sending the viewpt command.

        Returns
        -------
        bool
            True if the viewpt exists (i.e., the command result is not an empty string),
            False otherwise.
        """
        if not (self.is_xmon_client_initialize and self.is_xmon_server_connected):
            self.initialize_xmon_client()
            self.connect_to_xmon_server()

        viewpt_command = "xmon::viewpt set"
        viewpt_result = self.send_command(viewpt_command)

        # returns False if viewpt_result[1] is an empty string (""), otherwise it returns True.
        return viewpt_result[1] != ""

    def get_host_interface(self):
        """
        Get platform interface with all the possible target commands.

        Returns
        -------
        tuple
            Returns platform interface with corresponding target command, or (None, None) if not found.
        """
        counter = 0

        if not (self.is_xmon_client_initialize and self.is_xmon_server_connected):
            self.initialize_xmon_client()
            self.connect_to_xmon_server()

        maestro_command = "use " + self.package  # TODO diff project use diff command
        self.send_command(maestro_command)
        for host, command in HOST_INTERFACE.items():
            target_command = f"target tgt{counter} {command}"
            counter += 1
            target_result = self.send_command(target_command)

            status, message = target_result
            if status == 0 and message == "":
                print(f"Found platform interface: {host}. Exiting...")
                return host, command

        return None, None

    def gen_platcap_via_xmon(self):
        """
        Fetches the GBT (platform configuration) string from the platform
        and saves it to the current working directory as PlatformConfig.xml.

        Returns
        -------
        str
            Path where platformconfig generated or -1 if an error occurred.
        """
        try:
            if not self.is_viewpt_exist():
                self.get_host_interface()  # call host_interface to create viewpt
            result = self.send_command("get_gbt_str")[1]
            with open(self.path, "a") as f:
                f.write(result.replace("\n\n\t", "\n\t").replace("\n\n", "\n"))
            if _is_platcap_valid(self.path):
                self.platcap_path = self.path
        except Exception:
            print("Failed to fetches the GBT string from the platform.")
            print(traceback.format_exc())
            return -1

        return self.platcap_path
