__all__ = ["XmlCliHelper"]

import os
import ipccli
import logging
import time

from xmlcli import XmlCli as cli
from xmlcli import XmlIniParser as prs

itp = ipccli.baseaccess()


def _get_xmlcli_file_path():
    _skill_dir = os.path.dirname(os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..")))
    return os.path.join(_skill_dir, "tmp", "emb", "Output", "Knobs.xml")


class XmlCliHelper:
    def __init__(self):
        super().__init__()
        self.logger = logging.getLogger(__name__)
        self.xmlcli_file_path = _get_xmlcli_file_path()
        self.xmlcli_enable = self.check_xmlcli_enable()
        if self.xmlcli_enable == 0:
            self.get_version()
            if os.path.isfile(self.xmlcli_file_path):
                tree = prs.ET.parse(self.xmlcli_file_path)
                self.root = tree.getroot()
                self.generate_dicts_from_xml()
            else:
                self.knobs_dict = dict()
                self.ucode_dict = dict()
        else:
            self.logger.error(f"[{__name__}] XmlCli is not supported/enabled.")
            return -1

    def check_xmlcli_enable(self):
        itp.halt()
        time.sleep(5)  # pause sometime to allow system completely halt
        cli.clb._setCliAccess("ipc")
        xmlcli_support = cli.clb.ConfXmlCli()
        itp.go()

        if xmlcli_support == 1:
            self.logger.error(f"[{__name__}] XmlCli is not supported. [{xmlcli_support}]")
            return -1
        elif xmlcli_support == 2:
            self.logger.error(f"[{__name__}] XmlCli is not enabled. [{xmlcli_support}]")
            return -2
        else:
            self.logger.info(f"[{__name__}] XmlCli is enabled. [{xmlcli_support}]")
            return 0

    def get_version(self):
        version = cli.clb.__version__
        self.logger.info("XmlCli Version : ", str(version))

    def generate_xml(self):
        if self.xmlcli_enable != 0:
            self.logger.error(f"[{__name__}] XmlCli is not supported/enabled.")
            return False

        if not os.path.isfile(self.xmlcli_file_path):
            try:
                # Attempt to generate and save the XML file
                cli.savexml(filename=self.xmlcli_file_path)
                if not os.path.isfile(self.xmlcli_file_path):  # TODO: check for valid instead of exist?
                    self.logger.error(f"[{__name__}] XmlCli failed to generate knobs xml.")
                    return False
            except FileNotFoundError as e:
                self.logger.error(f"[{__name__}] FileNotFoundError: {e}")
                return False
            except Exception as e:
                self.logger.error(f"[{__name__}] An unexpected error occurred: {e}")
                return False
        elif self.knobs_dict != {} or self.ucode_dict != {}:
            return True

        self.logger.info(f"[{__name__}] Generating dictionaries...")
        tree = prs.ET.parse(self.xmlcli_file_path)
        self.root = tree.getroot()
        self.generate_dicts_from_xml()
        self.logger.info(f"[{__name__}]   Done")

        return True

    def generate_dicts_from_xml(self):
        self.knobs_dict = dict()
        for child in self.root.findall("./biosknobs/knob"):
            self.knobs_dict[child.attrib["name"]] = child.attrib["CurrentVal"]
        if self.knobs_dict == {}:
            self.logger.error(f"[{__name__}] knobs_dict is empty.")
        else:
            self.logger.info(f"[{__name__}] knobs_dict generated.")

        self.ucode_dict = dict()
        for child in self.root.findall("./UcodeEntries/Ucode"):
            self.ucode_dict[child.attrib["CpuId"]] = child.attrib["Version"]
        if self.ucode_dict == {}:
            self.logger.error(f"[{__name__}] ucode_dict is empty.")
        else:
            self.logger.info(f"[{__name__}] ucode_dict generated.")

    def get_bios_version_from_xml(self):
        if not self.generate_xml():
            self.logger.error(f"[{__name__}] get_bios_version_from_xml() failed.")
            return -1

        tree = prs.ET.parse(self.xmlcli_file_path)
        root = tree.getroot()

        for child in root.iter("BIOS"):
            return child.get("VERSION")

    def get_value_from_knob(self, knob_name):
        if not self.generate_xml():
            self.logger.error(f"[{__name__}] get_value_from_knob() failed.")
            return False

        return self.knobs_dict[knob_name]

    def check_knob_values(self, knobs_dict):
        if not self.generate_xml():
            return False

        mismatch = False
        for i in knobs_dict:
            if knobs_dict[i] != self.knobs_dict[i]:
                self.logger.info(
                    f"[{__name__}] check_knob_values(): Found mismatch: {i} = {self.knobs_dict[i]} != {knobs_dict[i]}"
                )
                mismatch = True

        return not mismatch

    def get_ucode_versions_from_xml(self):
        if not self.generate_xml():
            return False
        return self.ucode_dict
