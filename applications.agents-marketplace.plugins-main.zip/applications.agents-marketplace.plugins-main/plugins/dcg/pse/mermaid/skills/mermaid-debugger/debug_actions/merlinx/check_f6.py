"""Check whether the SUT has booted to F6 status.

Replaces MerlinXHelper.is_f6(). Checks via TTK POST code first,
falls back to DCI emb0 register.
"""

import sys
import os

_helpers_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "helpers")
if _helpers_dir not in sys.path:
    sys.path.insert(0, _helpers_dir)

from namednodes import sv
from TTKControl import TTKControl

if not hasattr(sv, "socket0"):
    sv.refresh()


def check_f6():
    """Check whether the SUT has booted to F6.

    Tries TTK POST code first. If TTK is unavailable, falls back to
    reading the emb0 register via DCI.

    Returns
    -------
    bool
        True if F6 is reached, False otherwise.
    """
    try:
        ttk = TTKControl()
        if ttk.detect_ttk_version() is not None:
            postcode = ttk.port80_get_postcode()
            if "F6" in postcode.upper():
                return True
            else:
                return False
        else:
            return _check_f6_via_emb0()
    except Exception:
        return False


def _check_f6_via_emb0():
    """Check F6 status by reading the emb0 register via DCI."""
    try:
        emb_paths = [
            ("emb0", sv.socket0.soc.south.exi.exi.emb0),
            ("emb0", sv.pch0.exi.exi.emb0),
        ]
        for emb_name, emb_value in emb_paths:
            if emb_name in sv.socket0.search(emb_name)[0] or emb_name in sv.pch0.search(emb_name)[0]:
                return emb_value & 0xFF == 0xF6
    except Exception:
        return False
    return False
