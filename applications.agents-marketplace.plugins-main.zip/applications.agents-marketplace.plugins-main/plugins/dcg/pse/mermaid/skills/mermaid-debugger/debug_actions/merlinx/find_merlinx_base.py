"""
Find the base address of MerlinX.efi in physical memory via DCI DMA.

Algorithm:
  1. Read emb1/emb2 registers to obtain the VSMB base address.
  2. Walk the VSMB table to locate the BIOS_API entry (signature 0x3554A458).
  3. Read 32-bit function pointers from the BIOS_API table.
  4. Bulk-read 8 MB of physical memory around the first valid pointer.
  5. Scan page-aligned (0x1000) offsets for MZ + PE signature.
  6. Return the PE image whose address range contains the pointer.
"""

import struct
import ipccli as ipccli
from namednodes import sv

itp = ipccli.baseaccess()

# Lazy discovery: access sv.pch0 directly instead of forcing a full sv.refresh(),
# which can deadlock on shared debug hosts when another session holds the RocksDB lock.
try:
    _ = sv.pch0
except Exception:
    sv.refresh()

# ---------------------------------------------------------------------------
# VSMB / BIOS_API constants
# ---------------------------------------------------------------------------
VSMB_SIG_BIOS_API = 0x3554A458
VSMB_TABLE_SIZE = 0xA0  # bytes to read from the VSMB header
BIOS_API_READ_SIZE = 256  # bytes to read from the BIOS_API table
BULK_SCAN_SIZE = 8 * 1024 * 1024  # 8 MB scan window
PAGE_SIZE = 0x1000
PE_SIG = 0x00004550  # "PE\0\0"

# Plausible range for UEFI code pointers (32-bit physical)
PTR_LOW = 0x01000000
PTR_HIGH = 0x80000000


def _read_dma(address, size):
    """DCI DMA read helper — returns a bytearray."""
    return itp.devs.dci_usb_dma0.dma(f"{address}P", size)


def _get_vsmb_base():
    """Return the VSMB base address from emb1 or emb2."""
    emb1 = int(sv.pch0.exi.exi.emb1)
    emb2 = int(sv.pch0.exi.exi.emb2)
    base = emb1 if emb1 != 0 else emb2
    if base == 0:
        raise RuntimeError("Both emb1 and emb2 are zero — VSMB not initialised")
    return base


def _get_bios_api_address(vsmb_base):
    """Walk the VSMB table and return the BIOS_API buffer address."""
    vsmb_data = _read_dma(vsmb_base, VSMB_TABLE_SIZE)
    for offset in range(0x20, VSMB_TABLE_SIZE, 0x10):
        sig = struct.unpack_from("<I", vsmb_data, offset)[0]
        if sig == VSMB_SIG_BIOS_API:
            addr = struct.unpack_from("<I", vsmb_data, offset + 4)[0]
            return addr
    raise RuntimeError("BIOS_API signature (0x3554A458) not found in VSMB table")


def _extract_code_pointers(api_addr):
    """Read the BIOS_API table and return plausible 32-bit code pointers."""
    api_data = _read_dma(api_addr, BIOS_API_READ_SIZE)
    pointers = []
    # Skip the first 8 bytes ($BIOS_PA header)
    for i in range(8, len(api_data), 4):
        val = struct.unpack_from("<I", api_data, i)[0]
        if PTR_LOW < val < PTR_HIGH and (val & 0x3) == 0:
            pointers.append(val)
    return pointers


def _find_pe_image_for_pointer(ptr):
    """
    Bulk-read memory around *ptr* and scan for PE images.
    Returns (base, size_of_image) of the image that contains *ptr*, or None.
    """
    scan_start = (ptr & ~(PAGE_SIZE - 1)) - BULK_SCAN_SIZE + PAGE_SIZE
    if scan_start < 0:
        scan_start = 0
    scan_size = (ptr & ~(PAGE_SIZE - 1)) - scan_start + PAGE_SIZE

    bulk = _read_dma(scan_start, scan_size)

    for off in range(0, len(bulk), PAGE_SIZE):
        if bulk[off : off + 2] != b"MZ":
            continue
        e_lfanew = struct.unpack_from("<I", bulk, off + 0x3C)[0]
        if e_lfanew == 0 or e_lfanew >= PAGE_SIZE:
            continue
        if off + e_lfanew + 0x54 > len(bulk):
            continue
        pe_sig = struct.unpack_from("<I", bulk, off + e_lfanew)[0]
        if pe_sig != PE_SIG:
            continue
        size_of_image = struct.unpack_from("<I", bulk, off + e_lfanew + 0x50)[0]
        base = scan_start + off
        if base <= ptr < base + size_of_image:
            return base, size_of_image
    return None


def find_merlinx_base():
    """
    Locate MerlinX.efi in physical memory and return a dict with the results.

    Returns
    -------
    dict
        Keys: base, size_of_image, image_end, vsmb_base, bios_api_addr
    """
    vsmb_base = _get_vsmb_base()
    bios_api_addr = _get_bios_api_address(vsmb_base)
    pointers = _extract_code_pointers(bios_api_addr)

    if not pointers:
        raise RuntimeError("No valid code pointers found in BIOS_API table")

    for ptr in pointers:
        result = _find_pe_image_for_pointer(ptr)
        if result is not None:
            base, size_of_image = result
            return {
                "base": base,
                "size_of_image": size_of_image,
                "image_end": base + size_of_image,
                "vsmb_base": vsmb_base,
                "bios_api_addr": bios_api_addr,
            }

    raise RuntimeError(
        f"PE image not found for any of {len(pointers)} BIOS_API pointers "
        f"(first: 0x{pointers[0]:08X})"
    )


# ---------------------------------------------------------------------------
# CLI entry point
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    info = find_merlinx_base()
    print(f"MerlinX.efi base address = 0x{info['base']:08X}")
    print(f"  SizeOfImage = 0x{info['size_of_image']:X} ({info['size_of_image']:,} bytes)")
    print(f"  Image range = 0x{info['base']:08X} – 0x{info['image_end']:08X}")
    print(f"  VSMB base   = 0x{info['vsmb_base']:08X}")
    print(f"  BIOS_API    = 0x{info['bios_api_addr']:08X}")
