"""Download PlatformConfig.xml (GBT) from the SUT via DCI.

Replaces MerlinXHelper.gen_platcap_via_dci().
"""

import os
import sys
import traceback

_helpers_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "helpers")
if _helpers_dir not in sys.path:
    sys.path.insert(0, _helpers_dir)

import ipccli as ipccli

from merlinx.vsmb import MERLINX_SIGNATURES, get_vsmb_table, get_address_from_signature
from merlinx.host_interface import get_dci_host_interface

itp = ipccli.baseaccess()


def _run_eval(command):
    return eval(command.replace("\\", "\\\\"))


def _is_dma():
    try:
        if "DCI_USB_DMA0" in itp.devicelist.search("DCI_USB_DMA0"):
            result = itp.devs.dci_usb_dma0.dma("0x20000P", 4)
            if type(result) is bytearray:
                return True, "0"
    except Exception:
        pass
    try:
        if "DCI_USB_DMA1" in itp.devicelist.search("DCI_USB_DMA1"):
            result = itp.devs.dci_usb_dma1.dma("0x20000P", 4)
            if type(result) is bytearray:
                return True, "1"
    except Exception:
        pass
    return False, ""


def _get_emb_output_dir():
    _skill_dir = os.path.dirname(os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..")))
    return os.path.join(_skill_dir, "tmp", "emb", "Output")


def _get_platcap_file_path():
    return os.path.join(_get_emb_output_dir(), "PlatformConfig.xml")


def _is_platcap_valid(path):
    try:
        with open(path, "r") as f:
            if "<SYSTEM>" in f.read():
                return True
            else:
                os.remove(path)
    except FileNotFoundError:
        print(f"Error: File not found - {path}")
        return False


def _save_platcap_via_dma(gbtaddr, dma_path, output_path):
    """Save PlatformConfig.xml by reading GBT buffer via DCI DMA."""
    gbtsize = _run_eval('{}.dma(str({}) + "P", 4)'.format(dma_path, gbtaddr))
    gbtsize_hex = hex(int.from_bytes(gbtsize, "little"))
    gbtsize_int = int(gbtsize_hex, base=16)
    gbtaddr = hex(int(gbtaddr, base=16) + 4)
    _run_eval(
        '{}.dmasave("{}", "{}" + "P", {})'.format(dma_path, output_path, gbtaddr, gbtsize_int)
    )


def _save_platcap_via_mem(gbtaddr, output_path):
    """Save PlatformConfig.xml by reading GBT buffer via halted memory access."""
    gbtsize = itp.threads[0].mem(str(gbtaddr) + "P", 4)
    gbtsize_int = int(hex(gbtsize), base=16)
    itp.threads[0].memsave(
        output_path,
        hex(int(gbtaddr, base=16) + 4) + "P",
        gbtsize_int,
        True,
    )


def gen_platcap_via_dci():
    """Download PlatformConfig.xml (GBT) from the SUT via DCI.

    Builds the VSMB table, locates the PCXML buffer, and saves the
    PlatformConfig.xml file using DMA or halted memory access.

    Returns
    -------
    str or int
        Path to the saved PlatformConfig.xml, or -1 on failure.
    """
    output_path = _get_platcap_file_path()

    if os.path.exists(output_path):
        os.remove(output_path)

    output_dir = _get_emb_output_dir()
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    try:
        host_interface, emb = get_dci_host_interface()
        vsmb_table = get_vsmb_table()
        gbtaddr = get_address_from_signature(vsmb_table, MERLINX_SIGNATURES["VSMB_SIG_PCXML_BUFFER"])

        is_dma, dma_index = _is_dma()

        if host_interface == "DCI":
            if is_dma:
                dma_path = f"itp.devs.dci_usb_dma{dma_index}"
                _save_platcap_via_dma(gbtaddr, dma_path, output_path)
            else:
                itp.halt()
                _save_platcap_via_mem(gbtaddr, output_path)
                itp.go()
        else:
            itp.halt()
            p0 = itp.cores[0].threads[0]
            gbtaddr = p0.state.regs.xmm1
            gbtsize = p0.mem("0x%xP" % gbtaddr, 4)
            p0.memsave(
                output_path,
                "0x%xP" % (gbtaddr + 4),
                int(gbtsize),
            )
            itp.go()

        if _is_platcap_valid(output_path):
            return output_path
    except Exception:
        print(traceback.format_exc())
        return -1

    return -1
