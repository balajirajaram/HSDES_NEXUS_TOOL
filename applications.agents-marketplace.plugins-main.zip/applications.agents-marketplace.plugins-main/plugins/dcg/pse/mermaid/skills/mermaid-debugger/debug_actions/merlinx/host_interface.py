"""Detect the DCI host interface by reading emb1/emb2 registers."""

import traceback
import ipccli as ipccli
from namednodes import sv

itp = ipccli.baseaccess()

if not hasattr(sv, "socket0"):
    sv.refresh()


def get_dci_host_interface():
    """Detect the DCI host interface and return the VSMB base address.

    Reads emb1/emb2 registers from socket0/pch0 to find the active
    DCI host interface.

    Returns
    -------
    tuple
        ("DCI", vsmb_base_address) if found, ("", None) otherwise.
    """
    try:
        emb = None
        emb_paths = [
            ("emb1", sv.socket0.soc.south.exi.exi.emb1),
            ("emb1", sv.pch0.exi.exi.emb1),
            ("emb2", sv.socket0.soc.south.exi.exi.emb2),
            ("emb2", sv.pch0.exi.exi.emb2),
        ]

        for emb_name, emb_value in emb_paths:
            if emb_name in sv.socket0.search(emb_name)[0] or emb_name in sv.pch0.search(emb_name)[0]:
                if emb_value != 0x0:
                    emb = emb_value
                    return "DCI", emb

        return "", emb
    except Exception:
        print(traceback.format_exc())
        return "", None
