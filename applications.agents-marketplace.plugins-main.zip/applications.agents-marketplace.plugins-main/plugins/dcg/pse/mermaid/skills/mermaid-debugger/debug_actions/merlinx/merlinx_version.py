"""Read the MerlinX firmware version from the BIOS info buffer.

Replaces MerlinXHelper.get_merlinx_version().
"""

import sys
import os

_helpers_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "helpers")
if _helpers_dir not in sys.path:
    sys.path.insert(0, _helpers_dir)

import ipccli as ipccli

from merlinx.vsmb import MERLINX_SIGNATURES, get_vsmb_table, get_address_from_signature

itp = ipccli.baseaccess()


def _is_dma():
    try:
        if "DCI_USB_DMA0" in itp.devicelist.search("DCI_USB_DMA0"):
            result = itp.devs.dci_usb_dma0.dma("0x20000P", 4)
            if type(result) is bytearray:
                return True, "0"
    except Exception:
        pass
    try:
        if "DCI_USB_DMA1" in itp.devicelist.search("DCI_USB_DMA1"):
            result = itp.devs.dci_usb_dma1.dma("0x20000P", 4)
            if type(result) is bytearray:
                return True, "1"
    except Exception:
        pass
    return False, ""


def _run_eval(command):
    return eval(command.replace("\\", "\\\\"))


def get_merlinx_version():
    """Read the MerlinX firmware version from the BIOS info buffer.

    Builds the VSMB table, locates the BIOS_INFO signature (0x5A7ECAFE),
    and reads the version field at offset +0x14.

    Returns
    -------
    str
        Hex string of the MerlinX version.
    """
    vsmb_table = get_vsmb_table()
    offset = get_address_from_signature(vsmb_table, MERLINX_SIGNATURES["VSMB_SIG_BIOS_INFO"])
    offset_hex = hex(int(offset, 16) + 20)  # Decimal 20 >> Hexadecimal 14

    is_dma, dma_index = _is_dma()

    if is_dma:
        merlinx_version = _run_eval(
            f'itp.devs.dci_usb_dma{dma_index}.dma("{offset_hex}P", 4)'
        )
        return hex(int.from_bytes(merlinx_version, "little"))
    else:
        if not itp.ishalted():
            itp.halt()
        merlinx_version = itp.threads[0].mem(f"{offset_hex}P", 4)
        itp.go()
        return hex(merlinx_version)
