"""VSMB (Validation Shared Mailbox) table parsing and signature lookup.

Provides the signature constants, table-building, and address-lookup functions
that were previously inside MerlinXHelper.__init__ / get_vsmb / get_address_from_signature.
"""

import sys
import os

_helpers_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "helpers")
if _helpers_dir not in sys.path:
    sys.path.insert(0, _helpers_dir)

import ipccli as ipccli

from merlinx.host_interface import get_dci_host_interface

itp = ipccli.baseaccess()


def _run_eval(command):
    return eval(command.replace("\\", "\\\\"))


def _is_dma():
    try:
        if "DCI_USB_DMA0" in itp.devicelist.search("DCI_USB_DMA0"):
            result = itp.devs.dci_usb_dma0.dma("0x20000P", 4)
            if type(result) is bytearray:
                return True, "0"
    except Exception:
        pass
    try:
        if "DCI_USB_DMA1" in itp.devicelist.search("DCI_USB_DMA1"):
            result = itp.devs.dci_usb_dma1.dma("0x20000P", 4)
            if type(result) is bytearray:
                return True, "1"
    except Exception:
        pass
    return False, ""


# ---------------------------------------------------------------------------
# Validation Shared Mailbox signature constants
# ---------------------------------------------------------------------------
MERLINX_SIGNATURES = {
    "VSMB_SIG_SHARED_MAILBOX": 0xBA5EBA11,
    "VSMB_SIG_BIOS_INFO": 0x5A7ECAFE,
    "VSMB_SIG_BIOS_API": 0x3554A458,
    "VSMB_SIG_PCXML_BUFFER": 0x61C04F1C,
    "VSMB_SIG_CLI_REQ_BUFFER": 0xCA11AB1E,
    "VSMB_SIG_CLI_RSP_BUFFER": 0xCA11B0B0,
    "VSMB_SIG_CLI_OBJ_BUFFER": 0x0B76A6EA,
    "VSMB_SIG_SUMMARY_SCREEN": 0x5CEE5CEE,
    "VSMB_SIG_HOST_CARD_ADDR": 0x4057CA9D,
    "VSMB_SIG_IO_BLOCK": 0x1A571EAF,
    "VSMB_SIG_MMIO_BLOCK": 0xFACEB00C,
    "VSMB_SIG_KFIR_NT_SUPPORT": 0x5A7E0002,
    "VSMB_SIG_XML_CLI_DISABLED": 0xCD15A1ED,
    "VSMB_COMPRESSED_IMAGES_BUFFER": 0xCAC7EDD9,
    "VSMB_SIG_END_OF_TABLE": 0xDEADBEA7,
}


# ---------------------------------------------------------------------------
# Low-level address readers (DMA vs halt-and-read)
# ---------------------------------------------------------------------------

def _get_address_via_dma(dma_index, signature_const, offset):
    """Read a VSMB entry via DCI DMA and return its address if the signature matches."""
    signature = hex(
        int.from_bytes(
            _run_eval(
                'itp.devs.dci_usb_dma{}.dma(str({}) + "P", 4)'.format(dma_index, offset)
            ),
            "little",
        )
    )
    if hex(signature_const) == signature:
        print("Signature matched : {}".format(signature.upper()))
        signature_base = hex(int(str(offset), base=16) + 4)
        signature_addr = _run_eval(
            'itp.devs.dci_usb_dma{}.dma("{}" + "P", 4)'.format(dma_index, signature_base)
        )
        signature_addr_hex = hex(int.from_bytes(signature_addr, "little"))
        print("Address for signature {} : {}".format(hex(signature_const).upper(), signature_addr_hex))
        return signature_addr_hex
    return None


def _get_address_via_mem(signature_const, offset):
    """Read a VSMB entry via halted memory access and return its address if the signature matches."""
    if not itp.ishalted():
        itp.halt()
    signature = itp.threads[0].mem(str(offset) + "P", 4)
    if hex(signature_const) == hex(signature):
        print("Signature matched : {}".format(signature))
        signature_base = hex(int(str(offset), base=16) + 4)
        signature_addr = itp.threads[0].mem(str(signature_base) + "P", 4)
        return hex(signature_addr)
    return None


def _get_address(is_dma, dma_index, sig, offset):
    """Route to DMA or memory-based address reading."""
    if is_dma:
        return _get_address_via_dma(dma_index, sig, offset)
    else:
        return _get_address_via_mem(sig, offset)


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def get_vsmb_table():
    """Parse the Validation Shared Mailbox (VSMB) table from hardware.

    Detects DMA availability, reads the VSMB base from the DCI host interface,
    then walks the signature table entries.

    Returns
    -------
    dict
        Keys are hex signature strings, values are hex address strings.
    """
    is_dma, dma_index = _is_dma()
    _, vsmb_base = get_dci_host_interface()

    vsmb_table = {}

    initial_sig = MERLINX_SIGNATURES["VSMB_SIG_SHARED_MAILBOX"]
    initial_address = _get_address(is_dma, dma_index, initial_sig, vsmb_base)

    if initial_address is None:
        raise ValueError(
            f"Initial signature {hex(initial_sig)} not found at offset {hex(vsmb_base)}"
        )

    vsmb_table[hex(initial_sig)] = initial_address

    offset = vsmb_base + 0x20
    address = 0

    while address != hex(MERLINX_SIGNATURES["VSMB_SIG_END_OF_TABLE"]):
        for sig_value in MERLINX_SIGNATURES.values():
            if sig_value == MERLINX_SIGNATURES["VSMB_SIG_SHARED_MAILBOX"]:
                continue
            address = _get_address(is_dma, dma_index, sig_value, hex(offset))
            if address is not None:
                vsmb_table[hex(sig_value)] = address
        offset += 0x10

    if itp.ishalted():
        itp.go()

    return vsmb_table


def get_address_from_signature(vsmb_table, signature_const):
    """Look up a buffer address by its VSMB signature constant.

    Parameters
    ----------
    vsmb_table : dict
        Table returned by get_vsmb_table().
    signature_const : int
        One of the MERLINX_SIGNATURES values.

    Returns
    -------
    str
        The address in hexadecimal format.
    """
    return vsmb_table[hex(signature_const)]
