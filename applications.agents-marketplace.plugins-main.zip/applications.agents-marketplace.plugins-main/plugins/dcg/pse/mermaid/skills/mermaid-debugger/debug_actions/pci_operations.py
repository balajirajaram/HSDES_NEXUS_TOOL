"""PCI config space scan on the SUT via DCI dport (IO CF8/CFC).

Uses itp.threads[0].dport() to access the SUT's IO port space over DCI.
All functions halt the target before scanning and resume afterward.
"""
import traceback
import ipccli as ipccli
from namednodes import sv

itp = ipccli.baseaccess()

if not hasattr(sv, "pch0"):
    sv.refresh()


def pci_config_read(bus, dev, func, offset):
    """Read a 32-bit PCI config register on the SUT via IO CF8/CFC.

    Args:
        bus: PCI bus number (0-255).
        dev: PCI device number (0-31).
        func: PCI function number (0-7).
        offset: Config register offset (0x00-0xFC, 4-byte aligned).

    Returns:
        int: 32-bit config register value.
    """
    addr = (1 << 31) | (bus << 16) | (dev << 11) | (func << 8) | (offset & 0xFC)
    itp.threads[0].dport(0xCF8, addr)
    return int(itp.threads[0].dport(0xCFC))


def pci_config_write(bus, dev, func, offset, value):
    """Write a 32-bit PCI config register on the SUT via IO CF8/CFC.

    Args:
        bus: PCI bus number (0-255).
        dev: PCI device number (0-31).
        func: PCI function number (0-7).
        offset: Config register offset (0x00-0xFC, 4-byte aligned).
        value: 32-bit value to write.

    Returns:
        int: Readback of the register after write.
    """
    addr = (1 << 31) | (bus << 16) | (dev << 11) | (func << 8) | (offset & 0xFC)
    itp.threads[0].dport(0xCF8, addr)
    itp.threads[0].dport(0xCFC, int(value))
    itp.threads[0].dport(0xCF8, addr)
    return int(itp.threads[0].dport(0xCFC))


def _parse_device(bus, dev, func):
    """Read and parse PCI config header fields for one BDF.

    Returns:
        dict with device info, or None if no device present.
    """
    val = pci_config_read(bus, dev, func, 0x00)
    vid = val & 0xFFFF
    did = (val >> 16) & 0xFFFF
    if vid == 0xFFFF or vid == 0x0000:
        return None

    class_val = pci_config_read(bus, dev, func, 0x08)
    class_code = (class_val >> 24) & 0xFF
    subclass = (class_val >> 16) & 0xFF
    prog_if = (class_val >> 8) & 0xFF
    rev = class_val & 0xFF

    hdr_val = pci_config_read(bus, dev, func, 0x0C)
    hdr_type = (hdr_val >> 16) & 0xFF
    is_multifunction = bool(hdr_type & 0x80)
    is_bridge = (hdr_type & 0x7F) == 0x01

    sub_val = pci_config_read(bus, dev, func, 0x2C)
    sub_vid = sub_val & 0xFFFF
    sub_did = (sub_val >> 16) & 0xFFFF

    sec_bus = 0
    sub_bus = 0
    if is_bridge:
        br_val = pci_config_read(bus, dev, func, 0x18)
        sec_bus = (br_val >> 8) & 0xFF
        sub_bus = (br_val >> 16) & 0xFF

    return {
        "bdf": "%02X:%02X.%d" % (bus, dev, func),
        "bus": bus,
        "dev": dev,
        "func": func,
        "vid": "%04X" % vid,
        "did": "%04X" % did,
        "class": "%02X%02X" % (class_code, subclass),
        "class_code": class_code,
        "subclass": subclass,
        "prog_if": prog_if,
        "rev": "%02X" % rev,
        "sub_vid": "%04X" % sub_vid,
        "sub_did": "%04X" % sub_did,
        "hdr_type": hdr_type,
        "multifunction": is_multifunction,
        "bridge": is_bridge,
        "sec_bus": sec_bus,
        "sub_bus": sub_bus,
    }


def scan_pci_bus(start_bus=0, end_bus=5):
    """Scan a range of PCI buses on the SUT and return all found devices.

    Halts the target before scanning and resumes afterward.

    Args:
        start_bus: First bus to scan (default 0).
        end_bus: Last bus to scan, inclusive (default 5).

    Returns:
        list[dict]: List of device dicts with keys: bdf, vid, did, class,
                    sub_vid, sub_did, rev, bridge, sec_bus, sub_bus, etc.
    """
    devices = []
    itp.halt()
    try:
        for bus in range(start_bus, end_bus + 1):
            for dev in range(32):
                for func in range(8):
                    try:
                        entry = _parse_device(bus, dev, func)
                        if entry is None:
                            if func == 0:
                                break
                            continue
                        devices.append(entry)
                        if func == 0 and not entry["multifunction"]:
                            break
                    except Exception:
                        if func == 0:
                            break
                        continue
    finally:
        itp.go()
    return devices


def scan_pci_tree():
    """Recursively scan the full PCI tree on the SUT.

    Starts at bus 0, finds all bridges, and follows their secondary buses.
    Halts the target before scanning and resumes afterward.

    Returns:
        list[dict]: All devices found across the entire PCI hierarchy.
    """
    all_devices = []
    buses_to_scan = {0}
    buses_scanned = set()

    itp.halt()
    try:
        while buses_to_scan:
            bus = min(buses_to_scan)
            buses_to_scan.discard(bus)
            if bus in buses_scanned:
                continue
            buses_scanned.add(bus)

            for dev in range(32):
                for func in range(8):
                    try:
                        entry = _parse_device(bus, dev, func)
                        if entry is None:
                            if func == 0:
                                break
                            continue
                        all_devices.append(entry)
                        if entry["bridge"] and entry["sec_bus"] > 0:
                            buses_to_scan.add(entry["sec_bus"])
                        if func == 0 and not entry["multifunction"]:
                            break
                    except Exception:
                        if func == 0:
                            break
                        continue
    finally:
        itp.go()
    return all_devices


def read_pci_config(bus, dev, func, offset):
    """Read a single PCI config register on the SUT.

    Halts the target, reads the register, and resumes.

    Args:
        bus: PCI bus (0-255).
        dev: PCI device (0-31).
        func: PCI function (0-7).
        offset: Register offset (0x00-0xFC, 4-byte aligned).

    Returns:
        dict: {bdf, offset, value}
    """
    itp.halt()
    try:
        val = pci_config_read(bus, dev, func, offset)
    finally:
        itp.go()
    return {
        "bdf": "%02X:%02X.%d" % (bus, dev, func),
        "offset": "0x%02X" % offset,
        "value": "0x%08X" % val,
    }


def find_device_by_id(vendor_id, device_id=None, start_bus=0, end_bus=255):
    """Search for a PCI device by vendor/device ID across a bus range.

    Halts the target before scanning and resumes afterward.

    Args:
        vendor_id: 16-bit vendor ID to match (e.g. 0x8086).
        device_id: Optional 16-bit device ID. If None, matches any device from the vendor.
        start_bus: First bus to scan (default 0).
        end_bus: Last bus to scan, inclusive (default 255).

    Returns:
        list[dict]: All matching devices.
    """
    matches = []
    vid_str = "%04X" % (vendor_id & 0xFFFF)
    did_str = "%04X" % (device_id & 0xFFFF) if device_id is not None else None

    itp.halt()
    try:
        for bus in range(start_bus, end_bus + 1):
            for dev in range(32):
                for func in range(8):
                    try:
                        entry = _parse_device(bus, dev, func)
                        if entry is None:
                            if func == 0:
                                break
                            continue
                        if entry["vid"] == vid_str:
                            if did_str is None or entry["did"] == did_str:
                                matches.append(entry)
                        if func == 0 and not entry["multifunction"]:
                            break
                    except Exception:
                        if func == 0:
                            break
                        continue
    finally:
        itp.go()
    return matches


def get_pci_bridges(start_bus=0, end_bus=5):
    """Find all PCI-to-PCI bridges and their bus assignments.

    Halts the target before scanning and resumes afterward.

    Args:
        start_bus: First bus to scan (default 0).
        end_bus: Last bus to scan, inclusive (default 5).

    Returns:
        list[dict]: Bridge devices with sec_bus and sub_bus populated.
    """
    devices = scan_pci_bus(start_bus, end_bus)
    return [d for d in devices if d["bridge"]]
