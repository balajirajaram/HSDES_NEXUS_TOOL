import traceback
import ipccli as ipccli
from namednodes import sv

itp = ipccli.baseaccess()

if not hasattr(sv, "pch0"):
    sv.refresh()


def check_f6_via_dci():
    emb0 = sv.pch0.exi.exi.emb0
    return int(emb0)


def read_memory(address, size):
    data = itp.devs.dci_usb_dma0.dma(f"{str(address)}p", int(size)).hex()
    return str(data)


def write_memory(address, size, value):
    itp.devs.dci_usb_dma0.dma(f"{str(address)}p", int(size), int(value))
    return read_memory(address, size)


def read_cpu_registers(thread_index=8):
    """Read all CPU registers for the specified thread.
    Halts the target before reading registers and resumes afterward.
    Returns a string representation of the register values."""
    itp.halt()
    try:
        regs = itp.threads[thread_index].regs()
        return str(regs)
    finally:
        itp.go()


def read_cpu_register(register_name, thread_index=8):
    """Read a single CPU register by parsing regs() output.
    Halts the target before reading and resumes afterward.

    NOTE: regs() returns 32-bit names (eip, eax, esp, etc.) even in long mode.
    Both 32-bit and 64-bit names are accepted (e.g. 'rip' matches 'eip').

    WARNING: itp.devs[str(thread)].arch_register() does NOT work —
    itp.devs requires int index, and the resulting MTP_ICC_Node has no
    arch_register method. Always use regs() + parse instead."""
    import re
    itp.halt()
    try:
        regs_str = str(itp.threads[thread_index].regs())
        # Normalize: accept rip -> also match eip, rax -> eax, etc.
        name = register_name.lower()
        # Build pattern that matches both 32-bit and 64-bit register names
        if name.startswith('r') and name[1:] in ('ax','bx','cx','dx','si','di','bp','sp','ip'):
            pattern = rf'(?:r|e){re.escape(name[1:])}\s*=\s*(?:0x)?([0-9a-fA-F]+)'
        elif name.startswith('e') and name[1:] in ('ax','bx','cx','dx','si','di','bp','sp','ip'):
            pattern = rf'(?:r|e){re.escape(name[1:])}\s*=\s*(?:0x)?([0-9a-fA-F]+)'
        else:
            pattern = rf'{re.escape(name)}\s*=\s*(?:0x)?([0-9a-fA-F]+)'
        match = re.search(pattern, regs_str, re.IGNORECASE)
        if match:
            return {register_name: hex(int(match.group(1), 16))}
        raise ValueError(f"Register '{register_name}' not found in regs() output: {regs_str}")
    finally:
        itp.go()


def is_unlocked():
    """Check whether the SUT is unlocked using itp.isunlocked().
    Returns True if unlocked, False otherwise."""
    return itp.isunlocked()


def read_asm_instructions(address, count=10, thread_index=0):
    """Disassemble instructions at a given memory address using itp.threads[#].asm().
    Halts the target before reading and resumes afterward.

    Args:
        address: The memory address to disassemble from (int or hex string).
        count: Number of instructions to disassemble (default 10).
        thread_index: Which thread context to use for disassembly (default 0).

    Returns:
        String containing the disassembled instructions.
    """
    itp.halt()
    try:
        if isinstance(address, int):
            addr_str = hex(address)
        else:
            addr_str = str(address)
        result = itp.threads[thread_index].asm(addr_str, count)
        return str(result)
    finally:
        itp.go()


def read_microcode_version(thread_index=0):
    """Read the microcode version from IA32_BIOS_SIGN_ID (MSR 0x8B).
    Halts the target before reading and resumes afterward.

    Args:
        thread_index: Which thread to read from (default 0).

    Returns:
        Dict with raw MSR value, microcode version, and whether it is debug microcode.
    """
    IA32_BIOS_SIGN_ID = 0x8B
    itp.halt()
    try:
        raw = itp.threads[thread_index].msr(IA32_BIOS_SIGN_ID)
        version = (raw >> 32) & 0xFFFFFFFF
        is_debug = bool(version & 0x80000000)
        return {
            "raw_msr": hex(raw),
            "version": hex(version),
            "is_debug": is_debug,
            "thread_index": thread_index,
        }
    finally:
        itp.go()


def find_bsp():
    """Identify the BSP (Boot Strap Processor) core by checking IA32_APIC_BASE MSR (0x1B) bit 8.
    Halts the target before reading MSRs and resumes afterward."""
    IA32_APIC_BASE = 0x1B
    BSP_FLAG = 1 << 8
    itp.halt()
    try:
        for i, thread in enumerate(itp.threads):
            apic_base = thread.msr(IA32_APIC_BASE)
            if apic_base & BSP_FLAG:
                return {"thread_index": i, "thread": str(thread), "apic_base_msr": hex(apic_base)}
    finally:
        itp.go()
    return None
def check_patch23():
    debug_modes = []
    result = "not_found"
    try:
        global_list = sv.socket0.search("sv_global_enable", "f")
        if not global_list:
            return None
        for node in global_list:
            node_name = str(node)
            if "pic_cr_debug_modes" in node_name:
                debug_modes.append(node)
        if not debug_modes:
            return "not_found"
        for mode in debug_modes:
            try:
                if hasattr(mode, "read"):
                    value = mode.read()
                else:
                    mode_name = str(mode)
                    mode_path = mode_name if mode_name.startswith("sv.socket0.") else f"sv.socket0.{mode_name}"
                    value = eval(f"{mode_path}.read()")
            except Exception as e:
                print(f"Error in run_eval: {e}")
                traceback.print_exc()
                continue
            try:
                value = int(value)
            except Exception:
                pass
            if value == 0x1:
                return "enabled"
            if value == 0x0:
                result = "disabled"
        return result
    except Exception as e:
        print(f"Error global list: {e}")
        traceback.print_exc()
        return None
