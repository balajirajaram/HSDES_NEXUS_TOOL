from debug_actions.helpers.SerialHelper import SerialHelper


def list_serial_ports():
    return SerialHelper.list_ports()


def capture_serial_log(port, duration=30, baudrate=115200, filepath=None):
    helper = SerialHelper(port=port, baudrate=baudrate)
    if not helper.open():
        return None
    try:
        return helper.capture_log(duration=duration, filepath=filepath)
    finally:
        helper.close()


def wait_for_f6(port, timeout=300, baudrate=115200):
    helper = SerialHelper(port=port, baudrate=baudrate)
    if not helper.open():
        return [], False
    try:
        return helper.wait_for_f6(timeout=timeout)
    finally:
        helper.close()


def parse_serial_log(filepath):
    return SerialHelper.parse_log(filepath)


def get_last_postcode_from_log(filepath):
    return SerialHelper.get_last_postcode(filepath)


def classify_log_line(line):
    return SerialHelper.classify_line(line)


def send_serial_command(port, command, wait=3.0, baudrate=115200):
    helper = SerialHelper(port=port, baudrate=baudrate)
    if not helper.open():
        return None
    try:
        return helper.send_command(command, wait=wait)
    finally:
        helper.close()
