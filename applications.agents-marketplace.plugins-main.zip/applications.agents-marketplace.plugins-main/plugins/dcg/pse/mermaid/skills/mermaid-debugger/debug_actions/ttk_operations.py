from debug_actions.helpers.TTKControl import TTKControl


def get_postcode():
    ttk = TTKControl()
    data = ttk.port80_get_postcode()
    return data
