"""XmlCli operations — flat function bridge over XmlCliHelper.

Instantiates XmlCliHelper once at import time so the expensive
itp.halt() / cli.ConfXmlCli() / XML parse cycle runs only once per
session.  All subsequent calls reuse the cached helper instance.
"""

import os

from debug_actions.helpers.XmlCliHelper import XmlCliHelper

_helper = XmlCliHelper()


def regenerate_knobs_xml():
    """Delete and regenerate Knobs.xml from the live SUT.

    Returns the path to the new file, or None on failure.
    """
    import ipccli
    from xmlcli import XmlCli as cli

    itp = ipccli.baseaccess()
    path = _helper.xmlcli_file_path

    os.makedirs(os.path.dirname(path), exist_ok=True)
    if os.path.exists(path):
        os.remove(path)

    itp.halt()
    cli.clb._setCliAccess("ipc")
    cli.savexml(filename=path)
    itp.go()

    return path if os.path.exists(path) else None


def get_bios_version():
    """Return the BIOS version string from the knobs XML."""
    return _helper.get_bios_version_from_xml()


def get_knob_value(knob_name):
    """Return the current value of a single BIOS knob by name."""
    return _helper.get_value_from_knob(knob_name)


def check_knob_values(expected):
    """Compare a dict of {knob_name: expected_value} against actual values.

    Returns True if all match, False otherwise (mismatches are logged).
    """
    return _helper.check_knob_values(expected)


def get_ucode_versions():
    """Return a dict of {CpuId: ucode_version} from the knobs XML."""
    return _helper.get_ucode_versions_from_xml()
