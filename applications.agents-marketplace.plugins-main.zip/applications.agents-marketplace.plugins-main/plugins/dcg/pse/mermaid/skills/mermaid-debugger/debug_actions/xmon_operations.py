"""XMon operations — flat function bridge over XMonHelper.

Instantiates XMonHelper once at import time.  The high-level methods
auto-initialize the xMon client and connect to the server on first use,
so callers don't need to manage the connection lifecycle.

The ``package`` parameter defaults to the XMON_PACKAGE environment
variable, falling back to "arrowlake" if unset.
"""

import os
from debug_actions.helpers.XMonHelper import XMonHelper

_package = os.environ.get("XMON_PACKAGE", "arrowlake")
_helper = XMonHelper(_package)


def send_command(command):
    """Send a command string to xMon and return (status, message)."""
    return _helper.send_command(command)


def get_host_interface():
    """Auto-detect platform interface (KFIR, DCI, JTAG, etc.).

    Returns (interface_name, clsid_command) or (None, None).
    """
    return _helper.get_host_interface()


def gen_platcap_via_xmon():
    """Download PlatformConfig.xml (GBT) via xMon's get_gbt_str command.

    Returns the file path on success, or -1 on error.
    """
    return _helper.gen_platcap_via_xmon()


def is_viewpt_exist():
    """Check if a target viewpoint is configured."""
    return _helper.is_viewpt_exist()


def is_xmon_ready():
    """Ping the xMon server to verify the connection is alive."""
    return _helper.is_xmon_ready()
