# Debug Case Studies

Detailed, real-world debug walkthroughs with actual tool output, decision points, and resolution steps. Each case study follows the end-to-end workflow pattern from [SKILL.md](../SKILL.md#end-to-end-debug-workflows).

## Format

Each case study should include:

1. **Symptom** — what the user observed (POST code, hang, error message)
2. **Triage** — initial assessment and tool selection
3. **Debug steps** — commands executed with actual output
4. **Analysis** — interpretation of results (references mermaid-analyst when applicable)
5. **Root cause** — what went wrong
6. **Resolution** — fix or workaround applied
