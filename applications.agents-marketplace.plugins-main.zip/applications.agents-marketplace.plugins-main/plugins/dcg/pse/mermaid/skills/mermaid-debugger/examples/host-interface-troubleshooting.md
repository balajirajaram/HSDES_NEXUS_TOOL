# Host Interface Troubleshooting: Kfir vs DCI

## Symptom

xMon fails to create a target with:
```
% target tgt $CLSID_CKfir
CKfirDriver::Open(): Error Kfir device wasn't found !
CKfirDriver::Open(): Cannot open interface in KfirInterface.dll or KfirNTInterface.dll
failed to open a target device: operation failed
```

## Triage

MerlinX and xMon communicate over a **host interface**. Two types exist:
- **Kfir** — PCIe-based (`$CLSID_CKfir`), requires `CpuSvBootMode=0x2`
- **DCI** — USB-based (`$CLSID_CDCI`), requires `CpuSvBootMode=0x4`

## Debug Steps

### 1. Check BIOS knob configuration

```python
# First, check if hidden/test knobs are visible:
get_knob_value("EnableTestMenu")
# Must be 0x1 — otherwise CpuSvBootMode won't appear in Knobs.xml

get_knob_value("CpuSvBootMode")
# Expected: 0x2 for Kfir, 0x4 for DCI
```

> **Gotcha — `KeyError: 'CpuSvBootMode'`:**
> `CpuSvBootMode` is a hidden/test knob. It only appears in the generated Knobs.xml
> when `EnableTestMenu=0x1`. If `EnableTestMenu` is 0x0 (default), the knob is
> absent and `get_knob_value("CpuSvBootMode")` raises `KeyError`.
>
> **Fallback when test menu is disabled:** Check these visible knobs instead:
> ```python
> get_knob_value("PlatformDebugOption")  # 0x0=Disabled, 0x2=DCI
> get_knob_value("DciEn")                # 0x1=Enabled
> get_knob_value("DciDbcMode")           # 0x1=USB2 DbC
> ```

If the knob doesn't match the interface being used, reconfigure and reboot.

### 2. If Kfir — verify the PCIe card is enumerated on the SUT

```python
# Scan full PCI tree via DCI
devices = scan_pci_tree()

# Or search specifically for non-Intel devices (Kfir has its own VID:DID)
non_intel = [d for d in devices if d['vid'] != '8086']
```

If no Kfir device appears in the PCI tree:
- The platform may not have a Kfir card installed
- The SUT hasn't booted far enough to enumerate PCIe devices
- The Kfir card is physically faulty or not seated properly

### 3. If DCI — verify USB debug connection on the debug host

```powershell
Get-PnpDevice | Where-Object { $_.FriendlyName -match 'DCI|DbC' }
```

### 4. xMon auto-detect as a cross-check

```python
get_host_interface()
# Returns detected interface type: KFIR, DCI, DCIDMA, JTAG, etc.
```

### 5. Verify driver DLLs are installed

For Kfir: `KfirInterface.dll` / `KfirNTInterface.dll` must be present in the IPC/OpenIPC installation directory on the debug host.

## Analysis

In the original case, the error `Kfir device wasn't found` on an Arrow Lake client platform pointed to a mismatch — Arrow Lake client typically uses DCI (USB), not Kfir (PCIe). A full PCI scan of the SUT confirmed no Kfir card was present anywhere in the PCIe hierarchy (buses 0–85).

## Root Cause

Wrong interface type selected. The system uses DCI, but xMon was configured to connect via Kfir.

## Resolution

Use a DCI-based target class instead:
```
% target tgt $CLSID_CDCI
```

And ensure `CpuSvBootMode=0x4` is set in BIOS.
