# Case Study: ULX #UD Exception on patch2/patch3 Opcodes (ArrowLake-S A0)

## Symptom

ULX v1.44 crashes with `#UD (Invalid Opcode)` exception on APIC ID 0x00 (BSP, LionCove P-core) during the "Disabling X2Apic locks" phase on an ArrowLake-S A0 system (CPUID `0x000C0662`).

```
Disabling X2Apic locks
..00!!!! X64 Exception Type - 06(#UD - Invalid Opcode)  CPU Apic ID - 00000000 !!!!
RIP  - 000000005BB7D126, CS  - 0000000000000038, RFLAGS - 0000000000010202
```

## Triage

- **Exception type:** `#UD` = CPU encountered an unrecognized instruction
- **Faulting phase:** After successful APIC enumeration (14 threads found), during X2APIC lock teardown
- **Faulting core:** APIC ID 0x00 — the BSP (first P-core), meaning it failed on the very first iteration

**Tools needed:** `read_asm_instructions` (disassemble at crash RIP), `read_microcode_version` (check ucode), `is_unlocked` (check SUT lock state)

## Debug Steps

### Step 1: Disassemble at the crash RIP

```python
read_asm_instructions(0x5BB7D126, count=10, thread_index=0)
```

**Output:**
```
0x38:0x5bb7d126    0f0e       patch2
0x38:0x5bb7d128    0faee8     lfence
0x38:0x5bb7d12b    4889d0     mov rax, rdx
0x38:0x5bb7d12e    c3         ret
0x38:0x5bb7d12f    4889c8     mov rax, rcx
0x38:0x5bb7d132    4889d1     mov rcx, rdx
0x38:0x5bb7d135    4c89c2     mov rdx, r8
0x38:0x5bb7d138    0f0f       patch3
0x38:0x5bb7d13a    0faee8     lfence
0x38:0x5bb7d13d    c3         ret
```

**Interpretation:** The faulting instruction is `patch2` (opcode `0F 0E`). This is a debug-mode patchable opcode — a placeholder that debug microcode replaces at runtime with the actual `RDMSR`/`WRMSR` instruction. Two MSR wrapper functions are visible:
- `patch2` + `lfence` + `mov rax, rdx` + `ret` → RDMSR wrapper
- arg setup + `patch3` + `lfence` + `ret` → WRMSR wrapper

### Step 2: Check microcode version

```python
read_microcode_version(thread_index=0)
```

**Output:**
```python
{'raw_msr': '0x8100010500000000', 'version': '0x81000105', 'is_debug': True, 'thread_index': 0}
```

**Interpretation:** Debug microcode is loaded (bit 31 set → `0x81xxxxxx`). This prerequisite is met.

### Step 3: Check SUT unlock status

```python
is_unlocked()
```

**Output:**
```
False
```

**Interpretation:** The SUT is **locked**. This is the missing prerequisite.

## Root Cause

The `patch2`/`patch3` patchable opcodes (`0F 0E`/`0F 0F`) require **two prerequisites** to function:

1. **Debug microcode loaded** — ✅ met (version `0x81000105`)
2. **SUT unlocked** — ❌ **not met** (SUT is locked)

On a locked part, the debug microcode does not activate the patch opcode handlers. The CPU treats `0F 0E` as an undefined opcode and raises `#UD`.

The crash occurs on the BSP (APIC ID 0x00, thread index 0) at the very first iteration of the X2APIC lock disable loop, confirming no cores were successfully processed — the failure is immediate and deterministic.

## Resolution

**Unlock the SUT via DCI** before running ULX. The unlock must happen before the patchable opcodes are executed.

Alternatively, use a production ULX build that uses standard `RDMSR`/`WRMSR` instructions instead of patch2/patch3 placeholders, if available.

## Key Takeaways

- `#UD` during MSR operations → check for `patch2`/`patch3` opcodes at the faulting RIP
- `patch2` (`0F 0E`) and `patch3` (`0F 0F`) are debug-mode patchable instruction placeholders
- Both **debug microcode** and **SUT unlock** are required for patch opcodes to work
- On recent cores, `patch3` with RCX command `0x11` is used to write `ML3_CR_PIC_THREAD_CONFIG[CLEAR_APIC_STATE]` for APIC reset. The **ULX tool must be run first** to unlock patch3 support; without it, `FAKED_INIT` will `#GP` during `ResetApicControllerPatch2`
- Use `read_asm_instructions()` to identify the faulting instruction — register dumps alone are not enough to distinguish `patch2` from other `#UD` causes
- Use `read_microcode_version()` to verify debug ucode (bit 31 of version = debug flag)
- Use `is_unlocked()` to verify SUT unlock state
