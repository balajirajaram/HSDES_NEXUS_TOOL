---
name: mermaid-developer
description: "BIOS project retrieval and codebase navigation for Intel Client/Server BIOS. Use EdkRepo to clone repositories from C:\\ProgramData\\edkrepo\\cr-manifest-main, trace IFWI binaries ($IBIOSI$ signature) back to source code via pin files, and navigate the multi-repo BIOS workspace structure (Intel, Edk2, Edk2Platforms, Binaries, SvRestricted). Also covers MerlinX/SvRestricted code structure including ULX, ValidationMegaBlock, ValSharedMailbox, and all validation libraries. Includes EFI binary symbol lookup — locating NASM assembly functions inside stripped .efi files via byte-pattern matching with pefile. Use this skill whenever the user mentions edkrepo, clone, manifest, pin file, checkout-pin, IFWI, $IBIOSI$, BIOS version, repo setup, code structure, find module, where is, MerlinX structure, SvRestricted, ValidationMegaBlock, VMB, ValSharedMailbox, VSM, ULX, find_symbol, .efi offset, function offset, byte signature, NASM function, pefile, symbol lookup — even if they just say 'clone the repo', 'what version is this IFWI', or 'find function in .efi'."
---

# Mermaid Developer — BIOS Project Retrieval & Code Navigation

**Clone BIOS repositories via EdkRepo, trace IFWI binaries to source, and navigate the multi-repo codebase structure.**

## Purpose

This skill provides:

1. **EdkRepo Clone** — Retrieve BIOS source code from `C:\ProgramData\edkrepo\cr-manifest-main` using project manifests
2. **IFWI → Source Tracing** — Extract `$IBIOSI$` signature from IFWI binary → BIOS version → pin file → exact source snapshot
3. **Codebase Structure** — Navigate the 5-repo BIOS workspace layout and locate modules
4. **MerlinX/SvRestricted** — Understand validation framework components (ULX, VMB, VSM, CpuidDump, Poof)
5. **Code Search** — Find source files by keyword across project repositories
6. **EFI Binary Symbol Lookup** — Locate NASM assembly functions inside stripped `.efi` binaries via byte-pattern matching

## When I Activate

Automatically when you mention:

- "edkrepo", "clone", "manifest", "combination", "checkout-pin", "pin file"
- "IFWI", "$IBIOSI$", "BIOS version", "which version", "trace to source"
- "repo structure", "code structure", "where is", "find module", "find package"
- "SvRestricted", "MerlinX", "ValidationMegaBlock", "VMB", "ValSharedMailbox", "VSM", "ULX"
- "repo setup", "workspace setup", "get the source", "clone the repo"
- "find_symbol", ".efi offset", "function offset", "byte signature", "NASM function in .efi", "pefile", "symbol lookup"

---

## EdkRepo Clone Workflow

### Quick Start

```powershell
# Clone NovaLake project (main branch combination)
edkrepo clone <WorkspaceDir> NovaLakeJenkins Edk2Master

# Clone with specific combination (e.g., power-on branch)
edkrepo clone <WorkspaceDir> NovaLakeJenkins nvl_s_po

# Clone with sparse checkout (faster, only needed packages)
edkrepo clone <WorkspaceDir> NovaLakeJenkins Edk2Master --sparse
```

### Manifest Location

All project manifests live in:
```
C:\ProgramData\edkrepo\cr-manifest-main\
├── CCG\                    ← Client projects (NovaLake, MeteorLake, etc.)
│   └── NovaLakeJenkins\
│       ├── Manifest.xml    ← Project manifest (repos, combinations, sparse rules)
│       └── pins\           ← Pin files (source snapshots tied to BIOS versions)
└── DCG\                    ← Server projects (OakStream, DiamondRapids, etc.)
```

### Available Combinations (NovaLake)

| Combination | Branch Pattern | Purpose |
|---|---|---|
| `Edk2Master` | `main` / `Downstream/master` | Main development (default) |
| `novalake_program_platform` | `platform/novalake_program` | Program integration |
| `novalake_mobile_program_platform` | `platform/novalake_mobile_program` | Mobile program |
| `nvl_s_po` | `po/nvl_s_po` | S-die power-on |
| `nvl_mob_po` | `po/nvl_mob_po` | Mobile power-on |
| `nvl_milestone_rel` | `release/nvl_milestone` | Milestone releases |
| `ttl_afp_dev` | `dev/ttl_afp_dev` | TitanLake AFP development |

### Key EdkRepo Commands

| Command | Usage | Purpose |
|---|---|---|
| `clone` | `edkrepo clone <dir> <project> [combo]` | Initial workspace creation |
| `checkout-pin` | `edkrepo checkout-pin <pin.xml>` | Restore exact source snapshot |
| `sync` | `edkrepo sync` | Fetch latest for current combination |
| `checkout` | `edkrepo checkout <combo>` | Switch branch combination |
| `status` | `edkrepo status` | Show current combo + git status |
| `combo` | `edkrepo combo` | List all available combinations |
| `manifest` | `edkrepo manifest` | List all projects in manifest repo |

Read [references/edkrepo.md](references/edkrepo.md) for full command reference and the [EdkRepo Manual](references/EdkRepo%20Manual_public.docx) for detailed options.

---

## IFWI → Source Tracing

### Overview

Given an IFWI binary, trace it back to the exact source code snapshot:

```
IFWI binary → extract $IBIOSI$ signature → parse BIOS version
    → scripts/pin_file_search.py → find matching pin XML
    → edkrepo checkout-pin <pin.xml> → exact source
```

### Step 1: Extract $IBIOSI$ from IFWI Binary

The `$IBIOSI$` signature is an ASCII string embedded in the IFWI binary that identifies the BIOS version. Search for it:

```powershell
# Find the $IBIOSI$ string in a binary file
python -c "
import sys
data = open(sys.argv[1], 'rb').read()
idx = data.find(b'$IBIOSI$')
if idx >= 0:
    # BIOS ID string follows the signature (null-terminated)
    end = data.index(b'\x00', idx + 8)
    print(f'Found at offset 0x{idx:X}: {data[idx+8:end].decode()}')
else:
    print('$IBIOSI$ signature not found')
" <path_to_ifwi.bin>
```

The extracted string contains the BIOS version (e.g., `NVLSFWI1.R00.0042_00.P00.2506010001`).

### Step 2: Parse BIOS Version

**Client BIOS version format:** `XXXX` or `XXXX_YY`
- `XXXX` = build number (4 digits)
- `YY` = sub-version (2 digits, defaults to `00`)

**Server BIOS version format:** `NNNN.L.NN`
- `NNNN` = build number, `L` = letter revision, `NN` = sub-version

### Step 3: Find Pin File

Use the pin file search script:

```powershell
# Client project (NovaLake)
python scripts/pin_file_search.py
# Or call programmatically:
# lookup_pin_file("nvl", "0042")     → searches CCG/ for matching pin XML
# lookup_pin_file("nvl", "0042_00")  → explicit sub-version

# Server project (from IFWI filename)
# lookup_pin_file_from_ifwi("OKS.BMC.0042.A.01.bin")
```

Pin files are searched in `C:\ProgramData\edkrepo\cr-manifest-main\CCG\` (client) or `DCG\` (server).

### Step 4: Checkout Pin

```powershell
edkrepo checkout-pin <path_to_pin.xml>
```

This restores the workspace to the exact commit SHAs that produced that BIOS version.

### Supported Projects

| Project | Aliases | Manifest Path |
|---|---|---|
| NovaLake | `nvl`, `novalake`, `novalakejenkins` | `CCG/NovaLakeJenkins/` |
| MeteorLake | `mtl`, `meteorlake` | `CCG/MeteorLakeJenkins/` (if available) |
| OakStream/Gen4 | `oks`, `dmr`, `oakstream`, `gen4` | `DCG/ServerGen4/` |

---

## BIOS Repository Structure

### 5-Repo Workspace Layout

A cloned BIOS workspace consists of 5 git repositories mapped to local directories:

| Local Root | Remote | Content |
|---|---|---|
| `Intel/` | `firmware.boot.uefi.iafw.intel` | Platform packages: board, FSP, silicon, features |
| `Edk2/` | `firmware.boot.uefi.iafw.externalmirror.edk2` | Tianocore EDK II: core UEFI infrastructure |
| `Edk2Platforms/` | `firmware.boot.uefi.iafw.externalmirror.edk2-platforms` | MinPlatformPkg, BoardModulePkg, IntelSiliconPkg |
| `Binaries/` | `firmware.boot.uefi.iafw.binaries` | Pre-built binaries, crypto libs, tools |
| `SvRestricted/` | `firmware.boot.uefi.iafw.svrestricted` | Silicon validation (MerlinX, VMB, VSM, ULX) |

### Intel/ Package Organization

```
Intel/
├── NovaLakeBoardPkg/          ← Primary build target (BoardPkg.dsc, BoardPkg.fdf)
├── NovaLakeOpenBoardPkg/      ← Simplified board variant
├── NovaLakeFspPkg/            ← Firmware Support Package (FSP-T/M/S)
├── NovaLakeFspBinPkg/         ← Pre-built FSP binaries
├── NovaLakePlatSamplePkg/     ← Platform sample drivers, setup, libraries
├── NovaLakeRestrictedPkg/     ← Restricted platform features
├── ClientFspPkg/              ← Cross-platform FSP common code
├── CsiApiPkg/                 ← CSI API package
├── OneSiliconPkg/             ← Cross-product silicon IP blocks
│   ├── IpBlock/              ← Per-IP libraries (CPU, PCH, Memory, Graphics)
│   ├── Product/NovaLake/     ← NovaLake-specific silicon init
│   ├── Library/              ← Shared libraries (TraceHub, PostCode, Debug)
│   ├── Include/              ← Headers (Protocol/, Ppi/, Register/)
│   ├── Fru/                  ← Field Replaceable Unit configs (NvlCpu, NvlPch)
│   └── Pch/                  ← PCH-specific code
├── Features/                  ← Feature packages (XmlCli, Thermal, Security, USB-C, etc.)
└── SimulationPkg/            ← IP simulation support
```

### Edk2/ Key Packages

| Package | Purpose |
|---|---|
| `MdePkg/` | Core libraries, protocols, GUID definitions |
| `MdeModulePkg/` | Generic modules (BDS, Variable, StatusCode, Console) |
| `UefiCpuPkg/` | CPU architecture (MP init, MTRR, microcode loader) |
| `IntelFsp2Pkg/` | FSP infrastructure (SEC core, dispatch) |
| `IntelFsp2WrapperPkg/` | FSP wrapper (platform calls into FSP) |
| `SecurityPkg/` | Secure boot, TPM, crypto |
| `NetworkPkg/` | Network stack (PXE, HTTP boot) |
| `ShellPkg/` | UEFI Shell |
| `BaseTools/` | Build tools (GenFv, GenFfs, build.exe) |

### Key Build Entry Points

| File | Purpose |
|---|---|
| `Intel/NovaLakeBoardPkg/BoardPkg.dsc` | Main platform DSC (full build) |
| `Intel/NovaLakeBoardPkg/BoardPkg.fdf` | Flash layout (FV definitions) |
| `Intel/NovaLakeFspPkg/NovaLakeFspPkg.dsc` | FSP package build |
| `Intel/NovaLakeOpenBoardPkg/OpenBoardPkg.dsc` | Simplified board build |
| `SvRestricted/Core/AgnosticSvPkg.dsc` | MerlinX/validation build |

---

## MerlinX / SvRestricted Structure

### Component Overview

```
SvRestricted/Core/
├── MerlinX/                   ← Bare-metal validation executor (25+ libraries)
│   ├── MerlinX.inf           ← Main module (DXE_DRIVER)
│   ├── Library/              ← Specialized libraries (see below)
│   ├── Include/              ← Headers, protocol definitions
│   ├── Shell/                ← Shell application variant
│   └── Docs/                 ← Release notes, documentation
├── ValidationMegaBlock/       ← PEIM: reserves large memory blocks for validation
├── ValSharedMailbox/          ← DXE driver: shared memory mailbox (host↔target comms)
├── ulx/                       ← X2APIC unlock utility (per-core MSR writes)
├── CpuidDump/                 ← CPUID information extraction
├── Poof/                      ← Host bridge + platform drivers
├── XmlWriter/                 ← Dynamic PlatformConfig.xml generation
├── TestEfiRun/                ← Test scenario applications
├── build_merlinx.py           ← Build script for validation components
└── AgnosticSvPkg.dsc          ← Build DSC for all validation modules
```

### MerlinX Libraries

| Library | Purpose |
|---|---|
| `CommandLineInterfaceLib` | CLI parsing, scatter object file loading |
| `HostInterfaceLib` | Multi-protocol host communication (DCI, LCBE SPI/Sideband, PCI cards) |
| `SharedMailboxLib` | Memory-mapped buffer protocol access |
| `SmmSvDispatcherLib` | SMM-level test dispatch |
| `PlatformConfigXmlLib` | Parses PlatformConfig.xml for system topology |
| `ContextInitLib` | Processor/memory context initialization |
| `BiosApiLib` | BIOS API interface for test runtime |
| `ExecutionListLib` | Test sequence execution with POST code tracking |
| `ApicLib` | APIC/X2APIC operations |
| `PcieLib` | PCIe device enumeration and access |
| `SmBusLib` | SMBus/I2C communication |

### MerlinX Domain References

For detailed data structures and execution flows of these components, read:

| Component | Reference | When to read |
|---|---|---|
| **ULX** | [references/ulx.md](references/ulx.md) | X2APIC unlock flow, per-core MSR recipe dispatch, command-line options |
| **ValidationMegaBlock** | [references/vmb.md](references/vmb.md) | Memory reservation PEIM, HOB carving, MEGABLOCK_DATA structures |
| **ValSharedMailbox** | [references/vsm.md](references/vsm.md) | VSM protocol, entry signatures, lock states, HIF sync, CMOS persistence |

### Communication Architecture

```
Host (xMon/PythonSV/XmlCli)
    │
    ├─ DCI (Direct Connect Interface) ─── DciInterface.c
    ├─ LCBE SPI/Sideband ─────────────── LcbeSpi.c, LcbeSideband.c
    └─ PCI Debug Card (Net2282/KFIR) ─── SvFindPciCard.c
    │
    ▼
ValSharedMailbox (512-byte table in DRAM)
    │
    ▼
MerlinX (test executor on target)
```

---

## Code Search

### Using code_search_tool.py

Search for files containing keywords across project repositories:

```powershell
python scripts/code_search_tool.py
# Programmatic usage:
# search_for_keywords("nvl", ["PcdDebugPrintErrorLevel", "FixedAtBuild"])
# search_for_keywords("merlinx", ["ValSharedMailbox", "Connect"])
```

### Project Lookup (repo_lookup.toml)

The `scripts/repo_lookup.toml` maps project names/aliases to local repo paths:

```toml
[novalake]
edkrepo_name = 'NovaLakeJenkins'
aliases = ['nvl', 'novalakejenkins']
path_to_repo = 'C:\emb_donkey\repos\NovaLakeJenkins\Intel'
```

Update `path_to_repo` to match your local workspace location.

### Finding Modules by Name

To locate a specific module (INF) in the workspace:
1. Search for the module name: `grep -r "BASE_NAME.*=.*ModuleName" --include="*.inf"`
2. Find which DSC includes it: `grep -r "ModuleName.inf" --include="*.dsc"`
3. Find which FV dispatches it: `grep -r "ModuleName.inf" --include="*.fdf"`

---

## EFI Binary Symbol Lookup

UEFI `.efi` binaries are stripped PE images — no COFF symbol table, no exports. To find where a NASM assembly function lives inside the binary, use **byte-pattern matching** with `pefile`.

### Tool: `find_symbol.py`

Located at `.agents/skills/mermaid-developer/scripts/find_symbol.py`. Uses a signature table to locate functions:

```bash
python .agents/skills/mermaid-developer/scripts/find_symbol.py
```

### How It Works

1. Load the `.efi` with `pefile.PE()` and get the memory-mapped image
2. For each function, search for its unique first-N-bytes signature
3. Map the match offset (RVA) back to section name and file offset

### NASM Encoding Gotchas

NASM encodes instructions differently than MASM/Intel reference manuals suggest:

| Source Instruction | Expected Encoding | NASM Actual Encoding |
|---|---|---|
| `mov ebp, esp` | `8B EC` | `89 E5` |
| `mov rax, 0` / `mov rax, 0h` | `48 C7 C0 00 00 00 00` | `B8 00 00 00 00` (mov eax,0 — zero-extends) |
| `mov rax, [ecx+20h]` (64-bit mode with 32-bit addr) | `48 8B 41 20` | `67 48 8B 41 20` (67h addr-size override for ecx) |

Always verify signatures against the actual binary bytes, not the source mnemonics.

### Section Layout in MerlinX.efi

| Section | Content | Functions Found There |
|---|---|---|
| `.text` | Main C code + 32-bit NASM (BITS 32, SECTION .text) | CliSaveState, NativeBiosApi_* |
| `.code` | 64-bit NASM (SECTION .code) | Clix64RestoreState, CliRestoreState, Patch2/3_P/E, AsmPatch2/3 |
| `.data` | Runtime-patched code (32/64-bit mode-switch + Extended APIs) | GoToLongMode, ReturnFromLongMode, NasmDoorbell*, ExtendedBiosApi_* |

### Signature Disambiguation

- **Identical bodies**: `NasmDoorbellWrite64` and `NasmHeartbeat64` have the same instructions (`mov rcx,[addr]; mov [rcx],ebx; ret`). Disambiguate by RVA order — Write comes first in the source.
- **Shared prologues**: All three `ExtendedBiosApi_*` functions share the `SAVE_CONTENT_32_BIT_STATE` macro prologue. Find all instances of the prologue; the three hits in ascending RVA order are: DoorbellRead64, DoorbellWrite64, Heartbeat64.
- **Duplicate hits**: `AsmPatch2` (from AsmPatch23Lib) and `Patch2_P` (from Patch23Lib) have identical instruction sequences. Both hits at different RVAs are valid — they are separate compiled copies.

### Adding New Function Signatures

To add a new function to `find_symbol.py`:

1. Read the NASM source for the function's first few unique instructions
2. Hand-assemble or check the binary for the actual byte encoding (watch for NASM gotchas above)
3. Add an entry to the `SIGNATURES` list: `("FunctionName", bytes([...]), "description")`
4. Use at least 8-10 bytes for uniqueness; include distinctive instructions (CR moves, `patch2`/`patch3` opcodes `0F 0E`/`0F 0F`, `lfence`)
