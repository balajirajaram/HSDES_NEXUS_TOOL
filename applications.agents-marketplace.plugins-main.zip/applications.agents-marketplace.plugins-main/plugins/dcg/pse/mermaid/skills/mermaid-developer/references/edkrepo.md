# EdkRepo Domain Knowledge

EdkRepo is a multi-repository UEFI source management tool built on top of `git` and `gerrit`, implemented in Python. It manages branch combinations across multiple repositories using a Project Manifest XML file.

---

## Core Concepts

| Concept | Description |
|---|---|
| **Workspace** | Root directory containing cloned repositories plus a `repo/Manifest.xml` |
| **Combination** | A named set of branches (one per remote repo) from the manifest |
| **Manifest** | XML file (`Manifest.xml`) describing repos, branches, build groups, sparse settings |
| **CiIndex.xml** | Global index mapping project names to manifest file paths |
| **Global Manifest Repo** | Git repository containing all project manifests (`C:\ProgramData\edkrepo\manifest-master\`) |
| **Pin File** | Snapshot of SHAs for all repos at a specific point in time |
| **Sparse Checkout** | Limits checked-out files to only those needed for a specific project |

### Common Options (all commands)
- `-v / --verbose` — verbose output
- `-h / --help` — show help
- `-o / --override` — ignore warnings and proceed

---

## Commands Reference

### clone
Pull all repos for a project into a new workspace.

```
EdkRepo clone <Workspace> <ProjectNameOrManifestFile> [Combination]
              [--sparse] [--nosparse] [--skip-submodule]
```

**Resolution order:**
1. Project name in `CiIndex.xml`
2. Absolute path to manifest file
3. Relative path → current directory, then global manifest repo

### checkout
Switch branch combination in an existing workspace.

```
EdkRepo checkout <Combination | sha>
```

### checkout-pin  (alias: `chp`)
Restore a workspace to a saved pin state.

```
EdkRepo checkout-pin <pinfile>
```

Pin file search order: manifest pin path → global manifest repo → anywhere in workspace.

### sync
Fetch latest changes for all repos in the current combination.

```
EdkRepo sync [--fetch] [-u/--update-local-manifest] [-o/--override] [--skip-submodule]
```

### send-review  (alias: `sr`)
Submit changes to Gerrit for code review.

```
EdkRepo send-review [Repository] [-n/--noweb] [--reviewers] [--dry-run] [--override]
```

### bisect
Binary-search for a bad commit across all repos.

```
EdkRepo bisect [start | reset | good | bad] [commit]
```

### f2f-cherry-pick
Convert and cherry-pick commits from one project's folder layout to another.

```
EdkRepo f2f-cherry-pick [--template SRC:DST] [--folders ...] [--continue] [--abort] <Commit-ish>
```

### personal-build  (alias: `pb`)
Trigger a TeamCity personal build with local changes.

```
EdkRepo personal-build [<Tree-ish>] [--builds ...] [--heads] [-n/--noweb] [--dry-run]
```
Modes: **Staged Files** (default) | **Tree-ish** | **HEADs**

### create-pin  (alias: `crp`)
Snapshot current workspace state to a pin file.

```
EdkRepo create-pin <PinFileName> <Description> [--push]
```

### Other Commands
| Command | Purpose |
|---|---|
| `clean` | Delete untracked files (`--force`, `--dirs`) |
| `combo` | List all branch combinations in the workspace manifest |
| `geo` | View/select geographic mirror region |
| `log` | Unified cross-repo commit log sorted by date |
| `manifest` | List all projects in the global manifest repo |
| `reset` | Soft (or `--hard`) reset across all repos |
| `self-check` | Validate edkrepo installation and manifest connectivity |
| `shared-branch` | Create named remote branches (dev/po/release/platform/override) |
| `shelf` | Push/pull/apply/drop named stashes to a shared remote shelf |
| `sparse` | Enable or disable sparse checkout on an existing workspace |
| `squash` | Squash a range of commits into one new branch |
| `status` | Show current combination + git status across all repos |
| `update` | Check for and install new version of EdkRepo |
| `update-manifest-repo` (alias: `umr`) | Pull latest global manifest without a full clone |

---

## Exit Code Reference

| Code | Meaning |
|---|---|
| 0 | Success |
| 1 | General error |
| 101 | Invalid parameter |
| 102 | Global configuration not found |
| 103 | Configuration file invalid |
| 104 | Manifest invalid |
| 105 | Workspace invalid |
| 106 | Global data directory not found |
| 107 | Uncommitted changes present |
| 108 | Manifest not found for project |
| 109 | Manifest changed — operation blocked |
| 110 | WIT executable not found |
| 111 | No reviewers found |
| 112 | Config file is read-only |
| 113 | Project mismatch between manifest/pin |
| 114 | Manifest verification failed |
| 115 | Sparse checkout invalid combination |
| 118 | Workspace corrupt |
| 119 | Credential prompt cancelled |
| 127 | Mandatory update available (all cmds blocked except `update`) |
| 129 | Git exception |
| 130 | Git hooks from manifest not found |
