# Pre-Built Diagram Examples

Ready-to-use Mermaid diagrams for common EdkRepo workflows. Use these as starting points and adapt to the user's specific question.

## Example 1 — Clone Workflow

```mermaid
flowchart TD
    A([EdkRepo clone]) --> B{Input is project name?}
    B -- yes --> C{Found in CiIndex.xml?}
    C -- yes --> D[Load manifest from CiIndex.xml path]
    C -- no --> E{Absolute path provided?}
    E -- yes --> F[Load manifest at absolute path]
    E -- no --> G[Search relative to CWD]
    G --> H{Found?}
    H -- yes --> D
    H -- no --> I[Search in global manifest repo]
    I --> D
    B -- no --> E
    D --> J[Pull latest global manifest repo]
    J --> K[Create workspace + repo/Manifest.xml]
    K --> L{--sparse flag?}
    L -- yes --> M[Run DSC dependency checker]
    M --> N[Sparse checkout only required packages]
    L -- no --> O[Full checkout]
    N --> P{--skip-submodule?}
    O --> P
    P -- no --> Q[Init + sync submodules]
    P -- yes --> R[Install Gerrit client hooks]
    Q --> R
    R --> S([Workspace ready])
```

## Example 2 — Sync Workflow

```mermaid
flowchart TD
    A([EdkRepo sync]) --> B{--update-local-manifest?}
    B -- yes --> C[Pull latest global manifest repo]
    C --> D{Current combo still in manifest?}
    D -- no --> E([Abort: combo not found])
    D -- yes --> F[Update repo/Manifest.xml]
    B -- no --> F
    F --> G{Repo URLs changed in manifest?}
    G -- yes --> H([Abort: notify user of URL change])
    G -- no --> I[For each repo in current combination]
    I --> J{--fetch only?}
    J -- yes --> K[git fetch]
    J -- no --> L[git fetch + update local tracking branch]
    K --> M{Dynamic sparse checkout active?}
    L --> M
    M -- yes --> N[Re-run dependency checker, update sparse tree]
    M -- no --> O{--skip-submodule?}
    N --> O
    O -- no --> P[Sync submodules]
    O -- yes --> Q([Sync complete])
    P --> Q
```

## Example 3 — Send-Review Workflow

```mermaid
flowchart TD
    A([EdkRepo send-review]) --> B{Repository param provided?}
    B -- yes --> C[Use specified repository]
    B -- no --> D[Scan all workspace repos for local-only commits]
    D --> E{Multiple repos have changes?}
    E -- yes --> F([Error: specify one repository])
    E -- no --> C
    C --> G[Load current combination's target branch from Manifest.xml]
    G --> H{Local branch out of sync with target?}
    H -- yes --> I{--override?}
    I -- no --> J([Warn + abort: rebase required])
    I -- yes --> K
    H -- no --> K[Check for multiple local commits]
    K --> L{Multiple commits present?}
    L -- yes --> M{--override?}
    M -- no --> N([Warn + abort: squash required])
    M -- yes --> O
    L -- no --> O[Collect lead reviewers from manifest]
    O --> P[Match changed files against reviewers.ini rules]
    P --> Q[Add --reviewers CLI additions]
    Q --> R{Reviewers list empty?}
    R -- yes --> S([Error 111: no reviewers found])
    R -- no --> T[git push to Gerrit]
    T --> U{--noweb?}
    U -- no --> V[Open Gerrit review URL in browser]
    U -- yes --> W([Review submitted])
    V --> W
```

## Example 4 — Bisect Workflow

```mermaid
stateDiagram-v2
    [*] --> Idle
    Idle --> Active : bisect start\n(saves workspace state)
    Active --> Active : bisect good [commit]\n(mark revision good)
    Active --> Active : bisect bad [commit]\n(mark revision bad)
    Active --> Active : EdkRepo checks out midpoint revision\nacross all repositories
    Active --> Idle : bisect reset\n(restores workspace to start state)
    Active --> Found : good + bad revisions converge\n→ first bad commit identified

    note right of Active
        At any time:
        EdkRepo bisect
        shows current session status
    end note
```

## Example 5 — F2f Cherry-Pick Workflow

```mermaid
flowchart TD
    A([EdkRepo f2f-cherry-pick]) --> B{--template or --folders?}
    B -- template --> C[Look up FolderToFolderMapping in manifest]
    B -- folders --> D[Use CLI-provided folder pairs]
    C --> E[Resolve source → destination folder mapping]
    D --> E
    E --> F{Single commit or range?}
    F -- single --> G[Filter commit diff by mapped folders]
    F -- range --> H[Filter all commits, discard empty ones]
    H --> I[Squash remaining commits into one]
    I --> G
    G --> J[3-way merge into destination folder structure]
    J --> K{Merge conflict?}
    K -- yes --> L{User resolves conflict}
    L --> M{--continue or --abort?}
    M -- continue --> J
    M -- abort --> N([Restore pre-cherry-pick state])
    K -- no --> O{-x flag and single commit?}
    O -- yes --> P[Append cherry-pick source SHA to commit message]
    O -- no --> Q[Commit cherry-picked change]
    P --> Q
    Q --> R([Cherry-pick complete])
```

## Example 6 — Personal-Build Mode Selection

```mermaid
flowchart TD
    A([EdkRepo personal-build]) --> B{--heads flag?}
    B -- yes --> C[HEADs Mode:\nSend current HEAD state\nof all repos to TeamCity]
    B -- no --> D{tree-ish arg provided?}
    D -- yes --> E[Tree-ish Mode:\nWorkspace must be clean\nSend specified tree-ish to TeamCity]
    D -- no --> F{Staged files present?}
    F -- yes --> G[Staged Files Mode:\nSend staged files as patch\non top of workspace state]
    F -- no --> H[Staged Files Mode:\nFall back → use HEAD commit\nas implicit tree-ish]
    C --> I[Compute applicable build targets\nvia manifest + sparse settings]
    E --> I
    G --> I
    H --> I
    I --> J{--dry-run?}
    J -- yes --> K([Print target list, no build triggered])
    J -- no --> L{--builds filter?}
    L -- yes --> M[Restrict to specified build subset]
    L -- no --> N[Run all applicable TeamCity builds]
    M --> N
    N --> O{--noweb?}
    O -- no --> P[Open TeamCity build page in browser]
    O -- yes --> Q([Personal build triggered])
    P --> Q
```

## Example 7 — Project Manifest File Structure

```mermaid
classDiagram
    class Manifest {
        +repo/Manifest.xml
    }
    class ProjectInfo {
        +CodeName: string
        +Description: string
        +DevLead: idsid
        +Org: string
        +ShortName: string
    }
    class LeadReviewers {
        +Idsid[]: string
    }
    class GeneralConfig {
        +PinPath: string
        +DefaultCombo: string
        +CurrentClonedCombo: string
        +WitConfigPath: string
    }
    class SparseCheckout {
        +useDsc: bool
        +sparseByDefault: bool
    }
    class SparseData {
        +remote: string
        +AlwaysInclude[]: string
        +AlwaysExclude[]: string
    }
    class RemoteList {
    }
    class Remote {
        +name: string
        +url: string
    }
    class CombinationList {
    }
    class Combination {
        +name: string
        +description: string
    }
    class Source {
        +localRoot: string
        +remote: string
        +branch: string
        +sparseCheckout: bool
        +enableSubmodule: bool
    }
    class DscList {
        +Dsc[]: path
    }
    class FolderToFolderMapping {
        +project1: string
        +project2: string
        +remote: string
    }
    class BuildServerList {
    }
    class BuildServer {
        +name: string
        +url: string
    }
    class BuildGroupList {
    }
    class BuildGroup {
        +name: string
        +buildServer: string
        +projectPath: string
    }
    class BuildTargetList {
    }
    class BuildTarget {
        +name: string
        +type: all|review|post
    }

    Manifest --> ProjectInfo
    Manifest --> GeneralConfig
    Manifest --> SparseCheckout
    Manifest --> RemoteList
    Manifest --> CombinationList
    Manifest --> DscList
    Manifest --> FolderToFolderMapping
    Manifest --> BuildServerList
    Manifest --> BuildGroupList
    Manifest --> BuildTargetList
    ProjectInfo --> LeadReviewers
    SparseCheckout "1" --> "0..*" SparseData
    RemoteList "1" --> "1..*" Remote
    CombinationList "1" --> "1..*" Combination
    Combination "1" --> "1..*" Source
    BuildServerList "1" --> "1..*" BuildServer
    BuildGroupList "1" --> "1..*" BuildGroup
    BuildTargetList "1" --> "1..*" BuildTarget
```

## Example 8 — Shelf Workflow

```mermaid
sequenceDiagram
    participant Dev as Developer
    participant EdkRepo
    participant Remote as Remote Git Server

    Note over Dev,Remote: Push a shelved branch
    Dev->>EdkRepo: edkrepo shelf push [--branch-name X]
    EdkRepo->>Remote: git push refs/shelf/<idsid>/<ref>
    Remote-->>Dev: Branch shelved

    Note over Dev,Remote: List available shelves
    Dev->>EdkRepo: edkrepo shelf list [--all]
    EdkRepo->>Remote: git ls-remote refs/shelf/
    Remote-->>Dev: List of shelved references

    Note over Dev,Remote: Apply shelved changes
    Dev->>EdkRepo: edkrepo shelf apply <reference>
    EdkRepo->>Remote: git fetch refs/shelf/<idsid>/<ref>
    EdkRepo->>EdkRepo: Apply commits on top of current branch
    EdkRepo-->>Dev: Changes applied

    Note over Dev,Remote: Pop (fetch + drop)
    Dev->>EdkRepo: edkrepo shelf pop <reference>
    EdkRepo->>Remote: git fetch + delete remote ref
    EdkRepo-->>Dev: Branch popped and removed from shelf
```
