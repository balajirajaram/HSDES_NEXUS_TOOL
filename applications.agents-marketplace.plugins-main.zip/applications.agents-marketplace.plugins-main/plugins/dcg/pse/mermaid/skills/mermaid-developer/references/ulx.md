# ULX Domain Knowledge

**ULX** (One-Way X2APIC Unlocker, v1.44) is a UEFI shell application (`ulx.efi`) that disables the one-way X2APIC lock on Intel processors. X2APIC mode normally has a permanent lock — once enabled it cannot be disabled. ULX bypasses this using per-stepping **recipes** (MSR address + code + bit) looked up from a platform-specific `.ini` info file.

Source: `MerlinX/SvRestricted/Core/ulx/`

---

## Architecture

| File | Purpose |
|---|---|
| `ulx.c` | Entry point, command-line parsing, orchestration of the full unlock flow |
| `Metal.c/.h` | CPUID queries, hybrid P/E core detection, recipe check/write to MSRs |
| `ThreadInfo.c/.h` | Per-thread state struct, reporting, recipe lookup from info file |
| `ThreadAction.c/.h` | Per-core AP functions dispatched via MP Services (`CoreGetCpuIdInfo`, `CoreSetGlobalSvBit`, `CoreDisableX2ApicLock`) |
| `ParseInfoFile.c/.h` | INI file parser for platform info files |
| `Recipe.h` | `Patch23Recipe` struct: `{mAddr, mCode, mBit, mPolarity, mValid}` |
| `PlatformInfo/` | Platform-specific `.ini` files with CPUID→recipe mappings |

---

## Key Data Structures

| Structure | Fields | Purpose |
|---|---|---|
| `ThreadInfo` | `mThreadIdx`, `mApicId`, `mCoreId`, `mCoreDef`, `mCoreName`, `mCoreStep`, `mCorePE`, `mXApicUnlockRecipe`, `mDoLookupInfo`, `mDoGlobalSv`, `mResult` | Per-thread state: silicon info + recipe + progress |
| `Patch23Recipe` | `mAddr` (MSR), `mCode`, `mBit`, `mPolarity`, `mValid` | The MSR write recipe that unlocks X2APIC |
| `CheckList` enum | `Ck_ToDo`, `Ck_Done`, `Ck_Skip`, `Ck_NoAp`, `Ck_Prev`, `Ck_Errr` | Step progress tracking |
| `DisableResults` enum | `Dr_ToDo`, `Dr_Done`, `Dr_Skip`, `Dr_Prev`, `Dr_NotPCore`, `Dr_NotECore`, `Dr_NotX2Apic`, `Dr_NotLocked`, `Dr_CantUnlock`, `Dr_BadCoreType`, `Dr_NoRecipe`, `Dr_Error` | Per-thread unlock outcome |

---

## Command Line

```
ulx.efi [-h] [-info <file>] [-cpu <name>] [-defs] [-gsv] [-walk] [-scout] [-quiet]
```

| Flag | Action |
|---|---|
| `-info <file>` | Platform info `.ini` file with CPUID→recipe mappings |
| `-cpu <name>` | Platform/CPU section name in the info file |
| `-gsv` | Set global SV bit on E-cores |
| `-scout` | Explore mode: gather CPUID/CoreID without unlocking |
| `-walk` | Test mode: launch all threads without writing the unlock |
| `-defs` | List available platform definitions in the info file |
| `-quiet` | Suppress output during unlock |

---

## Execution Flow

**Entry:** `ulxEntryPoint` → `UlxShell()` → `Ulx()` → `DoUnlock()`

**`DoUnlock()` sequence:**

1. **`MpGetCpuIdInfo`** — Dispatch `CoreGetCpuIdInfo` to each AP via `StartupThisAP`; collect APIC IDs and Core IDs
2. **`MpLookupCoreInfo`** — Match each core against the `.ini` info file to find the correct `Patch23Recipe`
3. **`MpSetGlobalSvBit`** — (if `-gsv`) Dispatch `CoreSetGlobalSvBit` to each AP; enables SV global bit on E-cores
4. **`MpDisableLock`** — Dispatch `CoreDisableX2ApicLock` to each AP; writes recipe MSR on the target core
5. **`MpReportInfo`** — Tally results: done / skipped / already-unlocked / failed

**MP Dispatch pattern:** For each core, check `WhoAmI` — if BSP, call directly; otherwise `StartupThisAP`. MSR writes must execute on the target core itself.

**`UlxShell()` shortcut paths:**

- `-h` → `ShowHelp()` → exit
- `-scout` → `DoScout()` (gather + report only) → exit
- `-gsv` without `-info` → `DoGsv()` (set SV bits only) → exit
- `-defs` → `ListPlatforms()` → exit
- Otherwise → `Ulx()` (full unlock)

---

## Pre-Built Diagrams

### Full Unlock Flow

```mermaid
flowchart TD
    A([ulxEntryPoint]) --> B[ReadCommandLine]
    B --> C{-h flag?}
    C -- yes --> D[ShowHelp] --> Z([Return])
    C -- no --> E[MpInit]
    E --> F{-scout?}
    F -- yes --> G[DoScout: gather CPUID info] --> Z
    F -- no --> H{-info provided?}
    H -- no --> I{-gsv only?}
    I -- yes --> J[DoGsv: set SV bits] --> Z
    I -- no --> K[Error: missing -info] --> Z
    H -- yes --> L[LoadInfoFile]
    L --> M{-defs?}
    M -- yes --> N[ListPlatforms] --> Z
    M -- no --> O[Ulx]
    O --> P[VerifySilicon: CPUID check]
    P --> Q[DoUnlock]
    Q --> Q1[MpGetCpuIdInfo]
    Q1 --> Q2[MpLookupCoreInfo]
    Q2 --> Q3[MpSetGlobalSvBit]
    Q3 --> Q4[MpDisableLock]
    Q4 --> Q5[MpReportInfo]
    Q5 --> Z
```

### Per-Core MP Dispatch

```mermaid
sequenceDiagram
    participant ULX as ulx.c orchestrator
    participant MP as EFI_MP_SERVICES
    participant BSP as BSP Thread
    participant AP as AP Thread N

    ULX->>MP: WhoAmI()
    MP-->>ULX: bspIndex

    loop For each enabled processor
        alt coreIdx == bspIndex
            ULX->>BSP: CoreDisableX2ApicLock(ti)
            BSP->>BSP: Read CoreId, check recipe
            BSP->>BSP: WriteRecipe(MSR addr, code, bit)
            BSP-->>ULX: result in ThreadInfo
        else coreIdx != bspIndex
            ULX->>MP: StartupThisAP(CoreDisableX2ApicLock, coreIdx, ti)
            MP->>AP: dispatch to AP
            AP->>AP: Read CoreId, check recipe
            AP->>AP: WriteRecipe(MSR addr, code, bit)
            AP-->>ULX: result in ThreadInfo
        end
    end
    ULX->>ULX: MpReportInfo: tally done/skip/prev/fail
```

### ThreadInfo State Machine

```mermaid
stateDiagram-v2
    [*] --> Ck_ToDo : allocated
    Ck_ToDo --> Ck_Done : step succeeded
    Ck_ToDo --> Ck_Errr : step failed
    Ck_ToDo --> Ck_Skip : not applicable

    state "DisableResults" as DR {
        [*] --> Dr_ToDo
        Dr_ToDo --> Dr_Done : recipe written
        Dr_ToDo --> Dr_Prev : already unlocked
        Dr_ToDo --> Dr_Skip : walk mode
        Dr_ToDo --> Dr_NotPCore : E-core only path
        Dr_ToDo --> Dr_NotLocked : X2APIC not locked
        Dr_ToDo --> Dr_NoRecipe : no recipe in info file
        Dr_ToDo --> Dr_CantUnlock : recipe write failed
    }
```

---

## Version History

| Version | Change |
|---|---|
| 1.00 | RWC-only processors |
| 1.10/1.20 | ApicId table lookups (deprecated) |
| 1.30 | CoreId lookups |
| 1.40 | ArrowLake-S support |
| 1.41 | Filename bug fix, GraniteRapids release |
| 1.42 | Atom core Patch2/3 fix for LNL |
| 1.43 | Fix last line in .ini file without newline |
| 1.44 | `-quiet` parameter and application return value |
