# ValidationMegaBlock (VMB) Domain Knowledge

**ValidationMegaBlock** (VMB) is a UEFI PEI Module (PEIM) that reserves large contiguous memory blocks for bare-metal silicon validation. It runs early in the PEI phase — immediately after memory discovery — and carves out reserved regions in three address zones (below 1 MB, 1 MB–4 GB, above 4 GB) by manipulating HOBs (Hand-Off Blocks). These reserved blocks are later used by MerlinX test content for scratch memory, trace buffers, and data structures.

Source: `MerlinX/SvRestricted/Core/ValidationMegaBlock/`

---

## Module Specification

| Field | Value |
|---|---|
| **Module Type** | PEIM (Pre-EFI Initialization Module) |
| **Base Name** | ValidationMegaBlock |
| **File GUID** | `D732566C-BA66-4F94-B68A-BE4FE7CBA58D` |
| **Entry Point** | `ValidationMegaBlockEntryPoint()` |
| **Dependency** | `gEfiPeiMemoryDiscoveredPpiGuid` (waits for memory discovery) |

---

## Architecture

| File | Purpose |
|---|---|
| `ValidationMegaBlock.c` | Entry point, HOB parsing, memory carving via `ConstructMegablockHob()` |
| `ValidationMegaBlock.h` | `VALIDATION_MEGA_BLOCK20`, `MEGABLOCK_TYPE`, `MEGABLOCK_RECORD`, `MEGABLOCK_DATA` |
| `ValidationMegaBlock.inf` | UEFI module descriptor (PPIs, GUIDs, PCDs, library deps) |
| `ValidationMegaBlock.dec` | Package declarations (GUIDs, PCDs) |
| `xValidationMegaBlock.dsc` | Platform build descriptor |

---

## Key Data Structures

### VALIDATION_MEGA_BLOCK20 (HOB Configuration)

Read from `gMegaBlockHobGuid` during PEI. Defines what memory regions to reserve.

```c
typedef struct {
  UINT32   Revision;                  // Version (current = 2)
  UINT64   SizeAboveOneMega;          // Block size in 1MB–4GB region
  UINT64   SizeAboveFourGiga;         // Block size > 4GB
  UINT64   SizeBelowOneMega;          // Block size < 1MB
  // V2.0+ fields:
  BOOLEAN  HangOnAllocationFailure;   // Halt if allocation fails
  UINT64   BaseAboveOneMega;          // Base address for 1MB block
  UINT64   BaseAboveFourGiga;         // Base address for 4GB block
  UINT64   BaseBelowOneMega;          // Base address for < 1MB block
  UINT8    PolicyUsedAboveOneMega;    // EFI memory type when used
  UINT8    PolicyUsedAboveFourGiga;
  UINT8    PolicyUsedBelowOneMega;
  UINT8    PolicyUnUsedAboveOneMega;  // EFI memory type when unused
  UINT8    PolicyUnUsedAboveFourGiga;
  UINT8    PolicyUnUsedBelowOneMega;
} VALIDATION_MEGA_BLOCK20;
```

### MEGABLOCK_TYPE Enum

```c
typedef enum {
  megablock_type_none,            // 0 — Not used
  megablock_type_below_one_meg,   // 1 — < 1MB region
  megablock_type_above_one_meg,   // 2 — 1MB–4GB region
  megablock_type_above_four_gig,  // 3 — > 4GB region
  megablock_type_any,             // 4 — Any type
} MEGABLOCK_TYPE;
```

### MEGABLOCK_RECORD (Runtime per-block state)

```c
typedef struct {
  UINT64   mBase;          // Base address
  UINT64   mSize;          // Size in bytes
  BOOLEAN  mAllocError;    // Allocation failed
  UINT8    mPolicyUsed;    // EFI memory type when used
  UINT8    mPolicyUnused;  // EFI memory type when unused
} MEGABLOCK_RECORD;
```

### MEGABLOCK_DATA (Aggregate runtime state)

```c
typedef struct {
  UINT32           mVersion;                        // Structure version
  UINT32           mSize;                           // Total size
  UINT32           mCount;                          // Number of megablocks (max 3)
  MEGABLOCK_RECORD mMegablocks[MEGABLOCK_TYPE_MAX]; // Array of 3 blocks
  BOOLEAN          mEnabled;                        // Any block enabled?
  BOOLEAN          mForceHang;                      // Hang on allocation failure?
} MEGABLOCK_DATA;
```

### Constants

```c
#define VALIDATION_MEGABLOCK_REVISION20   2
#define MEGA_1_BELOW_ONE_START_ADDRESS    0x60000       // 384KB
#define HANG_ON_FAILURE_BIT               (1 << 1)
#define MEGABLOCK_TYPE_MAX                3              // 3 block types
#define BASE_4GB                          0x100000000
#define BASE_1MB                          0x100000
```

---

## GUIDs and PCDs

### GUIDs

| GUID | Purpose |
|---|---|
| `gValidationMegaBlockSpaceGuid` | Package token space |
| `gMegaBlockHobGuid` | HOB containing `VALIDATION_MEGA_BLOCK20` config |

### PCDs (Platform Configuration Data)

| PCD | Purpose |
|---|---|
| `PcdBelowOneMega` | VMB size below 1 MB |
| `PcdAboveOneMega` | VMB size above 1 MB |
| `PcdAboveFourGiga` | VMB size above 4 GB |
| `PcdTotalSystemIPAllocatedMemory` | Total memory allocated by PSMI/Tracehub |

---

## Execution Flow

**Entry:** `ValidationMegaBlockEntryPoint()` — called after `gEfiPeiMemoryDiscoveredPpiGuid` is signaled.

1. **Locate HOB** — Find `gMegaBlockHobGuid` in the HOB list
2. **Extract config** — Read `VALIDATION_MEGA_BLOCK20` from HOB data
3. **Validate revision** — Upgrade v1.0 → v2.0 if needed
4. **For each of three memory regions** (Above4G, Above1M, Below1M):
   a. Read base address and memory type policy from config
   b. If size > 0, call `ConstructMegablockHob()`
   c. On failure: mark allocation as `(UINT64)-1`
   d. If `HangOnAllocationFailure`: write `0xEBBE` to port `0x80` and `ASSERT()`
5. **Return `EFI_SUCCESS`** (even on allocation failures, unless hang is requested)

### ConstructMegablockHob() — Memory Carving Algorithm

```c
EFI_STATUS ConstructMegablockHob(
  CHAR8           *MegaBlockStr,   // "Below1Meg", "Above1Meg", "Above4G"
  UINT64          BaseAddress,     // Must be page-aligned (4KB)
  UINT64          MemoryLength,    // Must be page-aligned
  EFI_MEMORY_TYPE UsedMemoryType   // EfiReservedMemoryType, etc.
)
```

**Algorithm:**

1. **Validate** — Base and length must be 4KB page-aligned (`0x1000`)
2. **GCD Search** — Iterate `EFI_HOB_TYPE_RESOURCE_DESCRIPTOR` entries to find `EFI_RESOURCE_SYSTEM_MEMORY` containing the block; mark as `TESTED`
3. **Memory Allocation Search** — Iterate `EFI_HOB_TYPE_MEMORY_ALLOCATION` entries to find `EfiConventionalMemory` encompassing the block
4. **Carve block** — Handle four placement cases:
   - **Case 1:** Block in middle of HOB → split: keep before, create after
   - **Case 2:** Block at start of HOB → adjust original HOB forward
   - **Case 3:** Block at end of HOB → shrink original HOB
   - **Case 4:** Block spans entire HOB → replace entirely
5. **Create HOB** — `BuildMemoryAllocationHob()` with the desired memory type policy

**Error returns:** `EFI_INVALID_PARAMETER` (misaligned), `EFI_NOT_FOUND` (no GCD resource), `EFI_OUT_OF_RESOURCES` (no conventional memory)

---

## HOB Manipulation

VMB performs extensive Hand-Off Block manipulation during PEI:

| HOB Type | Purpose | VMB Action |
|---|---|---|
| `EFI_HOB_TYPE_RESOURCE_DESCRIPTOR` | GCD memory map | Search for `EFI_RESOURCE_SYSTEM_MEMORY`; mark `TESTED` |
| `EFI_HOB_TYPE_MEMORY_ALLOCATION` | Memory regions | Search `EfiConventionalMemory`; split/adjust/replace |
| `EFI_HOB_TYPE_GUID_EXTENSION` | Custom data | Read VMB config from `gMegaBlockHobGuid` |

`DumpHobList()` prints all HOBs for debug (when `MDEPKG_NDEBUG` is not defined).

---

## Interaction with ValSharedMailbox (VSM)

VMB reserves memory blocks that are later registered in the ValSharedMailbox as entries with specific signatures. The VSM protocol provides the runtime interface for MerlinX components to discover and use these blocks.

See [vsm.md](vsm.md) for the ValSharedMailbox protocol, entry signatures, and data structures.

Key VMB-related VSM signatures:
- `VSMB_SIG_MMIO_BLOCK` (`0xFACEB00C`) — MMIO memory block
- `VSMB_SIG_SHARED_MAILBOX` (`0xBA5EBA11`) — Shared mailbox base

---

## Pre-Built Diagrams

### VMB Execution Flow

```mermaid
flowchart TD
    A([ValidationMegaBlockEntryPoint]) --> B[Locate gMegaBlockHobGuid]
    B --> C{HOB found?}
    C -- no --> Z([Return EFI_SUCCESS])
    C -- yes --> D[Extract VALIDATION_MEGA_BLOCK20]
    D --> E{Revision == 2?}
    E -- no --> F[Upgrade v1 to v2 defaults]
    E -- yes --> G[Process three regions]
    F --> G

    G --> H[Above 4GB region]
    G --> I[Above 1MB region]
    G --> J[Below 1MB region]

    H --> K{Size > 0?}
    I --> K
    J --> K
    K -- no --> L[Skip]
    K -- yes --> M[ConstructMegablockHob]
    M --> N{Success?}
    N -- yes --> O[Block reserved]
    N -- no --> P[Mark alloc error]
    P --> Q{HangOnFailure?}
    Q -- yes --> R[Port 0x80 = 0xEBBE, ASSERT]
    Q -- no --> L
    L --> Z
    O --> Z
```

### ConstructMegablockHob — HOB Carving

```mermaid
flowchart TD
    A([ConstructMegablockHob]) --> B{Page-aligned?}
    B -- no --> ERR1([EFI_INVALID_PARAMETER])
    B -- yes --> C[Search RESOURCE_DESCRIPTOR HOBs]
    C --> D{Found SYSTEM_MEMORY containing block?}
    D -- no --> ERR2([EFI_NOT_FOUND])
    D -- yes --> E[Mark resource TESTED]
    E --> F[Search MEMORY_ALLOCATION HOBs]
    F --> G{Found EfiConventionalMemory containing block?}
    G -- no --> ERR3([EFI_OUT_OF_RESOURCES])
    G -- yes --> H{Where is block in HOB?}

    H -- middle --> I[Case 1: Split HOB, keep before and after]
    H -- start --> J[Case 2: Adjust HOB forward]
    H -- end --> K[Case 3: Shrink HOB]
    H -- entire --> L[Case 4: Replace HOB]

    I --> M[BuildMemoryAllocationHob]
    J --> M
    K --> M
    L --> M
    M --> Z([EFI_SUCCESS])
```

### VMB Memory Layout

```mermaid
classDiagram
    class MEGABLOCK_DATA {
        +UINT32 mVersion
        +UINT32 mCount
        +BOOLEAN mEnabled
        +BOOLEAN mForceHang
        +MEGABLOCK_RECORD[] mMegablocks
    }

    class MEGABLOCK_RECORD {
        +UINT64 mBase
        +UINT64 mSize
        +BOOLEAN mAllocError
        +UINT8 mPolicyUsed
        +UINT8 mPolicyUnused
    }

    class VALIDATION_MEGA_BLOCK20 {
        +UINT32 Revision
        +UINT64 SizeBelowOneMega
        +UINT64 SizeAboveOneMega
        +UINT64 SizeAboveFourGiga
        +BOOLEAN HangOnAllocationFailure
        +UINT64 BaseBelowOneMega
        +UINT64 BaseAboveOneMega
        +UINT64 BaseAboveFourGiga
    }

    MEGABLOCK_DATA "1" --> "3" MEGABLOCK_RECORD : mMegablocks
    VALIDATION_MEGA_BLOCK20 ..> MEGABLOCK_DATA : configures
```

### VMB in Boot Flow Context

```mermaid
sequenceDiagram
    participant BIOS as BIOS PEI Core
    participant MRC as Memory Reference Code
    participant VMB as ValidationMegaBlock PEIM
    participant HOB as HOB List
    participant VSM as ValSharedMailbox

    BIOS->>MRC: Initialize memory
    MRC->>HOB: Create RESOURCE_DESCRIPTOR HOBs
    MRC->>HOB: Create MEMORY_ALLOCATION HOBs
    MRC-->>BIOS: Signal gEfiPeiMemoryDiscoveredPpiGuid

    BIOS->>VMB: Dispatch (dependency satisfied)
    VMB->>HOB: Read gMegaBlockHobGuid config
    HOB-->>VMB: VALIDATION_MEGA_BLOCK20

    loop For each region (Above4G, Above1M, Below1M)
        VMB->>HOB: Search RESOURCE_DESCRIPTOR
        VMB->>HOB: Search MEMORY_ALLOCATION
        VMB->>HOB: Split/adjust conventional memory HOB
        VMB->>HOB: BuildMemoryAllocationHob (reserved)
    end

    Note over VMB,VSM: Later in DXE phase
    VSM->>HOB: Discover reserved blocks
    VSM->>VSM: Register as VSMB entries
```
