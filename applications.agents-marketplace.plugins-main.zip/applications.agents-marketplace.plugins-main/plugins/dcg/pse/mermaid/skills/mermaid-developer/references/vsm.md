# ValSharedMailbox (VSM) Domain Knowledge

**ValSharedMailbox** (VSMB / VSM) is a UEFI DXE driver that provides a shared memory mailbox for communication between MerlinX BIOS-side components and external host tools (xMon, PythonSV, XmlCli). The mailbox is a compact 512-byte table containing a 32-byte header followed by up to 30 entries (16 bytes each), with each entry registering a named memory region (DRAM, MMIO, or I/O) using a signature-based lookup. A legacy BIOS info record sits at offset `0x200` past the mailbox base.

Source: `MerlinX/SvRestricted/Core/ValSharedMailbox/`

---

## Module Specification

| Field | Value |
|---|---|
| **Module Type** | DXE_DRIVER |
| **Base Name** | ValSharedMailbox |
| **Protocol GUID** | `gValSmbProtocolGuid` = `{86d520a1-03d1-4b57-88cd-cab08ad0dfe1}` |
| **Entry Point** | `ValSharedMailboxEntryPoint()` |
| **Unload** | `ValSharedMailboxUnloadPoint()` |
| **Spec Version** | 0.8.0 |
| **Protocol Version** | 3 |

---

## Architecture

| File | Purpose |
|---|---|
| `ValSharedMailboxDxe.c` | DXE driver entry/unload, protocol installation, global contexts |
| `ValSharedMailboxProtocol.c` | Protocol function implementations (`Connect`, `SyncHifMailbox`, etc.) |
| `ValSharedMailboxLib.c/.h` | Core library: context management, entry CRUD, lock/unlock, allocation (~1700 lines) |
| `Include/ValSharedMailboxDef.h` | Header/entry structs, lock states, constants |
| `Include/ValSharedMailboxProtocol.h` | Protocol struct with all function pointers |
| `Include/ValSharedMailboxSignatures.h` | Entry signature `#define`s and description lookup |
| `Include/ValLegacyBiosInfo.h` | `ValBiosInfoRecord` struct at offset `0x200` |
| `ValSharedMailboxCmos.c/.h` | CMOS address persistence (ports `0x72`/`0x73`, registers `0xF0`/`0xF1`) |
| `ValSharedMailboxSignatures.c` | `VSMB_SIG_GetDescription()` — human-readable signature names |
| `ValLegacyBiosInfo.c` | `ValBiosInfo_Init`, `ValBiosInfo_Sync`, `ValBiosInfo_Print` |
| `VsmbChecker.c/.inf` | Standalone UEFI shell checker/diagnostic tool |

---

## Memory Layout

```
Offset  Content
──────  ─────────────────────────────────────────
0x000   ValSmbTableHeader (32 bytes)
0x020   Entry 0  (16 bytes)
0x030   Entry 1  (16 bytes)
  ...   Up to 30 entries
0x1F0   Entry 29 / END_OF_TABLE terminator
──────  ─────────────────────────────────────────
0x200   ValBiosInfoRecord (96 bytes) — Legacy BIOS info
──────  ─────────────────────────────────────────
        Max VSMB table size: 0x200 (512 bytes)
        Legacy MMIO area size: 0x3E00
        Required alignment: 16 KB (kValSmbMemAlignment)
```

---

## Key Data Structures

### ValSmbTableHeader (32 bytes)

```c
typedef struct {
    UINT32 BIOS_Signature;           // 0xBA5EBA11
    struct {
        UINT8  EntriesNumber;        // Number of used entries
        UINT8  FirstEntryOffset;     // Offset to first entry (0x20)
        UINT8  EntrySize;            // 0x10 (16 bytes)
        UINT8  Reserved     : 6;
        UINT8  ValidHeader  : 2;     // Lock state (0/1/2)
    } EntriesInfo;
    UINT32 BIOS_Signature2;          // 0xBA5EBA11 (duplicate)
    UINT32 CheckSum;
    struct {
        UINT32 BarBlockSize : 8;     // BAR size in KB
        UINT32 DevId        : 16;    // HIF device ID
        UINT32 BarId        : 4;     // HIF BAR ID
        UINT32 Reserved1    : 4;
    } CommonFlags;
    ValSmbSpecVersionType SvBiosSpecVersion;
    UINT32 Reserved[2];
} ValSmbTableHeader;
```

### ValSmbTableEntry (16 bytes)

```c
typedef struct {
    UINT32 Signature;   // Entry type identifier
    UINT32 Data1;       // Address/offset (low 32 bits)
    UINT32 Data2;       // Size
    UINT32 Data3;       // Flags (block type, DevId, BarId)
} ValSmbTableEntry;
```

### ValSmbTableEntryFlags

```c
typedef struct {
    union {
        struct {
            UINT32 BlockType :  3;   // 0=DRAM, 1=MMIO, 2=IO
            UINT32 Reserved  :  5;
            UINT32 DevId     : 16;
            UINT32 BarId     :  4;
            UINT32 Reserved2 :  4;
        } fields;
        UINT32 u32;
    } flags;
} ValSmbTableEntryFlags;
```

### ValSmbLockState

```c
typedef enum {
    VSmb_State_NotReady = 0,   // Not initialized
    VSmb_State_Ready    = 1,   // Ready for operations
    VSmb_State_Locked   = 2,   // Locked for modification
} ValSmbLockState;
```

### ValSmbContext (Library-side working state)

```c
typedef struct {
    ValSmbTableHeader* mValSmbTableBaseAddr;     // Pointer to header
    ValSmbTableEntry*  mValSmbTableFirstEntry;   // Pointer to first entry
    UINT32 mValSmbTableMaxEntries;               // Max entries (30)
    UINT32 mValSmbTableSize;                     // Total size (0x200)

    UINT32 mOwnsAllocationVsmb;                  // Owns VSMB memory
    UINT32 mOwnsAllocationBiosInfo;              // Owns BiosInfo buffer
    UINT32 mOwnsAllocationPcXml;                 // Owns PcXml buffer
    UINT32 mOwnsAllocationCliReq;                // Owns CLI request buffer
    UINT32 mOwnsAllocationCliRsp;                // Owns CLI response buffer
    UINT32 mOwnsAllocationCliObj;                // Owns CLI object buffer

    UINT8  mCnxCountBiosInfo;                    // Connection ref count
    UINT8  mCnxCountPcXml;
    UINT8  mCnxCountCliReq;
    UINT8  mCnxCountCliRsp;
    UINT8  mCnxCountCliObj;

    CHAR8  mValSmb_SpecVersionString[12];        // "0.8.0"
    BOOLEAN mAllocateHiMemBuffers;               // Allow >4G allocation
} ValSmbContext;
```

### ValBiosInfoRecord (96 bytes at offset 0x200)

```c
typedef struct {
    UINT32 mHeartbeat;               // 0x00  Last heartbeat value
    UINT32 mReserved04;              // 0x04
    UINT32 mReserved08;              // 0x08
    UINT32 mPcXml;                   // 0x0C  Pointer to PlatformConfig.xml

    UINT16 mLtResetFlag;             // 0x10  0x26 if LT recovery
    UINT16 mBootStatus;              // 0x12  0xF6 = ready
    UINT16 mMerlinXMinor;            // 0x14
    UINT16 mMerlinXMajor      : 14;  // 0x16
    UINT16 mMerlinXOfcBuild   :  1;  // Official build flag
    UINT16 mMerlinXRelBuild   :  1;  // Release build flag
    UINT16 mMerlinXApiMinor;         // 0x18
    UINT16 mMerlinXApiMajor;         // 0x1A

    UINT32 mSmBaseReloc       :  1;  // 0x28:0  SmBase relocated
    UINT32 mXmlCliActive      :  1;  // 0x28:1  XmlCli active
    UINT32 mDciActive         :  1;  // 0x28:2  DCI as host interface
    UINT32 mDciGeneration     :  3;  // 0x28:3  DCI generation

    UINT32 mPrPost;                  // 0x32  Reset indicator
    UINT32 mBiosKnobs;               // 0x50  BIOS knobs file pointer
    UINT32 mBiosKnobsCmp;            // 0x5C  Compressed knobs pointer
} ValBiosInfoRecord;
```

---

## Entry Signatures

| Signature | Value | Description |
|---|---|---|
| `VSMB_SIG_SHARED_MAILBOX` | `0xBA5EBA11` | Mailbox base address (self-reference) |
| `VSMB_SIG_BIOS_INFO` | `0x5A7ECAFE` | Legacy BIOS info record |
| `VSMB_SIG_BIOS_API` | `0x3554A458` | BIOS API interface |
| `VSMB_SIG_PCXML_BUFFER` | `0x61C04F1C` | PlatformConfig.xml buffer |
| `VSMB_SIG_CLI_REQ_BUFFER` | `0xCA11AB1E` | CLI request buffer |
| `VSMB_SIG_CLI_RSP_BUFFER` | `0xCA11B0B0` | CLI response buffer |
| `VSMB_SIG_CLI_OBJ_BUFFER` | `0x0B76A6EA` | OBJ load buffer |
| `VSMB_SIG_SUMMARY_SCREEN` | `0x5CEE5CEE` | Summary screen |
| `VSMB_SIG_HOST_CARD_ADDR` | `0x4057CA9D` | Host card address |
| `VSMB_SIG_IO_BLOCK` | `0x1A571EAF` | HIF I/O block |
| `VSMB_SIG_MMIO_BLOCK` | `0xFACEB00C` | HIF MMIO block |
| `VSMB_SIG_KFIR_NT_SUPPORT` | `0x5A7E0002` | KFIR NT support |
| `VSMB_SIG_XML_CLI_DISABLED` | `0xCD15A1ED` | XmlCli disabled flag |
| `VSMB_COMPRESSED_IMAGES_BUFFER` | `0xCAC7EDD9` | Compressed OBJ buffer |
| `VSMB_SIG_END_OF_TABLE` | `0xDEADBEA7` | Terminator entry |

### Block Type Constants

| Constant | Value | Description |
|---|---|---|
| `ValSmbBlockType_Dram` | 0 | System DRAM |
| `ValSmbBlockType_Mmio` | 1 | Memory-mapped I/O |
| `ValSmbBlockType_Io` | 2 | I/O port space |

---

## Constants

```c
#define kValSmbMemAlignment      16*1024     // 16 KB alignment
#define kValSmbMaxEntries        30          // Max table entries
#define VALSMB_MAXIMUM_SIZE      0x200       // 512 bytes max
#define BIOS_INFO_OFFSET         0x200       // BiosInfo at VSMB+0x200
#define VALSMB_LEGMMIO_SIZE      0x3E00      // Legacy MMIO area
```

---

## Protocol Interface

The `VAL_SHARED_MAILBOX_PROTOCOL` struct exposes all operations. Function pointer order is ABI-stable across revisions.

### Rev 1 Functions

| Category | Function | Purpose |
|---|---|---|
| **Connection** | `Connect(version, searchMem, searchCmos, create)` | Find or create VSMB |
| **Status** | `IsInstantiated()` | Check if context is active |
| | `IsReady()` | Check `VSmb_State_Ready` |
| | `IsLocked()` | Check `VSmb_State_Locked` |
| **Locking** | `Lock()` | Acquire lock → `Locked` state |
| | `Unlock()` | Release lock → `Ready` state, recalculate checksum |
| **Version** | `GetProtocolVersion()` | Returns protocol version (3) |
| | `CheckProtocolVersion(desired)` | Backward-compatible version check |
| **Output** | `DecodeMailbox()` | Human-readable dump |
| | `PrintMailbox()` | Raw hex dump |
| | `PrintHifMailbox()` | Print HIF card copy |
| | `PrintInfoRec()` | Print BiosInfo record |
| | `PrintPcXml()` | Print PlatformConfig.xml |
| | `GetSignatureDescription(sig)` | Signature → string |
| **Lifecycle** | `Abandon()` | Disconnect without erase |
| | `Destroy(erase)` | Deallocate and optionally erase |
| **Entry CRUD** | `AddEntry(sig, addr, size, flags)` | Add new entry |
| | `EditEntry(sig, addr, size, flags)` | Modify existing entry |
| | `EditAddEntry(sig, addr, size, flags)` | Edit or add if not found |
| | `FetchEntry(sig, &addr, &size, &flags)` | Read entry by signature |
| | `DeleteEntry(sig)` | Remove entry |
| | `FetchAddressField(sig)` | Quick address-only fetch |
| | `FindEntry(sig)` | Check if entry exists (Rev 2) |
| **CLI Buffers** | `ConnectCliBuffer(sig, addr, size, align)` | Connect/allocate CLI buffer |
| | `DisconnectCliBuffer(sig)` | Disconnect CLI buffer |
| **Block Flags** | `CreateBlockFlags(blockType)` | Build flags word |
| **HIF Card** | `FetchHifCardInfo(&devId, &barId)` | Read HIF card info from header |
| | `UpdateHifCardInfo(devId, barId)` | Write HIF card info to header |
| | `SyncHifMailbox()` | Copy VSMB to HIF card MMIO |
| **Address** | `GetMailboxAddress()` | Get DRAM mailbox base |
| | `GetHifBiosInfoAddress()` | Get HIF BiosInfo address |
| | `SaveAddressToCmos()` | Persist address in CMOS |
| | `ResetVsmbSpecVersion(rel, maj, min)` | Override spec version |

### Rev 2 Additions

| Function | Purpose |
|---|---|
| `XmlCliInstantiate(version, addr, size, entries)` | Wrap pre-allocated memory for XmlCli |
| `FindEntry(sig)` | Check entry existence |

### Rev 3 Additions

| Function | Purpose |
|---|---|
| `FetchHifCardInfoSize(&devId, &barId, &size)` | Read HIF info including size |
| `UpdateHifCardInfoSize(devId, barId, size)` | Write HIF info including size |

---

## Execution Flow

### DXE Driver Initialization

**Entry:** `ValSharedMailboxEntryPoint()`

1. Check protocol not already installed (prevent duplicates)
2. `VsmbDxe_InitProtocol()` — zero both global contexts (`mValSmbContext` for DRAM, `mHifSmbContext` for HIF)
3. Install `gValSmbProtocolGuid` protocol on a new handle
4. Return — mailbox is **not yet instantiated** (requires `Connect()` call)

### Connect() — Mailbox Discovery/Creation

```
Connect(desiredProtoVersion, searchMem, searchCmos, create)
```

1. **Version check** — backward-compatible protocol version validation
2. If already instantiated → return `EFI_SUCCESS`
3. **Search in memory** — if `searchMem != 0`, try `AssumePreExisting()` at that address; validate spec version
4. **Search via CMOS** — if `searchCmos`, read CMOS registers `0xF0`/`0xF1` → reconstruct base address → search 64 KB range for signature `0xBA5EBA11`
5. **Create new** — if `create`, allocate 16 KB-aligned memory → `Initialize()` → save address to CMOS
6. Return status

### Lock/Unlock Protocol

All entry modifications require the lock:

```
Lock():   ValidHeader 1 (Ready) → 2 (Locked)  — returns header pointer
Unlock(): ValidHeader 2 (Locked) → 1 (Ready)  — recalculates checksum
```

### 64-bit Address Handling

For addresses > 32 bits, the library uses **two consecutive entries**:
- Entry N: signature, low 32-bit address, size, flags
- Entry N+1: signature+1, high 32-bit address, 0, 0

`AddEntry64` / `EditEntry64` / `FetchEntry64` / `DeleteEntry64` handle both entries transparently.

### SyncHifMailbox() — HIF Card Synchronization

1. Read HIF device ID and BAR from header `CommonFlags`
2. Get `HOST_CARD_ADDR` entry → HIF MMIO base address
3. Initialize HIF context if needed
4. Copy entire DRAM VSMB → HIF MMIO
5. Sync `ValBiosInfoRecord` to HIF + `0x200`
6. Update `BIOS_INFO` entry to point to HIF MMIO copy

### CLI Buffer Management

`ConnectCliBuffer(signature, addr, size, align)`:
- Supported: `BIOS_INFO`, `PCXML`, `CLI_REQ`, `CLI_RSP`, `CLI_OBJ`
- If `addr == NULL`: allocate aligned memory, driver owns it
- If `addr != NULL`: wrap pre-allocated buffer, caller owns it
- Tracks per-buffer connection reference count
- `DisconnectCliBuffer()` decrements ref count; frees only when count reaches 0

### CMOS Address Persistence

VSMB base address is stored in CMOS for cross-boot discovery:
- **Config port:** `0x72`, **Data port:** `0x73`
- **Registers:** `0xF0` (bits 16–23) and `0xF1` (bits 24–31)
- Only upper 16 bits stored → VSMB must be 64 KB aligned for CMOS recovery
- On reconnect: read CMOS → reconstruct base → search 64 KB range for `0xBA5EBA11` header

---

## Pre-Built Diagrams

### VSMB Memory Layout

```mermaid
classDiagram
    class ValSmbTableHeader {
        +UINT32 BIOS_Signature [0xBA5EBA11]
        +UINT8 EntriesNumber
        +UINT8 FirstEntryOffset [0x20]
        +UINT8 EntrySize [0x10]
        +UINT8 ValidHeader [lock state]
        +UINT32 BIOS_Signature2
        +UINT32 CheckSum
        +CommonFlags [DevId, BarId, BarBlockSize]
        +ValSmbSpecVersionType SvBiosSpecVersion
    }

    class ValSmbTableEntry {
        +UINT32 Signature
        +UINT32 Data1 [address]
        +UINT32 Data2 [size]
        +UINT32 Data3 [flags]
    }

    class ValBiosInfoRecord {
        +UINT32 mHeartbeat
        +UINT32 mPcXml
        +UINT16 mBootStatus [0xF6=ready]
        +UINT16 mMerlinXMajor/Minor
        +UINT16 mMerlinXApiMajor/Minor
        +UINT32 mDciActive, mXmlCliActive
        +UINT32 mBiosKnobs
    }

    class ValSmbContext {
        +ValSmbTableHeader* mValSmbTableBaseAddr
        +ValSmbTableEntry* mValSmbTableFirstEntry
        +UINT32 mValSmbTableMaxEntries [30]
        +UINT32 mOwnsAllocation*
        +UINT8 mCnxCount*
    }

    ValSmbTableHeader "1" --> "0..30" ValSmbTableEntry : entries at offset 0x20
    ValSmbTableHeader ..> ValBiosInfoRecord : at offset 0x200
    ValSmbContext --> ValSmbTableHeader : mValSmbTableBaseAddr
    ValSmbContext --> ValSmbTableEntry : mValSmbTableFirstEntry
```

### VSMB Lock State Machine

```mermaid
stateDiagram-v2
    [*] --> NotReady : allocated / zeroed
    NotReady --> Ready : Initialize() or AssumePreExisting()
    Ready --> Locked : Lock()
    Locked --> Ready : Unlock() [recalculate checksum]
    Ready --> NotReady : Destroy(erase=true)
    Locked --> NotReady : Destroy(erase=true)
```

### Connect() Discovery Flow

```mermaid
flowchart TD
    A([Connect called]) --> B{Already instantiated?}
    B -- yes --> Z([Return EFI_SUCCESS])
    B -- no --> C{searchMem != 0?}
    C -- yes --> D[AssumePreExisting at searchMem]
    D --> E{Found valid VSMB?}
    E -- yes --> F[ValidateSpecVersion] --> Z
    E -- no --> G{searchCmos?}
    C -- no --> G
    G -- yes --> H[Read CMOS 0xF0/0xF1]
    H --> I[Reconstruct base address]
    I --> J[Search 64KB range for 0xBA5EBA11]
    J --> K{Found?}
    K -- yes --> F
    K -- no --> L{create?}
    G -- no --> L
    L -- yes --> M[Allocate 16KB-aligned memory]
    M --> N[Initialize header + terminator]
    N --> O[SaveAddressToCmos]
    O --> Z
    L -- no --> ERR([Return EFI_NOT_FOUND])
```

### DXE Driver Initialization

```mermaid
sequenceDiagram
    participant BIOS as DXE Core
    participant DXE as ValSharedMailboxDxe
    participant Proto as Protocol Layer
    participant Lib as ValSharedMailboxLib
    participant CMOS as CMOS Registers

    BIOS->>DXE: ValSharedMailboxEntryPoint()
    DXE->>DXE: Check no duplicate protocol
    DXE->>Proto: VsmbDxe_InitProtocol()
    Proto->>Lib: ZeroContext(mValSmbContext)
    Proto->>Lib: ZeroContext(mHifSmbContext)
    DXE->>BIOS: InstallProtocolInterface(gValSmbProtocolGuid)

    Note over DXE: Mailbox NOT yet instantiated

    BIOS->>Proto: Connect(version, searchMem, searchCmos, create)
    alt Found in memory
        Proto->>Lib: AssumePreExisting(base)
        Lib-->>Proto: context initialized
    else Found via CMOS
        Proto->>CMOS: Read 0xF0, 0xF1
        CMOS-->>Proto: upper 16 bits of address
        Proto->>Lib: SearchForPreExistingVsmb(base)
        Lib-->>Proto: found header
    else Create new
        Proto->>Lib: Allocate(maxEntries)
        Proto->>Lib: Initialize()
        Lib->>Lib: Write header, terminator, checksum
        Proto->>CMOS: SaveAddressToCmos()
    end
    Proto-->>BIOS: EFI_SUCCESS
```

### SyncHifMailbox Flow

```mermaid
sequenceDiagram
    participant Caller
    participant Proto as Protocol
    participant DRAM as DRAM VSMB
    participant HIF as HIF Card MMIO

    Caller->>Proto: SyncHifMailbox()
    Proto->>DRAM: Read CommonFlags (DevId, BarId)
    Proto->>DRAM: FetchEntry(HOST_CARD_ADDR)
    DRAM-->>Proto: HIF MMIO base address

    alt HIF context not initialized
        Proto->>HIF: InitContext at HIF base
    end

    Proto->>HIF: Copy entire VSMB table (0x200 bytes)
    Proto->>HIF: Sync ValBiosInfoRecord to HIF+0x200
    Proto->>DRAM: EditEntry(BIOS_INFO) → point to HIF MMIO copy
    Proto-->>Caller: EFI_SUCCESS
```

### Entry CRUD Operations

```mermaid
flowchart TD
    subgraph "AddEntry64(sig, addr, size, flags)"
        A1[Lock mailbox] --> A2{Entry count < max?}
        A2 -- no --> A3([EFI_OUT_OF_RESOURCES])
        A2 -- yes --> A4{Signature already exists?}
        A4 -- yes --> A5([EFI_ALREADY_STARTED])
        A4 -- no --> A6[Write entry at next slot]
        A6 --> A7{addr > 32 bits?}
        A7 -- yes --> A8[Write high 32 bits in sig+1 entry]
        A7 -- no --> A9[Append END_OF_TABLE terminator]
        A8 --> A9
        A9 --> A10[Unlock + recalculate checksum]
    end

    subgraph "FetchEntry64(sig, &addr, &size, &flags)"
        F1[Search entries for signature] --> F2{Found?}
        F2 -- no --> F3([EFI_NOT_FOUND])
        F2 -- yes --> F4[Read Data1, Data2, Data3]
        F4 --> F5{sig+1 entry exists?}
        F5 -- yes --> F6[Combine high+low 32 bits → 64-bit addr]
        F5 -- no --> F7[Return 32-bit addr]
    end

    subgraph "DeleteEntry64(sig)"
        D1[Lock mailbox] --> D2[Find entry index]
        D2 --> D3[Shift remaining entries up]
        D3 --> D4{sig+1 entry exists?}
        D4 -- yes --> D5[Delete high-addr entry too]
        D4 -- no --> D6[Decrement EntriesNumber]
        D5 --> D6
        D6 --> D7[Append END_OF_TABLE terminator]
        D7 --> D8[Unlock + recalculate checksum]
    end
```
