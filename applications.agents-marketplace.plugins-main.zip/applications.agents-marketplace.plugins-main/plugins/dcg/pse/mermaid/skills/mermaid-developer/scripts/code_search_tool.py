import os
import json
import logging
import tomllib
from pathlib import Path

logger = logging.getLogger("donkey.tools.code")
logger.setLevel(logging.DEBUG)

# File extensions to search (code and text files)
SEARCHABLE_EXTENSIONS = {
    '.asm', '.bat', '.c', '.cmd', '.dec', '.depex', '.docx', '.dpx',
    '.dsc', '.dtd', '.exe', '.fdf', '.gitignore', '.h', '.hfr', '.ico',
    '.inf', '.ini', '.md', '.nasm', '.pdf', '.png', '.ppt', '.py', '.pyc',
    '.readme', '.rules', '.sh', '.txt', '.uni', '.vfr', '.vhd', '.vsd',
    '.xml', '.yml', '.zip'
}

# Maximum file size to search (skip very large files)
MAX_FILE_SIZE = 1024 * 1024  # 1 MB


def find_repo_path(project: str) -> str:
    """Find the repository path for the given project name."""
    logger.debug("Finding repo path for project: %s", project)
    lookup_toml = os.path.join(os.path.dirname(os.path.abspath(__file__)), "repo_lookup.toml")
    
    if not os.path.isfile(lookup_toml):
        raise FileNotFoundError(f"repo_lookup.toml not found at {lookup_toml}")

    with open(lookup_toml, "rb") as f:
        repos_dict = tomllib.load(f)
    
    repo = None
    for section_name, section_data in repos_dict.items():
        if project in section_name:
            repo = section_data
            break
        
        aliases = section_data.get("aliases", [])
        if any(project in alias.lower() for alias in aliases):
            repo = section_data
            break
    
    if not repo:
        logger.warning("No matching project found for: %s", project)
        raise ValueError(f"No matching projects found for project='{project}'")

    repo_path = (repo.get("path_to_repo") or "").strip()
    if not repo_path:
        raise ValueError("Matched repo has empty path_to_repo")
    
    if not os.path.isdir(repo_path):
        raise FileNotFoundError(f"Repository path not found: {repo_path}")

    logger.debug("Found repo path: %s", repo_path)
    return repo_path


def search_for_keywords(project: str, keywords: list[str], max_results: int = 10) -> str:
    """
    Search for files containing ALL specified keywords in the given project repository.
    
    Args:
        project: The project name or alias to search in
        keywords: List of keywords that must ALL be present in a file
        max_results: Maximum number of matching files to return
    
    Returns:
        JSON string containing list of matching files with their content excerpts
    """
    logger.info("Searching code in %s for keywords: %s", project, keywords)
    
    if not keywords:
        return json.dumps({"error": "No keywords provided"}, ensure_ascii=False)
    
    repo_path = find_repo_path(project.lower())
    results = []
    files_searched = 0
    
    # Walk through all files in the repository
    for root, dirs, files in os.walk(repo_path):
        # Skip hidden directories and common non-code directories
        dirs[:] = [d for d in dirs if not d.startswith('.') and d not in {'__pycache__', 'node_modules', '.git', 'Build', 'build'}]
        
        for filename in files:
            # Check file extension
            ext = Path(filename).suffix.lower()
            if ext not in SEARCHABLE_EXTENSIONS:
                continue
            
            filepath = os.path.join(root, filename)
            
            # Skip files that are too large
            try:
                if os.path.getsize(filepath) > MAX_FILE_SIZE:
                    continue
            except OSError:
                continue
            
            files_searched += 1
            
            try:
                with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
                    content = f.read()
                
                content_lower = content.lower()
                
                # Check if ALL keywords are present in the file
                if all(kw.lower() in content_lower for kw in keywords):
                    # Get relative path from repo root
                    rel_path = os.path.relpath(filepath, repo_path)
                    
                    # Find relevant excerpts containing the keywords
                    excerpts = extract_excerpts(content, keywords)
                    
                    results.append({
                        "file_path": rel_path,
                        "full_path": filepath,
                        "excerpts": excerpts
                    })
                    
                    if len(results) >= max_results:
                        break
                        
            except (IOError, OSError) as e:
                logger.debug("Could not read file %s: %s", filepath, e)
                continue
        
        if len(results) >= max_results:
            break
    
    logger.info("Searched %d files, found %d matches", files_searched, len(results))
    
    return json.dumps({
        "project": project,
        "keywords": keywords,
        "files_searched": files_searched,
        "matches_found": len(results),
        "results": results
    }, ensure_ascii=False)


def extract_excerpts(content: str, keywords: list[str], context_lines: int = 3) -> list[str]:
    """
    Extract relevant excerpts from content that contain the keywords.
    
    Args:
        content: The file content to extract from
        keywords: Keywords to find
        context_lines: Number of lines of context around matches
    
    Returns:
        List of excerpt strings
    """
    lines = content.split('\n')
    excerpts = []
    matched_line_indices = set()
    
    # Find all lines containing any keyword
    for i, line in enumerate(lines):
        line_lower = line.lower()
        for kw in keywords:
            if kw.lower() in line_lower:
                matched_line_indices.add(i)
                break
    
    # Group nearby matches and extract with context
    if not matched_line_indices:
        return excerpts
    
    sorted_indices = sorted(matched_line_indices)
    groups = []
    current_group = [sorted_indices[0]]
    
    for idx in sorted_indices[1:]:
        # If this line is close to the previous one, add to current group
        if idx - current_group[-1] <= context_lines * 2:
            current_group.append(idx)
        else:
            groups.append(current_group)
            current_group = [idx]
    groups.append(current_group)
    
    # Extract excerpts for each group (limit to first 3 groups)
    for group in groups[:3]:
        start = max(0, min(group) - context_lines)
        end = min(len(lines), max(group) + context_lines + 1)
        
        excerpt_lines = []
        for i in range(start, end):
            prefix = ">>> " if i in matched_line_indices else "    "
            excerpt_lines.append(f"{i+1:4d}{prefix}{lines[i]}")
        
        excerpts.append('\n'.join(excerpt_lines))
    
    return excerpts
