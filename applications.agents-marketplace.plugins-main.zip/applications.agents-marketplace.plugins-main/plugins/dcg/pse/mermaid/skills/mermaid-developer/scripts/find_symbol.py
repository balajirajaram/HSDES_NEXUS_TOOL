"""Find NASM function offsets in MerlinX.efi via byte-pattern matching.

Each function has a unique byte signature derived from its first few instructions.
The script searches the PE image for each signature and reports the RVA and file offset.
"""
import pefile
import sys

EFI_PATH = r"C:\SVSHARE\jlam2\pysvtools.mermaid-agent\MerlinX\MerlinX.efi"

# ── Signature table ──────────────────────────────────────────────────────────
# Each entry: (function_name, byte_signature, description)
# Signatures are the first N bytes of each function as assembled by NASM x64/x86.
SIGNATURES = [
    # ── CliRestoreState.nasm (.code section, BITS 64) ────────────────────────
    # Clix64RestoreState: mov rax,[ecx+20h]; mov cr2,rax; mov rax,[ecx+08h]; mov cr4,rax
    ("Clix64RestoreState",
     bytes([0x67, 0x48, 0x8B, 0x41, 0x20,       # mov rax, qword [ecx+20h]
            0x0F, 0x22, 0xD0]),                    # mov cr2, rax
     "64-bit CPU state restore entry"),

    # CliRestoreState: DB 8bh,41h,00h; DB 0fh,22h,0d8h; DB 8bh,41h,08h; DB 0fh,22h,0e0h
    ("CliRestoreState",
     bytes([0x8B, 0x41, 0x00, 0x0F, 0x22, 0xD8,  # mov eax,[ecx+0]; mov cr3,eax
            0x8B, 0x41, 0x08, 0x0F, 0x22, 0xE0]), # mov eax,[ecx+8]; mov cr4,eax
     "32-bit entry, sets CR3/CR4 then jumps to long mode"),

    # ── CliSaveState.nasm (.text section, BITS 64) ───────────────────────────
    # mov rax, 0h -> NASM encodes as mov eax, 0 (B8 00 00 00 00)
    # mov [rcx+0E0h], rax; mov rax, cr3
    ("CliSaveState",
     bytes([0xB8, 0x00, 0x00, 0x00, 0x00,               # mov eax, 0 (zero-extends to rax)
            0x48, 0x89, 0x81, 0xE0, 0x00, 0x00, 0x00,    # mov [rcx+0E0h], rax
            0x0F, 0x20, 0xD8]),                            # mov rax, cr3
     "64-bit CPU state save"),

    # ── AsmFakedInit.nasm (.code section, BITS 64) ───────────────────────────
    # cli; jmp $
    # FA EB FE
    ("AsmFakedInit",
     bytes([0xFA, 0xEB, 0xFE,                     # cli; jmp $
            0xFF, 0x2D]),                           # jmp far [rip+...]
     "faked INIT handler (cli + jmp $)"),

    # ── BiosApiNativeFunctions.nasm (.text section, BITS 32) ─────────────────
    # NativeBiosApi_Heartbeat: push ebp; mov ebp,esp; push ebx; push esi; push edi; pushad
    # NASM uses 89 E5 for mov ebp,esp
    ("NativeBiosApi_Heartbeat",
     bytes([0x55, 0x89, 0xE5, 0x53, 0x56, 0x57, 0x60,   # push ebp; mov ebp,esp; push ebx/esi/edi; pushad
            0xB8, 0x60, 0x00, 0x00, 0x00]),                # mov eax, 60h
     "32-bit heartbeat API"),

    # NativeBiosApi_RestoreCli: push ebp; mov eax, 0x00082138; jmp eax
    ("NativeBiosApi_RestoreCli",
     bytes([0x55,                                          # push ebp
            0xB8, 0x38, 0x21, 0x08, 0x00,                 # mov eax, 0x00082138
            0xFF, 0xE0]),                                  # jmp eax
     "32-bit restore CLI helper"),

    # NativeBiosApi_DoorbellRead: push ebp; mov ebp,esp; mov eax,0x64
    # NASM uses 89 E5 for mov ebp,esp
    ("NativeBiosApi_DoorbellRead",
     bytes([0x55, 0x89, 0xE5,                              # push ebp; mov ebp,esp
            0xB8, 0x64, 0x00, 0x00, 0x00,                  # mov eax, 64h
            0x8B, 0x88, 0x00, 0x20, 0x08, 0x00,            # mov ecx, [eax+82000h]
            0x8B, 0x01]),                                   # mov eax, [ecx]  (Read returns value)
     "32-bit doorbell read"),

    # NativeBiosApi_DoorbellWrite: same prologue, then mov edx,[ebp+08]; mov [ecx],edx
    ("NativeBiosApi_DoorbellWrite",
     bytes([0x55, 0x89, 0xE5,                              # push ebp; mov ebp,esp
            0xB8, 0x64, 0x00, 0x00, 0x00,                  # mov eax, 64h
            0x8B, 0x88, 0x00, 0x20, 0x08, 0x00,            # mov ecx, [eax+82000h]
            0x8B, 0x55, 0x08,                               # mov edx, [ebp+08h]
            0x89, 0x11]),                                    # mov [ecx], edx
     "32-bit doorbell write"),

    # ── BiosApiExtendedFunctions.nasm (.text section, BITS 64) ───────────────
    # NasmDoorbellRead64: mov rcx, qword [HeartbeatAddress64 + APITable_Address]
    #   = mov rcx, [0x82080]
    #   48 8B 0C 25 80 20 08 00   (mov rcx, qword [abs 0x82080])
    #   8B 01                      (mov eax, [rcx])
    #   C3                         (ret)
    ("NasmDoorbellRead64",
     bytes([0x48, 0x8B, 0x0C, 0x25, 0x80, 0x20, 0x08, 0x00,  # mov rcx, [0x82080]
            0x8B, 0x01,                                         # mov eax, [rcx]
            0xC3]),                                              # ret
     "64-bit doorbell read"),

    # NasmDoorbellWrite64: mov rcx, qword [0x82080]; mov [rcx], ebx; ret
    # 48 8B 0C 25 80 20 08 00  89 19  C3
    ("NasmDoorbellWrite64",
     bytes([0x48, 0x8B, 0x0C, 0x25, 0x80, 0x20, 0x08, 0x00,  # mov rcx, [0x82080]
            0x89, 0x19,                                         # mov [rcx], ebx
            0xC3]),                                              # ret
     "64-bit doorbell write"),

    # NasmHeartbeat64: mov rcx, qword [0x82080]; mov [rcx], ebx; ret
    # Same bytes as NasmDoorbellWrite64 - they may share the same pattern
    # (will be a duplicate hit if so, which is valid)
    ("NasmHeartbeat64",
     bytes([0x48, 0x8B, 0x0C, 0x25, 0x80, 0x20, 0x08, 0x00,  # mov rcx, [0x82080]
            0x89, 0x19,                                         # mov [rcx], ebx
            0xC3]),                                              # ret
     "64-bit heartbeat (same body as DoorbellWrite64)"),

    # GoToLongMode (BITS 32): mov eax, 0x00000000; mov cr3, eax
    # B8 00 00 00 00  0F 22 D8  (very distinctive: mov eax,0; mov cr3,eax followed by more setup)
    # Then: mov ebx, 0; mov eax, cr4; bt eax, 5
    # B8 00 00 00 00  0F 22 D8  BB 00 00 00 00  0F 20 E0  0F BA E0 05
    ("GoToLongMode",
     bytes([0xB8, 0x00, 0x00, 0x00, 0x00,         # mov eax, 0 (patched CR3)
            0x0F, 0x22, 0xD8,                       # mov cr3, eax
            0xBB, 0x00, 0x00, 0x00, 0x00,           # mov ebx, 0
            0x0F, 0x20, 0xE0,                       # mov eax, cr4
            0x0F, 0xBA, 0xE0, 0x05]),               # bt eax, 5
     "32-bit to long mode transition"),

    # ReturnFromLongMode (BITS 64): cli; mov rax, 0; mov rcx, 0x10; shl rcx, 32
    # NASM encodes mov rax, 0 as mov eax, 0 (B8 form)
    ("ReturnFromLongMode",
     bytes([0xFA,                                              # cli
            0xB8, 0x00, 0x00, 0x00, 0x00,                      # mov eax, 0
            0x48, 0xC7, 0xC1, 0x10, 0x00, 0x00, 0x00,         # mov rcx, 0x10
            0x48, 0xC1, 0xE1, 0x20]),                          # shl rcx, 32
     "64-bit to 32-bit protected mode transition"),

    # ExtendedBiosApi_DoorbellRead64 (BITS 32): push ebp; mov ebp,esp
    # Then SAVE_CONTENT_32_BIT_STATE macro: sub esp,6; sgdt [esp]; sub esp,6; sidt [esp]
    # NASM uses 89 E5 for mov ebp,esp
    ("ExtendedBiosApi_DoorbellRead64",
     bytes([0x55, 0x89, 0xE5,                              # push ebp; mov ebp,esp
            0x83, 0xEC, 0x06,                               # sub esp, 6
            0x0F, 0x01, 0x04, 0x24,                         # sgdt [esp]
            0x83, 0xEC, 0x06,                               # sub esp, 6
            0x0F, 0x01, 0x0C, 0x24]),                       # sidt [esp]
     "32-bit wrapper -> 64-bit doorbell read"),

    # ExtendedBiosApi_DoorbellWrite64: same prologue as Read64 but continues differently
    # after the macro. Since the macro bytes are the same, we need a longer signature.
    # After SAVE_CONTENT_32_BIT_STATE: mov eax,cr4; push eax; mov eax,cr0; push eax;
    #   mov eax,cr3; push eax; push cs; push 0; call GoToLongMode
    # All three Extended APIs share the same SAVE_CONTENT_32_BIT_STATE prologue.
    # We differentiate them by what follows after the macro + push 0 + call GoToLongMode + BITS64 code.
    # For DoorbellWrite64 after GoToLongMode: mov ebx, dword [ebp+08h]
    # Let's use: 8B 5D 08 (mov ebx, [ebp+08]) as a disambiguator after call GoToLongMode
    # We'll search for the "call NasmDoorbellWrite64" pattern which follows "mov ebx, [ebp+08h]"
    ("ExtendedBiosApi_DoorbellWrite64",
     None,  # Will be found relative to DoorbellRead64
     "32-bit wrapper -> 64-bit doorbell write (found relative to Read64)"),

    # ExtendedBiosApi_Heartbeat64: similar structure
    ("ExtendedBiosApi_Heartbeat64",
     None,  # Will be found relative to DoorbellRead64
     "32-bit wrapper -> 64-bit heartbeat (found relative to Read64)"),

    # ── Patch23Asm.nasm / Patch23.nasm (.code section, BITS 64) ──────────────
    # Patch2_P: mov rax,rcx; mov rcx,rdx; db 0F 0E; lfence; mov rax,rdx; ret
    # 48 89 C8  48 89 D1  0F 0E  0F AE E8  48 89 D0  C3
    ("Patch2_P",
     bytes([0x48, 0x89, 0xC8,                     # mov rax, rcx
            0x48, 0x89, 0xD1,                      # mov rcx, rdx
            0x0F, 0x0E,                             # patch2
            0x0F, 0xAE, 0xE8,                      # lfence
            0x48, 0x89, 0xD0,                      # mov rax, rdx
            0xC3]),                                 # ret
     "P-core Patch2 (read CR)"),

    # Patch3_P: mov rax,rcx; mov rcx,rdx; mov rdx,r8; db 0F 0F; lfence; ret
    # 48 89 C8  48 89 D1  4C 89 C2  0F 0F  0F AE E8  C3
    ("Patch3_P",
     bytes([0x48, 0x89, 0xC8,                     # mov rax, rcx
            0x48, 0x89, 0xD1,                      # mov rcx, rdx
            0x4C, 0x89, 0xC2,                      # mov rdx, r8
            0x0F, 0x0F,                             # patch3
            0x0F, 0xAE, 0xE8,                      # lfence
            0xC3]),                                 # ret
     "P-core Patch3 (write CR)"),

    # Patch2_E: mov rax,rcx; mov rcx,rdx; push rbx; xor rbx,rbx; xor rdx,rdx; db 0F 0E
    # 48 89 C8  48 89 D1  53  48 31 DB  48 31 D2  0F 0E
    ("Patch2_E",
     bytes([0x48, 0x89, 0xC8,                     # mov rax, rcx
            0x48, 0x89, 0xD1,                      # mov rcx, rdx
            0x53,                                   # push rbx
            0x48, 0x31, 0xDB,                      # xor rbx, rbx
            0x48, 0x31, 0xD2,                      # xor rdx, rdx
            0x0F, 0x0E]),                           # patch2
     "E-core Patch2 (read CR)"),

    # Patch3_E: push rbx; mov rax,rcx; mov rcx,rdx; mov rdx,r8; mov rbx,r8; shr rbx,32
    # 53  48 89 C8  48 89 D1  4C 89 C2  4C 89 C3  48 C1 EB 20  0F 0F
    ("Patch3_E",
     bytes([0x53,                                   # push rbx
            0x48, 0x89, 0xC8,                      # mov rax, rcx
            0x48, 0x89, 0xD1,                      # mov rcx, rdx
            0x4C, 0x89, 0xC2,                      # mov rdx, r8
            0x4C, 0x89, 0xC3,                      # mov rbx, r8
            0x48, 0xC1, 0xEB, 0x20,                # shr rbx, 32
            0x0F, 0x0F]),                           # patch3
     "E-core Patch3 (write CR)"),

    # AsmPatch2 (from AsmPatch23Lib): mov rax,rcx; mov rcx,rdx; db 0F 0E; lfence; mov rax,rdx; ret
    # Same bytes as Patch2_P  (will be a duplicate hit)
    ("AsmPatch2",
     bytes([0x48, 0x89, 0xC8,                     # mov rax, rcx
            0x48, 0x89, 0xD1,                      # mov rcx, rdx
            0x0F, 0x0E,                             # patch2
            0x0F, 0xAE, 0xE8,                      # lfence
            0x48, 0x89, 0xD0,                      # mov rax, rdx
            0xC3]),                                 # ret
     "AsmPatch23Lib Patch2 (same body as Patch2_P)"),

    # AsmPatch3 (from AsmPatch23Lib): mov eax,ecx; mov ecx,edx; mov rdx,r8; db 0F 0F; lfence; ret
    # 89 C8  89 D1  4C 89 C2  0F 0F  0F AE E8  C3
    ("AsmPatch3",
     bytes([0x89, 0xC8,                            # mov eax, ecx
            0x89, 0xD1,                             # mov ecx, edx
            0x4C, 0x89, 0xC2,                      # mov rdx, r8
            0x0F, 0x0F,                             # patch3
            0x0F, 0xAE, 0xE8,                      # lfence
            0xC3]),                                 # ret
     "AsmPatch23Lib Patch3"),
]


def find_section(pe, rva):
    """Return (section_name, file_offset) for a given RVA."""
    for s in pe.sections:
        if s.VirtualAddress <= rva < s.VirtualAddress + s.Misc_VirtualSize:
            name = s.Name.rstrip(b'\x00').decode('ascii', errors='replace')
            foff = s.PointerToRawData + (rva - s.VirtualAddress)
            return name, foff
    return "???", 0


def search_signature(data, sig):
    """Yield all RVAs where sig is found in data."""
    pos = 0
    while True:
        idx = data.find(sig, pos)
        if idx == -1:
            return
        yield idx
        pos = idx + 1


def main():
    pe = pefile.PE(EFI_PATH)
    data = pe.get_memory_mapped_image()

    print(f"MerlinX.efi  ImageBase=0x{pe.OPTIONAL_HEADER.ImageBase:X}")
    print(f"Sections:")
    for s in pe.sections:
        name = s.Name.rstrip(b'\x00').decode('ascii', errors='replace')
        print(f"  {name:10s}  VA=0x{s.VirtualAddress:06X}  VSize=0x{s.Misc_VirtualSize:06X}")
    print()

    results = {}  # name -> list of (rva, section, file_offset)

    print(f"{'Function':<40s} {'RVA':>10s} {'FileOff':>10s} {'Section':>10s}")
    print("-" * 76)

    for name, sig, desc in SIGNATURES:
        if sig is None:
            continue
        hits = list(search_signature(data, sig))
        if not hits:
            print(f"{name:<40s} {'NOT FOUND':>10s}")
        for rva in hits:
            sect, foff = find_section(pe, rva)
            print(f"{name:<40s} 0x{rva:08X} 0x{foff:08X} {sect:>10s}")
            results.setdefault(name, []).append((rva, sect, foff))

    # ── Special handling for ExtendedBiosApi functions ────────────────────────
    # These share the same SAVE_CONTENT_32_BIT_STATE prologue.
    # Search for ALL instances of the prologue and report them in order.
    prologue = bytes([0x55, 0x8B, 0xEC,            # push ebp; mov ebp,esp
                      0x83, 0xEC, 0x06,             # sub esp, 6
                      0x0F, 0x01, 0x04, 0x24,       # sgdt [esp]
                      0x83, 0xEC, 0x06,             # sub esp, 6
                      0x0F, 0x01, 0x0C, 0x24])      # sidt [esp]
    ext_hits = sorted(search_signature(data, prologue))
    if len(ext_hits) >= 3:
        ext_names = ["ExtendedBiosApi_DoorbellRead64",
                     "ExtendedBiosApi_DoorbellWrite64",
                     "ExtendedBiosApi_Heartbeat64"]
        print()
        print("Extended BiosApi functions (ordered by RVA from shared prologue):")
        for i, (rva, fname) in enumerate(zip(ext_hits[:3], ext_names)):
            sect, foff = find_section(pe, rva)
            print(f"  {fname:<40s} 0x{rva:08X} 0x{foff:08X} {sect:>10s}")
            results[fname] = [(rva, sect, foff)]
    elif len(ext_hits) > 0:
        print(f"\nFound {len(ext_hits)} instances of Extended prologue (expected 3):")
        for rva in ext_hits:
            sect, foff = find_section(pe, rva)
            print(f"  0x{rva:08X} 0x{foff:08X} {sect:>10s}")

    # ── Summary ──────────────────────────────────────────────────────────────
    found = sum(1 for v in results.values() if v)
    total = len([s for s in SIGNATURES if s[1] is not None])
    # count Extended APIs that had None signatures but were found
    for ext in ["ExtendedBiosApi_DoorbellWrite64", "ExtendedBiosApi_Heartbeat64"]:
        if ext in results:
            found += 1
            total += 1

    print(f"\n{found}/{total + 2} functions located.")  # +2 for the None-sig entries counted

    pe.close()


if __name__ == "__main__":
    main()
