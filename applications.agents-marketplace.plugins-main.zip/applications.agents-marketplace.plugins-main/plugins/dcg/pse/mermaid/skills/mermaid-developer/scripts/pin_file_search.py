import glob
import sys
import json
import logging
import os
import re
from pprint import pprint

logger = logging.getLogger("donkey.tools.pinfile")

BASE_DIR = r'C:\ProgramData\edkrepo\cr-manifest-main'
server_projects = ['oks', 'oakstream', 'gen4', 'dmr', 'diamondrapids']
client_projects = [ "nvl", "novalake", "mtl", "meteorlake"]

def fix_bios_version_and_base_path(version: str, project: str) -> tuple[str, str]:
    cleaned = re.sub(r'[.\s]', '', version).upper()
    if project in server_projects:
        match = re.match(r'^(\d{2,4})([A-Z])(\d{2})$', cleaned)
        if match:
            num = match.group(1).zfill(4)
            return (f"{num}.{match.group(2)}.{match.group(3)}", os.path.join(BASE_DIR, "DCG"))
        raise NotImplementedError(f"Version {version} is not a supported server version type")
    elif project in client_projects:
        match = re.match(r'^(\d{4})_(\d{2})$', cleaned)
        if match:
            return (f"{match.group(1)}_{match.group(2)}",  os.path.join(BASE_DIR, "CCG"))
        match = re.match(r'^(\d{4})$', cleaned)
        if match:
            return (f"{match.group(1)}_00",  os.path.join(BASE_DIR, "CCG"))
        raise NotImplementedError(f"Version {version} is not a supported client version type")
    raise NotImplementedError(f"Provided BIOS version {version} does not match expected patterns for either client of server BIOS")

def lookup_pin_file(project: str, bios_version: str) -> str:
    logger.info("Looking up pin file for project=%s, version=%s", project, bios_version)
    project = project.lower()
    results = set()
    try:
        normalized_version, new_base_path = fix_bios_version_and_base_path(bios_version, project)
        logger.debug("Normalized version: %s, base path: %s", normalized_version, new_base_path)

        files = glob.glob(f"{new_base_path}/**/*.xml", recursive= True)
        logger.debug("Searching %d XML files", len(files))
        for file in files:
            try:
                with open(file, 'r', encoding='utf-8', errors='ignore') as f:
                    if normalized_version in f.read():
                        results.add(file)
            except (IOError, PermissionError):
                continue
        logger.info("Found %d matching pin file(s)", len(results))
        return json.dumps(list(results))
    except NotImplementedError as ne:
        logger.warning("Version normalization failed: %s", ne)
        return json.dumps({"error": str(ne)})

def lookup_pin_file_from_ifwi(ifwi_name: str) -> str:
    logger.info("Looking up pin file from IFWI name: %s", ifwi_name)
    match = re.match(r'^[A-Z0-9]+\.[0-9A-Z]+\.(\d{2,4}\.[A-Z]\d{2}).*', ifwi_name.upper())
    if not match:
        logger.warning("IFWI name does not match expected pattern: %s", ifwi_name)
        return json.dumps({"error": "IFWI name does not match expected pattern. " +
                           "BIOS extraction from IFWI name is only supported for server IFWI files."})
    
    bios_version = match.group(1)
    logger.debug("Extracted BIOS version: %s", bios_version)

    for project in server_projects:
        try:
            result = lookup_pin_file(project, bios_version)
            result_data = json.loads(result)
            if isinstance(result_data, list) and result_data:
                logger.info("Found pin file(s) for project %s and version %s", project, bios_version)
                return result
        except NotImplementedError:
            continue
    
    logger.info("No pin files found for IFWI name: %s", ifwi_name)
    return json.dumps({"error": "No pin files found for the given IFWI name"})

if __name__ == "__main__":
    #retval = lookup_pin_file(sys.argv[1], sys.argv[2])
    retval = lookup_pin_file_from_ifwi(sys.argv[1])
    print("===================")
    pprint(retval)
