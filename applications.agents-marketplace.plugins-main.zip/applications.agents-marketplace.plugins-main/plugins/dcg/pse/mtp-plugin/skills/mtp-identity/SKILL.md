---
name: mtp-identity
description: "Capture and remember the user's Intel IDSID (network nickname, e.g. 'izavads') for passing to MTP tools. MANDATORY before calling ANY MTP tool that has a user_idsid parameter — no call may be made without it. Never pass 'unknown'. Tools requiring it: mtp_list_projects, mtp_list_domains, mtp_find_my_issues, mtp_missing_records, mtp_run_check, mtp_phoenix_reuse, mtp_phoenix_reuse_bulk, mtp_phoenix_trash, mtp_apply_description, mtp_populate_blank_descriptions, mtp_query_structure, mtp_update_record, mtp_copy_description, mtp_generate_full_report."
---

# MTP Identity Skill

## Purpose

The MTP server runs on Intel CaaS (a Docker container) and cannot detect your Windows username.
This skill ensures your Intel IDSID is captured once, saved to memory, and **always** passed as `user_idsid` to every MTP tool that accepts it.

**Critical rule: never call an MTP tool with `user_idsid` omitted or set to `"unknown"`.**

## When This Skill Applies

Apply this skill **before every call** to any MTP tool that has a `user_idsid` parameter:

| Tool | `user_idsid` param |
|---|---|
| `mtp_list_projects` | ✅ |
| `mtp_list_domains` | ✅ |
| `mtp_find_my_issues` | ✅ |
| `mtp_missing_records` | ✅ |
| `mtp_run_check` | ✅ |
| `mtp_apply_description` | ✅ |
| `mtp_populate_blank_descriptions` | ✅ |
| `mtp_query_structure` | ✅ |
| `mtp_phoenix_reuse` | ✅ |
| `mtp_phoenix_reuse_bulk` | ✅ |
| `mtp_phoenix_trash` | ✅ |
| `mtp_update_record` | ✅ |
| `mtp_copy_description` | ✅ |
| `mtp_generate_full_report` | via `email` param — ask user for their email explicitly |

Tools with **no** `user_idsid` param (no action needed):
`mtp_health`, `mtp_list_checks`, `mtp_hsdes_lookup`, `mtp_inspect_description`, `mtp_description_rewriting`, `mtp_phoenix_get_hierarchy`, `mtp_invalidate_caches`, `mtp_check_reuse_status`, `mtp_get_record`, `mtp_list_updatable_fields`, `mtp_version`, `mtp_generate_coverage_report`, `mtp_project_coverage_report`

## Step 1: Load Memory

Before calling any MTP tool, load `/memories/mtp-identity.md` using the memory tool (`command: view`).

## Step 2: Check for Saved IDSID

### If a saved IDSID exists in memory:
- Use it silently — do NOT ask the user again
- Proceed directly to Step 4
- Optionally inform the user: *"Using your saved Intel IDSID: `izavads`"*

### If no saved IDSID is found:
- Proceed to Step 3

## Step 3: Ask for IDSID (First Time Only)

Use `vscode_askQuestions` to prompt the user:

```json
{
  "header": "Intel Identity Required",
  "question": "What is your Intel network nickname (IDSID)? This is your Windows/Linux login name, e.g. 'izavads'. It will be remembered for future MTP sessions.",
  "allowFreeformInput": true
}
```

After the user provides their IDSID:

1. Save it to `/memories/mtp-identity.md`:
   ```
   MTP-identity-consent: granted
   MTP-user-idsid: <idsid>
   ```
2. Confirm to the user: *"Got it — I'll use `<idsid>` for all MTP operations."*

## Step 4: Pass `user_idsid` to Tool Calls

Always pass the resolved IDSID explicitly. **Never omit it. Never pass `"unknown"`.**

```
mtp_list_projects(user_idsid='izavads')

mtp_find_my_issues(
    source='nvl',
    target='mtp',
    val_teams='fv.dfx',
    user_idsid='izavads'
)

mtp_phoenix_reuse(
    source_id='16028476674',
    dest_parent_id='13015266711',
    user_idsid='izavads'
)
```

If the IDSID is somehow still unresolved at call time — **stop and ask the user before proceeding**. Do not fall back to `"unknown"` or an empty string.

## Rules

- **Never call an MTP tool with `user_idsid` missing or set to `"unknown"`.**
- Never ask for the IDSID more than once per conversation unless the user explicitly asks to change it.
- Never save passwords, tokens, or any sensitive data — only the IDSID nickname.
- If the user says *"use a different IDSID"* or *"I'm logged in as X"*, update memory with the new value and use it immediately.
- Prior consent does not expire — once saved, reuse across all future sessions without re-asking.

## Quick Reference

| Scenario | Action |
|---|---|
| First time ever | Ask for IDSID, save to memory, proceed |
| IDSID in memory | Load silently, use without asking |
| User says "use X instead" | Update memory, use new IDSID |
| Tool needs `email` param | Ask the user for their email address explicitly and confirm before using |
| IDSID still unknown at call time | **Stop and ask — never pass "unknown"** |

## Example — First Session

1. User: *"find me missing records from NVL to MTP for fv.dfx"*
2. Agent loads `/memories/mtp-identity.md` → no IDSID found
3. Agent asks: *"What is your Intel IDSID?"*
4. User: *"izavads"*
5. Agent saves to memory: `MTP-user-idsid: izavads`
6. Agent calls: `mtp_find_my_issues(source='nvl', target='mtp', val_teams='fv.dfx', user_idsid='izavads')`

## Example — Subsequent Sessions

1. User: *"find me missing records from NVL to MTP for fv.dfx"*
2. Agent loads memory → finds `MTP-user-idsid: izavads`
3. Agent informs: *"Using your saved Intel IDSID: `izavads`"*
4. Agent calls: `mtp_find_my_issues(source='nvl', target='mtp', val_teams='fv.dfx', user_idsid='izavads')`
5. No prompt needed — zero friction

## Example — List Projects (previously had no user_idsid)

1. User: *"what projects are available?"*
2. Agent loads memory → finds `MTP-user-idsid: izavads`
3. Agent calls: `mtp_list_projects(user_idsid='izavads')`  ← always pass it
