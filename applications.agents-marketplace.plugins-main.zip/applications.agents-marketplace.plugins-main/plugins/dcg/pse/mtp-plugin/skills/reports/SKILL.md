---
name: reports
description: "Generate a focused MTP ↔ reference project coverage Excel report and email it. Handles the full interaction: asks for reference project, val_teams scope, and email — then triggers the report via mtp_generate_coverage_report. Use when user asks to generate a coverage report, send the MTP coverage report, or analyze coverage between MTP and a reference project (NVL, RZL, PTL)."
---

# MTP Coverage Report Skill

Generates a focused MTP ↔ reference project coverage Excel report and emails it.
Handles the full interaction: asks for reference project, val_teams scope, and email — then triggers the report.

## Trigger

Use this skill when the user asks to:
- "generate a coverage report"
- "send me the MTP coverage report"
- "coverage report for NVL / RZL / PTL"
- "how covered is NVL against MTP"
- "generate a focused report for fv.dfx"
- any variation of MTP ↔ reference project coverage analysis by email

## Behavior

### Step 1 — Identify reference project

If the user has not specified which reference project to compare MTP against, ask:

> "Which reference project should I compare MTP against?"
> Options: `nvl`, `rzl`, `nvl_heia_soc`, `ptl_heia_soc`, `ttl`

### Step 2 — Ask for val_teams scope

Always ask the user whether they want the report scoped to specific val_teams or all teams:

> "Should the report cover all val_teams, or do you want to focus on specific ones?
> If specific, provide them comma-separated (e.g. `fv.dfx,fv.pcie,fv.pm`).
> Leave empty or say 'all' for the full report."

- If user says "all", "none", or leaves empty → pass `val_teams = ""`
- If user provides teams → pass them as-is comma-separated string (e.g. `"fv.dfx,fv.pcie"`)
- Multiple teams are supported: `fv.dfx,fv.pcie,fv.pm`

### Step 3 — Get email

If the user has not provided an email address, ask:

> "What email address should the report be sent to?"

Default suggestion: their Intel email (if known from context).

### Step 4 — Trigger the report

Call the MCP tool:

```
mtp_generate_coverage_report(
    email="<email>",
    reference_project="<project>",
    val_teams="<comma-separated teams or empty string>",
    use_cache=False
)
```

### Step 5 — Confirm to user

After triggering, confirm with a message like:

> "Coverage report triggered for MTP ↔ NVL_AX.
> Scope: fv.dfx, fv.pcie
> You will receive the Excel report at <email> in ~5-10 minutes.
> [Monitor workflow](<workflow_url>)"

If val_teams was empty:
> "Scope: all val_teams (unfiltered)"

## Rules

- Always ask for val_teams scope — do NOT silently default to all teams without asking.
- If user says "same as before" or references a previous team, reuse it.
- Multiple val_teams: accept comma-separated, pass through as-is.
- Do not fabricate val_teams values — use exactly what the user provides.
- If the MCP tool returns an error, surface it clearly and suggest remediation.

## Example Interactions

**Focused report:**
> User: "Generate a coverage report for NVL focused on fv.dfx and fv.pcie, send to iliya.zavadski@intel.com"
> → call: `mtp_generate_coverage_report(email="iliya.zavadski@intel.com", reference_project="nvl", val_teams="fv.dfx,fv.pcie")`

**Full report:**
> User: "Send me the full NVL coverage report to my email"
> → ask for email if not known, then:
> → call: `mtp_generate_coverage_report(email="...", reference_project="nvl", val_teams="")`

**Single team:**
> User: "Coverage report for RZL, only fv.pm team"
> → call: `mtp_generate_coverage_report(email="...", reference_project="rzl", val_teams="fv.pm")`
