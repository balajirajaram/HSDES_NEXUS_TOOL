---
name: reuse
description: "Guide Phoenix reuse (copy) operations that duplicate a test plan, TCD, or test case from a source project into a destination folder. Handles the full interaction: resolves source and destination by name, ASKS the user whether to apply custom override variables (owner, owner_team, val_teams, family_affected), REQUIRES the user to verify and approve the operation before it runs, then executes and reports the background job id (checking the reuse status ONLY when the user explicitly asks — it never polls on its own). Use when the user asks to reuse, copy, or clone a TP/TCD/TC from one project (e.g. NVL, RZL, PTL) into MTP or any destination folder."
---

# MTP Phoenix Reuse Skill

Guides a safe, verified Phoenix reuse (copy) operation from a source record into a
destination folder — with optional custom field overrides.

Reuse creates copies of TP / TPF / TCD records; **Test Cases are always created
fresh** and **Test Results are never copied**. Reused records track their origin
via the `from_id` field.

## Trigger

Use this skill when the user asks to:
- "reuse / copy / clone this TP (or TCD or TC) to MTP"
- "reuse the Crashlog test plan into the Security folder"
- "copy these test cases from NVL to ws_mtp"
- "bulk reuse these records to <destination>"
- any variation of copying Phoenix records between projects or folders

## Prerequisites

- The user's Intel IDSID must be resolved first — defer to the **mtp-identity**
  skill and pass `user_idsid` on every tool call.

## Workflow

### Step 1 — Resolve the SOURCE record (by name, never ask for raw IDs)

If the user described the source by name, resolve it to an HSDES ID with
`mtp_query_structure`:

```
mtp_query_structure(
    name="<source_project>",       # e.g. "nvl", "nvl_heia_soc", "rzl"
    record_types=["TP"],           # or ["TCD"], ["TC"]
    title_contains="<search text>",
    return_records=True,
    user_idsid="<idsid>"
)
```

- Multiple matches → show the list (id, title, subject, status, owner) and ask
  the user to pick.
- No matches → broaden the search or ask for clarification.

### Step 2 — Resolve the DESTINATION folder/parent

The destination must be a **specific folder or TP**, not a project root. Ask
"Where in <destination project>?" if unspecified, then resolve:

```
mtp_query_structure(
    name="<dest_project>",         # e.g. "mtp"
    domain="<domain>",             # optional: "Security", "DFX", "Power"
    record_types=["TP", "TPF"],
    title_contains="<search text>",
    return_records=True,
    user_idsid="<idsid>"
)
```

### Step 3 — Choose reuse mode

| Situation | Mode |
|---|---|
| Copy a whole TP with ALL its children | standard (`with_parents=false`) |
| Copy a SINGLE TC/TCD with only its direct parent chain (no siblings) | `with_parents=true` |
| Copy several records at once | `mtp_phoenix_reuse_bulk` (`with_parents=true` default) |

> `with_parents=true` is **idempotent** — re-running will not create duplicates.
> Standard full-hierarchy reuse has **no** idempotency check and **can create
> duplicates** if the record was already reused. Warn the user in that case.

### Step 4 — ASK about custom override variables (MANDATORY)

Before executing, **always ask** the user whether they want to apply custom
field overrides to the copied records. These are stamped onto every copied record
by HSDES during the copy.

> "Do you want to apply any custom field overrides to the copied records?
> Common options:
> - **owner** — set a custom owner (e.g. `imoskov`) DIFFERENT from you, the
>   operator. HSDES honors this and the reused records will be owned by that
>   person, not by you.
> - **owner_team** — e.g. `FV-IDC`
> - **val_teams** — e.g. `fv.dfx`, `fv.pm`
> - **family_affected** — e.g. `Nova Lake H Product`
>
> Tell me any field=value pairs you want, or say 'none' to keep defaults."

Collect the answers into a `custom_values` list, one entry per field:

```json
[
  {"field": "owner", "value": "imoskov"},
  {"field": "owner_team", "value": "FV-IDC"},
  {"field": "val_teams", "value": "fv.dfx"},
  {"field": "family_affected", "value": "Nova Lake H Product"}
]
```

Notes to relay to the user when relevant:
- **Custom owner** overrides the operator identity — the reused records will be
  owned by the specified IDSID even though the operation is run by you.
- To deliberately blank a field, set `{"field": "<f>", "value": "", "setEmpty": true}`.
- Known limitation: `owner_team` may not apply to the **TCD (test_case_definition)**
  level during reuse even when requested — it applies to the TP and TC levels.
  `family_affected` applies to all levels.

### Step 5 — VERIFY and get explicit approval (MANDATORY — do not skip)

**Never execute a reuse without the user's explicit confirmation.** Present a
clear summary and wait for a "yes":

```
REUSE OPERATION — PLEASE VERIFY
────────────────────────────────────────────
SOURCE:      <title> (<id>) — <subject> in <source_project>
             Children included: <n> records (TCs will be created fresh)
DESTINATION: <folder title> (<id>) in <dest_project>
             tenant=<tenant>, family=<family>
MODE:        <standard | with_parents | bulk>
OVERRIDES:   owner=<...>, owner_team=<...>, val_teams=<...>, family_affected=<...>
             (or: none)
WARNINGS:    <e.g. "record already exists in destination — this will create a duplicate">
────────────────────────────────────────────
Proceed? (yes / no)
```

If the user says no or wants changes, adjust and re-confirm. Only proceed on an
explicit yes.

### Step 6 — Execute

Single record:
```
mtp_phoenix_reuse(
    source_id="<id>",
    dest_parent_id="<dest_id>",
    dest_tenant="<tenant>",
    dest_family="<family>",
    with_parents=<true|false>,
    custom_values=<list or omit>,
    user_idsid="<idsid>"
)
```

Multiple records:
```
mtp_phoenix_reuse_bulk(
    source_ids=["<id1>", "<id2>", ...],
    dest_parent_id="<dest_id>",
    with_parents=true,
    custom_values=<list or omit>,
    user_idsid="<idsid>"
)
```

These run as background jobs and return a `job_id` immediately.

### Step 7 — Report the job id and STOP (do NOT poll)

The reuse runs as a background job and returns a `job_id` immediately.

> **Never poll `mtp_check_reuse_status` automatically, and never call it in a
> loop.** On large reuse jobs, repeated status polling burns a huge amount of
> tokens for no benefit — it is the single most expensive mistake this skill can
> make.

Instead, report the `job_id` to the user and offer to check status on request:

> "Reuse job started — job id `<job_id>`. It's running in the background.
> If you'd like to see its status, just let me know and I'll check it."

Then **end your turn and wait for the user.** Do not call any status tool yet.

Only when the user explicitly asks for the status, call `mtp_check_reuse_status`
**exactly once** and report the result:

```
mtp_check_reuse_status(job_id="<job_id>")
```

Report `total / complete / error`. If it is still running, say so and again wait
for the user to ask again — never re-poll on your own initiative.

### Step 8 — Report and confirm the overrides landed

Only once the user has asked for a status check (Step 7) and it reports the job
`complete`, summarize for the user:
- Job id and final status (e.g. "13/13 complete, 0 errors")
- The new destination TP/record id
- If custom overrides were applied, confirm they took effect (e.g. verify the new
  records' `owner` / `owner_team` / `family_affected` via `mtp_get_record` /
  `mtp_hsdes_lookup`), and restate the `owner_team`-on-TCD limitation if the user
  set `owner_team`.

## Rules

- **Always** ask about custom override variables (Step 4) before running a reuse.
- **Always** show the verification summary and get explicit approval (Step 5)
  before executing. Never auto-run a reuse.
- Never ask the user for raw HSDES IDs — resolve names via `mtp_query_structure`.
- Always pass `user_idsid` (see the mtp-identity skill).
- **Never auto-poll `mtp_check_reuse_status`.** After starting a reuse, report the
  `job_id` and wait — only check the status when the user explicitly asks, and
  only once per request. Looping the status check wastes large amounts of tokens.
- Warn about duplicate creation when doing a standard (non-`with_parents`) reuse of
  a record that may already exist in the destination.
- Remember: Test Cases are always new; Test Results are never copied; Test Content
  is linked, not duplicated.

## Quick Reference

| Step | Action |
|---|---|
| 1 | Resolve source by name → id |
| 2 | Resolve destination folder → id |
| 3 | Pick mode (standard / with_parents / bulk) |
| 4 | **Ask about custom overrides** (owner, owner_team, val_teams, family_affected) |
| 5 | **Show summary, get explicit approval** |
| 6 | Execute `mtp_phoenix_reuse` / `_bulk` |
| 7 | Report job id; check `mtp_check_reuse_status` **only when the user asks** (never poll) |
| 8 | Report results, confirm overrides |
