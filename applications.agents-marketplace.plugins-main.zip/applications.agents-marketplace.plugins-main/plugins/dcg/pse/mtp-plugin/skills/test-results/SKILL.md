---
name: test-results
description: "Create Test Results (TRs) that record a pass/fail outcome under an existing Test Case in HSDES Phoenix, and update attributes on existing TRs. Handles the full interaction: resolves the parent Test Case by name (never asks for raw IDs), ASKS the user which optional TR attributes to set (test_cycle, val_teams, category, free_tag_3, log_path, details, etc.), REQUIRES the user to verify and approve before creating, then creates via mtp_create_test_result. For attribute updates it ALWAYS fetches the current revision first (mtp_get_record) and then applies changes via mtp_bulk_update_records / mtp_update_record — exactly how the Phoenix UI does it. Use when the user asks to create a test result, record a pass/fail on a test case, log a TR, or change/set an attribute (e.g. test cycle, val_teams) on an existing test result."
---

# MTP Test Results Skill

Creates **Test Results (TRs)** under an existing **Test Case (TC)** and updates
attributes on existing TRs — safely, with verification and optional custom fields.

A Test Result (HSDES subject `test_result`) records the outcome of running a test
case: `pass` or `fail`. It is created as a child of a TC and inherits the TC's
project context (family, family_group, family_affected, classification, tag,
val_teams). This is the same operation the HSDES Phoenix "My Items" UI performs
when a user records a result on a test case.

## Trigger

Use this skill when the user asks to:
- "create a test result / TR for this test case"
- "record a pass (or fail) on TC <name/id>"
- "log 2 TRs — one pass, one fail — under <test case>"
- "set the test cycle / val_teams / attribute on these test results"
- "update the test_cycle of TR <id> to <value>"
- any variation of creating or editing `test_result` records

## Prerequisites

- The user's Intel IDSID must be resolved first — defer to the **mtp-identity**
  skill and pass `user_idsid` (used as the TR owner / `closed_by`) on every call.

---

## Part A — Creating a Test Result

### Step 1 — Resolve the parent Test Case (by name, never ask for raw IDs)

If the user described the TC by title/project, resolve it to an HSDES id with
`mtp_query_structure`:

```
mtp_query_structure(
    name="<project>",              # e.g. "ws_mtp", "nvl", "rzl"
    record_types=["TC"],
    title_contains="<test case title>",
    return_records=True,
    user_idsid="<idsid>"
)
```

- Multiple matches → show the list (id, title, subject, owner) and ask the user to pick.
- No matches → broaden the search or ask for clarification.

### Step 2 — Get the result and title

Ask (if not already given):
- **Result** — `pass` or `fail`. (Required.)
- **Title** — the TR title (e.g. `testresut_1`). (Required.)

If the user wants several TRs at once (e.g. "1 pass and 1 fail"), collect a
title + result for each.

### Step 3 — ASK which optional attributes to set (MANDATORY)

Family / classification / val_teams / tag are **inherited automatically** from the
parent TC, so a minimal TR needs only result + title. But **always ask** whether
the user wants to set any optional Test Result attributes at creation time:

> "Do you want to set any optional attributes on the Test Result, or keep the
> defaults inherited from the test case?
> Common Test Result fields:
> - **test_result.test_cycle** — e.g. `acf-x0.val_po.IVE.MVS.PO`
> - **test_result.val_teams** — override the inherited team (e.g. `fv.audio`)
> - **test_result.category** — `functional` (default), `performance`, etc.
> - **test_result.free_tag_3** — free-form tag (e.g. `PPr_HFPGA`)
> - **test_result.log_path** — path/URL to the run log
> - **test_result.details** — free-text notes / result details
> - **test_result.automation** — `yes` / `no` (default `no`)
>
> Give me any field=value pairs, or say 'none' to keep defaults."

Collect the answers into an `extra_fields` dict, e.g.:

```json
{
  "test_result.test_cycle": "acf-x0.val_po.IVE.MVS.PO",
  "test_result.log_path": "\\\\server\\logs\\run123.log"
}
```

> Only ask once. If the user says "none" / "defaults", pass no `extra_fields`.

### Step 4 — VERIFY and get explicit approval (MANDATORY — do not skip)

**Never create a TR without the user's explicit confirmation.** Present a summary
and wait for a "yes":

```
CREATE TEST RESULT — PLEASE VERIFY
────────────────────────────────────────────
PARENT TC:   <title> (<id>) in <project>
             Inherited: family=<..>, val_teams=<..>, tag=<..>
TR(s):
   • "<title_1>"  → <pass|fail>
   • "<title_2>"  → <pass|fail>
OWNER:       <idsid>
EXTRA FIELDS: test_cycle=<..>, log_path=<..>   (or: none)
────────────────────────────────────────────
Proceed? (yes / no)
```

If the user says no or wants changes, adjust and re-confirm. Only proceed on yes.

> **Dry-run tip:** to preview the exact payload without creating anything, call
> `mtp_create_test_result(..., execute=false)`. It returns the built payload and
> creates nothing. Use `execute=true` to actually create the record.

### Step 5 — Execute

For each TR to create:

```
mtp_create_test_result(
    parent_id="<TC id>",
    title="<TR title>",
    result="<pass|fail>",
    extra_fields=<dict or omit>,
    execute=true,
    user_idsid="<idsid>"
)
```

### Step 6 — Report

Report each created TR's `new_id` and `rev`, e.g.:

> "Created 2 Test Results under TC <title> (<id>):
> • `21044868755` testresut_1 → complete.fail
> • `21044868756` testresut_2 → complete.pass"

---

## Part B — Updating attributes on existing Test Results

Use this when the user wants to change fields (e.g. `test_result.test_cycle`,
`test_result.val_teams`) on TRs that already exist.

### Step 1 — Identify the target TR(s)

Resolve the TR id(s) — from the create step above, from the user, or via
`mtp_query_structure` / `mtp_hsdes_lookup`. Never guess IDs.

### Step 2 — ALWAYS fetch the current revision first (MANDATORY)

HSDES updates use **optimistic locking** — you must supply the record's current
`rev`, and the update fails if the record was modified since. This is exactly what
the Phoenix UI does (it calls `get_record_by_id` before every update).

For each TR, fetch the current rev:

```
mtp_get_record(record_id="<TR id>")     # read the "rev" field from the result
```

> Do not skip this. A stale or omitted rev will cause the update to fail.

### Step 3 — Confirm the change

Show the user what will change and on which records:

```
UPDATE TEST RESULTS — PLEASE VERIFY
────────────────────────────────────────────
RECORDS:  21044868755 (rev 1), 21044868756 (rev 1)
CHANGES:  test_result.test_cycle = "acf-x0.val_po.IVE.MVS.PO"
────────────────────────────────────────────
Proceed? (yes / no)
```

### Step 4 — Apply the update

**Multiple TRs (preferred — one batched call):**

```
mtp_bulk_update_records(
    tenant="sighting_central",
    subject="test_result",
    records=[
        {"id": "21044868755", "rev": "1",
         "field_values": {"test_result.test_cycle": "acf-x0.val_po.IVE.MVS.PO"}},
        {"id": "21044868756", "rev": "1",
         "field_values": {"test_result.test_cycle": "acf-x0.val_po.IVE.MVS.PO"}}
    ],
    user_idsid="<idsid>"
)
```

**A single TR:**

```
mtp_update_record(
    record_id="21044868755",
    tenant="sighting_central",
    subject="test_result",
    field_values={"test_result.test_cycle": "acf-x0.val_po.IVE.MVS.PO"},
    rev=1,
    user_idsid="<idsid>"
)
```

> Only send the fields being changed — not the whole record. `send_mail` defaults
> to false. The record's `rev` increments on success (e.g. 1 → 2).

### Step 5 — Report

Report per-record success and the new rev. Optionally re-read with
`mtp_get_record` to confirm the value landed.

---

## Rules

- **Always** resolve the parent TC / target TR by name — never ask for raw IDs.
- **Always** pass `user_idsid` (see the mtp-identity skill); it is the TR owner.
- **Create:** always ASK which optional attributes to set (Part A Step 3) before
  creating, and show the verification summary + get explicit approval (Step 4).
  Never auto-create.
- **Update:** always fetch the current `rev` with `mtp_get_record` FIRST
  (Part B Step 2) — optimistic locking requires it, just like the Phoenix UI.
- Use `execute=false` on `mtp_create_test_result` to dry-run and preview the
  payload before committing.
- Family / classification / val_teams / tag are inherited from the parent TC — do
  not re-enter them unless the user wants to override.
- `result` must be `pass` or `fail`. The tool sets `status=complete` and
  `status_reason=complete.<result>` automatically.
- For bulk updates, all records must share the same `tenant` and `subject`
  (`sighting_central` / `test_result` for TRs).
- Only send changed fields on update — never the whole record.

## Test Result field reference

| Field | Meaning | Example |
|---|---|---|
| `result` (tool arg) | Outcome → status_reason | `pass`, `fail` |
| `title` (tool arg) | TR title | `testresut_1` |
| `test_result.test_cycle` | Validation test cycle | `acf-x0.val_po.IVE.MVS.PO` |
| `test_result.val_teams` | Owning val team | `fv.legacy`, `fv.audio` |
| `test_result.category` | Result category | `functional` |
| `test_result.free_tag_3` | Free-form tag | `PPr_HFPGA` |
| `test_result.log_path` | Path/URL to run log | `\\server\logs\run.log` |
| `test_result.details` | Free-text notes | `boot passed, 0 errors` |
| `test_result.automation` | Automated run? | `yes` / `no` |

## Quick Reference

| Step | Create (Part A) | Update (Part B) |
|---|---|---|
| 1 | Resolve parent TC → id | Identify target TR id(s) |
| 2 | Get result + title | **Get current `rev`** via `mtp_get_record` |
| 3 | **Ask which optional attributes to set** | Confirm the change |
| 4 | **Show summary, get approval** | Apply via `mtp_bulk_update_records` / `mtp_update_record` |
| 5 | Execute `mtp_create_test_result(execute=true)` | Report per-record success + new rev |
| 6 | Report new_id / rev | — |
