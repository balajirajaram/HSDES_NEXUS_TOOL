# Phytuner Plugin

**End-to-end PCIe Gen6 PAM4 PHY recipe optimization agent** for post-silicon validation teams.

## Overview

The Phytuner agent automates the complete PHY recipe development workflow:

1. **Validate** eqmap CSV measurement data (26 required columns, multi-AIC support) with auto-preprocessing
2. **Train** Gaussian Process Regression (GPR) surrogates per AIC with GridSearchCV hyperparameter optimization
3. **Optimize** TX FIR coefficients (Cm1, Cm2, Cp) via auto-selected exhaustive search or enhanced Genetic Algorithm with 70% robustness rule
4. **Generate** 26-slide Intel-branded PowerPoint report with methodology, DoE analysis, GPR validation, and optimization results
5. **Package** final recipe as `.joblib` artifacts for production deployment

Built on **10+ years of research**: ITESO PhD dissertation (Rangel-Patiño 2018), 12 IEEE/Intel papers, and DMR (Diamond Rapids) AI-CoP weekly validation decks WW45-49'25.

## Features

✅ **Multi-AIC Support**: Atlas, CX8, LCD, Marvell 88SS1098, Micron 7500, Nvidia CX7  
✅ **PAM4 Optimization**: TX FIR coefficients (Cm1, Cm2, Cp) for PCIe Gen6 / UXI / CXL 3.0  
✅ **Robustness-First**: 70% rule (industry-standard) ensures recipe works across silicon variance  
✅ **Production-Ready Reports**: 26-slide PPTX with Intel branding, QFBER heatmaps, GPR validation  
✅ **Automated Pipeline**: Single command from CSV → final recipe `.joblib` with auto-preprocessing  
✅ **Smart Optimization**: Auto-selects exhaustive search (≤5000 combos) or enhanced GA with multi-run elitism  
✅ **Advanced Modeling**: GridSearchCV hyperparameter optimization for superior GPR accuracy  
✅ **English-Only Communication**: Enforces professional documentation standards  

## Installation

This plugin is available in the **Intel DCG Agent Marketplace**. Install via:

1. Open VS Code Command Palette (`Ctrl+Shift+P`)
2. Select **"Chat: Install Agent Plugin"**
3. Search for **"phytuner-plugin"**
4. Click **Install**
5. Reload VS Code (`Developer: Reload Window`)

## Usage

### Basic Invocation

```
@Phytuner hello
```

The agent will respond with a 5-bullet briefing of capabilities.

### Full Pipeline Example

```
@Phytuner I have a CSV file at C:\PHY_Data\eqmap_20260610.csv with measurements 
from 6 AICs (Atlas, CX8, LCD, Marvell, Micron, Nvidia). Please:
1. Validate the CSV structure and preprocess coefficients
2. Train GPR surrogates for each AIC with GridSearchCV
3. Optimize TX FIR coefficients using auto-selected method with 70% robustness
4. Generate the PowerPoint report
5. Package everything in a timestamped folder
```

### CSV Validation Only

```
@Phytuner validate this CSV: C:\PHY_Data\eqmap_draft.csv
```

### Direct Script Access

You can also invoke the Python scripts directly via terminal:

```powershell
# Full pipeline
python .github\agents\scripts\phytuner_run.py C:\PHY_Data\eqmap_20260610.csv

# Validation only
python .github\agents\scripts\phytuner_validate_csv.py C:\PHY_Data\eqmap_draft.csv
```

## Requirements

- **Python**: 3.10 or 3.11 (tested on 3.10.11)
- **Dependencies**: Install from skill's `requirements.txt`
  ```powershell
  pip install -r .github/skills/phy-recipe-optimization/requirements.txt
  ```
- **Input**: CSV with 26 required columns (AIC, Lane, Cm1, Cm2, Cp, EW_mUI, EH_mV, etc.)

## CSV Format

Required columns (26 total):
- **Identifiers**: `AIC`, `Lane`, `Preset`
- **TX FIR**: `Cm1`, `Cm2`, `Cp`
- **Eye Diagram**: `EW_mUI`, `EH_mV`, `EH_asym_mV`
- **RX Equalizer**: `RxCTLE_Gain`, `RxCTLE_Pole`, `RxDFE_[1-8]`
- **QFBER**: `QFBER_1e12`, `QFBER_1e15`, `QFBER_1e18`
- **Margining**: `VmarginTop_mV`, `VmarginBottom_mV`

See [`templates/eqmap_example.csv`](skills/phy-recipe-optimization/templates/eqmap_example.csv) for a working example.

## Output Artifacts

The agent produces a timestamped folder (`phyt_MMDD_HHMMSS/`) with:

- **PowerPoint Report**: `PHY_Recipe_Report_YYYYMMDD.pptx` (26 slides)
- **GPR Models**: `gpr_models_per_aic.joblib` (trained surrogates)
- **Optimization Results**: `opt_results_per_aic.json` + `opt_results_global.json`
- **Final Recipe**: `final_recipe.joblib` (TX FIR coefficients for production)
- **Logs**: `phytuner.log` (detailed execution trace)

## Research Foundation

This agent packages:

- **ITESO PhD Dissertation** (Rangel-Patiño 2018): Space Mapping + Broyden updates for high-speed links
- **12 IEEE/Intel Papers** (2014-2025): GPR modeling, GA optimization, K-means clustering, system margining
- **DMR AI-CoP Decks** (WW45-49'25): Weekly validation recipes for Diamond Rapids silicon

## Keywords

`phy` `pcie` `gen6` `pam4` `equalization` `tx-fir` `gpr` `genetic-algorithm` `recipe-optimization` `post-silicon` `dmr` `diamond-rapids` `uxi` `cxl` `qfber` `validation` `intel`

## Owner

**Francisco E. Rangel-Patiño**  
📧 francisco.e.rangel.patino@intel.com  
Platform Solutions Engineering (PSE), Intel DCG

## License

Intel Confidential — Internal Use Only

## Version History

See [CHANGELOG.md](CHANGELOG.md) for detailed release notes.

### 1.1.0 (2026-07-10)
**Major optimization and modeling enhancements**
- Added GridSearchCV hyperparameter optimization for GPR (3 kernels × 3 alphas × 5-fold CV)
- Implemented exhaustive search optimizer with auto-selection (guarantees global optimum for small spaces)
- Enhanced GA with elitism (top 10%) and multi-run strategy (10 runs with best-of selection)
- Reduced robustness threshold from 80% to 70% (industry-standard)
- Auto-preprocessing pipeline (coefficient normalization → FBER→QFBER → Q normalization)
- Fixed PPT report generation (DoE coverage SPLOM and GPR Measured-vs-Predicted slides)
- Universal Recipe now shown in Executive Summary
- Updated all "80%" and "Sobol DoE" terminology

### 1.0.0 (2026-06-10)
**Initial marketplace release**
- Complete 5-stage pipeline (validate → train → optimize → report → pack)
- Multi-AIC support (6 AICs tested)
- 26-slide Intel-branded PowerPoint generation
- GPR + GA optimization with 80% robustness rule
- Provenance removed from Methodology slide (per v1.2.5 update)
