"""Phytuner end-to-end orchestrator (PCIe Gen6 PAM4).

Intel Confidential -- Internal Use Only.

Wraps the lab-validated v1.2.2 scripts (train_kriging_surrogate,
ga_recipe_optimizer, generate_phy_tuning_report) into a single guided
pipeline with progress reporting suitable for the Phytuner VS Code agent.

Stages:
    validate  Run phytuner_validate_csv on the input CSV.
    train     Train one GPR per AIC; write joblibs + training_summary.csv.
    optimize  Run per-AIC GA + (optional) global GA; write recipe CSVs.
    report    Build the 26-slide PPTX (uses --models-dir for M-vs-P slide).
    pack      Bundle joblibs + recipes.json artifacts into the run folder.
    all       Run validate -> train -> optimize -> report -> pack.

The agent will typically:
    1. call --stage train, render the summary, ask the user to approve;
    2. (if not approved) call --stage train --n-restarts 20 (or --kernel matern);
    3. once approved, call --stage optimize, then --stage report --stage pack
       (or simply --stage all when the user already approves the defaults).

CLI:
    python phytuner_run.py --stage all --data <csv> --out-dir runs/ts \\
        [--n-restarts 10] [--no-global] [--seed 42]
"""

from __future__ import annotations

import argparse
import csv
import json
import subprocess
import sys
import time
import zipfile
from datetime import datetime, timezone
from pathlib import Path

import pandas as pd


# ---------------------------------------------------------------------------
# Paths / constants
# ---------------------------------------------------------------------------

THIS_FILE = Path(__file__).resolve()
AGENT_DIR = THIS_FILE.parent.parent          # .github/agents
WORKSPACE_ROOT = AGENT_DIR.parent.parent     # workspace root

SKILL_SCRIPTS = (WORKSPACE_ROOT / ".github" / "skills"
                 / "phy-recipe-optimization" / "scripts")

VALIDATE_PY = AGENT_DIR / "scripts" / "phytuner_validate_csv.py"
TRAIN_PY = SKILL_SCRIPTS / "train_kriging_surrogate.py"
OPTIMIZE_PY = SKILL_SCRIPTS / "ga_recipe_optimizer.py"
EXHAUSTIVE_PY = SKILL_SCRIPTS / "exhaustive_recipe_optimizer.py"
ESTIMATE_TIME_PY = SKILL_SCRIPTS / "estimate_optimization_time.py"
REPORT_PY = SKILL_SCRIPTS / "generate_phy_tuning_report.py"
NORMALIZE_PY = SKILL_SCRIPTS / "normalize_coefficients.py"
FBER_TRANSFORM_PY = SKILL_SCRIPTS / "fber_to_qfber.py"

# Import local helper for optimization time estimation
sys.path.insert(0, str(SKILL_SCRIPTS))
from estimate_optimization_time import estimate_exhaustive_time

VALID_STAGES = ("validate", "train", "optimize", "report", "pack", "all")


# ---------------------------------------------------------------------------
# Optional rich progress; gracefully degrade if unavailable
# ---------------------------------------------------------------------------

try:
    from rich.console import Console
    from rich.panel import Panel
    from rich.table import Table
    _CONSOLE = Console(stderr=True)
    _HAS_RICH = True
except ImportError:
    _CONSOLE = None
    _HAS_RICH = False


def _emit_event(stage: str, status: str = "ok", **fields) -> None:
    """Emit a structured stage event to stderr (one line, key=value)."""
    parts = [f"stage={stage}", f"status={status}"]
    for k, v in fields.items():
        parts.append(f"{k}={v}")
    sys.stderr.write("[event] " + " ".join(parts) + "\n")
    sys.stderr.flush()


def _info(msg: str) -> None:
    if _HAS_RICH:
        _CONSOLE.print(f"[bold cyan]{msg}[/bold cyan]")
    else:
        sys.stderr.write(msg + "\n")
        sys.stderr.flush()


def _banner(title: str, body: str = "") -> None:
    if _HAS_RICH:
        _CONSOLE.print(Panel.fit(body or title, title=title,
                                 border_style="cyan"))
    else:
        sys.stderr.write(f"\n=== {title} ===\n{body}\n")
        sys.stderr.flush()


# ---------------------------------------------------------------------------
# Subprocess wrappers
# ---------------------------------------------------------------------------


def _run_subprocess(cmd: list[str], stage: str) -> int:
    """Run a child Python process, streaming output through to the parent."""
    _info(f"-> {' '.join(str(c) for c in cmd)}")
    t0 = time.time()
    try:
        proc = subprocess.run([sys.executable, *cmd], check=False)
    except OSError as exc:
        _emit_event(stage, status="error", error=f"OSError:{exc}")
        return 99
    dt = time.time() - t0
    _emit_event(stage, status="done" if proc.returncode == 0 else "fail",
                rc=proc.returncode, secs=f"{dt:.1f}")
    return proc.returncode


# ---------------------------------------------------------------------------
# Stages
# ---------------------------------------------------------------------------


def stage_validate(args) -> int:
    """Validate CSV and apply auto-preprocessing if needed."""
    _banner("Stage 1/5 -- Validate CSV & Auto-Preprocess",
            f"file: {args.data}\nDetecting input format (raw or normalized)...")
    _emit_event("validate", status="start", file=str(args.data))
    
    # 1. Run validator to detect preprocessing needs
    import tempfile
    report_json = tempfile.NamedTemporaryFile(
        mode='w', suffix='.json', delete=False)
    report_json.close()
    
    rc = _run_subprocess(
        [str(VALIDATE_PY), "--data", str(args.data), 
         "--json-out", str(report_json.name)],
        "validate")
    
    if rc != 0:
        _info("✗ Initial validation failed; check errors above.")
        return rc
    
    # 2. Read validation report
    try:
        with open(report_json.name, 'r') as f:
            report = json.load(f)
    except Exception as e:
        _info(f"✗ Could not read validation report: {e}")
        return 1
    finally:
        Path(report_json.name).unlink(missing_ok=True)
    
    preprocessing = report.get("preprocessing_needed", [])
    
    if not preprocessing:
        _info("✓ CSV is already in normalized format; no preprocessing needed.")
        return 0
    
    # 3. Apply preprocessing steps sequentially
    current_csv = args.data
    
    # 3a. Normalize coefficients if needed
    if "coefficient_normalization" in preprocessing:
        _banner("Auto-Preprocessing Step 1/2",
                "Normalizing Cm2/Cm1/Cp coefficients to MaxFS reference...")
        temp_csv = args.out_dir / f"{current_csv.stem}_normalized.csv"
        rc = _run_subprocess(
            [str(NORMALIZE_PY), "--data", str(current_csv),
             "--output", str(temp_csv)],
            "normalize_coefficients")
        if rc != 0:
            _info("✗ Coefficient normalization failed.")
            return rc
        current_csv = temp_csv
        _info(f"✓ Coefficients normalized → {temp_csv.name}")
    
    # 3b. Transform FBER to QFBER if needed (or normalize Q_min directly)
    if "fber_to_qfber_transformation" in preprocessing:
        step_num = 1 if "coefficient_normalization" not in preprocessing else 2
        total_steps = len(preprocessing)
        _banner(f"Auto-Preprocessing Step {step_num}/{total_steps}",
                "Transforming fber_max → Q → NormalizedQFBER...")
        temp_csv = args.out_dir / f"{args.data.stem}_qfber.csv"
        rc = _run_subprocess(
            [str(FBER_TRANSFORM_PY), "--data", str(current_csv),
             "--output", str(temp_csv)],
            "fber_to_qfber")
        if rc != 0:
            _info("✗ FBER→Q transformation failed.")
            return rc
        current_csv = temp_csv
        _info(f"✓ FBER→Q transformed → {temp_csv.name}")
    
    # 3c. Normalize Q_min if needed (Priority 1: direct Q normalization)
    if "q_normalization" in preprocessing:
        step_num = 1 if "coefficient_normalization" not in preprocessing else 2
        if "fber_to_qfber_transformation" in preprocessing:
            step_num += 1
        total_steps = len(preprocessing)
        _banner(f"Auto-Preprocessing Step {step_num}/{total_steps}",
                "Normalizing Q_min → NormalizedQFBER (Q / max(Q))...")
        temp_csv = args.out_dir / f"{args.data.stem}_qnorm.csv"
        rc = _run_subprocess(
            [str(FBER_TRANSFORM_PY), "--data", str(current_csv),
             "--output", str(temp_csv)],
            "q_normalization")
        if rc != 0:
            _info("✗ Q normalization failed.")
            return rc
        current_csv = temp_csv
        _info(f"✓ Q normalized → {temp_csv.name}")
    
    # 4. Update args.data to point to preprocessed CSV
    args.data = current_csv
    _info(f"✓ Preprocessing complete. Training will use: {current_csv}")
    
    # 5. Final validation of preprocessed data
    _info("Running final validation on preprocessed data...")
    rc = _run_subprocess(
        [str(VALIDATE_PY), "--data", str(current_csv)],
        "validate_final")
    
    return rc


def stage_train(args) -> int:
    _banner(
        "Stage 2/5 -- Train per-AIC GPR surrogates",
        f"data: {args.data}\nmodels-dir: {args.out_dir}\n"
        f"n_restarts: {args.n_restarts}  test_size: {args.test_size}")
    args.out_dir.mkdir(parents=True, exist_ok=True)
    _emit_event("train", status="start",
                n_restarts=args.n_restarts, test_size=args.test_size)
    cmd = [
        str(TRAIN_PY),
        "--data", str(args.data),
        "--out-dir", str(args.out_dir),
        "--n-restarts", str(args.n_restarts),
        "--test-size", str(args.test_size),
        "--random-state", str(args.seed),
    ]
    if args.use_gridsearch:
        cmd.append("--use-gridsearch")
    rc = _run_subprocess(cmd, "train")

    # Surface the training_summary.csv to the user via the agent.
    summary_csv = args.out_dir / "training_summary.csv"
    if summary_csv.is_file() and _HAS_RICH:
        _render_training_summary_table(summary_csv)
    return rc


def _render_training_summary_table(summary_csv: Path) -> None:
    """Pretty-print training_summary.csv with avg_rel_err thresholds."""
    if not _HAS_RICH:
        return
    table = Table(title="GPR fit quality (per AIC)")
    headers: list[str] = []
    rows: list[list[str]] = []
    with summary_csv.open(encoding="utf-8") as fh:
        reader = csv.reader(fh)
        for i, row in enumerate(reader):
            if i == 0:
                headers = row
            else:
                rows.append(row)
    for h in headers:
        table.add_column(h)
    err_idx = (headers.index("avg_rel_err_euclidean")
               if "avg_rel_err_euclidean" in headers else None)
    for r in rows:
        styled = list(r)
        if err_idx is not None:
            try:
                err = float(r[err_idx])
            except (ValueError, IndexError):
                err = float("nan")
            colour = ("green" if err < 0.10
                      else ("yellow" if err < 0.20 else "red"))
            styled[err_idx] = f"[{colour}]{r[err_idx]}[/{colour}]"
        table.add_row(*styled)
    _CONSOLE.print(table)


def stage_optimize(args) -> int:
    # Determine optimization method
    method = args.optimize_method
    if method == "auto":
        # Auto-select based on search space size
        df = pd.read_csv(args.data)
        n_aics = len(df['EndPoint'].unique())
        n_combos, est_time = estimate_exhaustive_time(df, n_aics)
        # Use exhaustive if < 5000 combinations AND < 2 minutes
        method = "exhaustive" if (n_combos < 5000 and est_time < 120) else "ga"
        _info(f"Auto-selected {method.upper()} optimization ({n_combos:,} combinations, est. {est_time:.0f}s)")
    
    _banner(
        f"Stage 3/5 -- Optimize TX FIR (Cm1, Cm2, Cp) per AIC + global [{method.upper()}]",
        f"models-dir: {args.out_dir}\nout-dir:     {args.out_dir}\n"
        f"method: {method}  global: {'no' if args.no_global else 'yes'}  seed: {args.seed}")
    _emit_event("optimize", status="start",
                method=method, global_ga=str(not args.no_global), seed=args.seed)
    
    plot_dir = args.out_dir / "_plots"
    plot_dir.mkdir(parents=True, exist_ok=True)
    
    # Choose optimizer script
    if method == "exhaustive":
        optimizer_script = EXHAUSTIVE_PY
        cmd = [
            str(optimizer_script),
            "--data", str(args.data),
            "--models-dir", str(args.out_dir),
            "--out-dir", str(args.out_dir),
            "--robustness-threshold", str(args.robustness_threshold),
        ]
        if not args.no_global:
            cmd.append("--global-search")
    else:  # ga
        optimizer_script = OPTIMIZE_PY
        cmd = [
            str(optimizer_script),
            "--data", str(args.data),
            "--models-dir", str(args.out_dir),
            "--out-dir", str(args.out_dir),
            "--plot-dir", str(plot_dir),
            "--seed", str(args.seed),
            "--ga-runs", str(args.ga_runs),
            "--robustness-threshold", str(args.robustness_threshold),
        ]
        if not args.no_global:
            cmd.append("--global-ga")
    
    rc = _run_subprocess(cmd, "optimize")

    # Render per-AIC GA summary table.
    summary_csv = args.out_dir / "per_aic_ga_summary.csv"
    if summary_csv.is_file() and _HAS_RICH:
        _render_ga_summary_table(summary_csv)
    return rc


def _render_ga_summary_table(summary_csv: Path) -> None:
    if not _HAS_RICH:
        return
    table = Table(title="GA-optimized recipes (per AIC)")
    headers: list[str] = []
    rows: list[list[str]] = []
    with summary_csv.open(encoding="utf-8") as fh:
        reader = csv.reader(fh)
        for i, row in enumerate(reader):
            if i == 0:
                headers = row
            else:
                rows.append(row)
    keep = ["AIC", "Cm1", "Cm2", "Cp", "Predicted_QFBER",
            "Is_Robust", "Neighbours_Checked", "Neighbours_Passed"]
    keep_idx = [headers.index(h) for h in keep if h in headers]
    for h in [headers[i] for i in keep_idx]:
        table.add_column(h)
    for r in rows:
        styled = [r[i] for i in keep_idx]
        try:
            qfber = float(r[headers.index("Predicted_QFBER")])
            robust = (r[headers.index("Is_Robust")].strip().lower() == "true")
            colour = ("green" if (robust and qfber >= 0.8)
                      else ("yellow" if (robust and qfber >= 0.5)
                            else "red"))
            q_pos = keep.index("Predicted_QFBER")
            styled[q_pos] = f"[{colour}]{r[headers.index('Predicted_QFBER')]}[/{colour}]"
        except (ValueError, IndexError):
            pass
        table.add_row(*styled)
    _CONSOLE.print(table)


def stage_report(args) -> int:
    # Find or create preprocessed CSV for report generation
    # Report needs: normalized_pre2/pre1/post + NormalizedQFBER columns
    
    source_csv = args.data
    
    # Priority 1: If args.data already points to a preprocessed CSV in out_dir, use it
    # (happens in pipeline completo: validate updates args.data to processed CSV)
    if str(args.data).endswith(("_qnorm.csv", "_normalized.csv", "_qfber.csv")) and args.data.exists():
        source_csv = args.data
        _info(f"✓ Using preprocessed CSV from pipeline: {source_csv.name}")
    
    # Priority 2: Look for preprocessed CSV in out_dir (standalone report case)
    elif args.out_dir.exists():
        # First try to match original filename pattern
        base_stem = args.data.stem.replace("_qnorm", "").replace("_normalized", "").replace("_qfber", "")
        expected_qnorm = args.out_dir / f"{base_stem}_qnorm.csv"
        expected_normalized = args.out_dir / f"{base_stem}_normalized.csv"
        expected_qfber = args.out_dir / f"{base_stem}_qfber.csv"
        
        if expected_qnorm.exists():
            source_csv = expected_qnorm
            _info(f"✓ Using preprocessed CSV: {source_csv.name}")
        elif expected_normalized.exists():
            source_csv = expected_normalized
            _info(f"✓ Using preprocessed CSV: {source_csv.name}")
        elif expected_qfber.exists():
            source_csv = expected_qfber
            _info(f"✓ Using preprocessed CSV: {source_csv.name}")
        else:
            # Fallback: any preprocessed CSV in out_dir
            qnorm_csvs = list(args.out_dir.glob("*_qnorm.csv"))
            normalized_csvs = list(args.out_dir.glob("*_normalized.csv"))
            qfber_csvs = list(args.out_dir.glob("*_qfber.csv"))
            
            if qnorm_csvs:
                source_csv = qnorm_csvs[0]
                _info(f"⚠ No matching preprocessed CSV; using: {source_csv.name}")
            elif normalized_csvs:
                source_csv = normalized_csvs[0]
                _info(f"⚠ No matching preprocessed CSV; using: {source_csv.name}")
            elif qfber_csvs:
                source_csv = qfber_csvs[0]
                _info(f"⚠ No matching preprocessed CSV; using: {source_csv.name}")
            else:
                # Priority 3: Preprocess the input CSV automatically
                _info("⚠ No preprocessed CSV found; running preprocessing now...")
                preprocess_rc = stage_validate(args)
                if preprocess_rc != 0:
                    _info("✗ Preprocessing failed; cannot generate report.")
                    return preprocess_rc
                # After preprocessing, args.data is updated to processed CSV
                source_csv = args.data
                _info(f"✓ Preprocessed CSV ready: {source_csv.name}")
    
    _banner(
        "Stage 4/5 -- Build PPTX report (26 slides)",
        f"out-dir:     {args.out_dir}\nmodels-dir:  {args.out_dir}\n"
        f"source-data: {source_csv}")
    _emit_event("report", status="start")
    # The v1.2.2 reporter writes intermediate PNGs into <out_dir>/_report_assets
    # but does not mkdir it itself; ensure it exists.
    (args.out_dir / "_report_assets").mkdir(parents=True, exist_ok=True)
    cmd = [
        str(REPORT_PY),
        "--out-dir", str(args.out_dir),
        "--training-dir", str(args.out_dir),
        "--plot-dir", str(args.out_dir / "_plots"),
        "--source-data", str(source_csv),
        "--models-dir", str(args.out_dir),
    ]
    return _run_subprocess(cmd, "report")


def stage_pack(args) -> int:
    """Assemble the user-facing artifacts: recipes.json + joblibs.zip."""
    _banner("Stage 5/5 -- Pack artifacts (recipes.json + joblibs.zip)",
            f"out-dir: {args.out_dir}")
    _emit_event("pack", status="start")
    out_dir = args.out_dir
    artifacts: dict[str, str] = {}

    # 1. recipes.json
    per_aic_csv = out_dir / "per_aic_ga_summary.csv"
    global_csv = out_dir / "global_ga_summary.csv"
    if per_aic_csv.is_file():
        recipes = {
            "schema_version": 1,
            "generated_at": datetime.now(timezone.utc).isoformat(),
            "interface": "PCIe Gen6 PAM4",
            "per_aic": _csv_to_records(per_aic_csv),
            "global": (_csv_to_records(global_csv)
                       if global_csv.is_file() else None),
        }
        recipes_path = out_dir / "recipes.json"
        recipes_path.write_text(json.dumps(recipes, indent=2),
                                encoding="utf-8")
        artifacts["recipes.json"] = str(recipes_path)
        _emit_event("pack", status="ok", artifact="recipes.json",
                    aics=len(recipes["per_aic"]))

    # 2. joblibs.zip
    joblibs = sorted(out_dir.glob("*_gpr_model.joblib"))
    if joblibs:
        zip_path = out_dir / "joblibs.zip"
        with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
            for jb in joblibs:
                zf.write(jb, arcname=jb.name)
        artifacts["joblibs.zip"] = str(zip_path)
        _emit_event("pack", status="ok", artifact="joblibs.zip",
                    n_models=len(joblibs))

    # 3. PPTX path (already built by stage_report; just surface it).
    pptx = out_dir / "phy_tuning_report.pptx"
    if pptx.is_file():
        artifacts["phy_tuning_report.pptx"] = str(pptx)

    # Summary file for the agent to consume.
    summary = {
        "out_dir": str(out_dir),
        "artifacts": artifacts,
    }
    (out_dir / "phytuner_run_summary.json").write_text(
        json.dumps(summary, indent=2), encoding="utf-8")
    _emit_event("pack", status="done",
                artifacts=",".join(sorted(artifacts.keys())))
    return 0


def _csv_to_records(path: Path) -> list[dict]:
    with path.open(encoding="utf-8") as fh:
        return list(csv.DictReader(fh))


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------


def _resolve_default_out_dir() -> Path:
    # Keep the folder name short -- on Windows under OneDrive, the workspace
    # root alone eats ~180 chars of the 260-char MAX_PATH budget; matplotlib
    # writes intermediate PNGs under <out_dir>/_report_assets/ with names
    # like 'gpr_measured_vs_predicted.png' (29 chars) which can push the
    # total over the limit if the run-folder name is verbose.
    ts = datetime.now().strftime("%m%d_%H%M%S")
    return WORKSPACE_ROOT / "runs" / f"phyt_{ts}"


def main() -> int:
    p = argparse.ArgumentParser(
        description=__doc__.splitlines()[0],
        formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--stage", choices=VALID_STAGES, default="all",
                   help="Pipeline stage to run (default: all).")
    p.add_argument("--data", type=Path, required=True,
                   help="Input CSV with per-AIC FBER full-sweep "
                        "measurements.")
    p.add_argument("--out-dir", type=Path, default=None,
                   help="Run output directory. Default: "
                        "<workspace>/runs/phytuner_<timestamp>.")
    p.add_argument("--n-restarts", type=int, default=10,
                   help="GPR n_restarts_optimizer (default 10; "
                        "bump to 20 for higher precision).")
    p.add_argument("--test-size", type=float, default=0.2)
    p.add_argument("--seed", type=int, default=42)
    p.add_argument("--robustness-threshold", type=float, default=0.7,
                   help="Robustness threshold (default: 0.7 = 70%%).")
    p.add_argument("--ga-runs", type=int, default=10,
                   help="Number of independent GA runs (multi-run strategy). Default=10.")
    p.add_argument("--use-gridsearch", action="store_true",
                   help="Use GridSearchCV for GPR hyperparameter optimization (slower, better accuracy).")
    p.add_argument("--optimize-method", choices=["ga", "exhaustive", "auto"], default="auto",
                   help="Optimization method: 'ga' (genetic algorithm), 'exhaustive' (full search), "
                        "'auto' (choose based on search space size). Default: auto.")
    p.add_argument("--no-global", action="store_true",
                   help="Skip the global multi-AIC optimization stage.")
    args = p.parse_args()

    if args.out_dir is None:
        args.out_dir = _resolve_default_out_dir()
    args.out_dir = args.out_dir.resolve()
    args.out_dir.mkdir(parents=True, exist_ok=True)

    _info(f"Phytuner run output dir: {args.out_dir}")

    stages_to_run: list[str]
    if args.stage == "all":
        stages_to_run = ["validate", "train", "optimize", "report", "pack"]
    else:
        stages_to_run = [args.stage]

    for stage in stages_to_run:
        rc = {
            "validate": stage_validate,
            "train": stage_train,
            "optimize": stage_optimize,
            "report": stage_report,
            "pack": stage_pack,
        }[stage](args)
        if rc != 0:
            _info(f"[abort] Stage '{stage}' failed (rc={rc}).")
            return rc

    _info("[done] Phytuner pipeline completed.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
