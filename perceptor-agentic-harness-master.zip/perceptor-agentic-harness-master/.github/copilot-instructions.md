## Perceptor Agentic Harness — Contributor Rules

**Purpose:** Harness engineering audit toolkit. Screens repos for harness gaps across 6 dimensions, produces scored reports with contextual suggestions.

**Self-dogfooding:** This repo must score A on its own audit. Run `python tools/harness_audit.py --target .` before any PR.

---

## Enforced Rules

1. **Suggestions, never mandates.** Every finding must use "Consider...", "You might benefit from...", or "This pattern has helped teams...". Never "You must", "This is wrong", or "FAIL" in user-facing output.

2. **Orientation first.** Every specialist reads the repo's orientation profile before applying any check. Checks not relevant to the repo's type are suppressed entirely — not surfaced as "N/A".

3. **No LLM calls in check logic.** All check modules (`tools/checks/*.py`) are pure heuristic. No API calls, no external services. CLI must run offline.

4. **No auto-fix without confirmation.** `@calibrate` only applies changes after the user confirms (a) the target path and (b) each specific change. Never apply changes silently.

5. **Stdlib-only core.** `tools/checks/*.py` and `tools/harness_audit.py` must import only stdlib. PyYAML and Jinja2 are optional; code must work without them.

6. **Severity is internal.** Score deductions use critical/finding/warning/advisory internally. User-facing output never shows these severity labels.

7. **Every check has a test.** Each rule in `tools/checks/*.py` must have a corresponding unit test in `tests/unit/`. New checks without tests are not merged.

8. **Tone contract in outputs.** Every finding follows: Observation → Context → Suggestion → Skip if. Context must reference the repo's detected domain when available.

9. **Scores are weighted averages.** Do not round intermediate scores. Final grade is derived from the weighted average in `config/defaults.yaml`. Do not hardcode grade boundaries.

10. **This repo self-audits.** Run `python tools/harness_audit.py --target . --json` and verify the output is valid JSON before pushing.
