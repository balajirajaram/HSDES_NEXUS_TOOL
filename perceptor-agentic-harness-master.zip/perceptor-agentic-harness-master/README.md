# Perceptor Agentic Harness

A multi-agent harness engineering audit toolkit. Screens any repo for harness engineering gaps
across 6 dimensions and produces scored, actionable reports.

**Philosophy:** Observe, diagnose, prescribe — never command, condemn, or auto-fix.

## Table of Contents

- [Architecture](#architecture)
- [How These Agents Help](#how-these-agents-help)
- [What is Harness Engineering?](#what-is-harness-engineering)
- [Scoring](#scoring)
- [Installation](#installation)
- [Quick Start](#quick-start)
- [Using Agents in VS Code](#using-agents-in-vs-code)
- [Project Layout](#project-layout)
- [Rules for This Repo](#rules-for-this-repo)
- [Design Principles](#design-principles)
- [Dependencies](#dependencies)
- [Running Tests](#running-tests)
- [License](#license)

## Architecture

```
Perceptor (master orchestrator)
├── lens      — Context injection quality (L1-L10)
├── ratchet   — Failure history & rule traceability (R1-R7)
├── spectrum  — Skill decomposition & structure (S1-S8)
├── reflex    — Enforcement, hooks, approval gates (E1-E8)
├── probe     — Test coverage & evaluator patterns (P1-P7)
├── engram    — Memory, caching, knowledge transfer (M1-M6)
└── calibrate — Fixer (applies confirmed changes only)
```

```mermaid
flowchart TD
    User([User / CI]) -->|"@perceptor &lt;path&gt;"| P

    subgraph P ["Perceptor — Master Orchestrator"]
        direction TB
        O["Phase 0: Orientation\n(detect repo type + domain)"]
        O --> L & R & S & RF & PR & E
        L["lens\nContext injection\nL1–L10"]
        R["ratchet\nFailure traceability\nR1–R7"]
        S["spectrum\nSkill structure\nS1–S8"]
        RF["reflex\nEnforcement & hooks\nE1–E8"]
        PR["probe\nTest coverage\nP1–P7"]
        E["engram\nMemory & cache\nM1–M6"]
        L & R & S & RF & PR & E --> SC["Scoring\n(weighted avg → Grade A–F)"]
        SC --> RPT["Report\n(markdown / JSON / HTML)"]
        RPT -->|"user confirms changes"| CAL["@calibrate\nApply fixes"]
    end

    subgraph Target ["Target Repo (read-only)"]
        F1["copilot-instructions.md\nAGENTS.md"]
        F2["SKILL.md files"]
        F3["tests/"]
        F4["docs/known-failures.md\nconfig/verified_transforms.md"]
        F5["tools/validate_output.py\n.github/hooks/"]
    end

    L -.->|reads| F1
    S -.->|reads| F2
    PR -.->|reads| F3
    R & E -.->|reads| F4
    RF -.->|reads| F5

    style P fill:#1e3a5f,color:#fff,stroke:#4a90d9
    style Target fill:#2d2d2d,color:#ccc,stroke:#555
    style CAL fill:#3d5a3e,color:#fff,stroke:#6aaa6b
```

> **Note:** VS Code Copilot does not support `@agentname` inline mentions. Use the **Set Agent** menu to activate a specialist — see [Using agents in VS Code](#using-agents-in-vs-code) below.

Named for the Autobot science team: each agent observes its dimension and prescribes.

## How These Agents Help

Each specialist targets a distinct failure mode that silently degrades agent quality over time.

**1. Token budget pressure — `lens`**
Context windows fill up with stale, oversized, or badly structured instruction files. Every unnecessary token displaces a useful one. `lens` flags instruction files over recommended size limits, code blocks embedded in always-injected prompts, and MCP tool counts that saturate the tool-call budget before the agent even starts working.

**2. The amnesiac agent problem — `ratchet` + `engram`**
Without the ratchet principle, agents repeat the same mistakes across sessions — every restart is a clean slate. `ratchet` checks that behavioral rules in `AGENTS.md` / `copilot-instructions.md` are traceable to a real past failure, not aspirational noise. `engram` checks that verified facts are cached so the agent does not re-derive them (and re-spend tokens) on every session.

**3. Hallucinated test coverage — `probe`**
Judgment-intensive code — classifiers, adapters, output validators — is where agents most frequently produce subtly wrong output. `probe` checks whether that logic has a generator/evaluator split and unit tests. Without it, CI passes but the agent silently degrades on edge cases.

**4. Unconstrained destructive actions — `reflex`**
Agents without approval gates, pre-commit hooks, or destructive-action guards will eventually delete, overwrite, or push something unintended. `reflex` verifies those back-pressure mechanisms exist before something goes wrong in production.

**5. Skill context bloat — `spectrum`**
Skills that are too large or poorly scoped inject unnecessary context on every turn. `spectrum` enforces single-responsibility and progressive disclosure so the right skill is loaded at the right time — not everything at once.

**At a glance:**

| Problem | Without audit | With perceptor |
|---|---|---|
| Bloated instructions | Model degrades silently as context fills | `lens` flags before degradation |
| Repeated mistakes | Agent re-makes known failures every session | `ratchet` ensures rules trace to failures |
| Re-deriving facts | Tokens wasted re-fetching known state | `engram` verifies caching exists |
| No test coverage | Output quality drift goes undetected | `probe` surfaces uncovered classifiers |
| No approval gates | Destructive actions run unchecked | `reflex` verifies guards exist |
| Oversized skills | Wrong or excessive skill context loaded | `spectrum` enforces size limits |

The scored grade (A–F) gives a single number to gate PRs on — the same way code-coverage thresholds gate CI.

## What is Harness Engineering?

A coding agent is the model plus everything built around it. **Harness engineering** — a term coined by Viv Trivedy and synthesized in [Addy Osmani's "Agent Harness Engineering" (April 2026)](https://addyosmani.com/blog/agent-harness-engineering/) — is the discipline of treating that scaffolding as a first-class engineering artifact that tightens every time the agent makes a mistake.

The core equation: `coding agent = AI model + harness`. The harness is system prompts, skill files, MCP tool configurations, hooks, memory files, test coverage, and approval gates. A capable model in a poorly designed harness consistently underperforms a weaker model in a well-designed one. Osmani cites a team that moved from Top 30 to Top 5 on Terminal Bench by changing only the harness — not the model.

**The ratchet** is the discipline's sharpest idea: every agent mistake becomes a permanent rule traceable to that specific failure. Rules without a corresponding failure are noise. This maps directly to postmortem culture in SRE — every production incident produces a runbook entry or an alert rule. The difference is that here the "runbook" is your `AGENTS.md` and the "alert" is a hook or validation check.

**How it compares to familiar software engineering reviews:**

| SE Practice | Harness Engineering Equivalent |
|---|---|
| Static analysis (lint, mypy, eslint) | **lens** + **spectrum** — scan instruction files and skills for structural defects |
| Postmortem → runbook entry | The ratchet — failure → traceable rule in `AGENTS.md` → hook or validator |
| Test coverage report | **probe** — verify judgment-intensive logic (classifiers, adapters) has unit tests |
| Production readiness review | **perceptor** — full pre-ship audit scored across 6 dimensions |
| Architecture review | **reflex** — verify enforcement hooks, approval gates, and back-pressure signals |
| Technical debt audit | **engram** — surface uncached repeated queries and missing memory persistence |

The key difference from static code analysis: harness checks are **heuristic, not syntactic**. A lint rule checks that a variable follows naming style. A harness check asks whether a behavioral rule is traceable, whether a skill has grown too large, or whether a generator exists without a separate evaluator. The checks operate on intent and structure — not code correctness.

## Scoring

Each dimension scores 0–10. Deductions: Critical(−3), Finding(−1.5), Warning(−1), Advisory(−0.5).

| Dimension | Weight |
|-----------|--------|
| Lens      | 20%    |
| Ratchet   | 20%    |
| Spectrum  | 15%    |
| Reflex    | 20%    |
| Probe     | 15%    |
| Engram    | 10%    |

Grade: **A** (≥9) · **B** (≥7) · **C** (≥5) · **D** (≥3) · **F** (<3)

## Installation

### Global (recommended)

```powershell
# Windows
.\scripts\install.ps1
```
```bash
# Linux / macOS
bash scripts/install.sh
```

### Per-repo (submodule)

```bash
git submodule add https://github.com/intel-sandbox/perceptor-agentic-harness .github/skills/perceptor-agentic-harness
```

### Manual

```bash
git clone https://github.com/intel-sandbox/perceptor-agentic-harness ~/.copilot/skills/perceptor-agentic-harness
cp ~/.copilot/skills/perceptor-agentic-harness/agents/perceptor.agent.md ~/.copilot/agents/
```

## Quick Start

### CLI

```bash
# Markdown report (default)
python tools/harness_audit.py --target /path/to/repo

# JSON (for CI)
python tools/harness_audit.py --target /path/to/repo --json

# HTML (for sharing)
python tools/harness_audit.py --target /path/to/repo --format html

# With domain context
python tools/harness_audit.py --target /path/to/repo --context "hardware validation testline porting"

# Single dimension
python tools/harness_audit.py --target /path/to/repo --only ratchet probe

# Save report
python tools/harness_audit.py --target /path/to/repo --save
```

### VS Code Copilot Chat

VS Code does not support inline `@agentname` mentions in the chat input. Use the **Set Agent** dropdown instead:

1. Open **Copilot Chat** (Agent mode).
2. Click the **Set Agent** button (the robot-head icon at the top of the chat panel, or the model-picker dropdown).
3. Select the agent you want — **perceptor**, **lens**, **ratchet**, **spectrum**, **reflex**, **probe**, **engram**, or **calibrate**.
4. Type your request naturally. Examples:

   | Agent | What to type |
   |---|---|
   | **perceptor** | `/path/to/repo` or `. --context "hardware validation"` |
   | **lens** | `.` or a path — audits context injection only |
   | **ratchet** | `.` — audits failure traceability only |
   | **spectrum** | `.` — audits skill structure only |
   | **reflex** | `.` — audits enforcement hooks only |
   | **probe** | `.` — audits test coverage only |
   | **engram** | `.` — audits memory & cache patterns only |
   | **calibrate** | `apply L1 from the last audit` |

5. Each agent will ask for a report output folder. Press **Enter** to accept the default (`reports/` inside this repo).

> **HTML reports from individual agents:** Yes — every specialist agent (lens, ratchet, etc.) saves both a `.md` and a `.html` report to the output folder, identical in format to the full perceptor audit.

### Self-audit

```bash
python tools/harness_audit.py --target . --context "harness engineering audit toolkit"
```

## Project Layout

```
tools/
  harness_audit.py          — CLI orchestrator
  orientation.py            — Phase 0: repo type detection
  finding.py                — Finding dataclass + Severity enum
  checks/
    context_size.py         — @lens (L1-L10)
    failure_history.py      — @ratchet (R1-R7)
    skill_structure.py      — @spectrum (S1-S8)
    enforcement.py          — @reflex (E1-E8)
    test_coverage.py        — @probe (P1-P7)
    memory_cache.py         — @engram (M1-M6)
  report/
    markdown_report.py
    html_report.py
config/
  defaults.yaml             — thresholds, weights, grade boundaries
  thresholds.yaml           — user-overridable overrides
schemas/
  harness_audit.schema.json — JSON output schema
[lens|ratchet|spectrum|reflex|probe|engram|calibrate]/SKILL.md  — VS Code skills
perceptor/SKILL.md          — master orchestrator skill
agents/perceptor.agent.md   — VS Code custom agent
prompts/onboarding.agent.md — setup wizard
scripts/
  install.ps1               — Windows installer
  install.sh                — Linux/macOS installer
tests/unit/                 — 7 test modules
```

## Using Agents in VS Code

After running `install.ps1` (Windows) or `install.sh` (Linux/macOS), the agents appear in the **Set Agent** menu in Copilot Chat. The `@agentname` syntax is **not** supported by VS Code — always use the Set Agent picker.

**Workflow:**
1. Set Agent → **perceptor** (or a specialist)
2. Provide a repo path or `.`
3. When prompted, enter a report output folder (or press Enter for the default `reports/` in this repo)
4. Review the markdown summary in chat; open the `.html` file for the interactive report
5. For fixes: Set Agent → **calibrate**, confirm each change individually

## Rules for This Repo

This repo self-dogfoods. It must score **Grade A** on its own audit.

```bash
python tools/harness_audit.py --target . --json
```

Before any PR: run the self-audit and verify the grade has not regressed.

## Design Principles

1. **Heuristic-only** — no LLM calls during audit. Runs fully offline.
2. **Orientation first** — Phase 0 detects repo type before any check runs. Irrelevant checks are suppressed.
3. **Tone contract** — every finding: Observation → Context → Suggestion → Skip if. "Consider...", never "FAIL".
4. **Severity is internal** — deductions drive scoring internally; user output never shows severity labels.
5. **No auto-fix** — `@calibrate` requires explicit confirmation per change.
6. **Stdlib-only core** — check modules use only Python stdlib. PyYAML and Jinja2 are optional.
7. **Self-dogfooding** — this repo is audited by its own tool on every PR.

## Dependencies

- Python 3.10+
- pytest (for tests)
- PyYAML (optional, for config loading)
- Jinja2 (optional, for richer HTML reports)

```bash
pip install -r requirements.txt
```

## Running Tests

```bash
pytest tests/unit/ -v
```

Expected: all tests pass.

## License

Intel Corporation — AI COE. Internal use.
