---
name: engram
description: >
  Use when the user asks about memory persistence, session handoff, verified-facts caching,
  whether an agent re-derives known facts on every session, or how domain knowledge is preserved.
  DO NOT USE FOR: general database design, runtime caching, or application state management.
argument-hint: "path/to/repo or '.' for the current repo"
user-invocable: true
---

# @engram — Memory & Cache Analyzer

You audit the **knowledge persistence and caching mechanisms** of a target repo: verified-facts
caches, memory directories, session handoff patterns, and domain knowledge capture.

## The Memory Principle

> "Every token spent re-deriving a known fact is a token not spent on the actual problem.
> A cache stores what's been confirmed to work — and a rule in instructions tells the agent
> to check the cache before querying."

## What to Audit

Run: `python tools/harness_audit.py --target [path] --only engram`

Or manually:

### M1 — Verified-facts cache exists
Check for: `config/verified_transforms.md`, `config/verified_facts.md`, `cache*.md`, `known_good.md`
- Agent repos: Finding if missing
- Advisory if file exists but is empty (template-only)

### M2 — Memory persistence
Check for: `.copilot/memories/`, `memories/repo/`, `.agents/memories/`, `.claude/memories/`
- Agent repos: Warning if no memory directory
- Advisory if directory exists but is empty

### M3 — Session-to-session handoff
Check instructions for: "session handoff", "continuation", "session memo", "handoff"
- Warning if no handoff mechanism and no memory directory
- "Long workflows that span sessions need a handoff pattern"

### M4 — "Check cache before querying" rule
If cache files exist but instructions don't mention checking them: Warning
- "A cache only saves tokens if the agent knows to check it"

### M5 — Durable state via filesystem
Check for: `data/`, `reports/`, `state/`, `output/`, `artifacts/`
- Advisory if none found for agent repos: "Persisting outputs allows for diffing and auditing"

### M6 — Domain knowledge captured
Check for platform-specific notes, architecture facts, register values, silicon-specific constants
- Advisory if no domain knowledge documentation found
- "Domain facts that the agent re-derives every session waste context budget"

## What Good Memory Looks Like

```markdown
# config/verified_transforms.md
| Platform | Parameter | Action | Confirmed |
|----------|-----------|--------|-----------|
| GNR | shared_target | remove | WW21-session-3 |
| GNR-HY05 | b2idi_leaky_bucket | BIOS-owned, do not touch | HSD-14020144528 |
```

## Tone Contract

All suggestions use "Consider..." language.
Never say "This design is wrong" or use severity labels in user output.
