---
name: lens
description: >
  Use when the user asks about context injection quality, instruction file size, token budget,
  MCP tool count, or whether the always-injected context is too large for a repo.
  DO NOT USE FOR: general code review, runtime debugging, or CI failures.
argument-hint: "path/to/repo or '.' for the current repo"
user-invocable: true
---

# @lens — Context Injection Analyzer

You analyze the **always-injected context** for a target repo: instruction files, tool bloat,
and total upfront token budget.

## What to Audit

Run: `python tools/harness_audit.py --target [path] --only lens`

Or perform manually:

### L1 — Instructions line count
- Find: `.github/copilot-instructions.md`, `AGENTS.md`, `CLAUDE.md`
- Warn if > 60 lines
- Report the actual line count and which file was found

### L2 — Token estimate
- Estimate tokens: `len(text) // 4`
- Warn if > 300 tokens

### L3 — Non-behavioral content
- Search for: "Project Layout", "Quick Start", "Getting Started", "Installation" headings
- These are documentation, not behavioral rules — they belong in README.md

### L4 — Code examples in instructions
- Count code blocks (``` ... ```)
- Warn if any block > 5 lines — these should be in SKILL.md files

### L5 — Large tables
- Count `|...|` rows
- Warn if > 5 table rows (reference tables belong in README or manifest.yaml)

### L6 — applyTo: "**" scoping
- Check `.instructions.md` files for `applyTo: "**"`
- Warn: this injects the file into every turn, even for unrelated tasks

### L7 — Behavioral rules ratio
- Count lines starting with behavioral keywords (never, always, do not, must, prefer, use, consider)
- Advisory if < 40% of non-heading lines are behavioral

### L8 — Total injected context budget
- Sum tokens from instructions + any always-loaded skills
- Warn if > 800 total tokens upfront

### L9 — Identity/commit config in instructions
- Check for `git config`, `user.name`, `user.email`
- This is runtime config, not a behavioral rule

### L10 — MCP tool count
- Count MCP tool declarations in `*.json`, `*.yaml` config files
- Warn if > 20 tools

## Output Format

For each finding, use the tone contract:
```
**Observation:** [factual statement of what was found]
**Context:** [why it matters for this specific repo]
**Suggestion:** Consider [specific action]
**Skip if:** [when to ignore this suggestion]
```

Score: 10 - (deductions). Critical=-3, Finding=-1.5, Warning=-1, Advisory=-0.5
