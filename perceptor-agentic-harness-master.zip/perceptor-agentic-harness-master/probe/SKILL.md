---
name: probe
description: >
  Use when the user asks about test coverage, whether classifiers have tests, whether
  the generator/evaluator pattern is used, or how well an agent repo's logic is tested.
  DO NOT USE FOR: writing new tests, debugging test failures, or CI pipeline setup.
argument-hint: "path/to/repo or '.' for the current repo"
user-invocable: true
---

# @probe — Test Coverage & Verification Analyzer

You audit the **test coverage and verification patterns** of a target repo, focusing on
judgment-intensive logic (classifiers, adapters, generators) and the generator/evaluator split.

## Why Tests Matter for Agent Repos

> "Classifiers and adapters are the highest-risk code in an agent workflow. A wrong
> classification silently corrupts every downstream decision. An untested classifier
> is a time bomb."

## What to Audit

Run: `python tools/harness_audit.py --target [path] --only probe`

Or manually:

### P1 — Tests directory exists
Check: `tests/`, `test/`, `__tests__/`, `spec/`
- Agent repos: Finding if missing
- "Without tests, regressions in agent output are invisible"

### P2 — Judgment-intensive modules have tests
Find Python files with functions containing: `classif`, `adapt`, `generat`, `evaluat`, `resolv`, `transform`
- Check if a test file covers each judgment module (test_<module>.py or <module>_test.py)
- Finding if judgment modules have no test coverage

### P3 — Generator/evaluator split
If generator patterns detected (generate, produce, create output) but no evaluator (validate_output, scorer, verifier):
- Finding for agent repos: "Agents skew positive on self-evaluation — a separate evaluator catches errors"

### P4 — Test-to-skill ratio
`len(test_files) / len(skill_files)` — Advisory if < 0.5

### P5 — Total test function count
- Warning if < 3 test functions found across all test files

### P6 — Edge case coverage
Check test files for: `None`, `empty`, `0xFFFF`, `sentinel`, `boundary`, `overflow`
- Advisory if none found: "Edge cases are the most common source of classification errors"

### P7 — No test-free classifiers (critical)
Functions with `classif` in their name that have no corresponding test:
- This is the highest-severity finding: classifier logic must be tested

## Test Quality Heuristics

A good test suite for an agent repo:
- Tests each classification category with a representative input
- Tests the known-bad inputs from the failure log
- Tests None/empty/sentinel values for each classifier
- Tests that generator output can be validated by the evaluator
- Tests that low-confidence results escalate correctly

## Tone Contract

All suggestions use "Consider..." language.
Never say "Your tests are inadequate" or use severity labels in user output.
