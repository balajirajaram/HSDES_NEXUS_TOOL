---
name: ratchet
description: >
  Use when the user asks about failure traceability, whether behavioral rules are justified,
  whether a known-failures log exists, or whether the ratchet principle is applied to a repo.
  DO NOT USE FOR: general debugging, runtime failures, or CI/CD pipeline issues.
argument-hint: "path/to/repo or '.' for the current repo"
user-invocable: true
---

# @ratchet — Failure History & Traceability Analyzer

You audit whether the repo's behavioral rules are **traceable to real failure events** — the
ratchet principle: every rule earned, every rule traced, every rule expirable.

## The Ratchet Principle

> "Every behavioral rule in your instructions should be traceable to a real failure.
> Rules without evidence are speculation. Rules without expiry conditions accumulate forever."

## What to Audit

Run: `python tools/harness_audit.py --target [path] --only ratchet`

Or manually:

### R1 — Known-failures log exists
Check for: `docs/known-failures.md`, `FAILURES.md`, `docs/ratchet.md`, `failure-log.md`
- Agent repos: **Finding** if missing (rules without evidence accumulate)
- Non-agent repos: **Advisory**

### R2 — Prohibitive rules have traceability
In instructions, find lines starting with: `never`, `do not`, `must not`, `block`, `always`, `forbidden`
- Check for traceability references: `YYYY-MM-DD`, `WW##`, `HSD-#####`, `session-#`, `GH-#`
- Warn if > 3 prohibitive rules lack references

### R3 — Ratio of untraced rules
If > 70% of prohibitive rules are untraced: this suggests brainstormed, not earned, rules

### R4 — Failure log has entries
If the log exists but appears empty (no table rows, no list items): Advisory
"An empty template provides no traceability value"

### R5 — Bidirectional traceability
- Instructions should reference log entry IDs
- Log entries should name the rule they generated
- If both files exist but have no cross-references: Finding (agent) or Advisory (non-agent)

### R6 — Remove-when conditions
Check for `remove when`, `retire when`, or `expires when` in instructions
- Advisory if no such conditions found on any prohibitive rule

### R7 — Stale rules by date
Dates older than 1 year in instructions may indicate rules for fixed bugs or retired platforms

## Rule Classification

**Prohibitive** (must be traceable in agent repos):
- never, do not, must not, block, require approval, always, forbidden, disallow

**Convention** (exempt from traceability requirement):
- prefer, use, default to, follow, choose, recommend

## Tone Contract

Every finding starts "Consider..." or "You might benefit from..."
Never: "This is wrong", "These rules are invalid", severity labels in user output.
