# Install Perceptor Agentic Harness - Windows
# Run from PowerShell: .\scripts\install.ps1

$ErrorActionPreference = "Stop"

$SKILLS_BASE = "$env:USERPROFILE\.copilot\skills"
$AGENTS_BASE = "$env:USERPROFILE\.copilot\agents"
$REPO_URL    = "https://github.com/intel-sandbox/perceptor-agentic-harness.git"
$DEST        = "$SKILLS_BASE\perceptor-agentic-harness"

Write-Host "==> Installing Perceptor Agentic Harness" -ForegroundColor Cyan
Write-Host "    Destination: $DEST"

# Create skills directory if it doesn't exist
if (-not (Test-Path $SKILLS_BASE)) {
    New-Item -ItemType Directory -Force -Path $SKILLS_BASE | Out-Null
    Write-Host "    Created $SKILLS_BASE"
}

# Clone or update
if (Test-Path $DEST) {
    Write-Host "==> Existing install found. Updating..."
    Push-Location $DEST
    git pull --ff-only
    Pop-Location
} else {
    Write-Host "==> Cloning repo..."
    git clone --depth=1 $REPO_URL $DEST
}

# Copy each skill folder directly into ~/.copilot/skills/<name>/ for VS Code discovery.
# VS Code looks for SKILL.md at exactly one level deep: ~/.copilot/skills/<name>/SKILL.md
$SKILLS = @("perceptor", "lens", "ratchet", "spectrum", "reflex", "probe", "engram", "calibrate")
foreach ($skill in $SKILLS) {
    $src = "$DEST\$skill"
    $dst = "$SKILLS_BASE\$skill"
    if (Test-Path $src) {
        if (Test-Path $dst) { Remove-Item $dst -Recurse -Force }
        Copy-Item $src $dst -Recurse -Force
        Write-Host "    Skill installed: $SKILLS_BASE\$skill\SKILL.md"
    }
}
Write-Host "==> Skills installed to $SKILLS_BASE"

# Copy all agent files to ~/.copilot/agents/ for VS Code @name discovery.
# Each .agent.md file becomes a separately invokable @agentname in chat.
if (-not (Test-Path $AGENTS_BASE)) {
    New-Item -ItemType Directory -Force -Path $AGENTS_BASE | Out-Null
}
foreach ($agentFile in Get-ChildItem "$DEST\agents\*.agent.md") {
    Copy-Item $agentFile.FullName "$AGENTS_BASE\$($agentFile.Name)" -Force
    Write-Host "    Agent installed: $AGENTS_BASE\$($agentFile.Name)"
}
Write-Host "==> Agents installed to $AGENTS_BASE"

# Install Python dependencies
$python = Get-Command python -ErrorAction SilentlyContinue
if ($python) {
    Write-Host "==> Installing Python dependencies..."
    python -m pip install -r "$DEST\requirements.txt" -q
} else {
    Write-Host "    [WARNING] Python not found. Install manually: pip install -r requirements.txt" -ForegroundColor Yellow
}

# Verify
Write-Host ""
Write-Host "==> Verifying installation..." -ForegroundColor Cyan
python "$DEST\tools\harness_audit.py" --target $DEST --json | Out-Null
if ($LASTEXITCODE -le 1) {
    Write-Host "    OK - harness_audit.py runs successfully." -ForegroundColor Green
} else {
    Write-Host "    [WARNING] harness_audit.py returned unexpected exit code $LASTEXITCODE" -ForegroundColor Yellow
}

Write-Host ""
Write-Host "==> Installation complete!" -ForegroundColor Green
Write-Host ""
Write-Host "    Skills available:"
Write-Host "      @perceptor - full audit orchestrator"
Write-Host "      @lens      - context injection analysis"
Write-Host "      @ratchet   - failure traceability"
Write-Host "      @spectrum  - skill structure"
Write-Host "      @reflex    - enforcement & hooks"
Write-Host "      @probe     - test coverage"
Write-Host "      @engram    - memory & caching"
Write-Host "      @calibrate - apply confirmed fixes"
Write-Host ""
Write-Host "    Quick start:"
Write-Host "      python `"$DEST\tools\harness_audit.py`" --target /path/to/your/repo"
Write-Host "      OR in VS Code Copilot chat: @perceptor /path/to/your/repo"
