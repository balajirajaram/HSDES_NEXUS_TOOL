#!/usr/bin/env bash
# Install Perceptor Agentic Harness — Linux / macOS
# Run: bash scripts/install.sh

set -euo pipefail

SKILLS_BASE="${HOME}/.copilot/skills"
AGENTS_BASE="${HOME}/.copilot/agents"
REPO_URL="https://github.com/intel-sandbox/perceptor-agentic-harness.git"
DEST="${SKILLS_BASE}/perceptor-agentic-harness"

echo "==> Installing Perceptor Agentic Harness"
echo "    Destination: ${DEST}"

# Create skills directory if it doesn't exist
mkdir -p "${SKILLS_BASE}"

# Clone or update
if [ -d "${DEST}/.git" ]; then
    echo "==> Existing install found. Updating..."
    git -C "${DEST}" pull --ff-only
else
    echo "==> Cloning repo..."
    git clone --depth=1 "${REPO_URL}" "${DEST}"
fi

# Copy each skill folder directly into ~/.copilot/skills/<name>/ for VS Code discovery.
# VS Code looks for SKILL.md at exactly one level deep: ~/.copilot/skills/<name>/SKILL.md
for skill in perceptor lens ratchet spectrum reflex probe engram calibrate; do
    src="${DEST}/${skill}"
    dst="${SKILLS_BASE}/${skill}"
    if [ -d "${src}" ]; then
        rm -rf "${dst}"
        cp -r "${src}" "${dst}"
        echo "    Skill installed: ${SKILLS_BASE}/${skill}/SKILL.md"
    fi
done
echo "==> Skills installed to ${SKILLS_BASE}"

# Copy all agent files to ~/.copilot/agents/ for VS Code @name discovery.
mkdir -p "${AGENTS_BASE}"
for agent_file in "${DEST}/agents/"*.agent.md; do
    fname="$(basename "${agent_file}")"
    cp "${agent_file}" "${AGENTS_BASE}/${fname}"
    echo "    Agent installed: ${AGENTS_BASE}/${fname}"
done
echo "==> Agents installed to ${AGENTS_BASE}"

# Install Python dependencies
if command -v python3 &>/dev/null; then
    echo "==> Installing Python dependencies..."
    python3 -m pip install -r "${DEST}/requirements.txt" -q
elif command -v python &>/dev/null; then
    python -m pip install -r "${DEST}/requirements.txt" -q
else
    echo "    [WARNING] Python not found. Install manually: pip install -r requirements.txt"
fi

# Verify
echo ""
echo "==> Verifying installation..."
if python3 "${DEST}/tools/harness_audit.py" --target "${DEST}" --json > /dev/null 2>&1; then
    echo "    OK — harness_audit.py runs successfully."
else
    echo "    [WARNING] harness_audit.py returned unexpected exit code. Check Python path."
fi

echo ""
echo "==> Installation complete!"
echo ""
echo "    Skills available:"
echo "      @perceptor — full audit orchestrator"
echo "      @lens      — context injection analysis"
echo "      @ratchet   — failure traceability"
echo "      @spectrum  — skill structure"
echo "      @reflex    — enforcement & hooks"
echo "      @probe     — test coverage"
echo "      @engram    — memory & caching"
echo "      @calibrate — apply confirmed fixes"
echo ""
echo "    Quick start:"
echo "      python3 ${DEST}/tools/harness_audit.py --target /path/to/your/repo"
echo "      OR in VS Code Copilot chat: @perceptor /path/to/your/repo"
