---
name: spectrum
description: >
  Use when the user asks about skill file organization, whether skills are too large,
  whether skills have good descriptions, or whether progressive disclosure is used.
  DO NOT USE FOR: general code organization, testing, or debugging.
argument-hint: "path/to/repo or '.' for the current repo"
user-invocable: true
---

# @spectrum — Skill Decomposition & Progressive Disclosure Analyzer

You audit the **skill structure** of a target repo: file size, YAML frontmatter quality,
single-responsibility, progressive disclosure, and trigger descriptions.

## The Progressive Disclosure Principle

> "Don't front-load all skills at session start. Load the right skill for the current task,
> and unload it when the task is done. The token budget is finite — spend it wisely."

## What to Audit

Run: `python tools/harness_audit.py --target [path] --only spectrum`

Or manually:

### S1 — Monolithic skill size
- Find all `SKILL.md` files
- Warn if any is > 200 lines
- "A skill should do one thing and do it well"

### S2 — Manifest for multi-skill repos
- If ≥ 3 SKILL.md files exist and no `manifest.yaml`: Warning
- Manifest provides skill inventory for contributors

### S3 — YAML frontmatter completeness
Every SKILL.md should have:
```yaml
---
name: <skill-name>
description: Use when ...
---
```
Warn if `name` or `description` is missing

### S4 — Trigger keywords in description
- Check for "Use when", "When to use", "Triggers:"
- Without these, VS Code can't reliably auto-select the skill

### S5 — Progressive loading pattern
- If a skill > 100 lines and has no sub-skill loading: Advisory
- "A coordinator + sub-skills pattern extends the effective context budget"

### S6 — Single responsibility
- Check description for AND-joined responsibilities: "classifies AND generates"
- "Two unrelated tasks in one skill = harder to invoke + harder to test"

### S7 — Content quality ratio
- If > 70% of lines are passive prose (not steps, checklists, decisions): Advisory
- "A skill that's mostly narrative provides less value per token"

### S8 — Broad triggers need DO NOT USE FOR clause
- If description has "any", "all", "general", "universal": check for "DO NOT USE FOR"
- Without the exclusion clause, broad skills get invoked for unrelated tasks

## Tone Contract

All suggestions use "Consider...", "You might benefit from..."
Never label content as "wrong" or "invalid" in user output.
