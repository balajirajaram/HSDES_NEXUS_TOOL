"""
Tests for tools/checks/context_size.py — @lens checks (L1-L10).
"""
import sys
from pathlib import Path

import pytest

_REPO_ROOT = Path(__file__).resolve().parent.parent.parent
sys.path.insert(0, str(_REPO_ROOT))

from tools.orientation import detect_profile
from tools.checks.context_size import run
from tools.finding import Severity


def make_repo(tmp_path: Path, files: dict[str, str]) -> Path:
    for rel, content in files.items():
        p = tmp_path / rel
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(content, encoding="utf-8")
    return tmp_path


_DEFAULT_CFG = {
    "lens": {
        "instructions_max_lines": 60,
        "instructions_max_tokens": 300,
        "total_injected_max_tokens": 800,
        "mcp_tool_count_warn": 20,
        "code_example_lines_warn": 5,
        "table_rows_warn": 5,
    }
}


class TestL1LineCount:
    def test_no_instructions_raises_warning(self, tmp_path):
        profile = detect_profile(tmp_path)
        findings = run(tmp_path, profile, _DEFAULT_CFG)
        rule_ids = [f.rule_id for f in findings]
        assert "L1" in rule_ids

    def test_short_instructions_no_l1_finding(self, tmp_path):
        content = "\n".join([f"{i}. Never do X." for i in range(10)])
        make_repo(tmp_path, {".github/copilot-instructions.md": content})
        profile = detect_profile(tmp_path)
        findings = run(tmp_path, profile, _DEFAULT_CFG)
        l1 = [f for f in findings if f.rule_id == "L1"]
        assert not l1  # Under 60 lines, no finding

    def test_long_instructions_triggers_l1(self, tmp_path):
        content = "\n".join([f"{i}. Rule number {i}." for i in range(100)])
        make_repo(tmp_path, {".github/copilot-instructions.md": content})
        profile = detect_profile(tmp_path)
        findings = run(tmp_path, profile, _DEFAULT_CFG)
        l1 = [f for f in findings if f.rule_id == "L1"]
        assert l1


class TestL3NonBehavioralContent:
    def test_layout_section_triggers_l3(self, tmp_path):
        content = "# Rules\n## Project Layout\n```\nfoo/\nbar/\n```\n"
        make_repo(tmp_path, {".github/copilot-instructions.md": content})
        profile = detect_profile(tmp_path)
        findings = run(tmp_path, profile, _DEFAULT_CFG)
        assert any(f.rule_id == "L3" for f in findings)

    def test_no_layout_no_l3(self, tmp_path):
        content = "1. Never auto-commit.\n2. Always confirm.\n"
        make_repo(tmp_path, {".github/copilot-instructions.md": content})
        profile = detect_profile(tmp_path)
        findings = run(tmp_path, profile, _DEFAULT_CFG)
        assert not any(f.rule_id == "L3" for f in findings)


class TestL4CodeBlocks:
    def test_large_code_block_triggers_l4(self, tmp_path):
        block = "```python\n" + "\n".join([f"x = {i}" for i in range(10)]) + "\n```"
        content = f"# Rules\n{block}"
        make_repo(tmp_path, {".github/copilot-instructions.md": content})
        profile = detect_profile(tmp_path)
        findings = run(tmp_path, profile, _DEFAULT_CFG)
        assert any(f.rule_id == "L4" for f in findings)

    def test_small_code_block_no_l4(self, tmp_path):
        content = "# Rules\n```\nx = 1\n```\n1. Never auto-commit.\n"
        make_repo(tmp_path, {".github/copilot-instructions.md": content})
        profile = detect_profile(tmp_path)
        findings = run(tmp_path, profile, _DEFAULT_CFG)
        assert not any(f.rule_id == "L4" for f in findings)


class TestL9IdentityInInstructions:
    def test_git_config_triggers_l9(self, tmp_path):
        content = "1. Never auto-commit.\ngit config user.name 'Agent'\n"
        make_repo(tmp_path, {".github/copilot-instructions.md": content})
        profile = detect_profile(tmp_path)
        findings = run(tmp_path, profile, _DEFAULT_CFG)
        assert any(f.rule_id == "L9" for f in findings)

    def test_no_identity_no_l9(self, tmp_path):
        content = "1. Never auto-commit.\n2. Always confirm.\n"
        make_repo(tmp_path, {".github/copilot-instructions.md": content})
        profile = detect_profile(tmp_path)
        findings = run(tmp_path, profile, _DEFAULT_CFG)
        assert not any(f.rule_id == "L9" for f in findings)


class TestSuggestionLanguage:
    def test_all_suggestions_start_with_consider(self, tmp_path):
        """All user-facing suggestions must use Consider/You might/This pattern language."""
        # Trigger as many findings as possible
        content = (
            "\n".join([f"{i}. Rule {i}." for i in range(80)])  # L1: long
            + "\n## Project Layout\nfoo/\n"                    # L3: layout
            + "\ngit config user.name 'Bot'\n"                 # L9: identity
        )
        make_repo(tmp_path, {".github/copilot-instructions.md": content})
        profile = detect_profile(tmp_path)
        findings = run(tmp_path, profile, _DEFAULT_CFG)
        for f in findings:
            lower = f.suggestion.lower()
            assert (
                lower.startswith("consider")
                or lower.startswith("you might")
                or lower.startswith("this pattern")
            ), f"Suggestion for {f.rule_id} does not start with 'Consider': {f.suggestion[:50]}"
