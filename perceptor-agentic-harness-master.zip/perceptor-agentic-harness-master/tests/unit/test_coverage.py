"""
Tests for tools/checks/test_coverage.py — @probe checks (P1-P7).
"""
import sys
from pathlib import Path

import pytest

_REPO_ROOT = Path(__file__).resolve().parent.parent.parent
sys.path.insert(0, str(_REPO_ROOT))

from tools.orientation import detect_profile
from tools.checks.test_coverage import run, _has_judgment_logic, _test_covers_module
from tools.finding import Severity


def make_repo(tmp_path: Path, files: dict[str, str]) -> Path:
    for rel, content in files.items():
        p = tmp_path / rel
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(content, encoding="utf-8")
    return tmp_path


_DEFAULT_CFG = {"probe": {"judgment_keywords": ["classif", "adapt", "generat", "evaluat"]}}


class TestP1TestsExist:
    def test_no_tests_triggers_p1(self, tmp_path):
        make_repo(tmp_path, {"lens/SKILL.md": "---\nname: lens\n---"})
        profile = detect_profile(tmp_path)
        findings = run(tmp_path, profile, _DEFAULT_CFG)
        assert any(f.rule_id == "P1" for f in findings)

    def test_tests_dir_no_p1(self, tmp_path):
        make_repo(tmp_path, {
            "lens/SKILL.md": "---\nname: lens\n---",
            "tests/unit/test_something.py": "def test_foo():\n    assert True\n",
        })
        profile = detect_profile(tmp_path)
        findings = run(tmp_path, profile, _DEFAULT_CFG)
        assert not any(f.rule_id == "P1" for f in findings)


class TestP2JudgmentModulesCovered:
    def test_classifier_without_test_triggers_p2(self, tmp_path):
        make_repo(tmp_path, {
            "lens/SKILL.md": "---\nname: lens\n---",
            "tools/classifier.py": "def classify_failure(text):\n    return 'software'\n",
            "tests/unit/test_unrelated.py": "def test_foo():\n    assert True\n",
        })
        profile = detect_profile(tmp_path)
        findings = run(tmp_path, profile, _DEFAULT_CFG)
        assert any(f.rule_id in ("P2", "P7") for f in findings)

    def test_classifier_with_test_no_p2(self, tmp_path):
        make_repo(tmp_path, {
            "lens/SKILL.md": "---\nname: lens\n---",
            "tools/classifier.py": "def classify_failure(text):\n    return 'software'\n",
            "tests/unit/test_classifier.py": "def test_classify_software():\n    assert True\n",
        })
        profile = detect_profile(tmp_path)
        findings = run(tmp_path, profile, _DEFAULT_CFG)
        assert not any(f.rule_id == "P7" for f in findings)


class TestHasJudgmentLogic:
    def test_classify_function_detected(self, tmp_path):
        py_file = tmp_path / "classifier.py"
        py_file.write_text("def classify_failure(text):\n    return 'software'\n")
        has_j, funcs = _has_judgment_logic(py_file)
        assert has_j
        assert "classify_failure" in funcs

    def test_adapter_function_detected(self, tmp_path):
        py_file = tmp_path / "adapter.py"
        py_file.write_text("def adapt_catalog(catalog):\n    return catalog\n")
        has_j, funcs = _has_judgment_logic(py_file)
        assert has_j
        assert "adapt_catalog" in funcs

    def test_no_judgment_function_returns_false(self, tmp_path):
        py_file = tmp_path / "utils.py"
        py_file.write_text("def read_file(path):\n    return open(path).read()\n")
        has_j, funcs = _has_judgment_logic(py_file)
        assert not has_j
        assert funcs == []


class TestTestCoversModule:
    def test_direct_name_match(self, tmp_path):
        test_file = tmp_path / "tests" / "test_classifier.py"
        test_file.parent.mkdir(parents=True)
        test_file.write_text("def test_foo(): pass\n")
        assert _test_covers_module("classifier", [test_file])

    def test_no_match_returns_false(self, tmp_path):
        test_file = tmp_path / "tests" / "test_unrelated.py"
        test_file.parent.mkdir(parents=True)
        test_file.write_text("def test_foo(): pass\n")
        assert not _test_covers_module("classifier", [test_file])


class TestP6EdgeCaseCoverage:
    def test_no_edge_cases_triggers_p6(self, tmp_path):
        make_repo(tmp_path, {
            "lens/SKILL.md": "---\nname: lens\n---",
            "tools/classifier.py": "def classify_failure(text):\n    return 'software'\n",
            "tests/unit/test_classifier.py": (
                "def test_basic():\n    assert classify_failure('error') == 'software'\n"
            ),
        })
        profile = detect_profile(tmp_path)
        findings = run(tmp_path, profile, _DEFAULT_CFG)
        assert any(f.rule_id == "P6" for f in findings)

    def test_sentinel_value_in_tests_no_p6(self, tmp_path):
        make_repo(tmp_path, {
            "lens/SKILL.md": "---\nname: lens\n---",
            "tools/classifier.py": "def classify_failure(text):\n    return 'software'\n",
            "tests/unit/test_classifier.py": (
                "def test_sentinel():\n    assert classify_failure(None) is not None\n"
                "def test_boundary():\n    assert classify_failure('0xFFFF error') == 'software'\n"
            ),
        })
        profile = detect_profile(tmp_path)
        findings = run(tmp_path, profile, _DEFAULT_CFG)
        assert not any(f.rule_id == "P6" for f in findings)
