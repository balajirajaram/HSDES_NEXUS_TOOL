"""
Tests for tools/checks/enforcement.py — @reflex checks (E1-E8).
"""
import sys
from pathlib import Path

import pytest

_REPO_ROOT = Path(__file__).resolve().parent.parent.parent
sys.path.insert(0, str(_REPO_ROOT))

from tools.orientation import detect_profile
from tools.checks.enforcement import run
from tools.finding import Severity


def make_repo(tmp_path: Path, files: dict[str, str]) -> Path:
    for rel, content in files.items():
        p = tmp_path / rel
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(content, encoding="utf-8")
    return tmp_path


_DEFAULT_CFG = {}


class TestE1ValidationToolExists:
    def test_no_tools_dir_triggers_e1_for_agent_repo(self, tmp_path):
        make_repo(tmp_path, {"lens/SKILL.md": "---\nname: lens\n---"})
        profile = detect_profile(tmp_path)
        findings = run(tmp_path, profile, _DEFAULT_CFG)
        assert any(f.rule_id == "E1" for f in findings)

    def test_validate_tool_exists_no_e1(self, tmp_path):
        make_repo(tmp_path, {
            "lens/SKILL.md": "---\nname: lens\n---",
            "tools/validate_output.py": "import sys\nif True:\n    sys.exit(0)\nelse:\n    sys.exit(1)\n",
        })
        profile = detect_profile(tmp_path)
        findings = run(tmp_path, profile, _DEFAULT_CFG)
        assert not any(f.rule_id == "E1" for f in findings)


class TestE3ApprovalGate:
    def test_no_approval_in_instructions_triggers_e3(self, tmp_path):
        make_repo(tmp_path, {
            "lens/SKILL.md": "---\nname: lens\n---",
            ".github/copilot-instructions.md": "1. Never auto-commit.\n2. Always check types.",
        })
        profile = detect_profile(tmp_path)
        findings = run(tmp_path, profile, _DEFAULT_CFG)
        assert any(f.rule_id == "E3" for f in findings)

    def test_approval_in_instructions_no_e3(self, tmp_path):
        make_repo(tmp_path, {
            "lens/SKILL.md": "---\nname: lens\n---",
            ".github/copilot-instructions.md": "1. Require approval before writing files.\n2. Confirm with user before any change.",
        })
        profile = detect_profile(tmp_path)
        findings = run(tmp_path, profile, _DEFAULT_CFG)
        assert not any(f.rule_id == "E3" for f in findings)


class TestE4DestructiveGuards:
    def test_unguarded_rm_rf_triggers_e4(self, tmp_path):
        make_repo(tmp_path, {
            "lens/SKILL.md": "---\nname: lens\n---",
            "tools/cleanup.py": "import os\nos.system('rm -rf /tmp/out')\n",
        })
        profile = detect_profile(tmp_path)
        findings = run(tmp_path, profile, _DEFAULT_CFG)
        assert any(f.rule_id == "E4" for f in findings)

    def test_guarded_destructive_no_e4(self, tmp_path):
        make_repo(tmp_path, {
            "lens/SKILL.md": "---\nname: lens\n---",
            "tools/cleanup.py": (
                "import subprocess\n"
                "# require approval before running\n"
                "if input('Confirm? ') == 'yes':\n"
                "    subprocess.run(['rm', '-rf', '/tmp/out'])\n"
            ),
        })
        profile = detect_profile(tmp_path)
        findings = run(tmp_path, profile, _DEFAULT_CFG)
        assert not any(f.rule_id == "E4" for f in findings)


class TestE7ValidationToolReferenced:
    def test_tool_not_in_instructions_triggers_e7(self, tmp_path):
        make_repo(tmp_path, {
            "lens/SKILL.md": "---\nname: lens\n---",
            "tools/validate_output.py": "import sys\nsys.exit(0)\n",
            ".github/copilot-instructions.md": "1. Never auto-commit.\n",
        })
        profile = detect_profile(tmp_path)
        findings = run(tmp_path, profile, _DEFAULT_CFG)
        assert any(f.rule_id == "E7" for f in findings)

    def test_tool_in_instructions_no_e7(self, tmp_path):
        make_repo(tmp_path, {
            "lens/SKILL.md": "---\nname: lens\n---",
            "tools/validate_output.py": "import sys\nsys.exit(0)\n",
            ".github/copilot-instructions.md": "1. Run validate_output.py before committing.\n",
        })
        profile = detect_profile(tmp_path)
        findings = run(tmp_path, profile, _DEFAULT_CFG)
        assert not any(f.rule_id == "E7" for f in findings)
