"""
Tests for tools/checks/failure_history.py — @ratchet checks (R1-R7).
"""
import sys
from pathlib import Path

import pytest

_REPO_ROOT = Path(__file__).resolve().parent.parent.parent
sys.path.insert(0, str(_REPO_ROOT))

from tools.orientation import detect_profile
from tools.checks.failure_history import run, _classify_rules, _count_failure_entries
from tools.finding import Severity


def make_repo(tmp_path: Path, files: dict[str, str]) -> Path:
    for rel, content in files.items():
        p = tmp_path / rel
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(content, encoding="utf-8")
    return tmp_path


_DEFAULT_CFG = {
    "ratchet": {
        "rules_without_evidence_warn": 3,
        "min_failure_log_entries": 1,
        "prohibitive_keywords": ["never", "do not", "must not", "block", "always", "forbidden"],
        "convention_keywords": ["prefer", "use", "default to", "follow", "choose"],
    }
}


class TestR1FailureLogExists:
    def test_no_log_produces_r1_finding(self, tmp_path):
        make_repo(tmp_path, {"lens/SKILL.md": "---\nname: lens\n---"})
        profile = detect_profile(tmp_path)
        findings = run(tmp_path, profile, _DEFAULT_CFG)
        assert any(f.rule_id == "R1" for f in findings)

    def test_log_exists_no_r1(self, tmp_path):
        make_repo(tmp_path, {
            "lens/SKILL.md": "---\nname: lens\n---",
            "docs/known-failures.md": "| Date | Session | Symptom | Rule |\n|---|---|---|---|\n| 2024-01-01 | s1 | bug | never X |"
        })
        profile = detect_profile(tmp_path)
        findings = run(tmp_path, profile, _DEFAULT_CFG)
        assert not any(f.rule_id == "R1" for f in findings)


class TestR2RuleTraceability:
    def test_untraced_prohibitive_rules_trigger_r2(self, tmp_path):
        instructions = "\n".join([
            "1. Never do X.",
            "2. Do not do Y.",
            "3. Must not do Z.",
            "4. Never do W.",
        ])
        make_repo(tmp_path, {
            "lens/SKILL.md": "---\nname: lens\n---",
            ".github/copilot-instructions.md": instructions,
            "docs/known-failures.md": "| Date | Session | Symptom | Rule |\n|---|---|---|---|",
        })
        profile = detect_profile(tmp_path)
        findings = run(tmp_path, profile, _DEFAULT_CFG)
        assert any(f.rule_id == "R2" for f in findings)

    def test_traced_rules_no_r2(self, tmp_path):
        instructions = "\n".join([
            "1. Never do X. (→ 2024-01-01, session-1)",
            "2. Do not do Y. (→ WW21, HSD-12345)",
            "3. Must not do Z. (→ 2024-02-15, session-3)",
        ])
        make_repo(tmp_path, {
            "lens/SKILL.md": "---\nname: lens\n---",
            ".github/copilot-instructions.md": instructions,
            "docs/known-failures.md": "| Date | Session | Symptom | Rule |\n|---|---|---|---|\n| 2024-01-01 | s1 | bug | never X |",
        })
        profile = detect_profile(tmp_path)
        findings = run(tmp_path, profile, _DEFAULT_CFG)
        assert not any(f.rule_id == "R2" for f in findings)


class TestClassifyRules:
    def test_prohibitive_keywords_detected(self):
        instructions = "1. Never do X.\n2. Do not commit.\n3. Must not delete.\n"
        prohibitive_kws = ["never", "do not", "must not"]
        convention_kws = ["prefer", "use"]
        prohibitive, convention = _classify_rules(instructions, prohibitive_kws, convention_kws)
        assert len(prohibitive) == 3
        assert len(convention) == 0

    def test_convention_keywords_detected(self):
        instructions = "1. Prefer small commits.\n2. Use pytest.\n3. Follow style guide.\n"
        prohibitive_kws = ["never", "do not"]
        convention_kws = ["prefer", "use", "follow"]
        prohibitive, convention = _classify_rules(instructions, prohibitive_kws, convention_kws)
        assert len(prohibitive) == 0
        assert len(convention) == 3

    def test_empty_instructions_returns_empty(self):
        prohibitive, convention = _classify_rules("", ["never"], ["prefer"])
        assert prohibitive == []
        assert convention == []


class TestCountFailureEntries:
    def test_table_rows_counted(self):
        text = "| Date | Session | Symptom |\n|---|---|---|\n| 2024 | s1 | bug |\n| 2024 | s2 | crash |"
        assert _count_failure_entries(text) == 2

    def test_empty_table_returns_zero(self):
        text = "| Date | Session | Symptom |\n|---|---|---|"
        assert _count_failure_entries(text) == 0

    def test_list_items_counted(self):
        text = "- 2024-01-01: Bug found\n- 2024-02-01: Another bug\n"
        assert _count_failure_entries(text) == 2

    def test_empty_string_returns_zero(self):
        assert _count_failure_entries("") == 0


class TestR4EmptyLog:
    def test_empty_log_triggers_r4(self, tmp_path):
        make_repo(tmp_path, {
            "lens/SKILL.md": "---\nname: lens\n---",
            "docs/known-failures.md": "| Date | Session | Symptom |\n|---|---|---|",
        })
        profile = detect_profile(tmp_path)
        findings = run(tmp_path, profile, _DEFAULT_CFG)
        assert any(f.rule_id == "R4" for f in findings)
