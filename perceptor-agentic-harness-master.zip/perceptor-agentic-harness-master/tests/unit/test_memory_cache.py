"""
Tests for tools/checks/memory_cache.py — @engram checks (M1-M6).
"""
import sys
from pathlib import Path

import pytest

_REPO_ROOT = Path(__file__).resolve().parent.parent.parent
sys.path.insert(0, str(_REPO_ROOT))

from tools.orientation import detect_profile
from tools.checks.memory_cache import run, _cache_has_entries
from tools.finding import Severity


def make_repo(tmp_path: Path, files: dict[str, str]) -> Path:
    for rel, content in files.items():
        p = tmp_path / rel
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(content, encoding="utf-8")
    return tmp_path


_DEFAULT_CFG = {}


class TestM1CacheExists:
    def test_no_cache_triggers_m1_for_agent_repo(self, tmp_path):
        make_repo(tmp_path, {"lens/SKILL.md": "---\nname: lens\n---"})
        profile = detect_profile(tmp_path)
        findings = run(tmp_path, profile, _DEFAULT_CFG)
        assert any(f.rule_id == "M1" for f in findings)

    def test_cache_exists_no_m1(self, tmp_path):
        make_repo(tmp_path, {
            "lens/SKILL.md": "---\nname: lens\n---",
            "config/verified_transforms.md": (
                "# Verified\n"
                "| Platform | Param | Action | Confirmed |\n"
                "|----------|-------|--------|----------|\n"
                "| GNR | shared_target | remove | WW21 |\n"
            ),
        })
        profile = detect_profile(tmp_path)
        findings = run(tmp_path, profile, _DEFAULT_CFG)
        assert not any(f.rule_id == "M1" for f in findings)


class TestM1EmptyCacheAdvisory:
    def test_empty_cache_triggers_advisory(self, tmp_path):
        make_repo(tmp_path, {
            "lens/SKILL.md": "---\nname: lens\n---",
            "config/verified_transforms.md": "# Verified\n| Platform | Param | Action |\n|---|---|---|",
        })
        profile = detect_profile(tmp_path)
        findings = run(tmp_path, profile, _DEFAULT_CFG)
        # M1 advisory for empty cache
        m1_findings = [f for f in findings if f.rule_id == "M1"]
        assert m1_findings  # Should have an M1 advisory


class TestM2MemoryPersistence:
    def test_no_memory_dir_triggers_m2(self, tmp_path):
        make_repo(tmp_path, {"lens/SKILL.md": "---\nname: lens\n---"})
        profile = detect_profile(tmp_path)
        findings = run(tmp_path, profile, _DEFAULT_CFG)
        assert any(f.rule_id == "M2" for f in findings)

    def test_memory_dir_no_m2(self, tmp_path):
        (tmp_path / "memories" / "repo").mkdir(parents=True)
        (tmp_path / "memories" / "repo" / "notes.md").write_text("# Notes\n- Platform: GNR\n")
        make_repo(tmp_path, {"lens/SKILL.md": "---\nname: lens\n---"})
        profile = detect_profile(tmp_path)
        findings = run(tmp_path, profile, _DEFAULT_CFG)
        assert not any(f.rule_id == "M2" for f in findings)


class TestM4CacheCheckInInstructions:
    def test_cache_exists_no_instruction_triggers_m4(self, tmp_path):
        make_repo(tmp_path, {
            "lens/SKILL.md": "---\nname: lens\n---",
            "config/verified_transforms.md": (
                "| Platform | Param | Action | Confirmed |\n"
                "|----------|-------|--------|----------|\n"
                "| GNR | shared_target | remove | WW21 |\n"
            ),
            ".github/copilot-instructions.md": "1. Never auto-commit.\n",
        })
        profile = detect_profile(tmp_path)
        findings = run(tmp_path, profile, _DEFAULT_CFG)
        assert any(f.rule_id == "M4" for f in findings)

    def test_cache_with_instruction_no_m4(self, tmp_path):
        make_repo(tmp_path, {
            "lens/SKILL.md": "---\nname: lens\n---",
            "config/verified_transforms.md": (
                "| Platform | Param | Action | Confirmed |\n"
                "|----------|-------|--------|----------|\n"
                "| GNR | shared_target | remove | WW21 |\n"
            ),
            ".github/copilot-instructions.md": "1. Check cache before querying any MCP tool.\n",
        })
        profile = detect_profile(tmp_path)
        findings = run(tmp_path, profile, _DEFAULT_CFG)
        assert not any(f.rule_id == "M4" for f in findings)


class TestCacheHasEntries:
    def test_table_with_entries_returns_true(self):
        text = "| Platform | Param |\n|---|---|\n| GNR | shared_target |\n"
        assert _cache_has_entries(Path("/fake")) is False  # can't read fake path

    def test_helper_with_real_content(self, tmp_path):
        cache = tmp_path / "verified.md"
        cache.write_text("| P | Q |\n|---|---|\n| GNR | X |\n")
        assert _cache_has_entries(cache) is True

    def test_helper_empty_table_returns_false(self, tmp_path):
        cache = tmp_path / "verified.md"
        cache.write_text("| P | Q |\n|---|---|")
        assert _cache_has_entries(cache) is False
