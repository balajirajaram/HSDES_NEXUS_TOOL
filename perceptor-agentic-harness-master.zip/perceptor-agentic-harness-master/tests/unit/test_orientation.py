"""
Tests for tools/orientation.py — RepoProfile detection.
"""
import sys
from pathlib import Path

import pytest

_REPO_ROOT = Path(__file__).resolve().parent.parent.parent
sys.path.insert(0, str(_REPO_ROOT))

from tools.orientation import detect_profile, RepoProfile


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def make_repo(tmp_path: Path, files: dict[str, str]) -> Path:
    """Create a minimal fake repo with the given files."""
    for rel, content in files.items():
        p = tmp_path / rel
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(content, encoding="utf-8")
    return tmp_path


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

class TestAgentRepoDetection:
    def test_skill_md_triggers_agent_repo(self, tmp_path):
        make_repo(tmp_path, {"lens/SKILL.md": "---\nname: lens\n---"})
        profile = detect_profile(tmp_path)
        assert profile.repo_type == "agent-repo"

    def test_agent_md_triggers_agent_repo(self, tmp_path):
        make_repo(tmp_path, {"agents/perceptor.agent.md": "---\nname: perceptor\n---"})
        profile = detect_profile(tmp_path)
        assert profile.repo_type == "agent-repo"

    def test_manifest_with_skills_triggers_agent_repo(self, tmp_path):
        make_repo(tmp_path, {"manifest.yaml": "package:\n  name: test\nskills:\n  - name: foo\n    path: foo/SKILL.md"})
        profile = detect_profile(tmp_path)
        assert profile.repo_type == "agent-repo"


class TestSkillCounting:
    def test_counts_skill_files(self, tmp_path):
        make_repo(tmp_path, {
            "lens/SKILL.md": "---\nname: lens\n---",
            "ratchet/SKILL.md": "---\nname: ratchet\n---",
            "probe/SKILL.md": "---\nname: probe\n---",
        })
        profile = detect_profile(tmp_path)
        assert profile.skill_count == 3

    def test_zero_skills_for_empty_repo(self, tmp_path):
        profile = detect_profile(tmp_path)
        assert profile.skill_count == 0


class TestInstructionsDetection:
    def test_detects_copilot_instructions(self, tmp_path):
        make_repo(tmp_path, {".github/copilot-instructions.md": "# Rules\n1. Never auto-commit."})
        profile = detect_profile(tmp_path)
        assert profile.has_instructions is True

    def test_detects_agents_md(self, tmp_path):
        make_repo(tmp_path, {"AGENTS.md": "# Rules\n1. Always confirm."})
        profile = detect_profile(tmp_path)
        assert profile.has_instructions is True

    def test_no_instructions_when_missing(self, tmp_path):
        profile = detect_profile(tmp_path)
        assert profile.has_instructions is False


class TestStructuralFacts:
    def test_detects_manifest(self, tmp_path):
        make_repo(tmp_path, {"manifest.yaml": "package:\n  name: test"})
        profile = detect_profile(tmp_path)
        assert profile.has_manifest is True

    def test_detects_tests_directory(self, tmp_path):
        (tmp_path / "tests" / "unit").mkdir(parents=True)
        profile = detect_profile(tmp_path)
        assert profile.has_tests is True

    def test_detects_known_failures(self, tmp_path):
        make_repo(tmp_path, {"docs/known-failures.md": "# Known Failures\n| Date |"})
        profile = detect_profile(tmp_path)
        assert profile.has_known_failures is True


class TestDomainDetection:
    def test_detects_hardware_validation_domain(self, tmp_path):
        make_repo(tmp_path, {
            ".github/copilot-instructions.md": "# Hardware validation agent for silicon testing."
        })
        profile = detect_profile(tmp_path)
        assert "hardware validation" in profile.domain

    def test_user_hint_overrides_detection(self, tmp_path):
        profile = detect_profile(tmp_path, context_hint="testline porting agent")
        assert profile.user_hint == "testline porting agent"
        assert "testline" in profile.domain


class TestContextPhrase:
    def test_context_phrase_uses_user_hint(self, tmp_path):
        profile = detect_profile(tmp_path, context_hint="my custom domain")
        assert profile.context_phrase() == "my custom domain"

    def test_context_phrase_uses_domain_when_no_hint(self, tmp_path):
        make_repo(tmp_path, {
            ".github/copilot-instructions.md": "# Hardware validation silicon testing"
        })
        profile = detect_profile(tmp_path)
        phrase = profile.context_phrase()
        assert len(phrase) > 0  # Should produce some non-empty phrase

    def test_is_agent_repo_returns_true_for_agent(self, tmp_path):
        make_repo(tmp_path, {"lens/SKILL.md": "---\nname: lens\n---"})
        profile = detect_profile(tmp_path)
        assert profile.is_agent_repo() is True

    def test_is_agent_repo_returns_false_for_unknown(self, tmp_path):
        profile = detect_profile(tmp_path)
        assert profile.is_agent_repo() is False
