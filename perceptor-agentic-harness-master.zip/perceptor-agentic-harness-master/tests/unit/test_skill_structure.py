"""
Tests for tools/checks/skill_structure.py — @spectrum checks (S1-S8).
"""
import sys
from pathlib import Path

import pytest

_REPO_ROOT = Path(__file__).resolve().parent.parent.parent
sys.path.insert(0, str(_REPO_ROOT))

from tools.orientation import detect_profile
from tools.checks.skill_structure import run, _prose_ratio, _parse_yaml_frontmatter
from tools.finding import Severity


def make_repo(tmp_path: Path, files: dict[str, str]) -> Path:
    for rel, content in files.items():
        p = tmp_path / rel
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(content, encoding="utf-8")
    return tmp_path


_DEFAULT_CFG = {
    "spectrum": {
        "skill_max_lines": 200,
        "min_skills_for_manifest": 3,
        "description_min_words": 10,
    }
}


class TestS1MonolithicSkill:
    def test_large_skill_triggers_s1(self, tmp_path):
        content = "\n".join([f"{i}. Step {i}." for i in range(250)])
        make_repo(tmp_path, {"lens/SKILL.md": content})
        profile = detect_profile(tmp_path)
        findings = run(tmp_path, profile, _DEFAULT_CFG)
        assert any(f.rule_id == "S1" for f in findings)

    def test_small_skill_no_s1(self, tmp_path):
        content = "---\nname: lens\ndescription: Use when checking context.\n---\n# Steps\n1. Check file."
        make_repo(tmp_path, {"lens/SKILL.md": content})
        profile = detect_profile(tmp_path)
        findings = run(tmp_path, profile, _DEFAULT_CFG)
        assert not any(f.rule_id == "S1" for f in findings)


class TestS2Manifest:
    def test_three_skills_no_manifest_triggers_s2(self, tmp_path):
        for name in ["lens", "ratchet", "probe"]:
            make_repo(tmp_path, {f"{name}/SKILL.md": f"---\nname: {name}\ndescription: Use when.\n---"})
        profile = detect_profile(tmp_path)
        findings = run(tmp_path, profile, _DEFAULT_CFG)
        assert any(f.rule_id == "S2" for f in findings)

    def test_three_skills_with_manifest_no_s2(self, tmp_path):
        for name in ["lens", "ratchet", "probe"]:
            make_repo(tmp_path, {f"{name}/SKILL.md": f"---\nname: {name}\ndescription: Use when.\n---"})
        make_repo(tmp_path, {"manifest.yaml": "package:\n  name: test\nskills:\n  - name: lens"})
        profile = detect_profile(tmp_path)
        findings = run(tmp_path, profile, _DEFAULT_CFG)
        assert not any(f.rule_id == "S2" for f in findings)


class TestS3YamlFrontmatter:
    def test_missing_name_triggers_s3(self, tmp_path):
        content = "---\ndescription: Use when checking context.\n---\n# Content"
        make_repo(tmp_path, {"lens/SKILL.md": content})
        profile = detect_profile(tmp_path)
        findings = run(tmp_path, profile, _DEFAULT_CFG)
        assert any(f.rule_id == "S3" for f in findings)

    def test_missing_description_triggers_s3(self, tmp_path):
        content = "---\nname: lens\n---\n# Content"
        make_repo(tmp_path, {"lens/SKILL.md": content})
        profile = detect_profile(tmp_path)
        findings = run(tmp_path, profile, _DEFAULT_CFG)
        assert any(f.rule_id == "S3" for f in findings)

    def test_both_fields_no_s3(self, tmp_path):
        content = "---\nname: lens\ndescription: Use when checking context injection quality.\n---\n# Content"
        make_repo(tmp_path, {"lens/SKILL.md": content})
        profile = detect_profile(tmp_path)
        findings = run(tmp_path, profile, _DEFAULT_CFG)
        assert not any(f.rule_id == "S3" for f in findings)


class TestParseYamlFrontmatter:
    def test_parses_name_and_description(self):
        content = "---\nname: lens\ndescription: Use when checking context.\n---\n# Content"
        fm = _parse_yaml_frontmatter(content)
        assert fm["name"] == "lens"
        assert "checking context" in fm["description"]

    def test_no_frontmatter_returns_empty(self):
        content = "# Just a heading\nSome content."
        fm = _parse_yaml_frontmatter(content)
        assert fm == {}


class TestProseRatio:
    def test_all_prose_returns_high_ratio(self):
        text = "This is prose.\nAnd more prose.\nYet another prose line."
        ratio = _prose_ratio(text)
        assert ratio > 0.5

    def test_all_lists_returns_low_ratio(self):
        text = "- Step 1\n- Step 2\n- Step 3\n- Step 4"
        ratio = _prose_ratio(text)
        assert ratio < 0.5
