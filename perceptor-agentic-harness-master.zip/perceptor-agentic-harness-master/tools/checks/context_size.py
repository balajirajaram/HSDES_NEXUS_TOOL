"""
@lens — Context injection checks (L1–L10).

Analyzes the size and quality of always-injected context:
copilot-instructions.md, AGENTS.md, and any auto-loaded skill/instruction files.
"""
from __future__ import annotations

import re
from pathlib import Path
from typing import List

from tools.orientation import RepoProfile
from tools.finding import Finding, Severity


_INSTRUCTION_CANDIDATES = [
    ".github/copilot-instructions.md",
    "copilot-instructions.md",
    ".github/AGENTS.md",
    "AGENTS.md",
    "CLAUDE.md",
    ".github/CLAUDE.md",
]

_CODE_BLOCK_RE = re.compile(r"```[\s\S]*?```", re.MULTILINE)
_TABLE_ROW_RE = re.compile(r"^\|.+\|", re.MULTILINE)
_HEADING_RE = re.compile(r"^#{1,4}\s+", re.MULTILINE)

# Layout / non-behavioral block patterns
_LAYOUT_PATTERNS = re.compile(
    r"(Project\s+Layout|Directory\s+Structure|File\s+Structure|Folder\s+Layout"
    r"|Quick\s+Start|Getting\s+Started|Installation|Setup\s+Steps)",
    re.IGNORECASE,
)

# Commit/identity info patterns (should be in git config, not prompt)
_IDENTITY_PATTERNS = re.compile(
    r"git\s+config|user\.name\s*=|user\.email\s*=|github\s+ID\s+[`'\"]",
    re.IGNORECASE,
)

# Behavioral rule signals
_BEHAVIORAL_RE = re.compile(
    r"^[\s*-]*(?:never|always|do not|must not|require|block|consider|prefer|use |default to)",
    re.IGNORECASE | re.MULTILINE,
)


def _estimate_tokens(text: str) -> int:
    return max(1, len(text) // 4)


def _find_instructions_file(repo_root: Path) -> tuple[Path | None, str]:
    for candidate in _INSTRUCTION_CANDIDATES:
        p = repo_root / candidate
        if p.exists():
            try:
                return p, p.read_text(encoding="utf-8", errors="ignore")
            except OSError:
                pass
    return None, ""


def _count_mcp_tools(repo_root: Path) -> int:
    """Count total distinct MCP tool declarations across all config files."""
    total = 0
    for pattern in ("*.json", "*.yaml", "*.yml"):
        for f in repo_root.rglob(pattern):
            if any(skip in str(f) for skip in (".git", "node_modules", "__pycache__")):
                continue
            try:
                text = f.read_text(encoding="utf-8", errors="ignore")
                # Count "name:" entries inside mcp / tools sections
                if "mcpServers" in text or "mcp_" in text:
                    total += len(re.findall(r'"name"\s*:', text))
            except OSError:
                pass
    return total


def run(repo_root: Path, profile: RepoProfile, cfg: dict) -> List[Finding]:
    findings: List[Finding] = []
    repo_root = Path(repo_root)
    lens_cfg = cfg.get("lens", {})

    max_lines = lens_cfg.get("instructions_max_lines", 60)
    max_tokens = lens_cfg.get("instructions_max_tokens", 300)
    max_total_tokens = lens_cfg.get("total_injected_max_tokens", 800)
    max_mcp_tools = lens_cfg.get("mcp_tool_count_warn", 20)
    code_warn = lens_cfg.get("code_example_lines_warn", 5)
    table_warn = lens_cfg.get("table_rows_warn", 5)

    instr_path, instr_text = _find_instructions_file(repo_root)
    line_count = len(instr_text.splitlines()) if instr_text else 0
    token_count = _estimate_tokens(instr_text)

    ctx = profile.context_phrase()

    # L1 — Instructions line count
    if not instr_path:
        findings.append(Finding(
            rule_id="L1",
            dimension="Lens",
            severity=Severity.WARNING,
            observation="No instructions file found (checked: copilot-instructions.md, AGENTS.md, CLAUDE.md).",
            context=f"For {ctx}, an instructions file is where always-injected behavioral rules live.",
            suggestion="Consider creating .github/copilot-instructions.md with your agent's core behavioral rules (aim for ≤60 lines).",
            skip_if="This repo doesn't use GitHub Copilot or has instructions in a non-standard location.",
        ))
    elif line_count > max_lines:
        findings.append(Finding(
            rule_id="L1",
            dimension="Lens",
            severity=Severity.WARNING,
            observation=f"Instructions file is {line_count} lines (threshold: {max_lines}).",
            context=f"For {ctx}, every line in the always-injected system prompt competes for attention. More lines mean each rule matters less.",
            suggestion=f"Consider slimming {instr_path.name} to ≤{max_lines} lines. Move project layout, quick-start examples, and glossaries to README.md. Keep only enforceable behavioral rules.",
            skip_if="The extra lines are all behavioral rules with no documentation or examples mixed in.",
        ))

    # L2 — Token count
    if instr_text and token_count > max_tokens:
        findings.append(Finding(
            rule_id="L2",
            dimension="Lens",
            severity=Severity.WARNING,
            observation=f"Instructions file is ~{token_count} tokens (threshold: {max_tokens}).",
            context=f"Token budget for always-injected context directly affects context rot and model attention quality.",
            suggestion=f"Consider reducing instructions to ≤{max_tokens} tokens. The current file is ~{token_count - max_tokens} tokens over.",
            skip_if="Your model has a very large context window and you've verified this doesn't degrade response quality.",
        ))

    # L3 — Non-behavioral content (layout blocks)
    if instr_text and _LAYOUT_PATTERNS.search(instr_text):
        findings.append(Finding(
            rule_id="L3",
            dimension="Lens",
            severity=Severity.FINDING,
            observation="Instructions file contains layout/setup sections (detected: 'Project Layout', 'Quick Start', or similar).",
            context="Project layout and setup instructions are reference material, not behavioral rules. They consume tokens every turn without guiding agent behavior.",
            suggestion="Consider moving layout/setup sections to README.md and replacing them with a single reference: 'See README.md for project layout.'",
            skip_if="The layout section is very short (< 5 lines) and helps orient the agent for this specific repo.",
        ))

    # L4 — Code examples in instructions
    if instr_text:
        code_blocks = _CODE_BLOCK_RE.findall(instr_text)
        large_blocks = [b for b in code_blocks if len(b.splitlines()) > code_warn]
        if large_blocks:
            findings.append(Finding(
                rule_id="L4",
                dimension="Lens",
                severity=Severity.FINDING,
                observation=f"Instructions file contains {len(large_blocks)} large code block(s) (>{code_warn} lines each).",
                context="Multi-line code examples in always-injected context consume significant tokens every turn. Skills are designed for on-demand context — load them only when needed.",
                suggestion="Consider moving code examples to a SKILL.md file that's loaded only when the relevant task is active.",
                skip_if="The code examples are essential behavioral references (e.g., exact API patterns the agent must follow on every call).",
            ))

    # L5 — Large tables in instructions
    if instr_text:
        table_rows = _TABLE_ROW_RE.findall(instr_text)
        if len(table_rows) > table_warn:
            findings.append(Finding(
                rule_id="L5",
                dimension="Lens",
                severity=Severity.ADVISORY,
                observation=f"Instructions file contains {len(table_rows)} table rows.",
                context="Large reference tables in always-injected context (MCP dependency tables, platform support matrices) are documentation, not behavioral rules.",
                suggestion="Consider moving reference tables to README.md or manifest.yaml and keeping only decision-critical rows in instructions.",
                skip_if="The table rows are all behavioral rules that genuinely apply on every turn.",
            ))

    # L6 — applyTo: "**" on non-universal instructions
    for instr_file in repo_root.rglob("*.instructions.md"):
        try:
            text = instr_file.read_text(encoding="utf-8", errors="ignore")
            if 'applyTo: "**"' in text or "applyTo: '**'" in text:
                findings.append(Finding(
                    rule_id="L6",
                    dimension="Lens",
                    severity=Severity.WARNING,
                    observation=f"{instr_file.relative_to(repo_root)} uses applyTo: \"**\" (applies to all files).",
                    context="A global applyTo pattern injects this instruction into every file interaction, even unrelated ones. This burns context on every turn.",
                    suggestion=f"Consider scoping {instr_file.name} with a specific glob (e.g., '**/*.py') unless it truly applies to every file type in the repo.",
                    skip_if="This instruction genuinely applies to all files in the repo (e.g., a security or licensing rule).",
                ))
        except OSError:
            pass

    # L7 — Behavioral rules ratio
    if instr_text and line_count > 5:
        behavioral_lines = len(_BEHAVIORAL_RE.findall(instr_text))
        total_content_lines = sum(
            1 for l in instr_text.splitlines()
            if l.strip() and not l.strip().startswith("#")
        )
        if total_content_lines > 0:
            ratio = behavioral_lines / total_content_lines
            if ratio < 0.4:
                findings.append(Finding(
                    rule_id="L7",
                    dimension="Lens",
                    severity=Severity.ADVISORY,
                    observation=f"Only ~{int(ratio*100)}% of non-heading lines appear to be behavioral rules.",
                    context="The instructions file is most effective when every line is an enforceable behavior. Documentation, examples, and reference material dilute this.",
                    suggestion="Consider auditing each line: if it doesn't tell the agent what to do or not do, it likely belongs elsewhere (README, skill file, manifest).",
                    skip_if="Your instructions intentionally include orientation context for a domain where the agent needs background knowledge.",
                ))

    # L8 — Total injected context
    total_tokens = token_count
    for skill_file in repo_root.rglob("SKILL.md"):
        try:
            skill_text = skill_file.read_text(encoding="utf-8", errors="ignore")
            # Only count skills that might be auto-loaded (no YAML frontmatter trigger)
            if "disable-model-invocation: true" not in skill_text:
                total_tokens += _estimate_tokens(skill_text) // 4  # partial injection estimate
        except OSError:
            pass
    if total_tokens > max_total_tokens:
        findings.append(Finding(
            rule_id="L8",
            dimension="Lens",
            severity=Severity.ADVISORY,
            observation=f"Estimated always-injected context is ~{total_tokens} tokens (threshold: {max_total_tokens}).",
            context="The total upfront context load affects model performance before the agent takes a single action. Skills should use progressive disclosure — loaded only when their task is active.",
            suggestion="Consider using skills with specific trigger descriptions so they're loaded on-demand rather than at session start.",
            skip_if="Your workflow is short and high-context, and you've tuned the instruction set to match.",
        ))

    # L9 — Identity/commit info in instructions
    if instr_text and _IDENTITY_PATTERNS.search(instr_text):
        findings.append(Finding(
            rule_id="L9",
            dimension="Lens",
            severity=Severity.FINDING,
            observation="Instructions file contains git identity or commit author configuration.",
            context="Git identity (user.name, user.email, GitHub ID) is runtime configuration, not a behavioral rule. It consumes prompt tokens every turn for something that should be set once in git config.",
            suggestion="Consider removing identity configuration from instructions and setting it via: git config user.name <name> && git config user.email <email>",
            skip_if="The identity instruction serves a different purpose (e.g., attributing generated content to a specific persona).",
        ))

    # L10 — MCP tool count
    mcp_count = _count_mcp_tools(repo_root)
    if mcp_count > max_mcp_tools:
        findings.append(Finding(
            rule_id="L10",
            dimension="Lens",
            severity=Severity.WARNING,
            observation=f"Detected ~{mcp_count} MCP tool declarations (threshold: {max_mcp_tools}).",
            context="Each MCP tool's name, description, and schema is injected into the prompt on every request. A large tool menu degrades the model's ability to select the right tool.",
            suggestion="Consider whether all MCP tools are actively used. Tools that are rarely needed could be moved to a separate MCP server loaded only for specific workflows.",
            skip_if="All detected tools are genuinely needed and the model is performing well with the current tool set.",
        ))

    return findings
