"""
@reflex — Enforcement, hooks, and approval gate checks (E1–E8).

Verifies that the harness has back-pressure mechanisms: validation tools,
approval gates for writes, destructive-action guards, and hooks.
"""
from __future__ import annotations

import re
from pathlib import Path
from typing import List

from tools.orientation import RepoProfile
from tools.finding import Finding, Severity


_DESTRUCTIVE_PATTERNS = re.compile(
    r"rm\s+-rf|git\s+push\s+--force|git\s+reset\s+--hard|DROP\s+TABLE"
    r"|truncate\s+table|os\.remove|shutil\.rmtree|git\s+clean\s+-fd",
    re.IGNORECASE,
)
_APPROVAL_PATTERNS = re.compile(
    r"approve|confirm|consent|gate|user\s+confirmation|require\s+approval"
    r"|before\s+apply|ask\s+user",
    re.IGNORECASE,
)
_EXIT_0_PATTERN = re.compile(r"\bsys\.exit\(0\)|\bexit\(0\)|return\s+0\b")
_EXIT_1_PATTERN = re.compile(r"\bsys\.exit\(1\)|\bexit\(1\)|return\s+1\b")
_VALIDATE_FILE_RE = re.compile(
    r"validate|check|lint|verify|inspect", re.IGNORECASE
)
_HOOK_CONTENT_RE = re.compile(
    r"post.?edit|pre.?commit|post.?commit|on.?save|file.?changed|watch",
    re.IGNORECASE,
)


def _find_validation_tools(repo_root: Path) -> list[Path]:
    """Find likely validation tool scripts."""
    candidates = []
    for pattern in ("tools/", "scripts/", ""):
        base = repo_root / pattern
        if base.is_dir():
            for f in base.glob("*.py"):
                if _VALIDATE_FILE_RE.search(f.name):
                    candidates.append(f)
            for f in base.glob("*.sh"):
                if _VALIDATE_FILE_RE.search(f.name):
                    candidates.append(f)
    return candidates


def _has_silent_success(tool_path: Path) -> bool:
    """Check if a validation tool exits 0 on success."""
    try:
        text = tool_path.read_text(encoding="utf-8", errors="ignore")
        return bool(_EXIT_0_PATTERN.search(text) and _EXIT_1_PATTERN.search(text))
    except OSError:
        return False


def _find_instructions_text(repo_root: Path) -> str:
    for candidate in (
        ".github/copilot-instructions.md",
        "copilot-instructions.md",
        ".github/AGENTS.md",
        "AGENTS.md",
    ):
        p = repo_root / candidate
        if p.exists():
            try:
                return p.read_text(encoding="utf-8", errors="ignore")
            except OSError:
                pass
    return ""


def _check_destructive_guards(repo_root: Path) -> list[str]:
    """Return list of files that contain destructive patterns without guards."""
    unguarded = []
    for f in repo_root.rglob("*.py"):
        if ".git" in str(f) or "__pycache__" in str(f) or f.name.startswith("test_"):
            continue
        try:
            text = f.read_text(encoding="utf-8", errors="ignore")
            if _DESTRUCTIVE_PATTERNS.search(text):
                # Check if same file has approval/confirmation logic
                if not _APPROVAL_PATTERNS.search(text):
                    unguarded.append(str(f.relative_to(repo_root)))
        except OSError:
            pass
    return unguarded


def run(repo_root: Path, profile: RepoProfile, cfg: dict) -> List[Finding]:
    findings: List[Finding] = []
    repo_root = Path(repo_root)
    ctx = profile.context_phrase()
    is_agent = profile.is_agent_repo()

    instructions = _find_instructions_text(repo_root)
    validation_tools = _find_validation_tools(repo_root)

    # E1 — Validation tool exists
    if not validation_tools and not profile.has_validation_tool:
        sev = Severity.FINDING if is_agent else Severity.ADVISORY
        findings.append(Finding(
            rule_id="E1",
            dimension="Reflex",
            severity=sev,
            observation="No validation/check script found in tools/ or scripts/.",
            context=f"For {ctx}, a back-pressure validation hook catches bad agent output before it propagates. The principle: success is silent (exit 0), failure is verbose (exit 1).",
            suggestion="Consider creating tools/validate_output.py that checks agent-produced artifacts and exits 0 on pass, 1 on fail with details.",
            skip_if="This repo's output validation is handled by an external CI system or test suite.",
        ))
    else:
        # E2 — Silent success pattern
        tools_with_silent_success = [t for t in validation_tools if _has_silent_success(t)]
        if validation_tools and not tools_with_silent_success:
            findings.append(Finding(
                rule_id="E2",
                dimension="Reflex",
                severity=Severity.ADVISORY,
                observation="Validation tool(s) found but may not implement the 'silent on success, verbose on failure' pattern.",
                context="A validation hook that always prints output is harder to integrate into CI. Exit 0 with no output on success; exit 1 with clear error details on failure.",
                suggestion="Consider checking that your validation tool calls sys.exit(0) on clean results and sys.exit(1) with a descriptive error message on violations.",
                skip_if="Your validation tool is designed to be interactive and always provides a summary.",
                evidence=", ".join(str(t.relative_to(repo_root)) for t in validation_tools),
            ))

    # E3 — Approval gate for writes
    if is_agent and not _APPROVAL_PATTERNS.search(instructions):
        findings.append(Finding(
            rule_id="E3",
            dimension="Reflex",
            severity=Severity.FINDING,
            observation="Instructions do not mention approval gates or user confirmation before writes.",
            context=f"For {ctx}, agents with write access (git commit, file modification, API calls) should require explicit confirmation before irreversible operations.",
            suggestion="Consider adding an approval rule: 'Before applying any change to [target], confirm the specific files and transformations with the user.'",
            skip_if="This agent is read-only and never writes files or makes API calls.",
        ))

    # E4 — Destructive action guards
    unguarded = _check_destructive_guards(repo_root)
    if unguarded:
        sev = Severity.FINDING if is_agent else Severity.WARNING
        findings.append(Finding(
            rule_id="E4",
            dimension="Reflex",
            severity=sev,
            observation=f"Destructive operations found without guards in {len(unguarded)} file(s): {', '.join(unguarded[:3])}{'...' if len(unguarded) > 3 else ''}",
            context="Operations like rm -rf, git push --force, and DROP TABLE are hard to reverse and should require explicit user confirmation or be gated by a dry-run flag.",
            suggestion="Consider adding a --dry-run flag or confirmation prompt before any destructive operations.",
            skip_if="These operations are gated upstream (e.g., only run in CI after approval workflows).",
            evidence=", ".join(unguarded[:5]),
        ))

    # E5 — Post-edit hook
    all_agent_files = list(repo_root.rglob("*.agent.md"))
    hooks_in_agents = False
    for agent_file in all_agent_files:
        try:
            if _HOOK_CONTENT_RE.search(agent_file.read_text(encoding="utf-8", errors="ignore")):
                hooks_in_agents = True
                break
        except OSError:
            pass

    hooks_dir = repo_root / ".github" / "hooks"
    if is_agent and not hooks_in_agents and not hooks_dir.is_dir() and not profile.has_hooks:
        findings.append(Finding(
            rule_id="E5",
            dimension="Reflex",
            severity=Severity.ADVISORY,
            observation="No post-edit hooks found in .agent.md files or .github/hooks/.",
            context="Post-edit hooks can trigger validation automatically after each agent-generated file write, reducing the chance of bad output going undetected.",
            suggestion="Consider adding a hooks section to your .agent.md: 'hooks: [{ on: file-edit, run: python tools/validate_output.py }]'",
            skip_if="Your workflow has a manual review step after every agent action.",
        ))

    # E6 — .github/hooks directory
    if is_agent and not hooks_dir.is_dir():
        findings.append(Finding(
            rule_id="E6",
            dimension="Reflex",
            severity=Severity.ADVISORY,
            observation="No .github/hooks/ directory found.",
            context="A dedicated hooks directory makes it easy to add and version-control automation triggers (pre-commit checks, post-edit validation).",
            suggestion="Consider creating .github/hooks/ and adding a post-edit validation script there.",
            skip_if="You use a different hooks mechanism (e.g., husky, lefthook, or CI-only checks).",
        ))

    # E7 — Instructions reference validation tool
    if validation_tools and instructions:
        tool_names = [t.name for t in validation_tools]
        referenced = any(name in instructions for name in tool_names)
        if not referenced:
            findings.append(Finding(
                rule_id="E7",
                dimension="Reflex",
                severity=Severity.ADVISORY,
                observation=f"Validation tool(s) found ({', '.join(tool_names[:2])}) but not referenced in instructions.",
                context="If the validation tool isn't mentioned in the instructions, agents may not know to run it. The hook is only effective if the agent uses it.",
                suggestion="Consider adding a rule to instructions: 'Run python tools/validate_output.py before any commit or delivery.'",
                skip_if="The validation tool is run automatically by CI, not by the agent.",
                evidence=", ".join(str(t.relative_to(repo_root)) for t in validation_tools),
            ))

    # E8 — Back-pressure documented
    back_pressure_re = re.compile(
        r"back.?pressure|validate.*before|check.*before|exit\s*1|fail.*loudly",
        re.IGNORECASE,
    )
    if is_agent and instructions and not back_pressure_re.search(instructions):
        findings.append(Finding(
            rule_id="E8",
            dimension="Reflex",
            severity=Severity.ADVISORY,
            observation="Instructions don't reference back-pressure validation patterns.",
            context="'Success is silent, failure is verbose' should be documented as a principle so agents understand why validation tools exist and when to run them.",
            suggestion="Consider documenting the validation signal: 'Validation: exit 0 = ready to proceed. exit 1 = stop and read the output.'",
            skip_if="Your validation approach is documented in README.md or a dedicated VALIDATION.md.",
        ))

    return findings
