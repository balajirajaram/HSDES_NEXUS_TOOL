"""
@ratchet — Failure history & rule traceability checks (R1–R7).

Verifies that behavioral rules in the instructions file are traceable to
real failure events (the "ratchet" principle), and that a failure log exists.
"""
from __future__ import annotations

import re
from pathlib import Path
from typing import List

from tools.orientation import RepoProfile
from tools.finding import Finding, Severity


_FAILURE_LOG_PATTERNS = [
    "docs/known-failures.md",
    "docs/KNOWN_FAILURES.md",
    "known-failures.md",
    "FAILURES.md",
    "failures.md",
    "docs/ratchet.md",
    "ratchet.md",
    "docs/failure-log.md",
]

# Templates for traceability references in rule text
_TRACE_PATTERNS = re.compile(
    r"(\d{4}-\d{2}-\d{2}"          # date YYYY-MM-DD
    r"|\bWW\d{2}\b"                 # Intel work week WW21
    r"|\bHSD[-_]?\d{5,}"            # HSD ticket
    r"|\b[Ss]ession[-_]?\d+"        # session ID
    r"|\bSS-\d+"                    # sighting ID
    r"|\bgit\s+[0-9a-f]{7,}"        # git hash
    r"|\bGH[-_]?\d+"                # GitHub issue
    r")",
    re.IGNORECASE,
)

# Remove-when conditions
_REMOVE_WHEN_RE = re.compile(r"remove\s+when|retire\s+when|expires?\s+when", re.IGNORECASE)


def _load_config_keywords(cfg: dict) -> tuple[list[str], list[str]]:
    ratchet_cfg = cfg.get("ratchet", {})
    prohibitive = ratchet_cfg.get("prohibitive_keywords", [
        "never", "do not", "must not", "block", "require approval",
        "always", "forbidden", "disallow",
    ])
    convention = ratchet_cfg.get("convention_keywords", [
        "prefer", "use", "default to", "follow", "choose", "recommend",
    ])
    return [k.lower() for k in prohibitive], [k.lower() for k in convention]


def _find_failure_log(repo_root: Path) -> tuple[Path | None, str]:
    for pattern in _FAILURE_LOG_PATTERNS:
        p = repo_root / pattern
        if p.exists():
            try:
                return p, p.read_text(encoding="utf-8", errors="ignore")
            except OSError:
                pass
    # Also check any *.md in docs/ matching ratchet/failure patterns
    docs_dir = repo_root / "docs"
    if docs_dir.is_dir():
        re_pattern = re.compile(r"(fail|ratchet|known)", re.IGNORECASE)
        for f in docs_dir.glob("*.md"):
            if re_pattern.search(f.name):
                try:
                    return f, f.read_text(encoding="utf-8", errors="ignore")
                except OSError:
                    pass
    return None, ""


def _find_instructions_text(repo_root: Path) -> str:
    for candidate in (
        ".github/copilot-instructions.md",
        "copilot-instructions.md",
        ".github/AGENTS.md",
        "AGENTS.md",
        "CLAUDE.md",
    ):
        p = repo_root / candidate
        if p.exists():
            try:
                return p.read_text(encoding="utf-8", errors="ignore")
            except OSError:
                pass
    return ""


def _classify_rules(
    instructions: str,
    prohibitive_kws: list[str],
    convention_kws: list[str],
) -> tuple[list[str], list[str]]:
    """
    Returns (prohibitive_rules, convention_rules) — each a list of line texts.
    A line is prohibitive if it starts/contains a prohibitive keyword.
    A line is convention if it contains a convention keyword but no prohibitive keyword.
    """
    prohibitive: list[str] = []
    convention: list[str] = []
    for line in instructions.splitlines():
        stripped = line.strip().lstrip("0123456789. -*").lower()
        is_prohibitive = any(stripped.startswith(k) or f" {k} " in stripped for k in prohibitive_kws)
        is_convention = any(stripped.startswith(k) or f" {k} " in stripped for k in convention_kws)
        if is_prohibitive:
            prohibitive.append(line)
        elif is_convention:
            convention.append(line)
    return prohibitive, convention


def _count_failure_entries(log_text: str) -> int:
    """Count table rows or list items in the failure log that look like real entries."""
    if not log_text:
        return 0
    # Count pipe-delimited table rows (skip header/separator)
    table_rows = [
        l for l in log_text.splitlines()
        if re.match(r"^\|\s*\S", l) and "---" not in l and not l.strip().endswith("|-")
    ]
    # Count list item rows
    list_rows = [
        l for l in log_text.splitlines()
        if re.match(r"^[\s]*[-*]\s+\S", l)
    ]
    return max(len(table_rows) - 1, 0) + len(list_rows)  # subtract header row


def run(repo_root: Path, profile: RepoProfile, cfg: dict) -> List[Finding]:
    findings: List[Finding] = []
    repo_root = Path(repo_root)
    ratchet_cfg = cfg.get("ratchet", {})
    untraced_warn = ratchet_cfg.get("rules_without_evidence_warn", 3)
    min_entries = ratchet_cfg.get("min_failure_log_entries", 1)
    is_agent = profile.is_agent_repo()
    ctx = profile.context_phrase()

    prohibitive_kws, convention_kws = _load_config_keywords(cfg)

    instructions = _find_instructions_text(repo_root)
    log_path, log_text = _find_failure_log(repo_root)

    # R1 — Known-failures log exists
    if not log_path:
        sev = Severity.FINDING if is_agent else Severity.ADVISORY
        findings.append(Finding(
            rule_id="R1",
            dimension="Ratchet",
            severity=sev,
            observation="No known-failures log found (checked: docs/known-failures.md, FAILURES.md, docs/ratchet.md, and similar).",
            context=f"For {ctx}, the ratchet principle says every behavioral rule should trace to a real failure. Without a log, rules accumulate without evidence and become stale over time.",
            suggestion="Consider creating docs/known-failures.md with a table: | Date | Session | Symptom | Rule Added |. Seed it with one entry per existing behavioral rule.",
            skip_if="This is not an agent repo and your team tracks failures in a separate system (e.g., JIRA, HSD).",
        ))
    else:
        # R4 — Failure log has entries
        entry_count = _count_failure_entries(log_text)
        if entry_count < min_entries:
            findings.append(Finding(
                rule_id="R4",
                dimension="Ratchet",
                severity=Severity.ADVISORY,
                observation=f"{log_path.name} exists but appears to have {entry_count} entries.",
                context="An empty or template-only failure log provides no traceability. The log's value comes from real failure records, not the template.",
                suggestion="Consider adding at least one real entry to the failure log, or note why the current rules were added.",
                skip_if="This is a new project and no failures have occurred yet.",
                evidence=str(log_path.relative_to(repo_root)),
            ))

    # R2 — Rules have traceability references
    if instructions:
        prohibitive_rules, _ = _classify_rules(instructions, prohibitive_kws, convention_kws)
        untraced = [r for r in prohibitive_rules if not _TRACE_PATTERNS.search(r)]
        if len(untraced) > untraced_warn:
            sev = Severity.FINDING if is_agent else Severity.WARNING
            findings.append(Finding(
                rule_id="R2",
                dimension="Ratchet",
                severity=sev,
                observation=f"{len(untraced)} prohibitive rule(s) lack traceability references (threshold: {untraced_warn}).",
                context=f"For {ctx}, prohibitive rules ('never', 'do not', 'must not') should each trace to a specific failure that motivated them. Untraced rules are often stale or redundant.",
                suggestion="Consider adding inline references to your failure log: '# Never do X. (→ WW21-session-3, HSD-14020144528)'",
                skip_if="This is a new project with rules derived from design principles rather than observed failures.",
            ))

    # R3 — Too many untraced prohibitive rules (brainstormed rules)
    if instructions:
        prohibitive_rules, _ = _classify_rules(instructions, prohibitive_kws, convention_kws)
        all_untraced = [r for r in prohibitive_rules if not _TRACE_PATTERNS.search(r)]
        ratio = len(all_untraced) / max(len(prohibitive_rules), 1)
        if len(prohibitive_rules) > 5 and ratio > 0.7:
            findings.append(Finding(
                rule_id="R3",
                dimension="Ratchet",
                severity=Severity.WARNING,
                observation=f"{int(ratio*100)}% of prohibitive rules ({len(all_untraced)}/{len(prohibitive_rules)}) lack failure traceability.",
                context="A high ratio of untraced prohibitive rules suggests the instructions were written upfront rather than grown from real failures. These rules may not reflect actual agent behavior problems.",
                suggestion="Consider doing a rule audit: for each prohibitive rule, find the failure that motivated it. Rules with no corresponding failure may be speculative and could be removed.",
                skip_if="This is a new agent repo where initial rules were designed based on domain knowledge rather than failure history.",
            ))

    # R5 — Bidirectional traceability (agent-repo gets FINDING, general gets ADVISORY)
    if log_path and instructions:
        prohibitive_rules, _ = _classify_rules(instructions, prohibitive_kws, convention_kws)
        log_has_references = any(
            rule_ref.strip().lower() in log_text.lower()
            for rule_ref in ["R1", "R2", "rule", "→"]
        )
        instr_has_log_refs = bool(_TRACE_PATTERNS.search(instructions))
        if not log_has_references and not instr_has_log_refs and prohibitive_rules:
            sev = Severity.FINDING if is_agent else Severity.ADVISORY
            findings.append(Finding(
                rule_id="R5",
                dimension="Ratchet",
                severity=sev,
                observation="Instructions and failure log exist but appear to have no cross-references.",
                context="Bidirectional traceability — instructions pointing to failure log entries, and log entries naming the rules they generated — makes the ratchet auditable and maintainable.",
                suggestion="Consider adding a 'Rule Added' column to your failure log table, and inline log references in your instructions file.",
                skip_if="You maintain traceability in a separate tracking system external to the repo.",
                evidence=f"{log_path.name} ↔ instructions",
            ))

    # R6 — Rules have "remove when" conditions
    if instructions:
        prohibitive_rules, _ = _classify_rules(instructions, prohibitive_kws, convention_kws)
        if prohibitive_rules and not _REMOVE_WHEN_RE.search(instructions):
            findings.append(Finding(
                rule_id="R6",
                dimension="Ratchet",
                severity=Severity.ADVISORY,
                observation="No 'remove when' or 'retire when' conditions found in instructions.",
                context="Rules without expiry conditions tend to accumulate indefinitely. A 'remove when' clause (e.g., 'remove when the underlying bug is fixed') keeps the ratchet from overgrowing.",
                suggestion="Consider adding removal conditions to at least your most specific rules: '# Never do X. Remove when: Bug HSD-12345 is closed.'",
                skip_if="Your rules are permanent architectural decisions that don't have natural expiry conditions.",
            ))

    # R7 — Stale rules (prohibitive rules older than 6 months by date reference)
    if instructions:
        dates_found = re.findall(r"(\d{4})-(\d{2})-(\d{2})", instructions)
        if dates_found:
            import datetime
            threshold = datetime.date.today().replace(year=datetime.date.today().year - 1)
            old_dates = [
                f"{y}-{m}-{d}" for y, m, d in dates_found
                if datetime.date(int(y), int(m), int(d)) < threshold
            ]
            if old_dates:
                findings.append(Finding(
                    rule_id="R7",
                    dimension="Ratchet",
                    severity=Severity.ADVISORY,
                    observation=f"Found {len(old_dates)} rule date reference(s) older than 1 year: {', '.join(old_dates[:3])}...",
                    context="Old rule references may indicate rules that were added for bugs that are now fixed, platform versions that are no longer supported, or behaviors that have changed.",
                    suggestion="Consider reviewing rules with old date references to determine if they still apply. Archive retired rules rather than deleting them.",
                    skip_if="The old dates are failure log entries, not active rule references.",
                ))

    return findings
