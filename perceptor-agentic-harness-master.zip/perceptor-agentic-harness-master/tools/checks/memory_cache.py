"""
@engram — Memory, caching, and knowledge transfer checks (M1–M6).

Verifies that the harness has mechanisms to persist verified facts,
carry context across sessions, and avoid re-querying for known results.
"""
from __future__ import annotations

import re
from pathlib import Path
from typing import List

from tools.orientation import RepoProfile
from tools.finding import Finding, Severity


_MEMORY_PATHS = [
    ".copilot/memories",
    "memories/repo",
    "memories",
    ".agents/memories",
    ".claude/memories",
]
_CACHE_FILE_RE = re.compile(
    r"verified.?transform|known.?good|sv.?path.?cache|verified.?fact"
    r"|facts.?cache|platform.?cache|cache",
    re.IGNORECASE,
)
_SESSION_HANDOFF_RE = re.compile(
    r"session\s+handoff|continuation|context\s+window|compaction|session.?memo|handoff",
    re.IGNORECASE,
)
_CACHE_CHECK_RE = re.compile(
    r"check.*cache|check.*verified|before.*query|cache.*before|consult.*cache",
    re.IGNORECASE,
)
_DOMAIN_KNOWLEDGE_RE = re.compile(
    r"platform[-_\s]?specific|silicon[-_\s]specific|DUT[-_\s]?specific"
    r"|architecture[-_\s]?note|register[-_\s]?fact|known[-_\s]?value",
    re.IGNORECASE,
)


def _find_instructions_text(repo_root: Path) -> str:
    for candidate in (
        ".github/copilot-instructions.md",
        "copilot-instructions.md",
        ".github/AGENTS.md",
        "AGENTS.md",
    ):
        p = repo_root / candidate
        if p.exists():
            try:
                return p.read_text(encoding="utf-8", errors="ignore")
            except OSError:
                pass
    return ""


def _find_cache_files(repo_root: Path) -> list[Path]:
    caches = []
    for f in repo_root.rglob("*.md"):
        if _CACHE_FILE_RE.search(f.name):
            caches.append(f)
    for f in repo_root.rglob("*.yaml"):
        if _CACHE_FILE_RE.search(f.name):
            caches.append(f)
    return caches


def _find_memory_dirs(repo_root: Path) -> list[str]:
    found = []
    for mp in _MEMORY_PATHS:
        if (repo_root / mp).is_dir():
            found.append(mp)
    return found


def _cache_has_entries(cache_path: Path) -> bool:
    try:
        text = cache_path.read_text(encoding="utf-8", errors="ignore")
        # Has at least one table row or list item beyond headers
        rows = [l for l in text.splitlines()
                if re.match(r"^\|\s*\S", l) and "---" not in l]
        items = [l for l in text.splitlines()
                 if re.match(r"^[\s]*[-*]\s+\S", l)]
        return len(rows) > 1 or len(items) > 0
    except OSError:
        return False


def run(repo_root: Path, profile: RepoProfile, cfg: dict) -> List[Finding]:
    findings: List[Finding] = []
    repo_root = Path(repo_root)
    ctx = profile.context_phrase()
    is_agent = profile.is_agent_repo()

    instructions = _find_instructions_text(repo_root)
    cache_files = _find_cache_files(repo_root)
    memory_dirs = _find_memory_dirs(repo_root)

    # M1 — Verified-facts cache exists
    if not cache_files:
        sev = Severity.FINDING if is_agent else Severity.ADVISORY
        findings.append(Finding(
            rule_id="M1",
            dimension="Engram",
            severity=sev,
            observation="No verified-facts cache file found (checked for: verified_transforms.md, known_good.md, cache*.md in config/ or reports/).",
            context=f"For {ctx}, re-querying MCP tools or external services for already-verified facts wastes tokens every session. A cache stores what's been confirmed to work.",
            suggestion="Consider creating config/verified_transforms.md (or similar) to record confirmed platform parameters, known-good transforms, and lookup results.",
            skip_if="This repo doesn't make repeated queries for facts that could be cached, or all state is in code.",
        ))
    else:
        for cache_file in cache_files:
            if not _cache_has_entries(cache_file):
                findings.append(Finding(
                    rule_id="M1",
                    dimension="Engram",
                    severity=Severity.ADVISORY,
                    observation=f"{cache_file.relative_to(repo_root)} appears to be an empty template.",
                    context="An empty cache provides no token savings. The cache is only useful once verified facts are recorded.",
                    suggestion="Consider populating the cache with at least one confirmed result per domain area (platform parameters, register values, API patterns).",
                    skip_if="The cache was just created and is being populated in progress.",
                    evidence=str(cache_file.relative_to(repo_root)),
                ))

    # M2 — Memory persistence
    if not memory_dirs:
        if is_agent:
            findings.append(Finding(
                rule_id="M2",
                dimension="Engram",
                severity=Severity.WARNING,
                observation="No memory persistence directory found (.copilot/memories, memories/repo, etc.).",
                context=f"For {ctx}, agent repos benefit from persistent memory that survives session restarts. Without it, the agent re-learns the same context on every session.",
                suggestion="Consider creating memories/repo/ for session-to-session handoff notes, or using .copilot/memories/ for Copilot memory integration.",
                skip_if="This agent uses a different memory mechanism (e.g., database, external key-value store).",
            ))
    else:
        # Check if memory dirs have any content
        empty_dirs = [d for d in memory_dirs if not any((repo_root / d).iterdir())]
        if empty_dirs:
            findings.append(Finding(
                rule_id="M2",
                dimension="Engram",
                severity=Severity.ADVISORY,
                observation=f"Memory director{'ies' if len(empty_dirs) > 1 else 'y'} exist but appear empty: {', '.join(empty_dirs)}.",
                context="An empty memory directory provides no value. Seeding it with known project facts reduces re-orientation time on each new session.",
                suggestion="Consider adding initial memory notes: platform names, key file paths, known agent pitfalls, and tested configuration values.",
                skip_if="Memory is being populated dynamically by the agent and was just created.",
            ))

    # M3 — Session-to-session handoff
    if is_agent and not _SESSION_HANDOFF_RE.search(instructions) and not memory_dirs:
        findings.append(Finding(
            rule_id="M3",
            dimension="Engram",
            severity=Severity.WARNING,
            observation="No session handoff mechanism detected in instructions or as a memory directory.",
            context=f"For {ctx}, long-running agent workflows often span multiple sessions. Without a handoff mechanism, each session restarts cold with no memory of previous progress.",
            suggestion="Consider documenting a handoff pattern: 'At session end, write a 5-line summary to memories/repo/session-handoff.md.'",
            skip_if="Your workflow fits within a single session and doesn't need session continuity.",
        ))

    # M4 — "Check cache before querying" rule in instructions
    if cache_files and instructions and not _CACHE_CHECK_RE.search(instructions):
        findings.append(Finding(
            rule_id="M4",
            dimension="Engram",
            severity=Severity.WARNING,
            observation="Verified-facts cache exists but instructions don't tell the agent to check it before querying.",
            context="A cache is only used if the agent knows to check it. An instruction like 'Before calling [tool], check config/verified_transforms.md' makes the cache actionable.",
            suggestion="Consider adding a rule: 'Before querying [MCP tool], check config/verified_transforms.md for cached results.'",
            skip_if="The agent checks the cache automatically via tool logic, not via instructions.",
            evidence=", ".join(str(f.relative_to(repo_root)) for f in cache_files[:2]),
        ))

    # M5 — Durable state via filesystem
    if is_agent:
        has_state_files = any(
            (repo_root / d).is_dir()
            for d in ("data", "reports", "state", "output", "artifacts")
        )
        if not has_state_files and not memory_dirs:
            findings.append(Finding(
                rule_id="M5",
                dimension="Engram",
                severity=Severity.ADVISORY,
                observation="No durable state directories found (data/, reports/, state/, output/, artifacts/).",
                context="Without a designated output directory, agent-produced results are ephemeral. Persisting outputs allows for diffing, auditing, and debugging regressions.",
                suggestion="Consider creating a data/ or reports/ directory and having the agent write artifacts there for review.",
                skip_if="This agent produces in-memory output only and downstream systems handle persistence.",
            ))

    # M6 — Domain knowledge captured
    if is_agent and not _DOMAIN_KNOWLEDGE_RE.search(instructions):
        all_md = []
        for f in list(repo_root.rglob("*.md"))[:30]:
            try:
                all_md.append(f.read_text(encoding="utf-8", errors="ignore")[:500])
            except OSError:
                pass
        combined_md = "\n".join(all_md)
        if not _DOMAIN_KNOWLEDGE_RE.search(combined_md):
            findings.append(Finding(
                rule_id="M6",
                dimension="Engram",
                severity=Severity.ADVISORY,
                observation="No domain-specific knowledge notes detected (platform facts, architecture notes, silicon-specific values).",
                context=f"For {ctx}, domain knowledge that the agent re-derives on every session (platform-specific parameters, known API quirks, hardware constraints) is a token budget drain.",
                suggestion="Consider documenting domain facts in config/verified_transforms.md or memories/repo/ so agents don't re-derive them from scratch each session.",
                skip_if="This repo's domain is well-covered by public documentation and doesn't need custom knowledge capture.",
            ))

    return findings
