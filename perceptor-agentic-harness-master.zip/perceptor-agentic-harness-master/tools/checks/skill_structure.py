"""
@spectrum — Skill decomposition & progressive disclosure checks (S1–S8).

Analyzes SKILL.md files for size, single responsibility, quality of descriptions,
and progressive loading patterns.
"""
from __future__ import annotations

import re
from pathlib import Path
from typing import List

from tools.orientation import RepoProfile
from tools.finding import Finding, Severity


_YAML_FRONT_MATTER_RE = re.compile(r"^---\s*\n(.*?)\n---\s*\n", re.DOTALL)
_USE_WHEN_RE = re.compile(r"Use\s+when|When\s+to\s+use|Triggers?\s*:", re.IGNORECASE)
_AND_JOIN_RE = re.compile(
    r"(classif\w+\s+AND\s+generat\w+|port\w+\s+AND\s+analyz\w+|\w+\s+AND\s+\w+\s+AND\s+\w+)",
    re.IGNORECASE,
)
_DO_NOT_USE_RE = re.compile(r"DO\s+NOT\s+USE\s+FOR|When\s+NOT\s+to\s+use", re.IGNORECASE)


def _parse_yaml_frontmatter(text: str) -> dict[str, str]:
    m = _YAML_FRONT_MATTER_RE.match(text)
    if not m:
        return {}
    result: dict[str, str] = {}
    for line in m.group(1).splitlines():
        if ":" in line:
            key, _, value = line.partition(":")
            result[key.strip()] = value.strip()
    return result


def _prose_ratio(text: str) -> float:
    """Fraction of non-empty lines that are passive prose (not headings, lists, code)."""
    lines = [l.strip() for l in text.splitlines() if l.strip()]
    if not lines:
        return 0.0
    # Remove YAML frontmatter
    if text.startswith("---"):
        end = text.find("\n---\n", 3)
        text = text[end + 5:] if end != -1 else text
        lines = [l.strip() for l in text.splitlines() if l.strip()]

    active = [l for l in lines if re.match(r"^(#{1,4}|[-*]|\d+\.|\|)", l)]
    return 1.0 - (len(active) / max(len(lines), 1))


def run(repo_root: Path, profile: RepoProfile, cfg: dict) -> List[Finding]:
    findings: List[Finding] = []
    repo_root = Path(repo_root)
    spectrum_cfg = cfg.get("spectrum", {})
    max_lines = spectrum_cfg.get("skill_max_lines", 200)
    min_skills_for_manifest = spectrum_cfg.get("min_skills_for_manifest", 3)
    min_desc_words = spectrum_cfg.get("description_min_words", 10)
    ctx = profile.context_phrase()

    skill_files = list(repo_root.rglob("SKILL.md"))

    if not skill_files:
        if profile.is_agent_repo():
            findings.append(Finding(
                rule_id="S0",
                dimension="Spectrum",
                severity=Severity.ADVISORY,
                observation="No SKILL.md files found in this repo.",
                context=f"For {ctx}, skills are the on-demand context units that load only when their task is active.",
                suggestion="Consider whether any always-injected context could be moved to a SKILL.md for on-demand loading.",
                skip_if="This repo uses a single monolithic copilot-instructions.md and doesn't need modular skills.",
            ))
        return findings

    for skill_path in skill_files:
        try:
            skill_text = skill_path.read_text(encoding="utf-8", errors="ignore")
        except OSError:
            continue
        rel = skill_path.relative_to(repo_root)
        line_count = len(skill_text.splitlines())
        fm = _parse_yaml_frontmatter(skill_text)

        # S1 — Monolithic skill size
        if line_count > max_lines:
            findings.append(Finding(
                rule_id="S1",
                dimension="Spectrum",
                severity=Severity.FINDING,
                observation=f"{rel} is {line_count} lines (threshold: {max_lines}).",
                context=f"For {ctx}, skill files larger than ~{max_lines} lines are hard to compose and tend to handle multiple responsibilities.",
                suggestion=f"Consider splitting {rel.name} into two or more skills with narrower responsibilities. A skill should have a single, clear job.",
                skip_if="The extra lines are all behavioral instructions for a genuinely complex single task.",
                evidence=str(rel),
            ))

        # S3 — YAML frontmatter has name + description
        has_name = "name" in fm
        has_description = "description" in fm
        if not has_name or not has_description:
            missing = []
            if not has_name:
                missing.append("name")
            if not has_description:
                missing.append("description")
            findings.append(Finding(
                rule_id="S3",
                dimension="Spectrum",
                severity=Severity.WARNING,
                observation=f"{rel} is missing YAML frontmatter field(s): {', '.join(missing)}.",
                context="VS Code uses SKILL.md frontmatter to discover and invoke skills. Missing fields prevent the skill from being auto-suggested.",
                suggestion=f"Consider adding frontmatter to {rel.name}:\n```yaml\n---\nname: {rel.parent.name}\ndescription: Use when ...\n---\n```",
                skip_if="This skill is invoked manually and doesn't need auto-discovery.",
                evidence=str(rel),
            ))

        # S4 — Description has trigger keywords
        description = fm.get("description", "")
        if description and not _USE_WHEN_RE.search(description):
            word_count = len(description.split())
            if word_count < min_desc_words:
                findings.append(Finding(
                    rule_id="S4",
                    dimension="Spectrum",
                    severity=Severity.ADVISORY,
                    observation=f"{rel} description is too short ({word_count} words) and lacks trigger keywords.",
                    context="VS Code's skill selection uses the description to determine when to load a skill. A description without 'Use when' or trigger context leads to poor auto-invocation.",
                    suggestion=f"Consider rewriting the description to include a trigger: 'Use when the user asks to [task]. Do NOT use for [anti-case].'",
                    skip_if="This skill has disable-model-invocation: true and is only triggered manually.",
                    evidence=str(rel),
                ))
            elif not _USE_WHEN_RE.search(description):
                findings.append(Finding(
                    rule_id="S4",
                    dimension="Spectrum",
                    severity=Severity.ADVISORY,
                    observation=f"{rel} description lacks 'Use when' or equivalent trigger wording.",
                    context="Model-invocable skills rely on trigger phrases in their description for reliable auto-selection.",
                    suggestion="Consider prefixing the description with 'Use when: ...' or 'Triggers: ...'",
                    skip_if="This skill is triggered manually and doesn't rely on model invocation.",
                    evidence=str(rel),
                ))

        # S5 — Progressive loading pattern
        # Check if skill loads other skills or has explicit "load when" logic
        has_progressive = re.search(
            r"load.*skill|read.*SKILL\.md|progressive|on.?demand|when.*active",
            skill_text,
            re.IGNORECASE,
        )
        if line_count > 100 and not has_progressive:
            findings.append(Finding(
                rule_id="S5",
                dimension="Spectrum",
                severity=Severity.ADVISORY,
                observation=f"{rel} is {line_count} lines but shows no progressive loading pattern.",
                context="Large skills that load all their content upfront contribute to context rot. Loading sub-skills or sections on demand extends the effective context budget.",
                suggestion=f"Consider breaking {rel.name} into a coordinator skill + sub-skills that are read only when that sub-task is active.",
                skip_if="This skill is a brief checklist that's intended to be fully loaded at once.",
                evidence=str(rel),
            ))

        # S6 — Single responsibility
        if _AND_JOIN_RE.search(description or ""):
            findings.append(Finding(
                rule_id="S6",
                dimension="Spectrum",
                severity=Severity.ADVISORY,
                observation=f"{rel} description appears to join unrelated tasks with 'AND'.",
                context="Skills that do two unrelated things are harder to invoke precisely and harder to test.",
                suggestion=f"Consider splitting {rel.name} so each skill has a single job. 'Use when X' should have one clear answer.",
                skip_if="The tasks in the description are genuinely part of the same workflow.",
                evidence=str(rel),
            ))

        # S7 — Skill content ratio (not just documentation)
        if line_count > 30:
            prose = _prose_ratio(skill_text)
            if prose > 0.70:
                findings.append(Finding(
                    rule_id="S7",
                    dimension="Spectrum",
                    severity=Severity.ADVISORY,
                    observation=f"{rel} is ~{int(prose * 100)}% passive prose (threshold: 70%).",
                    context="Skills that are mostly narrative documentation rather than structured behavioral instructions provide less value per token.",
                    suggestion="Consider restructuring the skill with numbered steps, checklists, or decision tables rather than free-form prose.",
                    skip_if="This skill is intentionally a reference document, loaded when the agent needs background knowledge.",
                    evidence=str(rel),
                ))

        # S8 — Broad skills need DO NOT USE FOR clause
        broad_triggers = re.search(
            r"(any|all|everything|general|universal|always\s+use)",
            description,
            re.IGNORECASE,
        )
        if broad_triggers and not _DO_NOT_USE_RE.search(skill_text):
            findings.append(Finding(
                rule_id="S8",
                dimension="Spectrum",
                severity=Severity.ADVISORY,
                observation=f"{rel} has a broad trigger description but no 'DO NOT USE FOR' clause.",
                context="Broad trigger descriptions increase false-positive invocations. A 'DO NOT USE FOR' clause helps the model avoid loading the skill for unrelated tasks.",
                suggestion=f"Consider adding a 'DO NOT USE FOR:' section to {rel.name} listing scenarios where this skill should NOT be invoked.",
                skip_if="This skill is genuinely universal and there are no meaningful anti-cases.",
                evidence=str(rel),
            ))

    # S2 — Manifest for multi-skill repos
    if len(skill_files) >= min_skills_for_manifest and not (repo_root / "manifest.yaml").exists():
        findings.append(Finding(
            rule_id="S2",
            dimension="Spectrum",
            severity=Severity.WARNING,
            observation=f"Repo has {len(skill_files)} skill files but no manifest.yaml.",
            context=f"For {ctx}, a manifest.yaml documents the skill inventory so contributors understand the scope before adding new skills.",
            suggestion="Consider creating manifest.yaml listing all skills, their paths, and descriptions.",
            skip_if="Your skills are documented in README.md with equivalent detail.",
        ))

    return findings
