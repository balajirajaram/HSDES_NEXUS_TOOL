"""
@probe — Test coverage & verification pattern checks (P1–P7).

Verifies that judgment-intensive skills have tests, that generator/evaluator
patterns are present, and that no classifiers run without tests.
"""
from __future__ import annotations

import ast
import re
from pathlib import Path
from typing import List

from tools.orientation import RepoProfile
from tools.finding import Finding, Severity


_JUDGMENT_RE = re.compile(
    r"classif|adapt|generat|evaluat|resolv|transform|analyz|port",
    re.IGNORECASE,
)
_TEST_FUNCTION_RE = re.compile(r"def\s+test_\w+", re.IGNORECASE)
_EVALUATOR_PATTERNS = re.compile(
    r"evaluator|scorer|verif|check.*output|validate.*output|assess",
    re.IGNORECASE,
)
_GENERATOR_PATTERNS = re.compile(
    r"generator|generat|produce|create|build|write.*output",
    re.IGNORECASE,
)


def _find_skill_files(repo_root: Path) -> list[Path]:
    return list(repo_root.rglob("SKILL.md"))


def _find_test_files(repo_root: Path) -> list[Path]:
    tests = []
    for test_dir in ("tests", "test", "__tests__", "spec"):
        base = repo_root / test_dir
        if base.is_dir():
            tests.extend(base.rglob("test_*.py"))
            tests.extend(base.rglob("*_test.py"))
    return tests


def _count_test_functions(test_file: Path) -> int:
    try:
        text = test_file.read_text(encoding="utf-8", errors="ignore")
        return len(_TEST_FUNCTION_RE.findall(text))
    except OSError:
        return 0


def _find_python_modules(repo_root: Path) -> list[Path]:
    """Find Python modules that are not tests."""
    modules = []
    skip_dirs = {"tests", "test", "__tests__", ".git", "__pycache__", "venv", ".venv"}
    for f in repo_root.rglob("*.py"):
        if any(part in skip_dirs for part in f.parts):
            continue
        if f.name.startswith("test_") or f.name.endswith("_test.py"):
            continue
        modules.append(f)
    return modules


def _has_judgment_logic(py_file: Path) -> tuple[bool, list[str]]:
    """Return (has_judgment, list_of_matching_function_names)."""
    try:
        text = py_file.read_text(encoding="utf-8", errors="ignore")
        matches = []
        try:
            tree = ast.parse(text)
            for node in ast.walk(tree):
                if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    if _JUDGMENT_RE.search(node.name):
                        matches.append(node.name)
        except SyntaxError:
            # Fallback to regex
            for line in text.splitlines():
                m = re.search(r"def\s+(\w*(?:classif|adapt|generat|evaluat)\w*)", line, re.I)
                if m:
                    matches.append(m.group(1))
        return bool(matches), matches
    except OSError:
        return False, []


def _test_covers_module(module_name: str, test_files: list[Path]) -> bool:
    """Check if any test file appears to cover a module name."""
    stem = module_name.lower().replace("-", "_")
    for tf in test_files:
        tf_stem = tf.stem.lower().replace("test_", "").replace("_test", "")
        if tf_stem in stem or stem in tf_stem:
            return True
    return False


def run(repo_root: Path, profile: RepoProfile, cfg: dict) -> List[Finding]:
    findings: List[Finding] = []
    repo_root = Path(repo_root)
    probe_cfg = cfg.get("probe", {})
    ctx = profile.context_phrase()

    skill_files = _find_skill_files(repo_root)
    test_files = _find_test_files(repo_root)
    py_modules = _find_python_modules(repo_root)

    # P1 — Tests directory exists
    if not test_files:
        sev = Severity.FINDING if profile.is_agent_repo() else Severity.WARNING
        findings.append(Finding(
            rule_id="P1",
            dimension="Probe",
            severity=sev,
            observation="No test files found (checked: tests/, test/, __tests__/).",
            context=f"For {ctx}, tests are essential for judgment-intensive logic (classifiers, adapters, generators). Without tests, regressions in agent output are invisible.",
            suggestion="Consider creating tests/unit/ and adding tests for your most critical skill logic (classification, adaptation, generation).",
            skip_if="This repo has no judgment logic — it's configuration-only or read-only.",
        ))
        return findings

    total_test_fns = sum(_count_test_functions(tf) for tf in test_files)

    # P2 — Judgment-intensive skills have tests
    judgment_modules = []
    for mod in py_modules:
        has_j, funcs = _has_judgment_logic(mod)
        if has_j:
            judgment_modules.append((mod, funcs))

    untested_judgment = [
        (mod, funcs) for mod, funcs in judgment_modules
        if not _test_covers_module(mod.stem, test_files)
    ]
    if untested_judgment:
        first_names = [mod.stem for mod, _ in untested_judgment[:3]]
        sev = Severity.CRITICAL if len(untested_judgment) > 3 else Severity.FINDING
        findings.append(Finding(
            rule_id="P2",
            dimension="Probe",
            severity=sev,
            observation=f"{len(untested_judgment)} judgment-intensive module(s) have no corresponding test file: {', '.join(first_names)}{'...' if len(untested_judgment) > 3 else ''}",
            context=f"For {ctx}, classifiers and adapters are the highest-risk code. A single wrong classification or bad parameter transform can silently corrupt outputs.",
            suggestion="Consider adding a test file for each judgment module. At minimum, test the known-bad inputs that motivated each rule.",
            skip_if="The judgment logic is trivial string matching with no conditional branching.",
            evidence=", ".join(str(m.relative_to(repo_root)) for m, _ in untested_judgment[:5]),
        ))

    # P3 — Generator/evaluator split
    has_generator = any(
        _GENERATOR_PATTERNS.search(mod.read_text(encoding="utf-8", errors="ignore"))
        for mod in py_modules[:20]
        if mod.stat().st_size < 100_000
    )
    has_evaluator = any(
        _EVALUATOR_PATTERNS.search(mod.read_text(encoding="utf-8", errors="ignore"))
        for mod in py_modules[:20]
        if mod.stat().st_size < 100_000
    )
    if has_generator and not has_evaluator and profile.is_agent_repo():
        findings.append(Finding(
            rule_id="P3",
            dimension="Probe",
            severity=Severity.FINDING,
            observation="Generator patterns detected but no evaluator/validator patterns found.",
            context=f"For {ctx}, agents tend to skew positive on self-evaluation. A separate evaluator that critically assesses generated output catches errors the generator won't surface.",
            suggestion="Consider separating generation from evaluation: generate output in one pass, then evaluate it in a second pass before delivery.",
            skip_if="Your workflow has an external evaluator or the output is validated by downstream tests.",
        ))

    # P4 — Test-to-skill ratio
    if skill_files and test_files:
        ratio = len(test_files) / max(len(skill_files), 1)
        if ratio < 0.5:
            findings.append(Finding(
                rule_id="P4",
                dimension="Probe",
                severity=Severity.ADVISORY,
                observation=f"Test-to-skill ratio is {ratio:.1f} ({len(test_files)} test files / {len(skill_files)} skill files).",
                context="A ratio below 0.5 suggests judgment-intensive skills may not have corresponding tests.",
                suggestion="Consider adding at least one test file per skill that has classification, adaptation, or generation logic.",
                skip_if="Your skills are documentation-only and have no testable code.",
            ))

    # P5 — Total test count warning (very low)
    if total_test_fns < 3 and len(test_files) > 0:
        findings.append(Finding(
            rule_id="P5",
            dimension="Probe",
            severity=Severity.WARNING,
            observation=f"Only {total_test_fns} test function(s) found across {len(test_files)} test file(s).",
            context="A very small test count relative to the codebase suggests the test suite covers only a fraction of critical logic.",
            suggestion="Consider expanding the test suite to cover edge cases, known-bad inputs, and regression scenarios for each judgment-intensive function.",
            skip_if="The test suite is still being bootstrapped and coverage is growing.",
        ))

    # P6 — Edge case coverage (heuristic: do tests cover sentinel/boundary values?)
    edge_case_re = re.compile(
        r"0xFFFF|None|empty|invalid|boundary|edge.?case|sentinel|overflow|underflow",
        re.IGNORECASE,
    )
    test_texts = []
    for tf in test_files[:20]:
        try:
            test_texts.append(tf.read_text(encoding="utf-8", errors="ignore"))
        except OSError:
            pass
    combined_tests = "\n".join(test_texts)
    if combined_tests and not edge_case_re.search(combined_tests):
        findings.append(Finding(
            rule_id="P6",
            dimension="Probe",
            severity=Severity.ADVISORY,
            observation="Test files don't appear to cover sentinel values, boundary conditions, or None inputs.",
            context="Edge cases (sentinel values, overflow, empty inputs) are the most common source of classification errors in production.",
            suggestion="Consider adding tests that pass None, empty strings, very large values, and known sentinel values (e.g., 0xFFFF) to each classifier or adapter.",
            skip_if="Your test suite covers these in integration tests not detected by this heuristic.",
        ))

    # P7 — No test-free classifiers
    classifier_modules = [
        (mod, funcs) for mod, funcs in judgment_modules
        if any("classif" in f.lower() for f in funcs)
    ]
    untested_classifiers = [
        (mod, funcs) for mod, funcs in classifier_modules
        if not _test_covers_module(mod.stem, test_files)
    ]
    if untested_classifiers:
        findings.append(Finding(
            rule_id="P7",
            dimension="Probe",
            severity=Severity.CRITICAL,
            observation=f"Classifier(s) with no test coverage: {', '.join(mod.stem for mod, _ in untested_classifiers)}.",
            context="Classifiers are the highest-risk single point of failure in an agent workflow. An untested classifier silently makes wrong decisions on every run.",
            suggestion="Consider treating classifier tests as mandatory. At minimum: one test per classification category, one test for each edge case from your failure log.",
            skip_if="These are trivial string comparisons with a single code path.",
            evidence=", ".join(str(mod.relative_to(repo_root)) for mod, _ in untested_classifiers),
        ))

    return findings
