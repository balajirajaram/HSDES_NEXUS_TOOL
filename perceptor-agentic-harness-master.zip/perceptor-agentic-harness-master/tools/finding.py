"""
Shared Finding data model used by all check modules.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum


class Severity(str, Enum):
    CRITICAL = "critical"           # -3.0 pts
    FINDING = "finding"             # -1.5 pts
    WARNING = "warning"             # -1.0 pts
    ADVISORY = "advisory"           # -0.5 pts
    INFORMATIONAL = "informational" # 0.0 pts

    @property
    def score_impact(self) -> float:
        return {
            "critical": 3.0,
            "finding": 1.5,
            "warning": 1.0,
            "advisory": 0.5,
            "informational": 0.0,
        }[self.value]


@dataclass
class Finding:
    rule_id: str                 # e.g. "L1", "R3", "E2"
    dimension: str               # e.g. "Lens", "Ratchet"
    severity: Severity
    observation: str             # Factual — what was found
    context: str                 # Why it matters for this repo
    suggestion: str              # "Consider..." language
    skip_if: str = ""            # When to ignore this suggestion
    evidence: str = ""           # Optional: file path / line excerpt
