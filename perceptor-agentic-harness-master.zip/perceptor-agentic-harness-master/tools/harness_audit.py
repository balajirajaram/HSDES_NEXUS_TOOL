"""
Perceptor Agentic Harness — CLI orchestrator.

Usage:
    python tools/harness_audit.py --target /path/to/repo
    python tools/harness_audit.py --target . --json
    python tools/harness_audit.py --target . --format html
    python tools/harness_audit.py --target . --context "hardware validation testline porting"
    python tools/harness_audit.py --target . --only lens ratchet
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

# Ensure the repo root is on sys.path regardless of cwd
_REPO_ROOT = Path(__file__).resolve().parent.parent
if str(_REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(_REPO_ROOT))

from tools.orientation import detect_profile
from tools.finding import Finding, Severity
from tools.checks import context_size, failure_history, skill_structure, enforcement, test_coverage, memory_cache


# ---------------------------------------------------------------------------
# Config loading (stdlib YAML fallback)
# ---------------------------------------------------------------------------

def _load_config(repo_root: Path) -> dict:
    """Load merged config: defaults.yaml → thresholds.yaml → inline defaults."""
    cfg: dict = {}

    def _parse_yaml_simple(text: str) -> dict:
        """Minimal YAML parser for flat key: value under a top-level key."""
        result: dict = {}
        current_section: str | None = None
        current_subsection: str | None = None
        for line in text.splitlines():
            if not line.strip() or line.strip().startswith("#"):
                continue
            indent = len(line) - len(line.lstrip())
            stripped = line.strip()
            if indent == 0 and stripped.endswith(":"):
                current_section = stripped[:-1]
                current_subsection = None
                result.setdefault(current_section, {})
            elif indent == 2 and stripped.endswith(":") and current_section:
                current_subsection = stripped[:-1]
                result[current_section].setdefault(current_subsection, {})
            elif indent == 4 and current_section and current_subsection and ":" in stripped:
                key, _, value = stripped.partition(":")
                value = value.strip()
                try:
                    parsed = float(value) if "." in value else int(value)
                except ValueError:
                    parsed = value.strip('"\'')  # type: ignore[assignment]
                result[current_section][current_subsection][key.strip()] = parsed
            elif indent == 2 and current_section and not stripped.endswith(":") and ":" in stripped:
                key, _, value = stripped.partition(":")
                value = value.strip()
                try:
                    parsed = float(value) if "." in value else int(value)
                except ValueError:
                    parsed = value.strip('"\'')  # type: ignore[assignment]
                result[current_section][key.strip()] = parsed
        return result

    def _try_load_file(path: Path) -> dict:
        if not path.exists():
            return {}
        text = path.read_text(encoding="utf-8", errors="ignore")
        try:
            import yaml  # type: ignore[import]
            return yaml.safe_load(text) or {}
        except ImportError:
            return _parse_yaml_simple(text)
        except Exception:
            return _parse_yaml_simple(text)

    defaults_path = _REPO_ROOT / "config" / "defaults.yaml"
    thresholds_path = _REPO_ROOT / "config" / "thresholds.yaml"

    raw_defaults = _try_load_file(defaults_path)
    raw_thresholds = _try_load_file(thresholds_path)

    perceptor_cfg = raw_defaults.get("perceptor", {})
    # Deep merge thresholds over defaults
    for key, val in raw_thresholds.items():
        if isinstance(val, dict) and key in perceptor_cfg:
            perceptor_cfg[key].update(val)
        elif val:
            perceptor_cfg[key] = val

    return perceptor_cfg


# ---------------------------------------------------------------------------
# Scoring
# ---------------------------------------------------------------------------

_DIMENSION_CHECKS = {
    "lens": context_size,
    "ratchet": failure_history,
    "spectrum": skill_structure,
    "reflex": enforcement,
    "probe": test_coverage,
    "engram": memory_cache,
}

_DEFAULT_WEIGHTS = {
    "lens": 0.20,
    "ratchet": 0.20,
    "spectrum": 0.15,
    "reflex": 0.20,
    "probe": 0.15,
    "engram": 0.10,
}

_GRADES = [(9.0, "A"), (7.0, "B"), (5.0, "C"), (3.0, "D"), (0.0, "F")]


def _compute_dimension_score(findings: list[Finding], max_score: float = 10.0) -> float:
    deductions = sum(f.severity.score_impact for f in findings)
    return max(0.0, max_score - deductions)


def _compute_weighted_score(dimension_scores: dict[str, float], weights: dict[str, float]) -> float:
    total = sum(dimension_scores.get(dim, 10.0) * weight for dim, weight in weights.items())
    return total


def _grade(score: float) -> str:
    for threshold, letter in _GRADES:
        if score >= threshold:
            return letter
    return "F"


# ---------------------------------------------------------------------------
# Output serialization
# ---------------------------------------------------------------------------

def _findings_to_dicts(findings: list[Finding]) -> list[dict]:
    return [
        {
            "rule_id": f.rule_id,
            "dimension": f.dimension,
            "observation": f.observation,
            "context": f.context,
            "suggestion": f.suggestion,
            "skip_if": f.skip_if,
            "evidence": f.evidence,
        }
        for f in findings
    ]


def _build_report_json(
    target: Path,
    profile_dict: dict,
    dimension_scores: dict[str, float],
    weighted_score: float,
    all_findings: dict[str, list[Finding]],
) -> dict:
    return {
        "tool": "perceptor-agentic-harness",
        "version": "1.0.0",
        "target": str(target),
        "profile": profile_dict,
        "score": {
            "weighted": round(weighted_score, 2),
            "grade": _grade(weighted_score),
            "dimensions": {
                dim: round(score, 2)
                for dim, score in dimension_scores.items()
            },
        },
        "findings": {
            dim: _findings_to_dicts(findings)
            for dim, findings in all_findings.items()
        },
        "total_findings": sum(len(v) for v in all_findings.values()),
    }


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def _print_utf8(text: str) -> None:
    """Print text to stdout with UTF-8 encoding (avoids cp1252 errors on Windows)."""
    sys.stdout.buffer.write((text + "\n").encode("utf-8", errors="replace"))
    sys.stdout.buffer.flush()


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="harness_audit",
        description="Perceptor Agentic Harness — harness engineering audit toolkit",
    )
    parser.add_argument(
        "--target", "-t",
        default=".",
        help="Path to the repo to audit (default: current directory)",
    )
    parser.add_argument(
        "--context", "-c",
        default="",
        help="Optional context hint describing the repo's domain/purpose",
    )
    parser.add_argument(
        "--format", "-f",
        choices=["markdown", "json", "html"],
        default="markdown",
        help="Output format (default: markdown)",
    )
    parser.add_argument(
        "--json",
        action="store_true",
        help="Shorthand for --format json",
    )
    parser.add_argument(
        "--only",
        nargs="+",
        choices=list(_DIMENSION_CHECKS.keys()),
        help="Run only the specified dimension(s)",
    )
    parser.add_argument(
        "--no-save",
        action="store_true",
        help="Do not save the report to the reports/ directory (default: always save)",
    )
    parser.add_argument(
        "--output-dir", "-o",
        default=None,
        help="Directory to save reports (default: <harness-repo>/reports/)",
    )
    args = parser.parse_args(argv)

    target = Path(args.target).resolve()
    if not target.is_dir():
        print(f"Error: target '{target}' is not a directory.", file=sys.stderr)
        return 1

    output_format = "json" if args.json else args.format

    # Phase 0: Orientation
    profile = detect_profile(target, context_hint=args.context)
    cfg = _load_config(target if (target / "config" / "defaults.yaml").exists() else _REPO_ROOT)

    # Select dimensions to run
    dimensions_to_run = args.only if args.only else list(_DIMENSION_CHECKS.keys())

    # Phase 1-6: Run checks
    all_findings: dict[str, list[Finding]] = {}
    dimension_scores: dict[str, float] = {}
    weights = cfg.get("weights", _DEFAULT_WEIGHTS)

    for dim in _DIMENSION_CHECKS:
        if dim not in dimensions_to_run:
            dimension_scores[dim] = 10.0
            all_findings[dim] = []
            continue
        checker = _DIMENSION_CHECKS[dim]
        findings = checker.run(target, profile, cfg)
        all_findings[dim] = findings
        dimension_scores[dim] = _compute_dimension_score(findings)

    weighted_score = _compute_weighted_score(dimension_scores, weights)

    # Build profile dict for output
    profile_dict = {
        "repo_type": profile.repo_type,
        "domain": profile.domain,
        "description": profile.description[:100] if profile.description else "",
        "skill_count": profile.skill_count,
        "is_agent_repo": profile.is_agent_repo(),
        "has_tests": profile.has_tests,
        "has_known_failures": profile.has_known_failures,
        "has_mcp": profile.has_mcp,
    }

    # Output
    if output_format == "json":
        report = _build_report_json(target, profile_dict, dimension_scores, weighted_score, all_findings)
        _print_utf8(json.dumps(report, indent=2))
    elif output_format == "html":
        from tools.report.html_report import render_html
        html = render_html(target, profile, profile_dict, dimension_scores, weighted_score, all_findings)
        _print_utf8(html)
    else:
        from tools.report.markdown_report import render_markdown
        md = render_markdown(target, profile, profile_dict, dimension_scores, weighted_score, all_findings)
        _print_utf8(md)

    # Always save both .md and .html reports — --no-save suppresses this behaviour.
    if not args.no_save:
        import datetime
        from tools.report.markdown_report import render_markdown
        from tools.report.html_report import render_html
        reports_dir = Path(args.output_dir).resolve() if args.output_dir else _REPO_ROOT / "reports"
        reports_dir.mkdir(parents=True, exist_ok=True)
        ts = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        stem = f"audit_{target.name}_{ts}"

        # Always write markdown
        md = render_markdown(target, profile, profile_dict, dimension_scores, weighted_score, all_findings)
        md_file = reports_dir / f"{stem}.md"
        md_file.write_text(md, encoding="utf-8")
        print(f"\nReport saved to: {md_file}", file=sys.stderr)

        # Always write interactive HTML
        html = render_html(target, profile, profile_dict, dimension_scores, weighted_score, all_findings)
        html_file = reports_dir / f"{stem}.html"
        html_file.write_text(html, encoding="utf-8")
        print(f"Report saved to: {html_file}", file=sys.stderr)

        # Also write JSON if that was the requested format
        if output_format == "json":
            report = _build_report_json(target, profile_dict, dimension_scores, weighted_score, all_findings)
            json_file = reports_dir / f"{stem}.json"
            json_file.write_text(json.dumps(report, indent=2), encoding="utf-8")
            print(f"Report saved to: {json_file}", file=sys.stderr)

    # Exit code: 0 = A or B, 1 = C or below
    return 0 if _grade(weighted_score) in ("A", "B") else 1


if __name__ == "__main__":
    sys.exit(main())
