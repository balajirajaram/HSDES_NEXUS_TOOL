"""
Orientation module — Phase 0 of every harness audit.

Detects the target repo's type, domain, and profile before any specialist
check runs. This allows specialists to:
  - Suppress irrelevant checks entirely
  - Contextualize suggestions to the repo's actual purpose
  - Adapt severity based on repo profile

Usage:
    from tools.orientation import detect_profile, RepoProfile
    profile = detect_profile(Path("/path/to/repo"), context_hint="hardware validation")
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional


# ---------------------------------------------------------------------------
# Data model
# ---------------------------------------------------------------------------

REPO_TYPES = {
    "agent-repo",        # Defines/orchestrates LLM agents or skills
    "codegen-repo",      # Generates code/scripts from specs
    "automation-repo",   # Automates workflows (CI, email, calendar)
    "library-repo",      # Shared utilities, no agent behavior
    "application-repo",  # End-user app, Copilot as dev tool
    "unknown",
}


@dataclass
class RepoProfile:
    """Complete orientation profile for a target repo."""
    repo_type: str = "unknown"            # One of REPO_TYPES
    domain: str = ""                      # e.g. "hardware validation", "testline porting"
    description: str = ""                 # Human-readable repo description
    purpose_verbs: list[str] = field(default_factory=list)  # e.g. ["generate", "classify"]

    # Structural facts
    skill_count: int = 0
    agent_count: int = 0
    has_manifest: bool = False
    has_instructions: bool = False
    has_dut: bool = False                 # Executes on live hardware/DUT
    has_mcp: bool = False                 # Uses MCP servers
    has_tests: bool = False
    has_known_failures: bool = False
    has_hooks: bool = False
    has_validation_tool: bool = False
    has_memory: bool = False
    has_cache: bool = False

    # Context hint from user (--context flag)
    user_hint: str = ""

    def is_agent_repo(self) -> bool:
        return self.repo_type in ("agent-repo", "codegen-repo")

    def context_phrase(self) -> str:
        """Short phrase describing the repo for use in suggestion Context fields."""
        if self.user_hint:
            return self.user_hint
        if self.domain:
            parts = [self.domain]
            if self.skill_count:
                parts.append(f"{self.skill_count} skill{'s' if self.skill_count != 1 else ''}")
            return " — ".join(parts)
        if self.description:
            return self.description[:100]
        return "this repo"


# ---------------------------------------------------------------------------
# Detection helpers
# ---------------------------------------------------------------------------

_SKILL_FILE_NAMES = {"SKILL.md", "skill.md"}
_AGENT_FILE_EXTENSIONS = {".agent.md"}
_INSTRUCTION_NAMES = {"copilot-instructions.md", "AGENTS.md", "CLAUDE.md"}
_HOOK_DIRS = {".github/hooks", "hooks"}
_VALIDATION_PATTERNS = re.compile(
    r"validate|lint|check|verify|test_output|back.?pressure", re.IGNORECASE
)
_MCP_PATTERNS = re.compile(r"mcp_|\.mcp\.|mcpServers|mcp-server", re.IGNORECASE)
_DUT_PATTERNS = re.compile(r"\bDUT\b|dut_target|ssh.*root@|ipccli|itp\s*=", re.IGNORECASE)
_MEMORY_PATHS = [
    ".copilot/memories", "memories/repo", ".agents/memories",
    "memories", ".claude/memories",
]
_CACHE_PATTERNS = re.compile(
    r"verified.?transform|sv.?path.?cache|known.?good|verified.?facts|cache",
    re.IGNORECASE,
)
_FAILURE_LOG_NAMES = re.compile(
    r"known.?fail|failure.?log|failures|FAILURES|ratchet", re.IGNORECASE
)
_PURPOSE_VERBS = [
    "generate", "classify", "adapt", "port", "debug", "validate", "analyze",
    "transform", "evaluate", "resolve", "screen", "audit", "report",
]

# Repo type heuristic signals
_AGENT_SIGNALS = [
    lambda p: any(p.rglob("SKILL.md")),
    lambda p: any(f.suffix == "" and (p / f).is_dir()
                  for f in p.iterdir()
                  if (p / f / "SKILL.md").exists()),
    lambda p: any(f.name.endswith(".agent.md") for f in p.rglob("*.agent.md")),
    lambda p: _has_manifest_with_skills(p),
]

_CODEGEN_SIGNALS = re.compile(
    r"generat|codegen|scaffold|template|render.*script|script.*from.*spec",
    re.IGNORECASE,
)
_AUTOMATION_SIGNALS = re.compile(
    r"automat|workflow|pipeline|email|calendar|ci/cd|orchestrat",
    re.IGNORECASE,
)


def _has_manifest_with_skills(repo_root: Path) -> bool:
    manifest = repo_root / "manifest.yaml"
    if not manifest.exists():
        return False
    try:
        content = manifest.read_text(encoding="utf-8", errors="ignore")
        return "skills:" in content
    except OSError:
        return False


def _count_skill_files(repo_root: Path) -> int:
    return sum(1 for _ in repo_root.rglob("SKILL.md"))


def _count_agent_files(repo_root: Path) -> int:
    return sum(1 for _ in repo_root.rglob("*.agent.md"))


def _read_description(repo_root: Path) -> tuple[str, str]:
    """Return (description, domain) from README or manifest."""
    # Try manifest first
    manifest = repo_root / "manifest.yaml"
    if manifest.exists():
        try:
            content = manifest.read_text(encoding="utf-8", errors="ignore")
            m = re.search(r"description:\s*[>|]?\s*\n?\s*(.+)", content)
            if m:
                return m.group(1).strip().rstrip("\\"), ""
        except OSError:
            pass

    # Try README
    for readme_name in ("README.md", "readme.md", "README.txt"):
        readme = repo_root / readme_name
        if readme.exists():
            try:
                lines = readme.read_text(encoding="utf-8", errors="ignore").splitlines()
                # First non-empty non-heading line after the title
                for line in lines[:20]:
                    line = line.strip()
                    if line and not line.startswith("#") and not line.startswith("!"):
                        return line[:200], ""
            except OSError:
                pass

    return "", ""


def _detect_domain(description: str, instructions_text: str, user_hint: str) -> str:
    """Extract a short domain phrase from available text."""
    if user_hint:
        return user_hint

    combined = f"{description} {instructions_text}".lower()

    domain_patterns = [
        (r"hardware\s+validation|register\s+validation|silicon\s+validation", "hardware validation"),
        (r"testline\s+port|catalog.*port|porting.*testline", "testline porting"),
        (r"security\s+analy|vulnerability|threat\s+model", "security analysis"),
        (r"pythonsv|pythonsv.*codegen|register.*generat", "PythonSV code generation"),
        (r"memory\s+test|ddr.*test|dimm.*valid", "memory validation"),
        (r"harness\s+engineer|audit.*harness|harness.*audit", "harness engineering audit"),
        (r"email|outlook|calendar|m365|office\s+automat", "M365 automation"),
        (r"wiki.*crawl|confluence.*crawl|crawl.*wiki", "wiki crawling"),
    ]
    for pattern, domain in domain_patterns:
        if re.search(pattern, combined):
            return domain
    return ""


def _detect_purpose_verbs(description: str, instructions_text: str) -> list[str]:
    combined = f"{description} {instructions_text}".lower()
    return [v for v in _PURPOSE_VERBS if v in combined]


def _detect_repo_type(
    repo_root: Path, description: str, instructions_text: str
) -> str:
    # Agent signals first
    for signal in _AGENT_SIGNALS:
        try:
            if signal(repo_root):
                return "agent-repo"
        except Exception:
            pass

    combined = f"{description} {instructions_text}"
    if _CODEGEN_SIGNALS.search(combined):
        return "codegen-repo"
    if _AUTOMATION_SIGNALS.search(combined):
        return "automation-repo"

    # If there's a .github/copilot-instructions.md or AGENTS.md it's at least using Copilot
    if any((repo_root / name).exists() for name in _INSTRUCTION_NAMES):
        return "application-repo"

    return "unknown"


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def detect_profile(repo_root: Path, context_hint: str = "") -> RepoProfile:
    """
    Run Phase 0 orientation on a target repo.

    Args:
        repo_root: Path to the repo root directory.
        context_hint: Optional user-provided description (--context flag).

    Returns:
        RepoProfile with all detected facts populated.
    """
    repo_root = Path(repo_root).resolve()

    # Gather raw text for pattern matching
    instructions_text = ""
    for name in _INSTRUCTION_NAMES:
        p = repo_root / ".github" / name
        if not p.exists():
            p = repo_root / name
        if p.exists():
            try:
                instructions_text += p.read_text(encoding="utf-8", errors="ignore")
                break
            except OSError:
                pass

    description, _ = _read_description(repo_root)
    domain = _detect_domain(description, instructions_text, context_hint)
    repo_type = _detect_repo_type(repo_root, description, instructions_text)

    # Structural facts
    skill_count = _count_skill_files(repo_root)
    agent_count = _count_agent_files(repo_root)
    has_manifest = (repo_root / "manifest.yaml").exists()
    has_instructions = any(
        (repo_root / ".github" / n).exists() or (repo_root / n).exists()
        for n in _INSTRUCTION_NAMES
    )

    # DUT / MCP
    all_text = instructions_text + description
    for py_file in list(repo_root.rglob("*.py"))[:50]:  # sample first 50 .py files
        try:
            all_text += py_file.read_text(encoding="utf-8", errors="ignore")[:500]
        except OSError:
            pass
    has_dut = bool(_DUT_PATTERNS.search(all_text))
    has_mcp = bool(_MCP_PATTERNS.search(all_text))

    # Tests
    has_tests = any(
        (repo_root / d).is_dir() for d in ("tests", "test", "__tests__", "spec")
    )

    # Known failures log
    has_known_failures = any(
        _FAILURE_LOG_NAMES.search(f.name)
        for f in repo_root.rglob("*.md")
        if f.is_file()
    )

    # Hooks
    has_hooks = any(
        (repo_root / d).is_dir() for d in _HOOK_DIRS
    ) or any(
        "hooks:" in f.read_text(encoding="utf-8", errors="ignore")
        for f in repo_root.rglob("*.agent.md")
        if f.is_file()
    )

    # Validation tool
    has_validation_tool = any(
        _VALIDATION_PATTERNS.search(f.name)
        for f in (repo_root / "tools").rglob("*.py")
        if f.is_file()
    ) if (repo_root / "tools").is_dir() else False

    # Memory
    has_memory = any(
        (repo_root / mp).is_dir() for mp in _MEMORY_PATHS
    ) or (repo_root / "memories").is_dir()

    # Cache
    has_cache = any(
        _CACHE_PATTERNS.search(f.name)
        for f in repo_root.rglob("*.md")
        if f.is_file() and "config" in str(f).lower()
    )

    return RepoProfile(
        repo_type=repo_type,
        domain=domain,
        description=description,
        purpose_verbs=_detect_purpose_verbs(description, instructions_text),
        skill_count=skill_count,
        agent_count=agent_count,
        has_manifest=has_manifest,
        has_instructions=has_instructions,
        has_dut=has_dut,
        has_mcp=has_mcp,
        has_tests=has_tests,
        has_known_failures=has_known_failures,
        has_hooks=has_hooks,
        has_validation_tool=has_validation_tool,
        has_memory=has_memory,
        has_cache=has_cache,
        user_hint=context_hint,
    )
