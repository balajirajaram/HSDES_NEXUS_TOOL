"""
Interactive HTML report renderer for harness audit results.
No CDN dependencies — pure SVG radar chart computed server-side.
Features: SVG radar + bar charts, dark/light mode, filterable findings,
          copy-to-clipboard, expand/collapse, print layout.
"""
from __future__ import annotations

import math
from pathlib import Path

from tools.finding import Finding
from tools.orientation import RepoProfile

_GRADE_COLOR = {"A": "#22c55e", "B": "#eab308", "C": "#f97316", "D": "#ef4444", "F": "#dc2626"}
_DIM_FULL_NAMES = {
    "lens":     "Lens",
    "ratchet":  "Ratchet",
    "spectrum": "Spectrum",
    "reflex":   "Reflex",
    "probe":    "Probe",
    "engram":   "Engram",
}
_DIM_SUBTITLES = {
    "lens":     "Context Injection",
    "ratchet":  "Failure Traceability",
    "spectrum": "Skill Structure",
    "reflex":   "Enforcement & Hooks",
    "probe":    "Test Coverage",
    "engram":   "Memory & Cache",
}


def _esc(text: str) -> str:
    return (text
            .replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
            .replace('"', "&quot;"))


def _radar_svg(scores: list[float], labels: list[str], size: int = 220) -> str:
    """Build a static SVG radar/spider chart — no JavaScript required."""
    n = len(scores)
    cx = cy = size / 2
    r_max = size / 2 - 30          # max radius for score=10
    rings = [2, 4, 6, 8, 10]

    def pt(score: float, i: int) -> tuple[float, float]:
        angle = math.pi / 2 - 2 * math.pi * i / n
        r = r_max * score / 10.0
        return cx + r * math.cos(angle), cy - r * math.sin(angle)

    def ring_pt(val: float, i: int) -> tuple[float, float]:
        angle = math.pi / 2 - 2 * math.pi * i / n
        r = r_max * val / 10.0
        return cx + r * math.cos(angle), cy - r * math.sin(angle)

    lines = []

    # Ring grid lines
    for rv in rings:
        pts = [ring_pt(rv, i) for i in range(n)]
        polygon = " ".join(f"{x:.1f},{y:.1f}" for x, y in pts)
        opacity = "0.25" if rv < 10 else "0.45"
        lines.append(f'<polygon points="{polygon}" fill="none" stroke="currentColor" '
                      f'stroke-width="0.8" opacity="{opacity}"/>')
        # Ring label at top
        lx, ly = ring_pt(rv, 0)
        lines.append(f'<text x="{lx:.1f}" y="{ly - 3:.1f}" text-anchor="middle" '
                      f'font-size="7" opacity="0.5" fill="currentColor">{rv}</text>')

    # Spoke lines
    for i in range(n):
        ex, ey = pt(10.0, i)
        lines.append(f'<line x1="{cx:.1f}" y1="{cy:.1f}" x2="{ex:.1f}" y2="{ey:.1f}" '
                      f'stroke="currentColor" stroke-width="0.8" opacity="0.3"/>')

    # Data polygon
    data_pts = [pt(s, i) for i, s in enumerate(scores)]
    poly_str = " ".join(f"{x:.1f},{y:.1f}" for x, y in data_pts)
    lines.append(f'<polygon points="{poly_str}" fill="#3b82f6" fill-opacity="0.18" '
                  f'stroke="#3b82f6" stroke-width="2"/>')

    # Data points
    for x, y in data_pts:
        lines.append(f'<circle cx="{x:.1f}" cy="{y:.1f}" r="4" fill="#3b82f6"/>')

    # Axis labels
    label_r = r_max + 18
    for i, label in enumerate(labels):
        angle = math.pi / 2 - 2 * math.pi * i / n
        lx = cx + label_r * math.cos(angle)
        ly = cy - label_r * math.sin(angle)
        anchor = "middle" if abs(math.cos(angle)) < 0.3 else ("start" if math.cos(angle) > 0 else "end")
        baseline = "auto" if math.sin(angle) > 0.1 else ("hanging" if math.sin(angle) < -0.1 else "middle")
        score = scores[i]
        lines.append(f'<text x="{lx:.1f}" y="{ly:.1f}" text-anchor="{anchor}" '
                      f'dominant-baseline="{baseline}" font-size="10" font-weight="600" '
                      f'fill="currentColor">{_esc(label)}</text>')
        lines.append(f'<text x="{lx:.1f}" y="{ly + 12:.1f}" text-anchor="{anchor}" '
                      f'font-size="8.5" fill="#3b82f6">{score:.1f}</text>')

    inner = "\n  ".join(lines)
    return (f'<svg width="{size}" height="{size}" viewBox="0 0 {size} {size}" '
            f'style="max-width:100%;display:block;margin:0 auto;" '
            f'xmlns="http://www.w3.org/2000/svg">\n  {inner}\n</svg>')


def _bar_svg(scores: list[float], labels: list[str], colors: list[str]) -> str:
    """Horizontal bar chart SVG — static, no JS."""
    row_h = 28
    label_w = 62
    bar_area = 170
    h_pad = 8
    n = len(scores)
    width = label_w + bar_area + 44
    height = n * row_h + h_pad * 2

    rows = []
    for i, (score, label, color) in enumerate(zip(scores, labels, colors)):
        y = h_pad + i * row_h
        bar_w = bar_area * score / 10.0
        mid = y + row_h / 2
        rows.append(
            f'<text x="{label_w - 6}" y="{mid:.1f}" text-anchor="end" '
            f'dominant-baseline="middle" font-size="10" fill="currentColor">{_esc(label)}</text>'
        )
        rows.append(
            f'<rect x="{label_w}" y="{y + 5}" width="{bar_area}" height="{row_h - 10}" '
            f'rx="3" fill="currentColor" opacity="0.08"/>'
        )
        rows.append(
            f'<rect x="{label_w}" y="{y + 5}" width="{bar_w:.1f}" height="{row_h - 10}" '
            f'rx="3" fill="{color}"/>'
        )
        rows.append(
            f'<text x="{label_w + bar_w + 5:.1f}" y="{mid:.1f}" '
            f'dominant-baseline="middle" font-size="9.5" font-weight="600" fill="{color}">'
            f'{score:.1f}</text>'
        )

    inner = "\n  ".join(rows)
    return (f'<svg width="{width}" height="{height}" viewBox="0 0 {width} {height}" '
            f'style="max-width:100%;display:block;" xmlns="http://www.w3.org/2000/svg">\n  {inner}\n</svg>')


def render_html(
    target: Path,
    profile: RepoProfile,
    profile_dict: dict,
    dimension_scores: dict[str, float],
    weighted_score: float,
    all_findings: dict[str, list[Finding]],
) -> str:
    from tools.harness_audit import _grade

    grade = _grade(weighted_score)
    grade_color = _GRADE_COLOR.get(grade, "#6b7280")
    total = sum(len(v) for v in all_findings.values())
    generated = __import__("datetime").datetime.now().strftime("%Y-%m-%d %H:%M")

    dims = list(_DIM_FULL_NAMES.keys())
    scores_list = [dimension_scores.get(d, 10.0) for d in dims]
    labels_list = [_DIM_FULL_NAMES[d] for d in dims]

    def _bar_color(s: float) -> str:
        return "#22c55e" if s >= 8 else "#eab308" if s >= 6 else "#f97316" if s >= 4 else "#ef4444"

    bar_colors = [_bar_color(s) for s in scores_list]

    radar = _radar_svg(scores_list, labels_list, size=230)
    bars  = _bar_svg(scores_list, [_DIM_SUBTITLES[d] for d in dims], bar_colors)

    # Score ring
    radius = 52
    circ = 2 * math.pi * radius
    fill = circ * weighted_score / 10.0
    dash = f"{fill:.1f} {circ - fill:.1f}"

    # Score table rows
    score_rows = ""
    for dim in dims:
        score = dimension_scores.get(dim, 10.0)
        count = len(all_findings.get(dim, []))
        pct = int(score * 10)
        bc = _bar_color(score)
        score_rows += (
            f'<tr class="score-row" data-dim="{dim}" title="Jump to {_DIM_FULL_NAMES[dim]}">'
            f'<td><span class="fw6">{_esc(_DIM_FULL_NAMES[dim])}</span>'
            f'<br><small class="muted">{_esc(_DIM_SUBTITLES[dim])}</small></td>'
            f'<td><div class="bar-track"><div class="bar-fill" style="width:{pct}%;background:{bc}"></div></div></td>'
            f'<td class="fw6 tabnum">{score:.1f}</td>'
            f'<td><span class="badge {"bclean" if count == 0 else "bwarn"}">{count}</span></td>'
            f'</tr>'
        )

    # Finding sections
    finding_sections = ""
    for dim in dims:
        findings = all_findings.get(dim, [])
        score = dimension_scores.get(dim, 10.0)
        sc = _bar_color(score)
        cards = ""
        for f in findings:
            ev = (f'<div class="evidence">Evidence: <code>{_esc(f.evidence)}</code></div>'
                  if f.evidence else "")
            sk = (f'<div class="skip">Skip if: {_esc(f.skip_if)}</div>'
                  if f.skip_if else "")
            cards += (
                f'<div class="finding-card" data-dim="{dim}">'
                f'<div class="card-head">'
                f'<span class="rule-id">{_esc(f.rule_id)}</span>'
                f'<button class="copy-btn" onclick="copyCard(this)" title="Copy">&#128203;</button>'
                f'</div>'
                f'<div class="card-body">'
                f'<div class="field"><span class="flabel">Observation</span>{_esc(f.observation)}</div>'
                f'<div class="field"><span class="flabel">Context</span>{_esc(f.context)}</div>'
                f'<div class="field suggest"><span class="flabel">Suggestion</span>{_esc(f.suggestion)}</div>'
                f'{sk}{ev}'
                f'</div></div>'
            )
        clean = ('<div class="clean-msg">&#10003; No suggestions &mdash; dimension is clean</div>'
                 if not findings else "")
        finding_sections += (
            f'<details class="dim-section" id="dim-{dim}" open>'
            f'<summary><div class="sum-inner">'
            f'<span class="fw7">{_esc(_DIM_FULL_NAMES[dim])}</span>'
            f'<span class="muted sm">{_esc(_DIM_SUBTITLES[dim])}</span>'
            f'<span style="color:{sc};font-weight:700">{score:.1f}/10</span>'
            f'<span class="badge {"bclean" if not findings else "bwarn"}">{len(findings)}</span>'
            f'</div></summary>'
            f'<div class="findings-body">{clean}{cards}</div>'
            f'</details>'
        )

    profile_rows = "".join(
        f'<tr><td class="muted">{_esc(str(k))}</td><td>{_esc(str(v))}</td></tr>'
        for k, v in profile_dict.items()
    )

    filter_btns = '<button class="fbtn active" data-dim="all" onclick="setDim(\'all\',this)">All (' + str(total) + ')</button>'
    for d in dims:
        cnt = len(all_findings.get(d, []))
        if cnt:
            filter_btns += (
                f'<button class="fbtn" data-dim="{d}" onclick="setDim(\'{d}\',this)">'
                f'{_esc(_DIM_FULL_NAMES[d])} ({cnt})</button>'
            )

    return f"""<!DOCTYPE html>
<html lang="en" data-theme="light">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Perceptor Audit &mdash; {_esc(target.name)}</title>
<style>
:root{{--bg:#f8fafc;--surf:#fff;--bord:#e2e8f0;--txt:#1e293b;--muted:#64748b;--acc:#3b82f6}}
[data-theme=dark]{{--bg:#0f172a;--surf:#1e293b;--bord:#334155;--txt:#f1f5f9;--muted:#94a3b8;--acc:#60a5fa}}
*{{box-sizing:border-box;margin:0;padding:0}}
body{{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;background:var(--bg);color:var(--txt);font-size:14px;line-height:1.55}}
.page{{max-width:1080px;margin:0 auto;padding:20px 16px}}
/* header */
.hdr{{display:flex;align-items:flex-start;justify-content:space-between;flex-wrap:wrap;gap:10px;margin-bottom:20px}}
.hdr h1{{font-size:1.3rem;font-weight:700}}
.meta{{color:var(--muted);font-size:.8rem;margin-top:3px}}
.meta code{{background:var(--bord);padding:1px 4px;border-radius:3px}}
.hdr-btns{{display:flex;gap:8px;flex-wrap:wrap}}
.btn{{padding:5px 12px;border-radius:6px;border:1px solid var(--bord);background:var(--surf);color:var(--txt);cursor:pointer;font-size:.8rem}}
.btn:hover{{background:var(--acc);color:#fff;border-color:var(--acc)}}
/* score strip */
.strip{{display:grid;grid-template-columns:auto 1fr;gap:20px;background:var(--surf);border:1px solid var(--bord);border-radius:10px;padding:18px;margin-bottom:18px;align-items:center}}
@media(max-width:580px){{.strip{{grid-template-columns:1fr}}}}
.ring-wrap{{position:relative;width:120px;height:120px;flex-shrink:0}}
.ring-wrap svg{{transform:rotate(-90deg)}}
.ring-lbl{{position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center}}
.ring-num{{font-size:1.7rem;font-weight:800;color:{grade_color}}}
.ring-grade{{font-size:.9rem;font-weight:700;color:{grade_color}}}
table.stbl{{width:100%;border-collapse:collapse}}
.stbl th{{text-align:left;padding:5px 8px;color:var(--muted);font-size:.72rem;text-transform:uppercase;letter-spacing:.05em;border-bottom:1px solid var(--bord)}}
.stbl td{{padding:6px 8px;border-bottom:1px solid var(--bord);vertical-align:middle}}
.stbl tr:last-child td{{border-bottom:none}}
.stbl tr.score-row:hover td{{background:var(--bg);cursor:pointer}}
.bar-track{{background:var(--bord);border-radius:4px;height:9px;width:150px}}
.bar-fill{{height:9px;border-radius:4px}}
.tabnum{{font-variant-numeric:tabular-nums;font-weight:600;font-size:.85rem}}
.badge{{display:inline-block;padding:1px 7px;border-radius:9999px;font-size:.72rem;font-weight:700}}
.bclean{{background:#dcfce7;color:#166534}}
.bwarn{{background:#fef3c7;color:#92400e}}
[data-theme=dark] .bclean{{background:#14532d;color:#86efac}}
[data-theme=dark] .bwarn{{background:#451a03;color:#fcd34d}}
/* charts row */
.charts{{display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-bottom:18px}}
@media(max-width:640px){{.charts{{grid-template-columns:1fr}}}}
.card{{background:var(--surf);border:1px solid var(--bord);border-radius:10px;padding:16px}}
.card-title{{font-size:.75rem;font-weight:700;text-transform:uppercase;letter-spacing:.06em;color:var(--muted);margin-bottom:12px}}
.prof-tbl{{width:100%;border-collapse:collapse;font-size:.82rem}}
.prof-tbl tr{{border-bottom:1px solid var(--bord)}}
.prof-tbl tr:last-child{{border-bottom:none}}
.prof-tbl td{{padding:4px 0}}
/* toolbar */
.toolbar{{display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin-bottom:12px}}
.toolbar input{{flex:1;min-width:180px;padding:6px 10px;border:1px solid var(--bord);border-radius:6px;background:var(--surf);color:var(--txt);font-size:.85rem}}
.fbtns{{display:flex;gap:5px;flex-wrap:wrap}}
.fbtn{{padding:3px 10px;border-radius:9999px;border:1px solid var(--bord);background:var(--surf);color:var(--muted);cursor:pointer;font-size:.75rem}}
.fbtn.active{{background:var(--acc);color:#fff;border-color:var(--acc)}}
/* dim sections */
.dim-section{{background:var(--surf);border:1px solid var(--bord);border-radius:8px;margin-bottom:10px;overflow:hidden}}
.dim-section>summary{{list-style:none;padding:12px 16px;cursor:pointer;user-select:none}}
.dim-section>summary::-webkit-details-marker{{display:none}}
.dim-section>summary::before{{content:"▶";margin-right:8px;font-size:.65rem;color:var(--muted);transition:transform .15s;display:inline-block}}
.dim-section[open]>summary::before{{transform:rotate(90deg)}}
.sum-inner{{display:inline-flex;align-items:center;gap:10px;width:calc(100% - 20px)}}
.findings-body{{padding:4px 16px 14px}}
.clean-msg{{padding:10px 12px;background:#f0fdf4;color:#166534;border-radius:6px;font-size:.83rem}}
[data-theme=dark] .clean-msg{{background:#14532d;color:#86efac}}
/* finding card */
.finding-card{{border:1px solid var(--bord);border-radius:7px;margin:8px 0;overflow:hidden}}
.finding-card:hover{{border-color:var(--acc)}}
.card-head{{display:flex;align-items:center;justify-content:space-between;padding:7px 12px;background:var(--bg);border-bottom:1px solid var(--bord)}}
.rule-id{{font-weight:700;font-size:.8rem;font-family:monospace;color:var(--acc)}}
.copy-btn{{background:none;border:none;cursor:pointer;font-size:.9rem;opacity:.55;color:var(--txt)}}
.copy-btn:hover{{opacity:1}}
.card-body{{padding:10px 12px;display:grid;gap:6px}}
.field{{font-size:.83rem}}
.flabel{{display:block;font-size:.68rem;font-weight:700;text-transform:uppercase;letter-spacing:.07em;color:var(--muted);margin-bottom:2px}}
.suggest{{background:color-mix(in srgb,var(--acc) 7%,transparent);border-left:3px solid var(--acc);padding:7px 9px;border-radius:0 4px 4px 0}}
.skip,.evidence{{font-size:.78rem;color:var(--muted)}}
.evidence code{{background:var(--bord);padding:1px 4px;border-radius:3px;font-size:.75rem}}
/* utils */
.fw6{{font-weight:600}}.fw7{{font-weight:700}}.muted{{color:var(--muted)}}.sm{{font-size:.8rem}}
.footer{{text-align:center;font-size:.73rem;color:var(--muted);margin-top:24px}}
#toast{{position:fixed;bottom:20px;right:20px;background:#1e293b;color:#fff;padding:8px 16px;border-radius:7px;font-size:.82rem;opacity:0;transition:opacity .25s;pointer-events:none;z-index:99}}
#toast.show{{opacity:1}}
@media print{{.hdr-btns,.toolbar,summary::before,.copy-btn{{display:none}}details{{display:block}}}}
</style>
</head>
<body>
<div class="page">

<div class="hdr">
  <div>
    <h1>&#128270; Perceptor Harness Audit</h1>
    <div class="meta">
      Target: <code>{_esc(str(target))}</code> &nbsp;|&nbsp;
      Type: <strong>{_esc(profile_dict.get('repo_type','unknown'))}</strong>
      {(' &nbsp;|&nbsp; Domain: <strong>' + _esc(profile_dict['domain']) + '</strong>') if profile_dict.get('domain') else ''}
      &nbsp;|&nbsp; {_esc(generated)}
    </div>
  </div>
  <div class="hdr-btns">
    <button class="btn" onclick="toggleTheme()">&#9681; Theme</button>
    <button class="btn" onclick="expandAll()">Expand all</button>
    <button class="btn" onclick="collapseAll()">Collapse all</button>
    <button class="btn" onclick="window.print()">Print</button>
  </div>
</div>

<div class="strip">
  <div class="ring-wrap">
    <svg width="120" height="120" viewBox="0 0 120 120">
      <circle cx="60" cy="60" r="{radius}" fill="none" stroke="var(--bord)" stroke-width="11"/>
      <circle cx="60" cy="60" r="{radius}" fill="none" stroke="{grade_color}" stroke-width="11"
              stroke-dasharray="{dash}" stroke-linecap="round"/>
    </svg>
    <div class="ring-lbl">
      <span class="ring-num" id="snum">0.0</span>
      <span class="ring-grade">Grade {_esc(grade)}</span>
    </div>
  </div>
  <div>
    <table class="stbl">
      <thead><tr><th>Dimension</th><th>Score</th><th></th><th>Issues</th></tr></thead>
      <tbody>{score_rows}</tbody>
    </table>
  </div>
</div>

<div class="charts">
  <div class="card">
    <div class="card-title">Score Radar</div>
    {radar}
  </div>
  <div class="card">
    <div class="card-title">Score Bars</div>
    {bars}
    <div style="margin-top:14px">
      <div class="card-title" style="margin-bottom:8px">Repo Profile</div>
      <table class="prof-tbl">
        {profile_rows}
      </table>
    </div>
  </div>
</div>

<div class="toolbar">
  <input type="search" id="qbox" placeholder="Search findings..." oninput="doFilter()">
  <div class="fbtns">{filter_btns}</div>
</div>

<div id="fcon">{finding_sections}</div>

<div class="footer">
  Generated by <a href="https://github.com/intel-sandbox/perceptor-agentic-harness">perceptor-agentic-harness</a>
  &mdash; {total} suggestion{'s' if total != 1 else ''} across {len(dims)} dimensions
</div>
</div>

<div id="toast">Copied!</div>
<script>
const TARGET = {weighted_score:.2f};
let cur = 0;
const t = setInterval(()=>{{
  cur = Math.min(cur + TARGET/40, TARGET);
  document.getElementById('snum').textContent = cur.toFixed(1);
  if(cur >= TARGET) clearInterval(t);
}}, 25);

function toggleTheme(){{
  const el = document.documentElement;
  el.setAttribute('data-theme', el.getAttribute('data-theme')==='dark' ? 'light' : 'dark');
}}
function expandAll(){{ document.querySelectorAll('details.dim-section').forEach(d=>d.open=true); }}
function collapseAll(){{ document.querySelectorAll('details.dim-section').forEach(d=>d.open=false); }}

let activeDim = 'all';
function setDim(dim, btn){{
  activeDim = dim;
  document.querySelectorAll('.fbtn').forEach(b=>b.classList.remove('active'));
  btn.classList.add('active');
  doFilter();
}}
function doFilter(){{
  const q = document.getElementById('qbox').value.toLowerCase();
  document.querySelectorAll('details.dim-section').forEach(sec=>{{
    const dim = sec.id.replace('dim-','');
    if(activeDim !== 'all' && activeDim !== dim){{ sec.style.display='none'; return; }}
    sec.style.display='';
    if(!q){{ sec.querySelectorAll('.finding-card').forEach(c=>c.style.display=''); return; }}
    let any=false;
    sec.querySelectorAll('.finding-card').forEach(c=>{{
      const vis = c.textContent.toLowerCase().includes(q);
      c.style.display = vis ? '' : 'none';
      if(vis) any=true;
    }});
    sec.open = any;
  }});
}}
function copyCard(btn){{
  const body = btn.closest('.finding-card').querySelector('.card-body');
  const text = [...body.querySelectorAll('.field')].map(f=>{{
    const lbl = f.querySelector('.flabel')?.textContent??'';
    return lbl+': '+f.textContent.replace(lbl,'').trim();
  }}).join('\\n');
  navigator.clipboard.writeText(text).then(()=>toast('Copied!'));
}}
function toast(msg){{
  const el=document.getElementById('toast');
  el.textContent=msg; el.classList.add('show');
  setTimeout(()=>el.classList.remove('show'),2000);
}}
document.querySelectorAll('tr.score-row').forEach(r=>{{
  r.addEventListener('click',()=>{{
    const s=document.getElementById('dim-'+r.dataset.dim);
    if(s){{ s.open=true; s.scrollIntoView({{behavior:'smooth',block:'start'}}); }}
  }});
}});
</script>
</body>
</html>"""
